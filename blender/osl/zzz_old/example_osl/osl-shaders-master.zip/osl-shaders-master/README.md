osl-shaders
===========

a repository of osl shaders for Blender.

The Shaders directory and the corresponding shaders.zip file contain the shaders and the .blend files accompanying my book 'Open Shading Language for Blender' which is available on https://www.smashwords.com/books/view/368598 and major online retailers.
