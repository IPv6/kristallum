//@include "libs/comixgen.jsx"
//@include "libs/persutils.jsx"

var globals = {};
initComix("d:/Downloads/export", globals);

//======================================================
var duppedDocument = null;

// Body
//duppedDocument = cloneDocument(500, 500);
//app.activeDocument = duppedDocument;
//switchScene(null,"station");
//exportSprite("station");
//duppedDocument.close(SaveOptions.DONOTSAVECHANGES);

var parts = [
/*
	["facebase1","facebase1"], 
	["nose1","nose10037"],
	["nose2","nose10035"],
	["nose3","nose10028"],
	["nose4","nose10020"],
	["nose5","nose10019"],
	["nose6","nose10015"],
	["nose7","nose10007"],
	
	["eye_close1","eyes1"],
	["eye_close2","eyes12"],
	["eye_dead1","eyes31"],
	["eye_dead2","eyes32"],
	["eye_dead3","eyes33"],
	["eye_dead4","eyes34"],
	["eye_dead5","eyes35"],
	["eye_dead6","eyes38"],
	["eye_sur1","eyes36"],
	["eye_sur2","eyes37"],
	["eye_sur3","eyes39"],
	
	
	["eye1","eyes2"],
	["eye2","eyes4"],
	["eye3","eyes6"],
	["eye4","eyes7"],
	["eye5","eyes8"],
	["eye6","eyes9"],
	["eye7","eyes11"],
	["eye8","eyes14"],
	["eye9","eyes15"],
	["eye10","eyes16"],
	["eye11","eyes17"],
	["eye12","eyes18"],
	["eye13","eyes19"],
	["eye14","eyes20"],
	["eye15","eyes21"],
	["eye16","eyes22"],
	["eye17","eyes23"],
	["eye18","eyes24"],
	["eye19","eyes25"],
	["eye20","eyes26"],
	["eye21","eyes27"],
	["eye22","eyes28"],
	["eye23","eyes29"],
	["eye24","eyes42"],
	["eye25","eyes43"],
	["eye26","eyes44"],
	["eye27","eyes45"],
	["eye28","eyes46"],
	["eye29","eyes47"],
	["eye30","eyes48"],
	
	["facefeat1","facefeat1"],
	["facefeat2","facefeat2"],
	["facefeat3","facefeat3"],
	["facefeat4","facefeat4"],
	["facefeat5","facefeat6"],
	["facefeat6","facefeat10"],
	["facefeat7","facefeat12"],
	["facefeat8","facefeat14"],
	["facefeat9","facefeat15"],
	["facefeat10","facefeat16"],
	["facefeat11","facefeat16"],
		
	["hairfeat1","hairfeat5"],
	["hairfeat2","hairfeat3"],
	["hairfeat3","hairfeat2"],
	["hairfeat4","hairfeat1"]
*/

	["mouth_nrm1","mouth49"],
	["mouth_nrm2","mouth39"],
	["mouth_nrm3","mouth36"],
	["mouth_nrm4","mouth4"],
	["mouth_nrm5","mouth17"],
	["mouth_nrm6","mouth2"],
	["mouth_nope1","mouth47"],
	["mouth_nope2","mouth21"],
	["mouth_nope3","mouth20"],
	["mouth_nope4","mouth13"],
	["mouth_nope5","mouth10"],
	["mouth_hehe1","mouth8"],
	["mouth_hehe2","mouth32"],
	["mouth_hehe3","mouth27"],
	["mouth_hehe4","mouth22"],
	["mouth_hehe5","mouth7"],
	["mouth_open1","mouth41"],
	["mouth_open2","mouth6"],
	["mouth_open3","mouth37"],
	["mouth_open4","mouth1"],
	["mouth_open5","mouth16"],
	["mouth_open6","mouth15"],
	["mouth_open7","mouth44"],
	["mouth_open8","mouth9"],
	["mouth_angry1","mouth38"],
	["mouth_angry2","mouth6"],
	["mouth_angry3","mouth29"],
	["mouth_angry4","mouth18"],
	["mouth_sad1","mouth35"],
	["mouth_sad2","mouth33"],
	["mouth_sad3","mouth30"],
	["mouth_sad4","mouth3"],
	["mouth_sad5","mouth5"],
	["mouth_sad6","mouth40"],

	["eyebrow_sur1","eyebrow2"],
	["eyebrow_sur2","eyebrow8"],
	["eyebrow_sur3","eyebrow3"],
	["eyebrow_nrm1","eyebrow5"],
	["eyebrow_nrm2","eyebrow7"],
	["eyebrow_nrm3","eyebrow11"],
	["eyebrow_nrm4","eyebrow10"],
	["eyebrow_angry1","eyebrow4"],
	["eyebrow_angry2","eyebrow13"],
	["eyebrow_angry3","eyebrow6"],

	["hair1","hairs2"],
	["hair2","hairs3"],
	["hair3","hairs4"],
	["hair4","hairs5"],
	["hair5","hairs6"],
	["hair6","hairs7"],
	["hair7","hairs8"],
	["hair8","hairs9"],
	["hair9","hairs10"],
	["hair10","hairs11"],
	["hair11","hairs12"],
	["hair12","hairs13"],
	["hair13","hairs14"],
	["hair14","hairs15"],
	["hair15","hairs16"],
	["hair16","hairs17"],
	["hair17","hairs18"],
	["hair18","hairs20"],
	["hair19","hairs21"],
	["hair20","hairs22"],
	["hair21","hairs23"],
	["hair22","hairs24"],
	["hair23","hairs26"],
	["hair24","hairs27"],
	["hair25","hairs29"],
	["hair26","hairs30"],
	["hair27","hairs31"],
	["hair28","hairs32"],
	["hair29","hairs33"],
	["hair30","hairs34"],
	["hair31","hairs35"],
	["hair32","hairs36"],
	["hair33","hairs37"],
	["hair34","hairs39"],
	["hair35","hairs41"],
	["hair36","hairs42"],
	["hair37","hairs45"],
	["hair38","hairs46"],
	["hair39","hairs47"],
	["hair40","hairs48"],
	["hair41","hairs49"],
	["hair42","hairs50"],
	["hair43","hairs52"],
	["hair44","hairs53"],
	["hair45","hairs57"],
	["hair46","hairs58"],
	["hair47","hairs60"],
	["hair48","hairs61"],
	["hair49","hairs62"],
	["hair50","hairs63"],
	["hair51","hairs64"],
	["hair52","hairs65"],
	["hair53","hairs67"],
	["hair54","hairs69"],
	["hair55","hairs70"],
	["hair56","hairs71"]

];
pathPref = "<path>";

var json_cnt = "{\n\t\"refs_ktan\": {";
json_cnt+="\n";

for(var i=0;i < parts.length;i++){
	duppedDocument = cloneDocument();
	app.activeDocument = duppedDocument;
	switchScene(null, null);
	var filename = exportSpriteWithRelOffset(parts[i][0], null, parts[i][1]);
	duppedDocument.close(SaveOptions.DONOTSAVECHANGES);
	json_cnt+="\t\t\""+parts[i][0]+"\": \"" + pathPref + "/"+filename+"\",";
	json_cnt+="\n";
}

json_cnt += "\t\t\"hash\": \"...\"";
json_cnt += "\n\t}\n}";
saveText("ktan_defns.json",json_cnt);

alert("Done!");

