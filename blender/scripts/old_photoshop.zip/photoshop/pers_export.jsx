//@include "libs/comixgen.jsx"
//@include "libs/persutils.jsx"

//var exportTo = "samanta";
//var exportTo = "belpoli";
//var exportTo = "kasatka";
//var exportTo = "may";
//var exportTo = "sasha";
//var exportTo = "leia";
//var exportTo = "marina";
//var exportTo = "anna";
//var exportTo = "vera";
var exportTo = "janna";

//var exportTo = "gena";
//var exportTo = "artem";
//var exportTo = "anton";
//var exportTo = "ura";

//var exportTo = "katya";
//var exportTo = "prof";
//var exportTo = "tamojk";
//var exportTo = "prodalx";
//var exportTo = "prodevg";


var globals = {};
var datever = date2str(new Date());
var exportToD = exportTo+datever;
initComix("d:/Downloads/"+exportToD, globals);

//======================================================
var duppedDocument = null;
var json_cnt = "";
switchScene(null, null);
var scaleFactor = 0.58; //0.71145833333 - 2048 problem;// 1920->1366
var refs_path = "/vn_storyline/art/pers2/";

if(exportTo == "prodevg"){

	var bodies = [
		["prodevg_p1_dress1","posa1","body+dress1"],
		["prodevg_p2_dress1","posa2","body+dress1+dress1_part1"],

		["prodevg_p1_dress2","posa1","body+dress2"],
		["prodevg_p2_dress2","posa2","body+dress2+dress1_part1"],
	];

	// Emotions
	var emots = [
		["prodevg_p1_nrm","posa1","nrm"],
		["prodevg_p1_smi","posa1","smi"],
		["prodevg_p1_lau","posa1","lau"],
		["prodevg_p1_sur","posa1","sur"],
		["prodevg_p1_hm","posa1","hm"],

		["prodevg_p2_nrm","posa2","nrm"],
		["prodevg_p2_smi","posa2","smi"],
		["prodevg_p2_lau","posa2","lau"],
		["prodevg_p2_sur","posa2","sur"],
		["prodevg_p2_hm","posa2","hm"]
	];

	// Avatar
	var avats = [
		["_prodevg_nrm","posa1","body+nrm"],
		["_prodevg_smi","posa1","body+smi"],
		["_prodevg_lau","posa1","body+lau"],
		["_prodevg_sur","posa1","body+sur"],
		["_prodevg_hm","posa1","body+hm"]
	];

	exportCharacter(bodies,emots,avats,exportTo,scaleFactor,refs_path,exportToD);
}

if(exportTo == "prodalx"){

	var bodies = [
		["prodalx_p1_dress1","posa1","body+dress1"],
		["prodalx_p1_dress2","posa1","body+dress2"],
	];

	// Emotions prodalx
	var emots = [
		["prodalx_p1_nrm","posa1","nrm"],
		["prodalx_p1_smi","posa1","smi"],
		["prodalx_p1_lau","posa1","lau"],
		["prodalx_p1_sur","posa1","sur"],
		["prodalx_p1_hm","posa1","hm"],
	];

	// Avatar prodalx
	var avats = [
		["_prodalx_nrm","posa1","body+nrm"],
		["_prodalx_smi","posa1","body+smi"],
		["_prodalx_lau","posa1","body+lau"],
		["_prodalx_sur","posa1","body+sur"],
		["_prodalx_hm","posa1","body+hm"]
	];

	exportCharacter(bodies,emots,avats,exportTo,scaleFactor,refs_path,exportToD);
}

if(exportTo == "tamojk"){

	var bodies = [
		["tamojk_p1_dress1","posa1","body+dress"],
		["tamojk_p2_dress1","posa2","body+dress"],
	];

	// Emotions tamojk
	var emots = [
		["tamojk_p1_nrm","posa1","nrm"],
		["tamojk_p1_smi","posa1","smi"],
		["tamojk_p1_lau","posa1","lau"],
		["tamojk_p1_sur","posa1","sur"],
		["tamojk_p1_hm","posa1","hm"],

		["tamojk_p2_nrm","posa2","nrm"],
		["tamojk_p2_smi","posa2","smi"],
		["tamojk_p2_lau","posa2","lau"],
		["tamojk_p2_sur","posa2","sur"],
		["tamojk_p2_hm","posa2","hm"]
	];

	// Avatar tamojk
	var avats = [
		["_tamojk_nrm","posa1","body+nrm"],
		["_tamojk_smi","posa1","body+smi"],
		["_tamojk_lau","posa1","body+lau"],
		["_tamojk_sur","posa1","body+sur"],
		["_tamojk_hm","posa1","body+hm"]
	];

	exportCharacter(bodies,emots,avats,exportTo,scaleFactor,refs_path,exportToD);
}

if(exportTo == "prof"){

	var bodies = [
		["prof_p1_dress1","posa1","body+dress1+hairs"],
		["prof_p1_dress2","posa1","body+dress2+hairs"],
	];

	// Emotions prof
	var emots = [
		["prof_p1_nrm","posa1","nrm+hairs"],
		["prof_p1_hm","posa1","hm+hairs"],
		["prof_p1_smi","posa1","smi+hairs"],
		["prof_p1_lau","posa1","lau+hairs"],
		["prof_p1_sur","posa1","sur+hairs"]
	];

	// Avatar prof
	var avats = [
		["_prof_nrm","posa1","body+nrm+hairs"],
		["_prof_hm","posa1","body+hm+hairs"],
		["_prof_smi","posa1","body+smi+hairs"],
		["_prof_lau","posa1","body+lau+hairs"],
		["_prof_sur","posa1","body+sur+hairs"]
	];

	exportCharacter(bodies,emots,avats,exportTo,scaleFactor,refs_path,exportToD);
}

if(exportTo == "sasha"){

	var bodies = [
		["sasha_p1_dress1","posa1","body+body_part3+dress1+hairs1+hairs2+hairs2_shadow"],
		["sasha_p1_dress2","posa1","body+body_part3+dress2+hairs1+hairs2+hairs2_shadow"],
		["sasha_p2_dress1","posa2","body+body_part3+dress1+hairs1+hairs2+hairs2_shadow"],
		["sasha_p2_dress2","posa2","body+body_part3+dress2+hairs1+hairs2+hairs2_shadow"],
		["sasha_p3_dress1","posa3","body+body_part3+dress1+hairs1+hairs2+hairs2_shadow"],
		["sasha_p3_dress2","posa3","body+body_part3+dress2+hairs1+hairs2+hairs2_shadow"],
	];

	// Emotions sasha
	var emots = [
		["sasha_p1_nrm","posa1","nrm+nose"],
		["sasha_p1_smi","posa1","smi+nose"],
		["sasha_p1_lau","posa1","lau+nose"],
		["sasha_p1_hm","posa1","hm+nose"],
		["sasha_p1_hm_cle","posa1","hm_cle+nose"],
		["sasha_p1_sur","posa1","sur+nose"],
		["sasha_p1_what","posa1","what+nose"],
		["sasha_p1_scared","posa1","scared+nose"],

		["sasha_p2_nrm","posa2","nrm+nose"],
		["sasha_p2_smi","posa2","smi+nose"],
		["sasha_p2_lau","posa2","lau+nose"],
		["sasha_p2_hm","posa2","hm+nose"],
		["sasha_p2_hm_cle","posa2","hm_cle+nose"],
		["sasha_p2_sur","posa2","sur+nose"],
		["sasha_p2_what","posa2","what+nose"],
		["sasha_p2_scared","posa2","scared+nose"],

		["sasha_p3_nrm","posa3","nrm+nose"],
		["sasha_p3_smi","posa3","smi+nose"],
		["sasha_p3_lau","posa3","lau+nose"],
		["sasha_p3_hm","posa3","hm+nose"],
		["sasha_p3_hm_cle","posa3","hm_cle+nose"],
		["sasha_p3_sur","posa3","sur+nose"],
		["sasha_p3_what","posa3","what+nose"],
		["sasha_p3_scared","posa3","scared+nose"],
	];

	// Avatar sasha
	var avats = [
		["_sasha_nrm","posa1","hairs1+body+body_part3+nrm+nose+hairs2"],
		["_sasha_hm","posa1","hairs1+body+body_part3+hm+nose+hairs2"],
		["_sasha_hm_cle","posa1","hairs1+body+body_part3+hm_cle+nose+hairs2"],
		["_sasha_smi","posa1","hairs1+body+body_part3+smi+nose+hairs2"],
		["_sasha_lau","posa1","hairs1+body+body_part3+lau+nose+hairs2"],
		["_sasha_sur","posa1","hairs1+body+body_part3+sur+nose+hairs2"],
		["_sasha_what","posa1","hairs1+body+body_part3+what+nose+hairs2"],
		["_sasha_scared","posa1","hairs1+body+body_part3+scared+nose+hairs2"],
	];

	exportCharacter(bodies,emots,avats,exportTo,scaleFactor,refs_path,exportToD);
}


if(exportTo == "samanta"){

	var bodies = [
		["samanta_p1_dress1","posa1","hairs1+body+dress1+hairs2+hairs2_shadow"],
		["samanta_p1_dress2","posa1","hairs1+body+dress2+hairs2+hairs2_shadow"],
		["samanta_p2_dress1","posa2","hairs1+body+dress1+hairs2+hairs2_shadow"],
		["samanta_p2_dress2","posa2","hairs1+body+dress2+hairs2+hairs2_shadow"],
		["samanta_p3_dress1","posa3","hairs1+body+dress1+hairs2+hairs2_shadow"],
		["samanta_p3_dress2","posa3","hairs1+body+dress2+hairs2+hairs2_shadow"],
	];

	var emots = [
		["samanta_p1_nrm","posa1","nrm+nose"],
		["samanta_p1_smi","posa1","smi+nose"],
		["samanta_p1_lau","posa1","lau+nose"],
		["samanta_p1_sur","posa1","sur+nose"],
		["samanta_p1_hm","posa1","hm+nose"],
		["samanta_p1_shy","posa1","shy+nose"],

		["samanta_p2_nrm","posa2","nrm+nose"],
		["samanta_p2_smi","posa2","smi+nose"],
		["samanta_p2_lau","posa2","lau+nose"],
		["samanta_p2_sur","posa2","sur+nose"],
		["samanta_p2_hm","posa2","hm+nose"],
		["samanta_p2_shy","posa2","shy+nose"],

		["samanta_p3_nrm","posa3","nrm+nose"],
		["samanta_p3_smi","posa3","smi+nose"],
		["samanta_p3_lau","posa3","lau+nose"],
		["samanta_p3_sur","posa3","sur+nose"],
		["samanta_p3_hm","posa3","hm+nose"],
		["samanta_p3_shy","posa3","shy+nose"],
	];

	var avats = [
		["_samanta_nrm","posa1","hairs1+body+hairs2+nrm+nose"],
		["_samanta_hm","posa1","hairs1+body+hairs2+hm+nose"],
		["_samanta_smi","posa1","hairs1+body+hairs2+smi+nose"],
		["_samanta_lau","posa1","hairs1+body+hairs2+lau+nose"],
		["_samanta_sur","posa1","hairs1+body+hairs2+sur+nose"],
		["_samanta_shy","posa1","hairs1+body+hairs2+shy+nose"],
	];

	exportCharacter(bodies,emots,avats,exportTo,scaleFactor,refs_path,exportToD);
}

if(exportTo == "belpoli"){

	var bodies = [
		["bpl_p1_dress1","posa1","body+dress1+body_rpart+hairs2+hairs2_shadow"],
		["bpl_p1_dress2","posa1","body+dress2+body_rpart+hairs2+hairs2_shadow"],
		["bpl_p2_dress1","posa2","body+dress1+hairs2+hairs2_shadow"],
		["bpl_p2_dress2","posa2","body+dress2+hairs2+hairs2_shadow"],
		["bpl_p3a_dress1","posa3","body+body_part2_1+dress1+body_rpart+hairs2+hairs2_shadow+dress1_part2"],
		["bpl_p3a_dress2","posa3","body+body_part2_1+dress2+body_rpart+hairs2+hairs2_shadow"],
		["bpl_p3b_dress1","posa3","body+body_part2_2+dress1+body_rpart+hairs2+hairs2_shadow+dress1_part2"],
		["bpl_p3b_dress2","posa3","body+body_part2_2+dress2+body_rpart+hairs2+hairs2_shadow"],
		["bpl_p3c_dress1","posa3","body+body_part2_3+dress1+body_rpart+hairs2+hairs2_shadow+dress1_part2"],
		["bpl_p3c_dress2","posa3","body+body_part2_3+dress2+body_rpart+hairs2+hairs2_shadow"],
	];

	var emots = [
		["bpl_p1_nrm","posa1","nrm+nose"],
		["bpl_p1_smi","posa1","smi+nose"],
		["bpl_p1_smi_z","posa1","smi_z+nose"],
		["bpl_p1_lau","posa1","lau+nose"],
		["bpl_p1_sur","posa1","sur+nose"],
		["bpl_p1_hm","posa1","hm+nose"],
		["bpl_p1_drim","posa1","drim+nose"],

		["bpl_p2_nrm","posa2","nrm+nose"],
		["bpl_p2_smi","posa2","smi+nose"],
		["bpl_p2_smi_z","posa2","smi_z+nose"],
		["bpl_p2_lau","posa2","lau+nose"],
		["bpl_p2_sur","posa2","sur+nose"],
		["bpl_p2_hm","posa2","hm+nose"],
		["bpl_p2_drim","posa2","drim+nose"],

		["bpl_p3a_nrm","posa3","nrm+nose"],
		["bpl_p3a_smi","posa3","smi+nose"],
		["bpl_p3a_smi_z","posa3","smi_z+nose"],
		["bpl_p3a_lau","posa3","lau+nose"],
		["bpl_p3a_sur","posa3","sur+nose"],
		["bpl_p3a_hm","posa3","hm+nose"],
		["bpl_p3a_drim","posa3","drim+nose"],

		["bpl_p3b_nrm","posa3","nrm+nose"],
		["bpl_p3b_smi","posa3","smi+nose"],
		["bpl_p3b_smi_z","posa3","smi_z+nose"],
		["bpl_p3b_lau","posa3","lau+nose"],
		["bpl_p3b_sur","posa3","sur+nose"],
		["bpl_p3b_hm","posa3","hm+nose"],
		["bpl_p3b_drim","posa3","drim+nose"],

		["bpl_p3c_nrm","posa3","nrm+nose"],
		["bpl_p3c_smi","posa3","smi+nose"],
		["bpl_p3c_smi_z","posa3","smi_z+nose"],
		["bpl_p3c_lau","posa3","lau+nose"],
		["bpl_p3c_sur","posa3","sur+nose"],
		["bpl_p3c_hm","posa3","hm+nose"],
		["bpl_p3c_drim","posa3","drim+nose"],
	];

	var avats = [
		["_bpl_nrm","posa1","body+body_rpart+hairs2+nrm+nose"],
		["_bpl_hm","posa1","body+body_rpart+hairs2+hm+nose"],
		["_bpl_smi","posa1","body+body_rpart+hairs2+smi+nose"],
		["_bpl_smi_z","posa1","body+body_rpart+hairs2+smi_z+nose"],
		["_bpl_lau","posa1","body+body_rpart+hairs2+lau+nose"],
		["_bpl_sur","posa1","body+body_rpart+hairs2+sur+nose"],
		["_bpl_drim","posa1","body+body_rpart+hairs2+drim+nose"],
	];

	exportCharacter(bodies,emots,avats,exportTo,scaleFactor,refs_path,exportToD);
}

if(exportTo == "anna"){

	var bodies = [
		["anna_p1_dress1","posa1","hairs1+body+dress1+hairs2+hairs2_shadow"],
		["anna_p1_dress2","posa1","hairs1+body+dress2+hairs2+hairs2_shadow"],
		["anna_p2_dress1","posa2","hairs1+body+dress1+hairs2+hairs2_shadow"],//+body_part2
		["anna_p2_dress2","posa2","hairs1+body+dress2+hairs2+hairs2_shadow"],//+body_part2
		["anna_p3_dress1","posa3","hairs1+body+dress1+hairs2+hairs2_shadow"],//+body_part2
		["anna_p3_dress2","posa3","hairs1+body+dress2+hairs2+hairs2_shadow"],//+body_part2
		["anna_p4_dress1","posa4","hairs1+body+dress1+hairs2+hairs2_shadow"],
		["anna_p4_dress2","posa4","hairs1+body+dress2+hairs2+hairs2_shadow"],
		["anna_p5_dress1","posa5","hairs1+body+dress1+hairs2+hairs2_shadow"],
		["anna_p5_dress2","posa5","hairs1+body+dress2+hairs2+hairs2_shadow"],
		["anna_p6_dress1","posa6","hairs1+body+dress1+hairs2+hairs2_shadow"],
		["anna_p6_dress2","posa6","hairs1+body+dress2+hairs2+hairs2_shadow"],
	];

	var emots = [
		["anna_p1_nrm","posa1","nrm+nose"],
		["anna_p1_smi","posa1","smi+nose"],
		["anna_p1_smi_cle","posa1","smi_cle+nose"],
		["anna_p1_lau","posa1","lau+nose"],
		["anna_p1_sur","posa1","sur+nose"],
		["anna_p1_fear","posa1","fear+nose"],
		["anna_p1_hm","posa1","hm+nose"],
		["anna_p1_hm_cle","posa1","hm_cle+nose"],
		["anna_p1_hate","posa1","hate+nose"],
		["anna_p1_drim","posa1","drim+nose"],
		["anna_p1_wtf","posa1","wtf+nose"],

		["anna_p2_nrm","posa2","nrm+nose"],
		["anna_p2_smi","posa2","smi+nose"],
		["anna_p2_smi_cle","posa2","smi_cle+nose"],
		["anna_p2_lau","posa2","lau+nose"],
		["anna_p2_sur","posa2","sur+nose"],
		["anna_p2_fear","posa2","fear+nose"],
		["anna_p2_hm_cle","posa2","hm_cle+nose"],
		["anna_p2_hm","posa2","hm+nose"],
		["anna_p2_hate","posa2","hate+nose"],
		["anna_p2_drim","posa2","drim+nose"],
		["anna_p2_wtf","posa2","wtf+nose"],

		["anna_p3_nrm","posa3","nrm+nose"],
		["anna_p3_smi","posa3","smi+nose"],
		["anna_p3_smi_cle","posa3","smi_cle+nose"],
		["anna_p3_lau","posa3","lau+nose"],
		["anna_p3_sur","posa3","sur+nose"],
		["anna_p3_fear","posa3","fear+nose"],
		["anna_p3_hm_cle","posa3","hm_cle+nose"],
		["anna_p3_hm","posa3","hm+nose"],
		["anna_p3_hate","posa3","hate+nose"],
		["anna_p3_drim","posa3","drim+nose"],
		["anna_p3_wtf","posa3","wtf+nose"],

		["anna_p4_nrm","posa4","nrm+nose"],
		["anna_p4_smi","posa4","smi+nose"],
		["anna_p4_smi_cle","posa4","smi_cle+nose"],
		["anna_p4_lau","posa4","lau+nose"],
		["anna_p4_sur","posa4","sur+nose"],
		["anna_p4_fear","posa4","fear+nose"],
		["anna_p4_hm_cle","posa4","hm_cle+nose"],
		["anna_p4_hm","posa4","hm+nose"],
		["anna_p4_hate","posa4","hate+nose"],
		["anna_p4_drim","posa4","drim+nose"],
		["anna_p4_wtf","posa4","wtf+nose"],

		["anna_p5_nrm","posa5","nrm+nose"],
		["anna_p5_smi","posa5","smi+nose"],
		["anna_p5_smi_cle","posa5","smi_cle+nose"],
		["anna_p5_lau","posa5","lau+nose"],
		["anna_p5_sur","posa5","sur+nose"],
		["anna_p5_fear","posa5","fear+nose"],
		["anna_p5_hm_cle","posa5","hm_cle+nose"],
		["anna_p5_hm","posa5","hm+nose"],
		["anna_p5_hate","posa5","hate+nose"],
		["anna_p5_drim","posa5","drim+nose"],
		["anna_p5_wtf","posa5","wtf+nose"],

		["anna_p6_nrm","posa6","nrm+nose"],
		["anna_p6_smi","posa6","smi+nose"],
		["anna_p6_smi_cle","posa6","smi_cle+nose"],
		["anna_p6_lau","posa6","lau+nose"],
		["anna_p6_sur","posa6","sur+nose"],
		["anna_p6_fear","posa6","fear+nose"],
		["anna_p6_hm_cle","posa6","hm_cle+nose"],
		["anna_p6_hm","posa6","hm+nose"],
		["anna_p6_hate","posa6","hate+nose"],
		["anna_p6_drim","posa6","drim+nose"],
		["anna_p6_wtf","posa6","wtf+nose"],
	];

	var avats = [
		["_anna_nrm","posa1","hairs1+body+hairs2+nrm+nose"],
		["_anna_hm","posa1","hairs1+body+hairs2+hm+nose"],
		["_anna_hm_cle","posa1","hairs1+body+hairs2+hm_cle+nose"],
		["_anna_smi","posa1","hairs1+body+hairs2+smi+nose"],
		["_anna_smi_cle","posa1","hairs1+body+hairs2+smi_cle+nose"],
		["_anna_lau","posa1","hairs1+body+hairs2+lau+nose"],
		["_anna_sur","posa1","hairs1+body+hairs2+sur+nose"],
		["_anna_fear","posa1","hairs1+body+hairs2+fear+nose"],
		["_anna_hate","posa1","hairs1+body+hairs2+hate+nose"],
		["_anna_drim","posa1","hairs1+body+hairs2+drim+nose"],
		["_anna_wtf","posa1","hairs1+body+hairs2+wtf+nose"]
	];

	exportCharacter(bodies,emots,avats,exportTo,scaleFactor,refs_path,exportToD);
}

if(exportTo == "katya"){

	var bodies = [
		["katya_p1_dress1","posa1","hairs1+body+dress1+hairs2+hairs3"],
		["katya_p2_dress1","posa2","hairs1+body+dress1+hairs2+hairs3"]
	];

	var emots = [
		["katya_p1_nrm","posa1","nrm"],
		["katya_p1_smi","posa1","smi"],
		["katya_p1_lau","posa1","lau"],
		["katya_p1_sur","posa1","sur"],
		["katya_p1_hm","posa1","hm"],

		["katya_p2_nrm","posa2","nrm"],
		["katya_p2_smi","posa2","smi"],
		["katya_p2_lau","posa2","lau"],
		["katya_p2_sur","posa2","sur"],
		["katya_p2_hm","posa2","hm"]
	];

	var avats = [
		["_katya_nrm","posa1","hairs1+body+hairs2+hairs3+nrm"],
		["_katya_hm","posa1","hairs1+body+hairs2+hairs3+hm"],
		["_katya_smi","posa1","hairs1+body+hairs2+hairs3+smi"],
		["_katya_lau","posa1","hairs1+body+hairs2+hairs3+lau"],
		["_katya_sur","posa1","hairs1+body+hairs2+hairs3+sur"]
	];

	exportCharacter(bodies,emots,avats,exportTo,scaleFactor,refs_path,exportToD);
}

if(exportTo == "vera"){

	var bodies = [
		["vera_p1_dress1","posa1","body+dress1+hairs2+hairs2_shadow+hairs3_dress1"],
		["vera_p1_dress2","posa1","body+dress2+hairs2+hairs2_shadow+hairs3_dress2"],
		["vera_p2_dress1","posa2","body+dress1+hairs2+hairs2_shadow+hairs3_dress1+body_part2"],
		["vera_p2_dress2","posa2","body+dress2+hairs2+hairs2_shadow+hairs3_dress2+body_part2"],
		["vera_p3_dress1","posa3","body+dress1+hairs2+hairs2_shadow+hairs3_dress1"],
		["vera_p3_dress2","posa3","body+dress2+hairs2+hairs2_shadow+hairs3_dress2"],
		["vera_p4_dress1","posa4","body+dress1+hairs2+hairs2_shadow+hairs3_dress1"],
		["vera_p4_dress2","posa4","body+dress2+hairs2+hairs2_shadow+hairs3_dress2"],
	];

	var emots = [
		["vera_p1_nrm","posa1","nrm+nose"],
		["vera_p1_smi","posa1","smi+nose"],
		["vera_p1_lau","posa1","lau+nose"],
		["vera_p1_sur","posa1","sur+nose"],
		["vera_p1_hm","posa1","hm+nose"],
		["vera_p1_rage","posa1","rage+nose"],
		["vera_p1_rage_z","posa1","rage_z+nose"],

		["vera_p2_nrm","posa2","nrm+nose"],
		["vera_p2_smi","posa2","smi+nose"],
		["vera_p2_lau","posa2","lau+nose"],
		["vera_p2_sur","posa2","sur+nose"],
		["vera_p2_hm","posa2","hm+nose"],
		["vera_p2_rage","posa2","rage+nose"],
		["vera_p2_rage_z","posa2","rage_z+nose"],

		["vera_p3_nrm","posa3","nrm+nose"],
		["vera_p3_smi","posa3","smi+nose"],
		["vera_p3_lau","posa3","lau+nose"],
		["vera_p3_sur","posa3","sur+nose"],
		["vera_p3_hm","posa3","hm+nose"],
		["vera_p3_rage","posa3","rage+nose"],
		["vera_p3_rage_z","posa3","rage_z+nose"],

		["vera_p4_nrm","posa4","nrm+nose"],
		["vera_p4_smi","posa4","smi+nose"],
		["vera_p4_lau","posa4","lau+nose"],
		["vera_p4_sur","posa4","sur+nose"],
		["vera_p4_hm","posa4","hm+nose"],
		["vera_p4_rage","posa4","rage+nose"],
		["vera_p4_rage_z","posa4","rage_z+nose"],
	];

	var avats = [
		["_vera_nrm","posa1","body+hairs2+nrm+nose"],
		["_vera_smi","posa1","body+hairs2+smi+nose"],
		["_vera_lau","posa1","body+hairs2+lau+nose"],
		["_vera_sur","posa1","body+hairs2+sur+nose"],
		["_vera_hm","posa1","body+hairs2+hm+nose"],
		["_vera_rage","posa1","body+hairs2+rage+nose"],
		["_vera_rage_z","posa1","body+hairs2+rage_z+nose"],
	];

	exportCharacter(bodies,emots,avats,exportTo,scaleFactor,refs_path,exportToD);
}

if(exportTo == "kasatka"){

	var bodies = [
		["kasatka_p1_dress1","posa1","hairs1+body+dress1+hairs2+hairs2_shadow"],
		["kasatka_p1_dress2","posa1","hairs1+body+dress2+hairs2+hairs2_shadow"],
		["kasatka_p2_dress1","posa2","hairs1+body+dress1+hairs2+hairs2_shadow"],
		["kasatka_p2_dress2","posa2","hairs1+body+dress2+hairs2+hairs2_shadow"],
		["kasatka_p3_dress1","posa3","hairs1+body+dress1+hairs2+hairs2_shadow"],
		["kasatka_p3_dress2","posa3","hairs1+body+dress2+hairs2+hairs2_shadow"],
	];

	var emots = [
		["kasatka_p1_nrm","posa1","nrm+nose"],
		["kasatka_p1_smi","posa1","smi+nose"],
		["kasatka_p1_lau","posa1","lau+nose"],
		["kasatka_p1_sur","posa1","sur+nose"],
		["kasatka_p1_hm","posa1","hm+nose"],

		["kasatka_p2_nrm","posa2","nrm+nose"],
		["kasatka_p2_smi","posa2","smi+nose"],
		["kasatka_p2_lau","posa2","lau+nose"],
		["kasatka_p2_sur","posa2","sur+nose"],
		["kasatka_p2_hm","posa2","hm+nose"],

		["kasatka_p3_nrm","posa3","nrm+nose"],
		["kasatka_p3_smi","posa3","smi+nose"],
		["kasatka_p3_lau","posa3","lau+nose"],
		["kasatka_p3_sur","posa3","sur+nose"],
		["kasatka_p3_hm","posa3","hm+nose"],
	];

	var avats = [
		["_kasatka_nrm","posa1","hairs1+body+hairs2+nrm+nose"],
		["_kasatka_hm","posa1","hairs1+body+hairs2+hm+nose"],
		["_kasatka_smi","posa1","hairs1+body+hairs2+smi+nose"],
		["_kasatka_lau","posa1","hairs1+body+hairs2+lau+nose"],
		["_kasatka_sur","posa1","hairs1+body+hairs2+sur+nose"],
	];

	exportCharacter(bodies,emots,avats,exportTo,scaleFactor,refs_path,exportToD);
}

if(exportTo == "marina"){

	var bodies = [
		["marina_p1_dress1","posa1","hairs3b+hairs3a+body+dress1+hairs2a+hairs2_shadow"],
		["marina_p1_dress1a","posa1","hairs3b+hairs6c+body+dress1+hairs2a+hairs2_shadow"],
		["marina_p1_dress2","posa1","hairs4b+body+dress2+hairs2a+hairs2_shadow"],
		["marina_p1_dress3","posa1","hairs3b+hairs3a+body+dress3+hairs2a+hairs2_shadow"],
		["marina_p1_dress3a","posa1","hairs3b+hairs3a+body+dress3a+hairs2a+hairs2_shadow"],
		["marina_p1_dress4","posa1","hairs5b+body+dress4+hairs2a+hairs2_shadow"],
		["marina_p1_dress5","posa1","hairs4b+body+dress5+hairs2a+hairs2_shadow"],

		["marina_p2_dress1","posa2","hairs3b+hairs3a+body+dress1+hairs2a+hairs2_shadow"],
		["marina_p2_dress1a","posa2","hairs3b+hairs6c+body+dress1+hairs2a+hairs2_shadow"],
		["marina_p2_dress2","posa2","hairs4b+body+dress2+hairs2a+hairs2_shadow"],
		["marina_p2_dress3","posa2","hairs3b+hairs3a+body+dress3+hairs2a+hairs2_shadow"],
		["marina_p2_dress3a","posa2","hairs3b+hairs3a+body+dress3a+hairs2a+hairs2_shadow"],
		["marina_p2_dress4","posa2","hairs5b+body+dress4+hairs2a+hairs2_shadow"],
		["marina_p2_dress5","posa2","hairs4b+body+dress5+hairs2a+hairs2_shadow"],

		["marina_p3_dress1","posa3","hairs3b+hairs3a+body+dress1+hairs2a+hairs2_shadow"],
		["marina_p3_dress1a","posa3","hairs3b+hairs6c+body+dress1+hairs2a+hairs2_shadow"],
		["marina_p3_dress2","posa3","hairs4b+body+dress2+hairs2a+hairs2_shadow"],
		["marina_p3_dress3","posa3","hairs3b+hairs3a+body+dress3+hairs2a+hairs2_shadow"],
		["marina_p3_dress3a","posa3","hairs3b+hairs3a+body+dress3a+hairs2a+hairs2_shadow"],
		["marina_p3_dress4","posa3","hairs5b+body+dress4+hairs2a+hairs2_shadow"],
		["marina_p3_dress5","posa3","hairs4b+body+dress5+hairs2a+hairs2_shadow"],

		["marina_p4_dress1","posa4","hairs3b+hairs3a+body+dress1+hairs2a+hairs2_shadow"],
		["marina_p4_dress1a","posa4","hairs3b+hairs6c+body+dress1+hairs2a+hairs2_shadow"],
		["marina_p4_dress2","posa4","hairs4b+body+dress2+hairs2a+hairs2_shadow"],
		["marina_p4_dress3","posa4","hairs3b+hairs3a+body+dress3+hairs2a+hairs2_shadow"],
		["marina_p4_dress3a","posa4","hairs3b+hairs3a+body+dress3a+hairs2a+hairs2_shadow"],
		["marina_p4_dress4","posa4","hairs5b+body+dress4+hairs2a+hairs2_shadow"],
		["marina_p4_dress5","posa4","hairs4b+body+dress5+hairs2a+hairs2_shadow"],

		["marina_p5_dress1","posa5","hairs3b+hairs3a+body+body_part2+dress1+hairs2a+hairs2_shadow"],
		["marina_p5_dress1a","posa5","hairs3b+hairs6c+body+body_part2+dress1+hairs2a+hairs2_shadow"],
		["marina_p5_dress2","posa5","hairs4b+body+body_part2+dress2+dress2_part2+hairs2a+hairs2_shadow"],
		["marina_p5_dress3","posa5","hairs3b+hairs3a+body+body_part2+dress3+hairs2a+hairs2_shadow"],
		["marina_p5_dress3a","posa5","hairs3b+hairs3a+body+body_part2+dress3a+hairs2a+hairs2_shadow"],
		["marina_p5_dress4","posa5","hairs5b+body+body_part2+dress4+hairs2a+hairs2_shadow"],
		["marina_p5_dress5","posa5","hairs4b+body+body_part2+dress5+hairs2a+hairs2_shadow"],

		["marina_p6_dress1","posa6", "hairs3b+hairs3a+body+body_part2+dress1+hairs2a+hairs2_shadow"],
		["marina_p6_dress1a","posa6","hairs3b+hairs6c+body+body_part2+dress1+hairs2a+hairs2_shadow"],
		["marina_p6_dress2","posa6", "hairs4b+body+body_part2+dress2+hairs2a+hairs2_shadow"],
		["marina_p6_dress3","posa6", "hairs3b+hairs3a+body+body_part2+dress3+hairs2a+hairs2_shadow"],
		["marina_p6_dress3a","posa6", "hairs3b+hairs3a+body+body_part2+dress3a+hairs2a+hairs2_shadow"],
		["marina_p6_dress4","posa6", "hairs5b+body+body_part2+dress4+hairs2a+hairs2_shadow"],
		["marina_p6_dress5","posa6", "hairs4b+body+body_part2+dress5+hairs2a+hairs2_shadow"],
	];

	var emots = [
		["marina_p1_nrm_x","posa1","nrm+hairs6b+nose"],
		["marina_p1_smi_x","posa1","smi+hairs6b+nose"],
		["marina_p1_smi_wide_x","posa1","smi_wide+hairs6b+nose"],
		["marina_p1_lau_x","posa1","lau+hairs6b+nose"],
		["marina_p1_sur_x","posa1","sur+hairs6b+nose"],
		["marina_p1_hm_x","posa1","hm+hairs6b+nose"],
		["marina_p1_hm_cle_x","posa1","hm_cle+hairs6b+nose"],
		["marina_p1_nrm_y","posa1","nrm+hairs6a+nose"],
		["marina_p1_smi_y","posa1","smi+hairs6a+nose"],
		["marina_p1_smi_wide_y","posa1","smi_wide+hairs6a+nose"],
		["marina_p1_lau_y","posa1","lau+hairs6a+nose"],
		["marina_p1_sur_y","posa1","sur+hairs6a+nose"],
		["marina_p1_hm_y","posa1","hm+hairs6a+nose"],
		["marina_p1_hm_cle_y","posa1","hm_cle+hairs6a+nose"],
		["marina_p1_nrm_a","posa1","nrm+nose"],
		["marina_p1_smi_a","posa1","smi+nose"],
		["marina_p1_smi_wide_a","posa1","smi_wide+nose"],
		["marina_p1_lau_a","posa1","lau+nose"],
		["marina_p1_sur_a","posa1","sur+nose"],
		["marina_p1_hm_a","posa1","hm+nose"],
		["marina_p1_hm_cle_a","posa1","hm_cle+nose"],

		["marina_p2_nrm_x","posa2","nrm+hairs6b+nose"],
		["marina_p2_smi_x","posa2","smi+hairs6b+nose"],
		["marina_p2_smi_wide_x","posa2","smi_wide+hairs6b+nose"],
		["marina_p2_lau_x","posa2","lau+hairs6b+nose"],
		["marina_p2_sur_x","posa2","sur+hairs6b+nose"],
		["marina_p2_hm_x","posa2","hm+hairs6b+nose"],
		["marina_p2_hm_cle_x","posa2","hm_cle+hairs6b+nose"],
		["marina_p2_nrm_y","posa2","nrm+hairs6a+nose"],
		["marina_p2_smi_y","posa2","smi+hairs6a+nose"],
		["marina_p2_smi_wide_y","posa2","smi_wide+hairs6a+nose"],
		["marina_p2_lau_y","posa2","lau+hairs6a+nose"],
		["marina_p2_sur_y","posa2","sur+hairs6a+nose"],
		["marina_p2_hm_y","posa2","hm+hairs6a+nose"],
		["marina_p2_hm_cle_y","posa2","hm_cle+hairs6a+nose"],
		["marina_p2_nrm_a","posa2","nrm+nose"],
		["marina_p2_smi_a","posa2","smi+nose"],
		["marina_p2_smi_wide_a","posa2","smi_wide+nose"],
		["marina_p2_lau_a","posa2","lau+nose"],
		["marina_p2_sur_a","posa2","sur+nose"],
		["marina_p2_hm_a","posa2","hm+nose"],
		["marina_p2_hm_cle_a","posa2","hm_cle+nose"],

		["marina_p3_nrm_x","posa3","nrm+hairs6b+nose"],
		["marina_p3_smi_x","posa3","smi+hairs6b+nose"],
		["marina_p3_smi_wide_x","posa3","smi_wide+hairs6b+nose"],
		["marina_p3_lau_x","posa3","lau+hairs6b+nose"],
		["marina_p3_sur_x","posa3","sur+hairs6b+nose"],
		["marina_p3_hm_x","posa3","hm+hairs6b+nose"],
		["marina_p3_hm_cle_x","posa3","hm_cle+hairs6b+nose"],
		["marina_p3_nrm_y","posa3","nrm+hairs6a+nose"],
		["marina_p3_smi_y","posa3","smi+hairs6a+nose"],
		["marina_p3_smi_wide_y","posa3","smi_wide+hairs6a+nose"],
		["marina_p3_lau_y","posa3","lau+hairs6a+nose"],
		["marina_p3_sur_y","posa3","sur+hairs6a+nose"],
		["marina_p3_hm_y","posa3","hm+hairs6a+nose"],
		["marina_p3_hm_cle_y","posa3","hm_cle+hairs6a+nose"],
		["marina_p3_nrm_a","posa3","nrm+nose"],
		["marina_p3_smi_a","posa3","smi+nose"],
		["marina_p3_smi_wide_a","posa3","smi_wide+nose"],
		["marina_p3_lau_a","posa3","lau+nose"],
		["marina_p3_sur_a","posa3","sur+nose"],
		["marina_p3_hm_a","posa3","hm+nose"],
		["marina_p3_hm_cle_a","posa3","hm_cle+nose"],

		["marina_p4_nrm_x","posa4","nrm+hairs6b+nose"],
		["marina_p4_smi_x","posa4","smi+hairs6b+nose"],
		["marina_p4_smi_wide_x","posa4","smi_wide+hairs6b+nose"],
		["marina_p4_lau_x","posa4","lau+hairs6b+nose"],
		["marina_p4_sur_x","posa4","sur+hairs6b+nose"],
		["marina_p4_hm_x","posa4","hm+hairs6b+nose"],
		["marina_p4_hm_cle_x","posa4","hm_cle+hairs6b+nose"],
		["marina_p4_nrm_y","posa4","nrm+hairs6a+nose"],
		["marina_p4_smi_y","posa4","smi+hairs6a+nose"],
		["marina_p4_smi_wide_y","posa4","smi_wide+hairs6a+nose"],
		["marina_p4_lau_y","posa4","lau+hairs6a+nose"],
		["marina_p4_sur_y","posa4","sur+hairs6a+nose"],
		["marina_p4_hm_y","posa4","hm+hairs6a+nose"],
		["marina_p4_hm_cle_y","posa4","hm_cle+hairs6a+nose"],
		["marina_p4_nrm_a","posa4","nrm+nose"],
		["marina_p4_smi_a","posa4","smi+nose"],
		["marina_p4_smi_wide_a","posa4","smi_wide+nose"],
		["marina_p4_lau_a","posa4","lau+nose"],
		["marina_p4_sur_a","posa4","sur+nose"],
		["marina_p4_hm_a","posa4","hm+nose"],
		["marina_p4_hm_cle_a","posa4","hm_cle+nose"],

		["marina_p5_nrm_x","posa5","nrm+hairs6b+nose"],
		["marina_p5_smi_x","posa5","smi+hairs6b+nose"],
		["marina_p5_smi_wide_x","posa5","smi_wide+hairs6b+nose"],
		["marina_p5_lau_x","posa5","lau+hairs6b+nose"],
		["marina_p5_sur_x","posa5","sur+hairs6b+nose"],
		["marina_p5_hm_x","posa5","hm+hairs6b+nose"],
		["marina_p5_hm_cle_x","posa5","hm_cle+hairs6b+nose"],
		["marina_p5_nrm_y","posa5","nrm+hairs6a+nose"],
		["marina_p5_smi_y","posa5","smi+hairs6a+nose"],
		["marina_p5_smi_wide_y","posa5","smi_wide+hairs6a+nose"],
		["marina_p5_lau_y","posa5","lau+hairs6a+nose"],
		["marina_p5_sur_y","posa5","sur+hairs6a+nose"],
		["marina_p5_hm_y","posa5","hm+hairs6a+nose"],
		["marina_p5_hm_cle_y","posa5","hm_cle+hairs6a+nose"],
		["marina_p5_nrm_a","posa5","nrm+nose"],
		["marina_p5_smi_a","posa5","smi+nose"],
		["marina_p5_smi_wide_a","posa5","smi_wide+nose"],
		["marina_p5_lau_a","posa5","lau+nose"],
		["marina_p5_sur_a","posa5","sur+nose"],
		["marina_p5_hm_a","posa5","hm+nose"],
		["marina_p5_hm_cle_a","posa5","hm_cle+nose"],

		["marina_p6_nrm_x","posa6","nrm+hairs6b+nose"],
		["marina_p6_smi_x","posa6","smi+hairs6b+nose"],
		["marina_p6_smi_wide_x","posa6","smi_wide+hairs6b+nose"],
		["marina_p6_lau_x","posa6","lau+hairs6b+nose"],
		["marina_p6_sur_x","posa6","sur+hairs6b+nose"],
		["marina_p6_hm_x","posa6","hm+hairs6b+nose"],
		["marina_p6_hm_cle_x","posa6","hm_cle+hairs6b+nose"],
		["marina_p6_nrm_y","posa6","nrm+hairs6a+nose"],
		["marina_p6_smi_y","posa6","smi+hairs6a+nose"],
		["marina_p6_smi_wide_y","posa6","smi_wide+hairs6a+nose"],
		["marina_p6_lau_y","posa6","lau+hairs6a+nose"],
		["marina_p6_sur_y","posa6","sur+hairs6a+nose"],
		["marina_p6_hm_y","posa6","hm+hairs6a+nose"],
		["marina_p6_hm_cle_y","posa6","hm_cle+hairs6a+nose"],
		["marina_p6_nrm_a","posa6","nrm+nose"],
		["marina_p6_smi_a","posa6","smi+nose"],
		["marina_p6_smi_wide_a","posa6","smi_wide+nose"],
		["marina_p6_lau_a","posa6","lau+nose"],
		["marina_p6_sur_a","posa6","sur+nose"],
		["marina_p6_hm_a","posa6","hm+nose"],
		["marina_p6_hm_cle_a","posa6","hm_cle+nose"],
	];

	var avats = [
		["_marina_nrm_x","posa1","hairs3b+body+hairs2a+hairs3a+nrm+hairs6b+nose"],
		["_marina_hm_x","posa1","hairs3b+body+hairs2a+hairs3a+hm+hairs6b+nose"],
		["_marina_hm_cle_x","posa1","hairs3b+body+hairs2a+hairs3a+hm_cle+hairs6b+nose"],
		["_marina_smi_x","posa1","hairs3b+body+hairs2a+hairs3a+smi+hairs6b+nose"],
		["_marina_smi_wide_x","posa1","hairs3b+body+hairs2a+hairs3a+smi_wide+hairs6b+nose"],
		["_marina_lau_x","posa1","hairs3b+body+hairs2a+hairs3a+lau+hairs6b+nose"],
		["_marina_sur_x","posa1","hairs3b+body+hairs2a+hairs3a+sur+hairs6b+nose"],
		["_marina_nrm_y","posa1","hairs3b+body+hairs2a+hairs3a+nrm+hairs6a+nose"],
		["_marina_hm_y","posa1","hairs3b+body+hairs2a+hairs3a+hm+hairs6a+nose"],
		["_marina_hm_cle_y","posa1","hairs3b+body+hairs2a+hairs3a+hm_cle+hairs6a+nose"],
		["_marina_smi_y","posa1","hairs3b+body+hairs2a+hairs3a+smi+hairs6a+nose"],
		["_marina_smi_wide_y","posa1","hairs3b+body+hairs2a+hairs3a+smi_wide+hairs6a+nose"],
		["_marina_lau_y","posa1","hairs3b+body+hairs2a+hairs3a+lau+hairs6a+nose"],
		["_marina_sur_y","posa1","hairs3b+body+hairs2a+hairs3a+sur+hairs6a+nose"],
		["_marina_nrm_a","posa1","hairs3b+body+hairs2a+hairs6c+nrm+nose"],
		["_marina_hm_a","posa1","hairs3b+body+hairs2a+hairs6c+hm+nose"],
		["_marina_hm_cle_a","posa1","hairs3b+body+hairs2a+hairs6c+hm_cle+nose"],
		["_marina_smi_a","posa1","hairs3b+body+hairs2a+hairs6c+smi+nose"],
		["_marina_smi_wide_a","posa1","hairs3b+body+hairs2a+hairs6c+smi_wide+nose"],
		["_marina_lau_a","posa1","hairs3b+body+hairs2a+hairs6c+lau+nose"],
		["_marina_sur_a","posa1","hairs3b+body+hairs2a+hairs6c+sur+nose"],
	];

	exportCharacter(bodies,emots,avats,exportTo,scaleFactor,refs_path,exportToD);
}

if(exportTo == "gena"){

	var bodies = [
		["gena_p1_dress1","posa1","body+dress1+hairs2+hairs2_shadow"],
		["gena_p1_dress2","posa1","body+dress2+hairs2+hairs2_shadow"]
	];

	var emots = [
		["gena_p1_nrm","posa1","nrm"],
		["gena_p1_smi","posa1","smi"],
		["gena_p1_lau","posa1","lau"],
		["gena_p1_sur","posa1","sur"],
		["gena_p1_hm","posa1","hm"]
	];

	var avats = [
		["_gena_nrm","posa1","body+hairs2+nrm"],
		["_gena_hm","posa1","body+hairs2+hm"],
		["_gena_smi","posa1","body+hairs2+smi"],
		["_gena_lau","posa1","body+hairs2+lau"],
		["_gena_sur","posa1","body+hairs2+sur"]
	];

	exportCharacter(bodies,emots,avats,exportTo,scaleFactor,refs_path,exportToD);
}

if(exportTo == "artem"){

	var bodies = [
		["artem_p1_dress1","posa1","body+dress1"],
		["artem_p1_dress2","posa1","body+dress2"],
		["artem_p1_dress3","posa1","body+dress3+glasses"],
		["artem_p2_dress1","posa2","body+dress1"],
		["artem_p2_dress2","posa2","body+dress2"],
		["artem_p2_dress3","posa2","body+dress3+glasses"],
		["artem_p3_dress1","posa3","body+dress1"],
		["artem_p3_dress2","posa3","body+dress2"],
		["artem_p3_dress3","posa3","body+dress3+glasses"]
	];

	var emots = [
		["artem_p1_nrm","posa1","nrm"],
		["artem_p1_smi","posa1","smi"],
		["artem_p1_lau","posa1","lau"],
		["artem_p1_sur","posa1","sur"],
		["artem_p1_hm","posa1","hm"],
		["artem_p1_cry","posa1","cry"],

		["artem_p2_nrm","posa2","nrm"],
		["artem_p2_smi","posa2","smi"],
		["artem_p2_lau","posa2","lau"],
		["artem_p2_sur","posa2","sur"],
		["artem_p2_hm","posa2","hm"],
		["artem_p2_cry","posa2","cry"],

		["artem_p3_nrm","posa3","nrm"],
		["artem_p3_smi","posa3","smi"],
		["artem_p3_lau","posa3","lau"],
		["artem_p3_sur","posa3","sur"],
		["artem_p3_hm","posa3","hm"],
		["artem_p3_cry","posa3","cry"],
	];

	var avats = [
		["_artem_nrm","posa1","body+nrm"],
		["_artem_hm","posa1","body+hm"],
		["_artem_cry","posa1","body+cry"],
		["_artem_smi","posa1","body+smi"],
		["_artem_lau","posa1","body+lau"],
		["_artem_sur","posa1","body+sur"]
	];

	exportCharacter(bodies,emots,avats,exportTo,scaleFactor,refs_path,exportToD);
}

if(exportTo == "anton"){

	var bodies = [
		["anton_p1_dress1","posa1","body+dress1"],
		["anton_p1_dress2","posa1","body+dress2"]
	];

	var emots = [
		["anton_p1_nrm","posa1","nrm"],
		["anton_p1_smi","posa1","smi"],
		["anton_p1_lau","posa1","lau"],
		["anton_p1_sur","posa1","sur"],
		["anton_p1_hm","posa1","hm"]
	];

	var avats = [
		["_anton_nrm","posa1","body+nrm"],
		["_anton_hm","posa1","body+hm"],
		["_anton_smi","posa1","body+smi"],
		["_anton_lau","posa1","body+lau"],
		["_anton_sur","posa1","body+sur"]
	];

	exportCharacter(bodies,emots,avats,exportTo,scaleFactor,refs_path,exportToD);
}

if(exportTo == "leia"){

	var bodies = [
		["leia_p1_dress1","posa1","body+dress1+hair1"]
	];

	var emots = [
		["leia_p1_nrm","posa1","nrm+nose"],
		["leia_p1_smi","posa1","smi+nose"],
		["leia_p1_smi_wide","posa1","smi_wide+nose"],
		["leia_p1_lau","posa1","lau+nose"],
		["leia_p1_sur","posa1","sur+nose"],
		["leia_p1_hm","posa1","hm+nose"]
	];

	var avats = [
		["_leia_nrm","posa1","body+hair1+nrm+nose"],
		["_leia_hm","posa1","body+hair1+hm+nose"],
		["_leia_smi","posa1","body+hair1+smi+nose"],
		["_leia_smi_wide","posa1","body+hair1+smi_wide+nose"],
		["_leia_lau","posa1","body+hair1+lau+nose"],
		["_leia_sur","posa1","body+hair1+sur+nose"]
	];

	exportCharacter(bodies,emots,avats,exportTo,scaleFactor,refs_path,exportToD);
}

if(exportTo == "may"){

	var bodies = [
		["may_p1_dress1","posa1","body+dress1+hair1"],
		["may_p2_dress2","posa2","hair1a+body+dress2+hair1+body_part2"]
	];

	var emots = [
		["may_p1_nrm","posa1","nrm+nose"],
		["may_p1_smi","posa1","smi+nose"],
		["may_p1_lau","posa1","lau+nose"],
		["may_p1_sur","posa1","sur+nose"],
		["may_p1_rage","posa1","rage+nose"],
		["may_p1_hm","posa1","hm+nose"],
		["may_p2_nrm","posa2","nrm+nose"],
		["may_p2_smi","posa2","smi+nose"],
		["may_p2_lau","posa2","lau+nose"],
		["may_p2_sur","posa2","sur+nose"],
		["may_p2_rage","posa2","rage+nose"],
		["may_p2_hm","posa2","hm+nose"]
	];

	var avats = [
		["_may_nrm","posa1","body+hair1+nrm+nose"],
		["_may_hm","posa1","body+hair1+hm+nose"],
		["_may_smi","posa1","body+hair1+smi+nose"],
		["_may_lau","posa1","body+hair1+lau+nose"],
		["_may_sur","posa1","body+hair1+sur+nose"],
		["_may_rage","posa1","body+hair1+rage+nose"]
	];

	exportCharacter(bodies,emots,avats,exportTo,scaleFactor,refs_path,exportToD);
}

if(exportTo == "ura"){

	var bodies = [
		["ura_p1_dress1","posa1","body+dress1+dress1_hat"],
		["ura_p1_dress2","posa1","body+dress2"],
		["ura_p1_dress3","posa1","body+dress3"],

		["ura_p2_dress1","posa2","body+dress1+dress1_hat"],
		["ura_p2_dress2","posa2","body+dress2"],
		["ura_p2_dress3","posa2","body+dress3"],
	];

	var emots = [
		["ura_p1_nrm","posa1","nrm"],
		["ura_p1_smi","posa1","smi"],
		["ura_p1_lau","posa1","lau"],
		["ura_p1_sur","posa1","sur"],
		["ura_p1_hm","posa1","hm"],

		["ura_p2_nrm","posa2","nrm"],
		["ura_p2_smi","posa2","smi"],
		["ura_p2_lau","posa2","lau"],
		["ura_p2_sur","posa2","sur"],
		["ura_p2_hm","posa2","hm"]
	];

	var avats = [
		["_ura_nrm","posa1","body+nrm"],
		["_ura_hm","posa1","body+hm"],
		["_ura_smi","posa1","body+smi"],
		["_ura_lau","posa1","body+lau"],
		["_ura_sur","posa1","body+sur"]
	];

	exportCharacter(bodies,emots,avats,exportTo,scaleFactor,refs_path,exportToD);
}


if(exportTo == "janna"){

	var bodies = [
		["janna_p1_dress1","posa1","body+dress1+body_part2_dress1+hairs2+hairs2_shadow"],
		["janna_p2_dress1","posa2","body+dress1+hairs2+hairs2_shadow"],
		["janna_p3_dress1","posa3","body+dress1+hairs2+hairs2_shadow"],
		["janna_p4_dress1","posa4","body+dress1+body_part2_dress1+hairs2+hairs2_shadow"],
		["janna_p5_dress1","posa5","body+dress1+body_part2_dress1+hairs2+hairs2_shadow"],

		["janna_p1_dress2","posa1","body+dress2+body_part2_dress2+hairs2+hairs2_shadow"],
		["janna_p2_dress2","posa2","body+dress2+hairs2+hairs2_shadow"],
		["janna_p3_dress2","posa3","body+dress2+hairs2+hairs2_shadow"],
		["janna_p4_dress2","posa4","body+dress2+body_part2_dress2+hairs2+hairs2_shadow"],
		["janna_p5_dress2","posa5","body+dress2+body_part2_dress2+hairs2+hairs2_shadow"],

		["janna_p1_dress3","posa1","body+dress3+body_part2_dress2+hairs2+hairs2_shadow"],
		["janna_p2_dress3","posa2","body+dress3+hairs2+hairs2_shadow"],
		["janna_p3_dress3","posa3","body+dress3+hairs2+hairs2_shadow"],
		["janna_p4_dress3","posa4","body+dress3+body_part2_dress2+hairs2+hairs2_shadow"],
		["janna_p5_dress3","posa5","body+dress3+body_part2_dress2+hairs2+hairs2_shadow"],
	];

	var emots = [
		["janna_p1_nrm","posa1","nrm+glasses+nose"],
		["janna_p1_smi","posa1","smi+glasses+nose"],
		["janna_p1_lau","posa1","lau+glasses+nose"],
		["janna_p1_sur","posa1","sur+glasses+nose"],
		["janna_p1_hm","posa1","hm+glasses+nose"],
		["janna_p1_scared","posa1","scared+glasses+nose"],
		["janna_p1_sad","posa1","sad+glasses+nose"],
		["janna_p1_dream","posa1","dream+glasses+nose"],

		["janna_p2_nrm","posa2","nrm+glasses+nose"],
		["janna_p2_smi","posa2","smi+glasses+nose"],
		["janna_p2_lau","posa2","lau+glasses+nose"],
		["janna_p2_sur","posa2","sur+glasses+nose"],
		["janna_p2_hm","posa2","hm+glasses+nose"],
		["janna_p2_scared","posa2","scared+glasses+nose"],
		["janna_p2_sad","posa2","sad+glasses+nose"],
		["janna_p2_dream","posa2","dream+glasses+nose"],

		["janna_p3_nrm","posa3","nrm+glasses+nose"],
		["janna_p3_smi","posa3","smi+glasses+nose"],
		["janna_p3_lau","posa3","lau+glasses+nose"],
		["janna_p3_sur","posa3","sur+glasses+nose"],
		["janna_p3_hm","posa3","hm+glasses+nose"],
		["janna_p3_scared","posa3","scared+glasses+nose"],
		["janna_p3_sad","posa3","sad+glasses+nose"],
		["janna_p3_dream","posa3","dream+glasses+nose"],

		["janna_p4_nrm","posa4","nrm+glasses+nose"],
		["janna_p4_smi","posa4","smi+glasses+nose"],
		["janna_p4_lau","posa4","lau+glasses+nose"],
		["janna_p4_sur","posa4","sur+glasses+nose"],
		["janna_p4_hm","posa4","hm+glasses+nose"],
		["janna_p4_scared","posa4","scared+glasses+nose"],
		["janna_p4_sad","posa4","sad+glasses+nose"],
		["janna_p4_dream","posa4","dream+glasses+nose"],

		["janna_p5_nrm","posa5","nrm+glasses+nose"],
		["janna_p5_smi","posa5","smi+glasses+nose"],
		["janna_p5_lau","posa5","lau+glasses+nose"],
		["janna_p5_sur","posa5","sur+glasses+nose"],
		["janna_p5_hm","posa5","hm+glasses+nose"],
		["janna_p5_scared","posa5","scared+glasses+nose"],
		["janna_p5_sad","posa5","sad+glasses+nose"],
		["janna_p5_dream","posa5","dream+glasses+nose"],
	];

	var avats = [
		["_janna_nrm","posa1","body+nrm+glasses+hairs2+nose"],
		["_janna_hm","posa1","body+hm+glasses+hairs2+nose"],
		["_janna_smi","posa1","body+smi+glasses+hairs2+nose"],
		["_janna_lau","posa1","body+lau+glasses+hairs2+nose"],
		["_janna_sur","posa1","body+sur+glasses+hairs2+nose"],
		["_janna_scared","posa1","body+scared+glasses+hairs2+nose"],
		["_janna_sad","posa1","body+sad+glasses+hairs2+nose"],
		["_janna_dream","posa1","body+dream+glasses+hairs2+nose"],
	];

	exportCharacter(bodies,emots,avats,exportTo,scaleFactor,refs_path,exportToD);
}

alert("Done!");
