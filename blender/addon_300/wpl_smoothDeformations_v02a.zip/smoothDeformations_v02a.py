# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful, but
# WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTIBILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
# General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program. If not, see <http://www.gnu.org/licenses/>.

import os, sys, time, datetime
import math, copy, string, random
import numpy as np
import bpy, bmesh, mathutils

import bpy.types
from mathutils import Vector, Matrix, Euler, Quaternion
from mathutils.bvhtree import BVHTree
from mathutils.kdtree import KDTree
from bpy_extras import view3d_utils
from bpy.props import *

bl_info = {
    "name": "WPL Smooth deformations",
    "author" : "IPv6",
    "description" : "",
    "blender" : (2, 80, 0),
    "version" : (1, 2, 0),
    "location" : "",
    "warning" : "",
    "category" : "Generic"
}

kWPLRaycastEpsilon = 0.0001
kWPLCoordPrecision = 10000.0

class WPL_G:
	store = {}

def coToKey(co_vec):
	key = str(int(co_vec[0] * kWPLCoordPrecision))+"_"+str(int(co_vec[1] * kWPLCoordPrecision))+"_"+str(int(co_vec[2] * kWPLCoordPrecision))
	return key


def deselect_all_objects():
	for obj in bpy.data.objects:
		obj.select_set(False)

def set_active_object(obj):
	if obj:
		bpy.context.view_layer.objects.active = obj

def ensure_visible(obj):
	if obj:
		obj.hide_viewport = False
		obj.hide_set(False)

def select_and_change_mode(obj, obj_mode):
	old_mode = bpy.context.mode
	if obj_mode == "EDIT_MESH" or  obj_mode == "EDIT_CURVE":
		obj_mode = "EDIT"
	if obj_mode == "PAINT_VERTEX":
		obj_mode = "VERTEX_PAINT"
	if obj_mode == "PAINT_WEIGHT":
		obj_mode = "WEIGHT_PAINT"
	if (obj is not None and bpy.context.view_layer.objects.active != obj) or old_mode != 'OBJECT':
		# stepping out from currently active object mode, or switch may fail
		try:
			bpy.ops.object.mode_set(mode='OBJECT')
		except Exception as e:
			#print("select_and_change_mode: failed to prep mode", obj.name, old_mode, e)
			pass
	deselect_all_objects()
	if obj:
		ensure_visible(obj)
		obj.select_set(True)
		set_active_object(obj)
		try:
			bpy.ops.object.mode_set(mode=obj_mode)
			#print("select_and_change_mode: Select and change mode of", obj.name, obj_mode)
		except AttributeError:
			print("select_and_change_mode: Can't change the mode of", obj.name, obj_mode)
	return old_mode


def selected_vertsIdx(active_mesh):
	bpy.ops.object.mode_set(mode='OBJECT')
	selectedVertsIdx = [e.index for e in active_mesh.vertices if e.select]
	return selectedVertsIdx

def active_object(validTypes = None):
	obj = bpy.context.view_layer.objects.active
	if (obj is not None) and (validTypes is not None):
		if not (obj.type in validTypes):
			return None
	if (obj is not None) and (validTypes is not None) and (obj.type == 'CURVE'):
		isOkCurve = True
		if ('2D' in validTypes) or ('3D' in validTypes):
			if not (obj.data.dimensions in validTypes):
				isOkCurve = False
		if ('POLY' in validTypes) or ('NURBS' in validTypes) or ('BEZIER' in validTypes):
			# validTypes should contain proper types
			for polyline in obj.data.splines:
				if not (polyline.type in validTypes):
					isOkCurve = False
		if isOkCurve == False:
			return None
	return obj

def bm_geodesicDistmap_v05(bme, step_vIdx, maxloops, maxdist, ignoreEdges, ignoreHidden, limitWalk2verts):
	# counting propagations
	vertDistMap = {}
	vertOriginMap = {}
	vertStepMap = {}
	for vIdx in step_vIdx:
		vertOriginMap[vIdx] = vIdx
	for curStep in range(maxloops):
		for vIdx in step_vIdx:
			if vIdx not in vertStepMap:
				vertStepMap[vIdx] = curStep+1
			if vIdx not in vertDistMap:
				vertDistMap[vIdx] = 0.0
		nextStepIdx = {}
		for vIdx in step_vIdx:
			v = bme.verts[vIdx]
			nearVers = []
			if ignoreEdges:
				# across faces
				for f in v.link_faces:
					for fv in f.verts:
						nearVers.append(fv)
			else:
				# across edges
				for e in v.link_edges:
					nearVers.append(e.other_vert(v))
			for fv in nearVers:
				if ignoreHidden == True and fv.hide != 0:
					continue
				if (limitWalk2verts is not None) and (fv.index not in limitWalk2verts):
					continue
				if fv.index not in vertStepMap:
					fv_dist = vertDistMap[vIdx]+(fv.co-v.co).length
					if fv.index not in vertDistMap:
						vertDistMap[fv.index] = fv_dist
						vertOriginMap[fv.index] = vertOriginMap[vIdx]
						if (maxdist is None) or (fv_dist <= maxdist):
							nextStepIdx[fv.index] = vIdx
					elif vertDistMap[fv.index] > fv_dist:
						vertDistMap[fv.index] = fv_dist
						vertOriginMap[fv.index] = vertOriginMap[vIdx]
						if (maxdist is None) or (fv_dist <= maxdist):
							nextStepIdx[fv.index] = vIdx
		# print("- step",curStep+1,len(step_vIdx),len(nextStepIdx))
		step_vIdx = []
		for vIdxNext in nextStepIdx:
			step_vIdx.append(vIdxNext)
		if len(step_vIdx) == 0:
			#print("- walk stopped at", curStep)
			break
	return vertDistMap, vertOriginMap, vertStepMap

def bm_sortVertsByConnection_v01(bm, vertsIdx, smartFirst):
	bm.verts.ensure_lookup_table()
	bm.verts.index_update()
	bm.edges.ensure_lookup_table()
	bm.edges.index_update()
	bm.faces.ensure_lookup_table()
	bm.faces.index_update()
	if len(vertsIdx)<3:
		return vertsIdx
	if smartFirst:
		for i in range(1, len(vertsIdx)):
			v = bm.verts[vertsIdx[i]]
			selothors = 0
			for e in v.link_edges:
				if e.other_vert(v).index in vertsIdx:
					selothors = selothors+1
			if selothors == 1:
				t = vertsIdx[0]
				vertsIdx[0] = vertsIdx[i]
				vertsIdx[i] = t
				break
	for i in range(len(vertsIdx)-1):
		v = bm.verts[vertsIdx[i]]
		mindst = 9999
		exhpos = -1
		for j in range(i+1,len(vertsIdx)):
			vo = bm.verts[vertsIdx[j]]
			for f in v.link_faces:
				if vo in f.verts:
					if (vo.co-v.co).length < mindst:
						mindst = (vo.co-v.co).length
						exhpos = j
					break
		if exhpos >= 0:
			t = vertsIdx[i+1]
			vertsIdx[i+1] = vertsIdx[exhpos]
			vertsIdx[exhpos] = t
	return vertsIdx

def bm_setPinmapFastIdx(active_obj, bm, pinId):
	bm.verts.ensure_lookup_table()
	bm.verts.index_update()
	bm.faces.ensure_lookup_table()
	bm.faces.index_update()
	pins_f = []
	pins_v = {}
	for vert in bm.verts:
		pindat = {}
		isSelect = 0
		if vert.select:
			isSelect = 1
		isHide = 0
		if vert.hide>0:
			isHide = 1
		pindat["co"] = copy.copy(vert.co)
		vert_co_g = active_obj.matrix_world @ vert.co
		pindat["co_g"] = vert_co_g
		pindat["se"] = isSelect
		pindat["hi"] = isHide
		pins_v[vert.index] = pindat
	for f in bm.faces:
		if not f.select:
			continue
		if f.hide:
			continue
		faceverts = []
		for vert in f.verts:
			v_co_g = active_obj.matrix_world @ vert.co
			faceverts.append(v_co_g)
		pins_f.append(faceverts)
	WPL_G.store[pinId] = pins_v
	WPL_G.store[pinId+"_selfaces"] = pins_f

def bm_getPinmapFastIdx(active_obj, bm, pinId):
	if pinId not in WPL_G.store:
		return None, None
	pins_v = WPL_G.store[pinId]
	verts_dat = {}
	faces_dat = []
	if pinId+"_selfaces" in WPL_G.store:
		faces_dat = WPL_G.store[pinId+"_selfaces"]
	bm.verts.ensure_lookup_table()
	bm.verts.index_update()
	bm.faces.ensure_lookup_table()
	bm.faces.index_update()
	for vert in bm.verts:
		verts_dat[vert.index] = {}
		if vert.index not in pins_v:
			verts_dat[vert.index]["co"] = Vector(vert.co)
			verts_dat[vert.index]["co_g"] = active_obj.matrix_world @ vert.co
			verts_dat[vert.index]["se"] = 0
			verts_dat[vert.index]["hi"] = 0
			verts_dat[vert.index]["idx"] = 0
		else:
			idxpin = pins_v[vert.index]
			verts_dat[vert.index]["co"] = Vector(idxpin["co"])
			verts_dat[vert.index]["co_g"] = Vector(idxpin["co_g"])
			verts_dat[vert.index]["se"] = idxpin["se"]
			verts_dat[vert.index]["hi"] = idxpin["hi"]
			verts_dat[vert.index]["idx"] = vert.index
	return verts_dat, faces_dat

def bm_vertsPropagations_v02(bm, smoothingLoops, initialVertsIdx):
	propagation_stages = []
	allWalkedVerts = []
	vertsFromIdx = {}
	#vertsFromRootIdx = {}
	vertsAddWeight = {}
	checked_verts = copy.copy(initialVertsIdx)
	for stage in range(1,int(smoothingLoops)+1):
		stage_verts = []
		checked_verts_cc = copy.copy(checked_verts)
		for v_idx in checked_verts_cc:
			v = bm.verts[v_idx]
			allWalkedVerts.append(v_idx)
			for edg in v.link_edges:
				v2 = edg.other_vert(v)
				if v2.hide == 0 and v2.index not in checked_verts_cc:
					if v2.index not in checked_verts:
						checked_verts.append(v2.index)
					if(v2.index not in stage_verts):
						vertsAddWeight[v2.index] = 1.0-(1.0+len(propagation_stages))/(1.0+smoothingLoops)
						stage_verts.append(v2.index)
						vertsFromIdx[v2.index] = []
					if v_idx not in vertsFromIdx[v2.index]:
						vertsFromIdx[v2.index].append(v_idx)
		if len(stage_verts) == 0:
			break
		propagation_stages.append(stage_verts)
	return (propagation_stages, vertsAddWeight, allWalkedVerts, vertsFromIdx)

def bm_fuzzyBVHRayCast_v01(bvh, vFrom, vDir, fuzzyVal, fuzzyQual):
	gResult = mathutils.Vector((0,0,0))
	gResultNormal = mathutils.Vector((0,0,0))
	gCount = 0.0
	vDirs = [vDir.normalized()]
	if fuzzyVal > 0.0:
		perpBase = mathutils.Vector((0,0,1))
		if(math.fabs(vDir.dot(perpBase)) > 0.9):
			perpBase = mathutils.Vector((0,1,0))
		perp1 = vDir.cross(perpBase)
		perp2 = vDir.cross(perp1)
		vDirs = [vDir.normalized()]
		for i in range(0,fuzzyQual):
			delim = float(i+1)/float(fuzzyQual)
			slice = [(vDir+delim*perp1*fuzzyVal).normalized(), (vDir-delim*perp1*fuzzyVal).normalized(), (vDir+delim*perp2*fuzzyVal).normalized(), (vDir-delim*perp2*fuzzyVal).normalized()]
			vDirs.extend(slice)

	for shootDir in vDirs:
		loc_g, normal, index, distance = bvh.ray_cast(vFrom+vDir*kWPLRaycastEpsilon, shootDir)
		#print("fuzzySceneRayCast", vFrom, shootDir, result, loc_g)
		if loc_g is not None:
			gCount = gCount+1.0
			gResult = gResult+loc_g
			gResultNormal = gResultNormal+normal
	if gCount>0:
		return (gResult/gCount,gResultNormal/gCount)
	return (None, None)

# =============



class wplverts_pinsnap_gm(bpy.types.Operator):
	bl_idname = "mesh.wplverts_pinsnap_gm"
	bl_label = "Pin mesh state"
	bl_options = {'REGISTER', 'UNDO'}

	opt_pinId : StringProperty(
		name		= "Pin ID",
		default	 	= "fastpin1"
	)

	def execute(self, context):
		active_obj = active_object(['MESH'])
		if active_obj is None:
			self.report({'ERROR'}, "Select mesh object first")
			return {'CANCELLED'}

		active_mesh = active_obj.data
		select_and_change_mode(active_obj, 'EDIT')
		context.tool_settings.mesh_select_mode = (True, False, False) # 'VERT'
		bm = bmesh.from_edit_mesh(active_mesh)
		if bm_setPinmapFastIdx(active_obj, bm, self.opt_pinId) == 0:
			self.report({'ERROR'}, "Can`t create pinmap")
			return {'CANCELLED'}
		self.report({'INFO'}, "Mesh state remembered")
		return {'FINISHED'}

class wplverts_pinrestore_gm(bpy.types.Operator):
	bl_idname = "mesh.wplverts_pinrestore_gm"
	bl_label = "Restore selected"
	bl_options = {'REGISTER', 'UNDO'}

	opt_influence : FloatProperty(
			name="Influence",
			min=-10.0, max=10.0,
			default=1.0,
	)

	opt_pinId : StringProperty(
		name		= "Pin ID",
		default	 	= "fastpin1"
	)

	def execute(self, context):
		active_obj = active_object(['MESH'])
		if active_obj is None:
			self.report({'ERROR'}, "Select mesh object first")
			return {'CANCELLED'}

		matrix_world_inv = active_obj.matrix_world.inverted()
		active_mesh = active_obj.data
		select_and_change_mode(active_obj, 'EDIT')
		context.tool_settings.mesh_select_mode = (True, False, False) # 'VERT'
		bm = bmesh.from_edit_mesh(active_mesh)
		bm.verts.ensure_lookup_table()
		bm.verts.index_update()
		bm.faces.ensure_lookup_table()
		selverts = [v.index for v in bm.verts if v.select]
		if len(selverts) == 0:
			self.report({'ERROR'}, "No moved/selected verts found")
			return {'CANCELLED'}
		verts_snap_map, faces_snap_map = bm_getPinmapFastIdx(active_obj, bm, self.opt_pinId)
		if verts_snap_map is None:
			self.report({'ERROR'}, "Mesh not pinned")
			return {'CANCELLED'}
		for vIdx in selverts:
			s_v = bm.verts[vIdx]
			s_v_co_init = verts_snap_map[vIdx]["co"]
			s_v.co = s_v.co.lerp(s_v_co_init,self.opt_influence)
		bm.normal_update()
		bmesh.update_edit_mesh(active_mesh)
		return {'FINISHED'}

class wplverts_pinpropagt_gm(bpy.types.Operator):
	bl_idname = "mesh.wplverts_pinpropagt_gm"
	bl_label = "Smooth around"
	bl_options = {'REGISTER', 'UNDO'}

	opt_mode : EnumProperty(
		items = [
			('KEEPACTIV', "Active selection", "", 1),
			('ENFORPINS', "Reset initial", "", 2)
		],
		name="Movement source",
		default='KEEPACTIV',
	)

	opt_influence : FloatProperty(
			name="Influence",
			min=-100, max=100,
			default=1.0,
	)
	opt_smoothLoops : IntProperty(
			name="Smoothing loops",
			min=0, max=100,
			default=5,
	)
	opt_smoothPow : FloatProperty(
			name="Smoothing pow",
			min=0.001, max=10,
			default=1.0,
	)
	opt_pinId : StringProperty(
		name		= "Pin ID",
		default	 	= "fastpin1"
	)

	def execute(self, context):
		active_obj = active_object(['MESH'])
		if active_obj is None:
			self.report({'ERROR'}, "Select mesh object first")
			return {'CANCELLED'}
		
		active_mesh = active_obj.data
		selverts = selected_vertsIdx(active_mesh)
		select_and_change_mode(active_obj, 'EDIT')

		matrix_world = active_obj.matrix_world
		matrix_world_inv = active_obj.matrix_world.inverted()
		matrix_world_nrml = matrix_world_inv.transposed().to_3x3()
		bm = bmesh.from_edit_mesh(active_mesh)
		bm.verts.ensure_lookup_table()
		bm.faces.ensure_lookup_table()
		bm.verts.index_update()
		verts_shifts = {}
		verts_snap_map, faces_snap_map = bm_getPinmapFastIdx(active_obj, bm, self.opt_pinId)
		if verts_snap_map is None:
			self.report({'ERROR'}, "Mesh not pinned")
			return {'CANCELLED'}
		useCurrentVposAsRef = False
		if self.opt_mode == 'ENFORPINS':
			selverts = []
			useCurrentVposAsRef = True
			# resetting initial selection
			for v in bm.verts:
				if verts_snap_map[v.index]["se"] > 0:
					selverts.append(v.index)
					v_co2 = v.co.lerp(verts_snap_map[v.index]["co"], self.opt_influence)
					verts_shifts[v.index] = Vector(v_co2 - v.co)
					v.co = v_co2
		if len(selverts) == 0:
			selverts = []
			for v in bm.verts:
				if verts_snap_map[v.index] is not None:
					if (v.co-verts_snap_map[v.index]["co"]).length > kWPLRaycastEpsilon:
						# vert moved
						selverts.append(v.index)
		if len(selverts) == 0:
			self.report({'ERROR'}, "No moved/selected verts found")
			return {'CANCELLED'}
		(propagationSteps, vertsWeight, allWalkedVerts, vertsFromIdx) = bm_vertsPropagations_v02(bm, self.opt_smoothLoops, selverts)
		for v_idx in allWalkedVerts:
			if (v_idx not in verts_shifts) and (v_idx in verts_snap_map):
				v = bm.verts[v_idx]
				verts_shifts[v_idx] = Vector(v.co - verts_snap_map[v_idx]["co"])
		new_positions = {}
		for stage_verts in propagationSteps:
			for vIdx in stage_verts:
				if vIdx not in verts_snap_map:
					continue
				avg_shift = mathutils.Vector((0,0,0))
				avg_count = 0.0
				from_vIdxes = vertsFromIdx[vIdx]
				for froms_idx in from_vIdxes:
					avg_shift = avg_shift + verts_shifts[froms_idx]
					avg_count = avg_count + 1.0
				#print("Vert avg shift", vIdx, avg_shift, avg_count, from_vIdxes)
				if avg_count>0:
					s_shift = mathutils.Vector(avg_shift)/avg_count
					verts_shifts[vIdx] = s_shift
					if useCurrentVposAsRef:
						s_v_co = bm.verts[vIdx].co
					else:
						s_v_co = verts_snap_map[vIdx]["co"]
					total_shift = s_shift
					vertWeight = 1.0
					if self.opt_smoothPow > 0.0:
						if vIdx in vertsWeight and abs(vertsWeight[vIdx])>0.0:
							vertWeight = pow(vertsWeight[vIdx], self.opt_smoothPow)
						else:
							print("- opt_smoothPow: vert not found", vIdx, len(vertsWeight))
					total_shift = total_shift*vertWeight*self.opt_influence
					s_v_co2 = s_v_co+total_shift
					new_positions[vIdx] = s_v_co2
		# updating positions as post-step
		for s_idx in new_positions:
			if self.opt_mode == 'KEEPACTIV' and s_idx in selverts:
				continue
			s_v = bm.verts[s_idx]
			s_v.co = new_positions[s_idx]
		bm.normal_update()
		bmesh.update_edit_mesh(active_mesh)
		self.report({'INFO'}, "Smoothed "+str(len(new_positions))+" verts")
		return {'FINISHED'}

class wplverts_pinsurfshrw_gm(bpy.types.Operator):
	bl_idname = "mesh.wplverts_pinsurfshrw_gm"
	bl_label = "Shrinkwrap to pinned"
	bl_options = {'REGISTER', 'UNDO'}

	opt_influence : FloatProperty(
		name		= "Influence",
		default	 = 1.0,
		min		 = 0,
		max		 = 1
	)
	opt_shrinkwMethod : EnumProperty(
		name="Detection method", default="NEAR",
		items=(("NEAR", "Near surface", ""), 
			("NEGPROJ", "Negative proj", ""))
	)
	opt_vertsType : EnumProperty(
		name="Apply to verts", default="ALL",
		items=(("ALL", "All", ""), ("ABOVE", "Above surface", ""), ("UNDER", "Under surface", ""))
	)
	opt_makeConvex : BoolProperty(
		name="Shrinkwrap to convex", default=False
	)
	opt_dopFeats : FloatVectorProperty(
		name = "Softcast/Displace/???",
		size = 3,
		default	 = (0.5, 0.0, 0.0)
	)
	opt_pinId : StringProperty(
		name		= "Pin ID",
		default	 	= "fastpin1"
	)

	def execute( self, context ):
		active_obj = active_object(['MESH'])
		if active_obj is None:
			self.report({'ERROR'}, "Select mesh object first")
			return {'CANCELLED'}

		active_mesh = active_obj.data
		selvertsAll = selected_vertsIdx(active_mesh)
		if len(selvertsAll) == 0:
			self.report({'ERROR'}, "No verts selected")
			return {'FINISHED'}
		matrix_world_inv = active_obj.matrix_world.inverted()
		matrix_world_norm = matrix_world_inv.transposed().to_3x3()
		select_and_change_mode(active_obj,"EDIT")
		bm = bmesh.from_edit_mesh(active_mesh)
		bm.verts.ensure_lookup_table()
		bm.verts.index_update()
		bm.faces.ensure_lookup_table()
		bm.faces.index_update()
		bm2bvh = None

		#print("self.opt_pinId0", self.opt_pinId, self.opt_dopFeats)
		verts_snap_map, faces_snap_map = bm_getPinmapFastIdx(active_obj, bm, self.opt_pinId)
		if faces_snap_map is not None:
			bm2 = bmesh.new()
			bm2vmap = {}
			bm2conv = []
			for f_vg in faces_snap_map:
				f_v_set = []
				f_v_set_ko = []
				for v_co_g in f_vg:
					v_co = matrix_world_inv @ v_co_g
					vert_index = coToKey(v_co)
					if vert_index not in bm2vmap:
						v_cc = bm2.verts.new(v_co)
						bm2vmap[vert_index] = v_cc
					else:
						v_cc = bm2vmap[vert_index]
					#v_cc = bm2.verts.new(v_co)
					if v_cc not in f_v_set:
						f_v_set.append(v_cc)
						f_v_set_ko.append(vert_index)
				if len(f_v_set) >= 3:
					f_v_set_ko = sorted(f_v_set_ko)
					f_v_set_ko = ",".join(f_v_set_ko)
					if f_v_set_ko not in bm2vmap:
						bm2vmap[f_v_set_ko] = f_v_set
						f_cc = bm2.faces.new(f_v_set)
				if self.opt_makeConvex:
					for v_cc in f_v_set:
						if v_cc not in bm2conv:
							bm2conv.append(v_cc)
			if len(bm2conv)>0:
				res = bmesh.ops.convex_hull(bm2, input=bm2conv)
				bm2.verts.ensure_lookup_table()
				bm2.verts.index_update()
				bm2.faces.ensure_lookup_table()
				bm2.faces.index_update()
			bm2.normal_update()
			bm2bvh = BVHTree.FromBMesh(bm2, epsilon = kWPLRaycastEpsilon)
			bm2.free()
		if bm2bvh is None:
			self.report({'ERROR'}, "No surface faces found, pin mesh with selected faces first")
			return {'CANCELLED'}

		vertsWeight = None
		vnormls = {}
		for vIdx in selvertsAll:
			v = bm.verts[vIdx]
			vnormls[vIdx] = v.normal
		okCnt = 0
		for vIdx in selvertsAll:
			v = bm.verts[vIdx]
			if self.opt_shrinkwMethod == 'NEAR':
				n_loc, n_normal, n_index, n_distance = bm2bvh.find_nearest(v.co)
			else: # NEGPROJ
				proj_dir = -1*vnormls[vIdx]
				n_loc, n_normal = bm_fuzzyBVHRayCast_v01(bm2bvh, v.co, proj_dir, self.opt_dopFeats[0], 4)
			if n_loc is not None:
				n_normorg = n_normal
				dotFac = (v.co-n_loc).dot(n_normal)
				if self.opt_vertsType == 'ABOVE':
					if dotFac <= 0:
						continue
				if self.opt_vertsType == 'UNDER':
					if dotFac > 0:
						continue
				if abs(self.opt_dopFeats[1])>0.00001:
					n_loc = n_loc+n_normal*self.opt_dopFeats[1]
				infl = self.opt_influence
				v.co = v.co.lerp(n_loc,infl)
				okCnt = okCnt+1
		bm.verts.ensure_lookup_table()
		bm.faces.ensure_lookup_table()
		bm.verts.index_update()
		bm.normal_update()
		bmesh.update_edit_mesh(active_mesh)
		self.report({'INFO'}, "Done, "+str(okCnt)+" verts moved")
		return {'FINISHED'}

# ==============================================

class WPL_PT_SculptPanelGM2(bpy.types.Panel):
	bl_idname = "WPL_PT_SculptPanelGM2"
	bl_label = "Mesh helpers"
	bl_space_type = 'VIEW_3D'
	bl_region_type = 'UI'
	bl_category = 'WPL'

	def draw(self, context):
		layout = self.layout
		active_obj = active_object()
		col = layout.column()
		box1 = col.box()
		box1.operator("mesh.wplverts_pinsnap_gm", text="S1: Pin").opt_pinId = "fastpin1"
		box1.operator("mesh.wplverts_pinrestore_gm", text="S1: Sel restore")
		box1.separator()
		box1.operator("mesh.wplverts_pinpropagt_gm", text="S1: Smooth selection").opt_mode = 'KEEPACTIV'
		box1.operator("mesh.wplverts_pinpropagt_gm", text="S1: Enforce pinned").opt_mode = 'ENFORPINS'
		box1.separator()
		ss1 = box1.operator("mesh.wplverts_pinsurfshrw_gm", text="S1: Shrinkwrap")
		ss1.opt_shrinkwMethod = 'NEAR'
		ss1.opt_vertsType = 'ALL'
		ss1.opt_pinId = "fastpin1"
		col.separator()
		box2 = col.box()
		box2.operator("mesh.wplverts_pinsnap_gm", text="S2: Pin").opt_pinId = "fastpin2"
		ss1 = box2.operator("mesh.wplverts_pinsurfshrw_gm", text="S2: Shrinkwrap")
		ss1.opt_shrinkwMethod = 'NEAR'
		ss1.opt_vertsType = 'ALL'
		ss1.opt_pinId = "fastpin2"


# ==========================================
# ==========================================

classes = (
	WPL_PT_SculptPanelGM2,
	wplverts_pinsnap_gm,
	wplverts_pinrestore_gm,
	wplverts_pinpropagt_gm,
	wplverts_pinsurfshrw_gm,
)

def register():
	for cls in classes:
		bpy.utils.register_class(cls)

def unregister():
	for cls in reversed(classes):
		bpy.utils.unregister_class(cls)

if __name__ == "__main__":
	register()