# ##### BEGIN GPL LICENSE BLOCK #####
#
#  This program is free software; you can redistribute it and/or
#  modify it under the terms of the GNU General Public License
#  as published by the Free Software Foundation; either version 2
#  of the License, or (at your option) any later version.
#
#  This program is distributed in the hope that it will be useful,
#  but WITHOUT ANY WARRANTY; without even the implied warranty of
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#  GNU General Public License for more details.
#
#  You should have received a copy of the GNU General Public License
#  along with this program; if not, write to the Free Software Foundation,
#  Inc., 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301, USA.
#
# ##### END GPL LICENSE BLOCK #####
# Created by Kushiro

import math

import bpy
import bmesh

from mathutils import Matrix, Vector, Quaternion

import mathutils

import math
from bpy.props import (
	FloatProperty,FloatVectorProperty,
	IntProperty,
	BoolProperty,
	EnumProperty,
)

from . import gui

kWPLRaycastEpsilon = 0.0001
def active_object(validTypes = None):
	obj = bpy.context.view_layer.objects.active
	if (obj is not None) and (validTypes is not None):
		if not (obj.type in validTypes):
			return None
		if (obj.type == 'CURVE'):
			isOkCurve = True
			if ('2D' in validTypes) or ('3D' in validTypes):
				if not (obj.data.dimensions in validTypes):
					isOkCurve = False
			if ('POLY' in validTypes) or ('NURBS' in validTypes) or ('BEZIER' in validTypes):
				# validTypes should contain proper types
				for polyline in obj.data.splines:
					if not (polyline.type in validTypes):
						isOkCurve = False
						break
			if isOkCurve == False:
				return None
	return obj

def select_and_change_mode(obj, obj_mode):
	old_mode = bpy.context.mode
	for objx in bpy.data.objects:
		objx.select_set(False)
	bpy.ops.object.mode_set(mode='OBJECT')
	if obj_mode == "EDIT_MESH" or obj_mode == "EDIT_CURVE" or obj_mode == "EDIT_ARMATURE" or obj_mode == "EDIT_LATTICE":
		obj_mode = "EDIT"
	if obj:
		obj.select_set(True)
		bpy.context.view_layer.objects.active = obj
		bpy.ops.object.mode_set(mode=obj_mode)
	return old_mode

def bisect_gen_lines(numberCuts, p1, p2, norml):
	lines = []
	if numberCuts<3:
		return lines
	for i in range(int(numberCuts)+1):
		pp = p1.lerp(p2, i/numberCuts)
		lines.append( (pp, norml) )
	return lines

def bisect_make_mass(bm, cutplanes):
	print("- Bisecting. planes:",len(cutplanes))
	verts_protect_co = []
	for cutpp in cutplanes:
		bm.verts.index_update()
		bm.verts.ensure_lookup_table()
		bm.edges.index_update()
		bm.edges.ensure_lookup_table()
		bm.faces.index_update()
		bm.faces.ensure_lookup_table()
		bisectFaces = [f for f in bm.faces if f.hide == False]
		geom_in_v = []
		geom_in_e = []
		geom_in_f = []
		for f in bisectFaces:
			geom_in_v.extend(f.verts)
			geom_in_e.extend(f.edges)
			geom_in_f.append(f)
		geom_in = set(geom_in_v[:]+geom_in_e[:]+geom_in_f[:])
		print("- Bisecting faces", len(geom_in_f), cutpp)
		res = bmesh.ops.bisect_plane(bm, geom=list(geom_in), dist=kWPLRaycastEpsilon, plane_co=cutpp[0], plane_no=cutpp[1], use_snap_center=False, clear_outer=False, clear_inner=False)
		# TBD: need to calc PROTECTED verts (angle != 180)
		# bisect_v = set()
		# bisect_e = set()
		# for elem in res["geom"]:
		# 	if isinstance(elem, bmesh.types.BMEdge):
		# 		bisect_e.add(elem)
		# 	if isinstance(elem, bmesh.types.BMVert):
		# 		bisect_v.add(elem)
	return verts_protect_co

class QuadSwordsOperator(bpy.types.Operator):
	"""Tooltip"""
	bl_idname = "mesh.quad_swords_operator"
	bl_label = "Quad Swords"
	bl_options = {"REGISTER", "UNDO"}
	#, "GRAB_CURSOR", "BLOCKING"


	opt_cutDensity: FloatProperty(
		name="Slice density",
		description="Define the density of the cuts",
		default=5,
		min = 1,
		step = 1
	)
	opt_cutDensityPerAxis: FloatVectorProperty(
		name="Segments per axis",
		size=3, default=(1.0,1.0,1.0),
		min = 0.0,
		max = 50.0
	)
	
	opt_bboxMargin: FloatProperty(
		name="Margin",
		description="Define the negative margin of the projection",
		default=1.01,
		min = 1,
		max = 5
	)

	opt_cutSelectionOnly: BoolProperty(
		name="Selected Faces Only",
		description="Only cut the selected faces",
		default=False,
	)

	opt_postCleanup: BoolProperty(
		name="Remove old edges",
		default=True,
	)

	# Running as separate dialog
	def invoke(self, context, event):
		return context.window_manager.invoke_props_dialog(self, width = 200)

	def execute( self, context ):
		active_obj = active_object(['MESH'])
		if active_obj is None:
			self.report({'ERROR'}, "Select mesh object first")
			return {'FINISHED'}
		print("- obj", active_obj)
		oldmode = select_and_change_mode(active_obj,'EDIT')
		if self.opt_cutSelectionOnly:
			if any([v.select == True for v in active_obj.data.vertices]) == False:
				self.report({'ERROR'}, "Select some verts first")
				return {'FINISHED'}
		print("- starting cuts")
		bs = [Vector(p) for p in active_obj.bound_box]
		if self.opt_cutSelectionOnly:
			bpy.ops.mesh.select_mode(type="FACE")
			bpy.ops.mesh.hide(unselected=True)
			bs = [Vector(v.co) for v in active_obj.data.vertices]

		x1 = min(bs, key=lambda e:e.x).x
		x2 = max(bs, key=lambda e:e.x).x
		y1 = min(bs, key=lambda e:e.y).y
		y2 = max(bs, key=lambda e:e.y).y
		z1 = min(bs, key=lambda e:e.z).z
		z2 = max(bs, key=lambda e:e.z).z
		margin = self.opt_bboxMargin
		x1 *= margin
		x2 *= margin
		y1 *= margin
		y2 *= margin
		z1 *= margin
		z2 *= margin
		
		bisect_lines = []
		bisect_lines = bisect_lines+bisect_gen_lines(int(self.opt_cutDensity*self.opt_cutDensityPerAxis[0]), Vector((x1, y1, z1)), Vector((x2, y1, z1)), Vector((1, 0, 0)))
		bisect_lines = bisect_lines+bisect_gen_lines(int(self.opt_cutDensity*self.opt_cutDensityPerAxis[1]), Vector((x1, y1, z1)), Vector((x1, y2, z1)), Vector((0, 1, 0)))
		bisect_lines = bisect_lines+bisect_gen_lines(int(self.opt_cutDensity*self.opt_cutDensityPerAxis[2]), Vector((x1, y1, z1)), Vector((x1, y1, z2)), Vector((0, 0, 1)))
		if len(bisect_lines) == 0:
			self.report({'ERROR'}, "No bisect lines")
			return {'FINISHED'}
		select_and_change_mode(active_obj,'OBJECT')
		select_and_change_mode(active_obj,'EDIT')
		active_mesh = active_obj.data
		bm = bmesh.from_edit_mesh( active_mesh )
		bm.verts.index_update()
		bm.verts.ensure_lookup_table()
		bm.edges.index_update()
		bm.edges.ensure_lookup_table()
		bm.faces.index_update()
		bm.faces.ensure_lookup_table()
		verts_protect_co = bisect_make_mass(bm, bisect_lines)
		bmesh.update_edit_mesh(active_mesh)
		
		if self.opt_postCleanup:
			print("- cleaning mesh, lines",len(bisect_lines))
			maxTries = 50
			while maxTries > 0:
				maxTries = maxTries-1
				select_and_change_mode(active_obj,'OBJECT')
				select_and_change_mode(active_obj,'EDIT')
				#bpy.ops.mesh.select_all( action = 'DESELECT' )
				active_mesh = active_obj.data
				bm = bmesh.from_edit_mesh( active_mesh )
				bm.verts.index_update()
				bm.verts.ensure_lookup_table()
				bm.edges.index_update()
				bm.edges.ensure_lookup_table()
				bm.faces.index_update()
				bm.faces.ensure_lookup_table()
				vertsUsed = set()
				edges2Diss = []
				diff = 0.0001
				for e in bm.edges:
					if e.is_wire or e.is_boundary or e.hide or e.seam or any([f.hide == True for f in e.link_faces]):
						continue
					if (e.verts[0] in vertsUsed) or (e.verts[1] in vertsUsed):
						continue
					v0co = e.verts[0].co
					v1co = e.verts[1].co
					isEdgeFromCutlines = False
					for cutpp in bisect_lines:
						dst0 = abs(mathutils.geometry.distance_point_to_plane(v0co, cutpp[0], cutpp[1]))
						dst1 = abs(mathutils.geometry.distance_point_to_plane(v1co, cutpp[0], cutpp[1]))
						if dst0<diff and dst1<diff:
							isEdgeFromCutlines = True
							break
					if isEdgeFromCutlines:
						continue
					#e.select = True
					vertsUsed.add(e.verts[0])
					vertsUsed.add(e.verts[1])
					edges2Diss.append(e)
				if len(edges2Diss) == 0:
					print("- nothing to dissolve", maxTries)
					break
				print("- dissolving edges", maxTries, len(edges2Diss))
				bmesh.ops.dissolve_edges(bm, edges = edges2Diss, use_verts=True, use_face_split=False)
				bmesh.update_edit_mesh(active_mesh)
		bpy.ops.mesh.select_all(action = 'DESELECT')
		select_and_change_mode(active_obj,'OBJECT')
		if self.opt_cutSelectionOnly:
			select_and_change_mode(active_obj,'EDIT')
			bpy.ops.mesh.reveal()
			bpy.ops.mesh.select_all(action='INVERT')
		select_and_change_mode(active_obj, oldmode)
		self.report({'INFO'}, "Quad sword applied. lines "+str(len(bisect_lines)))
		return {'FINISHED'}
