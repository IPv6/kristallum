# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful, but
# WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTIBILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
# General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program. If not, see <http://www.gnu.org/licenses/>.

import os, sys, time, datetime
import math, copy, string, random
import numpy as np
import bpy, bmesh, mathutils

import bpy.types
from mathutils import Vector, Matrix, Euler, Quaternion
from mathutils.bvhtree import BVHTree
from mathutils.kdtree import KDTree
from bpy_extras import view3d_utils
from bpy.props import *

bl_info = {
    "name" : "WPL Node helpers",
    "author" : "IPv6",
    "description" : "",
    "blender" : (2, 80, 0),
    "version" : (1, 2, 0),
    "location" : "",
    "warning" : "",
    "category" : "Generic"
}

kWPLNodeMenuSubChar = '_'
class WPL_G_NODESGM:
	ngstore = {}
	rowstr = {}
	nodecopy = {}


class WPL_MT_NodeGroupsGM(bpy.types.Menu):
	bl_label = "WPL Groups"
	bl_idname = "WPL_MT_NodeGroupsGM"
	
	def draw(self, context):
		# menu type
		tree_type = context.space_data.tree_type
		typeFilter = 'SHADER'
		addnodeType = 'ShaderNodeGroup'
		if tree_type == 'CompositorNodeTree':
			typeFilter = 'COMPOSITING'
			addnodeType = 'CompositorNodeGroup'
		# hierlevel
		nameFilter = ""
		try:
			row = context.hier
			nameFilter = WPL_G_NODESGM.rowstr[row]
		except:
			pass
		if len(nameFilter) == 0:
			WPL_G_NODESGM.rowstr = {} # resetting to free objects
		#print("WPL_G_NODESGM.rowstr len=",len(WPL_G_NODESGM.rowstr))
		layout = self.layout
		all_ngroups = bpy.data.node_groups
		all_ngroups_mtt = []
		next_hiercounts = {}
		for ng in all_ngroups:
			ui_name = ng.name
			if ng.type != typeFilter:
				# ignoring improper nodes
				#print("node type",ng.type)
				continue
			if ng.library is not None:
				ui_name = "L: "+ng.name
			if len(nameFilter) > 0 and not ui_name.startswith(nameFilter):
				continue
			bpy.types.WindowManager.ngstore[ui_name] = ng
			
			ui_name_nofil = ui_name
			if len(nameFilter) > 0:
				ui_name_nofil = ui_name_nofil.replace(nameFilter,"")
			ng_hier = ui_name_nofil.split(kWPLNodeMenuSubChar)
			ng_hier_str = ""
			if len(ng_hier)>0:
				ng_hier_str = nameFilter+ng_hier[0]+kWPLNodeMenuSubChar
			if ng_hier_str not in next_hiercounts:
				next_hiercounts[ng_hier_str] = 0
			next_hiercounts[ng_hier_str] = next_hiercounts[ng_hier_str]+1
			item = {"item": ng, "ui_name": ui_name, "hier": ng_hier_str}
			all_ngroups_mtt.append(item)
		all_ngroups_mtt = sorted(all_ngroups_mtt, key=lambda k: k["ui_name"])
		
		if len(nameFilter) == 0:
			n_op_start = layout.operator("node.add_node", text = "Frame")
			n_op_start.type = "NodeFrame"
			n_op_start.use_transform = True
			n_op_start = layout.operator("node.add_node", text = "Reroute")
			n_op_start.type = "NodeReroute"
			n_op_start.use_transform = True
		else:
			n_op_start = layout.operator("node.add_node", text = nameFilter+"...")
			n_op_start.type = "NodeReroute"
			n_op_start.use_transform = True
		layout.separator()
		for item in all_ngroups_mtt:
			ng = item["item"]
			ng_ui = item["ui_name"]
			ng_hier = item["hier"]
			if len(ng_hier) == 0 or next_hiercounts[ng_hier] < 2:
				n_op = layout.operator("node.add_node", text = ng_ui) #bpy.ops.node.add_node
				n_op.type = addnodeType
				n_op.use_transform = True
				n_op_set = n_op.settings.add()
				n_op_set.name = "node_tree"
				# !!!-->> not using node name here! Local and Library items can have EXACT THE SAME NAME <<--!!!
				n_op_set.value = "bpy.types.WindowManager.ngstore['"+ng_ui+"']" #"bpy.data.node_groups['"+item.name+"']"
			else:
				if next_hiercounts[ng_hier] < 999:
					next_hiercounts[ng_hier] = 999
					row = layout.row()
					#n_op_set2 = n_op_start.settings.add()
					#n_op_set2.name = "hier["+ng_ui+"]"
					#n_op_set2.value = ng_hier
					WPL_G_NODESGM.rowstr[row] = ng_hier
					row.context_pointer_set("hier", row)
					row.menu("WPL_MT_NodeGroupsGM", text = item["hier"]+"...")

def drawNodeGroupsRootMenuGM(self, context):
	if context.space_data.type != 'NODE_EDITOR':
		return
	tree_type = context.space_data.tree_type
	if not ((tree_type in "ShaderNodeTree") or (tree_type in "CompositorNodeTree")):
		#print("tree_type",tree_type)
		return

	layout = self.layout
	layout.separator()
	#layout.label(text = "tt:" + tree_type)
	layout.operator_context = 'INVOKE_REGION_WIN'
	layout.menu(WPL_MT_NodeGroupsGM.bl_idname)

# ==========================================
# ==========================================

classes = (
	WPL_MT_NodeGroupsGM,
)

def register():
	for cls in classes:
		bpy.utils.register_class(cls)
	try:
		ngstore = bpy.types.WindowManager.ngstore
	except:
		# print("Adding NodeGroups submenu...")
		bpy.types.NODE_MT_add.append(drawNodeGroupsRootMenuGM)
		bpy.types.WindowManager.ngstore = WPL_G_NODESGM.ngstore

def unregister():
	for cls in reversed(classes):
		bpy.utils.unregister_class(cls)
	try:
		ngstore = bpy.types.WindowManager.ngstore
		del bpy.types.WindowManager.ngstore
		bpy.types.NODE_MT_add.remove(drawNodeGroupsRootMenuGM)
	except:
		pass

if __name__ == "__main__":
	register()