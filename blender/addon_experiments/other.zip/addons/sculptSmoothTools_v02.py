import bpy
import bmesh
import math
import copy
import mathutils
import random
from mathutils import Vector, Matrix
from bpy_extras import view3d_utils
from bpy.props import (StringProperty,
						BoolProperty,
						IntProperty,
						FloatProperty,
						FloatVectorProperty,
						EnumProperty,
						PointerProperty,
						)
from bpy.types import (Panel,
						Operator,
						AddonPreferences,
						PropertyGroup,
						)

bl_info = {
	"name": "WPL Smooth Deforming",
	"author": "IPv6",
	"version": (1, 0, 0),
	"blender": (2, 7, 9),
	"location": "View3D > T-panel > WPL",
	"description" : "",
	"warning"	 : "",
	"wiki_url"	: "",
	"tracker_url" : "",
	"category"	: ""
}

kRaycastEpsilon = 0.01
kWPLShrinkWrapMod = "WPL_PinnedVerts"
kWPLMeshDeformMod = "WPL_Meshdefrm"
kWPLBonesDefPostfix = "_wpldeform"
kWPLRefitStoreKey = "kWPLRefitStoreKey"

kWPLSmoothHolderUVMap1 = "_tmpPosHolder1"
kWPLSmoothHolderUVMap2 = "_tmpPosHolder2"
kWPLSmoothHolderUVMap3 = "_tmpPosHolder3"
class WPL_G:
	store = {}

######################### ######################### #########################
######################### ######################### #########################
def force_visible_object(obj):
	if obj:
		if obj.hide == True:
			obj.hide = False
		for n in range(len(obj.layers)):
			obj.layers[n] = False
		current_layer_index = bpy.context.scene.active_layer
		obj.layers[current_layer_index] = True
def unselect_all():
	for obj in bpy.data.objects:
		obj.select = False
def select_and_change_mode(obj,obj_mode,hidden=False):
	unselect_all()
	if obj:
		obj.select = True
		bpy.context.scene.objects.active = obj
		force_visible_object(obj)
		try:
			m=bpy.context.mode
			if bpy.context.mode!='OBJECT':
				bpy.ops.object.mode_set(mode='OBJECT')
			bpy.context.scene.update()
			bpy.ops.object.mode_set(mode=obj_mode)
			#print("Mode switched to ", obj_mode)
		except:
			pass
		obj.hide = hidden
	return m

def get_selected_vertsIdx(active_mesh):
	bpy.ops.object.mode_set(mode='OBJECT')
	selectedVertsIdx = [e.index for e in active_mesh.vertices if e.select]
	return selectedVertsIdx
def get_selected_edgesIdx(active_mesh):
	bpy.ops.object.mode_set(mode='OBJECT')
	selectedEdgesIdx = [e.index for e in active_mesh.edges if e.select]
	return selectedEdgesIdx
def get_selected_vertsIdxWeighted(active_mesh,loops):
	weights = {}
	selectedVertsIdx = get_selected_vertsIdx(active_mesh)
	for vIdx in selectedVertsIdx:
		weights[vIdx] = 1.0
	if loops > 0:
		for i in range(loops):
			bpy.ops.object.mode_set(mode='EDIT')
			bpy.ops.mesh.select_less()
			bpy.ops.object.mode_set(mode='OBJECT')
			selectedVertsIdx2 = [e.index for e in active_mesh.vertices if e.select]
			for vIdx in selectedVertsIdx2:
				weights[vIdx] = weights[vIdx]+1.0
		for vIdx in selectedVertsIdx:
			weights[vIdx] = float(weights[vIdx])/float(loops+1.0)
	return (selectedVertsIdx,weights)

def fuzzySceneRayCast_v02(vFrom, vDir, fuzzyVal, fuzzyQual, objs2ignore):
	gResult = mathutils.Vector((0,0,0))
	gResultNormal = mathutils.Vector((0,0,0))
	gCount = 0.0;
	vDirs = [vDir.normalized()]
	if fuzzyVal > 0.0:
		perpBase = mathutils.Vector((0,0,1))
		if(math.fabs(vDir.dot(perpBase)) > 0.9):
			perpBase = mathutils.Vector((0,1,0))
		perp1 = vDir.cross(perpBase)
		perp2 = vDir.cross(perp1)
		vDirs = [vDir.normalized()]
		for i in range(0,fuzzyQual):
			delim = float(i+1)/float(fuzzyQual)
			slice = [(vDir+delim*perp1*fuzzyVal).normalized(), (vDir-delim*perp1*fuzzyVal).normalized(), (vDir+delim*perp2*fuzzyVal).normalized(), (vDir-delim*perp2*fuzzyVal).normalized()]
			vDirs.extend(slice)

	for shootDir in vDirs:
		(result, loc_g, normal, index, object, matrix) = bpy.context.scene.ray_cast(vFrom+vDir*kRaycastEpsilon, shootDir)
		#print("fuzzySceneRayCast", vFrom, shootDir, result, loc_g)
		if result and (objs2ignore is None or object.name not in objs2ignore):
			gCount = gCount+1.0
			gResult = gResult+loc_g
			gResultNormal = gResultNormal+normal

	if gCount>0:
		return (gResult/gCount,gResultNormal/gCount)
	return (None, None)

def addConnectedBmVerts_v01(v, verts_list, selverts):
	v.tag = True
	if (selverts is not None) and (v.index not in selverts):
		return
	if v not in verts_list:
		verts_list.append(v)
	for edge in v.link_edges:
		ov = edge.other_vert(v)
		if (ov is None) or ov.tag:
			continue
		addConnectedBmVerts_v01(ov, verts_list, selverts)
	
def getBmEdgesAsStrands_v01(bm, vertsIdx, edgesIdx, opt_flowDirP, opt_edgeStep):
	# looking for bounding verts
	bndVerts = []
	opt_flowDir = Vector(opt_flowDirP)
	opt_flowDir = opt_flowDir.normalized()
	for vIdx in vertsIdx:
		v = bm.verts[vIdx]
		edgeDirs = []
		edgeLens = 0
		edgeLensC = 0
		for e in v.link_edges:
			if e.index in edgesIdx:
				flowfir = (e.other_vert(v).co-v.co).normalized()
				flowdot = flowfir.dot(opt_flowDir)
				flowang = math.acos(flowdot)
				edgeDirs.append(flowang)
			else:
				edgeLens = edgeLens+e.calc_length()
				edgeLensC = edgeLensC+1
		if len(edgeDirs) == 1:
			bndVerts.append((vIdx, edgeDirs[0],edgeLens/(edgeLensC+0.001)))
	if len(bndVerts)<2 or len(bndVerts)%2 == 1:
		return (None, None, None)
	bndVerts.sort(key=lambda ia: ia[1], reverse=False)
	strands_points = []
	strands_radius = []
	strands_vidx = []
	checked_verts = []
	#print("bndVerts", bndVerts)
	for ia in bndVerts:
		vIdx = ia[0]
		points_co = None
		points_idx = None
		canContinue = True
		while canContinue == True:
			#print("Checking vIdx", vIdx)
			if vIdx in checked_verts:
				canContinue = False
				continue
			checked_verts.append(vIdx)
			if points_co is None:
				points_co = []
				points_idx = []
				strands_points.append(points_co)
				strands_vidx.append(points_idx)
				strands_radius.append(ia[2])
			v = bm.verts[vIdx]
			points_idx.append([v.index])
			points_co.append(v.co)
			canContinue = False
			for e in v.link_edges:
				if e.index in edgesIdx:
					vIdx = e.other_vert(v).index
					if vIdx not in checked_verts:
						canContinue = True
						break
	#print("strands_points", strands_points, strands_vidx)
	if(opt_edgeStep > 1):
		# repacking
		strands_points2 = []
		strands_vidx2 = []
		for i,points_co in enumerate(strands_points):
			points_co2 = []
			points_idx2 = []
			strands_points2.append(points_co2)
			strands_vidx2.append(points_idx2)
			lastIdxList = None
			for j in range(len(points_co)):
				if j == 0 or (j%opt_edgeStep) == 0 or j == len(points_co)-1:
					if j < len(points_co)-1:
						lastIdxList = strands_vidx[i][j]
					else:
						lastIdxList.append(strands_vidx[i][j][0])
					points_co2.append(points_co[j])
					points_idx2.append(lastIdxList)
				else:
					lastIdxList.append(strands_vidx[i][j][0])
		#print("strands_points2", strands_points2, strands_vidx2)
		strands_points = strands_points2
		strands_vidx = strands_vidx2
	return (strands_points, strands_radius, strands_vidx)

def strandsPoints2globalCurveset(active_object, bm, strands_points, strands_vidx):
	matrix_world = active_object.matrix_world
	matrix_world_inv = active_object.matrix_world.inverted()
	matrix_world_norm = matrix_world_inv.transposed().to_3x3()
	g_curveset = []
	for i, strand_curve in enumerate(strands_points):
		if len(strand_curve) < 2: # we can have single vertices in list too
			continue
		g_curve = []
		for j, co in enumerate(strand_curve):
			vIdx = strands_vidx[i][j][0]
			v = bm.verts[vIdx]
			v_co_g = matrix_world*co
			flow_g = Vector((0,0,0))
			if j<len(strand_curve)-1:
				flow_g = matrix_world*strand_curve[j+1] - v_co_g
			else:
				#flow_g = v_co_g-matrix_world*strand_curve[j-1]
				break #last one is SKIPPED
			g_curve.append((v_co_g, matrix_world_norm*v.normal, flow_g))
		g_curveset.append(g_curve)
	return g_curveset
	
def customAxisMatrix(v_origin, a, b):
	#https://blender.stackexchange.com/questions/30808/how-do-i-construct-a-transformation-matrix-from-3-vertices
	#def make_matrix(v_origin, v2, v3):
	#a = v2-v_origin
	#b = v3-v_origin
	c = a.cross(b)
	if c.magnitude>0:
		c = c.normalized()
	else:
		raise BaseException("A B C are colinear")
	b2 = c.cross(a).normalized()
	a2 = a.normalized()
	m = Matrix([a2, b2, c]).transposed()
	s = a.magnitude
	m = Matrix.Translation(v_origin) * Matrix.Scale(s,4) * m.to_4x4()
	return m
#def getVertsMapByDistance(bm, initialVertsIdx, maxDist):
#	near_verts = {}
#	for v in bm.verts:
#		if v.index not in initialVertsIdx and v.hide == 0:
#			for ini_vIdx in initialVertsIdx:
#				ini_v = bm.verts[ini_vIdx]
#				v_dist = (ini_v.co-v.co).length
#				if v_dist<maxDist:
#					if v.index in near_verts:
#						near_verts[v.index] = min(near_verts[v.index], v_dist)
#					else:
#						near_verts[v.index] = v_dist
#	return near_verts

def getVertsPropagationStages(bm, smoothingLoops, initialVertsIdx):
	propagation_stages = []
	preWalkedVerts = []
	checked_verts = copy.copy(initialVertsIdx)
	for stage in range(1,smoothingLoops+1):
		stage_verts = {}
		checked_verts_cc = copy.copy(checked_verts)
		for v_idx in checked_verts_cc:
			v = bm.verts[v_idx]
			preWalkedVerts.append(v_idx)
			#if (v_idx not in verts_shifts) and (v_idx in verts_map):
			#	verts_shifts[v_idx] = mathutils.Vector(v.co - verts_map[v_idx])
			for edg in v.link_edges:
				v2 = edg.other_vert(v)
				if v2.hide == 0 and v2.index not in checked_verts_cc:
					#print("found new vert",v2.index,"at stage",stage)
					#v2.select = True
					if v2.index not in checked_verts:
						checked_verts.append(v2.index)
					if(v2.index not in stage_verts):
						stage_verts[v2.index] = []
					if v_idx not in stage_verts[v2.index]:
						stage_verts[v2.index].append(v_idx)
		if len(stage_verts) == 0:
			break
		propagation_stages.append(stage_verts)
	return (propagation_stages, preWalkedVerts)

def updateVertWeight(vg, vIdx, newval, compareOp):
	vg_wmod = 'REPLACE'
	vg_newval = newval
	vg_oldval = 0
	try:
		vg_oldval = vg.weight(idx)
		if compareOp is not None:
			vg_newval = compareOp(vg_oldval,vg_newval)
	except Exception as e:
		vg_wmod = 'ADD'
		vg_newval = newval
	vg.add([vIdx], vg_newval, vg_wmod)
	return vg_oldval

h_cnt = 1
h_pool = "QWERTYUIOPLKJHGFDSAZXCVBNM"
def random_string(length):
	global h_pool
	return ''.join(random.choice(h_pool) for i in range(length))

def getUniqueHash():
	global h_cnt
	h_cnt = h_cnt+1
	return "_"+random_string(2)+str(h_cnt)

def makeObjectWireNoRender(c_object):
	c_object.draw_type = 'WIRE'
	c_object.hide_render = True
	c_object.cycles_visibility.camera = False
	c_object.cycles_visibility.diffuse = False
	c_object.cycles_visibility.glossy = False
	c_object.cycles_visibility.transmission = False
	c_object.cycles_visibility.scatter = False
	c_object.cycles_visibility.shadow = False
######################### ######################### #########################
######################### ######################### #########################
class WPLsmthdef_snap(bpy.types.Operator):
	bl_idname = "mesh.wplsmthdef_snap"
	bl_label = "Remember mesh state"
	bl_options = {'REGISTER', 'UNDO'}

	@classmethod
	def poll(self, context):
		# Check if we have a mesh object active and are in vertex paint mode
		p = context.object and context.object.data and (isinstance(context.scene.objects.active, bpy.types.Object) and isinstance(context.scene.objects.active.data, bpy.types.Mesh))
		return p

	def execute(self, context):
		active_obj = context.scene.objects.active
		active_mesh = active_obj.data
		select_and_change_mode(active_obj, 'EDIT')
		uv_layer_holdr1 = active_mesh.uv_textures.get(kWPLSmoothHolderUVMap1)
		if uv_layer_holdr1 is None:
			active_mesh.uv_textures.new(kWPLSmoothHolderUVMap1)
		uv_layer_holdr2 = active_mesh.uv_textures.get(kWPLSmoothHolderUVMap2)
		if uv_layer_holdr2 is None:
			active_mesh.uv_textures.new(kWPLSmoothHolderUVMap2)
		uv_layer_holdr3 = active_mesh.uv_textures.get(kWPLSmoothHolderUVMap3)
		if uv_layer_holdr3 is None:
			active_mesh.uv_textures.new(kWPLSmoothHolderUVMap3)
		bm = bmesh.from_edit_mesh(active_mesh)
		bm.verts.ensure_lookup_table()
		bm.faces.ensure_lookup_table()
		bm.verts.index_update()
		uv_layer_holdr1 = bm.loops.layers.uv.get(kWPLSmoothHolderUVMap1)
		uv_layer_holdr2 = bm.loops.layers.uv.get(kWPLSmoothHolderUVMap2)
		uv_layer_holdr3 = bm.loops.layers.uv.get(kWPLSmoothHolderUVMap3)
		for face in bm.faces:
			for vert, loop in zip(face.verts, face.loops):
				loop[uv_layer_holdr1].uv = (vert.co[0],vert.co[1])
				loop[uv_layer_holdr2].uv = (vert.co[2],vert.normal[0])
				loop[uv_layer_holdr3].uv = (vert.normal[1],vert.normal[2])
		self.report({'INFO'}, "Mesh state remembered")
		return {'FINISHED'}


class WPLsmthdef_restore(bpy.types.Operator):
	bl_idname = "mesh.wplsmthdef_restore"
	bl_label = "Restore at bounds"
	bl_options = {'REGISTER', 'UNDO'}

	opt_smoothingLoops = IntProperty(
			name="Smoothing Loops",
			description="Loops",
			min=0, max=1000,
			default=2,
	)
	opt_sloppiness = FloatProperty(
			name="Sloppiness",
			description="Sloppiness",
			min=-10.0, max=10.0,
			default=1.0,
	)
	opt_influence = FloatProperty(
			name="Influence",
			description="Influence",
			min=-10.0, max=10.0,
			default=1.0,
	)
	opt_inverse = BoolProperty(
		name="Inverse influence",
		description="Inverse influence",
		default=True
	)

	@classmethod
	def poll(self, context):
		# Check if we have a mesh object active and are in vertex paint mode
		p = context.object and context.object.data and (isinstance(context.scene.objects.active, bpy.types.Object) and isinstance(context.scene.objects.active.data, bpy.types.Mesh))
		return p

	def execute(self, context):
		active_obj = context.scene.objects.active
		active_mesh = active_obj.data
		if (active_mesh.uv_textures.get(kWPLSmoothHolderUVMap1) is None) or (active_mesh.uv_textures.get(kWPLSmoothHolderUVMap2) is None):
			self.report({'ERROR'}, "Object not snapped, snap mesh first")
			return {'CANCELLED'}
		(selverts,weight) = get_selected_vertsIdxWeighted(active_mesh,self.opt_smoothingLoops)
		select_and_change_mode(active_obj, 'EDIT')
		if len(selverts) == 0:
			self.report({'ERROR'}, "No moved/selected verts found")
			return {'CANCELLED'}
		bm = bmesh.from_edit_mesh(active_mesh)
		bm.verts.ensure_lookup_table()
		bm.faces.ensure_lookup_table()
		bm.verts.index_update()
		verts_map = {}
		vertsnrm_map = {}
		uv_layer_holdr1 = bm.loops.layers.uv.get(kWPLSmoothHolderUVMap1)
		uv_layer_holdr2 = bm.loops.layers.uv.get(kWPLSmoothHolderUVMap2)
		uv_layer_holdr3 = bm.loops.layers.uv.get(kWPLSmoothHolderUVMap3)
		for face in bm.faces:
			for vert, loop in zip(face.verts, face.loops):
				verts_map[vert.index] = mathutils.Vector((loop[uv_layer_holdr1].uv[0], loop[uv_layer_holdr1].uv[1], loop[uv_layer_holdr2].uv[0]))
				vertsnrm_map[vert.index] = mathutils.Vector((loop[uv_layer_holdr2].uv[1], loop[uv_layer_holdr3].uv[0], loop[uv_layer_holdr3].uv[1]))
		for vIdx in selverts:
			inf = pow(weight[vIdx],self.opt_sloppiness)*self.opt_influence
			s_v = bm.verts[vIdx]
			if self.opt_inverse == True:
				s_v.co = verts_map[vIdx].lerp(s_v.co,inf)
			else:
				s_v.co = s_v.co.lerp(verts_map[vIdx],inf)
		bm.normal_update()
		bmesh.update_edit_mesh(active_mesh, True)
		return {'FINISHED'}
		
class WPLsmthdef_apply(bpy.types.Operator):
	bl_idname = "mesh.wplsmthdef_apply"
	bl_label = "Smooth around selection"
	bl_options = {'REGISTER', 'UNDO'}

	SmoothingLoops = IntProperty(
			name="Smoothing Loops",
			description="Loops",
			min=0, max=1000,
			default=3,
	)
	Sloppiness = FloatProperty(
			name="Sloppiness",
			description="Sloppiness",
			min=0.0, max=100.0,
			default=1.0,
	)
	NormalFac = FloatProperty(
			name="Align to Normal",
			description="Align to Normal",
			min=0.0, max=1.0,
			default=0.0,
	)
	CollisionDist = FloatProperty(
			name="Collision Distance",
			description="Collision Distance",
			min=0.0, max=100.0,
			default=0.0,
	)
	CollisionFuzz = FloatProperty(
			name="Collision Fuzziness",
			description="Collision Fuzziness",
			min=-100.0, max=100.0,
			default=0.1,
	)

	@classmethod
	def poll(self, context):
		# Check if we have a mesh object active and are in vertex paint mode
		p = context.object and context.object.data and (isinstance(context.scene.objects.active, bpy.types.Object) and isinstance(context.scene.objects.active.data, bpy.types.Mesh))
		return p

	def execute(self, context):
		active_obj = context.scene.objects.active
		active_mesh = active_obj.data
		#if WPLSMTHDEF_G.mesh_name != active_obj.name:
		if (active_mesh.uv_textures.get(kWPLSmoothHolderUVMap1) is None) or (active_mesh.uv_textures.get(kWPLSmoothHolderUVMap2) is None):
			self.report({'ERROR'}, "Object not snapped, snap mesh first")
			return {'CANCELLED'}
		selverts = get_selected_vertsIdx(active_mesh)
		select_and_change_mode(active_obj, 'EDIT')

		matrix_world = active_obj.matrix_world
		matrix_world_inv = active_obj.matrix_world.inverted()
		matrix_world_nrml = matrix_world_inv.transposed().to_3x3()
		bm = bmesh.from_edit_mesh(active_mesh)
		bm.verts.ensure_lookup_table()
		bm.faces.ensure_lookup_table()
		bm.verts.index_update()
		verts_map = {}
		vertsnrm_map = {}
		uv_layer_holdr1 = bm.loops.layers.uv.get(kWPLSmoothHolderUVMap1)
		uv_layer_holdr2 = bm.loops.layers.uv.get(kWPLSmoothHolderUVMap2)
		uv_layer_holdr3 = bm.loops.layers.uv.get(kWPLSmoothHolderUVMap3)
		for face in bm.faces:
			for vert, loop in zip(face.verts, face.loops):
				verts_map[vert.index] = mathutils.Vector((loop[uv_layer_holdr1].uv[0], loop[uv_layer_holdr1].uv[1], loop[uv_layer_holdr2].uv[0]))
				vertsnrm_map[vert.index] = mathutils.Vector((loop[uv_layer_holdr2].uv[1], loop[uv_layer_holdr3].uv[0], loop[uv_layer_holdr3].uv[1]))
		if len(selverts) == 0:
			selverts = []
			for v in bm.verts:
				if verts_map[v.index] is not None:
					if (v.co-verts_map[v.index]).length > kRaycastEpsilon:
						# vert moved
						selverts.append(v.index)
		if len(selverts) == 0:
			self.report({'ERROR'}, "No moved/selected verts found")
			return {'CANCELLED'}
		collFuzziness = self.CollisionFuzz
		collIgnore = [active_obj.name]
		if collFuzziness<0:
			collFuzziness = -1*collfuzz
			collIgnore = None

		verts_shifts = {}
		(propagation_stages, preWalkedVerts) = getVertsPropagationStages(bm, self.SmoothingLoops, selverts)
		for v_idx in preWalkedVerts:
			if (v_idx not in verts_shifts) and (v_idx in verts_map):
				v = bm.verts[v_idx]
				verts_shifts[v_idx] = mathutils.Vector(v.co - verts_map[v_idx])
		#print("vert stages",propagation_stages)
		#print("verts_shifts",verts_shifts)
		new_positions = {}
		stage_cnt = 1.0
		for stage_verts in propagation_stages:
			stage_weight = pow(1.0-stage_cnt/len(propagation_stages),self.Sloppiness)
			for s_idx in stage_verts:
				avg_shift = mathutils.Vector((0,0,0))
				avg_count = 0.0
				for p_idx in stage_verts[s_idx]:
					avg_shift = avg_shift+verts_shifts[p_idx]
					avg_count = avg_count+1.0
				if avg_count>0:
					s_shift = mathutils.Vector(avg_shift)/avg_count
					verts_shifts[s_idx] = s_shift
					s_v = bm.verts[s_idx]
					s_v_n = vertsnrm_map[s_idx]
					#print("shifting vert",s_idx, s_v.index, s_v.co,verts_map[s_idx])
					sn_shift = s_v_n*s_shift.length*math.copysign(1.0,s_v.normal.dot(s_shift))
					total_shift = self.NormalFac*sn_shift + (1.0-self.NormalFac)*s_shift
					s_v_co2 = s_v.co+total_shift*stage_weight
					if(self.CollisionDist > 0.0):
						s_dir_g = (matrix_world_nrml*s_shift.normalized())
						s_v_g = matrix_world*s_v.co
						min_okdst = (s_shift*stage_weight).length
						loc_g, normal = fuzzySceneRayCast_v02(s_v_g, s_dir_g, collFuzziness, 3, collIgnore)
						if loc_g is not None:
							loc_l = matrix_world_inv * loc_g
							hit_dst = (loc_l-s_v.co).length-self.CollisionDist
							if hit_dst < min_okdst:
								if hit_dst > 0:
									#s_v_co2 = s_v.co+hit_dst*(loc_l-s_v.co).normalized()
									s_v_co2 = s_v.co+hit_dst*s_shift.normalized()
								else:
									s_v_co2 = s_v.co
					#s_v.co = s_v_co2
					new_positions[s_idx] = s_v_co2
			stage_cnt = stage_cnt+1.0
		# updating positions as post-step
		for s_idx in new_positions:
			s_v = bm.verts[s_idx]
			s_v.co = new_positions[s_idx]
		bm.normal_update()
		bmesh.update_edit_mesh(active_mesh, True)
		return {'FINISHED'}

class WPLedges2bones(bpy.types.Operator):
	bl_idname = "mesh.wpledges2bones"
	bl_label = "Edges to Bones"
	bl_options = {'REGISTER', 'UNDO'}

	# opt_genType = bpy.props.EnumProperty(
		# name="Generation Type", default="ALONG",
		# items=(("ALONG", "Along edges", ""), ("ACROSS", "Across edges", ""))
	# )
	opt_flowDir = FloatVectorProperty(
		name	 = "Preferred direction",
		size	 = 3,
		min=-1.0, max=1.0,
		default	 = (0.0,0.0,-1.0)
	)
	opt_edgeStep = IntProperty(
		name	 = "Edges per bone",
		min=1, max=100,
		default	 = 2
	)
	opt_smoothLoops = IntProperty(
		name	 = "Bone affection: loops",
		min=0, max=100,
		default	 = 5
	)
	opt_loopsSloppiness = FloatProperty(
		name="Affection sloppiness",
		min=0.0, max=100.0,
		default=1.0,
	)
	opt_parentIntoChain = BoolProperty(
		name	 = "Parent int chain",
		default=True
	)
	opt_bsmHidden = BoolProperty(
		name	 = "Hide basement",
		default=True
	)
	opt_bsmAsParent = BoolProperty(
		name	 = "Parent to basement",
		default=False
	)

	@classmethod
	def poll(self, context):
		# Check if we have a mesh object active and are in vertex paint mode
		p = context.object and context.object.data and (isinstance(context.scene.objects.active, bpy.types.Object) and isinstance(context.scene.objects.active.data, bpy.types.Mesh))
		return p

	def execute(self, context):
		active_obj = context.scene.objects.active
		active_mesh = active_obj.data
		select_and_change_mode(active_obj, 'EDIT')

		vertsIdx = get_selected_vertsIdx(active_mesh)
		edgesIdx = get_selected_edgesIdx(active_mesh)
		if len(edgesIdx)<1:
			self.report({'ERROR'}, "No selected edges found, select some edges first")
			return {'CANCELLED'}
		bpy.ops.object.mode_set( mode = 'EDIT' )
		#bpy.ops.mesh.select_mode(type="FACE")
		bm = bmesh.from_edit_mesh(active_mesh)
		bm.verts.ensure_lookup_table()
		bm.faces.ensure_lookup_table()
		bm.verts.index_update()
		(strands_points,strands_radius,strands_vidx) = getBmEdgesAsStrands_v01(bm, vertsIdx, edgesIdx, self.opt_flowDir, self.opt_edgeStep)
		if strands_points is None:
			self.report({'ERROR'}, "Looped edges found, can`t work on looped edges")
			return {'CANCELLED'}
		# if self.opt_genType == "ACROSS":
			# #rebuilding points. vIdx for pre-last point should contain last line to!!!
			# strands_points_single=[]
			# strands_vidx_single=[]
			# for i, strand_curve in enumerate(strands_points):
				# mid_co = Vector((0,0,0))
				# mid_cnt = 0
				# mid_vidx = []
				# if i<len(strands_points)-1:
					# mid_strands_vidx = []
				# for j, co in enumerate(strand_curve):
					# mid_co = mid_co+co
					# mid_cnt = mid_cnt+1
					# mid_strands_vidx.extend(strands_vidx[i][j])
				# mid_co = mid_co/mid_cnt
				# strands_points_single.append(mid_co)
				# strands_vidx_single.append(mid_strands_vidx)
			# strands_points = [strands_points_single]
			# strands_vidx = [strands_vidx_single]

		# Create armature and object
		select_and_change_mode(active_obj, 'OBJECT')
		scn = context.scene
		armatOBname = active_obj.name+kWPLBonesDefPostfix
		if bpy.data.objects.get(armatOBname) is not None:
			bpy.data.objects.remove(bpy.data.objects[armatOBname], True)
		prevArmatModifier = active_obj.modifiers.get(armatOBname)
		if prevArmatModifier is not None:
			active_obj.modifiers.remove(prevArmatModifier)
		armatAR = bpy.data.armatures.new(armatOBname+'_arm')
		armatOB = bpy.data.objects.new(armatOBname, armatAR)
		armatOB.matrix_world = active_obj.matrix_world
		armatOB.show_x_ray = True
		armatAR.draw_type = 'STICK' #OCTAHEDRAL
		#bpy.ops.object.mode_set( mode = 'OBJECT' )
		scn.objects.link(armatOB)
		active_obj.select = False
		#armatOB.select = True
		#bpy.context.scene.objects.active = armatOB
		select_and_change_mode(armatOB, 'EDIT')
		# Create bones
		parentBone = None
		for i, strand_curve in enumerate(strands_points):
			# root bone
			bname_root = armatOBname+"_c"+str(i+1)+"_basement"
			bone_root = armatAR.edit_bones.new(bname_root)
			bone_root.head = strand_curve[len(strand_curve)-1]
			bone_root.tail = strand_curve[0]
			if self.opt_bsmAsParent:
				parentBone = bone_root
			else:
				parentBone = None
			for j, co in enumerate(strand_curve):
				if j<len(strand_curve)-1:
					bname = armatOBname+"_c"+str(i+1)+"_b"+str(j+1)
					bone = armatAR.edit_bones.new(bname)
					if parentBone is not None:
						bone.parent = parentBone
						bone.head = parentBone.tail
						bone.use_connect = True
						bone.tail = strand_curve[j+1]
					else:
						bone.head = co
						bone.tail = strand_curve[j+1]
					if self.opt_parentIntoChain:
						parentBone = bone
					#print("Added bone", bone)
		bpy.ops.object.mode_set(mode='POSE')
		for i, strand_curve in enumerate(strands_points):
			bname_root = armatOBname+"_c"+str(i+1)+"_basement"
			bone_root = armatOB.pose.bones[bname_root]
			bone_root.rotation_mode = "ZYX"
			for j, co in enumerate(strand_curve):
				if j<len(strand_curve)-1:
					bname = armatOBname+"_c"+str(i+1)+"_b"+str(j+1)
					bone = armatOB.pose.bones[bname]
					bone.rotation_mode = "ZYX"
		if self.opt_bsmHidden:
			for i, strand_curve in enumerate(strands_points):
				bname_root = armatOBname+"_c"+str(i+1)+"_basement"
				#bone_root = armatOB.pose.bones[bname_root]
				bone_root = armatAR.bones[bname_root]
				bone_root.hide = 1
		select_and_change_mode(active_obj, 'OBJECT')
		bm2 = bmesh.new()
		bm2.from_mesh(active_mesh)
		bm2.verts.ensure_lookup_table()
		bm2.faces.ensure_lookup_table()
		bm2.verts.index_update()
		# making weights
		for i, strand_curve in enumerate(strands_points):
			bname_root = armatOBname+"_c"+str(i+1)+"_basement"
			vg_root = active_obj.vertex_groups.get(bname_root)
			if vg_root is not None:
				active_obj.vertex_groups.remove(vg_root)
			vg_root = active_obj.vertex_groups.new(bname_root)
			affectedVerts = {}
			for j, co in enumerate(strand_curve):
				if j<len(strand_curve)-1:
					bname = armatOBname+"_c"+str(i+1)+"_b"+str(j+1)
					vg = active_obj.vertex_groups.get(bname)
					if vg is not None:
						active_obj.vertex_groups.remove(vg)
					vg = active_obj.vertex_groups.new(bname)
					if self.opt_smoothLoops>0:
						(propagation_stages, preWalkedVerts) = getVertsPropagationStages(bm2, self.opt_smoothLoops, strands_vidx[i][j])
						propagation_stages.insert(0,strands_vidx[i][j])
					else:
						propagation_stages = [strands_vidx[i][j]]
					for k,stageIdxs in enumerate(propagation_stages):
						newval = 1.0-k/len(propagation_stages)
						newval = pow(newval,self.opt_loopsSloppiness)
						#print("Setting vertext group", bname,"weight",newval,"k/l",k,len(propagation_stages))
						for idx in stageIdxs:
							if k>0 and idx in vertsIdx:
								# root verts should not be smoothed
								continue
							updateVertWeight(vg, idx, newval, lambda wn,wo: wn+wo)
							if idx not in affectedVerts:
								affectedVerts[idx] = (newval,1)
							else:
								affectedVerts[idx] = (affectedVerts[idx][0]+newval,affectedVerts[idx][1]+1)
					#dist_verts_map = getVertsMapByDistance(bm2,strands_vidx[i][j],self.opt_smoothDist)
					#for idx in dist_verts_map:
					#	if idx in vertsIdx:
					#		# root verts should not be smoothed
					#		continue
					#	newval = 1.0-dist_verts_map[idx]/self.opt_smoothDist
					#	newval = pow(newval,self.opt_loopsSloppiness)
					#	newval = updateVertWeight(vg, idx, newval, lambda wn,wo: max(wn,wo))
					#	if idx not in affectedVerts:
					#		affectedVerts[idx] = (newval,1)
					#	else:
					#		affectedVerts[idx] = (affectedVerts[idx][0]+newval,affectedVerts[idx][1]+1)
			for idx in affectedVerts:
				updateVertWeight(vg_root, idx, 1.0-affectedVerts[idx][0]/affectedVerts[idx][1], None)
		bm2.free()
		mod = active_obj.modifiers.new(armatOBname, 'ARMATURE')
		mod.object = armatOB
		mod.use_bone_envelopes = False
		mod.use_vertex_groups = True
		return {'FINISHED'}

class WPLshsel_snap(bpy.types.Operator):
	bl_idname = "mesh.wplshsel_snap"
	bl_label = "Shrinkwrap selected to nearest"
	bl_options = {'REGISTER', 'UNDO'}

	opt_offset = bpy.props.FloatProperty(
		name		= "Offset",
		default	 	= 0.0
	)

	@classmethod
	def poll(self, context):
		# Check if we have a mesh object active and are in vertex paint mode
		p = context.object and context.object.data and (isinstance(context.scene.objects.active, bpy.types.Object) and isinstance(context.scene.objects.active.data, bpy.types.Mesh))
		return p

	def execute(self, context):
		active_obj = context.scene.objects.active
		active_mesh = active_obj.data
		vertsIdx = get_selected_vertsIdx(active_mesh)
		if len(vertsIdx) == 0:
			vertsIdx = [e.index for e in active_mesh.vertices]
		matrix_world = active_obj.matrix_world
		matrix_world_inv = active_obj.matrix_world.inverted()
		matrix_world_nrml = matrix_world_inv.transposed().to_3x3()
		nearObject = None
		nearObjectDist = 99999
		histVertlist = vertsIdx
		if(len(histVertlist) > 50):
			bm_tmp = bmesh.new()
			bm_tmp.from_mesh(active_mesh)
			bm_tmp.verts.index_update()
			histVertlist = [elem.index for elem in bm_tmp.select_history if isinstance(elem, bmesh.types.BMVert)]
			bm_tmp.free()
			if len(histVertlist) == 0:
				histVertlist = vertsIdx
			histVertlist = histVertlist[:50]
		for vIdx in histVertlist:
			s_v = active_mesh.vertices[vIdx]
			vFrom = matrix_world*s_v.co
			vDir = (matrix_world_nrml*s_v.normal)
			(result, loc_g, normal, index, obj, matrix) = bpy.context.scene.ray_cast(vFrom+vDir*kRaycastEpsilon, vDir)
			if result and obj.name != active_obj.name:
				resultDist = (loc_g-vFrom).length
				if resultDist<nearObjectDist:
					nearObject = obj
					nearObjectDist = resultDist
			vDir = -1*vDir
			(result, loc_g, normal, index, obj, matrix) = bpy.context.scene.ray_cast(vFrom+vDir*kRaycastEpsilon, vDir)
			if result and obj.name != active_obj.name:
				resultDist = (loc_g-vFrom).length
				if resultDist<nearObjectDist:
					nearObject = obj
					nearObjectDist = resultDist
		if nearObject is None:
			self.report({'ERROR'}, "No convinient target found")
			return {'CANCELLED'}
		modname = kWPLShrinkWrapMod
		bpy.ops.object.modifier_remove(modifier=modname)
		modifiers = active_obj.modifiers
		shrinkwrap_modifier = modifiers.new(name = modname, type = 'SHRINKWRAP')
		shrinkwrap_modifier.offset = self.opt_offset
		shrinkwrap_modifier.target = nearObject
		shrinkwrap_modifier.use_keep_above_surface = True
		shrinkwrap_modifier.wrap_method = 'NEAREST_SURFACEPOINT'

		vg_root = active_obj.vertex_groups.get(modname)
		if vg_root is not None:
			active_obj.vertex_groups.remove(vg_root)
		vg_root = active_obj.vertex_groups.new(modname)
		for vIdx in vertsIdx:
			updateVertWeight(vg_root, vIdx, 1.0, None)
		shrinkwrap_modifier.vertex_group = vg_root.name
		select_and_change_mode(active_obj,"EDIT")
		return {'FINISHED'}

class WPLmdefr_bind(bpy.types.Operator):
	bl_idname = "mesh.wplmdefr_bind"
	bl_label = "Multi-bind mesh deform"
	bl_options = {'REGISTER', 'UNDO'}

	@classmethod
	def poll(self, context):
		# Check if we have a mesh object active and are in vertex paint mode
		p = context.object and context.object.data and (isinstance(context.scene.objects.active, bpy.types.Object))
		return p

	def execute(self, context):
		active_obj = context.scene.objects.active
		active_mesh = active_obj.data
		sel_all = [o.name for o in bpy.context.selected_objects]
		select_and_change_mode(active_obj,"OBJECT")
		if len(sel_all) == 0:
			self.report({'ERROR'}, "No objects selectedt")
			return {'CANCELLED'}
		smoothdeformOpts = context.scene.smoothdeformOpts
		cage_object = None
		try:
			cage_object = context.scene.objects[smoothdeformOpts.bind_targ]
		except:
			pass
		if cage_object is None or isinstance(cage_object.data, bpy.types.Mesh) == False:
			self.report({'ERROR'}, "No proper mesh deformer found, choose cage object first")
			return {'CANCELLED'}
		makeObjectWireNoRender(cage_object)
		modname = kWPLMeshDeformMod
		error = 0
		for i, sel_obj_name in enumerate(sel_all):
			if sel_obj_name == cage_object.name:
				continue
			sel_obj = context.scene.objects[sel_obj_name]
			prevModifier = sel_obj.modifiers.get(modname)
			if prevModifier is not None:
				sel_obj.modifiers.remove(prevModifier)
			print("Handling object "+str(i+1)+" of "+str(len(sel_all)))
			bpy.context.scene.objects.active = sel_obj
			if sel_obj.type == 'MESH' or sel_obj.type == 'CURVE':
				meshdef_modifier = sel_obj.modifiers.new(name = modname, type = 'MESH_DEFORM')
				meshdef_modifier.object = cage_object
				meshdef_modifier.precision = 5
				meshdef_modifier.use_dynamic_bind = True
				bpy.ops.object.meshdeform_bind(modifier=modname)
			else:
				print({'ERROR'}, "Failed to add modifier for type "+sel_obj.type)
				error = error+1
		self.report({'INFO'}, "Done: count="+str(len(sel_all))+" errors:"+str(error))
		return {'FINISHED'}

class WPLsdefr_bind(bpy.types.Operator):
	bl_idname = "mesh.wplsdefr_bind"
	bl_label = "Multi-bind surf deform"
	bl_options = {'REGISTER', 'UNDO'}

	@classmethod
	def poll(self, context):
		# Check if we have a mesh object active and are in vertex paint mode
		p = context.object and context.object.data and (isinstance(context.scene.objects.active, bpy.types.Object))
		return p

	def execute(self, context):
		active_obj = context.scene.objects.active
		active_mesh = active_obj.data
		sel_all = [o.name for o in bpy.context.selected_objects]
		select_and_change_mode(active_obj,"OBJECT")
		if len(sel_all) == 0:
			self.report({'ERROR'}, "No objects selected")
			return {'CANCELLED'}
		smoothdeformOpts = context.scene.smoothdeformOpts
		cage_object = None
		try:
			cage_object = context.scene.objects[smoothdeformOpts.bind_targ]
		except:
			pass
		if cage_object is None or isinstance(cage_object.data, bpy.types.Mesh) == False:
			self.report({'ERROR'}, "No proper surface found, choose surface object first")
			return {'CANCELLED'}
		makeObjectWireNoRender(cage_object)
		modname = kWPLMeshDeformMod
		error = 0
		for i, sel_obj_name in enumerate(sel_all):
			if sel_obj_name == cage_object.name:
				continue
			sel_obj = context.scene.objects[sel_obj_name]
			prevModifier = sel_obj.modifiers.get(modname)
			if prevModifier is not None:
				sel_obj.modifiers.remove(prevModifier)
			print("Handling object "+str(i+1)+" of "+str(len(sel_all)))
			bpy.context.scene.objects.active = sel_obj
			if sel_obj.type == 'MESH':
				surfdef_modifier = sel_obj.modifiers.new(name = modname, type = 'SURFACE_DEFORM')
				surfdef_modifier.target = cage_object
				#surfdef_modifier.falloff = 5
				bpy.ops.object.surfacedeform_bind(modifier=modname) #bpy.ops.object.
			else:
				print({'ERROR'}, "Failed to add modifier for type "+sel_obj.type)
				error = error+1
		self.report({'INFO'}, "Done: count="+str(len(sel_all))+" errors:"+str(error))
		return {'FINISHED'}
		
class WPLmodifs_apply(bpy.types.Operator):
	bl_idname = "mesh.wplmodifs_apply"
	bl_label = "Apply deform modifier"
	bl_options = {'REGISTER', 'UNDO'}

	@classmethod
	def poll(self, context):
		# Check if we have a mesh object active and are in vertex paint mode
		p = context.object and context.object.data and (isinstance(context.scene.objects.active, bpy.types.Object))
		return p

	def execute(self, context):
		active_obj = context.scene.objects.active
		active_mesh = active_obj.data
		sel_all = [o.name for o in bpy.context.selected_objects]
		select_and_change_mode(active_obj,"OBJECT")
		if len(sel_all) == 0:
			self.report({'ERROR'}, "No objects selectedt")
			return {'CANCELLED'}
		error = 0
		done = 0
		for i, sel_obj_name in enumerate(sel_all):
			sel_obj = context.scene.objects[sel_obj_name]
			print("Handling object "+str(i+1)+" of "+str(len(sel_all)))
			try:
				#bpy.context.scene.objects.active = sel_obj
				select_and_change_mode(sel_obj, 'OBJECT')
				modname = kWPLShrinkWrapMod
				if sel_obj.modifiers.get(modname) is not None:
					bpy.ops.object.modifier_apply(apply_as='DATA', modifier=modname)
					groups2del = []
					for grp in sel_obj.vertex_groups:
						if grp.name.find(modname) >= 0:
							groups2del.append(grp.name)
					for grp in groups2del:
						vg = sel_obj.vertex_groups.get(grp)
						sel_obj.vertex_groups.remove(vg)
					done = done+1
				modname = kWPLMeshDeformMod
				if sel_obj.modifiers.get(modname) is not None:
					bpy.ops.object.modifier_apply(apply_as='DATA', modifier=modname)
					done = done+1

				modname = sel_obj.name+kWPLBonesDefPostfix
				if bpy.data.objects.get(modname) is not None:
					bpy.ops.object.modifier_apply(apply_as='DATA', modifier=modname)
					groups2del = []
					for grp in sel_obj.vertex_groups:
						if grp.name.find(modname) >= 0:
							groups2del.append(grp.name)
					for grp in groups2del:
						vg = sel_obj.vertex_groups.get(grp)
						sel_obj.vertex_groups.remove(vg)
					if bpy.data.objects.get(modname) is not None:
						bpy.data.objects.remove(bpy.data.objects[modname], True)
					done = done+1
			except error:
				print({'ERROR'}, "Failed to apply modifier: "+error)
				error = error+1
		self.report({'INFO'}, "Done: count="+str(done)+" errors:"+str(error))
		return {'FINISHED'}
	
class WPLedges_refit_store(bpy.types.Operator):
	bl_idname = "mesh.wpledges_refit_store"
	bl_label = "Refitting: Store target edges"
	bl_options = {'REGISTER', 'UNDO'}

	opt_flowDir = FloatVectorProperty(
		name	 = "Preferred direction",
		size	 = 3,
		min=-1.0, max=1.0,
		default	 = (0.0,0.0,-1.0)
	)
	
	@classmethod
	def poll(self, context):
		# Check if we have a mesh object active and are in vertex paint mode
		p = context.object and context.object.data and (isinstance(context.scene.objects.active, bpy.types.Object))
		return p
		
	def execute(self, context):
		active_obj = context.scene.objects.active
		active_mesh = active_obj.data
		vertsIdx = get_selected_vertsIdx(active_mesh)
		edgesIdx = get_selected_edgesIdx(active_mesh)
		if len(edgesIdx)<1:
			self.report({'ERROR'}, "No selected edges found, select some edges first")
			return {'CANCELLED'}

		bpy.ops.object.mode_set( mode = 'EDIT' )
		bm = bmesh.from_edit_mesh(active_mesh)
		bm.verts.ensure_lookup_table()
		bm.faces.ensure_lookup_table()
		bm.verts.index_update()
		(strands_points,strands_radius,strands_vidx) = getBmEdgesAsStrands_v01(bm, vertsIdx, edgesIdx, self.opt_flowDir, 1)
		if strands_points is None:
			self.report({'ERROR'}, "Looped edges found, can`t work on looped edges")
			return {'CANCELLED'}
		
		g_curvetarg = strandsPoints2globalCurveset(active_obj, bm, strands_points, strands_vidx)
		WPL_G.store[kWPLRefitStoreKey] = g_curvetarg
		bpy.ops.object.mode_set(mode='OBJECT')
		self.report({'INFO'}, "Done: curves stored="+str(len(g_curvetarg)))
		return {'FINISHED'}
		
class WPLedges_refit_move(bpy.types.Operator):
	bl_idname = "mesh.wpledges_refit_move"
	bl_label = "Refitting: Refit selected edge"
	bl_options = {'REGISTER', 'UNDO'}

	opt_flowDir = FloatVectorProperty(
		name	 = "Preferred direction",
		size	 = 3,
		min=-1.0, max=1.0,
		default	 = (0.0,0.0,-1.0)
	)
	opt_smoothLevel = IntProperty(
		name="Smoothing level",
		min=1, max=1000,
		default=2,
	)

	@classmethod
	def poll(self, context):
		# Check if we have a mesh object active and are in vertex paint mode
		p = context.object and context.object.data and (isinstance(context.scene.objects.active, bpy.types.Object))
		return p
		
	def execute(self, context):
		g_curvetarg = []
		if kWPLRefitStoreKey in WPL_G.store:
			g_curvetarg = WPL_G.store[kWPLRefitStoreKey]
		if len(g_curvetarg)<1:
			self.report({'ERROR'}, "No stored edges found, store some edges first")
			return {'CANCELLED'}
		active_obj = context.scene.objects.active
		active_mesh = active_obj.data
		vertsIdx = get_selected_vertsIdx(active_mesh)
		edgesIdx = get_selected_edgesIdx(active_mesh)
		if len(edgesIdx)<1:
			self.report({'ERROR'}, "No selected edges found, select some edges first")
			return {'CANCELLED'}
		bpy.ops.object.mode_set( mode = 'EDIT' )
		bm = bmesh.from_edit_mesh(active_mesh)
		bm.verts.ensure_lookup_table()
		bm.faces.ensure_lookup_table()
		bm.verts.index_update()
		(strands_points,strands_radius,strands_vidx) = getBmEdgesAsStrands_v01(bm, vertsIdx, edgesIdx, self.opt_flowDir, 1)
		if strands_points is None:
			self.report({'ERROR'}, "Looped edges found, can`t work on looped edges")
			return {'CANCELLED'}
		g_curvebase = strandsPoints2globalCurveset(active_obj, bm, strands_points, strands_vidx)
		strand_curve = g_curvebase[0]
		# Selected vertexes define mesh islands
		duplimesh_verts = []
		for v in bm.verts:
			v.tag = False
		for vIdx in vertsIdx:
			addConnectedBmVerts_v01(bm.verts[vIdx], duplimesh_verts, None)
		# calculating each vertex position regarding original curvebase (strand_curve)
		matrixsPersVertex = {}
		for v in duplimesh_verts:
			g_co = active_obj.matrix_world * v.co
			curve_base_dists = []
			for j,curve_pt in enumerate(strand_curve):
				pt_matrix = customAxisMatrix(Vector((0,0,0)),curve_pt[1].normalized(),curve_pt[2].normalized()) #curve_pt[0]
				pt_co = pt_matrix.inverted()*(g_co-curve_pt[0])
				pt2curve_dist = (g_co-curve_pt[0]).length
				curve_base_dists.append([pt2curve_dist, 1, curve_pt[2], pt_co, j])
				#print("curve_pt",curve_pt,"pt_co",pt_co)
			curve_base_dists.sort(key=lambda ia: ia[0], reverse=False)
			curve_base_dists = curve_base_dists[:self.opt_smoothLevel]
			total_dists = 0
			for cbd in curve_base_dists:
				total_dists = total_dists+cbd[0]
			for cbd in curve_base_dists:
				cbd[1] = 1.0-(cbd[0])/total_dists
			matrixsPersVertex[v.index] = curve_base_dists
		# applying coord matrices in new coord system
		# TBD: resample curve_base to curve_stored
		curve_target = g_curvetarg[0]
		for v in duplimesh_verts:
			g_co = Vector((0,0,0))
			g_co_num = 0.0
			curve_base_dists = matrixsPersVertex[v.index]
			for k, cbd in curve_base_dists:
				curve_target_idx = cbd[4]
				curve_target_pt = curve_target[curve_target_idx]
				curve_base_xyz = cbd[3]
				curve_base_wei = 1.0 #cbd[1]
				curve_base_flo = cbd[2]
				pt_matrix = customAxisMatrix(Vector((0,0,0)),curve_target_pt[1].normalized(),curve_target_pt[2].normalized())
				flowScale = curve_target_pt[2].length / curve_base_flo.length
				#curve_base_xyz[1] = curve_base_xyz[1]*??? # flow direction
				#curve_base_xyz[2] = curve_base_xyz[2]*??? # aside direction
				g_co = g_co+curve_base_wei*(curve_target_pt[0]+pt_matrix*(flowScale*curve_base_xyz))
				g_co_num = g_co_num+curve_base_wei
			if g_co_num>0:
				v_co = active_obj.matrix_world.inverted() * (g_co/g_co_num)
				#v_co = active_obj.matrix_world.inverted() * g_co
				v.co = v_co
		bm.normal_update()
		bmesh.update_edit_mesh(active_mesh, True)
		self.report({'INFO'}, "Done")
		return {'FINISHED'}
######################### ######################### #########################
######################### ######################### #########################
class WPLSmoothDeformsSettings(PropertyGroup):
	bake_wmco = StringProperty(
		name="Vert group",
		description="Vert group",
		default = ""
	)
	bind_targ = StringProperty(
		name="Deformer",
		description="Object deformer",
		default = ""
	)

class WPLSmoothDeform_Panel1(bpy.types.Panel):
	bl_label = "Smooth Deforming"
	bl_space_type = 'VIEW_3D'
	bl_region_type = 'TOOLS'
	bl_category = 'WPL'

	def draw_header(self, context):
		layout = self.layout
		layout.label(text="")

	def draw(self, context):
		smoothdeformOpts = context.scene.smoothdeformOpts
		layout = self.layout
		col = layout.column()

		col.separator()
		col.label("Mesh smoothing")
		col.operator("mesh.wplsmthdef_snap", text="Pin mesh state")
		col.operator("mesh.wplsmthdef_apply", text="Smooth around selection")
		col.operator("mesh.wplsmthdef_restore", text="Restore at bounds")

		col.separator()
		col.label("Bending")
		col.operator("mesh.wpledges2bones", text="Edges to bones")
		col.operator("mesh.wplmodifs_apply", text="Apply bones deform")
		col.separator()
		col.operator("mesh.wpledges_refit_store", text="Refitting: Store target edges")
		col.operator("mesh.wpledges_refit_move", text="Refitting: Refit selected edge")

		col.separator()
		col.separator()
		col.prop_search(smoothdeformOpts, "bind_targ", context.scene, "objects",icon="SNAP_NORMAL")
		col.operator("mesh.wplmdefr_bind", text="Multi-bind mesh deform")
		col.operator("mesh.wplsdefr_bind", text="Multi-bind surf deform")
		col.operator("mesh.wplmodifs_apply", text="Multi-apply deforms")

		col.separator()
		col.label("Modifiers")
		col.operator("mesh.wplshsel_snap", text="Shrinkwrap selected to nearest")
		col.operator("mesh.wplmodifs_apply", text="Apply shrinkwrap")

def register():
	print("WPLSmoothDeform_Panel registered")
	bpy.utils.register_module(__name__)
	bpy.types.Scene.smoothdeformOpts = PointerProperty(type=WPLSmoothDeformsSettings)

def unregister():
	bpy.utils.unregister_module(__name__)
	bpy.utils.unregister_class(WPLSmoothDeformsSettings)

	
if __name__ == "__main__":
	register()
