# Simplified hnd posing for Manuel Bastioni rigs

import bpy
import bmesh
import math
import mathutils
import copy
from mathutils import Vector
from math import radians
import numpy as np

from random import random, seed
from bpy_extras import view3d_utils
from bpy_extras.object_utils import world_to_camera_view
from mathutils.bvhtree import BVHTree

from bpy.props import (StringProperty,
						BoolProperty,
						IntProperty,
						FloatProperty,
						FloatVectorProperty,
						EnumProperty,
						PointerProperty,
						BoolVectorProperty
						)
from bpy.types import (Panel,
						Operator,
						AddonPreferences,
						PropertyGroup,
						)

kRaycastEpsilon = 0.0001
bl_info = {
	"name": "WPL Character tools",
	"author": "IPv6",
	"version": (1, 0, 0),
	"blender": (2, 7, 9),
	"location": "View3D > T-panel > WPL",
	"description" : "",
	"warning"	 : "",
	"wiki_url"	: "",
	"tracker_url" : "",
	"category"	: ""
	}

MBArmatureBones_v02 = {
	"head" : {
		"def": Vector((0, 0, 0)), "min": Vector((-30, -60, -10)), "max": Vector((30, 60, 10)),
		"spd": Vector((1, 1, 1)),
		"prop": ["mbh_head",1]
	},
	"neck" : {
		"def": Vector((0, 0, 0)), "min": Vector((-50, -50, -25)), "max": Vector((50, 50, 25)),
		"spd": Vector((1, 1, 1)),
		"prop": ["mbh_head",0]
	},
	"spine01" : {
		"def": Vector((0, 0, 0)), "min": Vector((-60, -30, -20)), "max": Vector((60, 30, 20)),
		"spd": Vector((1, 1, 1)),
		"prop": ["mbh_spine",0]
	},
	"spine02" : {
		"def": Vector((0, 0, 0)), "min": Vector((-60, -30, -20)), "max": Vector((60, 30, 20)),
		"spd": Vector((1, 1, 1)),
		"prop": ["mbh_spine",1]
	},
	"spine03" : {
		"def": Vector((0, 0, 0)), "min": Vector((-60, -30, -20)), "max": Vector((60, 30, 20)),
		"spd": Vector((1, 1, 1)),
		"prop": ["mbh_spine",2]
	},
	"pelvis" : {
		"def": Vector((0, 0, 0)), "min": Vector((-20, -20, -20)), "max": Vector((20, 20, 20)),
		"spd": Vector((1, 1, 1)),
		"prop": None
	},
	"thigh_L" : {
		"def": Vector((0, 0, 0)), "min": Vector((-60, -50, -30)), "max": Vector((60, 50, 30)),
		"spd": Vector((0.5, 1, 1)),
		"prop": ["mbh_legs_L",0]
	},
	"calf_L" : {
		"def": Vector((0, 0, 0)), "min": Vector((-100, 0, 0)), "max": Vector((2, 0, 0)),
		"spd": Vector((1, 0, 0)),
		"prop": ["mbh_legs_L",1]
	},
	"foot_L" : {
		"def": Vector((0, 0, 0)), "min": Vector((-70, -20, 0)), "max": Vector((50, 20, 0)),
		"spd": Vector((1, 1, 0)),
		"prop": ["mbh_legs_L",2]
	},
	"toes_L" : {
		"def": Vector((0, 0, 0)), "min": Vector((-70, 0, 0)), "max": Vector((90, 0, 0)),
		"spd": Vector((1, 0, 0)),
		"prop": ["mbh_legs_L",3]
	},

	"clavicle_L" : {
		"def": Vector((0, 0, 0)), "min": Vector((-20, -30, -30)), "max": Vector((30, 60, 20)),
		"spd": Vector((1, 1, 1)),
		"prop": ["mbh_hands_L",0]
	},
	"upperarm_L" : {
		"def": Vector((0, 0, 0)), "min": Vector((-40, -30, -40)), "max": Vector((80, 50, 60)),
		"spd": Vector((1, 1, 1)),
		"prop": ["mbh_hands_L",1]
	},
	"lowerarm_L" : {
		"def": Vector((0, 0, 0)), "min": Vector((-10, -10, 0)), "max": Vector((130, 50, 0)),
		"spd": Vector((1, 1, 0)),
		"prop": ["mbh_hands_L",2]
	},

	"hand_L" : {
		"def": Vector((0, 0, 0)), "min": Vector((-50, -50, -50)), "max": Vector((50, 50, 50)),
		"spd": Vector((1, 1, 1)),
		"prop": ["mbh_wrist_L",0]
	},
	"thumb01_L" : {
		"def": Vector((0, 0, 0)), "min": Vector((-20, -20, -40)), "max": Vector((30, 60, 20)),
		"spd": Vector((1, 1, 1)),
		"prop": ["mbh_thumb_L",0]
	},
	"thumb02_L" : {
		"def": Vector((0, 0, 0)), "min": Vector((-80, 0, -10)), "max": Vector((10, 0, 50)),
		"spd": Vector((1, 0, 1)),
		"prop": ["mbh_thumb_L",1]
	},
	"thumb03_L" : {
		"def": Vector((0, 0, 0)), "min": Vector((-80, 0, 0)), "max": Vector((20, 0, 0)),
		"spd": Vector((1, 0, 0)),
		"prop": ["mbh_thumb_L",2]
	},
	"index01_L" : {
		"def": Vector((0, 0, 0)), "min": Vector((-80, 0, -40)), "max": Vector((30, 0, 10)),
		"spd": Vector((1, 0, 1)),
		"prop": ["mbh_index_L",0]
	},
	"index02_L" : {
		"def": Vector((0, 0, 0)), "min": Vector((-80, 0, 0)), "max": Vector((10, 0, 0)),
		"spd": Vector((1, 0, 0)),
		"prop": ["mbh_index_L",1]
	},
	"index03_L" : {
		"def": Vector((0, 0, 0)), "min": Vector((-80, 0, 0)), "max": Vector((10, 0, 0)),
		"spd": Vector((1, 0, 0)),
		"prop": ["mbh_index_L",2]
	},
	"middle01_L" : {
		"def": Vector((0, 0, 0)), "min": Vector((-80, 0, -40)), "max": Vector((30, 0, 10)),
		"spd": Vector((1, 0, 1)),
		"prop": ["mbh_middle_L",0]
	},
	"middle02_L" : {
		"def": Vector((0, 0, 0)), "min": Vector((-80, 0, 0)), "max": Vector((10, 0, 0)),
		"spd": Vector((1, 0, 0)),
		"prop": ["mbh_middle_L",1]
	},
	"middle03_L" : {
		"def": Vector((0, 0, 0)), "min": Vector((-80, 0, 0)), "max": Vector((10, 0, 0)),
		"spd": Vector((1, 0, 0)),
		"prop": ["mbh_middle_L",2]
	},
	"ring01_L" : {
		"def": Vector((0, 0, 0)), "min": Vector((-80, 0, -40)), "max": Vector((30, 0, 10)),
		"spd": Vector((1, 0, 1)),
		"prop": ["mbh_ring_L",0]
	},
	"ring02_L" : {
		"def": Vector((0, 0, 0)), "min": Vector((-80, 0, 0)), "max": Vector((10, 0, 0)),
		"spd": Vector((1, 0, 0)),
		"prop": ["mbh_ring_L",1]
	},
	"ring03_L" : {
		"def": Vector((0, 0, 0)), "min": Vector((-80, 0, 0)), "max": Vector((10, 0, 0)),
		"spd": Vector((1, 0, 0)),
		"prop": ["mbh_ring_L",2]
	},
	"pinky01_L" : {
		"def": Vector((0, 0, 0)), "min": Vector((-80, 0, -40)), "max": Vector((30, 0, 10)),
		"spd": Vector((1, 0, 1)),
		"prop": ["mbh_pinky_L",0]
	},
	"pinky02_L" : {
		"def": Vector((0, 0, 0)), "min": Vector((-80, 0, 0)), "max": Vector((10, 0, 0)),
		"spd": Vector((1, 0, 0)),
		"prop": ["mbh_pinky_L",1]
	},
	"pinky03_L" : {
		"def": Vector((0, 0, 0)), "min": Vector((-80, 0, 0)), "max": Vector((10, 0, 0)),
		"spd": Vector((1, 0, 0)),
		"prop": ["mbh_pinky_L",2]
	},
}

def deduceRightBones():
	bones = list(MBArmatureBones_v02.keys())
	for boneName_L in bones:
		if boneName_L.find("_L") > 0:
			boneName_R = boneName_L.replace("_L","_R")
			propName_L = MBArmatureBones_v02[boneName_L]["prop"][0]
			propName_R = propName_L.replace("_L","_R")
			MBArmatureBones_v02[boneName_R] = copy.deepcopy(MBArmatureBones_v02[boneName_L])
			MBArmatureBones_v02[boneName_R]["prop"][0] = propName_R
deduceRightBones()

def mixBone(context, boneName, curMuls, addVal, rememAfter, applyLims):
	scene = context.scene
	armatr = context.active_object
	if armatr is None or not isinstance(armatr.data, bpy.types.Armature):
		return
	boneNames = armatr.pose.bones.keys()
	if boneName in boneNames:
		bone = armatr.pose.bones[boneName]
		bone.rotation_mode = "ZYX"
		minVal = MBArmatureBones_v02[boneName]["min"]
		maxVal = MBArmatureBones_v02[boneName]["max"]
		curVal = bone.rotation_euler
		newX = curMuls[0]*curVal[0]+addVal[0]
		newY = curMuls[1]*curVal[1]+addVal[1]
		newZ = curMuls[2]*curVal[2]+addVal[2]
		if applyLims:
			newX = np.clip(newX,radians(minVal[0]),radians(maxVal[0]))
			newY = np.clip(newY,radians(minVal[1]),radians(maxVal[1]))
			newZ = np.clip(newZ,radians(minVal[2]),radians(maxVal[2]))
		newVal = Vector((newX,newY,newZ))
		bone.rotation_euler = newVal
		if rememAfter:
			MBArmatureBones_v02[boneName]["rest"] = newVal
		print("Updating bone",boneName,newVal)

def applyAngls(self,context):
	wpposeOpts = context.scene.wplPoseMBSettings
	for boneName in MBArmatureBones_v02:
		defSpd = MBArmatureBones_v02[boneName]["spd"]
		defVal = MBArmatureBones_v02[boneName]["def"]
		boneProp = MBArmatureBones_v02[boneName]["prop"]
		if boneProp is not None:
			propProp = wpposeOpts.get(boneProp[0])
			isEnabled = 0
			if propProp is not None:
				isEnabled = propProp[boneProp[1]]
			if isEnabled > 0:
				refVal = defVal
				if "rest" in MBArmatureBones_v02[boneName]:
					refVal = MBArmatureBones_v02[boneName]["rest"]
				newX = refVal[0]+wpposeOpts.mbh_foldAngle*defSpd[0]
				newY = refVal[1]+wpposeOpts.mbh_twistAngle*defSpd[1]
				newZ = refVal[2]+wpposeOpts.mbh_tiltAngle*defSpd[2]
				rotVec = Vector((newX,newY,newZ))
				#print("Applying", rotVec, "to", boneName)
				mixBone(context, boneName, Vector((0,0,0)), rotVec, False, wpposeOpts.mbh_applyLimits)
	bpy.context.scene.update()
	return None

def restAngls(self,context):
	wpposeOpts = context.scene.wplPoseMBSettings
	for boneName in MBArmatureBones_v02:
		# isEnabled = 0
		# boneProp = MBArmatureBones_v02[boneName]["prop"]
		# propProp = wpposeOpts.get(boneProp[0])
		# if propProp is not None:
			# isEnabled = propProp[boneProp[1]]
			# print("restAngls",boneName,isEnabled,boneProp[0],boneProp[1])
		mixBone(context, boneName, Vector((1,1,1)), Vector((0,0,0)), True, False)
	wpposeOpts.mbh_foldAngle = 0
	wpposeOpts.mbh_twistAngle = 0
	wpposeOpts.mbh_tiltAngle = 0
	bpy.context.scene.update()
	return None

def deflAngls(self,context):
	wpposeOpts = context.scene.wplPoseMBSettings
	wpposeOpts.mbh_foldAngle = 0
	wpposeOpts.mbh_twistAngle = 0
	wpposeOpts.mbh_tiltAngle = 0

	for boneName in MBArmatureBones_v02:
		defVal = MBArmatureBones_v02[boneName]["def"]
		boneProp = MBArmatureBones_v02[boneName]["prop"]
		if boneProp is not None:
			propProp = wpposeOpts.get(boneProp[0])
			isEnabled = 0
			if propProp is not None:
				isEnabled = propProp[boneProp[1]]
			if isEnabled > 0:
				mixBone(context, boneName, Vector((0,0,0)), Vector((defVal[0],defVal[1],defVal[2])), True, False)
	bpy.context.scene.update()
	return None

def force_visible_object(obj):
	if obj:
		if obj.hide == True:
			obj.hide = False
		for n in range(len(obj.layers)):
			obj.layers[n] = False
		current_layer_index = bpy.context.scene.active_layer
		obj.layers[current_layer_index] = True
def unselect_all():
	for obj in bpy.data.objects:
		obj.select = False
def select_and_change_mode(obj,obj_mode,hidden=False):
	unselect_all()
	if obj:
		obj.select = True
		bpy.context.scene.objects.active = obj
		force_visible_object(obj)
		try:
			m=bpy.context.mode
			if bpy.context.mode!='OBJECT':
				bpy.ops.object.mode_set(mode='OBJECT')
			bpy.context.scene.update()
			bpy.ops.object.mode_set(mode=obj_mode)
			#print("Mode switched to ", obj_mode)
		except:
			pass
		obj.hide = hidden
	return m

def get_vertgroup_by_name(obj,group_name):
	if group_name in obj.vertex_groups:
		return obj.vertex_groups[group_name]
	return None
def remove_vertgroups_all(obj):
	obj.vertex_groups.clear()
def remove_vertgroup(obj, group_name):
	vertgroup = get_vertgroup_by_name(obj, group_name)
	if vertgroup:
		obj.vertex_groups.remove(vertgroup)
def new_vertgroup(obj, group_name):
	return obj.vertex_groups.new(name=group_name)
def less_boundary_verts(obj, verts_idx, iterations=1):
	polygons = obj.data.polygons
	vertices = obj.data.vertices
	while iterations != 0:
		verts_to_remove = set()
		for poly in polygons:
			poly_verts_idx = poly.vertices
			for v_idx in poly_verts_idx:
				if v_idx not in verts_idx:
					for v_idx in poly_verts_idx:
						verts_to_remove.add(v_idx)
					break
		verts_idx.difference_update(verts_to_remove)
		iterations -= 1
#############################################################################
#############################################################################
#############################################################################
class wplPoseMBSettings(PropertyGroup):
	mbh_head = BoolVectorProperty(
		size=2,
		default=[False,False], update=restAngls)
	mbh_spine = BoolVectorProperty(
		size=3,
		default=[False,False,False], update=restAngls)
	mbh_legs_L = BoolVectorProperty(
		size=4,
		default=[False,False,False,False], update=restAngls)
	mbh_legs_R = BoolVectorProperty(
		size=4,
		default=[False,False,False,False], update=restAngls)

	mbh_hands_L = BoolVectorProperty(
		size=3,
		default=[False,False,False], update=restAngls)
	mbh_hands_R = BoolVectorProperty(
		size=3,
		default=[False,False,False], update=restAngls)

	mbh_wrist_L = BoolVectorProperty(
		size=1,
		default=[False], update=restAngls)
	mbh_thumb_L = BoolVectorProperty(
		size=3,
		default=[False,False,False], update=restAngls)
	mbh_index_L = BoolVectorProperty(
		size=3,
		default=[False,False,False], update=restAngls)
	mbh_middle_L = BoolVectorProperty(
		size=3,
		default=[False,False,False], update=restAngls)
	mbh_ring_L = BoolVectorProperty(
		size=3,
		default=[False,False,False], update=restAngls)
	mbh_pinky_L = BoolVectorProperty(
		size=3,
		default=[False,False,False], update=restAngls)
	mbh_wrist_R = BoolVectorProperty(
		size=1,
		default=[False], update=restAngls)
	mbh_thumb_R = BoolVectorProperty(
		size=3,
		default=[False,False,False], update=restAngls)
	mbh_index_R = BoolVectorProperty(
		size=3,
		default=[False,False,False], update=restAngls)
	mbh_middle_R = BoolVectorProperty(
		size=3,
		default=[False,False,False], update=restAngls)
	mbh_ring_R = BoolVectorProperty(
		size=3,
		default=[False,False,False], update=restAngls)
	mbh_pinky_R = BoolVectorProperty(
		size=3,
		default=[False,False,False], update=restAngls)
	mbh_foldAngle = FloatProperty(
		name = "Fold",
		min = -3.14,
		soft_min  = -3.14,
		max = 3.14,
		soft_max  = 3.14,
		step = 10.0,
		unit = 'ROTATION',
		default = 0,
		update=applyAngls
	)
	mbh_tiltAngle = FloatProperty(
		name = "Tilt",
		min = -3.14,
		soft_min  = -3.14,
		max = 3.14,
		soft_max  = 3.14,
		step = 3.0,
		unit = 'ROTATION',
		default = 0,
		update=applyAngls
	)
	mbh_twistAngle = FloatProperty(
		name = "Twist",
		min = -3.14,
		soft_min  = -3.14,
		max = 3.14,
		soft_max  = 3.14,
		step = 10.0,
		unit = 'ROTATION',
		default = 0,
		update=applyAngls
	)
	mbh_applyLimits = BoolProperty(
		default = True
	)
	mbh_mask_targ = StringProperty(
		name="Body mesh",
		default = ""
	)

#############################################################################
#############################################################################
#############################################################################
class wplposing_mbbn2zero( bpy.types.Operator ):
	bl_idname = "object.wplposing_mbbn2zero"
	bl_label = "Reset bones to default angles"
	bl_options = {'REGISTER', 'UNDO'}

	@classmethod
	def poll( cls, context ):
		p = context.object and context.object.data and (isinstance(context.scene.objects.active, bpy.types.Object) and isinstance(context.scene.objects.active.data, bpy.types.Armature))
		return p

	def execute( self, context ):
		deflAngls(self, context)
		return {'FINISHED'}

class wplposing_clearchbx( bpy.types.Operator ):
	bl_idname = "object.wplposing_clearchbx"
	bl_label = "Clear posing checkboxes"
	bl_options = {'REGISTER', 'UNDO'}

	@classmethod
	def poll( cls, context ):
		p = context.object and context.object.data and (isinstance(context.scene.objects.active, bpy.types.Object) and isinstance(context.scene.objects.active.data, bpy.types.Armature))
		return p

	def execute( self, context ):
		wpposeOpts = context.scene.wplPoseMBSettings
		for boneName in MBArmatureBones_v02:
			boneProp = MBArmatureBones_v02[boneName]["prop"]
			if boneProp is not None:
				propProp = wpposeOpts.get(boneProp[0])
				if propProp is not None:
					propProp[boneProp[1]] = False
		restAngls(self, context)
		return {'FINISHED'}


class wplposing_selc2chbx( bpy.types.Operator ):
	bl_idname = "object.wplposing_selc2chbx"
	bl_label = "Checkboxes from selection"
	bl_options = {'REGISTER', 'UNDO'}

	@classmethod
	def poll( cls, context ):
		p = context.object and context.object.data and (isinstance(context.scene.objects.active, bpy.types.Object) and isinstance(context.scene.objects.active.data, bpy.types.Armature))
		return p

	def execute( self, context ):
		wpposeOpts = context.scene.wplPoseMBSettings
		scene = context.scene
		armatr = context.active_object
		if armatr is None or not isinstance(armatr.data, bpy.types.Armature):
			return {'CANCELLED'}
		boneNames = armatr.pose.bones.keys()
		for boneName in boneNames:
			if boneName in MBArmatureBones_v02:
				boneProp = MBArmatureBones_v02[boneName]["prop"]
				if boneProp is not None:
					bone = armatr.data.bones[boneName]
					if boneProp[0] in wpposeOpts: # unset props are NONE!
						propAttr = wpposeOpts[boneProp[0]]
						if bone.select:
							propAttr[boneProp[1]] = True
						else:
							propAttr[boneProp[1]] = False
					else:
						if bone.select:
							self.report({'ERROR'}, "Checkbox for bone not initialized")
							return {'CANCELLED'}
		restAngls(self, context)
		return {'FINISHED'}

class wplposing_bn_applyconstr( bpy.types.Operator ):
	bl_idname = "object.wplposing_bn_applyconstr"
	bl_label = "Apply constraints"
	bl_options = {'REGISTER', 'UNDO'}

	opt_postAction = bpy.props.EnumProperty(
		name="Action", default="ENABLE",
		items=(("CLEAR", "Clear constraints", ""), ("DISABLE", "Disable constraints", ""), ("ENABLE", "Enable constraints", ""))
	)

	@classmethod
	def poll( cls, context ):
		p = context.object and context.object.data and (isinstance(context.scene.objects.active, bpy.types.Object) and isinstance(context.scene.objects.active.data, bpy.types.Armature))
		return p

	def execute( self, context ):
		wpposeOpts = context.scene.wplPoseMBSettings
		scene = context.scene
		armatr = context.active_object
		if armatr is None or not isinstance(armatr.data, bpy.types.Armature):
			return {'CANCELLED'}
		bpy.ops.pose.visual_transform_apply()
		boneNames = armatr.pose.bones.keys()
		for boneName in boneNames:
			bone = armatr.data.bones[boneName]
			if bone.select:
				pbone = armatr.pose.bones[boneName]
				if len(pbone.constraints) > 0:
					constrs = []
					for constr in pbone.constraints:
						constrs.append(constr)
					for constr in constrs:
						if self.opt_postAction == "CLEAR":
							pbone.constraints.remove(constr)
						if self.opt_postAction == "DISABLE":
							constr.mute = True
						if self.opt_postAction == "ENABLE":
							constr.mute = False
		return {'FINISHED'}

class wplposing_bn_select_active( bpy.types.Operator ):
	bl_idname = "object.wplposing_bn_select_active"
	bl_label = "Select corresponding bones"
	bl_options = {'REGISTER', 'UNDO'}

	@classmethod
	def poll( cls, context ):
		p = context.object and context.object.data and (isinstance(context.scene.objects.active, bpy.types.Object) and isinstance(context.scene.objects.active.data, bpy.types.Armature))
		return p

	def execute( self, context ):
		wpposeOpts = context.scene.wplPoseMBSettings
		scene = context.scene
		armatr = context.active_object
		if armatr is None or not isinstance(armatr.data, bpy.types.Armature):
			return {'CANCELLED'}
		boneNames = armatr.pose.bones.keys()
		for boneName in boneNames:
			if boneName in MBArmatureBones_v02:
				boneProp = MBArmatureBones_v02[boneName]["prop"]
				if boneProp is not None:
					propProp = wpposeOpts.get(boneProp[0])
					if propProp is not None and propProp[boneProp[1]] == True:
						bone = armatr.data.bones[boneName]
						bone.select = True
		return {'FINISHED'}

class wplposing_bn_deselect_inactive( bpy.types.Operator ):
	bl_idname = "object.wplposing_bn_deselect_inactive"
	bl_label = "Select corresponding bones"
	bl_options = {'REGISTER', 'UNDO'}

	@classmethod
	def poll( cls, context ):
		p = context.object and context.object.data and (isinstance(context.scene.objects.active, bpy.types.Object) and isinstance(context.scene.objects.active.data, bpy.types.Armature))
		return p

	def execute( self, context ):
		wpposeOpts = context.scene.wplPoseMBSettings
		scene = context.scene
		armatr = context.active_object
		if armatr is None or not isinstance(armatr.data, bpy.types.Armature):
			return {'CANCELLED'}
		boneNames = armatr.pose.bones.keys()
		for boneName in boneNames:
			need2deselect = True
			if boneName in MBArmatureBones_v02:
				boneProp = MBArmatureBones_v02[boneName]["prop"]
				if boneProp is not None:
					propProp = wpposeOpts.get(boneProp[0])
					if propProp is not None and propProp[boneProp[1]] == True:
						need2deselect = False
			if need2deselect:
				bone = armatr.data.bones[boneName]
				bone.select = False
		return {'FINISHED'}

class wplposing_datatransf( bpy.types.Operator ):
	bl_idname = "object.wplposing_datatransf"
	bl_label = "Mass-transfer data"
	bl_options = {'REGISTER', 'UNDO'}
	
	opt_tranfType = bpy.props.EnumProperty(
		name="Data type", default="WEI",
		items=(("WEI", "Weights", ""), ("VC", "Vertex colors", ""))
	)
	
	@classmethod
	def poll( cls, context ):
		p = (isinstance(context.scene.objects.active, bpy.types.Object))
		return p

	def execute( self, context ):
		wpposeOpts = context.scene.wplPoseMBSettings
		if wpposeOpts.mbh_mask_targ not in bpy.data.objects.keys():
			self.report({'INFO'}, 'No source to get weight')
			return {"CANCELLED"}
		sel_all = [o.name for o in bpy.context.selected_objects]
		if len(sel_all) == 0:
			self.report({'ERROR'}, "No objects selectedt")
			return {'CANCELLED'}

		ok = 0
		active_obj = bpy.data.objects[wpposeOpts.mbh_mask_targ]
		select_and_change_mode(active_obj,"OBJECT")
		for i, sel_obj_name in enumerate(sel_all):
			sel_obj = context.scene.objects[sel_obj_name]
			if sel_obj.name == active_obj.name:
				continue
			select_and_change_mode(sel_obj,"OBJECT")
			print("Handling object "+str(i+1)+" of "+str(len(sel_all)))
			modname = "sys_dataTransfer"
			bpy.ops.object.modifier_remove(modifier=modname)
			modifiers = sel_obj.modifiers
			dt_modifier = modifiers.new(name = modname, type = 'DATA_TRANSFER')
			if dt_modifier is not None:
				if self.opt_tranfType == "WEI":
					dt_modifier.use_vert_data = True
					dt_modifier.data_types_verts = {'VGROUP_WEIGHTS'}
					dt_modifier.vert_mapping = 'POLYINTERP_NEAREST'
					dt_modifier.layers_vgroup_select_src = 'ALL'
					dt_modifier.layers_vgroup_select_dst = 'NAME'
				if self.opt_tranfType == "VC":
					dt_modifier.use_loop_data = True
					dt_modifier.data_types_loops = {'VCOL'}
					dt_modifier.loop_mapping = 'POLYINTERP_NEAREST'
					dt_modifier.layers_vcol_select_src = 'ALL'
					dt_modifier.layers_vcol_select_dst = 'NAME'
				dt_modifier.object = active_obj
				while sel_obj.modifiers[0].name != modname:
					bpy.ops.object.modifier_move_up(modifier=modname)
				bpy.ops.object.datalayout_transfer(modifier=modname)
				bpy.ops.object.modifier_apply(apply_as='DATA', modifier=modname)
				ok = ok+1
		self.report({'INFO'}, "Transferred to "+str(ok)+" objects")
		return {'FINISHED'}

class wplposing_maskgarm( bpy.types.Operator ):
	bl_idname = "object.wplposing_maskgarm"
	bl_label = "Mask from selection"
	bl_options = {'REGISTER', 'UNDO'}
	opt_displInfluence = FloatProperty(
			name="Displace (0 to hide)",
			min=-10, max=10,
			step=0.01,
			default=0.01,
	)
	opt_dist2hide = FloatProperty(
			name="Vert distance",
			min=0.0001, max=100.0,
			step=0.01,
			default=0.02,
	)
	opt_insetLoops = IntProperty(
			name="Post-inset edges (loops)",
			min=0, max=100,
			default=1,
	)

	@classmethod
	def poll( cls, context ):
		p = (isinstance(context.scene.objects.active, bpy.types.Object))
		return p

	def execute( self, context ):
		wpposeOpts = context.scene.wplPoseMBSettings
		if wpposeOpts.mbh_mask_targ not in bpy.data.objects.keys():
			self.report({'INFO'}, 'No target to add masks')
			return {"CANCELLED"}
		sel_all = [o.name for o in bpy.context.selected_objects]
		if len(sel_all) == 0:
			self.report({'ERROR'}, "No objects selectedt")
			return {'CANCELLED'}

		active_obj = bpy.data.objects[wpposeOpts.mbh_mask_targ]
		select_and_change_mode(active_obj,"OBJECT")
		#main bvh
		#active_obj_mesh = active_obj.to_mesh(context.scene, True, 'PREVIEW')
		bmFromAct = bmesh.new()
		bmFromAct.from_mesh(active_obj.data)
		#bpy.data.meshes.remove(active_obj_mesh)
		bmFromAct.transform(active_obj.matrix_world)
		bmFromAct.verts.ensure_lookup_table()
		bmFromAct.faces.ensure_lookup_table()
		bmFromAct.verts.index_update()
		bmFromAct.faces.index_update()
		vertsSet = []
		#bvhGlobAct = BVHTree.FromBMesh(bmFromAct, epsilon = kRaycastEpsilon)
		for i, sel_obj_name in enumerate(sel_all):
			sel_obj = context.scene.objects[sel_obj_name]
			if sel_obj.name == active_obj.name:
				continue
			print("Handling object "+str(i+1)+" of "+str(len(sel_all)))
			#main bvh
			sel_obj_mesh = sel_obj.to_mesh(context.scene, True, 'PREVIEW')
			bmFromSel = bmesh.new()
			bmFromSel.from_mesh(sel_obj_mesh)
			bpy.data.meshes.remove(sel_obj_mesh)
			bmesh.ops.subdivide_edges(bmFromSel,edges=bmFromSel.edges[:], cuts=1, use_grid_fill=True, use_single_edge=True)
			bmFromSel.transform(sel_obj.matrix_world)
			bvhGlobSel = BVHTree.FromBMesh(bmFromSel, epsilon = kRaycastEpsilon)
			#creating vertex group
			modname = "mask_"+sel_obj.name
			remove_vertgroup(active_obj,"sys_"+modname)
			mask_group = new_vertgroup(active_obj,"sys_"+modname)
			vert2nearmap = set()
			for i, vert in enumerate(bmFromAct.verts):
				s_location, s_normal, s_index, s_distance = bvhGlobSel.find_nearest(vert.co, self.opt_dist2hide)
				if s_location is not None:
					vert2nearmap.add(vert.index)
			less_boundary_verts(active_obj, vert2nearmap, self.opt_insetLoops)
			for i, vert in enumerate(bmFromAct.verts):
				if vert.index in vert2nearmap:
					if vert.index not in vertsSet:
						vertsSet.append(vert.index)
					mask_group.add([vert.index], 1.0, 'ADD')
			bpy.ops.object.modifier_remove(modifier=modname)
			modifiers = active_obj.modifiers
			if self.opt_displInfluence == 0.0:
				mask_modifier = modifiers.new(name = modname, type = 'MASK')
				mask_modifier.vertex_group = mask_group.name
				mask_modifier.invert_vertex_group = True
			else:
				mask_modifier = modifiers.new(name = modname, type = 'DISPLACE')
				mask_modifier.direction = 'NORMAL'
				mask_modifier.mid_level = 0.0
				mask_modifier.strength = -1*self.opt_displInfluence
				mask_modifier.vertex_group = mask_group.name
			bmFromSel.free()
		bmFromAct.free()
		select_and_change_mode(active_obj,"EDIT")
		bpy.ops.mesh.select_mode(type="VERT")
		bpy.ops.mesh.select_all(action = 'DESELECT')
		bpy.ops.object.mode_set(mode='OBJECT')
		active_mesh = active_obj.data
		for v in active_mesh.vertices:
			if v.index in vertsSet:
				active_mesh.vertices[v.index].select = True
		return {'FINISHED'}
#############################################################################
#############################################################################
#############################################################################
class WPLPosingMBArmBody_Panel(bpy.types.Panel):
	bl_label = "Posing: Body"
	bl_space_type = 'VIEW_3D'
	bl_region_type = 'TOOLS'
	bl_context = "posemode"
	bl_category = 'WPL'

	def draw_header(self, context):
		layout = self.layout
		layout.label(text="")

	def draw(self, context):
		layout = self.layout
		scene = context.scene
		wpposeOpts = context.scene.wplPoseMBSettings

		# display the properties
		col = layout.column()
		row_ftt1 = col.row(align=True)
		row_ftt1.prop(wpposeOpts, "mbh_foldAngle", text="Fold")
		row_ftt1.prop(wpposeOpts, "mbh_twistAngle", text="Twist")
		row_ftt1.prop(wpposeOpts, "mbh_tiltAngle", text="Tilt")
		box_ftt1 = col.box()
		row_mbh_head = box_ftt1.row()
		row_mbh_head.prop(wpposeOpts, "mbh_head", text="Head")
		row_mbh_spine = box_ftt1.row()
		row_mbh_spine.prop(wpposeOpts, "mbh_spine", text="Spine")
		box_ftt2 = col.box()
		row_mbh_hands_L = box_ftt2.row()
		row_mbh_hands_L.prop(wpposeOpts, "mbh_hands_L", text="L:Hand")
		row_mbh_hands_R = box_ftt2.row()
		row_mbh_hands_R.prop(wpposeOpts, "mbh_hands_R", text="R:Hand")
		box_ftt3 = col.box()
		row_mbh_legs_L = box_ftt3.row()
		row_mbh_legs_L.prop(wpposeOpts, "mbh_legs_L", text="L:Leg")
		row_mbh_legs_R = box_ftt3.row()
		row_mbh_legs_R.prop(wpposeOpts, "mbh_legs_R", text="R:Leg")
		col.operator("object.wplposing_mbbn2zero", text="Reset to default")


class WPLPosingMBArmRHand_Panel(bpy.types.Panel):
	bl_label = "Posing: Right palm"
	bl_space_type = 'VIEW_3D'
	bl_region_type = 'TOOLS'
	bl_context = "posemode"
	bl_category = 'WPL'

	def draw_header(self, context):
		layout = self.layout
		layout.label(text="")

	def draw(self, context):
		layout = self.layout
		scene = context.scene
		wpposeOpts = context.scene.wplPoseMBSettings

		# display the properties
		col = layout.column()

		row_ftt3 = col.row(align=True)
		row_ftt3.prop(wpposeOpts, "mbh_foldAngle", text="Fold")
		row_ftt3.prop(wpposeOpts, "mbh_twistAngle", text="Twist")
		row_ftt3.prop(wpposeOpts, "mbh_tiltAngle", text="Tilt")
		box_ftt6 = col.box()
		row_mbh_wrist_R = box_ftt6.row()
		row_mbh_wrist_R.prop(wpposeOpts, "mbh_wrist_R", text="Wrist")
		box_ftt7 = col.box()
		row_mbh_thumb_R = box_ftt7.row()
		row_mbh_thumb_R.prop(wpposeOpts, "mbh_thumb_R", text="=:-:-")
		row_mbh_index_R = box_ftt7.row()
		row_mbh_index_R.prop(wpposeOpts, "mbh_index_R", text="=:=:>")
		row_mbh_middle_R = box_ftt7.row()
		row_mbh_middle_R.prop(wpposeOpts, "mbh_middle_R", text="=:=:-")
		row_mbh_ring_R = box_ftt7.row()
		row_mbh_ring_R.prop(wpposeOpts, "mbh_ring_R", text="=:=:-")
		row_mbh_pinky_R = box_ftt7.row()
		row_mbh_pinky_R.prop(wpposeOpts, "mbh_pinky_R", text="=:-:-")
		col.operator("object.wplposing_mbbn2zero", text="Reset to default")

class WPLPosingMBArmLHand_Panel(bpy.types.Panel):
	bl_label = "Posing: Left palm"
	bl_space_type = 'VIEW_3D'
	bl_region_type = 'TOOLS'
	bl_context = "posemode"
	bl_category = 'WPL'

	def draw_header(self, context):
		layout = self.layout
		layout.label(text="")

	def draw(self, context):
		layout = self.layout
		scene = context.scene
		wpposeOpts = context.scene.wplPoseMBSettings

		# display the properties
		col = layout.column()

		row_ftt2 = col.row(align=True)
		row_ftt2.prop(wpposeOpts, "mbh_foldAngle", text="Fold")
		row_ftt2.prop(wpposeOpts, "mbh_twistAngle", text="Twist")
		row_ftt2.prop(wpposeOpts, "mbh_tiltAngle", text="Tilt")
		box_ftt4 = col.box()
		row_mbh_wrist_L = box_ftt4.row()
		row_mbh_wrist_L.prop(wpposeOpts, "mbh_wrist_L", text="Wrist")
		box_ftt5 = col.box()
		row_mbh_thumb_L = box_ftt5.row()
		row_mbh_thumb_L.prop(wpposeOpts, "mbh_thumb_L", text="=:-:-")
		row_mbh_index_L = box_ftt5.row()
		row_mbh_index_L.prop(wpposeOpts, "mbh_index_L", text="=:=:>")
		row_mbh_middle_L = box_ftt5.row()
		row_mbh_middle_L.prop(wpposeOpts, "mbh_middle_L", text="=:=:-")
		row_mbh_ring_L = box_ftt5.row()
		row_mbh_ring_L.prop(wpposeOpts, "mbh_ring_L", text="=:=:-")
		row_mbh_pinky_L = box_ftt5.row()
		row_mbh_pinky_L.prop(wpposeOpts, "mbh_pinky_L", text="=:-:-")
		col.operator("object.wplposing_mbbn2zero", text="Reset to default")

class WPLPosingOpts_Panel(bpy.types.Panel):
	bl_label = "Opts and Utils"
	bl_space_type = 'VIEW_3D'
	bl_region_type = 'TOOLS'
	bl_context = "posemode"
	bl_category = 'WPL'

	def draw_header(self, context):
		layout = self.layout
		layout.label(text="")

	def draw(self, context):
		layout = self.layout
		scene = context.scene
		wpposeOpts = context.scene.wplPoseMBSettings

		# display the properties
		col = layout.column()
		col.prop(wpposeOpts, "mbh_applyLimits", text="Apply physical rotation limits")
		col.operator("object.wplposing_clearchbx", text="Clear checkboxes")
		col.operator("object.wplposing_selc2chbx", text="Checkboxes from selected")
		col.separator()
		col.label("Selection")
		row1 = col.row()
		row1.operator("object.wplposing_bn_select_active", text="Select bones")
		row1.operator("object.wplposing_bn_deselect_inactive", text="Deselect others")
		col.separator()
		col.operator("object.wplposing_bn_applyconstr", text="Apply constraints")


class WPLPosingMask_Panel(bpy.types.Panel):
	bl_label = "Garment tools"
	bl_space_type = 'VIEW_3D'
	bl_region_type = 'TOOLS'
	bl_context = "objectmode"
	bl_category = 'WPL'

	def draw_header(self, context):
		layout = self.layout
		layout.label(text="")

	def draw(self, context):
		layout = self.layout
		wpposeOpts = context.scene.wplPoseMBSettings

		# display the properties
		col = layout.column()
		col.prop_search(wpposeOpts, "mbh_mask_targ", context.scene, "objects",icon="SNAP_NORMAL")
		col.operator("object.wplposing_maskgarm", text="Mask by selection").opt_displInfluence = 0.0
		col.operator("object.wplposing_maskgarm", text="Displace by selection").opt_displInfluence = 0.01

		col.separator()
		col.operator("object.wplposing_datatransf", text="Transfer weights to selection").opt_tranfType = 'WEI'
		col.operator("object.wplposing_datatransf", text="Transfer v-colors to selection").opt_tranfType = 'VC'


#############################################################################
#############################################################################
#############################################################################

def register():
	bpy.utils.register_module(__name__)
	bpy.types.Scene.wplPoseMBSettings = PointerProperty(type=wplPoseMBSettings)

def unregister():
	del bpy.types.Scene.wplPoseMBSettings
	bpy.utils.unregister_module(__name__)

if __name__ == "__main__":
	register()
