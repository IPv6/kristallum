import bpy
import bmesh
import math
import copy
import mathutils
import random
import numpy as np
from mathutils import Vector
from bpy_extras import view3d_utils
from bpy_extras.object_utils import world_to_camera_view
from mathutils.bvhtree import BVHTree

from bpy.props import (StringProperty,
						BoolProperty,
						IntProperty,
						FloatProperty,
						FloatVectorProperty,
						EnumProperty,
						PointerProperty,
						)
from bpy.types import (Panel,
						Operator,
						AddonPreferences,
						PropertyGroup,
						)

bl_info = {
	"name": "WPL Curve Tools",
	"author": "IPv6",
	"version": (1, 0, 0),
	"blender": (2, 7, 9),
	"location": "View3D > T-panel > WPL",
	"description" : "",
	"warning"	 : "",
	"wiki_url"	: "",
	"tracker_url" : "",
	"category"	: ""
}

kWPLSystemEmpty = "zzz_Support"
kWPLCurvePostfix = "_curve"
kWPLCurveHookPostfix = "_hook"

kRaycastEpsilon = 0.0001
######################### ######################### #########################
######################### ######################### #########################
def force_visible_object(obj):
	if obj:
		if obj.hide == True:
			obj.hide = False
		for n in range(len(obj.layers)):
			obj.layers[n] = False
		current_layer_index = bpy.context.scene.active_layer
		obj.layers[current_layer_index] = True
def unselect_all():
	for obj in bpy.data.objects:
		obj.select = False
def select_and_change_mode(obj,obj_mode,hidden=False):
	unselect_all()
	if obj:
		obj.select = True
		bpy.context.scene.objects.active = obj
		force_visible_object(obj)
		try:
			m=bpy.context.mode
			if bpy.context.mode!='OBJECT':
				bpy.ops.object.mode_set(mode='OBJECT')
			bpy.context.scene.update()
			bpy.ops.object.mode_set(mode=obj_mode)
			#print("Mode switched to ", obj_mode)
		except:
			pass
		obj.hide = hidden
	return m

def getSysEmpty(context):
	empty = context.scene.objects.get(kWPLSystemEmpty)
	if empty is None:
		empty = bpy.data.objects.new(kWPLSystemEmpty, None)
		empty.empty_draw_size = 0.45
		empty.empty_draw_type = 'PLAIN_AXES'
		context.scene.objects.link(empty)
		context.scene.update()
	return empty

def get_selected_vertsIdx(active_mesh):
	bpy.ops.object.mode_set(mode='OBJECT')
	selectedVertsIdx = [e.index for e in active_mesh.vertices if e.select]
	return selectedVertsIdx
def get_selected_edgesIdx(active_mesh):
	bpy.ops.object.mode_set(mode='OBJECT')
	selectedEdgesIdx = [e.index for e in active_mesh.edges if e.select]
	return selectedEdgesIdx

def getBmEdgesAsStrands_v01(bm, vertsIdx, edgesIdx, opt_flowDirP, opt_edgeStep):
	# looking for bounding verts
	bndVerts = []
	opt_flowDir = Vector(opt_flowDirP)
	opt_flowDir = opt_flowDir.normalized()
	for vIdx in vertsIdx:
		v = bm.verts[vIdx]
		edgeDirs = []
		edgeLens = 0
		edgeLensC = 0
		for e in v.link_edges:
			if e.index in edgesIdx:
				flowfir = (e.other_vert(v).co-v.co).normalized()
				flowdot = flowfir.dot(opt_flowDir)
				flowang = math.acos(flowdot)
				edgeDirs.append(flowang)
			else:
				edgeLens = edgeLens+e.calc_length()
				edgeLensC = edgeLensC+1
		if len(edgeDirs) == 1:
			bndVerts.append((vIdx, edgeDirs[0],edgeLens/(edgeLensC+0.001)))
	if len(bndVerts)<2 or len(bndVerts)%2 == 1:
		return (None, None, None)
	bndVerts.sort(key=lambda ia: ia[1], reverse=False)
	strands_points = []
	strands_radius = []
	strands_vidx = []
	checked_verts = []
	#print("bndVerts", bndVerts)
	for ia in bndVerts:
		vIdx = ia[0]
		points_co = None
		points_idx = None
		canContinue = True
		while canContinue == True:
			#print("Checking vIdx", vIdx)
			if vIdx in checked_verts:
				canContinue = False
				continue
			checked_verts.append(vIdx)
			if points_co is None:
				points_co = []
				points_idx = []
				strands_points.append(points_co)
				strands_vidx.append(points_idx)
				strands_radius.append(ia[2])
			v = bm.verts[vIdx]
			points_idx.append([v.index])
			points_co.append(v.co)
			canContinue = False
			for e in v.link_edges:
				if e.index in edgesIdx:
					vIdx = e.other_vert(v).index
					if vIdx not in checked_verts:
						canContinue = True
						break
	#print("strands_points", strands_points, strands_vidx)
	if(opt_edgeStep > 1):
		# repacking
		strands_points2 = []
		strands_vidx2 = []
		for i,points_co in enumerate(strands_points):
			points_co2 = []
			points_idx2 = []
			strands_points2.append(points_co2)
			strands_vidx2.append(points_idx2)
			lastIdxList = None
			for j in range(len(points_co)):
				if j == 0 or (j%opt_edgeStep) == 0 or j == len(points_co)-1:
					if j < len(points_co)-1:
						lastIdxList = strands_vidx[i][j]
					else:
						lastIdxList.append(strands_vidx[i][j][0])
					points_co2.append(points_co[j])
					points_idx2.append(lastIdxList)
				else:
					lastIdxList.append(strands_vidx[i][j][0])
		#print("strands_points2", strands_points2, strands_vidx2)
		strands_points = strands_points2
		strands_vidx = strands_vidx2
	return (strands_points, strands_radius, strands_vidx)

def makeObjectWireNoRender(c_object):
	c_object.draw_type = 'WIRE'
	c_object.hide_render = True
	c_object.cycles_visibility.camera = False
	c_object.cycles_visibility.diffuse = False
	c_object.cycles_visibility.glossy = False
	c_object.cycles_visibility.transmission = False
	c_object.cycles_visibility.scatter = False
	c_object.cycles_visibility.shadow = False

def areas_tuple():
	res = {}
	count = 0
	for area in bpy.context.screen.areas:
		res[area.type] = count
		count += 1
	return res
######################### ######################### #########################
######################### ######################### #########################

class WPLedges2curves(bpy.types.Operator):
	bl_idname = "mesh.wpledges2curves"
	bl_label = "Edges to curves"
	bl_options = {'REGISTER', 'UNDO'}

	opt_curveType = bpy.props.EnumProperty(
		name="Curve Type", default="NURBS",
		items=(("NURBS", "Nurbs", ""), ("POLY", "Poly", ""))
	)
	opt_flowDir = FloatVectorProperty(
		name	 = "Preferred direction",
		size	 = 3,
		min=-1.0, max=1.0,
		default	 = (0.0,0.0,-1.0)
	)
	opt_initRadFrac = FloatProperty(
		name	 = "Initial radius (edgelen frac)",
		min=-100.0000, max=100.0,
		default	 = 0.5
	)
	opt_edgeStep = IntProperty(
		name	 = "Curve points per edge",
		min=1, max=100,
		default	 = 3
	)
	opt_resetObjOrigin = BoolProperty(
		name="Reset curve origin",
		description="Reset curve origin",
		default=True
	)
	opt_curveAttachType = bpy.props.EnumProperty(
		name="Attach to source", default="NONE",
		items=(("NONE", "None", ""), ("SHRW", "Shrinkwrap", ""), ("HOOK", "Hook to verts", ""))
	)
	opt_hideSourceObj = BoolProperty(
		name="Hide source from render",
		description="Hide source object from render",
		default=False
	)

	@classmethod
	def poll(self, context):
		# Check if we have a mesh object active and are in vertex paint mode
		p = context.object and context.object.data and (isinstance(context.scene.objects.active, bpy.types.Object) and isinstance(context.scene.objects.active.data, bpy.types.Mesh))
		return p

	def execute(self, context):
		active_obj = context.scene.objects.active
		active_mesh = active_obj.data
		select_and_change_mode(active_obj, 'EDIT')

		vertsIdx = get_selected_vertsIdx(active_mesh)
		edgesIdx = get_selected_edgesIdx(active_mesh)
		if len(edgesIdx)<1:
			self.report({'ERROR'}, "No selected edges found, select some edges first")
			return {'CANCELLED'}
		bpy.ops.object.mode_set( mode = 'EDIT' )
		#bpy.ops.mesh.select_mode(type="FACE")
		bm = bmesh.from_edit_mesh( active_mesh )
		bm.verts.ensure_lookup_table()
		bm.faces.ensure_lookup_table()
		bm.verts.index_update()
		(strands_points,strands_radius,strands_vidx) = getBmEdgesAsStrands_v01(bm, vertsIdx, edgesIdx, self.opt_flowDir, self.opt_edgeStep)
		if strands_points is None:
			self.report({'ERROR'}, "Looped edges found, can`t work on looped edges")
			return {'CANCELLED'}
		curveData = bpy.data.curves.new(active_obj.name+kWPLCurvePostfix, type='CURVE')
		curveData.dimensions = '3D'
		curveData.twist_mode = 'MINIMUM' #'TANGENT'
		curveData.fill_mode = 'FULL'
		if self.opt_initRadFrac>0:
			curveData.bevel_depth = strands_radius[0]*self.opt_initRadFrac
		else:
			curveData.bevel_depth = abs(self.opt_initRadFrac)
		curveData.bevel_resolution = 2
		curveOB = bpy.data.objects.new(active_obj.name+kWPLCurvePostfix, curveData)
		curveOB.matrix_world = active_obj.matrix_world
		curveOB.sourceMeshPointer = active_obj.name
		bpy.context.scene.objects.link(curveOB)
		activeName = active_obj.name
		curveName = curveOB.name

		hookEmptyes = {}
		for i,strand_curve in enumerate(strands_points):
			polyline = curveData.splines.new(self.opt_curveType)
			polyline.points.add(len(strand_curve) - 1)
			if self.opt_curveType == 'NURBS':
				polyline.order_u = 3  # like bezier thing
				polyline.use_endpoint_u = True
			for j, co in enumerate(strand_curve):
				polyline.points[j].co = (co[0], co[1], co[2], 1)
				if self.opt_curveAttachType == 'HOOK':
					hookName = kWPLCurveHookPostfix+str(i)+"_"+str(j)
					empt1 = bpy.data.objects.new("sys_"+curveName+kWPLCurveHookPostfix+str(i)+"_"+str(j), None)
					empt1.hide = True
					empt1.hide_render = True
					empt1.hide_select = True
					empt1.parent = active_obj
					empt1.parent_type = 'VERTEX'
					if j < len(strand_curve)-1:
						empt1.parent_vertices[0] = strands_vidx[i][j][0]
					else:
						empt1.parent_vertices[0] = strands_vidx[i][j][-1]
					bpy.context.scene.objects.link(empt1)
					empt1.location = Vector((0,0,0))
					#empt2 = bpy.data.objects.new("sys_"+activeName+"_hook"+str(i)+"_"+str(j), None)
					#empt2.hide = True
					#empt2.hide_render = True
					#empt2.hide_select = True
					#empt2.parent = curveOB
					#followCon = empt2.constraints.new('COPY_TRANSFORMS')
					#followCon.target = empt1
					#bpy.context.scene.objects.link(empt2)
					hookEmptyes[hookName] = [i,j,empt1]
		bpy.ops.object.mode_set( mode = 'OBJECT' )
		active_obj.select = False
		curveOB.select = True
		curveOB.data.show_normal_face = False
		if self.opt_resetObjOrigin:
			select_and_change_mode(curveOB, 'OBJECT')
			bpy.ops.object.origin_set(type='ORIGIN_GEOMETRY')
		if self.opt_curveAttachType == 'HOOK':
			modifiers = curveOB.modifiers
			for hookTripleId in hookEmptyes:
				hookTriple = hookEmptyes[hookTripleId]
				hookmdf = modifiers.new(name = hookTripleId, type = 'HOOK')
				hookmdf.object = hookTriple[2]
			select_and_change_mode(curveOB, 'EDIT')
			bpy.ops.curve.select_all(action='DESELECT')
			for hookTripleId in hookEmptyes:
				hookTriple = hookEmptyes[hookTripleId]
				polyId = hookTriple[0]
				polyPointId = hookTriple[1]
				polyline = curveOB.data.splines[polyId]
				point = polyline.points[polyPointId]
				point.select = True
				#point_temp = (point.co[0],point.co[1],point.co[2],1)
				#hookTriple.append(point_temp)
				#point.co = (0,0,0,1)
				bpy.ops.object.hook_assign(modifier = hookTripleId)
				bpy.ops.object.hook_reset(modifier = hookTripleId)
				bpy.ops.curve.select_all(action='DESELECT')
			select_and_change_mode(curveOB, 'OBJECT')
			#select_and_change_mode(curveOB, 'EDIT')
			#areas = areas_tuple()
			#view3d = bpy.context.screen.areas[areas['VIEW_3D']].spaces[0]
			#for hookTripleId in hookEmptyes:
			#	hookTriple = hookEmptyes[hookTripleId]
			#	polyId = hookTriple[0]
			#	polyPointId = hookTriple[1]
			#	polyline = curveOB.data.splines[polyId]
			#	point = polyline.points[polyPointId]
			#	point.co = hookTriple[3]
			#	bpy.ops.object.hook_reset(modifier = hookTripleId)
			#	#bpy.context.scene.cursor_location = (point.co[0], point.co[1], point.co[2])
			#	#view3d.cursor_location = (point.co[0], point.co[1], point.co[2])
			#	#view3d.cursor_location = (0, 0, 0)
			#	#bpy.ops.object.hook_recenter(modifier = hookTripleId)
			#select_and_change_mode(curveOB, 'OBJECT')
		if self.opt_hideSourceObj:
			makeObjectWireNoRender(active_obj)
		if self.opt_curveAttachType == 'SHRW':
			modifiers = curveOB.modifiers
			shrinkwrap_modifier = modifiers.new(name = "", type = 'SHRINKWRAP')
			shrinkwrap_modifier.offset = 0.0
			shrinkwrap_modifier.target = active_obj
			shrinkwrap_modifier.use_keep_above_surface = True
			#shrinkwrap_modifier.use_negative_direction = True
			shrinkwrap_modifier.use_apply_on_spline = True
			shrinkwrap_modifier.wrap_method = 'NEAREST_SURFACEPOINT'
		select_and_change_mode(active_obj, 'OBJECT')
		return {'FINISHED'}

class WPLc_apply_hooks(bpy.types.Operator):
	bl_idname = "object.wplc_apply_hooks"
	bl_label = "Apply hooks and clean objects"
	bl_options = {'REGISTER', 'UNDO'}


	@classmethod
	def poll(self, context):
		# Check if we have a mesh object active and are in vertex paint mode
		p = context.object and context.object.data and (isinstance(context.scene.objects.active, bpy.types.Object))
		return p

	def execute(self, context):
		active_obj = context.scene.objects.active
		active_mesh = active_obj.data
		select_and_change_mode(active_obj, 'OBJECT')
		hookMods = []
		for md in active_obj.modifiers:
			if md.name.find(kWPLCurveHookPostfix)>=0:
				hookMods.append(md.name)
		for mdname in hookMods:
			md = active_obj.modifiers.get(mdname)
			hookEmpty = md.object
			bpy.ops.object.modifier_apply(apply_as='DATA', modifier=mdname)
			if bpy.data.objects.get(hookEmpty.name) is not None:
				bpy.data.objects.remove(bpy.data.objects[hookEmpty.name], True)
		return {'FINISHED'}

class WPLc_taper_curve(bpy.types.Operator):
	bl_label = "Taper Curve"
	bl_idname = "object.wplc_taper_curve"
	bl_description = "Taper Curve radius over length"
	bl_options = {"REGISTER", "UNDO"}

	opt_RadiusFalloff = FloatProperty(
		name="Radius falloff", description="Radius falloff over strand lenght",
		default=0,
		min=-1, max=1,
		subtype='PERCENTAGE'
	)
	opt_RadiusFlattenForward = FloatProperty(
		name="Flatten Forward", description="Flatten Radius",
		default=0,
		min=0, max=1,
		subtype='PERCENTAGE'
	)
	opt_RadiusFlattenBackward = FloatProperty(
		name="Flatten Backward", description="Flatten Radius",
		default=0,
		min=0, max=1,
		subtype='PERCENTAGE'
	)
	opt_Radius = FloatProperty(
		name="Radius", description="Radius for bezier curve",
		default=1,
		min=0, max=100
	)
	opt_onlySelection = BoolProperty(
		name="Only Selected",
		description="Affect only selected points",
		default=True
	)

	def invoke(self, context, event):
		if bpy.context.mode == 'EDIT':
			self.opt_onlySelection = True
		elif bpy.context.mode == 'OBJECT':
			self.opt_onlySelection = False
		return self.execute(context)

	def execute(self, context):
		def calc_power(cpow):
			if cpow < 0:  # (((OldValue - OldMin) * (NewMax - NewMin)) / (OldMax - OldMin)) + NewMin
				cpow = 1 + cpow * 0.8  # map to 0.5 to 1
			else:
				cpow = 1 + 4 * cpow  # map from 1 to 8
			return cpow
		selectedCurves = [obj for obj in context.selected_objects if obj.type == 'CURVE']
		cpow = calc_power(-self.opt_RadiusFalloff)
		for Curve in selectedCurves:
			curveData = Curve.data
			for polyline in curveData.splines:  # for strand point
				if polyline.type == 'NURBS' or polyline.type == 'POLY':
					points = polyline.points
				else:
					points = polyline.bezier_points
				if self.opt_onlySelection:
					if polyline.type == 'NURBS' or polyline.type == 'POLY':
						points = [point for point in points if point.select]
					else:  # bezier
						points = [point for point in points if point.select_control_point]
				curveLength = len(points)
				for j, point in enumerate(points):  # for strand point
					RadFallofPositiv = math.pow((curveLength - (j + 1)) / curveLength, cpow)
					RadFallofNegativ = math.pow(j / curveLength, cpow)
					RadMIxPositiv = (RadFallofPositiv * (1 - self.opt_RadiusFlattenForward) + self.opt_RadiusFlattenForward)
					RadMIxNegativ = (RadFallofNegativ * (1 - self.opt_RadiusFlattenBackward) + self.opt_RadiusFlattenBackward)
					point.radius = self.opt_Radius * RadMIxPositiv * RadMIxNegativ # apply fallof

		return {"FINISHED"}

class WPLc_adjust_pnt_rt(bpy.types.Operator):
	bl_label = "Smooth tilt/radius"
	bl_idname = "object.wplc_adjust_pnt_rt"
	bl_description = "Smooth tilt/radius"
	bl_options = {"REGISTER", "UNDO"}

	opt_onlySelection = BoolProperty(
		name="Only Selected",
		description="Affect only selected points",
		default=True
	)
	opt_tilt_strength = IntProperty(
		name="Smooth tilt", default=3, min=0, max=10
	)
	opt_tilt_add = FloatProperty(
			name="Additional rotation",
			min=-180.0, max=180.0,
			step=30,
			default=0.0,
	)
	opt_radius_strength = IntProperty(
		name="Smooth radius", default=0, min=0, max=10
	)
	opt_radius_add = FloatProperty(
			name="Additional radius",
			min=-10.0, max=10.0,
			step=0.1,
			default=0.0,
	)
	opt_tilt_revert = BoolProperty(
		name="Revert tilt",
		default=False
	)
	opt_radius_revert = BoolProperty(
		name="Revert radius",
		default=False
	)

	@staticmethod
	def smooth(y, box_pts):
		len_y = len(y)
		smoothed = []
		for i in range(len(y)):
			if box_pts==0:
				smoothed.append(y[i])
				continue
			if box_pts<0:
				smoothed.append(0)
				continue
			low = max(0, i - box_pts)
			hi = min(len_y, i + box_pts)
			smoothed.append(np.sum(y[low:hi]) / (hi - low))  # average
		return smoothed

	def invoke(self, context, event):
		if bpy.context.mode == 'EDIT':
			self.opt_onlySelection = True
		elif bpy.context.mode == 'OBJECT':
			self.opt_onlySelection = False
		return self.execute(context)

	def execute(self, context):
		Curve = context.active_object
		if not Curve.type == 'CURVE':
			self.report({'INFO'}, 'Use operator on curve type object')
			return {"CANCELLED"}
		curveData = Curve.data
		for i, polyline in enumerate(curveData.splines):  # for strand point
			if polyline.type == 'NURBS' or polyline.type == 'POLY':
				points = polyline.points
			else:
				points = polyline.bezier_points
			if self.opt_onlySelection:
				if polyline.type == 'NURBS' or polyline.type == 'POLY':
					points = [point for point in points if point.select]
				else:  # bezier
					points = [point for point in points if point.select_control_point]
			curveTiltList = [curvePoint.tilt for curvePoint in points]
			smoothedTilts = self.smooth(curveTiltList, self.opt_tilt_strength)
			curveRadList = [curvePoint.radius for curvePoint in points]
			smoothedRads = self.smooth(curveRadList, self.opt_radius_strength)
			for j, curvePoint in enumerate(points):
				idxT = j
				idxR = j
				if self.opt_tilt_revert:
					idxT = len(points)-1-idxT
				if self.opt_radius_revert:
					idxR = len(points)-1-idxR
				curvePoint.tilt = smoothedTilts[idxT]+math.radians(self.opt_tilt_add)
				curvePoint.radius = smoothedRads[idxR]+self.opt_radius_add
		return {"FINISHED"}

class WPLc_align_tilt(bpy.types.Operator):
	bl_label = "Align curve tilt"
	bl_idname = "object.wplc_align_tilt"
	bl_description = "Align curve tilt to target surface"
	bl_options = {"REGISTER", "UNDO"}

	opt_onlySelection = BoolProperty(
		name="Only Selected",
		description="Affect only selected points",
		default=True
	)
	opt_influence = FloatProperty(
			name="Influence",
			description="Influence",
			min=-100.0, max=100.0,
			default=1.0,
	)
	opt_tilt_add = FloatProperty(
			name="Additional rotation",
			description="Additional rotation",
			min=-180.0, max=180.0,
			step=30,
			default=0.0,
	)
	opt_fixContnorml = BoolProperty(
		name="Check surface penetration",
		default=True
	)
	@staticmethod
	def angle_signed(vA, vB, vN):  # angle betwen a - b, is vN space
		a = vA.normalized()
		b = vB.normalized()
		adotb = a.dot(b)  # not sure why but cos(x) goes above 1, and below -1   if a= -b
		if a.dot(b) > 1:
			adotb = 1
		elif a.dot(b) < -1:
			adotb = -1
		angle = math.acos(adotb)
		cross = a.cross(b)
		if vN.dot(cross) < 0:  # // Or > 0
			angle = -angle
		return angle

	def invoke(self, context, event):
		if bpy.context.mode == 'EDIT':
			self.opt_onlySelection = True
		elif bpy.context.mode == 'OBJECT':
			self.opt_onlySelection = False
		return self.execute(context)

	def execute(self, context):
		snapTargetName = context.active_object.sourceMeshPointer
		if snapTargetName not in bpy.data.objects.keys():
			self.report({'INFO'}, 'No target to snap to')
			return {"CANCELLED"}
		snapTarget = bpy.data.objects[snapTargetName]
		Curve = context.active_object
		if not Curve.type == 'CURVE':
			self.report({'INFO'}, 'Use operator on curve type object')
			return {"CANCELLED"}

		CurveCopy = Curve.copy()
		CurveCopy.data = CurveCopy.data.copy()
		CurveCopy.data.bevel_object = None  # zero out to prevent changing default one
		CurveCopy.data.resolution_v = 3
		CurveCopy.data.resolution_u = 3
		curveCopyData = CurveCopy.data
		curveCopyData.twist_mode = 'MINIMUM' #'MINIMUM' #'TANGENT'
		curveCopyData.fill_mode = 'HALF'
		curveCopyData.extrude = 0.5
		curveCopyData.bevel_depth = 0.0
		# resetting angles
		for i, polyline in enumerate(curveCopyData.splines):  # for strand point
			if polyline.type == 'NURBS' or polyline.type == 'POLY':
				points = polyline.points
			else:
				points = polyline.bezier_points
			for j, curvePoint in enumerate(points):
				curvePoint.tilt = math.pi / 2
				curvePoint.radius = 0.01
		curveMesh = CurveCopy.to_mesh(context.scene, True, 'PREVIEW')
		bmFromCurve = bmesh.new()
		bmFromCurve.from_mesh(curveMesh)
		bpy.data.meshes.remove(curveMesh)
		bpy.data.objects.remove(CurveCopy, True)
		#context.scene.objects.link(CurveCopy)

		bmFromCurve.transform(Curve.matrix_world)
		bmFromCurve.verts.ensure_lookup_table()
		bmFromCurve.faces.ensure_lookup_table()
		bmFromCurve.verts.index_update()
		bmFromCurve.faces.index_update()
		bvhGlobCurve = BVHTree.FromBMesh(bmFromCurve, epsilon = kRaycastEpsilon)

		snapMesh = snapTarget.to_mesh(context.scene, True, 'PREVIEW')
		bmFromSnap = bmesh.new()
		bmFromSnap.from_mesh(snapMesh)
		bpy.data.meshes.remove(snapMesh)
		bmFromSnap.transform(snapTarget.matrix_world)
		bmFromSnap.verts.ensure_lookup_table()
		bmFromSnap.faces.ensure_lookup_table()
		bmFromSnap.verts.index_update()
		bmFromSnap.faces.index_update()
		bvhGlobSnap = BVHTree.FromBMesh(bmFromSnap, epsilon = kRaycastEpsilon)

		for i, polyline in enumerate(Curve.data.splines):  # for strand point
			if polyline.type == 'NURBS' or polyline.type == 'POLY':
				points = polyline.points
			else:
				points = polyline.bezier_points
			allpoints = points
			if self.opt_onlySelection:
				if polyline.type == 'NURBS' or polyline.type == 'POLY':
					points = [point for point in points if point.select]
				else:  # bezier
					points = [point for point in points if point.select_control_point]
			points_changed = 0
			for j, curvePoint in enumerate(points):  # for strand point
				curvePointGlob = Curve.matrix_world * curvePoint.co.to_3d()
				chitGlob, curveNormal, cface_index, distance = bvhGlobCurve.find_nearest(curvePointGlob)
				if curveNormal is None:
					continue
				shitGlob, snapNormal, sface_index, distance = bvhGlobSnap.find_nearest(curvePointGlob)
				if snapNormal is None:
					continue
				#snapTarget.data.polygons[sface_index].select = True
				curveFace = bmFromCurve.faces[cface_index]
				tangent = curveFace.loops[0].calc_tangent()
				biTangentCurve = tangent.cross(curveNormal)
				vectSurfHitProjected90 = tangent.cross(snapNormal)
				vectSurfHitProjectedToTangent = vectSurfHitProjected90.cross(tangent)
				alignAngle = math.pi/2
				if self.opt_fixContnorml and curveNormal.dot(snapNormal)<0:
					alignAngle = alignAngle-math.pi*2
				angle = self.angle_signed(biTangentCurve, vectSurfHitProjectedToTangent, tangent) + alignAngle # a,b, vN  - signed -180 to 180
				curvePoint.tilt = angle*self.opt_influence + curvePoint.tilt*(1-self.opt_influence) + math.radians(self.opt_tilt_add) # in radians
				points_changed=points_changed+1
		bmFromCurve.free()
		bmFromSnap.free()
		return {"FINISHED"}

class WPLc_upd_ribbons(bpy.types.Operator):
	bl_label = "Update profile"
	bl_idname = "object.wplc_upd_ribbons"
	bl_options = {"REGISTER", "UNDO"}
	bl_description = "Add ribbon to curve profile"

	strandResU = IntProperty(
		name="Segments U", default=3, min=1, max=10, description="Additional subdivision along strand length"
	)
	strandResV = IntProperty(
		name="Segments V", default=2, min=1, max=10, description="Subdivisions perpendicular to strand length "
	)
	strandWidth = FloatProperty(
		name="Strand Width", default=0.5, min=0.0, max=10
	)
	strandPeak = FloatProperty(
		name="Strand peak", default=0.4, min=0.0, max=10,
		description="Describes how much middle point of ribbon will be elevated"
	)
	strandUplift = FloatProperty(
		name="Strand uplift", default=0.0, min=-10, max=10, description="Moves whole ribbon up or down"
	)
	opt_tilt_add = FloatProperty(
		name="Additional tilt",
		min=-180.0, max=180.0,
		step=30,
		default=0.0,
		description="Rotate whole ribbon"
	)

	diagonal  = 0
	# @classmethod
	# def poll(cls, context):  #breaks undo
	#	 return context.active_object.type == 'CURVE'  # bpy.context.scene.render.engine == "CYCLES"

	def invoke(self,context, event):
		if context.active_object.type != 'CURVE':
			self.report({'INFO'}, 'Select curve object first')
			return {"CANCELLED"}
		hairCurve = context.active_object
		# unitsScale = 1 #context.scene.unit_settings.scale_length
		self.diagonal = math.sqrt(pow(hairCurve.dimensions[0], 2) + pow(hairCurve.dimensions[1], 2) + pow(hairCurve.dimensions[2], 2))  # to normalize some values
		bevelObj = hairCurve.data.bevel_object
		if bevelObj:
			points = bevelObj.data.splines[0].points[:]
			self.strandResV = len(points)-1
			self.strandResU = hairCurve.data.resolution_u
		return  self.execute(context)

	def execute(self, context):
		hairCurve = context.active_object
		pointsCo = []
		if self.diagonal==0:
			diagonal = math.sqrt(pow(hairCurve.dimensions[0], 2) + pow(hairCurve.dimensions[1], 2) + pow(hairCurve.dimensions[2], 2))  # to normalize some values
		else:
			diagonal = self.diagonal
		# print("diagonal is :" + str(diagonal))
		# unitsScale = 1 #context.scene.unit_settings.scale_length
		strandWidth = self.strandWidth / 10  * diagonal
		for i in range(self.strandResV + 1):
			x = 2 * i / self.strandResV - 1  # normalise and map from -1 to 1
			pointsCo.append((x * strandWidth , ((1 - x * x) * self.strandPeak + self.strandUplift) * strandWidth  , 0))  # **self.strandWidth to mantain proportion while changing widht
		# create the Curve Datablock
		if hairCurve.data.bevel_object:
			curveBevelObj = hairCurve.data.bevel_object
			curveBevelObj.data.splines.clear()
			BevelCurveData = curveBevelObj.data
		else:
			BevelCurveData = bpy.data.curves.new("sys_"+hairCurve.name+"_bevel", type='CURVE')  # new CurveData
			BevelCurveData.dimensions = '2D'
			curveBevelObj = bpy.data.objects.new("sys_"+hairCurve.name+"_bevel", BevelCurveData)  # new object
			hairCurve.data.bevel_object = curveBevelObj
		bevelSpline = BevelCurveData.splines.new('POLY')  # new spline
		bevelSpline.points.add(len(pointsCo) - 1)
		for i, coord in enumerate(pointsCo):
			x, y, z = coord
			bevelSpline.points[i].co = (x, y, z, 1)
		curveBevelObj.use_fake_user = True
		hairCurve.data.resolution_u = self.strandResU
		hairCurve.data.use_auto_texspace = True
		hairCurve.data.use_uv_as_generated = True
		hairCurve.data.show_normal_face = False
		if abs(self.opt_tilt_add) > 0.01:
			for i, polyline in enumerate(hairCurve.data.splines):  # for strand point
				if polyline.type == 'NURBS' or polyline.type == 'POLY':
					points = polyline.points
				else:
					points = polyline.bezier_points
				for j, curvePoint in enumerate(points):
					curvePoint.tilt = curvePoint.tilt+math.radians(self.opt_tilt_add)
		return {"FINISHED"}

class WPLc_upd_ribbons(bpy.types.Operator):
	bl_label = "Edit profile"
	bl_idname = "object.wplc_edit_ribbon"
	bl_options = {"REGISTER", "UNDO"}
	bl_description = "Edit ribbon curve"

	def invoke(self,context, event):
		if context.active_object.type != 'CURVE':
			self.report({'INFO'}, 'Select curve object first')
			return {"CANCELLED"}
		return  self.execute(context)


	def execute(self, context):
		hairCurve = context.active_object
		bevelObj = hairCurve.data.bevel_object
		if bevelObj is None:
			return {"CANCELLED"}
		scn = context.scene
		if scn.objects.get(bevelObj.name) is None:
			empty = getSysEmpty(context)
			#bevelObj.parent = hairCurve
			bevelObj.parent = empty
			scn.objects.link(bevelObj)
			makeObjectWireNoRender(bevelObj)
			bevelObj.use_fake_user = False
		hairCurve.select = False
		bevelObj.select = True
		select_and_change_mode(bevelObj, 'EDIT')
		bpy.ops.view3d.localview()
		return {"FINISHED"}

class WPLc_ribbon2mesh(bpy.types.Operator):
	bl_label = "Curve to mesh"
	bl_idname = "object.wplc_ribbon2mesh"
	bl_options = {"REGISTER", "UNDO"}
	bl_description = 'Convert curve to mesh object'

	def invoke(self,context, event):
		curveHairs = context.active_object
		if curveHairs.type != "CURVE":
			self.report({'INFO'}, 'You need to select curve ribbon object first')
			return {"CANCELLED"}
		return  self.execute(context)

	def createMeshFromCurve(self,parentCurve):
		meshFromCurve = parentCurve.to_mesh(bpy.context.scene, False, 'PREVIEW')
		meshObjFromCurve = bpy.data.objects.new(parentCurve.name + "_mesh", meshFromCurve)
		bpy.context.scene.objects.link(meshObjFromCurve)
		meshObjFromCurve.select = True
		bpy.context.scene.objects.active = meshObjFromCurve
		meshObjFromCurve.matrix_world = parentCurve.matrix_world
		meshObjFromCurve.color = parentCurve.color
		makeObjectWireNoRender(parentCurve)

	def execute(self, context):
		curveHairs = context.active_object
		bpy.ops.object.mode_set(mode='OBJECT', toggle=False)
		self.createMeshFromCurve(curveHairs)
		return {"FINISHED"}
######################### ######################### #########################
######################### ######################### #########################
bpy.types.Object.sourceMeshPointer = StringProperty(name="Target", description="Target")
class WPLCurveToolsSettings(PropertyGroup):
	bind_targ = StringProperty(
		name="Target object",
		default = ""
	)

class WPLCurveTools_Panel1(bpy.types.Panel):
	bl_label = "Curve tools"
	bl_space_type = 'VIEW_3D'
	bl_region_type = 'TOOLS'
	bl_category = 'WPL'

	@classmethod
	def poll( cls, context ):
		obj = context.active_object
		return obj

	def draw_header(self, context):
		layout = self.layout
		layout.label(text="")

	def draw(self, context):
		obj = context.active_object
		if obj is None:
			return
		#curvetoolsOpts = context.scene.curvetoolsOpts
		layout = self.layout
		col = layout.column()
		if obj.type == 'CURVE' and obj.data.dimensions == '3D':
			isHookCurve = False
			for md in obj.modifiers:
				if md.name.find(kWPLCurveHookPostfix)>=0:
					isHookCurve = True
					break
			col.operator("object.wplc_taper_curve", icon="PARTICLE_POINT")
			col.operator("object.wplc_upd_ribbons", icon="OUTLINER_OB_SURFACE")
			if obj.data.bevel_object is not None:
				col.operator("object.wplc_edit_ribbon", icon="OUTLINER_OB_SURFACE")
			if isHookCurve:
				col.operator("object.wplc_apply_hooks", icon="FILE_REFRESH")
			col.separator()
			col.prop_search(obj, "sourceMeshPointer", context.scene, "objects",icon="SNAP_NORMAL")
			col.operator("object.wplc_align_tilt", icon="SNAP_NORMAL")
			col.operator("object.wplc_adjust_pnt_rt", icon="SNAP_NORMAL")
			col.separator()
			col.operator("object.wplc_ribbon2mesh", icon="FILE_REFRESH")

		if obj.type == 'MESH':
			col.operator("mesh.wpledges2curves", text="Edges to curves")


def register():
	print("WPLCurveTools_Panel1 registered")
	bpy.utils.register_module(__name__)
	bpy.types.Scene.curvetoolsOpts = PointerProperty(type=WPLCurveToolsSettings)

def unregister():
	bpy.utils.unregister_module(__name__)
	bpy.utils.unregister_class(WPLCurveToolsSettings)

if __name__ == "__main__":
	register()
