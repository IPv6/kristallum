# TBD: anti-same-face-hit (face area/face-net deepness)

import bpy
import bmesh
import math
import mathutils
import copy
import time
from random import random, seed
from mathutils import Vector,Matrix
from mathutils import kdtree
from mathutils.bvhtree import BVHTree
from bpy_extras import view3d_utils
from bpy_extras.object_utils import world_to_camera_view

from bpy.props import (StringProperty,
						BoolProperty,
						IntProperty,
						FloatProperty,
						FloatVectorProperty,
						EnumProperty,
						PointerProperty,
						)
from bpy.types import (Panel,
						Operator,
						AddonPreferences,
						PropertyGroup,
						)

bl_info = {
	"name": "WPL Edge builder",
	"author": "IPv6",
	"version": (1, 0, 0),
	"blender": (2, 7, 9),
	"location": "View3D > T-panel > WPL",
	"description" : "",
	"warning"	 : "",
	"wiki_url"	: "",
	"tracker_url" : "",
	"category"	: ""
	}

kWPLSystemEmpty = "zzz_Support"
kWPLVGPostfixRem = "_rem"
kWPLVGPostfixAdd = "_add"
kWPLEdgeLayer = 18
kWPLMinCurveLen = 3

######################### ######################### #########################
######################### ######################### #########################
def force_visible_object(obj):
	if obj:
		if obj.hide == True:
			obj.hide = False
		for n in range(len(obj.layers)):
			obj.layers[n] = False
		current_layer_index = bpy.context.scene.active_layer
		obj.layers[current_layer_index] = True

def select_and_change_mode(obj,obj_mode,hidden=False):
	if obj:
		obj.select = True
		bpy.context.scene.objects.active = obj
		force_visible_object(obj)
		try:
			m = bpy.context.mode
			if bpy.context.mode!='OBJECT':
				bpy.ops.object.mode_set(mode='OBJECT')
			bpy.context.scene.update()
			bpy.ops.object.mode_set(mode=obj_mode)
			#print("Mode switched to ", obj_mode)
		except:
			pass
		obj.hide = hidden
	return m

def getSysEmpty(context,subname):
	emptyname = kWPLSystemEmpty
	if len(subname)>0:
		emptyname = subname
	empty = context.scene.objects.get(emptyname)
	if empty is None:
		empty = bpy.data.objects.new(emptyname, None)
		empty.empty_draw_size = 0.45
		empty.empty_draw_type = 'PLAIN_AXES'
		context.scene.objects.link(empty)
		context.scene.update()
		if len(subname) > 0:
			empty.parent = getSysEmpty(context,"")
	return empty

def camera_pos(region_3d):
	""" Return position, rotation data about a given view for the first space attached to it """
	#https://stackoverflow.com/questions/9028398/change-viewport-angle-in-blender-using-python
	def camera_position(matrix):
		""" From 4x4 matrix, calculate camera location """
		t = (matrix[0][3], matrix[1][3], matrix[2][3])
		r = (
		  (matrix[0][0], matrix[0][1], matrix[0][2]),
		  (matrix[1][0], matrix[1][1], matrix[1][2]),
		  (matrix[2][0], matrix[2][1], matrix[2][2])
		)
		rp = (
		  (-r[0][0], -r[1][0], -r[2][0]),
		  (-r[0][1], -r[1][1], -r[2][1]),
		  (-r[0][2], -r[1][2], -r[2][2])
		)
		output = mathutils.Vector((
		  rp[0][0] * t[0] + rp[0][1] * t[1] + rp[0][2] * t[2],
		  rp[1][0] * t[0] + rp[1][1] * t[1] + rp[1][2] * t[2],
		  rp[2][0] * t[0] + rp[2][1] * t[1] + rp[2][2] * t[2],
		))
		return output
	#look_at = region_3d.view_location
	matrix = region_3d.view_matrix
	#rotation = region_3d.view_rotation
	camera_pos = camera_position(matrix)
	return camera_pos

def get_selected_facesIdx(active_mesh):
	# find selected faces
	bpy.ops.object.mode_set(mode='OBJECT')
	faces = [f.index for f in active_mesh.polygons if f.select]
	# print("selected faces: ", faces)
	return faces

def get_selected_edgesIdx(active_mesh):
	# find selected edges
	bpy.ops.object.mode_set(mode='OBJECT')
	selectedEdgesIdx = [e.index for e in active_mesh.edges if e.select]
	return selectedEdgesIdx

def get_selected_vertsIdx(active_mesh):
	# find selected faces
	bpy.ops.object.mode_set(mode='OBJECT')
	selectedVertsIdx = [e.index for e in active_mesh.vertices if e.select]
	return selectedVertsIdx

def makeObjectNoShadow(c_object, andWire):
	if andWire:
		c_object.draw_type = 'WIRE'
	c_object.hide_render = False
	c_object.cycles_visibility.camera = True
	c_object.cycles_visibility.diffuse = False
	c_object.cycles_visibility.glossy = False
	c_object.cycles_visibility.transmission = False
	c_object.cycles_visibility.scatter = False
	c_object.cycles_visibility.shadow = False

def setLayerForObject(edgeObj,lst):
	for i in range(0,20):
		if i == lst:
			edgeObj.layers[i] = True
		else:
			edgeObj.layers[i] = False

def getObjectWeightsMap(active_object, vgname):
	weights = {}
	vgroup = active_object.vertex_groups.get(vgname)
	if vgroup is not None:
		for index, vert in enumerate(active_object.data.vertices):
			for group in vert.groups:
				if group.group == vgroup.index:
					weights[index] = group.weight
	return weights

def getEdgeVertsForObject(edgeName, active_object, active_bmesh, cameraOrigin_g, visShifting, visEps, visMaxVeFac, vertMaxZdiff):
	def edgeViewAnglMeasure(v0,v1,camPos,antiEdgeDir):
		edg1 = ((v1-v0).normalized())
		if antiEdgeDir is None:
			edg2 = (v0-camPos).normalized()
		else:
			edg2 = antiEdgeDir
		result = abs(edg1.dot(edg2))
		#viewinc = (camPos-v0).length-(camPos-v1).length
		#edg1 = ((v1-v0).normalized())
		#edg2 = (v0-camPos).normalized()
		#result = abs(edg1.dot(edg2))+viewinc*0.5
		return result
	def edgeViewIniMeasure(v0,camPos):
		viewdist = (camPos-v0).length
		result = viewdist*10000-v0[2]*1000+(v0[1]+v0[0])
		return result
	#vertAngOverlap = (0.4,0.4) 	#opt_vertAngOverlap = bpy.props.FloatVectorProperty(name = "View-angle overlapping", size = 2, default	 = (0.4, 0.4),)
	bmesh.ops.subdivide_edges(active_bmesh,edges=active_bmesh.edges[:], cuts=1, use_grid_fill=True, use_single_edge=True)
	active_bmesh.verts.ensure_lookup_table()
	active_bmesh.edges.ensure_lookup_table()
	active_bmesh.faces.ensure_lookup_table()
	active_bmesh.verts.index_update()
	active_bmesh.edges.index_update()
	active_bmesh.faces.index_update()
	vgRemMap = getObjectWeightsMap(active_object, edgeName+kWPLVGPostfixRem)
	vgAddMap = getObjectWeightsMap(active_object, edgeName+kWPLVGPostfixAdd)

	edgeVerts = []
	vertsNearVerts = {}
	verts2CamDist = {}
	verts2IniSort = {}
	verts2CamDir = {}
	vertsAntiEdgeDir = {}
	vertsMaxEdgeLen = {}
	verts2curvestat = {}
	usedVerts = {}
	curves_all = []
	v2rhint = {}
	v2dhint = {}

	cam2objDir = active_object.location - cameraOrigin_g
	cam2objDir.normalize()
	perp1 = cam2objDir.cross(Vector((0,0,1)))
	perp2 = cam2objDir.cross(perp1)
	matrix_world_inv = active_object.matrix_world.inverted()
	cameraOrigin_l = matrix_world_inv * cameraOrigin_g
	bmesh_bvh0 = BVHTree.FromBMesh(active_bmesh, epsilon=0.0)

	# creating BVHTrees
	shiftBVH = []
	shiftDirs = [(0,0,0),perp1*visShifting,perp2*visShifting,-1*perp1*visShifting,-1*perp2*visShifting]
	#[(0,0,0),perp1*visShifting,perp2*visShifting,-1*perp1*visShifting,-1*perp2*visShifting,(perp1+perp2)*visShifting,-1*(perp1+perp2)*visShifting,(perp1-perp2)*visShifting,-1*(perp1-perp2)*visShifting]
	for sdir in shiftDirs:
		#bmesh_d = active_bmesh.copy() #bmesh.new()
		##bmesh.ops.duplicate(active_bmesh, geom=active_bmesh.verts[:] + active_bmesh.edges[:] + active_bmesh.faces[:], dest=bmesh_d)
		#bmesh_d.transform(Matrix.Translation(Vector(sdir)))
		#bmesh_d.verts.ensure_lookup_table()
		#bmesh_d.faces.ensure_lookup_table()
		#bmesh_d.verts.index_update()
		#bmesh_bvh = BVHTree.FromBMesh(bmesh_d, epsilon=0.0)
		#shiftBVH.append((bmesh_bvh, cameraOrigin_l))
		#bmesh_d.free()
		shiftBVH.append((bmesh_bvh0, Vector(sdir)))

	# getting raw contour verts
	print("Getting raw verts...")
	millisA1 = int(round(time.time() * 1000))
	for v in active_bmesh.verts:
		direction = (v.co - cameraOrigin_l).normalized()
		verts2CamDir[v] = direction
		verts2CamDist[v] = (cameraOrigin_l-v.co).length # for ALL verts
		verts2IniSort[v] = edgeViewIniMeasure(v.co,cameraOrigin_l)
		vertsAntiEdgeDir[v] = None
		hit0, normal0, index0, distance0 = bmesh_bvh0.ray_cast(cameraOrigin_l, direction)
		#if v.select: # DBG
		#	print("DBG testing vert:", v, [f.index for f in v.link_faces])
		if v.index in vgRemMap:
			if vgRemMap[v.index] > 0.9:
				continue
		if hit0 is not None:
			# raycast missed -> possible for some normal edge verts, checking futher
			if (hit0 - v.co).length > visEps:
				# invisible vertex, not interested
				continue
		distance0 = verts2CamDist[v]
		antiedgeDir = Vector()
		antiedgeCnt = 0
		for i in range(1,len(shiftBVH)):
			isEdge = False
			if v.index in vgAddMap and vgAddMap[v.index] > 0.1:
				isEdge = True
			if isEdge == False:
				bmesh_bvh = shiftBVH[i][0]
				bmesh_sht = shiftBVH[i][1]
				bmesh_dir = ((v.co + bmesh_sht) - cameraOrigin_l).normalized()
				hit, normal, index, distance = bmesh_bvh.ray_cast(cameraOrigin_l, bmesh_dir)
				#if v.select: # DBG
				#	print("DBG hit:", index, distance)
				if hit is None:
					isEdge = True
				else:
					if distance>distance0 and (hit - v.co).length >= vertMaxZdiff:
						isEdge = True
			if isEdge:
				if v not in edgeVerts:
					vnv = []
					maxedgelen = 0
					for f in v.link_faces:
						for vf in f.verts:
							if vf != v and vf not in vnv:
								vnv.append(vf)
								edglen = (vf.co-v.co).length
								if edglen>maxedgelen:
									maxedgelen = edglen
					vertsMaxEdgeLen[v] = maxedgelen
					vertsNearVerts[v] = vnv
					edgeVerts.append(v)
			else:
				antiedgeCnt = antiedgeCnt+1
				antiedgeDir = antiedgeDir+(hit-v.co)
		if antiedgeCnt>0:
			vertsAntiEdgeDir[v] = (antiedgeDir/antiedgeCnt).normalized()
	millisA2 = int(round(time.time() * 1000))
	print("Done! Verts count="+str(len(edgeVerts))+"; ms="+str(millisA2-millisA1))
	# calc hints
	print("Tracing verts hints...")
	for v in edgeVerts:
		radhint = 1
		if v.index in vgRemMap:
			radhint = radhint*(1.0-vgRemMap[v.index])
		if v.index in vgAddMap:
			radhint = radhint*(2*vgAddMap[v.index])
		if abs(radhint-1.0) > 0.001:
			v2rhint[v] = radhint
		depnDir = -1*v.normal
		hitDepn, normalDepn, indexDepn, distanceDepn = bmesh_bvh0.ray_cast(v.co+depnDir*0.00001, depnDir)
		if hitDepn is not None:
			v2dhint[v] = distanceDepn
	# sorting to simplify beauty edges
	print("Sortings verts...")
	millisB1 = int(round(time.time() * 1000))
	edgeVerts = sorted(edgeVerts,key=lambda v:verts2IniSort[v], reverse=False)
	vertsKD = kdtree.KDTree(len(edgeVerts))
	for i, v in enumerate(edgeVerts):
		vertsKD.insert(v.co, v.index)
	vertsKD.balance()
	#if vertAngOverlap[0]>0.0 and len(edgeVerts)>3:
	#	angdotDiff = 1.0-vertAngOverlap[0]*0.000001
	#	distminDiff = vertAngOverlap[1]
	#	edgeVertsZSort = sorted(edgeVerts,key=lambda v:verts2CamDist[v], reverse=False)
	#	# removing verts, AngOverlapd by at least two verts, closer to camera
	#	AngOverlapdBy = {}
	#	for i in range(0,len(edgeVertsZSort)-1):
	#		v1 = edgeVertsZSort[i]
	#		for j in range(i+1,len(edgeVertsZSort)):
	#			v2 = edgeVertsZSort[j]
	#			if verts2CamDir[v2].dot(verts2CamDir[v1]) > angdotDiff:
	#				if verts2CamDist[v2]-verts2CamDist[v1] > distminDiff:
	#					if v2 not in AngOverlapdBy:
	#						AngOverlapdBy[v2] = 0
	#					AngOverlapdBy[v2] = AngOverlapdBy[v2]+1
	#	edgeVerts2 = []
	#	for v in edgeVerts:
	#		if v in AngOverlapdBy and AngOverlapdBy[v] >= 1:
	#			continue
	#		edgeVerts2.append(v)
	#	edgeVerts = edgeVerts2
	millisB2 = int(round(time.time() * 1000))
	print("Done! ms="+str(millisB2-millisB1))
	# building curves
	print("Building curves...")
	millisC1 = int(round(time.time() * 1000))
	droppedCurves = 0
	while True:
		v_curve = []
		isVadded = False
		isFirstTrackedTo = None
		isLastTrackedTo = None
		for v in edgeVerts:
			if v in usedVerts:
				continue
			isVadded = True
			usedVerts[v] = True
			v_curve.append(v)
			#v2rhint[v] = 999 # DBG
			break
		while isVadded == True:
			isVadded = False
			curve_first = v_curve[0]
			curve_first2 = curve_first
			curve_last = v_curve[-1]
			curve_last2 = curve_last
			if len(v_curve) > 1:
				curve_first2 = v_curve[1]
				curve_last2 = v_curve[-2]
			curve_first_d = verts2CamDist[curve_first]
			curve_last_d = verts2CamDist[curve_last]
			curve_first_prob = []
			curve_last_prob = []

			#nearVerts = edgeVerts
			nearVerts = []
			curve_first_mel = vertsMaxEdgeLen[curve_first]
			kdres_first = vertsKD.find_range(curve_first.co, curve_first_mel)
			kdres_first_verts = [active_bmesh.verts[x[1]] for x in kdres_first]
			nearVerts.extend(kdres_first_verts)
			curve_last_mel = vertsMaxEdgeLen[curve_last]
			kdres_last = vertsKD.find_range(curve_last.co, curve_last_mel)
			kdres_last_verts = [active_bmesh.verts[x[1]] for x in kdres_last]
			nearVerts.extend(kdres_last_verts)
			for v in nearVerts:
				#if v in usedVerts:
				#	continue
				if v == curve_last or v in curve_last_prob:
					continue
				if v == curve_first or v in curve_first_prob:
					continue
				if v in v_curve:
					continue
				if isFirstTrackedTo is None and (curve_first in vertsNearVerts[v]):
					if curve_first2 != curve_first:
						if ((v.co-curve_first.co).normalized()).dot((curve_first2.co-curve_first.co).normalized()) > visMaxVeFac:
							continue
					curve_first_prob.append(v)
					continue
				if isLastTrackedTo is None and (v in vertsNearVerts[curve_last]):
					if curve_last2 != curve_last:
						if ((v.co-curve_last.co).normalized()).dot((curve_last2.co-curve_last.co).normalized()) > visMaxVeFac:
							continue
					curve_last_prob.append(v)
					continue
			if len(curve_last_prob) > 0:
				curve_last_prob = sorted(curve_last_prob,key=lambda v:edgeViewAnglMeasure(v.co, curve_last.co, cameraOrigin_l, vertsAntiEdgeDir[v]), reverse = False)
				v2 = curve_last_prob[0]
				isVadded = True
				if v2 in usedVerts:
					# TBD: effective merge/recut with another curve
					isLastTrackedTo = v2
				usedVerts[v2] = True
				v_curve.append(v2)
			if len(curve_first_prob) > 0:
				curve_first_prob = sorted(curve_first_prob,key=lambda v:edgeViewAnglMeasure(v.co, curve_first.co,cameraOrigin_l, vertsAntiEdgeDir[v]), reverse = False)
				v2 = curve_first_prob[0]
				isVadded = True
				if v2 in usedVerts:
					# TBD: effective merge/recut with another curve
					isFirstTrackedTo = v2
				usedVerts[v2] = True
				v_curve.insert(0, v2)
		curve_len = len(v_curve)
		if curve_len == 0:
			break
		if isFirstTrackedTo is not None or isLastTrackedTo is not None:
			if (isFirstTrackedTo is not None) and (isFirstTrackedTo in verts2curvestat):
				fcl = verts2curvestat[isFirstTrackedTo][0]
			else:
				fcl = 0
			if (isLastTrackedTo is not None) and (isLastTrackedTo in verts2curvestat):
				lcl = verts2curvestat[isLastTrackedTo][0]
			else:
				lcl = 0
			if fcl>curve_len or lcl>curve_len:
				droppedCurves = droppedCurves+1
				continue
		if curve_len < kWPLMinCurveLen:
			droppedCurves = droppedCurves+1
			continue
		curves_all.append(v_curve)
		for v in v_curve:
			verts2curvestat[v] = (curve_len,len(curves_all))
	millisC2 = int(round(time.time() * 1000))
	print("Done! curves="+str(len(curves_all))+"; dropped="+str(droppedCurves)+"; ms="+str(millisC2-millisC1))
	return {"curves":curves_all,"radius":v2rhint,"deeps":v2dhint}
######################### ######################### #########################
######################### ######################### #########################

class WPLbuild_edge( bpy.types.Operator ):
	bl_idname = "object.wplbuild_edge"
	bl_label = "Build edge for selection"
	bl_options = {'REGISTER', 'UNDO'}
	opt_vertSphere = bpy.props.FloatProperty(
		name		= "Test offset",
		default	 = 0.0005,
	)
	opt_vertVisEps = bpy.props.FloatProperty(
		#some "near invisible" verts are OK and needed for continuity
		name		= "Visibility epsilon",
		default	 = 0.3,
	)
	opt_vertZChange = bpy.props.FloatProperty(
		name		= "Z-edge epsilon",
		default	 = 0.005,
	)
	opt_vertVeSharp = bpy.props.FloatProperty(
		name		= "Curvature dot-factor",
		min = -1.0, max = 1.0,
		default	 = 0.0,
	)
	opt_widthProfile = bpy.props.FloatVectorProperty(
		name		= "Width profile",
		size = 2,
		default	 = (0.01, 0.01),
	)
	opt_widthProfilePow = bpy.props.FloatProperty(
		name		= "Width profile pow",
		min = 0.1, max = 10.0,
		default	 = 0.8,
	)
	opt_widthPerDeepn = bpy.props.FloatProperty(
		name		= "Microdeepness level",
		min = 0.0, max = 10.0,
		default	 = 0.04,
	)
	@classmethod
	def poll( cls, context ):
		return (bpy.context.space_data.region_3d.is_perspective)

	def execute( self, context ):
		if not bpy.context.space_data.region_3d.is_perspective:
			self.report({'ERROR'}, "Can`t work in ORTHO mode")
			return {'CANCELLED'}
		sel_all = [o.name for o in bpy.context.selected_objects]
		if len(sel_all) == 0:
			self.report({'ERROR'}, "No objects selected")
			return {'CANCELLED'}
		wplEdgeBuildProps = context.scene.wplEdgeBuildProps
		if len(wplEdgeBuildProps.opt_nameSubstr2skip)>0:
			skipNameParts = [x.strip().lower() for x in wplEdgeBuildProps.opt_nameSubstr2skip.split(",")]
		else:
			skipNameParts = []
		camera_gCo = camera_pos(bpy.context.space_data.region_3d)
		empty = getSysEmpty(context,wplEdgeBuildProps.opt_edgePostfix)
		setLayerForObject(empty,kWPLEdgeLayer)
		changed_edgemeshed = 0
		radiusPow = self.opt_widthProfilePow
		radiusFlattenForward = self.opt_widthProfile[0]
		radiusFlattenBackward = self.opt_widthProfile[1]
		curveMat = None
		if len(wplEdgeBuildProps.opt_Edgemat)>0:
			curveMat = bpy.data.materials.get(wplEdgeBuildProps.opt_Edgemat)
		for i, sel_obj_name in enumerate(sel_all):
			for snp in skipNameParts:
				if sel_obj_name.lower().find(snp) >= 0:
					sel_obj_name = ""
					break
			sel_obj = None
			if len(sel_obj_name)>0:
				sel_obj = context.scene.objects.get(sel_obj_name)
			if sel_obj is None or sel_obj.cycles_visibility.camera == False:
				continue
			sel_mesh = None
			try:
				if sel_obj.parent == empty:
					continue
				sel_mesh = sel_obj.to_mesh(context.scene, True, wplEdgeBuildProps.opt_meshType)
			except:
				pass
			if sel_mesh is None:
				continue
			print("Preparing object "+sel_obj_name+"...")
			sel_bmesh = bmesh.new()
			sel_bmesh.from_mesh(sel_mesh)
			bpy.data.meshes.remove(sel_mesh)
			if sel_bmesh is None:
				continue
			edgeDB = getEdgeVertsForObject(wplEdgeBuildProps.opt_edgePostfix, sel_obj, sel_bmesh, camera_gCo, self.opt_vertSphere, self.opt_vertVisEps, self.opt_vertVeSharp, self.opt_vertZChange)
			vert_curves = edgeDB["curves"]
			vert_rhint = edgeDB["radius"]
			vert_deeps = edgeDB["deeps"]
			print("Making "+str(len(vert_curves))+" curves...")
			#print("vert_curves",vert_curves)
			#print("vert_rhint",vert_rhint)
			#print("vert_deeps",vert_deeps)
			curveData = bpy.data.curves.new(sel_obj_name+"_"+wplEdgeBuildProps.opt_edgePostfix+'_curve', type='CURVE')
			curveData.dimensions = '3D'
			curveData.fill_mode = 'FULL'
			curveData.bevel_depth = wplEdgeBuildProps.opt_edgeWidth
			curveData.bevel_resolution = 2
			curveData.use_fill_caps = True
			curveData.show_normal_face = False
			curveData.splines.clear()
			for curve in vert_curves:
				polyline = curveData.splines.new('NURBS')
				polyline.order_u = 4
				polyline.resolution_u = 10
				polyline.use_endpoint_u = True
				curveLength = len(curve)
				for i,v in enumerate(curve):
					if len(polyline.points) <= i:
						polyline.points.add(1)
					polyline.points[i].co = (v.co[0], v.co[1], v.co[2], 1)
					RadFallofPositiv = math.pow((curveLength - (i + 1)) / curveLength, radiusPow)
					RadFallofNegativ = math.pow(i / curveLength, radiusPow)
					RadMIxPositiv = (RadFallofPositiv * (1 - radiusFlattenForward) + radiusFlattenForward)
					RadMIxNegativ = (RadFallofNegativ * (1 - radiusFlattenBackward) + radiusFlattenBackward)
					RadTotal = 1.0 * RadMIxPositiv * RadMIxNegativ # apply fallof
					if v in vert_rhint:
						RadTotal = RadTotal*vert_rhint[v]
					if self.opt_widthPerDeepn > 0 and v in vert_deeps and vert_deeps[v]<self.opt_widthPerDeepn:
						deepnFac = vert_deeps[v]/self.opt_widthPerDeepn
						RadTotal = RadTotal*max(deepnFac,0.2)
					polyline.points[i].radius = RadTotal
			if len(curveData.splines) == 0:
				continue
			edgeObj = context.scene.objects.get(sel_obj_name+"_"+wplEdgeBuildProps.opt_edgePostfix)
			if edgeObj is not None:
				bpy.data.objects.remove(edgeObj, True)
			edgeObj = bpy.data.objects.new(sel_obj_name+"_"+wplEdgeBuildProps.opt_edgePostfix, curveData)
			edgeObj.matrix_world = sel_obj.matrix_world
			edgeObj.parent = empty
			if curveMat is not None:
				edgeObj.data.materials.append(curveMat)
			makeObjectNoShadow(edgeObj, wplEdgeBuildProps.opt_edgeWiremode)
			followCon = edgeObj.constraints.new('COPY_TRANSFORMS')
			followCon.target = sel_obj
			context.scene.objects.link(edgeObj)
			setLayerForObject(edgeObj,kWPLEdgeLayer)
			curveData.splines[0].order_u = 4
			#curveData.splines[0].resolution_u = 10
			edgeModifiers = edgeObj.modifiers
			shrinkwrap_modifier = edgeModifiers.new(name = "", type = 'SHRINKWRAP')
			shrinkwrap_modifier.offset = 0.0
			shrinkwrap_modifier.target = sel_obj
			shrinkwrap_modifier.use_keep_above_surface = True
			shrinkwrap_modifier.use_apply_on_spline = True
			shrinkwrap_modifier.wrap_method = 'NEAREST_SURFACEPOINT'
			#if wplEdgeBuildProps.opt_edgeSecWidth > 0.0:
			#	edgeObj2 = context.scene.objects.get(sel_obj_name+"_"+wplEdgeBuildProps.opt_edgeSecPostfix)
			#	if edgeObj2 is not None:
			#		bpy.data.objects.remove(edgeObj2, True)
			#	curveData2 = curveData.copy()
			#	curveData2.bevel_depth = wplEdgeBuildProps.opt_edgeSecWidth
			#	edgeObj2 = bpy.data.objects.new(sel_obj_name+"_"+wplEdgeBuildProps.opt_edgeSecPostfix, curveData2)
			#	edgeObj2.matrix_world = sel_obj.matrix_world
			#	edgeObj2.parent = empty
			#	edgeObj2.layers[kWPLEdgeLayer] = True
			#	makeObjectNoShadow(edgeObj2, True)
			#	followCon = edgeObj2.constraints.new('COPY_TRANSFORMS')
			#	followCon.target = sel_obj
			#	context.scene.objects.link(edgeObj2)
			sel_bmesh.free()
			changed_edgemeshed = changed_edgemeshed+1
			print("Object "+str(changed_edgemeshed)+" of "+str(len(sel_all))+" done!")
		self.report({'INFO'}, "Updated "+str(changed_edgemeshed)+" edges of "+str(len(sel_all)))
		return {'FINISHED'}

########## ############ ########## ############ ########## ############
########## ############ ########## ############ ########## ############
class WPLEdgeBuildSettings(PropertyGroup):
	opt_nameSubstr2skip = bpy.props.StringProperty(
		name		= "Skip if object name contain...",
		default	 = "sys_,zzz_"
		)
	opt_Edgemat = StringProperty(
		name="Edge material",
		description="Edge material",
		default = ""
		)
	opt_edgePostfix = bpy.props.StringProperty(
		name		= "Edge object postfix",
		default	 = "sys_edge_d",
	)
	opt_edgeWidth = bpy.props.FloatProperty(
		name		= "Base curve radius",
		default	 = 0.01,
	)
	opt_meshType = bpy.props.EnumProperty(
		name="Mesh Type", default="PREVIEW",
		items=(("PREVIEW", "Preview", ""), ("RENDER", "Render", ""))
	)
	opt_edgeWiremode = bpy.props.BoolProperty(
		name		= "Enable wireframe",
		default	 = False,
	)

class WPLEdgeBuilder_Panel(bpy.types.Panel):
	bl_label = "Edge build"
	bl_space_type = 'VIEW_3D'
	bl_region_type = 'TOOLS'
	bl_category = 'WPL'

	def draw_header(self, context):
		layout = self.layout
		layout.label(text="")

	def draw(self, context):
		wplEdgeBuildProps = context.scene.wplEdgeBuildProps
		layout = self.layout
		col = layout.column()

		col.prop(wplEdgeBuildProps, "opt_nameSubstr2skip")
		col.prop(wplEdgeBuildProps, "opt_edgePostfix")
		col.prop(wplEdgeBuildProps, "opt_edgeWidth")
		col.prop_search(wplEdgeBuildProps, "opt_Edgemat", bpy.data, "materials")
		col.prop(wplEdgeBuildProps, "opt_meshType")
		col.prop(wplEdgeBuildProps, "opt_edgeWiremode")
		col.operator("object.wplbuild_edge", text="Build edge for selection")


def register():
	print("WPLEdgeBuilder_Panel registered")
	bpy.utils.register_module(__name__)
	bpy.types.Scene.wplEdgeBuildProps = PointerProperty(type=WPLEdgeBuildSettings)

def unregister():
	bpy.utils.unregister_module(__name__)
	del bpy.types.Scene.wplEdgeBuildProps
	bpy.utils.unregister_class(WPLEdgeBuildSettings)

if __name__ == "__main__":
	register()
