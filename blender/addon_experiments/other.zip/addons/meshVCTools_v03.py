import bpy
import bmesh
import math
import mathutils
from mathutils import Vector
from random import random, seed
from bpy_extras import view3d_utils
from bpy.props import (StringProperty,
						BoolProperty,
						IntProperty,
						FloatProperty,
						FloatVectorProperty,
						EnumProperty,
						PointerProperty,
						)
from bpy.types import (Panel,
						Operator,
						AddonPreferences,
						PropertyGroup,
						)

bl_info = {
	"name": "WPL VC Bake",
	"author": "IPv6",
	"version": (1, 0, 0),
	"blender": (2, 7, 9),
	"location": "View3D > T-panel > WPL",
	"description": "Bake mesh features into vertext colors/UVMaps.",
	"warning": "",
	"wiki_url": "",
	"tracker_url": "",
	"category": ""}

def get_selected_facesIdx(active_mesh):
	# find selected faces
	bpy.ops.object.mode_set(mode='OBJECT')
	faces = [f.index for f in active_mesh.polygons if f.select]
	# print("selected faces: ", faces)
	return faces
def get_selected_vertsIdx(active_mesh):
	bpy.ops.object.mode_set(mode='OBJECT')
	selectedVertsIdx = [e.index for e in active_mesh.vertices if e.select]
	return selectedVertsIdx

def getF3cValue(indexCur,indexMax,index50,F3c):
	value = 0.0
	if indexCur<index50:
		value = F3c[0]+(F3c[1]-F3c[0])*(indexCur/index50)
	else:
		value = F3c[1]+(F3c[2]-F3c[1])*((indexCur-index50)/(indexMax-index50))
	return value

def addConnectedBmVerts_v01(v, verts_list, selverts):
	v.tag = True
	if (selverts is not None) and (v.index not in selverts):
		return
	if v not in verts_list:
		verts_list.append(v)
	for edge in v.link_edges:
		ov = edge.other_vert(v)
		if (ov is None) or ov.tag:
			continue
		addConnectedBmVerts_v01(ov,verts_list,selverts)

def location_to_region(worldcoords):
	out = view3d_utils.location_3d_to_region_2d(bpy.context.region, bpy.context.space_data.region_3d, worldcoords)
	return out

def region_to_location(viewcoords, depthcoords):
	out = view3d_utils.region_2d_to_location_3d(bpy.context.region, bpy.context.space_data.region_3d, viewcoords, depthcoords)
	return out

def get_active_context_cursor(context):
	scene = context.scene
	space = context.space_data
	cursor = (space if space and space.type == 'VIEW_3D' else scene).cursor_location
	return cursor

def force_visible_object(obj):
	if obj:
		if obj.hide == True:
			obj.hide = False
		for n in range(len(obj.layers)):
			obj.layers[n] = False
		current_layer_index = bpy.context.scene.active_layer
		obj.layers[current_layer_index] = True

def select_and_change_mode(obj,obj_mode,hidden=False):
	if obj:
		obj.select = True
		bpy.context.scene.objects.active = obj
		force_visible_object(obj)
		try:
			m = bpy.context.mode
			if bpy.context.mode!='OBJECT':
				bpy.ops.object.mode_set(mode='OBJECT')
			bpy.context.scene.update()
			bpy.ops.object.mode_set(mode=obj_mode)
			#print("Mode switched to ", obj_mode)
		except:
			pass
		obj.hide = hidden
	return m

class WPLbake_mesh_centers(bpy.types.Operator):
	bl_idname = "object.wplbake_mesh_centers"
	bl_label = "UV: Bake mesh coords"
	bl_options = {'REGISTER', 'UNDO'}

	opt_bakeType = bpy.props.EnumProperty(
		name="Bake Type", default="XZ",
		items=(("XZ", "X-Z", ""), ("YZ", "Y-Z", ""), ("XY", "X-Y", ""))
	)

	@classmethod
	def poll(self, context):
		# Check if we have a mesh object active
		p = context.object and context.object.data and (isinstance(context.scene.objects.active, bpy.types.Object) and isinstance(context.scene.objects.active.data, bpy.types.Mesh))
		return p

	def execute(self, context):
		vc_bakeOpts = context.scene.vc_bakeOpts
		active_object = context.scene.objects.active
		active_mesh = active_object.data
		selverts = get_selected_vertsIdx(active_mesh)
		if len(selverts) == 0:
			operator.report({'ERROR'}, "No faces selected, select some faces first")
			return {'FINISHED'}
		bpy.ops.object.mode_set(mode='OBJECT')

		bakemap_pref = vc_bakeOpts.bake_uvbase
		uv_layer_ob = active_mesh.uv_textures.get(bakemap_pref)
		if uv_layer_ob is None:
			active_mesh.uv_textures.new(bakemap_pref)

		bm = bmesh.new()
		bm.from_mesh(active_mesh)
		bm.verts.ensure_lookup_table()
		bm.faces.ensure_lookup_table()
		bm.verts.index_update()
		#selverts = [e.index for e in bm.verts if e.select]
		#print("selverts",len(selverts))
		uv_values1 = {}
		for v in bm.verts:
			v.tag = False
		for v in bm.verts:
			if v.tag == False:
				meshlist = []
				addConnectedBmVerts_v01(v,meshlist,selverts)
				if len(meshlist) > 0:
					#print("meshlist",len(meshlist))
					medianpoint = mathutils.Vector()
					for mv in meshlist:
						mvco_glob = active_object.matrix_world*mv.co
						medianpoint = medianpoint+mvco_glob
					medianpoint = medianpoint/len(meshlist)
					for mv in meshlist:
						mvco_glob = active_object.matrix_world*mv.co
						#print("vert",mvco_glob,medianpoint)
						uv_values1[mv.index] = mvco_glob-medianpoint
		ok_count = 0
		if len(uv_values1)>0:
			uv_layer_ob = bm.loops.layers.uv.get(bakemap_pref)
			for face in bm.faces:
				for loop in face.loops:
					vert = loop.vert
					if (vert.index in selverts) and (vert.index in uv_values1):
						ok_count = ok_count+1
						coOffset = uv_values1[vert.index]
						if self.opt_bakeType == 'XZ':
							loop[uv_layer_ob].uv = (coOffset[0],coOffset[2])
						if self.opt_bakeType == 'YZ':
							loop[uv_layer_ob].uv = (coOffset[1],coOffset[2])
						if self.opt_bakeType == 'XY':
							loop[uv_layer_ob].uv = (coOffset[0],coOffset[1])
			bm.to_mesh(active_mesh)
		bm.free()
		context.scene.update()
		self.report({'INFO'}, "Vertices baked:" + str(ok_count))
		return {'FINISHED'}

class WPLbake_rndcol_to_vc(bpy.types.Operator):
	bl_idname = "object.wplbake_rndcol_to_vc"
	bl_label = "VC: Bake random color"
	bl_options = {'REGISTER', 'UNDO'}

	@classmethod
	def poll(self, context):
		# Check if we have a mesh object active and are in vertex paint mode
		p = context.object and context.object.data and (isinstance(context.scene.objects.active, bpy.types.Object) and isinstance(context.scene.objects.active.data, bpy.types.Mesh))
		return p

	def execute(self, context):
		print("execute ", self.bl_idname)
		active_object = context.scene.objects.active
		if active_object is None:
			return {'CANCELLED'}
		active_mesh = active_object.data
		selfaces = get_selected_facesIdx(active_mesh)
		if len(selfaces) == 0:
			operator.report({'ERROR'}, "No faces selected, select some faces first")
			return {'CANCELLED'}
		bpy.ops.object.mode_set(mode='EDIT')
		vc_bakeOpts = context.scene.vc_bakeOpts
		color_map = active_object.data.vertex_colors.get(vc_bakeOpts.bake_vcnm)
		if color_map is None:
			self.report({'ERROR'}, "Target VC not found")
			return {'CANCELLED'}

		bm = bmesh.new()
		bm.from_mesh(active_mesh)
		bm.verts.ensure_lookup_table()
		bm.faces.ensure_lookup_table()
		bm.verts.index_update()
		vc_values = {}
		selverts = []
		for v in bm.verts:
			v.tag = False
		for face in bm.faces:
			face_is_selected = face.index in selfaces
			if face_is_selected:
				for vert, loop in zip(face.verts, face.loops):
					selverts.append(vert.index)
		print("Faces selected:", len(selfaces), "; Vertices selected:", len(selverts))
		for v in bm.verts:
			if v.tag == False:
				meshlist = []
				addConnectedBmVerts_v01(v,meshlist,selverts)
				if len(meshlist) > 0:
					rndc = (random(),random(),random(),1.0)
					for ov in meshlist:
						vc_values[ov.index] = rndc
		bpy.ops.object.mode_set(mode='OBJECT')
		context.scene.update()
		color_map = active_object.data.vertex_colors.get(vc_bakeOpts.bake_vcnm)
		color_map.active = True
		if len(vc_values)>0:
			for poly in active_mesh.polygons:
				face_is_selected = poly.index in selfaces
				if face_is_selected:
					ipoly = poly.index
					for idx, ivertex in enumerate(active_mesh.polygons[ipoly].loop_indices):
						ivdx = active_mesh.polygons[ipoly].vertices[idx]
						if (ivdx in vc_values):
							color_map.data[ivertex].color = vc_values[ivdx]
		bpy.ops.object.mode_set(mode='VERTEX_PAINT')
		context.scene.update()
		return {'FINISHED'}

class WPLbake_uv_to_vc(bpy.types.Operator):
	bl_idname = "object.wplbake_uv_to_vc"
	bl_label = "VC: Remap UV to VC"
	bl_options = {'REGISTER', 'UNDO'}

	FacURemap = FloatVectorProperty(
			name="U Remap (0%->50%->100%)",
			description="U Remap",
			size=3,
			min=0.0, max=1.0,
			default=(0.0,0.5,1.0),
	)
	FacUMid = FloatProperty(
			name = "U midpoint",
			min=0.01, max=0.99,
			default = 0.5
	)
	FacVRemap = FloatVectorProperty(
			name = "V Remap (0%->50%->100%)",
			description="V Remap",
			size=3,
			min=0.0, max=1.0,
			default=(0.0,0.5,1.0),
	)
	FacVMid = FloatProperty(
			name = "V midpoint",
			min=0.01, max=0.99,
			default = 0.5
	)
	#OpType = bpy.props.EnumProperty(
	#	name="Operation", default="ASIS",
	#	items=(("ASIS", "U->R, V->G", ""), ("ONLYU", "U->RGB", ""), ("ONLYV", "V->RGB", ""), ("MULUV", "U*V->RGB", ""))
	#)
	ROp = StringProperty(
			name = "R=",
			default = "U"
	)
	GOp = StringProperty(
			name = "G=",
			default = "V"
	)
	BOp = StringProperty(
			name = "B=",
			default = "max(max(R,G),B)"
	)

	@classmethod
	def poll(self, context):
		# Check if we have a mesh object active and are in vertex paint mode
		p = context.object and context.object.data and (isinstance(context.scene.objects.active, bpy.types.Object) and isinstance(context.scene.objects.active.data, bpy.types.Mesh))
		return p

	def execute(self, context):
		print("execute ", self.bl_idname)
		active_object = context.scene.objects.active
		if active_object is None:
			return {'CANCELLED'}
		active_mesh = active_object.data
		selverts = get_selected_vertsIdx(active_mesh)
		if len(selverts) == 0:
			operator.report({'ERROR'}, "No verts selected, select some verts first")
			return {'CANCELLED'}
		vc_bakeOpts = context.scene.vc_bakeOpts
		color_map = active_object.data.vertex_colors.get(vc_bakeOpts.bake_vcnm)
		if color_map is None:
			self.report({'ERROR'}, "Target VC not found")
			return {'CANCELLED'}
		uv_layer = active_mesh.uv_textures.active
		if uv_layer is None:
			self.report({'ERROR'}, "Active UV not found")
			return {'CANCELLED'}

		RopCode = None
		GopCode = None
		BopCode = None
		try:
			RopCode = compile(self.ROp, "<string>", "eval")
			GopCode = compile(self.GOp, "<string>", "eval")
			BopCode = compile(self.BOp, "<string>", "eval")
		except:
			self.report({'ERROR'}, "RGB ops: syntax error")
			return {'CANCELLED'}
		bm = bmesh.new()
		bm.from_mesh(active_mesh)
		bm.verts.ensure_lookup_table()
		bm.faces.ensure_lookup_table()
		bm.verts.index_update()
		uv_layer_ob = bm.loops.layers.uv.get(uv_layer.name)
		vertUvMap = {}
		for face in bm.faces:
			for vert, loop in zip(face.verts, face.loops):
				if (vert.index in selverts):
					vertUvMap[vert.index] = loop[uv_layer_ob].uv
		color_map = active_object.data.vertex_colors.get(vc_bakeOpts.bake_vcnm)
		for poly in active_mesh.polygons:
			for loop_index in range(poly.loop_start, poly.loop_start + poly.loop_total):
				vi = active_mesh.loops[loop_index].vertex_index
				if (vi in vertUvMap):
					oldColor = color_map.data[loop_index].color
					R = oldColor[0]
					G = oldColor[1]
					B = oldColor[2]
					U = getF3cValue(vertUvMap[vi][0],1.0,self.FacUMid,self.FacURemap)
					V = getF3cValue(vertUvMap[vi][1],1.0,self.FacVMid,self.FacVRemap)
					newR = eval(RopCode)
					newG = eval(GopCode)
					newB = eval(BopCode)
					color_map.data[loop_index].color = (newR,newG,newB)
		color_map.active = True
		bpy.ops.object.mode_set(mode='VERTEX_PAINT')
		return {'FINISHED'}

class WPLvert_selvccol( bpy.types.Operator ):
	bl_idname = "mesh.wplvert_selvccol"
	bl_label = "Pick faces by Brush color"
	bl_options = {'REGISTER', 'UNDO'}
	opt_colFuzz = bpy.props.FloatProperty(
		name		= "HSV color distance",
		default	 = 0.3
	)
	@classmethod
	def poll( cls, context ):
		return ( context.object is not None  and
				context.object.type == 'MESH' and
				context.area.type == 'VIEW_3D' and context.vertex_paint_object)

	def current_brush(self, context):
		if context.area.type == 'VIEW_3D' and context.vertex_paint_object:
			brush = context.tool_settings.vertex_paint.brush
		elif context.area.type == 'VIEW_3D' and context.image_paint_object:
			brush = context.tool_settings.image_paint.brush
		elif context.area.type == 'IMAGE_EDITOR' and  context.space_data.mode == 'PAINT':
			brush = context.tool_settings.image_paint.brush
		else :
			brush = None
		return brush

	def execute( self, context ):
		active_object = context.scene.objects.active
		active_mesh = active_object.data
		if not active_mesh.vertex_colors:
			self.report({'ERROR'}, "Active object has no Vertex color layer")
			return {'CANCELLED'}
		select_and_change_mode(active_object,"VERTEX_PAINT")
		active_mesh.use_paint_mask = True
		br = self.current_brush(context)
		if br:
			#print("brush color:",br.color)
			basecol = Vector((br.color[0],br.color[1],br.color[2]))
			baselayr = active_mesh.vertex_colors.active
			vertx2sel = []
			for ipoly in range(len(active_mesh.polygons)):
				for idx, ivertex in enumerate(active_mesh.polygons[ipoly].loop_indices):
					ivdx = active_mesh.polygons[ipoly].vertices[idx]
					if (ivdx not in vertx2sel) and (baselayr.data[ivertex].color is not None):
						vcol = baselayr.data[ivertex].color
						dist = Vector((vcol[0],vcol[1],vcol[2]))
						if (dist-basecol).length <= self.opt_colFuzz:
							#print("Near color:",dist,basecol)
							vertx2sel.append(ivdx)
			select_and_change_mode(active_object,"OBJECT")
			for idx in vertx2sel:
				active_mesh.vertices[idx].select = True
			select_and_change_mode(active_object,"EDIT")
			bpy.context.tool_settings.mesh_select_mode = (True, False, False)
			select_and_change_mode(active_object,"VERTEX_PAINT")
		return {'FINISHED'}

class WPLvert_pickvccol( bpy.types.Operator ):
	bl_idname = "mesh.wplvert_pickvccol"
	bl_label = "Pick VC color from selection"
	bl_options = {'REGISTER', 'UNDO'}
	@classmethod
	def poll( cls, context ):
		return ( context.object is not None  and
				context.object.type == 'MESH' and
				context.area.type == 'VIEW_3D' and context.vertex_paint_object)

	def current_brush(self, context):
		if context.area.type == 'VIEW_3D' and context.vertex_paint_object:
			brush = context.tool_settings.vertex_paint.brush
		elif context.area.type == 'VIEW_3D' and context.image_paint_object:
			brush = context.tool_settings.image_paint.brush
		elif context.area.type == 'IMAGE_EDITOR' and  context.space_data.mode == 'PAINT':
			brush = context.tool_settings.image_paint.brush
		else :
			brush = None
		return brush

	def execute( self, context ):
		active_object = context.scene.objects.active
		active_mesh = active_object.data
		if not active_mesh.vertex_colors:
			self.report({'ERROR'}, "Active object has no Vertex color layer")
			return {'CANCELLED'}
		select_and_change_mode(active_object,"OBJECT")
		selfaces = get_selected_facesIdx(active_mesh)
		select_and_change_mode(active_object,"VERTEX_PAINT")
		if len(selfaces) < 1:
			self.report({'ERROR'}, "Not enough verts, select verts first")
			return {'CANCELLED'}
		br = self.current_brush(context)
		if br:
			baselayr = active_mesh.vertex_colors.active
			vertx2cols = None
			vertx2cnt = 0
			for ipoly in range(len(active_mesh.polygons)):
				if ipoly in selfaces:
					for idx, ivertex in enumerate(active_mesh.polygons[ipoly].loop_indices):
						ivdx = active_mesh.polygons[ipoly].vertices[idx]
						if vertx2cnt == 0:
							vertx2cols = mathutils.Vector(baselayr.data[ivertex].color)
						else:
							vertx2cols = vertx2cols + mathutils.Vector(baselayr.data[ivertex].color)
						vertx2cnt = vertx2cnt+1
			br.color = mathutils.Vector((vertx2cols[0],vertx2cols[1],vertx2cols[2]))/vertx2cnt
		return {'FINISHED'}

######### ############ ################# ############
class WPLVCBakeSettings(PropertyGroup):
	bake_uvbase = StringProperty(
		name="Target UV",
		description="Bake into set of UVMaps",
		default = "Eye_XZ"
		)
	bake_vcnm = StringProperty(
		name="Target VC",
		description="Target VC",
		default = ""
		)

class WPLBakeMeshFeatures_Panel2(bpy.types.Panel):
	bl_label = "UV/VC bake"
	bl_space_type = 'VIEW_3D'
	bl_region_type = 'TOOLS'
	bl_category = 'WPL'

	def draw(self, context):
		layout = self.layout
		vc_bakeOpts = context.scene.vc_bakeOpts
		active_object = context.scene.objects.active
		col = layout.column()
		if active_object is not None and active_object.data is not None:
			obj_data = active_object.data
			if obj_data is not None:
				col.label("VC: Selection")
				col.prop_search(vc_bakeOpts, "bake_vcnm", obj_data, "vertex_colors", icon='GROUP_VCOL')
				col.operator("object.wplbake_rndcol_to_vc", text="Bake random color")
				col.operator("object.wplbake_uv_to_vc", text="Remap UV to VC (eval)")
				col.separator()
				col.label("UV: Selection")
			col.prop_search(vc_bakeOpts, "bake_uvbase", obj_data, "uv_layers", icon='GROUP_UVS')
			col.operator("object.wplbake_mesh_centers", text="Bake local space (island centers)")

class WPLPaintSelect_Panel(bpy.types.Panel):
	bl_label = "WPL: VC Selection"
	bl_space_type = 'VIEW_3D'
	bl_region_type = 'TOOLS'
	bl_category = 'Tools'

	def draw_header(self, context):
		layout = self.layout
		layout.label(text="")

	def draw(self, context):
		layout = self.layout
		col = layout.column()

		col.separator()
		col.operator("mesh.wplvert_pickvccol", text="Pick color from faces")
		col.operator("mesh.wplvert_selvccol", text="Pick faces by Brush color")

def register():
	print("WPLBakeMeshFeatures_Panel register")
	bpy.utils.register_module(__name__)
	bpy.types.Scene.vc_bakeOpts = PointerProperty(type=WPLVCBakeSettings)

def unregister():
	print("WPLBakeMeshFeatures_Panel unregister")
	bpy.utils.unregister_module(__name__)
	del bpy.types.Scene.vc_bakeOpts
	bpy.utils.unregister_class(WPLVCBakeSettings)

if __name__ == "__main__":
	register()
