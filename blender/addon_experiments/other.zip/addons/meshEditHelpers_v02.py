import bpy
import bmesh
import math
import mathutils
from mathutils import Vector, Matrix
from random import random, seed
from mathutils.bvhtree import BVHTree
from bpy_extras import view3d_utils
from bpy_extras.object_utils import world_to_camera_view

from bpy.props import (StringProperty,
						BoolProperty,
						IntProperty,
						FloatProperty,
						FloatVectorProperty,
						EnumProperty,
						PointerProperty,
						)
from bpy.types import (Panel,
						Operator,
						AddonPreferences,
						PropertyGroup,
						)

bl_info = {
	"name": "WPL Mesh Helpers",
	"author": "IPv6",
	"version": (1, 0, 0),
	"blender": (2, 7, 9),
	"location": "View3D > T-panel > WPL",
	"description" : "",
	"warning"	 : "",
	"wiki_url"	: "",
	"tracker_url" : "",
	"category"	: ""
	}

kRaycastEpsilon = 0.0001
kRaycastDeadzone = 0.0

def force_visible_object(obj):
	if obj:
		if obj.hide == True:
			obj.hide = False
		for n in range(len(obj.layers)):
			obj.layers[n] = False
		current_layer_index = bpy.context.scene.active_layer
		obj.layers[current_layer_index] = True

def select_and_change_mode(obj,obj_mode,hidden=False):
	if obj:
		obj.select = True
		bpy.context.scene.objects.active = obj
		force_visible_object(obj)
		try:
			m = bpy.context.mode
			if bpy.context.mode!='OBJECT':
				bpy.ops.object.mode_set(mode='OBJECT')
			bpy.context.scene.update()
			bpy.ops.object.mode_set(mode=obj_mode)
			#print("Mode switched to ", obj_mode)
		except:
			pass
		obj.hide = hidden
	return m

def camera_pos(region_3d):
	""" Return position, rotation data about a given view for the first space attached to it """
	#https://stackoverflow.com/questions/9028398/change-viewport-angle-in-blender-using-python
	def camera_position(matrix):
		""" From 4x4 matrix, calculate camera location """
		t = (matrix[0][3], matrix[1][3], matrix[2][3])
		r = (
		  (matrix[0][0], matrix[0][1], matrix[0][2]),
		  (matrix[1][0], matrix[1][1], matrix[1][2]),
		  (matrix[2][0], matrix[2][1], matrix[2][2])
		)
		rp = (
		  (-r[0][0], -r[1][0], -r[2][0]),
		  (-r[0][1], -r[1][1], -r[2][1]),
		  (-r[0][2], -r[1][2], -r[2][2])
		)
		output = mathutils.Vector((
		  rp[0][0] * t[0] + rp[0][1] * t[1] + rp[0][2] * t[2],
		  rp[1][0] * t[0] + rp[1][1] * t[1] + rp[1][2] * t[2],
		  rp[2][0] * t[0] + rp[2][1] * t[1] + rp[2][2] * t[2],
		))
		return output
	#look_at = region_3d.view_location
	matrix = region_3d.view_matrix
	#rotation = region_3d.view_rotation
	camera_pos = camera_position(matrix)
	return camera_pos

def get_selected_facesIdx(active_mesh):
	# find selected faces
	bpy.ops.object.mode_set(mode='OBJECT')
	faces = [f.index for f in active_mesh.polygons if f.select]
	# print("selected faces: ", faces)
	return faces

def get_selected_edgesIdx(active_mesh):
	# find selected faces
	bpy.ops.object.mode_set(mode='OBJECT')
	selectedEdgesIdx = [e.index for e in active_mesh.edges if e.select]
	return selectedEdgesIdx

def get_selected_vertsIdx(active_mesh):
	# find selected faces
	bpy.ops.object.mode_set(mode='OBJECT')
	selectedVertsIdx = [e.index for e in active_mesh.vertices if e.select]
	return selectedVertsIdx

def fuzzySceneRayCast_v02(vFrom, vDir, fuzzyVal, fuzzyQual, objs2ignore):
	gResult = mathutils.Vector((0,0,0))
	gResultNormal = mathutils.Vector((0,0,0))
	gCount = 0.0;
	vDirs = [vDir.normalized()]
	if fuzzyVal > 0.0:
		perpBase = mathutils.Vector((0,0,1))
		if(math.fabs(vDir.dot(perpBase)) > 0.9):
			perpBase = mathutils.Vector((0,1,0))
		perp1 = vDir.cross(perpBase)
		perp2 = vDir.cross(perp1)
		vDirs = [vDir.normalized()]
		for i in range(0,fuzzyQual):
			delim = float(i+1)/float(fuzzyQual)
			slice = [(vDir+delim*perp1*fuzzyVal).normalized(), (vDir-delim*perp1*fuzzyVal).normalized(), (vDir+delim*perp2*fuzzyVal).normalized(), (vDir-delim*perp2*fuzzyVal).normalized()]
			vDirs.extend(slice)

	for shootDir in vDirs:
		(result, loc_g, normal, index, object, matrix) = bpy.context.scene.ray_cast(vFrom+vDir*kRaycastEpsilon, shootDir)
		#print("fuzzySceneRayCast", vFrom, shootDir, result, loc_g)
		if result and (objs2ignore is None or object.name not in objs2ignore):
			gCount = gCount+1.0
			gResult = gResult+loc_g
			gResultNormal = gResultNormal+normal

	if gCount>0:
		return (gResult/gCount,gResultNormal/gCount)
	return (None, None)

def fuzzyBVHRayCast_v01(bvh, vFrom, vDir, fuzzyVal, fuzzyQual):
	gResult = mathutils.Vector((0,0,0))
	gResultNormal = mathutils.Vector((0,0,0))
	gCount = 0.0;
	vDirs = [vDir.normalized()]
	if fuzzyVal > 0.0:
		perpBase = mathutils.Vector((0,0,1))
		if(math.fabs(vDir.dot(perpBase)) > 0.9):
			perpBase = mathutils.Vector((0,1,0))
		perp1 = vDir.cross(perpBase)
		perp2 = vDir.cross(perp1)
		vDirs = [vDir.normalized()]
		for i in range(0,fuzzyQual):
			delim = float(i+1)/float(fuzzyQual)
			slice = [(vDir+delim*perp1*fuzzyVal).normalized(), (vDir-delim*perp1*fuzzyVal).normalized(), (vDir+delim*perp2*fuzzyVal).normalized(), (vDir-delim*perp2*fuzzyVal).normalized()]
			vDirs.extend(slice)

	for shootDir in vDirs:
		loc_g, normal, index, distance = bvh.ray_cast(vFrom+vDir*kRaycastEpsilon, shootDir)
		#print("fuzzySceneRayCast", vFrom, shootDir, result, loc_g)
		if loc_g is not None:
			gCount = gCount+1.0
			gResult = gResult+loc_g
			gResultNormal = gResultNormal+normal

	if gCount>0:
		return (gResult/gCount,gResultNormal/gCount)
	return (None, None)

def getBmEdgesAsStrands_v01(bm, vertsIdx, edgesIdx, opt_flowDirP, opt_edgeStep):
	# looking for bounding verts
	bndVerts = []
	opt_flowDir = Vector(opt_flowDirP)
	opt_flowDir = opt_flowDir.normalized()
	for vIdx in vertsIdx:
		v = bm.verts[vIdx]
		edgeDirs = []
		edgeLens = 0
		edgeLensC = 0
		for e in v.link_edges:
			if e.index in edgesIdx:
				flowfir = (e.other_vert(v).co-v.co).normalized()
				flowdot = flowfir.dot(opt_flowDir)
				flowang = math.acos(flowdot)
				edgeDirs.append(flowang)
			else:
				edgeLens = edgeLens+e.calc_length()
				edgeLensC = edgeLensC+1
		if len(edgeDirs) == 1:
			bndVerts.append((vIdx, edgeDirs[0],edgeLens/(edgeLensC+0.001)))
	if len(bndVerts)<2 or len(bndVerts)%2 == 1:
		return (None, None, None)
	bndVerts.sort(key=lambda ia: ia[1], reverse=False)
	strands_points = []
	strands_radius = []
	strands_vidx = []
	checked_verts = []
	#print("bndVerts", bndVerts)
	for ia in bndVerts:
		vIdx = ia[0]
		points_co = None
		points_idx = None
		canContinue = True
		while canContinue == True:
			#print("Checking vIdx", vIdx)
			if vIdx in checked_verts:
				canContinue = False
				continue
			checked_verts.append(vIdx)
			if points_co is None:
				points_co = []
				points_idx = []
				strands_points.append(points_co)
				strands_vidx.append(points_idx)
				strands_radius.append(ia[2])
			v = bm.verts[vIdx]
			points_idx.append([v.index])
			points_co.append(v.co)
			canContinue = False
			for e in v.link_edges:
				if e.index in edgesIdx:
					vIdx = e.other_vert(v).index
					if vIdx not in checked_verts:
						canContinue = True
						break
	#print("strands_points", strands_points, strands_vidx)
	if(opt_edgeStep > 1):
		# repacking
		strands_points2 = []
		strands_vidx2 = []
		for i,points_co in enumerate(strands_points):
			points_co2 = []
			points_idx2 = []
			strands_points2.append(points_co2)
			strands_vidx2.append(points_idx2)
			lastIdxList = None
			for j in range(len(points_co)):
				if j == 0 or (j%opt_edgeStep) == 0 or j == len(points_co)-1:
					if j < len(points_co)-1:
						lastIdxList = strands_vidx[i][j]
					else:
						lastIdxList.append(strands_vidx[i][j][0])
					points_co2.append(points_co[j])
					points_idx2.append(lastIdxList)
				else:
					lastIdxList.append(strands_vidx[i][j][0])
		#print("strands_points2", strands_points2, strands_vidx2)
		strands_points = strands_points2
		strands_vidx = strands_vidx2
	return (strands_points, strands_radius, strands_vidx)
	
def getF3cValue(indexCur,indexMax,index50,F3c):
	value = 0.0
	if indexCur<index50:
		value = F3c[0]+(F3c[1]-F3c[0])*(indexCur/index50)
	else:
		value = F3c[1]+(F3c[2]-F3c[1])*((indexCur-index50)/(indexMax-index50))
	return value
	
def cutLongEdges(active_mesh, seledgesIdx, context, opt_edgelen, method ):
	bpy.ops.object.mode_set( mode = 'EDIT' )
	bpy.ops.mesh.select_mode(type="FACE")
	bm = bmesh.from_edit_mesh( active_mesh )
	changesCount = 0
	long_edges = None
	if method == 0:
		long_edges = [ e for e in bm.edges if e.calc_length() >= opt_edgelen and e.index in seledgesIdx ]
	if method == 1:
		long_edges = []
		sorted_edges = [ e for e in bm.edges ]
		sorted_edges.sort(key=lambda e: e.calc_length(), reverse=True)
		facesused = []
		for e in sorted_edges:
			isEok = False
			if e.index in seledgesIdx:
				for f in e.link_faces:
					if f not in facesused and f.calc_area() >= opt_edgelen:
						facesused.append(f)
						isEok = True
			if isEok and e not in long_edges:
				long_edges.append(e)
	if not long_edges or len(long_edges) == 0:
		return 0
	result = bmesh.ops.subdivide_edges(
		bm,
		edges=long_edges,
		cuts=1
		#use_single_edge=True,
		#use_grid_fill=True
	)
	splitgeom = result['geom_split']
	#for face in filter(lambda e: isinstance(e, bmesh.types.BMFace), splitgeom):
	#	if face not in out_faces:
	#		out_faces.append(face)
	out_verts = []
	out_faces = []
	bm.verts.ensure_lookup_table()
	bm.faces.ensure_lookup_table()
	bm.verts.index_update()
	for vert in filter(lambda e: isinstance(e, bmesh.types.BMVert), splitgeom):
		if vert not in out_verts:
			out_verts.append(vert)
			changesCount = changesCount+1
	for f in bm.faces:
		for v in f.verts:
			if v in out_verts:
				out_faces.append(f)
				break
	trianggeom = bmesh.ops.triangulate( bm, faces=out_faces )
	for f in out_faces:
		f.select = True
	for f in trianggeom["faces"]:
		f.select = True
	# update, while in edit mode
	# thanks to ideasman42 for making this clear
	# http://blender.stackexchange.com/questions/414/
	bmesh.update_edit_mesh( active_mesh )
	# bpy.context.scene.update()
	return changesCount

class WPLsubdiv_long_edges( bpy.types.Operator ):
	bl_idname = "mesh.wplsubdiv_long_edges"
	bl_label = "Subdiv Long Edges"
	bl_options = {'REGISTER', 'UNDO'}
	opt_edgelen = bpy.props.FloatProperty(
		name		= "Edge Length",
		description = "Min len for subdiv",
		default	 = 0.5,
		min		 = 0.001,
		max		 = 999
		)

	@classmethod
	def poll( cls, context ):
		return ( context.object is not None  and
				context.object.type == 'MESH' )

	def execute( self, context ):
		active_object = context.scene.objects.active
		active_mesh = active_object.data
		seledgesIdx = get_selected_edgesIdx(active_mesh)
		if len(seledgesIdx) == 0:
			self.report({'ERROR'}, "No faces selected, select some faces first")
			return {'CANCELLED'}
		changesCount = cutLongEdges(active_mesh, seledgesIdx, context, self.opt_edgelen, 0 )
		self.report({'INFO'}, "Verts added: "+str(changesCount))
		return {'FINISHED'}

class WPLsubdiv_big_faces( bpy.types.Operator ):
	bl_idname = "mesh.wplsubdiv_big_faces"
	bl_label = "Smart subdiv"
	bl_options = {'REGISTER', 'UNDO'}
	opt_facearea = bpy.props.FloatProperty(
		name		= "Face area",
		description = "Min area for subdiv",
		default	 = 1.0,
		min		 = 0.000001,
		max		 = 999
		)

	@classmethod
	def poll( cls, context ):
		return ( context.object is not None  and
				context.object.type == 'MESH' )

	def execute( self, context ):
		active_object = context.scene.objects.active
		active_mesh = active_object.data
		seledgesIdx = get_selected_edgesIdx(active_mesh)
		if len(seledgesIdx) == 0:
			self.report({'ERROR'}, "No faces selected, select some faces first")
			return {'CANCELLED'}
		changesCount = cutLongEdges(active_mesh, seledgesIdx, context, self.opt_facearea, 1 )
		self.report({'INFO'}, "Verts added: "+str(changesCount))
		return {'FINISHED'}

class WPLstripify_edge( bpy.types.Operator ):
	bl_idname = "mesh.wplstripify_edge"
	bl_label = "Stripify selected edges"
	bl_options = {'REGISTER', 'UNDO'}

	TWidthF3c = FloatVectorProperty(
			name="Width (0%->50%->100%)",
			size=3,
			min=0.001, max=100.0,
			default=(0.1,0.1,0.1),
	)
	SHeightF3c = FloatVectorProperty(
			name="Height (0%->50%->100%)",
			size=3,
			min=-100.0, max=100.0,
			default=(0.01,0.01,0.01),
	)
	TRotationF3c = FloatVectorProperty(
			name="Rotation (0%->50%->100%)",
			size=3,
			min=-1, max=1,
			default=(0.0,0.0,0.0),
	)
	SRotationF3c = FloatVectorProperty(
			name="Edge Rotation (0%->50%->100%)",
			size=3,
			min=-1, max=1,
			default=(0.0,0.0,0.0),
	)
	FacMid = FloatProperty(
			name="Middle point",
			min=0.0, max=1.0,
			default=0.5,
	)
	opt_Solidify = BoolProperty(
		name="Solidify stripe",
		default=True
	)
	
	@classmethod
	def poll( cls, context ):
		return ( context.object is not None  and
				context.object.type == 'MESH' )
	def execute( self, context ):
		active_object = context.scene.objects.active
		active_mesh = active_object.data
		vertsIdx = get_selected_vertsIdx(active_mesh)
		edgesIdx = get_selected_edgesIdx(active_mesh)
		if len(edgesIdx)<1:
			self.report({'ERROR'}, "No selected edges found, select some edges first")
			return {'CANCELLED'}
		bpy.ops.object.mode_set( mode = 'EDIT' )
		#bpy.ops.mesh.select_mode(type="FACE")
		bm = bmesh.from_edit_mesh(active_mesh)
		bm.verts.ensure_lookup_table()
		bm.verts.index_update()
		(strands_points,strands_radius,strands_vidx) = getBmEdgesAsStrands_v01(bm, vertsIdx, edgesIdx, Vector((0,0,1)), 1)
		if strands_points is None:
			self.report({'ERROR'}, "Looped edges found, can`t work on looped edges")
			return {'CANCELLED'}
		#print("strands_points:",strands_points)
		vIdx_cache = {}
		def getVertsForStrokePoint(bm,vIdx,flowDir,point_num,mid_num,las_num):
			if vIdx in vIdx_cache:
				return vIdx_cache[vIdx]
			bm.verts.ensure_lookup_table()
			bm.verts.index_update()
			s3d = bm.verts[vIdx].co
			cen_dr = bm.verts[vIdx].normal
			cen_flow = flowDir.normalized() #s3d-bm.verts[prevIdx].co
			
			l_width = getF3cValue(point_num,las_num,mid_num,self.TWidthF3c)
			h_offset = getF3cValue(point_num,las_num,mid_num,self.SHeightF3c)
			r_angl_s = getF3cValue(point_num,las_num,mid_num,self.SRotationF3c)*math.pi
			r_angl_t = getF3cValue(point_num,las_num,mid_num,self.TRotationF3c)*math.pi+r_angl_s
			cen_flow = cen_flow.normalized()
			cen_dr = cen_dr.normalized()
			cen_perp = cen_dr.cross(cen_flow)
			r_mat_s = Matrix.Rotation(r_angl_s, 4, cen_flow)
			cen_dr = r_mat_s*cen_dr
			cen_perp_vec = cen_perp*l_width
			r_mat_t = Matrix.Rotation(r_angl_t, 4, cen_flow)
			cen_perp_vec = r_mat_t*cen_perp_vec
			cen_p = s3d+cen_dr*h_offset
			v1_p = (cen_p+cen_perp_vec)
			v2_p = (cen_p-cen_perp_vec)
			v1 = bm.verts.new(v1_p)
			v2 = bm.verts.new(v2_p)
			if self.opt_Solidify:
				cen_p2 = s3d-cen_dr*h_offset
				v3_p = (cen_p2+cen_perp_vec)
				v4_p = (cen_p2-cen_perp_vec)
				v3 = bm.verts.new(v3_p)
				v4 = bm.verts.new(v4_p)
				vIdx_cache[vIdx] = (v1,v2,v4,v3)
			else:
				vIdx_cache[vIdx] = (v1,v2)
			#print("New points",vIdx,vIdx_cache[vIdx],cen_p,cen_dr,cen_perp)
			return vIdx_cache[vIdx]
		for i, strand_curve in enumerate(strands_points):
			if len(strand_curve) < 2:
				continue
			lastVertIdx = 0
			flowDir = Vector((0,0,0))
			las_num = len(strand_curve)
			mid_num = las_num * self.FacMid
			for j, co in enumerate(strand_curve):
				vIdx = strands_vidx[i][j][0]
				if j > 0:
					coLast = strand_curve[j-1]
					coThis = strand_curve[j]
					flowDir = coThis-coLast
					##########################################
					v_prev = getVertsForStrokePoint(bm,lastVertIdx,flowDir,j,mid_num,las_num)
					v_this = getVertsForStrokePoint(bm,vIdx,flowDir,j,mid_num,las_num)
					bm.faces.new([v_prev[0],v_prev[1],v_this[1],v_this[0]])
					if self.opt_Solidify:
						bm.faces.new([v_prev[1],v_prev[2],v_this[2],v_this[1]])
						bm.faces.new([v_prev[2],v_prev[3],v_this[3],v_this[2]])
						bm.faces.new([v_prev[3],v_prev[0],v_this[0],v_this[3]])
					##########################################
				lastVertIdx = vIdx
				
		bm.verts.ensure_lookup_table()
		bm.faces.ensure_lookup_table()
		bm.verts.index_update()
		bm.normal_update()
		bmesh.update_edit_mesh(active_mesh, True)
		return {'FINISHED'}
		
class WPLrefill_select( bpy.types.Operator ):
	bl_idname = "mesh.wplrefill_select"
	bl_label = "Refill selection"
	bl_options = {'REGISTER', 'UNDO'}

	@classmethod
	def poll( cls, context ):
		return ( context.object is not None  and
				context.object.type == 'MESH' )

	def execute( self, context ):
		active_object = context.scene.objects.active
		active_mesh = active_object.data
		selvertsAll = get_selected_vertsIdx(active_mesh)
		bpy.ops.object.mode_set( mode = 'EDIT' )
		bpy.ops.mesh.region_to_loop()
		selvertsBnd = get_selected_vertsIdx(active_mesh)
		selvertsInner = list(filter(lambda plt: plt not in selvertsBnd, selvertsAll))
		bpy.ops.object.mode_set( mode = 'EDIT' )
		if len(selvertsInner) == 0:
			self.report({'ERROR'}, "No inner vertices found")
			#print("All: ",selvertsAll," outer:", selvertsBnd)
			return {'CANCELLED'}
		bm = bmesh.from_edit_mesh(active_mesh)
		verts_select = [f for f in bm.verts if f.index in selvertsInner]
		bmesh.ops.delete(bm, geom=verts_select, context=1)
		bmesh.update_edit_mesh(active_mesh)
		#bpy.ops.mesh.fill_grid(use_interp_simple = True)
		bpy.ops.mesh.fill()
		bpy.ops.mesh.faces_shade_smooth()
		return {'FINISHED'}

class WPLdissolve_sharpfaces( bpy.types.Operator ):
	bl_idname = "mesh.wpldissolve_sharpfaces"
	bl_label = "Dissolve sharp faces"
	bl_options = {'REGISTER', 'UNDO'}

	opt_genType = bpy.props.EnumProperty(
		name="Dissolve Type", default="SLCT",
		items=(("EDGES", "Dissolve edges", ""), ("VERTS", "Dissolve verts", ""), ("SLCT", "Just select", ""))
	)
	opt_Angle = bpy.props.FloatProperty(
		name		= "Angle",
		description = "Angle",
		default	 = 20.0,
		min		 = 0.1,
		max		 = 180
	)

	@classmethod
	def poll( cls, context ):
		return ( context.object is not None  and
				context.object.type == 'MESH' )

	def execute( self, context ):
		#### Calculates the angle between two pairs of points in space.
		def orientation_difference(points_A_co, points_B_co): # each parameter should be a list with two elements, and each element should be a x,y,z coordinate.
			vec_A = points_A_co[0] - points_A_co[1]
			vec_B = points_B_co[0] - points_B_co[1]
			angle = vec_A.angle(vec_B)
			if angle > 0.5 * math.pi:
				angle = abs(angle - math.pi)
			return angle
		active_object = context.scene.objects.active
		active_mesh = active_object.data
		selfacesIdx = get_selected_facesIdx(active_mesh)
		if len(selfacesIdx) == 0:
			self.report({'ERROR'}, "No faces selected")
			return {'CANCELLED'}
		bpy.ops.object.mode_set( mode = 'EDIT' )
		if self.opt_genType == 'SLCT':
			bpy.ops.mesh.select_all(action = 'DESELECT')
		bpy.ops.mesh.select_mode(type="FACE")
		changesCount = 0
		bm = bmesh.from_edit_mesh(active_mesh)
		bm.verts.index_update()
		bm.edges.index_update()
		bm.faces.index_update()
		bm.verts.ensure_lookup_table()
		bm.edges.ensure_lookup_table()
		bm.faces.ensure_lookup_table()
		selFaces = []
		for fIdx in selfacesIdx:
			selFaces.append(bm.faces[fIdx])
		changes = 0
		for f in reversed(selFaces):
			try:
				edgesEx = f.edges[:]
				edgesEx.append(f.edges[0])
			except:
				break
			for i in range(0,len(edgesEx)-1):
				try:
					e1 = edgesEx[i]
					e2 = edgesEx[i+1]
					if orientation_difference([e1.verts[0].co,e1.verts[1].co], [e2.verts[0].co,e2.verts[1].co])*180/math.pi < self.opt_Angle:
						if self.opt_genType == 'SLCT':
							#edg = f.edges[:]
							#bmesh.ops.collapse(bm,edges = list(edg), uvs = True)
							f.select = True
							for e in f.edges:
								e.select = True
								for v in e.verts:
									v.select = True
						if self.opt_genType == 'EDGES':
							edg = f.edges[:]
							bmesh.ops.dissolve_edges(bm, edges=list(edg))
						if self.opt_genType == 'VERTS':
							vrt = f.verts[:]
							bmesh.ops.dissolve_verts(bm, verts=list(vrt))
						changes = changes+1
				except:
					pass
		bm.normal_update()
		bmesh.update_edit_mesh(active_mesh) # without this flush bmesh.ops.collapse will CRASH!
		self.report({'INFO'}, "Faces handled: "+str(changesCount))
		return {'FINISHED'}

class WPLdissolve_shortedges( bpy.types.Operator ):
	bl_idname = "mesh.wpldissolve_shortedges"
	bl_label = "Dissolve short edges"
	bl_options = {'REGISTER', 'UNDO'}
	opt_genType = bpy.props.EnumProperty(
		name="Dissolve Type", default="VERTS",
		items=(("EDGES", "Dissolve edge", ""), ("VERTS", "Dissolve verts", ""), ("SLCT", "Just select", ""))
	)
	opt_edgelen = bpy.props.FloatProperty(
		name		= "Edge Length",
		description = "Max len for dissolve",
		default	 = 0.01,
		min		 = 0.001,
		max		 = 999
	)

	@classmethod
	def poll( cls, context ):
		return ( context.object is not None  and
				context.object.type == 'MESH' )

	def execute( self, context ):
		active_object = context.scene.objects.active
		active_mesh = active_object.data
		seledgesIdx = get_selected_edgesIdx(active_mesh)
		if len(seledgesIdx) == 0:
			self.report({'ERROR'}, "No edges selected, select some edges first")
			return {'CANCELLED'}
		bpy.ops.object.mode_set( mode = 'EDIT' )
		if self.opt_genType == 'SLCT':
			bpy.ops.mesh.select_all(action = 'DESELECT')
		bpy.ops.mesh.select_mode(type="EDGE")
		bm = bmesh.from_edit_mesh( active_mesh )
		bm.verts.ensure_lookup_table()
		bm.edges.ensure_lookup_table()
		bm.verts.index_update()
		bm.edges.index_update()
		short_edges = [ e for e in bm.edges if e.calc_length() <= self.opt_edgelen and e.index in seledgesIdx ]
		changesCount = 0
		for e in reversed(short_edges):
			try:
				if self.opt_genType == 'SLCT':
					#bmesh.ops.collapse(bm,edges = [e], uvs = True)
					e.select = True
					for v in e.verts:
						v.select = True
				if self.opt_genType == 'EDGES':
					bmesh.ops.dissolve_edges(bm, edges=[e])
				if self.opt_genType == 'VERTS':
					vrt = e.verts[:]
					bmesh.ops.dissolve_verts(bm, verts=list(vrt))
				changesCount = changesCount+1
			except:
				pass
		bm.normal_update()
		bmesh.update_edit_mesh(active_mesh) # without this flush bmesh.ops.collapse will CRASH!
		#bpy.ops.object.mode_set( mode = 'EDIT' )
		self.report({'INFO'}, "Edges handled: "+str(changesCount))
		return {'FINISHED'}

class WPLproj_bubble( bpy.types.Operator ):
	bl_idname = "mesh.wplproj_bubble"
	bl_label = "Bubble verts into direction"
	bl_options = {'REGISTER', 'UNDO'}

	opt_flatnMeth = EnumProperty(
		items = [
			('TO_CAMERA', "To camera", "", 1),
			('MESH_NORMALS', "Mesh Normals", "", 2),
			('SCENE_NORMALS', "Scene Normals", "", 3),
		],
		name="Method",
		description="Method",
		default='TO_CAMERA',
	)
	opt_flatnFac = bpy.props.FloatProperty(
		name		= "Influence",
		default	 = 1.0,
		min		 = -100,
		max		 = 100
	)
	opt_heightAbv = bpy.props.FloatProperty(
		name		= "Additional height",
		default	 = 0.0,
		min		 = -100,
		max		 = 100
	)
	opt_maxDist = bpy.props.FloatProperty(
		name		= "Max distance",
		default	 = 100.0,
		min		 = 0.001,
		max		 = 100
		)
	opt_fuzzrcFac = bpy.props.FloatProperty(
		name		= "Fuzzy bubbling",
		default	 = 0.0,
		min		 = 0,
		max		 = 10
	)

	@classmethod
	def poll( cls, context ):
		return ( context.object is not None  and
				context.object.type == 'MESH' )

	def execute( self, context ):
		active_object = context.scene.objects.active
		active_mesh = active_object.data
		if not bpy.context.space_data.region_3d.is_perspective:
			self.report({'ERROR'}, "Can`t work in ORTHO mode")
			return {'CANCELLED'}
		cameraOrigin_g = camera_pos(bpy.context.space_data.region_3d)
		selvertsAll = get_selected_vertsIdx(active_mesh)
		if len(selvertsAll) == 0:
			self.report({'ERROR'}, "No selected vertices found")
			return {'CANCELLED'}
		#unselvertsAll = [e.index for e in active_mesh.vertices if e.index not in selvertsAll]
		bpy.ops.object.mode_set( mode = 'EDIT' )
		bm = bmesh.from_edit_mesh(active_mesh)
		bm.verts.ensure_lookup_table()
		bm.faces.ensure_lookup_table()
		bm.verts.index_update()

		bm2 = bm.copy()
		bm2.verts.ensure_lookup_table()
		bm2.faces.ensure_lookup_table()
		bm2.verts.index_update()
		v2r = []
		for selvIdx in selvertsAll:
			v2r.append(bm2.verts[selvIdx])
		for v2r_v in v2r:
			bm2.verts.remove(v2r_v)
			bm2.verts.ensure_lookup_table()
			bm2.faces.ensure_lookup_table()
			bm2.verts.index_update()
		bm2_tree = BVHTree.FromBMesh(bm2, epsilon = kRaycastEpsilon)
		bm2.free()
		# tracing to new geometry
		collIgnore = [active_object.name]
		matrix_world_inv = active_object.matrix_world.inverted()
		matrix_world_norm = matrix_world_inv.transposed().to_3x3()
		cameraOrigin = matrix_world_inv * cameraOrigin_g
		inner_verts = [ (vIdx, bm.verts[vIdx].co, bm.verts[vIdx].normal) for vIdx in selvertsAll ]
		opt_normdir = 1
		if self.opt_flatnFac < 0 and (self.opt_flatnMeth == 'MESH_NORMALS' or self.opt_flatnMeth == 'SCENE_NORMALS'):
			opt_normdir = -1
		for w_v in inner_verts:
			hit = None
			if self.opt_flatnMeth == 'TO_CAMERA':
				direction = w_v[1] - cameraOrigin
				direction.normalize()
				hit, normal = fuzzyBVHRayCast_v01(bm2_tree, cameraOrigin, direction, self.opt_fuzzrcFac, 10)
			if self.opt_flatnMeth == 'MESH_NORMALS':
				origin = w_v[1]
				direction = w_v[2]
				direction.normalize()
				hit, normal = fuzzyBVHRayCast_v01(bm2_tree, origin+kRaycastDeadzone*direction*opt_normdir, direction*opt_normdir, self.opt_fuzzrcFac, 10)
			if self.opt_flatnMeth == 'SCENE_NORMALS':
				origin = active_object.matrix_world*w_v[1]
				direction = matrix_world_norm * w_v[2]
				hit_g, normal = fuzzySceneRayCast_v02(origin+kRaycastDeadzone*direction*opt_normdir, direction*opt_normdir, self.opt_fuzzrcFac, 10, collIgnore)
				if hit_g is not None:
					hit = matrix_world_inv*hit_g
			if (hit is not None) and ((w_v[1]-hit).length <= self.opt_maxDist):
				# lerping position
				hit = w_v[1]+w_v[2]*(hit - w_v[1]).length
				vco_shift = hit - w_v[1]
				vco = w_v[1]+vco_shift*abs(self.opt_flatnFac)
				vco = vco+self.opt_heightAbv*normal
				bm.verts[w_v[0]].co = vco
		bmesh.update_edit_mesh(active_mesh, True)
		return {'FINISHED'}

class WPLbridge_cirkpunch( bpy.types.Operator ):
	bl_idname = "mesh.wplbridge_cirkpunch"
	bl_label = "Star-break faces"
	bl_options = {'REGISTER', 'UNDO'}

	opt_iters = bpy.props.IntProperty(
		name		= "Iterations",
		description = "Iterations",
		default	 = 1,
		min		 = 1,
		max		 = 100
		)

	@classmethod
	def poll( cls, context ):
		return ( context.object is not None  and
				context.object.type == 'MESH' )

	def execute( self, context ):
		active_object = context.scene.objects.active
		active_mesh = active_object.data
		selfaceAll = get_selected_facesIdx(active_mesh)
		if len(selfaceAll) == 0:
			self.report({'ERROR'}, "No selected faces found")
			return {'CANCELLED'}

		bpy.ops.object.mode_set( mode = 'EDIT' )
		bm = bmesh.from_edit_mesh( active_mesh )
		bm.verts.ensure_lookup_table()
		bm.faces.ensure_lookup_table()
		bm.verts.index_update()
		iters = self.opt_iters
		facemap= {}
		edgmap = []
		for selfi in selfaceAll:
			face = bm.faces[selfi]
			facemap[selfi] = (face, face.calc_center_median())
			for edg in face.edges:
				if edg not in edgmap:
					edgmap.append(edg)
		for edg in edgmap:
			bm.verts.ensure_lookup_table()
			bm.faces.ensure_lookup_table()
			bm.verts.index_update()
			result = bmesh.ops.subdivide_edges(
				bm,
				edges=[edg],
				cuts=self.opt_iters
			)
		for selfi in selfaceAll:
			bm.verts.ensure_lookup_table()
			bm.faces.ensure_lookup_table()
			bm.verts.index_update()
			face = facemap[selfi][0]
			cenpos = facemap[selfi][1]
			facesnew = bmesh.ops.extrude_discrete_faces(bm, faces = [face], use_select_history = False)
			other_verts = [v for v in facesnew["faces"][0].verts]
			for v in other_verts:
				v.co = cenpos
			bmesh.ops.remove_doubles(bm, verts=other_verts, dist=0.01)

		bm.verts.ensure_lookup_table()
		bm.faces.ensure_lookup_table()
		bm.verts.index_update()
		bmesh.update_edit_mesh( active_mesh )
		return {'FINISHED'}

class WPLSculptFeatures_Panel(bpy.types.Panel):
	bl_label = "Sculpt helpers"
	bl_space_type = 'VIEW_3D'
	bl_region_type = 'TOOLS'
	bl_category = 'WPL'

	def draw_header(self, context):
		layout = self.layout
		layout.label(text="")

	def draw(self, context):
		layout = self.layout
		col = layout.column()

		col.separator()
		col.label("Bubbling")
		col.operator("mesh.wplproj_bubble", text="Bubble verts (Same mesh, Camera)").opt_flatnMeth = 'TO_CAMERA'
		col.operator("mesh.wplproj_bubble", text="Bubble verts (Same mesh, Normals)").opt_flatnMeth = 'MESH_NORMALS'
		col.operator("mesh.wplproj_bubble", text="Bubble verts (Scene, Normals)").opt_flatnMeth = 'SCENE_NORMALS'

		col.separator()
		col.label("Modifying")
		col.operator("mesh.wplrefill_select", text="ReFill selected")
		col.operator("mesh.wplbridge_cirkpunch", text="Star-break faces")
		col.operator("mesh.wplstripify_edge", text="Stripify edges")

		col.separator()
		col.operator("mesh.wpldissolve_sharpfaces", text="Dissolve sharp faces")
		col.operator("mesh.wpldissolve_shortedges", text="Dissolve short edges")
		col.separator()
		col.operator("mesh.wplsubdiv_big_faces", text="Cut big Faces")
		col.operator("mesh.wplsubdiv_long_edges", text="Cut long Edges")

def register():
	print("WPLSculptFeatures_Panel registered")
	bpy.utils.register_module(__name__)

def unregister():
	bpy.utils.unregister_module(__name__)

if __name__ == "__main__":
	register()
