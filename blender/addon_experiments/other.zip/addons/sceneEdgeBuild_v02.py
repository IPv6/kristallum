# TBD: preliminar reject of full-I-oriented vertex
# TBD: post-optimizing ucrves: collapse dense into straight
# TBD: Loop-distance replace with min geom distance (and very max for loops too) - extend area until dist < minimum
# TBD: edge-cross jumps -> due loop dist too big?
# jumpy edges are really bad thing... force manual streamlining in PH

import math
import copy
import mathutils
import time
import random
from random import random, seed

import bpy
from bpy.props import *
import bpy.types
import bmesh
from mathutils import Vector, Matrix
from mathutils import kdtree
from mathutils.bvhtree import BVHTree


bl_info = {
	"name": "WPL Edge builder",
	"author": "IPv6",
	"version": (1, 0, 0),
	"blender": (2, 7, 9),
	"location": "View3D > T-panel > WPL",
	"description" : "",
	"warning"	 : "",
	"wiki_url"	: "",
	"tracker_url" : "",
	"category"	: ""
	}

kWPLSystemEmpty = "zzz_Support"
kWPL_VCHint_CnlRem = 0 #Red
kWPL_VCHint_CnlAdd = 1 #Green
kWPLMinCurveLen = 3

######################### ######################### #########################
######################### ######################### #########################
def getSysEmpty(context,subname):
	emptyname = kWPLSystemEmpty
	if len(subname)>0:
		emptyname = subname
	empty = context.scene.objects.get(emptyname)
	if empty is None:
		empty = bpy.data.objects.new(emptyname, None)
		empty.empty_draw_size = 0.45
		empty.empty_draw_type = 'PLAIN_AXES'
		context.scene.objects.link(empty)
		context.scene.update()
		if len(subname) > 0:
			empty.parent = getSysEmpty(context,"")
	return empty

def select_and_change_mode(obj, obj_mode):
	#print("select_and_change_mode",obj_mode)
	if obj_mode == "EDIT_MESH":
		obj_mode = "EDIT"
	if obj_mode == "PAINT_VERTEX":
		obj_mode = "VERTEX_PAINT"
	for objx in bpy.data.objects:
		objx.select = False
	if obj:
		obj.select = True
		bpy.context.scene.objects.active = obj
		if obj.hide == True:
			obj.hide = False
		for n in range(len(obj.layers)):
			obj.layers[n] = False
		current_layer_index = bpy.context.scene.active_layer
		obj.layers[current_layer_index] = True
		try:
			m = bpy.context.mode
			if bpy.context.mode!='OBJECT':
				bpy.ops.object.mode_set(mode='OBJECT')
			bpy.context.scene.update()
			bpy.ops.object.mode_set(mode=obj_mode)
			#print("Mode switched to ", obj_mode)
		except:
			pass
	return m

def curve_getSelectedPolys(curveData, andDesel):
	selected_polys = []
	for polyline in curveData.splines:
		if polyline.type == 'NURBS' or polyline.type == 'POLY':
			points = [point for point in polyline.points if point.select]
			if len(points)>0:
				selected_polys.append([point for point in polyline.points])
				if andDesel:
					for point in points:
						point.select = False
	return selected_polys

def curve_rescaleRadius(poly, radF3c, mid_fac, baseRadius):
	radiusAtStart = radF3c[0]
	radiusAtEnd = radF3c[1]
	radiusPow = radF3c[2]
	curveLength = float(len(poly))
	if curveLength>1:
		mid_fac = min(0.99,max(0.01,mid_fac))
		for i,p in enumerate(poly):
			curve_fac = float(i) / (curveLength-1)
			if curve_fac<mid_fac:
				RadTotal = radiusAtStart+(1.0-radiusAtStart)*(curve_fac/mid_fac)
			else:
				RadTotal = radiusAtEnd+(1.0-radiusAtEnd)*(1.0-(curve_fac-mid_fac)/mid_fac)
			RadTotal = max(0.00001,RadTotal)
			RadTotal = pow(RadTotal,radiusPow)
			p.radius = RadTotal*baseRadius

def camera_pos(region_3d):
	""" Return position, rotation data about a given view for the first space attached to it """
	#https://stackoverflow.com/questions/9028398/change-viewport-angle-in-blender-using-python
	def camera_position(matrix):
		""" From 4x4 matrix, calculate camera location """
		t = (matrix[0][3], matrix[1][3], matrix[2][3])
		r = (
		  (matrix[0][0], matrix[0][1], matrix[0][2]),
		  (matrix[1][0], matrix[1][1], matrix[1][2]),
		  (matrix[2][0], matrix[2][1], matrix[2][2])
		)
		rp = (
		  (-r[0][0], -r[1][0], -r[2][0]),
		  (-r[0][1], -r[1][1], -r[2][1]),
		  (-r[0][2], -r[1][2], -r[2][2])
		)
		output = mathutils.Vector((
		  rp[0][0] * t[0] + rp[0][1] * t[1] + rp[0][2] * t[2],
		  rp[1][0] * t[0] + rp[1][1] * t[1] + rp[1][2] * t[2],
		  rp[2][0] * t[0] + rp[2][1] * t[1] + rp[2][2] * t[2],
		))
		return output
	#look_at = region_3d.view_location
	matrix = region_3d.view_matrix
	#rotation = region_3d.view_rotation
	camera_pos = camera_position(matrix)
	return camera_pos

def get_selected_facesIdx(active_mesh):
	# find selected faces
	bpy.ops.object.mode_set(mode='OBJECT')
	faces = [f.index for f in active_mesh.polygons if f.select]
	# print("selected faces: ", faces)
	return faces

def get_selected_edgesIdx(active_mesh):
	# find selected edges
	bpy.ops.object.mode_set(mode='OBJECT')
	selectedEdgesIdx = [e.index for e in active_mesh.edges if e.select]
	return selectedEdgesIdx

def get_selected_vertsIdx(active_mesh):
	# find selected faces
	bpy.ops.object.mode_set(mode='OBJECT')
	selectedVertsIdx = [e.index for e in active_mesh.vertices if e.select]
	return selectedVertsIdx


def get_bmhistory_vertsIdx(active_bmesh):
	active_bmesh.verts.ensure_lookup_table()
	active_bmesh.verts.index_update()
	selectedVertsIdx = []
	for elem in active_bmesh.select_history:
		if isinstance(elem, bmesh.types.BMVert) and elem.select:
			selectedVertsIdx.append(elem.index)
	return selectedVertsIdx

def makeObjectNoShadow(c_object, andWire):
	if andWire is not None and andWire == True:
		c_object.draw_type = 'WIRE'
	c_object.hide_render = False
	c_object.cycles_visibility.camera = True
	c_object.cycles_visibility.diffuse = False
	c_object.cycles_visibility.glossy = False
	c_object.cycles_visibility.transmission = False
	c_object.cycles_visibility.scatter = False
	c_object.cycles_visibility.shadow = False

def attachEdgeToSourceObject(edgeObj,sel_obj):
	edgeObj.matrix_world = sel_obj.matrix_world
	#setLayerForObject(edgeObj,kWPLEdgeLayer)
	if len(edgeObj.constraints) == 0:
		# important for curves
		followCon = edgeObj.constraints.new('COPY_TRANSFORMS')
		followCon.target = sel_obj
	edgeModifiers = edgeObj.modifiers
	if (edgeModifiers.get('WPL_Edge2src') is None) and (sel_obj.type != 'CURVE'):
		shrinkwrap_modifier = edgeModifiers.new(name = "WPL_Edge2src", type = 'SHRINKWRAP')
		shrinkwrap_modifier.offset = 0.0
		shrinkwrap_modifier.target = sel_obj
		shrinkwrap_modifier.use_keep_above_surface = True
		shrinkwrap_modifier.use_apply_on_spline = True
		shrinkwrap_modifier.wrap_method = 'NEAREST_SURFACEPOINT'

def getObjectWeightsMap(active_object, vgname):
	weights = {}
	vgroup = active_object.vertex_groups.get(vgname)
	if vgroup is not None:
		for index, vert in enumerate(active_object.data.vertices):
			for group in vert.groups:
				if group.group == vgroup.index:
					weights[index] = group.weight
	return weights

def getBMeshVertLoops_v01(v, verts_set_out, max_loops):
	if (v in verts_set_out):
		return
	if v.hide:
		return
	verts_set_out.add(v)
	for edge in v.link_edges:
		ov = edge.other_vert(v)
		if (ov is None) or (ov in verts_set_out):
			continue
		if max_loops > 0:
			getBMeshVertLoops_v01(ov, verts_set_out, max_loops-1)

def getBMeshVCMap(active_bmesh, vcname):
	vccols = {}
	color_map = None
	try:
		color_map = active_bmesh.loops.layers.color.get(vcname)
	except:
		pass
	if color_map is not None:
		for face in active_bmesh.faces:
			for loop in face.loops:
				ivdx = loop.vert.index
				color = loop[color_map]
				newc = [color[0],color[1],color[2]]
				if (ivdx in vccols):
					prevc = vccols[ivdx]
					newc[0] = max(newc[0],prevc[0])
					newc[1] = max(newc[1],prevc[1])
					newc[2] = max(newc[2],prevc[2])
				vccols[ivdx] = newc
	#print("getBMeshVCMap",vccols)
	return vccols

def getEdgeVertsForObject(edgeName, active_object, active_bmesh, cameraOrigin_g, params):
	hintVCname = params["hintVCname"]
	vertRaycShift = params["vertRaycShift"]
	vertMaxZdiff = params["vertMaxZdiff"]
	vertMaxLdiff = params["vertMaxLdiff"]
	visEdgeEps = params["visEdgeEps"]
	visConnDst = params["visConnDst"]
	visMinSpace = params["visMinSpace"]
	visAllInciNormDot = params["visAllInciNormDot"]
	optmMinSpaceMul = params["optmMinSpaceMul"]
	#optmCurveDot = params["optmCurveDot"]
	#optmEdgedDot = params["optmEdgedDot"]
	optmNormSmtDot = params["optmNormSmtDot"]

	active_bmesh.transform(active_object.matrix_world)
	bmesh.ops.recalc_face_normals(active_bmesh, faces=active_bmesh.faces)
	#matrix_world_inv = active_object.matrix_world.inverted()
	#cameraOrigin_l = matrix_world_inv * cameraOrigin_g
	cameraOrigin_l = cameraOrigin_g
	#def edgeViewIniMeasure(v0,camPos):
	#	viewdist = (camPos-v0).length
	#	result = viewdist*10000-v0[2]*1000+(v0[1]*10+v0[0])
	#	return result
	if vertMaxLdiff<1:
		vertMaxLdiff = 1
	active_bmesh.verts.ensure_lookup_table()
	active_bmesh.edges.ensure_lookup_table()
	active_bmesh.faces.ensure_lookup_table()
	active_bmesh.verts.index_update()
	active_bmesh.edges.index_update()
	active_bmesh.faces.index_update()
	vcHintsMap = getBMeshVCMap(active_bmesh, hintVCname)

	edgeVerts = []
	vertsNearVerts = {}
	vertsNearVertsByLoop = {}
	verts2CamDst = {}
	verts2CamDir = {}
	vertsAntiEdgeDir = {}
	#vertsMaxEdgeLen = {}
	verts2curvestat = {}
	curves_all = []
	v2rhint = {}
	#v2dhint = {}

	cam2objDir = active_object.location - cameraOrigin_g
	cam2objDir.normalize()
	perp1 = cam2objDir.cross(Vector((0,0,1)))
	perp2 = cam2objDir.cross(perp1)
	bmesh_bvh0 = BVHTree.FromBMesh(active_bmesh, epsilon=0.0)

	# creating BVHTrees
	shiftBVH = []
	shiftDirs = [(0,0,0),perp1*vertRaycShift,perp2*vertRaycShift,-1*perp1*vertRaycShift,-1*perp2*vertRaycShift]
	for sdir in shiftDirs:
		shiftBVH.append((bmesh_bvh0, Vector(sdir)))

	# getting raw contour verts
	print("- Gathering verts, initial count="+str(len(active_bmesh.verts)))
	millisA1 = int(round(time.time() * 1000))
	allVerts = []
	for v in active_bmesh.verts:
		if v.hide:
			continue
		verts2CamDst[v] = (cameraOrigin_l-v.co).length # for ALL verts
		direction = (v.co - cameraOrigin_l).normalized()
		verts2CamDir[v] = direction
		if direction.dot(v.normal) < visAllInciNormDot:
			continue
		allVerts.append(v)
	#allVerts = sorted(allVerts,key=lambda v:edgeViewIniMeasure(v.co,cameraOrigin_l), reverse=False)
	allVerts = sorted(allVerts,key=lambda v:verts2CamDst[v], reverse=False)
	print("- Detecting edge verts, filtered count="+str(len(allVerts)))
	vertsAllKD = kdtree.KDTree(len(allVerts))
	for i, v in enumerate(allVerts):
		vertsAllKD.insert(v.co, v.index)
	vertsAllKD.balance()
	for v in allVerts:
		#if v in vertsSurelyBlocked:
		#	isBlocked = False
		#	# checking all edge-near-verts-byloop. If this somewhere here already -> block. If not - possible new edge on other mesh (fingers!)
		#	for ve in edgeVerts:
		#		if ve in vertsNearVertsByLoop and v in vertsNearVertsByLoop[ve]:
		#			if (ve.co-v.co).length < visMinSpace:
		#				isBlocked = True
		#				break
		#	if isBlocked:
		#		continue
		hit0, normal0, index0, distance0 = bmesh_bvh0.ray_cast(cameraOrigin_l, verts2CamDir[v])
		if hit0 is not None:
			# raycast missed -> possible for some normal edge verts, checking futher
			if (hit0 - v.co).length > visEdgeEps:
				# invisible vertex, not interested
				continue
		allowedNearFaceIdx = set()
		allowedNearVerts = set()
		getBMeshVertLoops_v01(v,allowedNearVerts,vertMaxLdiff)
		vertsNearVertsByLoop[v] = allowedNearVerts
		for ld_v in allowedNearVerts:
			for ld_f in ld_v.link_faces:
				allowedNearFaceIdx.add(ld_f.index)
		distance0 = verts2CamDst[v]
		antiedgeDir = Vector()
		antiedgeCnt = 0
		for i in range(1,len(shiftBVH)):
			isEdge = False
			#if v.index in vcHintsMap and vcHintsMap[v.index][kWPL_VCHint_CnlAdd] > 0.01:
			#	antiedgeCnt = antiedgeCnt+1
			#	antiedgeDir = ??? need dir or disable edge-align for curve building
			#	isEdge = True
			if isEdge == False:
				bmesh_bvh = shiftBVH[i][0]
				bmesh_sht = shiftBVH[i][1]
				bmesh_dir = ((v.co + bmesh_sht) - cameraOrigin_l).normalized()
				hit, normal, findex, distance = bmesh_bvh.ray_cast(cameraOrigin_l, bmesh_dir)
				if hit is None:
					isEdge = True
				else:
					if distance>distance0:
						if (hit - v.co).length >= vertMaxZdiff:
							isEdge = True
						if isEdge == False and len(allowedNearFaceIdx)>0 and (findex not in allowedNearFaceIdx):
							isEdge = True
			if isEdge:
				if v not in edgeVerts:
					edgeVerts.append(v)
					#vnv = set()
					#getBMeshVertLoops_v01(v, vnv, visLoopStep)
					near_verts = vertsAllKD.find_range(v.co, visConnDst)
					vnv =[active_bmesh.verts[x[1]] for x in near_verts]
					vnv_filtered = []
					maxedgelen = 0
					for vf in vnv:
						if vf.index == v.index:
							continue
						if v in vertsNearVertsByLoop and vf not in vertsNearVertsByLoop[v]:
							continue
						vnv_filtered.append(vf)
						edglen = (vf.co-v.co).length
						if edglen>maxedgelen:
							maxedgelen = edglen
					vertsNearVerts[v] = vnv_filtered
					#vertsMaxEdgeLen[v] = maxedgelen
			else:
				antiedgeCnt = antiedgeCnt+1
				antiedgeDir = antiedgeDir+(hit-v.co)
		if antiedgeCnt>0:
			vertsAntiEdgeDir[v] = (antiedgeDir/antiedgeCnt).normalized()
	millisA2 = int(round(time.time() * 1000))
	print("-- Edge verts="+str(len(edgeVerts))+"; ms="+str(millisA2-millisA1))
	# sorting to simplify beautication of edges
	print("- Optimizing verts...")
	millisB1 = int(round(time.time() * 1000))
	vertsEdgeKD = kdtree.KDTree(len(edgeVerts))
	for i, v in enumerate(edgeVerts):
		vertsEdgeKD.insert(v.co, v.index)
	vertsEdgeKD.balance()
	edges2remove = []
	if optmMinSpaceMul>0:
		for v0 in edgeVerts:
			kdres_nears = vertsEdgeKD.find_range(v0.co, visMinSpace*optmMinSpaceMul) #visConnDst*0.1
			kdres_nears_verts = [active_bmesh.verts[x[1]] for x in kdres_nears]
			for v2 in kdres_nears_verts:
				if v2.index == v0.index:
					continue
				if verts2CamDst[v2] > verts2CamDst[v0] and (v2 in vertsNearVerts[v0]):
					edges2remove.append(v2)
			if v0.index in vcHintsMap:
				if vcHintsMap[v0.index][kWPL_VCHint_CnlRem] >= 0.99:
					edges2remove.append(v0)
	if len(edges2remove)>0:
		edgeVerts2 = []
		for v in edgeVerts:
			if v in edges2remove:
				continue
			edgeVerts2.append(v)
		edgeVerts = edgeVerts2
	for v in edgeVerts:
		radhint = 1
		if v.index in vcHintsMap:
			radhint = radhint*(1.0+vcHintsMap[v.index][kWPL_VCHint_CnlAdd])
			radhint = radhint*(1.0-vcHintsMap[v.index][kWPL_VCHint_CnlRem])
		if abs(radhint-1.0) > 0.001:
			v2rhint[v] = radhint
	millisB2 = int(round(time.time() * 1000))
	print("-- Optimized verts="+str(len(edgeVerts))+"; ms="+str(millisB2-millisB1))
	# building curves
	print("- Building curves...")
	millisC1 = int(round(time.time() * 1000))
	usedVerts = set()
	vertsPossibBlocked = set()
	vertsSurelyBlocked = set()
	def addUsedVert(nv):
		usedVerts.add(nv)
		if nv is not None and visMinSpace > 0.0:
			kdres_min = vertsEdgeKD.find_range(nv.co, visMinSpace)
			kdres_min_verts = [active_bmesh.verts[x[1]] for x in kdres_min]
			vertsPossibBlocked.update(kdres_min_verts)
	def edgeViewAnglMeasure(v, v0,v1):
		result = (v0-v1).length
		return result
	droppedCurves = 0
	while True:
		v_curve = []
		vertsPossibBlocked = set()
		isVadded = False
		#isLastTrackedTo = None
		initial_v = None
		initial_v_min_possibl = 0
		for vi in edgeVerts:
			if vi in usedVerts:
				continue
			if (vi in vertsSurelyBlocked) or (vi in vertsPossibBlocked):
				continue
			if vi not in vertsAntiEdgeDir:
				continue
			possibl_vn = 0
			for vn in vertsNearVerts[vi]:
				if vn in usedVerts:
					continue
				possibl_vn = possibl_vn+1
			if initial_v is None:
				initial_v = vi
				initial_v_min_possibl = possibl_vn
			if initial_v_min_possibl<possibl_vn:
				initial_v = vi
				initial_v_min_possibl = possibl_vn
			if initial_v_min_possibl == 1:
				break
		if initial_v is not None:
			isVadded = True
			v_curve.append(initial_v)
			addUsedVert(initial_v)
		while isVadded == True:
			isVadded = False
			curve_last = v_curve[-1]
			curve_last2 = curve_last
			if len(v_curve) > 1:
				curve_last2 = v_curve[-2]
			curve_last_d = verts2CamDst[curve_last]
			curve_last_prob = []

			nearVerts = []
			nearVerts.extend(vertsNearVerts[curve_last])
			nearVerts_set = set(nearVerts)
			for v in nearVerts_set:
				if v not in vertsNearVerts: # not an EDGE vert, it is ok
					continue
				if (v in vertsSurelyBlocked) or (v in vertsPossibBlocked):
					continue
				if v not in vertsAntiEdgeDir:
					continue
				#if v == curve_last or v in curve_last_prob or v in v_curve: # if isLastTrackedTo-> CAN be in usedVerts
				#	continue
				if v in usedVerts:
					continue
				if v.normal.dot(curve_last.normal) < optmNormSmtDot:
					continue
				#if curve_last2 != curve_last:
				#	curvd = ((v.co-curve_last.co).normalized()).dot((curve_last2.co-curve_last.co).normalized())
					#if curvd > optmCurveDot:
					#	continue
				#if vertsAntiEdgeDir[v].dot(vertsAntiEdgeDir[curve_last]) < optmEdgedDot:
				#	continue
				curve_last_prob.append(v)
			v2 = None
			if len(curve_last_prob) > 0:
				curve_last_prob = sorted(curve_last_prob,key=lambda v:edgeViewAnglMeasure(v, v.co, curve_last.co), reverse = False)
				v2 = curve_last_prob[0]
				isVadded = True
				v_curve.append(v2)
				#if v2 in usedVerts:
				#	isLastTrackedTo = v2
				#	break
				addUsedVert(v2)
		curve_len = len(v_curve)
		if curve_len == 0:
			break
		# if isLastTrackedTo is not None:
			# if (isLastTrackedTo is not None) and (isLastTrackedTo in verts2curvestat):
				# lcl = verts2curvestat[isLastTrackedTo][0]
			# else:
				# lcl = 0
			# if lcl>curve_len:
				# droppedCurves = droppedCurves+1
				# continue
		if curve_len < kWPLMinCurveLen:
			droppedCurves = droppedCurves+1
			continue
		vertsSurelyBlocked.update(vertsPossibBlocked)
		curves_all.append(v_curve)
		for v in v_curve:
			verts2curvestat[v] = (curve_len,len(curves_all))
	millisC2 = int(round(time.time() * 1000))
	print("-- Curves="+str(len(curves_all))+"; dropped="+str(droppedCurves)+"; ms="+str(millisC2-millisC1))
	# TBD: post-collapse unnecessary points?
	return {"curves":curves_all,"radius":v2rhint} #,"deeps":v2dhint
######################### ######################### #########################
######################### ######################### #########################
class WPLcurve_merge( bpy.types.Operator ):
	bl_idname = "object.wplcurve_merge"
	bl_label = "Edge from verts"
	bl_options = {'REGISTER', 'UNDO'}
	opt_widthProfile = bpy.props.FloatVectorProperty(
		name		= "Width profile (start, end, pow)",
		size = 3,
		default	 = (0.1, 0.1, 0.8),
	)
	@classmethod
	def poll( cls, context ):
		p = context.object and context.object and context.object.type == 'CURVE'
		return p

	def execute( self, context ):
		wplEdgeBuildProps = context.scene.wplEdgeBuildProps
		active_obj = context.scene.objects.active
		select_and_change_mode(active_obj,'EDIT')
		curveData = active_obj.data
		selected_polys = curve_getSelectedPolys(curveData, True)
		if len(selected_polys) < 2:
			self.report({'ERROR'}, "Select two distinct curves first")
			return {'CANCELLED'}
		possibilities = [(selected_polys[0][0],selected_polys[1][0]),(selected_polys[0][0],selected_polys[1][-1]),(selected_polys[0][-1],selected_polys[1][0]),(selected_polys[0][-1],selected_polys[1][-1])]
		minpp = None
		minlen = 9999
		for pp in possibilities:
			posn = (pp[0].co-pp[1].co).length
			if posn<minlen:
				minlen = posn
				minpp = pp
		if minpp is not None:
			minpp[0].select = True
			minpp[1].select = True
			bpy.ops.curve.make_segment()
			selected_polys = curve_getSelectedPolys(curveData, False)
			for poly in selected_polys:
				radMax = 0
				for p in poly:
					if p.radius > radMax:
						radMax = p.radius
				curve_rescaleRadius(poly,self.opt_widthProfile, 0.5, radMax)
		return {'FINISHED'}

class WPLcurve_build( bpy.types.Operator ):
	bl_idname = "object.wplcurve_build"
	bl_label = "Edge from verts"
	bl_options = {'REGISTER', 'UNDO'}
	opt_widthProfile = bpy.props.FloatVectorProperty(
		name		= "Width profile (start, end, pow)",
		size = 3,
		default	 = (0.1, 0.1, 0.8),
	)
	@classmethod
	def poll( cls, context ):
		p = context.object and context.object and context.object.type == 'MESH'
		return p

	def execute( self, context ):
		wplEdgeBuildProps = context.scene.wplEdgeBuildProps
		active_obj = context.scene.objects.active
		select_and_change_mode(active_obj,'EDIT')
		active_mesh = active_obj.data
		bm = None
		vertsIdx = []
		try:
			bm = bmesh.from_edit_mesh( active_mesh )
			vertsIdx = get_bmhistory_vertsIdx(bm)
		except:
			pass
		if len(vertsIdx)<1:
			self.report({'ERROR'}, "No selected verts found, select some verts first")
			return {'CANCELLED'}
		curveMat = None
		if len(wplEdgeBuildProps.opt_Edgemat)>0:
			curveMat = bpy.data.materials.get(wplEdgeBuildProps.opt_Edgemat)
		empty = getSysEmpty(context,wplEdgeBuildProps.opt_edgePostfix)
		antiscale = 1.0/max(active_obj.scale[0],active_obj.scale[1],active_obj.scale[1])
		sel_obj_name = active_obj.name

		curveDataName = sel_obj_name+"_"+wplEdgeBuildProps.opt_edgePostfix+'_manualCurve'
		curveData = bpy.data.curves.get(curveDataName)
		if curveData is None:
			curveData = bpy.data.curves.new(curveDataName, type='CURVE')
			curveData.dimensions = '3D'
			curveData.fill_mode = 'FULL'
			curveData.bevel_depth = wplEdgeBuildProps.opt_edgeWidth*antiscale
			curveData.bevel_resolution = 2
			curveData.use_fill_caps = True
			curveData.show_normal_face = False
			#curveData.splines.clear()

		polyline = curveData.splines.new('NURBS')
		polyline.order_u = 4
		polyline.resolution_u = 10
		polyline.use_endpoint_u = True
		curveLength = float(len(vertsIdx))
		for i,v_idx in enumerate(vertsIdx):
			if len(polyline.points) <= i:
				polyline.points.add(1)
			v = bm.verts[v_idx]
			v_co_l = v.co
			polyline.points[i].co = (v_co_l[0], v_co_l[1], v_co_l[2], 1)
		curve_rescaleRadius(polyline.points, self.opt_widthProfile, 0.5, 1.0)
		curveData.splines[0].order_u = 4
		#curveData.splines[0].resolution_u = 10
		edgeObjName = sel_obj_name+"_"+wplEdgeBuildProps.opt_edgePostfix+'_manual'
		edgeObj = context.scene.objects.get(edgeObjName)
		if edgeObj is None:
			edgeObj = bpy.data.objects.new(edgeObjName, curveData)
			edgeObj.parent = empty
			context.scene.objects.link(edgeObj)
			if curveMat is not None:
				edgeObj.data.materials.append(curveMat)
		makeObjectNoShadow(edgeObj, wplEdgeBuildProps.opt_edgeWiremode)
		attachEdgeToSourceObject(edgeObj,active_obj)
		self.report({'INFO'}, "Added "+str(curveLength)+" points")
		return {'FINISHED'}

class WPLedge_build( bpy.types.Operator ):
	bl_idname = "object.wpledge_build"
	bl_label = "Edges for selection"
	bl_options = {'REGISTER', 'UNDO'}
	opt_vertVisEps = bpy.props.FloatVectorProperty(
		# 0: some "near invisible" verts are OK and needed for continuity
		# 1: for subdived meshes there is no point keep point too close to each other
		# 2: distance for points to consider them "near" - in vertLChange limits
		name		= "Vert selection (invisEps, spaceDist, connDist)",
		size = 3,
		default	 = (0.1,0.003,0.05),
	)
	opt_detectsEps = bpy.props.FloatVectorProperty(
		# 0: Raycast offsetting
		# 1: Z-difference to consider edge
		# 2: Loops-difference to consider edge
		name		= "Detection (ray-shift, z-diff, l-diff)",
		size = 3,
		default	 = (0.001,0.01,20),
	)
	opt_curveBuildEps = bpy.props.FloatVectorProperty(
		# 0: Overlap, min angle-dot to drop point
		# 1: Curve smoothness, min angle-dot to add to curve
		# 2: Visual Edge direction dot
		name		= "Optimizations (masking, normal-smoothness)",
		size = 2,
		default	 = (0.1,0.1),
	)
	opt_widthProfile = bpy.props.FloatVectorProperty(
		name		= "Width profile (start, end, pow)",
		size = 3,
		default	 = (0.1, 0.1, 0.8),
	)
	opt_vcName = bpy.props.StringProperty(
		name		= "Additional hinting VC",
		default	 = "Edges"
		)
	@classmethod
	def poll( cls, context ):
		return (bpy.context.space_data.region_3d.is_perspective)

	def execute( self, context ):
		if not bpy.context.space_data.region_3d.is_perspective:
			self.report({'ERROR'}, "Can`t work in ORTHO mode")
			return {'CANCELLED'}
		sel_all = [o.name for o in bpy.context.selected_objects]
		if len(sel_all) == 0:
			self.report({'ERROR'}, "No objects selected")
			return {'CANCELLED'}
		wplEdgeBuildProps = context.scene.wplEdgeBuildProps
		if len(wplEdgeBuildProps.opt_nameSubstr2skip)>0:
			skipNameParts = [x.strip().lower() for x in wplEdgeBuildProps.opt_nameSubstr2skip.split(",")]
		else:
			skipNameParts = []
		camera_gCo = camera_pos(bpy.context.space_data.region_3d)
		empty = getSysEmpty(context,wplEdgeBuildProps.opt_edgePostfix)
		#setLayerForObject(empty,kWPLEdgeLayer)
		changed_edgemeshed = 0
		curveMat = None
		if len(wplEdgeBuildProps.opt_Edgemat)>0:
			curveMat = bpy.data.materials.get(wplEdgeBuildProps.opt_Edgemat)
		for i, sel_obj_name in enumerate(sel_all):
			for snp in skipNameParts:
				if sel_obj_name.lower().find(snp) >= 0:
					sel_obj_name = ""
					break
			sel_obj = None
			if len(sel_obj_name)>0:
				sel_obj = context.scene.objects.get(sel_obj_name)
			if sel_obj is None or sel_obj.cycles_visibility.camera == False:
				continue
			sel_mesh = None
			try:
				if sel_obj.parent == empty:
					continue
				sel_mesh = sel_obj.to_mesh(context.scene, True, wplEdgeBuildProps.opt_meshType)
			except:
				pass
			if sel_mesh is None:
				continue
			print("Preparing object "+sel_obj_name+"...")
			selModifiers = sel_obj.modifiers
			if wplEdgeBuildProps.opt_subdRemeLevel < 0:
				target_cellsize = 1.0
				maxdim = max(max(sel_obj.dimensions[0],sel_obj.dimensions[1]),sel_obj.dimensions[2])
				remesh_scale = maxdim/target_cellsize
				opt_remeshLevel = abs(wplEdgeBuildProps.opt_subdRemeLevel)
				if opt_remeshLevel<10:
					remesh_scale = remesh_scale*pow(2,10-opt_remeshLevel)
				remesh_scale = min(remesh_scale,0.99)
				if remesh_scale > 0.001:
					print("- Remeshing, level: "+str(opt_remeshLevel)+"/"+str(remesh_scale))
					remesh_modifier = selModifiers.new('WPLTMPREMESH', 'REMESH')
					remesh_modifier.mode = 'SMOOTH'
					remesh_modifier.scale = remesh_scale
					remesh_modifier.use_remove_disconnected = False
					remesh_modifier.octree_depth = opt_remeshLevel
					bpy.data.meshes.remove(sel_mesh)
					sel_mesh = sel_obj.to_mesh(context.scene, True, wplEdgeBuildProps.opt_meshType)
					selModifiers.remove(remesh_modifier)
			# else if wplEdgeBuildProps.opt_maxVertCount > 0 and len(sel_mesh.vertices) > wplEdgeBuildProps.opt_maxVertCount:
				# decim = wplEdgeBuildProps.opt_maxVertCount/float(len(sel_mesh.vertices))
				# print("- Decimate level: "+str(decim))
				# decim_modifier = selModifiers.new(name = "WPLTMPDECIM", type = 'DECIMATE')
				# decim_modifier.use_collapse_triangulate = True
				# decim_modifier.ratio = decim
				# bpy.data.meshes.remove(sel_mesh)
				# sel_mesh = sel_obj.to_mesh(context.scene, True, wplEdgeBuildProps.opt_meshType)
				# selModifiers.remove(decim_modifier)
			sel_bmesh = bmesh.new()
			sel_bmesh.from_mesh(sel_mesh)
			bpy.data.meshes.remove(sel_mesh)
			if sel_bmesh is None:
				continue
			edger_params = {}
			edger_params["hintVCname"] = self.opt_vcName
			edger_params["visEdgeEps"] = self.opt_vertVisEps[0]
			edger_params["visMinSpace"] = self.opt_vertVisEps[1]
			edger_params["visConnDst"] = self.opt_vertVisEps[2]
			edger_params["visAllInciNormDot"] = -0.01
			edger_params["optmMinSpaceMul"] = self.opt_curveBuildEps[0]
			edger_params["optmNormSmtDot"] = self.opt_curveBuildEps[1]
			#edger_params["optmCurveDot"] = self.opt_curveBuildEps[1]
			#edger_params["optmEdgedDot"] = self.opt_curveBuildEps[2]
			edger_params["vertRaycShift"] = self.opt_detectsEps[0]
			edger_params["vertMaxZdiff"] = self.opt_detectsEps[1]
			edger_params["vertMaxLdiff"] = self.opt_detectsEps[2]
			if sel_obj.type == 'CURVE':
				edger_params["visAllInciNormDot"] = -0.99
				edger_params["vertMaxLdiff"] = 1
				#edger_params["optmCurveDot"] = 0
				#preSubdiv = 1
			if wplEdgeBuildProps.opt_subdRemeLevel > 0:
				# checking existing subdivs
				alreadySubd = 0
				for md in selModifiers:
					if md.type == 'SUBSURF':
						if wplEdgeBuildProps.opt_meshType=='PREVIEW':
							alreadySubd = alreadySubd+md.levels
						else:
							alreadySubd = alreadySubd+md.render_levels
				print("- Subdividing, level: "+str(wplEdgeBuildProps.opt_subdRemeLevel)+", already="+str(alreadySubd))
				finalSubd = wplEdgeBuildProps.opt_subdRemeLevel-alreadySubd
				if finalSubd>0:
					bmesh.ops.subdivide_edges(sel_bmesh, edges=sel_bmesh.edges[:], cuts=finalSubd, use_grid_fill=True, use_single_edge=True)
			edgeDB = getEdgeVertsForObject(wplEdgeBuildProps.opt_edgePostfix, sel_obj, sel_bmesh, camera_gCo, edger_params)
			vert_curves = edgeDB["curves"]
			vert_rhint = edgeDB["radius"]
			#vert_deeps = edgeDB["deeps"]
			print("- Making "+str(len(vert_curves))+" curves...")
			#print("vert_curves",vert_curves)
			#print("vert_rhint",vert_rhint)
			#print("vert_deeps",vert_deeps)
			matrix_world_inv = sel_obj.matrix_world.inverted()
			curveDataName = sel_obj_name+"_"+wplEdgeBuildProps.opt_edgePostfix+'_autoCurve'
			curveData = bpy.data.curves.new(curveDataName, type='CURVE')
			curveData.dimensions = '3D'
			curveData.fill_mode = 'FULL'
			curveData.bevel_depth = wplEdgeBuildProps.opt_edgeWidth
			curveData.bevel_resolution = 2
			curveData.use_fill_caps = True
			curveData.show_normal_face = False
			curveData.splines.clear()
			for curve in vert_curves:
				if len(curve) == 0:
					continue
				polyline = curveData.splines.new('NURBS')
				polyline.order_u = 4
				polyline.resolution_u = 10
				polyline.use_endpoint_u = True
				curveLength = float(len(curve))
				for i,v_g in enumerate(curve):
					if len(polyline.points) <= i:
						polyline.points.add(1)
					v_co_l = matrix_world_inv * v_g.co
					polyline.points[i].co = (v_co_l[0], v_co_l[1], v_co_l[2], 1)
				curve_rescaleRadius(polyline.points, self.opt_widthProfile, 0.5, 1.0)
				for i,v_g in enumerate(curve):
					if v_g in vert_rhint:
						polyline.points[i].radius = polyline.points[i].radius*vert_rhint[v_g]
			if len(curveData.splines) == 0:
				continue
			curveData.splines[0].order_u = 4
			#curveData.splines[0].resolution_u = 10
			edgeObjName = sel_obj_name+"_"+wplEdgeBuildProps.opt_edgePostfix+'_auto'
			edgeObj = context.scene.objects.get(edgeObjName)
			if edgeObj is not None:
				bpy.data.objects.remove(edgeObj, True)
			edgeObj = bpy.data.objects.new(edgeObjName, curveData)
			edgeObj.parent = empty
			if curveMat is not None:
				edgeObj.data.materials.append(curveMat)
			context.scene.objects.link(edgeObj)
			makeObjectNoShadow(edgeObj, wplEdgeBuildProps.opt_edgeWiremode)
			attachEdgeToSourceObject(edgeObj,sel_obj)
			antiscale = 1.0/max(edgeObj.scale[0],edgeObj.scale[1],edgeObj.scale[2])
			curveData.bevel_depth = wplEdgeBuildProps.opt_edgeWidth*antiscale
			sel_bmesh.free()
			changed_edgemeshed = changed_edgemeshed+1
			print(str(changed_edgemeshed)+" of "+str(len(sel_all))+" done.\n")
		self.report({'INFO'}, "Updated "+str(changed_edgemeshed)+" edges of "+str(len(sel_all)))
		return {'FINISHED'}

########## ############ ########## ############ ########## ############
########## ############ ########## ############ ########## ############
class WPLEdgeBuildSettings(bpy.types.PropertyGroup):
	opt_nameSubstr2skip = StringProperty(
		name		= "Skip if object name contain...",
		default	 = "sys_,zzz_"
		)
	opt_Edgemat = StringProperty(
		name="Edge material",
		description="Edge material",
		default = ""
		)
	opt_edgePostfix = StringProperty(
		name		= "Edge object postfix",
		default	 = "sys_edge_d",
	)
	opt_edgeWidth = FloatProperty(
		name		= "Base curve radius",
		default	 = 0.003,
	)
	opt_subdRemeLevel = FloatProperty(
		name		= "+Subdiv/-Remesh",
		default	 = 2,
	)
	# opt_remeshLevel = FloatProperty(
		# name		= "Remesh",
		# default	 = 10,
	# )
	# opt_maxVertCount = FloatProperty(
		# name		= "Max verts count",
		# default	 = 0,
	# )
	opt_meshType = EnumProperty(
		name="Mesh Type", default="PREVIEW",
		items=(("PREVIEW", "Preview", ""), ("RENDER", "Render", ""))
	)
	opt_edgeWiremode = BoolProperty(
		name		= "Enable wireframe",
		default	 = False,
	)

class WPLEdgeBuilder_Panel(bpy.types.Panel):
	bl_label = "Edge build"
	bl_space_type = 'VIEW_3D'
	bl_region_type = 'TOOLS'
	bl_category = 'WPL'

	def draw_header(self, context):
		layout = self.layout
		layout.label(text="")

	def draw(self, context):
		wplEdgeBuildProps = context.scene.wplEdgeBuildProps
		layout = self.layout
		col = layout.column()

		col.prop(wplEdgeBuildProps, "opt_nameSubstr2skip")
		col.prop(wplEdgeBuildProps, "opt_edgePostfix")
		col.prop(wplEdgeBuildProps, "opt_edgeWidth")
		r1 = col.row()
		r1.prop(wplEdgeBuildProps, "opt_subdRemeLevel")
		#r1.prop(wplEdgeBuildProps, "opt_remeshLevel")
		#col.prop(wplEdgeBuildProps, "opt_maxVertCount")
		col.prop_search(wplEdgeBuildProps, "opt_Edgemat", bpy.data, "materials")
		col.prop(wplEdgeBuildProps, "opt_meshType")
		col.prop(wplEdgeBuildProps, "opt_edgeWiremode")
		col.operator("object.wpledge_build", text="Build edges for selection")
		col.operator("object.wplcurve_build", text="Single Edge from active verts")
		col.operator("object.wplcurve_merge", text="Merge selected curves")


def register():
	print("WPLEdgeBuilder_Panel registered")
	bpy.utils.register_module(__name__)
	bpy.types.Scene.wplEdgeBuildProps = PointerProperty(type=WPLEdgeBuildSettings)

def unregister():
	bpy.utils.unregister_module(__name__)
	del bpy.types.Scene.wplEdgeBuildProps
	bpy.utils.unregister_class(WPLEdgeBuildSettings)

if __name__ == "__main__":
	register()
