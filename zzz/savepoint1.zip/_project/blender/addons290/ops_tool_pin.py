import os, sys, time, datetime
import math, copy, string, random
import numpy as np
import bpy, bmesh, mathutils

import bpy.types
from mathutils import Vector, Matrix, Euler, Quaternion
from mathutils.bvhtree import BVHTree
from mathutils.kdtree import KDTree
from bpy_extras import view3d_utils
from bpy.props import *

from . import config
from .tools import wla
from .tools import wla_do
from .tools import wla_bm
from .tools import wla_meshwrap
from .tools import wla_vgs

# ==========================================
class wplverts_pinsnap(bpy.types.Operator):
	bl_idname = "mesh.wplverts_pinsnap"
	bl_label = "Pin mesh state"
	bl_options = {'REGISTER', 'UNDO'}

	opt_pinId : StringProperty(
		name		= "Pin ID",
		default	 	= "fastpin1"
	)

	def execute(self, context):
		active_obj = wla.active_object(['MESH'])
		if active_obj is None:
			self.report({'ERROR'}, "Select mesh object first")
			return {'CANCELLED'}

		active_mesh = active_obj.data
		wla_do.select_and_change_mode(active_obj, 'EDIT')
		# DO NOT change mode: Prepinned mira/mirra need edges...
		#context.tool_settings.mesh_select_mode = (True, False, False) # 'VERT'
		bm = bmesh.from_edit_mesh(active_mesh)
		if wla_bm.bm_setPinmapFastIdx(active_obj, bm, self.opt_pinId) == 0:
			self.report({'ERROR'}, "Can`t create pinmap")
			return {'CANCELLED'}
		self.report({'INFO'}, "Mesh state remembered")
		return {'FINISHED'}

class wplverts_pinrestore(bpy.types.Operator):
	bl_idname = "mesh.wplverts_pinrestore"
	bl_label = "Restore selected"
	bl_options = {'REGISTER', 'UNDO'}

	opt_mode : EnumProperty(
		items = [
			('DIRECT', "As Is", "", 1),
			('CAMERA', "Camera view", "", 2)
		],
		name="Mode",
		default='DIRECT',
	)

	opt_influence : FloatProperty(
			name="Influence",
			min=-10.0, max=10.0,
			default=1.0,
	)

	opt_pinId : StringProperty(
		name		= "Pin ID",
		default	 	= "fastpin1"
	)

	def execute(self, context):
		active_obj = wla.active_object(['MESH'])
		if active_obj is None:
			self.report({'ERROR'}, "Select mesh object first")
			return {'CANCELLED'}
		
		camObj = wla.object_by_name(config.kWPLSystemMainCam)
		if camObj is None:
			self.report({'ERROR'}, "Camera not found: "+config.kWPLSystemMainCam)
			return {'CANCELLED'}
		matrix_world_inv = active_obj.matrix_world.inverted()
		camera_gCo = camObj.matrix_world.to_translation()
		camera_lCo = matrix_world_inv @ camera_gCo
		active_mesh = active_obj.data
		wla_do.select_and_change_mode(active_obj, 'EDIT')
		context.tool_settings.mesh_select_mode = (True, False, False) # 'VERT'
		bm = bmesh.from_edit_mesh(active_mesh)
		bm.verts.ensure_lookup_table()
		bm.verts.index_update()
		bm.faces.ensure_lookup_table()
		selverts = [v.index for v in bm.verts if v.select]
		if len(selverts) == 0:
			self.report({'ERROR'}, "No moved/selected verts found")
			return {'CANCELLED'}
		verts_snap_map, _ = wla_bm.bm_getPinmapFastIdx(active_obj, bm, self.opt_pinId)
		if verts_snap_map is None:
			self.report({'ERROR'}, "Mesh not pinned")
			return {'CANCELLED'}
		for vIdx in selverts:
			s_v = bm.verts[vIdx]
			s_v_co_init = verts_snap_map[vIdx]["co"]
			if self.opt_mode == 'CAMERA':
				incoming = s_v_co_init-camera_lCo
				intrRes = mathutils.geometry.intersect_point_line(s_v.co, camera_lCo, camera_lCo+10.0*incoming)
				s_v_co_init = intrRes[0]
			s_v.co = s_v.co.lerp(s_v_co_init,self.opt_influence)
		bm.normal_update()
		bmesh.update_edit_mesh(active_mesh)
		return {'FINISHED'}

class wplverts_pinpropagt(bpy.types.Operator):
	bl_idname = "mesh.wplverts_pinpropagt"
	bl_label = "Smooth around"
	bl_options = {'REGISTER', 'UNDO'}

	opt_mode : EnumProperty(
		items = [
			('KEEPACTIV', "Active selection", "", 1),
			('ENFORPINS', "Reset sel (preselected)", "", 2),
			('ENFORSEL', "Reset sel (current)", "", 3),
			('ENFORSEAMS', "Reset seams", "", 4)
		],
		name="Movement source",
		default='KEEPACTIV',
	)

	opt_influence : FloatProperty(
		name="Influence",
		min=-100, max=100,
		default=1.0,
	)
	opt_smoothLoops : IntProperty(
		name="Smoothing loops",
		min=0, max=100,
		default=5,
	)
	opt_smoothPow : FloatProperty(
		name="Smoothing pow",
		min=0.0, max=10,
		default=1.0,
	)
	opt_pinId : StringProperty(
		name = "Pin ID",
		default = "fastpin1"
	)

	def execute(self, context):
		active_obj = wla.active_object(['MESH'])
		if active_obj is None:
			self.report({'ERROR'}, "Select mesh object first")
			return {'CANCELLED'}
		
		active_mesh = active_obj.data
		selverts = wla.selected_vertsIdx(active_mesh)
		wla_do.select_and_change_mode(active_obj, 'EDIT')
		bm = bmesh.from_edit_mesh(active_mesh)
		bm.verts.ensure_lookup_table()
		bm.faces.ensure_lookup_table()
		bm.verts.index_update()
		verts_shifts = {}
		verts_snap_map, _ = wla_bm.bm_getPinmapFastIdx(active_obj, bm, self.opt_pinId)
		if verts_snap_map is None:
			self.report({'ERROR'}, "Mesh not pinned")
			return {'CANCELLED'}
		useCurrentVposAsRef = False
		if self.opt_mode == 'ENFORPINS' or self.opt_mode == 'ENFORSEAMS':
			selverts = []
			useCurrentVposAsRef = True
			# resetting initial selection
			for v in bm.verts:
				isLocked = False
				if self.opt_mode == 'ENFORPINS' and verts_snap_map[v.index]["se"] > 0:
					isLocked = True
				if self.opt_mode == 'ENFORSEAMS' and verts_snap_map[v.index]["sm"] > 0:
					isLocked = True
				if isLocked:
					selverts.append(v.index)
					v_co2 = v.co.lerp(verts_snap_map[v.index]["co"], self.opt_influence)
					verts_shifts[v.index] = Vector(v_co2 - v.co)
					v.co = v_co2
		if self.opt_mode == 'ENFORSEL':
			useCurrentVposAsRef = True
			# selverts already
			for v in bm.verts:
				isLocked = False
				if v.index in selverts:
					isLocked = True
				if isLocked:
					v_co2 = v.co.lerp(verts_snap_map[v.index]["co"], self.opt_influence)
					verts_shifts[v.index] = Vector(v_co2 - v.co)
					v.co = v_co2
		if len(selverts) == 0:
			selverts = []
			for v in bm.verts:
				if verts_snap_map[v.index] is not None:
					if (v.co-verts_snap_map[v.index]["co"]).length > config.kWPLRaycastEpsilon:
						# vert moved
						selverts.append(v.index)
		if len(selverts) == 0:
			self.report({'ERROR'}, "No moved/selected verts found")
			return {'CANCELLED'}
		(propagationSteps, vertsWeight, allWalkedVerts, vertsFromIdx) = wla_bm.bm_vertsPropagations_v02(bm, selverts, self.opt_smoothLoops)
		for v_idx in allWalkedVerts:
			if (v_idx not in verts_shifts) and (v_idx in verts_snap_map):
				v = bm.verts[v_idx]
				verts_shifts[v_idx] = Vector(v.co - verts_snap_map[v_idx]["co"])
		new_positions = {}
		for stage_verts in propagationSteps:
			for vIdx in stage_verts:
				if vIdx not in verts_snap_map:
					continue
				vertCurCo = bm.verts[vIdx].co
				vertWeight = 1.0
				if self.opt_smoothPow > 0.0:
					if vIdx in vertsWeight and abs(vertsWeight[vIdx])>0.0:
						vertWeight = 1.0-pow(1.0-vertsWeight[vIdx], self.opt_smoothPow)
					else:
						print("- opt_smoothPow: vert not found", vIdx, len(vertsWeight))
				vertWeight = max(0.0, vertWeight)
				avg_shift = mathutils.Vector((0,0,0))
				avg_count = 0.0
				from_vIdxes = vertsFromIdx[vIdx]
				for froms_idx in from_vIdxes:
					avg_shift = avg_shift + verts_shifts[froms_idx]
					avg_count = avg_count + 1.0
				#print("Vert avg shift", vIdx, avg_shift, avg_count, from_vIdxes)
				if avg_count>0:
					s_shift = mathutils.Vector(avg_shift)/avg_count
					verts_shifts[vIdx] = s_shift
					if useCurrentVposAsRef:
						s_v_co = vertCurCo
					else:
						s_v_co = verts_snap_map[vIdx]["co"]
					total_shift = s_shift * vertWeight * self.opt_influence
					s_v_co2 = s_v_co + total_shift
					new_positions[vIdx] = (s_v_co2, vertWeight)
		# updating positions as post-step
		for s_idx in new_positions:
			if s_idx in selverts:
				if self.opt_mode == 'KEEPACTIV':
					continue
			s_v = bm.verts[s_idx]
			s_v_co2 = new_positions[s_idx][0]
			vertWeight = new_positions[s_idx][1]
			# if ("v-infl" in verts_snap_map[s_idx]):
			# 	vertInfl = verts_snap_map[s_idx]["v-infl"]
			# 	vertInfl2 = max(0.0, vertInfl-vertWeight)
			# 	verts_snap_map[s_idx]["v-infl"] = vertInfl2
			# 	s_v_co2 = s_v.co.lerp(s_v_co2, vertInfl)
			s_v.co = s_v_co2
		# for s_idx in selverts:
		# 	if ("v-infl" in verts_snap_map[s_idx]):
		# 		verts_snap_map[s_idx]["v-infl"] = 0.0
		bm.normal_update()
		bmesh.update_edit_mesh(active_mesh)
		self.report({'INFO'}, "Smoothed "+str(len(new_positions))+" verts")
		return {'FINISHED'}

class wplverts_pinsurfshrw(bpy.types.Operator):
	bl_idname = "mesh.wplverts_pinsurfshrw"
	bl_label = "Shrinkwrap to pinned"
	bl_options = {'REGISTER', 'UNDO'}

	opt_influence : FloatProperty(
		name		= "Influence",
		default	 = 1.0,
		min		 = 0,
		max		 = 1
	)
	opt_shrinkwMethod : EnumProperty(
		name="Detection method", default="SHRINKWRAP_RECAST",
		items=(
			("SHRINKWRAP_RAW", "Shrinkwrap", ""),
			("SHRINKWRAP_RECAST", "Near surface", ""),
			("SHRINKWRAP_NORMAL", "Normal projection", ""),
			("SHRINKWRAP_NORMAL_INV", "Normal-inv projection", ""),
			# ("CAMPROJTO", "Camera: Project to", ""),
			# ("CAMPROJFROM", "Camera: Project from", ""),
			("VIEWPROJTO_AVG", "View: Project to, Avg", ""),
			("VIEWPROJFROM_AVG", "View: Project from, Avg", ""),
			("VIEWPROJTO_GRID", "View: Project to, Grid-ly", ""),
			("VIEWPROJFROM_GRID", "View: Project from, Grid-ly", ""),
			("VIEWPROJ_DESELV", "View:  Deselect", ""),
		)
	)
	opt_vertsType : EnumProperty(
		name="Apply to verts", default="ALL",
		items=(("ALL", "All", ""), ("ABOVE", "Above surface", ""), ("UNDER", "Under surface", ""))
	)
	opt_makeConvex : BoolProperty(
		name="Convex target surface", default=False
	)
	opt_castFeats : FloatVectorProperty(
		name = "Softcast/PreShift/PostDisplace",
		size = 3,
		default	 = (0.0, 0.0, 0.0)
	)
	opt_pinId : StringProperty(
		name		= "Pin ID",
		default	 	= "fastpin1"
	)

	def execute( self, context ):
		active_obj = wla.active_object(wla_meshwrap.kWPLMESHWRAP_TYPES)
		if active_obj is None:
			self.report({'ERROR'}, "Select mesh object first")
			return {'CANCELLED'}
		camObj = wla.object_by_name(config.kWPLSystemMainCam)
		if camObj is None:
			self.report({'ERROR'}, "Camera not found: "+config.kWPLSystemMainCam)
			return {'CANCELLED'}
		oldmod = wla_do.select_and_change_mode(active_obj, 'OBJECT')
		active_mesh = wla_meshwrap.object_wrappedmesh(active_obj)
		selvertsAll = active_mesh.selected_vertsIdx()
		if len(selvertsAll) == 0:
			self.report({'ERROR'}, "No verts selected")
			return {'FINISHED'}
		matrix_world_inv = active_obj.matrix_world.inverted()
		matrix_world_norm = matrix_world_inv.transposed().to_3x3()
		bm2bvh = None
		#print("self.opt_pinId0", self.opt_pinId, self.opt_castFeats)
		_, faces_snap_map = wla_bm.bm_getPinmapFastIdx(active_obj, None, self.opt_pinId)
		if faces_snap_map is not None:
			# ??? bm_BVHFromFacesIdx
			bm2 = bmesh.new()
			bm2vmap = {}
			bm2conv = []
			for f_vg in faces_snap_map:
				f_v_set = []
				f_v_set_ko = []
				for v_co_g in f_vg:
					v_co = matrix_world_inv @ v_co_g
					vert_index = wla.coToKey(v_co)
					if vert_index not in bm2vmap:
						v_cc = bm2.verts.new(v_co)
						bm2vmap[vert_index] = v_cc
					else:
						v_cc = bm2vmap[vert_index]
					#v_cc = bm2.verts.new(v_co)
					if v_cc not in f_v_set:
						f_v_set.append(v_cc)
						f_v_set_ko.append(vert_index)
				if len(f_v_set) >= 3:
					f_v_set_ko = sorted(f_v_set_ko)
					f_v_set_ko = ",".join(f_v_set_ko)
					if f_v_set_ko not in bm2vmap:
						bm2vmap[f_v_set_ko] = f_v_set
						bm2.faces.new(f_v_set)
				if self.opt_makeConvex:
					for v_cc in f_v_set:
						if v_cc not in bm2conv:
							bm2conv.append(v_cc)
			if len(bm2conv)>0:
				bmesh.ops.convex_hull(bm2, input=bm2conv)
				bm2.verts.ensure_lookup_table()
				bm2.verts.index_update()
				bm2.faces.ensure_lookup_table()
				bm2.faces.index_update()
			print("- Target faces:",len(bm2.faces))
			#wla_do.sys_dump_bmesh(active_obj, bm2, "pin_faces")
			bm2.normal_update()
			bm2bvh = BVHTree.FromBMesh(bm2, epsilon = 0.0)
			bm2.free()
		if bm2bvh is None:
			self.report({'ERROR'}, "No surface faces found, pin mesh with selected faces first")
			return {'CANCELLED'}
		okCnt = 0
		wla_do.select_and_change_mode(active_obj, 'OBJECT')
		print("- pinning:", self.opt_shrinkwMethod)
		for vIdx in selvertsAll:
			proj_dir = Vector( (0,0,0) )
			bubble_dir = None
			n_normal = None
			n_loc = None
			v = active_mesh.vertices[vIdx]
			if self.opt_shrinkwMethod == 'VIEWPROJ_DESELV':
				region, _ = wla.active_view_region()
				eo_dir2cam_g = (region.view_rotation @ Vector((0.0, 0.0, 1.0)))
				eo_dir2cam_l = matrix_world_norm.inverted() @ eo_dir2cam_g
				proj_dir = eo_dir2cam_l
				v_loc = v.co - self.opt_castFeats[1]*proj_dir
				hit_l, _ = wla_bm.bm_fuzzyBVHRayCast_v01(bm2bvh, v_loc, proj_dir, abs(self.opt_castFeats[0]), 20, 'AVG')
				if hit_l is None:
					# hit something -> vertex NOT visible
					# hit NOTHING -> vertex visible, deselecting
					v.select = False
					okCnt = okCnt+1
			elif self.opt_shrinkwMethod == 'VIEWPROJTO_GRID' or self.opt_shrinkwMethod == 'VIEWPROJFROM_GRID':
				region, _ = wla.active_view_region()
				eo_dir2cam_g = (region.view_rotation @ Vector((0.0, 0.0, 1.0)))
				print("- view dir(global)", eo_dir2cam_g)
				eo_dir2cam_l = matrix_world_norm.inverted() @ eo_dir2cam_g
				proj_dir = eo_dir2cam_l
				bubble_dir = proj_dir
				if self.opt_shrinkwMethod == 'VIEWPROJFROM_GRID':
					proj_dir = -1*eo_dir2cam_l
				v_loc = v.co - self.opt_castFeats[1]*proj_dir
				n_loc, n_normal = wla_bm.bm_fuzzyBVHRayCast_v01(bm2bvh, v_loc, proj_dir, 0.0, 20, 'AVG_ON_DIR')
				if abs(self.opt_castFeats[0]) > 0.0:
					# if n_loc is None:
					# 	n_loc, n_normal = wla_bm.bm_fuzzyBVHRayCast_v01(bm2bvh, v_loc, proj_dir, 0.05, 20, 'AVG_ON_DIR')
					# if n_loc is None:
					# 	n_loc, n_normal = wla_bm.bm_fuzzyBVHRayCast_v01(bm2bvh, v_loc, proj_dir, 0.1, 20, 'AVG_ON_DIR')
					if n_loc is None:
						n_loc, n_normal = wla_bm.bm_fuzzyBVHRayCast_v01(bm2bvh, v_loc, proj_dir, 0.3, 20, 'AVG_ON_DIR')
					if n_loc is None:
						n_loc, n_normal = wla_bm.bm_fuzzyBVHRayCast_v01(bm2bvh, v_loc, proj_dir, 0.6, 20, 'AVG_ON_DIR')
					if n_loc is None:
						n_loc, n_normal = wla_bm.bm_fuzzyBVHRayCast_v01(bm2bvh, v_loc, proj_dir, 1.2, 20, 'AVG_ON_DIR')
					if n_loc is None:
						n_loc, n_normal = wla_bm.bm_fuzzyBVHRayCast_v01(bm2bvh, v_loc, proj_dir, 3.0, 20, 'AVG_ON_DIR')
				# if n_loc is not None:
				# 	print("- fixing offset")
				# 	# recalcing, since "soft" can slide vertex, which is not needed on practice
				# 	n_loc = v.co - proj_dir*(n_loc-v.co).length
			elif self.opt_shrinkwMethod == 'VIEWPROJTO_AVG' or self.opt_shrinkwMethod == 'VIEWPROJFROM_AVG':
				region, _ = wla.active_view_region()
				eo_dir2cam_g = (region.view_rotation @ Vector((0.0, 0.0, 1.0)))
				eo_dir2cam_l = matrix_world_norm.inverted() @ eo_dir2cam_g
				proj_dir = eo_dir2cam_l
				bubble_dir = proj_dir
				if self.opt_shrinkwMethod == 'VIEWPROJFROM_AVG':
					proj_dir = -1 * proj_dir
				#print("- proj_dir (global)", self.opt_shrinkwMethod, eo_dir2cam_g)
				#print("- proj_dir (local)", self.opt_shrinkwMethod, proj_dir)
				v_loc = v.co - self.opt_castFeats[1]*proj_dir
				n_loc, n_normal = wla_bm.bm_fuzzyBVHRayCast_v01(bm2bvh, v_loc, proj_dir, abs(self.opt_castFeats[0]), 20, 'AVG')
				if n_loc is None and (self.opt_castFeats[0] < 0):
					# backward cast to land
					print("- att2: backward shift")
					proj_dir = -1 * proj_dir
					n_loc, n_normal = wla_bm.bm_fuzzyBVHRayCast_v01(bm2bvh, v_loc, proj_dir, abs(self.opt_castFeats[0]), 20, 'AVG')
			# elif self.opt_shrinkwMethod == 'CAMPROJTO' or self.opt_shrinkwMethod == 'CAMPROJFROM':
			# 	proj_dir = active_camera_dir_l(active_obj, v.co)
			# 	bubble_dir = proj_dir
			# 	if self.opt_shrinkwMethod == 'CAMPROJFROM':
			# 		proj_dir = -1 * proj_dir
			# 	print("- proj_dir (local)", self.opt_shrinkwMethod, proj_dir, v.co)
			# 	v_loc = v.co - self.opt_castFeats[1]*proj_dir
			# 	n_loc, n_normal = wla_bm.bm_fuzzyBVHRayCast_v01(bm2bvh, v_loc, proj_dir, abs(self.opt_castFeats[0]), 20, 'AVG')
			# 	if n_loc is None and (self.opt_castFeats[0] < 0):
			# 		# backward cast to land
			# 		print("- att2: backward shift")
			# 		proj_dir = -1 * proj_dir
			# 		n_loc, n_normal = wla_bm.bm_fuzzyBVHRayCast_v01(bm2bvh, v_loc, proj_dir, abs(self.opt_castFeats[0]), 20, 'AVG')
			else: # SHRINKWRAP_RAW / SHRINKWRAP_RECAST / SHRINKWRAP_NORMAL / SHRINKWRAP_NORMAL_INV
				proj_dir = v.normal
				bubble_dir = proj_dir
				if self.opt_shrinkwMethod == 'SHRINKWRAP_NORMAL_INV':
					n_loc, n_normal = wla_bm.bm_fuzzyBVHRayCast_v01(bm2bvh, v.co + self.opt_castFeats[1]*proj_dir, -1 * proj_dir, abs(self.opt_castFeats[0]), 20, 'AVG')
				elif self.opt_shrinkwMethod == 'SHRINKWRAP_NORMAL':
					n_loc, n_normal = wla_bm.bm_fuzzyBVHRayCast_v01(bm2bvh, v.co - self.opt_castFeats[1]*proj_dir, proj_dir, abs(self.opt_castFeats[0]), 20, 'AVG')
				else:
					n_loc, n_normal, _, n_dst = bm2bvh.find_nearest(v.co) #SHRINKWRAP_RAW
					if (n_loc is not None) and self.opt_shrinkwMethod == 'SHRINKWRAP_RECAST':
						if proj_dir.dot( (n_loc-v.co).normalized() ) < 0.0:
							proj_dir = -1.0 * proj_dir
						n_loc = v.co + proj_dir*n_dst
			if n_loc is not None:
				dotFac = (v.co-n_loc).dot(n_normal)
				if self.opt_vertsType == 'ABOVE':
					if dotFac <= 0:
						continue
				if self.opt_vertsType == 'UNDER':
					if dotFac > 0:
						continue
				if abs(self.opt_castFeats[2])>0.00001 and bubble_dir is not None:
					#print("- bubbling", bubble_dir, self.opt_castFeats[2])
					n_loc = n_loc + bubble_dir*self.opt_castFeats[2]
				infl = self.opt_influence
				#print("- diff", (n_loc-v.co).length)
				v.co = v.co.lerp(n_loc, infl)
				okCnt = okCnt+1
		active_mesh.to_mesh()
		#wla_do.sys_update_mesh(active_obj)
		wla_do.select_and_change_mode(active_obj, oldmod)
		self.report({'INFO'}, "Done, "+str(okCnt)+" verts updated")
		return {'FINISHED'}

# class wplsculpt_fastpin_edges(bpy.types.Operator):
# 	bl_idname = "mesh.wplsculpt_fastpin_edges"
# 	bl_label = "Store edges"
# 	bl_options = {'REGISTER', 'UNDO'}

# 	opt_srcMode : EnumProperty(
# 		name="Source mode", default="EDG",
# 		items=(("EDG", "Selected edges", ""), 
# 		("VERTLINE", "Selected verts", ""), 
# 		("VERTHIST", "History verts", ""))
# 	)

# 	opt_flowDir : FloatVectorProperty(
# 		name	 = "Preferred direction",
# 		size	 = 3,
# 		min=-1.0, max=1.0,
# 		default	 = (0.0,0.0,-1.0)
# 	)

# 	opt_append2last : BoolProperty(
# 		name="Append selection to saved edges",
# 		default=True
# 	)

# 	def execute( self, context ):
# 		active_obj = wla.active_object(['MESH'])
# 		if active_obj is None:
# 			self.report({'ERROR'}, "Select mesh object first")
# 			return {'CANCELLED'}
# 		active_mesh = active_obj.data
# 		vertsIdx =  wla.selected_vertsIdx(active_mesh)
# 		edgesIdx =  wla.selected_edgesIdx(active_mesh)
# 		if len(vertsIdx) < 2:
# 			del config.WPL_G.store[config.kWPLGKey_EdgePinStrands]
# 			#del config.WPL_G.store[config.kWPLGKey_EdgePinVerts]
# 			self.report({'ERROR'}, "No selected edges found, dropping all")
# 			return {'FINISHED'} # or all changes get lost!!!
# 		bm_defrco, _ = wla_bm.bm_getDeformedCos(active_obj)
# 		wla_do.select_and_change_mode(active_obj, 'EDIT')
# 		bm = bmesh.from_edit_mesh(active_mesh)
# 		bm.verts.ensure_lookup_table()
# 		bm.faces.ensure_lookup_table()
# 		bm.verts.index_update()
# 		vHistIdx = wla_bm.bm_historyVertsIdx(bm)
# 		vHistIdx = list(reversed(vHistIdx)) # Last selected - last in list
# 		vLastSelectedIdx = None
# 		if len(vHistIdx) > 0:
# 			vLastSelectedIdx = vHistIdx[-1]
# 			print("- vHistIdx", vHistIdx)
# 		strands_points = None
# 		# strands in deformed coords+rVerts for custom axis
# 		strands_dfrm = []
# 		if self.opt_srcMode == 'EDG':
# 			strands_points, strands_vidx = wla_bm.bm_edgesAsStrands_v04(active_obj, bm, vertsIdx, edgesIdx, self.opt_flowDir, active_obj)
# 			if strands_vidx is None:
# 				self.report({'ERROR'}, "No selected edges found")
# 				return {'FINISHED'}
# 			# sorting strand according to history verts
# 			# last selected should be near the end!
# 			# natural selection order: First -> CtrlClick -> Last
# 			if vLastSelectedIdx is not None:
# 				vlist0 = strands_vidx[0]
# 				lsIdx = vlist0.index(vLastSelectedIdx) if vLastSelectedIdx in vlist0 else -1
# 				if lsIdx >= 0 and lsIdx < len(vlist0)/2:
# 					strands_vidx[0].reverse()
# 					strands_points[0].reverse()
# 					#vlist0 = strands_vidx[0]
# 					#lsIdx2 = vlist0.index(vLastSelectedIdx) if vLastSelectedIdx in vlist0 else -1
# 					#print("- reverting vertex list according to active vert:",lsIdx,lsIdx2,vlist0)
# 					print("- reverting vertex list according to active vert")
# 			for strand_idx in strands_vidx:
# 				vCos_dfrm = []
# 				for i, vIdx in enumerate(strand_idx):
# 					v = bm.verts[vIdx]
# 					vco = v.co
# 					vco_dfrm = bm_defrco[vIdx]
# 					vertR = wla_bm.bm_vertSecondAxisVert( v, vertsIdx, True )
# 					vrco_dfrm = bm_defrco[vertR.index]
# 					vLDir_l = None
# 					if i==0:
# 						vIdx2 = strand_idx[i+1]
# 						v2 = bm.verts[vIdx2]
# 						vLDir_l = (v2.co-v.co).normalized()
# 					else:
# 						vIdx2 = strand_idx[i-1]
# 						v2 = bm.verts[vIdx2]
# 						vLDir_l = (v.co-v2.co).normalized()
# 					vUpDir_l = (vrco_dfrm-vco_dfrm).normalized().cross(vLDir_l)
# 					vUpDir_l = wla_vgs.srcbvh_orientToSurroundFaces(active_obj, vIdx, vUpDir_l, None)
# 					vCos_dfrm.append( (active_obj.matrix_world @ vco_dfrm, active_obj.matrix_world @ vrco_dfrm, active_obj.matrix_world @ (vco_dfrm+vLDir_l), active_obj.matrix_world @ (vco_dfrm+vUpDir_l) ))
# 				strands_dfrm.append(vCos_dfrm)
# 		else:
# 			if self.opt_srcMode == 'VERTHIST':
# 				vertsIdx = vHistIdx
# 			else: # VERTLINE
# 				vertsIdx = wla_bm.bm_sortVertsByConnection(bm, vertsIdx, True, True)
# 			if vLastSelectedIdx is not None:
# 				lsIdx = vertsIdx.index(vLastSelectedIdx) if vLastSelectedIdx in vertsIdx else -1
# 				if lsIdx >= 0 and lsIdx < len(vertsIdx)/2:
# 					vertsIdx.reverse()
# 					print("- reverting vertex list according to active vert")
# 			vCos = []
# 			vCos_dfrm = []
# 			for i,vIdx in enumerate(vertsIdx):
# 				v = bm.verts[vIdx]
# 				vco = v.co
# 				vco_dfrm = bm_defrco[vIdx]
# 				vCos.append(active_obj.matrix_world @ vco)
# 				vertR = wla_bm.bm_vertSecondAxisVert( v, vertsIdx, True )
# 				if vertR is None:
# 					# searchin without refVerts, since for sparce selection no near refverts is totally possible
# 					vertR = wla_bm.bm_vertSecondAxisVert( v, None, True )
# 				if vertR is None:
# 					print("- Warning: rVert not found:", v.index)
# 					continue
# 				#print("- rVert:", v.index, vertR.index)
# 				#vertR.select = True # DBG
# 				vrco_dfrm = bm_defrco[vertR.index]
# 				vLDir_l = None
# 				if i == 0:
# 					vIdx2 = vertsIdx[i+1]
# 					v2 = bm.verts[vIdx2]
# 					vLDir_l = (v2.co-v.co).normalized()
# 				else:
# 					vIdx2 = vertsIdx[i-1]
# 					v2 = bm.verts[vIdx2]
# 					vLDir_l = (v.co-v2.co).normalized()
# 				vUpDir_l = (vrco_dfrm-vco_dfrm).normalized().cross(vLDir_l)
# 				vUpDir_l = wla_vgs.srcbvh_orientToSurroundFaces(active_obj, vIdx, vUpDir_l, None)
# 				vCos_dfrm.append( (active_obj.matrix_world @ vco_dfrm, active_obj.matrix_world @ vrco_dfrm, active_obj.matrix_world @ (vco_dfrm+vLDir_l), active_obj.matrix_world @ (vco_dfrm+vUpDir_l) ))
# 			strands_points = [vCos]
# 			strands_dfrm = [vCos_dfrm]
# 			#bmesh.update_edit_mesh(active_mesh) # DBG
# 		if (strands_points is None) or len(strands_points) == 0:
# 			self.report({'ERROR'}, "No edges found")
# 			return {'FINISHED'} # or all changes get lost!!!
# 		# vertsIdxCoKeys = []
# 		# for vIdx in vertsIdx:
# 		# 	v = bm.verts[vIdx]
# 		# 	vertsIdxCoKeys.append(wla.coToKey(v.co))
# 		#config.WPL_G.store[config.kWPLGKey_EdgePinVerts] = (vertsIdx, vertsIdxCoKeys)
# 		if self.opt_append2last and (config.kWPLGKey_EdgePinStrands in config.WPL_G.store):
# 			(strands_points_pre, strands_dfrm_pre) = config.WPL_G.store[config.kWPLGKey_EdgePinStrands]
# 			strands_points = strands_points_pre+strands_points
# 			strands_dfrm = strands_dfrm_pre+strands_dfrm
# 		config.WPL_G.store[config.kWPLGKey_EdgePinStrands] = (strands_points, strands_dfrm)
# 		self.report({'INFO'}, "Done. Stored points:"+str(len(strands_points[-1]))+", edgelines saved:"+str(len(strands_points)))
# 		return {'FINISHED'}

# class wplsculpt_fastpin_edges_snap(bpy.types.Operator):
# 	bl_idname = "mesh.wplsculpt_fastpin_edges_snap"
# 	bl_label = "Snap to stored edgeline"
# 	bl_options = {'REGISTER', 'UNDO'}

# 	opt_invertDir : BoolProperty(
# 		name="Edge fit: Invert",
# 		default=False
# 	)
# 	opt_mode : EnumProperty(
# 		items = [
# 			('EDGE2EDGE', "Edge: Fit to length", "", 1),
# 			('VSHRINKWR', "Verts: Shrinkwrap", "", 2),
# 		],
# 		name="Action",
# 		default='VSHRINKWR',
# 	)

# 	def execute( self, context ):
# 		active_obj = wla.active_object(['MESH'])
# 		if active_obj is None:
# 			self.report({'ERROR'}, "Select mesh object first")
# 			return {'CANCELLED'}
# 		if (config.kWPLGKey_EdgePinStrands not in config.WPL_G.store):
# 			self.report({'ERROR'}, "Save some edgelines first")
# 			return {'CANCELLED'}
# 		(strands_pointsIni, _) = config.WPL_G.store[config.kWPLGKey_EdgePinStrands]
# 		active_mesh = active_obj.data
# 		vertsIdx =  wla.selected_vertsIdx(active_mesh)
# 		edgesIdx =  wla.selected_edgesIdx(active_mesh)
# 		if self.opt_mode == 'EDGE2EDGE' and len(edgesIdx)<1:
# 			self.report({'ERROR'}, "No selected edges found, select some edges first")
# 			return {'FINISHED'} # or all changes get lost!!!
# 		if len(vertsIdx)<1:
# 			self.report({'ERROR'}, "No selected verts found, select some verts first")
# 			return {'FINISHED'} # or all changes get lost!!!
# 		wla_do.select_and_change_mode(active_obj, 'EDIT')
# 		bm = bmesh.from_edit_mesh(active_mesh)
# 		bm.verts.ensure_lookup_table()
# 		bm.faces.ensure_lookup_table()
# 		bm.verts.index_update()
# 		if self.opt_mode == 'VSHRINKWR':
# 			pttree = KDTree(1000)
# 			for strand in strands_pointsIni:
# 				for gp_p in strand:
# 					pttree.insert(gp_p, 0)
# 			pttree.balance()
# 			for vIdx in vertsIdx:
# 				v = bm.verts[vIdx]
# 				vco_g = active_obj.matrix_world @ v.co
# 				pt_res = pttree.find_n(vco_g, 2)
# 				if pt_res is not None and len(pt_res) > 1:
# 					p1 = pt_res[0][0]
# 					p2 = pt_res[1][0]
# 					pNear = mathutils.geometry.intersect_point_line(vco_g, p1, p2)
# 					v.co = active_obj.matrix_world.inverted() @ pNear[0]
# 			self.report({'INFO'}, "Done. Shrinkwrapped points="+str(len(vertsIdx)))
# 			return {'FINISHED'}
# 		opt_flowDir = Vector((0.0,0.0,-1.0))
# 		strands_points, strands_vidx = wla_bm.bm_edgesAsStrands_v04(active_obj, bm, vertsIdx, edgesIdx, opt_flowDir, active_obj)
# 		if strands_points is None or len(strands_points) == 0:
# 			self.report({'ERROR'}, "No edges found")
# 			return {'FINISHED'} # or all changes get lost!!!
# 		print("strands_vidx", strands_vidx)
# 		strand_vids = strands_vidx[0]
# 		strand = strands_pointsIni[-1]
# 		curve_cache = {}
# 		len_trg = 0.0
# 		for gp_p in strand:
# 			len_trg = wla.math_lerpCurveAdd(gp_p, [gp_p], curve_cache)
# 		if len_trg>0.00001:
# 			for j, vIdx in enumerate(strand_vids):
# 				vert = bm.verts[vIdx]
# 				t_pos = float(j)/float(len(strand_vids)-1)
# 				if self.opt_invertDir:
# 					t_pos = 1.0 - t_pos
# 				new_co_g = wla.math_lerpCurveGet(t_pos, 0, curve_cache)
# 				new_co_l = active_obj.matrix_world.inverted() @ new_co_g
# 				vert.co = Vector((new_co_l[0], new_co_l[1], new_co_l[2]))
# 		bm.normal_update()
# 		bmesh.update_edit_mesh(active_mesh)
# 		self.report({'INFO'}, "Done. Snapped points="+str(len(strand_vids)))
# 		return {'FINISHED'}

# class wplverts_edge_depenetr(bpy.types.Operator): 
# # hard to use... face disks covering not predictable on deformed mesh (non-equal quads)
# 	bl_idname = "mesh.wplverts_edge_depenetr"
# 	bl_label = "Ease penetrations"
# 	bl_options = {'REGISTER', 'UNDO'}

# 	opt_shiftFrac : FloatProperty(
# 		name		= "Step fraction",
# 		min		 = 0.01,
# 		max		 = 1.0,
# 		default	 = 1.0
# 	)
# 	opt_shiftSteps : IntProperty (
# 		name = "Steps",
# 		min = 0, max = 100,
# 		default = 1
# 	)
# 	opt_distLimit : FloatProperty(
# 		name		= "Nearness limits",
# 		min		 = 0.0,
# 		max		 = 1.0,
# 		default	 = 0.01
# 	)
# 	opt_shiftAbove : FloatProperty(
# 		name		= "Place Above",
# 		min		 = 0.0,
# 		max		 = 1.0,
# 		default	 = 0.0
# 	)
# 	opt_pinID : StringProperty(
# 		name		= "Pin ID",
# 		default	 	= ""
# 	)

# 	def execute( self, context ):
# 		active_obj = wla.active_object(['MESH'])
# 		if active_obj is None:
# 			self.report({'ERROR'}, "Select mesh object first")
# 			return {'CANCELLED'}
# 		active_mesh = active_obj.data
# 		vertsIdx = wla.selected_vertsIdx(active_mesh)
# 		if len(vertsIdx) == 0:
# 			self.report({'ERROR'}, "No selected verts found, select some verts first")
# 			return {'FINISHED'}
# 		wla_do.select_and_change_mode(active_obj, 'EDIT')
# 		bm = bmesh.from_edit_mesh(active_mesh)
# 		bm.verts.ensure_lookup_table()
# 		bm.faces.ensure_lookup_table()
# 		bm.verts.index_update()
# 		vertNoBm = {}
# 		for vIdx in vertsIdx:
# 			v = bm.verts[vIdx]
# 			vertNoBm[vIdx] = v.normal
# 		facesDisk_g = []
# 		# if len(self.opt_pinID) == 0:
# 		# 	# self-collisions
# 		# 	for f in bm.faces:
# 		# 		if f.hide:
# 		# 			continue
# 		# 		f_co = f.calc_center_median()
# 		# 		f_isNeeded = False
# 		# 		f_edgeLen = 0
# 		# 		for v in f.verts:
# 		# 			f_edgeLen = max(f_edgeLen, (v.co-f_co).length)
# 		# 			if v.index in vertsIdx:
# 		# 				f_isNeeded = True
# 		# 		if f_isNeeded:
# 		# 			facesBm_l.append( (f, f_edgeLen) )
# 		# else:
# 		if self.opt_pinID+"_selfaces_disk" in config.WPL_G.store:
# 			facesDisk_g = config.WPL_G.store[self.opt_pinID+"_selfaces_disk"]
# 		if len(facesDisk_g) == 0:
# 			self.report({'ERROR'}, "No faces found")
# 			return {'FINISHED'}
# 		print("- faceDisk pts",len(facesDisk_g))
# 		ao_mw_inv = active_obj.matrix_world.inverted()
# 		# https://github.com/sakana3/PolyQuilt/blob/e5a5e68175292b442526349b6db951ed7b718a5d/Addons/PolyQuilt/utils/pqutil.py
# 		ao_mw_nrm_g_inv = active_obj.matrix_world.transposed().to_3x3() # .inverted().inverted()
# 		#opt_distLimit_l = ((ao_mw_inv @ Vector((0,0,0))) - (ao_mw_inv @ (Vector((0,0,0)) + Vector((0,0,self.opt_distLimit))))).length 
# 		opt_distLimit_l = (ao_mw_nrm_g_inv @ Vector((self.opt_distLimit,self.opt_distLimit,self.opt_distLimit))).length
# 		faceDir = []
# 		for f_co_g, f_no_g, f_rad_g in facesDisk_g:
# 			f_co = ao_mw_inv @ f_co_g
# 			f_no = (ao_mw_nrm_g_inv @ f_no_g).normalized()
# 			f_rad = (ao_mw_nrm_g_inv @ Vector((f_rad_g,f_rad_g,f_rad_g))).length
# 			# f_rad = max(f_rad, (ao_mw_nrm_g_inv @ Vector((0,f_rad_g,0))).length)
# 			# f_rad = max(f_rad, (ao_mw_nrm_g_inv @ Vector((f_rad_g,0,0))).length)
# 			#f_rad = ((ao_mw_inv @ f_co_g) - (ao_mw_inv @ (f_co_g + Vector((0,0,f_rad_g))))).length
# 			faceDir.append( (f_co, f_no, f_rad, None) )
# 		for ii in range(self.opt_shiftSteps):
# 			shifts = {}
# 			# if len(facesBm_l) > 0:
# 			# 	for f, f_rad in facesBm_l:
# 			# 		f_no = f.normal
# 			# 		f_co = f.calc_center_median()
# 			# 		faceDir.append( (f_co, f_no, f_rad, f) )
# 			# 	# # looking for verts on faces that half outer - half inner
# 			# 	# # BMESH self-itersections
# 			# 	# vertsISct = set()
# 			# 	# facesISct = set()
# 			# 	# tree, _ = wla_bm.bm_BVHFromFaces(bm, fIdxes)
# 			# 	# intersect_pairs = tree.overlap(tree)
# 			# 	# #print("- intersect_pairs", intersect_pairs)
# 			# 	# for pair in intersect_pairs:
# 			# 	# 	(first_index, second_index) = pair
# 			# 	# 	# exclude pairs with same index because these are false positive as result of cloning
# 			# 	# 	if first_index != second_index:
# 			# 	# 		f1 = bm.faces[fIdxes[first_index]]
# 			# 	# 		f2 = bm.faces[fIdxes[second_index]]
# 			# 	# 		facesISct.add(fIdxes[first_index])
# 			# 	# 		facesISct.add(fIdxes[second_index])
# 			# 	# 		for v in f1.verts:
# 			# 	# 			hit_loc, normal, index, distance = tree.ray_cast(v.co+v.normal*0.0001, v.normal)
# 			# 	# 			if hit_loc is not None:
# 			# 	# 				vertsISct.add(v.index)
# 			# 	# 		for v in f2.verts:
# 			# 	# 			hit_loc, normal, index, distance = tree.ray_cast(v.co+v.normal*0.0001, v.normal)
# 			# 	# 			if hit_loc is not None:
# 			# 	# 				vertsISct.add(v.index)
# 			# 	#print("- selfintersect", len(intersect_pairs), len(vertsISct))
# 			possibls = 0
# 			for vIdx in vertsIdx:
# 				v = bm.verts[vIdx]
# 				v_no = vertNoBm[vIdx] # v.normal
# 				for f_co, f_no, f_rad, ff in faceDir:
# 					bubble_dir = f_no
# 					if (ff is not None):
# 						if v in ff.verts:
# 							continue
# 					if(f_co-v.co).length > opt_distLimit_l:
# 						continue
# 					possibls = possibls+1
# 					if f_no.normalized().dot( v_no ) < 0.0:
# 						continue
# 					if (f_co-v.co).normalized().dot( bubble_dir ) < 0.0:
# 						continue
# 					proj_co = mathutils.geometry.intersect_line_plane(v.co, v.co + bubble_dir, f_co, f_no)
# 					if (proj_co is None):
# 						continue
# 					if (proj_co-f_co).length > f_rad:
# 						continue
# 					if (proj_co-v.co).length > opt_distLimit_l:
# 						continue
# 					if (proj_co-v.co).normalized().dot( bubble_dir ) < 0.0:
# 						continue
# 					if (vIdx not in shifts):
# 						shifts[vIdx] = []
# 					pp = proj_co + f_no*self.opt_shiftAbove
# 					shifts[vIdx].append( ( pp, pow((f_co-v.co).length, 2) ) )
# 			print("- step:", ii+1, "shifts:", len(shifts)," possibles",possibls,len(vertsIdx),len(faceDir))
# 			if len(shifts) == 0:
# 				break
# 			for vIdx in shifts:
# 				#print("--",sh_v.index, sh_v.co, sh_v_proj, self.opt_shiftFrac)
# 				sh_v = bm.verts[vIdx]
# 				sprjs = shifts[vIdx]
# 				wmax = max([itm[1] for itm in sprjs])
# 				wmin = max([itm[1] for itm in sprjs])
# 				weightsNrms = [ (1.0-(itm[1]-wmin)/(wmax-wmin+0.001)) for itm in sprjs]
# 				nx = np.average([itm[0][0] for itm in sprjs],weights=weightsNrms)
# 				ny = np.average([itm[0][1] for itm in sprjs],weights=weightsNrms)
# 				nz = np.average([itm[0][2] for itm in sprjs],weights=weightsNrms)
# 				sh_v_proj = Vector((nx,ny,nz))
# 				sh_v.co = sh_v.co.lerp(sh_v_proj, self.opt_shiftFrac)
# 			bm.normal_update()
# 		bmesh.update_edit_mesh(active_mesh)
# 		self.report({'INFO'}, "Done, "+str(len(vertsIdx))+" verts moved")
# 		return {'FINISHED'}


class wplverts_prepinneds(bpy.types.Operator):
	bl_idname = "mesh.wplverts_prepinneds"
	bl_label = "Pre-pinned Ops"
	bl_options = {'REGISTER', 'UNDO'}

	opt_passOp : EnumProperty(
		name="operator", default="MIRA",
		items=(("MIRA", "Mira", ""), 
		("VIEWLATTICE", "ViewLattice", ""))
	)

	opt_ops_param : IntProperty(
		name	 = "Ops param",
		default	 = 10
	)

	def execute( self, context ):
		# Prepinned mira/mirra
		bpy.ops.mesh.wplverts_pinsnap(opt_pinId = "fastpin1")
		if self.opt_passOp == 'MIRA':
			try:
				context.scene.mi_cur_stretch_settings.points_number = self.opt_ops_param
			except Exception as e:
				print(" Error: Mira execution failed", e)
				return {'FINISHED'}
			return bpy.ops.mira.curve_stretch('INVOKE_DEFAULT')
		if self.opt_passOp == 'VIEWLATTICE':
			# bpy.ops.mesh.wplarmd_viewlattice(opt_action = "VIEW")
			return bpy.ops.mesh.wplarmd_viewlattice('INVOKE_DEFAULT', opt_action = "VIEW")
		return {'FINISHED'}

# ==========================================
# ==========================================
# ==========================================
# ==========================================

def uilayout_lattBox(col, context):
	col.label(text="Lattice operations")
	row1 = col.row()
	row1.operator("mesh.wplsculpt_stepsubd", text="Subd +1", icon="MOD_PARTICLE_INSTANCE")
	row1.operator("mesh.wplarmd_viewlattice", text = 'Reset Insides').opt_action = 'RESETDEFRM'
	active_obj = wla.active_object(['LATTICE'])
	if (active_obj is not None) and (config.kWPLMeshDeformMod in active_obj):
		row1 = col.row()
		row1.operator("mesh.wplarmd_viewlattice", text = 'FINALIZE').opt_action = 'APPLY'
		row1.operator("mesh.wplarmd_viewlattice", text = 'CANCEL').opt_action = 'CANCEL'
	else:
		col.operator("mesh.wplarmd_viewlattice", text = 'CANCEL').opt_action = 'CANCEL'

class WPL_PT_SculptVPanel(bpy.types.Panel):
	bl_idname = "WPL_PT_SculptVPanel"
	bl_label = "Pinning"
	bl_space_type = 'VIEW_3D'
	bl_region_type = 'UI'
	bl_category = 'Sculpt'

	def draw(self, context):
		layout = self.layout
		active_obj = wla.active_object()
		col = layout.column()
			
		if active_obj is not None and wla.is_edit_mode():
			box1 = col.box()
			box1.label(text = "Pre-pinned Shortcuts")
			if active_obj.type == 'LATTICE':
				# helper for "VIEWLATTICE"
				uilayout_lattBox(col, context)
			if active_obj.type == 'MESH':
				row1 = box1.row(align=True)
				op = row1.operator("mesh.wplverts_prepinneds", text = 'M[2]')
				op.opt_ops_param = 2
				op.opt_passOp = "MIRA"
				op = row1.operator("mesh.wplverts_prepinneds", text = 'M[3]')
				op.opt_ops_param = 3
				op.opt_passOp = "MIRA"
				op = row1.operator("mesh.wplverts_prepinneds", text = 'M[4]')
				op.opt_ops_param = 4
				op.opt_passOp = "MIRA"
				op = row1.operator("mesh.wplverts_prepinneds", text = 'M[5]')
				op.opt_ops_param = 5
				op.opt_passOp = "MIRA"
				op = row1.operator("mesh.wplverts_prepinneds", text = 'M[6]')
				op.opt_ops_param = 6
				op.opt_passOp = "MIRA"
				op = box1.operator("mesh.wplverts_prepinneds", text = 'ViewLattice')
				op.opt_ops_param = 0
				op.opt_passOp = "VIEWLATTICE"
		if active_obj is not None and active_obj.data is not None:
			box1 = col.box()
			box1.label(text = "S1: Commons")
			box1c = box1.column(align=True)
			ss0 = box1c.operator("mesh.wplverts_pinsnap", text="S1: Pin surface", icon="SNAP_NORMAL")
			ss0.opt_pinId = "fastpin1"
			ss0 = box1c.operator("mesh.wplverts_pinpropagt", text="S1: Smooth selection", icon = "GP_SELECT_POINTS")
			ss0.opt_mode = 'KEEPACTIV'
			ss0.opt_pinId = "fastpin1"
			opr6 = box1c.row(align=True)
			ss2 = opr6.operator("mesh.wplverts_pinsurfshrw", text="S1: Recast")
			ss2.opt_shrinkwMethod = 'SHRINKWRAP_RECAST'
			ss2.opt_vertsType = 'ALL'
			ss2.opt_pinId = "fastpin1"
			ss1 = opr6.operator("mesh.wplverts_pinsurfshrw", text="S1: Shrinkwrap")
			ss1.opt_shrinkwMethod = 'SHRINKWRAP_RAW'
			ss1.opt_vertsType = 'ALL'
			ss1.opt_pinId = "fastpin1"
			opr6 = box1c.row(align=True)
			ss2 = opr6.operator("mesh.wplverts_pinsurfshrw", text="S1: View-cast, TO")
			ss2.opt_shrinkwMethod = 'VIEWPROJTO_GRID'
			ss2.opt_vertsType = 'ALL'
			ss2.opt_pinId = "fastpin1"
			ss1 = opr6.operator("mesh.wplverts_pinsurfshrw", text="S1: View-cast, FROM")
			ss1.opt_shrinkwMethod = 'VIEWPROJFROM_GRID'
			ss1.opt_vertsType = 'ALL'
			ss1.opt_pinId = "fastpin1"
			# ss3 = box1c.operator("mesh.wplverts_edge_depenetr", text="Depenetrate")
			# ss3.opt_pinID = "fastpin1"
			col.separator()
			box1 = col.box()
			box1.label(text = "vSel: Convex")
			row1 = box1.row(align=True)
			row1.operator("mesh.wplsculpt_pin_toconvex", text="Pin convex", icon="SNAP_NORMAL")
			row1.operator("mesh.wplsculpt_flt_toconvex_mesh", text="Wrap to pinned").opt_convexMode = 'USEPINNED'
			col.separator()
			box1 = col.box()
			box1.label(text = "S1: Enforce (smooth reset)")
			box1c = box1.column(align=True)
			opr4 = box1c.row(align=True)
			opr4.operator("mesh.wplverts_pinpropagt", text="Selected").opt_mode = 'ENFORSEL'
			opr4.operator("mesh.wplverts_pinpropagt", text="Preselects").opt_mode = 'ENFORPINS'
			opr4.operator("mesh.wplverts_pinpropagt", text="Seams").opt_mode = 'ENFORSEAMS'
			opr5 = box1c.row(align=True)
			opr5.operator("mesh.wplverts_pinrestore", text="Hard Reset").opt_mode = 'DIRECT'
			opr5.operator("mesh.wplverts_pinrestore", text="Reset To CamLine").opt_mode = 'CAMERA'
			col.separator()
			box1 = col.box()
			box1.label(text = "S2: Commons")
			box1c = box1.column(align=True)
			ss0 = box1c.operator("mesh.wplverts_pinsnap", text="S2: Pin surface", icon="SNAP_NORMAL")
			ss0.opt_pinId = "fastpin2"
			ss0 = box1c.operator("mesh.wplverts_pinpropagt", text="S2: Smooth selection", icon = "GP_SELECT_POINTS")
			ss0.opt_mode = 'KEEPACTIV'
			ss0.opt_pinId = "fastpin2"
			opr6 = box1c.row(align=True)
			ss2 = opr6.operator("mesh.wplverts_pinsurfshrw", text="S2: Recast")
			ss2.opt_shrinkwMethod = 'SHRINKWRAP_RECAST'
			ss2.opt_vertsType = 'ALL'
			ss2.opt_pinId = "fastpin2"
			ss1 = opr6.operator("mesh.wplverts_pinsurfshrw", text="S2: Shrinkwrap")
			ss1.opt_shrinkwMethod = 'SHRINKWRAP_RAW'
			ss1.opt_vertsType = 'ALL'
			ss1.opt_pinId = "fastpin2"

# ==========================================
# ==========================================

classes = (
	WPL_PT_SculptVPanel,

	wplverts_pinsnap,
	wplverts_pinrestore,
	wplverts_pinpropagt,
	wplverts_pinsurfshrw,
	wplverts_prepinneds,
	#wplverts_edge_depenetr,
	#wplsculpt_fastpin_edges,
	#wplsculpt_fastpin_edges_snap,
)

def register():
	for cls in classes:
		bpy.utils.register_class(cls)

def unregister():
	for cls in reversed(classes):
		bpy.utils.unregister_class(cls)

if __name__ == "__main__":
	register()