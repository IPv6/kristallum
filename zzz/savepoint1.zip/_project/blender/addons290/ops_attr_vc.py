import os, sys, time, datetime
import math, copy, string, random
import numpy as np
import bpy, bmesh, mathutils

import bpy.types
from mathutils import Vector, Matrix, Euler, Quaternion
from mathutils.bvhtree import BVHTree
from mathutils.kdtree import KDTree
from bpy_extras import view3d_utils
from bpy.props import *

from . import config
from .tools import wla
from .tools import wla_do
from .tools import wla_bm
from .tools import wla_attr

kWPL_VCLIST_MAXITEMS = 10
kWPL_VCLIST_NOOP = '...'

# ==========================================

def getActiveBrush(context):
	if context.area.type == 'VIEW_3D' and context.vertex_paint_object:
		brush = context.tool_settings.vertex_paint.brush
	elif context.area.type == 'VIEW_3D' and context.image_paint_object:
		brush = context.tool_settings.image_paint.brush
	elif context.area.type == 'IMAGE_EDITOR' and  context.space_data.mode == 'PAINT':
		brush = context.tool_settings.image_paint.brush
	else:
		brush = None
	return brush

def setActiveBrushColor(context, newcol):
	wpl_vcOpts = context.scene.wpl_vcOpts
	wpl_vcOpts.bake_vc_col = (newcol[0],newcol[1],newcol[2])
	try:
		wplEdgeBuildProps = context.scene.wplEdgeBuildProps
		wplEdgeBuildProps.opt_edgeCol = wpl_vcOpts.bake_vc_col
	except:
		pass
	br = getActiveBrush(context)
	if br:
		br.color = mathutils.Vector((newcol[0],newcol[1],newcol[2]))

# ==========================================

class wplvc_updcol(bpy.types.Operator):
	bl_idname = "mesh.wplvc_updcol"
	bl_label = "Update color"
	bl_options = {'REGISTER', 'UNDO'}

	opt_target : EnumProperty(
		name="Target", default="FACE",
		items=(("FACE", "FACE", ""), ("VERT", "VERT", ""), ("PROP", "Custom prop", ""))
	)
	opt_influence : FloatProperty(
		name="Influence",
		min=0.0001, max=1.0,
		default=1
	)
	opt_rgbMask : FloatVectorProperty(
		name="RGB mask",
		size=3,
		default=(1.0, 1.0, 1.0)
	)

	def execute( self, context ):
		wpl_vcOpts = context.scene.wpl_vcOpts
		active_objs = wla.selected_objects(['MESH', 'CURVE', 'FONT', 'GPENCIL'])
		if len(active_objs) == 0:
			self.report({'INFO'}, "Nothing selected")
			return {'CANCELLED'}
		if len(wpl_vcOpts.vc_name) == 0:
			wpl_vcOpts.vc_name = config.kWPLMeshColVC
		if (kWPL_VCLIST_NOOP in wpl_vcOpts.vc_name) or (len(wpl_vcOpts.vc_name) == 0):
			self.report({'INFO'}, "Select VC first")
			return {'CANCELLED'}
		#active_obj = wla.active_object()
		setCount = 0
		color_map = None
		for active_obj in active_objs:
			target_mod = self.opt_target
			if active_obj.type == 'MESH' and wla.modf_by_type(active_obj,'SKIN') is not None:
				target_mod = 'PROP'
			if (active_obj.type == 'CURVE') or (active_obj.type == 'FONT') or (active_obj.type == 'GPENCIL'):
				target_mod = 'PROP'
			if (wla.modf_by_type(active_obj, 'REMESH') is not None):
				target_mod = 'PROP'
			if config.kWPLAutoSetupCustomPropCol in wpl_vcOpts.vc_name:
				target_mod = 'PROP'
			if (target_mod == 'PROP'):
				# No gamma correction here! opt_correctGamma - when converted to mesh
				#wla_attr.vc_obj_update(active_obj, 'PROP', wpl_vcOpts.vc_name, wpl_vcOpts.bake_vc_col, self.opt_rgbMask, self.opt_influence, None,None,None)
				wla_attr.vc_obj_setPropCol(active_obj, wpl_vcOpts.vc_name, wpl_vcOpts.bake_vc_col, 'COL_TO_GAMMA, PROP_NON_GAMMA')
				# self.report({'INFO'}, "Updated prop:" + wpl_vcOpts.vc_name)
				active_obj.update_tag()
				setCount = setCount+1
				continue
			oldmode = wla_do.select_and_change_mode(active_obj,"OBJECT")
			active_mesh = active_obj.data
			selverts = None
			selfaces = None
			if len(active_objs) == 1:
				selverts = wla.selected_vertsIdx(active_mesh)
				selfaces = wla.selected_facesIdx(active_mesh)
				if (target_mod == 'FACE' and len(selfaces) == 0) or (target_mod == 'VERT' and len(selverts) == 0):
					selverts = None #[e.index for e in active_mesh.vertices]
					selfaces = None #[f.index for f in active_mesh.polygons]
			gradinfo = None
			color_map = wla_attr.vc_obj_ensure(active_obj, wpl_vcOpts.vc_name)
			active_mesh.vertex_colors.active = color_map
			setCount = setCount + wla_attr.vc_obj_update(active_obj, target_mod, wpl_vcOpts.vc_name, wpl_vcOpts.bake_vc_col, self.opt_rgbMask, self.opt_influence, gradinfo, selverts, selfaces)
			# if len(active_objs) == 1:
			# 	# storing gradient data
			# 	selCenter = Vector((0,0,0))
			# 	if selverts is not None:
			# 		selCenterCnt = 0.0
			# 		for vIdx in selverts:
			# 			v = active_mesh.vertices[vIdx]
			# 			selCenter = selCenter+v.co
			# 			selCenterCnt = selCenterCnt+1.0
			# 		if selCenterCnt>0.0:
			# 			selCenter = selCenter/selCenterCnt
			# 	active_obj["wpl_last_paint"] = [selCenter, wpl_vcOpts.bake_vc_col] # kWPLCustomPropTag... required
			wla_do.select_and_change_mode(active_obj, oldmode)
			print("- wplvc_updcol", active_obj, target_mod, wpl_vcOpts.bake_vc_col, 'verts='+str(setCount))
			if (selverts == None or len(selverts) == 0) and (selfaces == None or len(selfaces) == 0):
				print("// not limited")
		self.report({'INFO'}, wpl_vcOpts.vc_name+': verts='+str(setCount))
		return {'FINISHED'}

class wplvc_pickcol(bpy.types.Operator):
	bl_idname = "mesh.wplvc_pickcol"
	bl_label = "Pick color from faces"
	bl_options = {'REGISTER', 'UNDO'}

	def execute( self, context ):
		wpl_vcOpts = context.scene.wpl_vcOpts
		if (kWPL_VCLIST_NOOP in wpl_vcOpts.vc_name) or (len(wpl_vcOpts.vc_name) == 0):
			self.report({'INFO'}, "Select VC first")
			return {'CANCELLED'}
		active_obj = wla.active_object(["MESH"])
		if active_obj is None:
			# custom prop selected?
			active_obj = wla.active_object()
			if (active_obj is not None) and (wpl_vcOpts.vc_name in active_obj):
				col = active_obj[wpl_vcOpts.vc_name]
				col = (math.pow(col[0], 1.0/2.2), math.pow(col[1], 1.0/2.2), math.pow(col[2], 1.0/2.2)  ) # COL_FROM_GAMMA
				setActiveBrushColor(context, col)
				self.report({'INFO'}, "Color picked (PROP)")
				return {'FINISHED'}
		if active_obj is None:
			self.report({'ERROR'}, "Select mesh object first")
			return {'CANCELLED'}
		active_mesh = active_obj.data
		oldmode = wla_do.select_and_change_mode(active_obj,"OBJECT")
		selfaces = wla.selected_facesIdx(active_mesh)
		# wla_do.select_and_change_mode(active_obj,"VERTEX_PAINT")
		if len(selfaces) < 1:
			self.report({'ERROR'}, "Select faces first")
			return {'CANCELLED'}
		print("- picking from", len(selfaces),"faces on",active_obj.name,"for",wpl_vcOpts.vc_name)
		pickedcol, _ = wla_attr.vc_obj_avgcolor(active_obj, wpl_vcOpts.vc_name, selfaces)
		if pickedcol is None:
			self.report({'ERROR'}, "Nothing selected")
			return {'FINISHED'}
		color_map = active_mesh.vertex_colors.get(wpl_vcOpts.vc_name)
		active_mesh.vertex_colors.active = color_map
		setActiveBrushColor(context, pickedcol)
		wla_do.select_and_change_mode(active_obj, oldmode)
		self.report({'INFO'}, "Color picked")
		return {'FINISHED'}

class wplvc_cppaste(bpy.types.Operator):
	bl_idname = "mesh.wplvc_cppaste"
	bl_label = "Copy/Paste VC"
	bl_options = {'REGISTER', 'UNDO'}

	opt_op : EnumProperty(
		name="Operation", default="COPY",
		items=(
			('COPY', "COPY", ""), 
			('PASTE', "PASTE", ""),
			('PASTE_SEGM', "PASTE SEGMENTED", ""),
			('SEGMENT', "SEGMENT", "")
		)
	)

	def execute( self, context ):
		sel_all = wla.selected_objects(["MESH"])
		active_obj = wla.active_object(["MESH"])
		if active_obj is None and len(sel_all) > 0:
			# active is empty or alike... not important
			active_obj = sel_all[0]
		if active_obj is None:
			self.report({'ERROR'}, "Select mesh object first")
			return {'CANCELLED'}
		active_mesh = active_obj.data
		wpl_vcOpts = context.scene.wpl_vcOpts
		oldmode = wla_do.select_and_change_mode(active_obj,"OBJECT")
		selfaces = wla.selected_facesIdx(active_mesh)
		if self.opt_op == 'SEGMENT':
			facespasted = wla_attr.mat_segmentFaces(active_obj, selfaces)
			if facespasted < 0:
				print("- segmentation failed: no mat", len(selfaces))
			self.report({'INFO'}, 'SEGMENTATION: Done, faces='+str(facespasted))
		if self.opt_op == 'COPY':
			if len(selfaces) < 1:
				self.report({'ERROR'}, "Select faces first")
				return {'CANCELLED'}
			faceDescr = {}
			faceDescr['obj_name'] = active_obj.name
			for ipoly in range(len(active_mesh.polygons)):
				if ipoly in selfaces:
					faceDescr['material_index'] = active_mesh.polygons[ipoly].material_index
					faceDescr['material_name'] = active_obj.material_slots[faceDescr['material_index']].name
					faceDescr['colors'] = {}
					for idx, lIdx in enumerate(active_mesh.polygons[ipoly].loop_indices):
						ivdx = active_mesh.polygons[ipoly].vertices[idx]
						for vc in active_mesh.vertex_colors:
							col = vc.data[lIdx].color
							pickedcol = Vector((col[0], col[1], col[2]))
							faceDescr['colors'][vc.name] = pickedcol
							if vc.name == wpl_vcOpts.vc_name:
								setActiveBrushColor(context, pickedcol)
					break
			config.WPL_G.store[config.kWPLGKey_vercolCP] = faceDescr
			print('- Material COPY:',faceDescr)
			self.report({'INFO'}, 'COPY: Done')
		if self.opt_op == 'PASTE' or self.opt_op == 'PASTE_SEGM':
			if config.kWPLGKey_vercolCP not in config.WPL_G.store:
				self.report({'ERROR'}, "Nothing copied")
				return {'CANCELLED'}
			faceDescr = copy.copy(config.WPL_G.store[config.kWPLGKey_vercolCP])
			if len(sel_all) > 1:
				print('- Material PASTE: using ALL faces (multiselection)')
				selfaces = None #ignored
			facespasted = 0
			objpasted = 0
			for sel_obj in sel_all:
				wla_do.select_and_change_mode(sel_obj, "OBJECT")
				if sel_obj.type=='MESH':
					sel_mesh = sel_obj.data
					objpasted = objpasted+1
					if faceDescr['obj_name'] != sel_obj.name or self.opt_op == 'PASTE_SEGM':
						# checking materials, VCS, adding missing
						isMatFound = False
						for idx, mt in enumerate(sel_obj.material_slots):
							if mt.name == faceDescr['material_name']:
								isMatFound = True
								faceDescr['material_index'] = idx
								break
						if isMatFound == False or self.opt_op == 'PASTE_SEGM':
							#adding material
							forceSlot = False
							if self.opt_op == 'PASTE_SEGM':
								forceSlot = True
							mtIdx = wla_attr.mat_obj_ensuremat(sel_obj, faceDescr['material_name'], forceSlot)
							faceDescr['material_index'] = mtIdx
					facescolors = faceDescr['colors']
					for cl_name in facescolors:
						if sel_mesh.vertex_colors.get(cl_name) is None:
							# wla_attr.vc_obj_ensure - but manually, no mode changes
							sel_mesh.vertex_colors.new(name = cl_name)
							# defaulting to black
							vc = sel_mesh.vertex_colors.get(cl_name)
							for ipoly in range(len(sel_mesh.polygons)):
								for idx, lIdx in enumerate(sel_mesh.polygons[ipoly].loop_indices):
									vc.data[lIdx].color = (0,0,0,1.0)
					for ipoly in range(len(sel_mesh.polygons)):
						if (selfaces is None) or (ipoly in selfaces):
							sel_mesh.polygons[ipoly].material_index = faceDescr['material_index']
							facespasted = facespasted+1
							for idx, lIdx in enumerate(sel_mesh.polygons[ipoly].loop_indices):
								#ivdx = sel_mesh.polygons[ipoly].vertices[idx]
								for vc in sel_mesh.vertex_colors:
									if vc.name in facescolors:
										col = facescolors[vc.name]
										vc.data[lIdx].color = (col[0],col[1],col[2],1.0)
			print('- Material PASTE: Done, faces='+str(facespasted)+' in '+str(objpasted)+' obj')
			self.report({'INFO'}, 'PASTE: Done, faces='+str(facespasted)+' in '+str(objpasted)+' obj')
		wla_do.select_and_change_mode(active_obj, oldmode)
		return {'FINISHED'}

class wplvc_resetvc(bpy.types.Operator):
	bl_idname = "mesh.wplvc_resetvc"
	bl_label = "Reset color to palette"
	bl_options = {'REGISTER', 'UNDO'}

	opt_resetIdx : IntProperty(
		name="Pallete id",
		min=0, max=10,
		default=0
	)
	def execute( self, context ):
		wpl_vcOpts = context.scene.wpl_vcOpts
		predefsCols = [wpl_vcOpts.bake_vc_col_ref2_d0,wpl_vcOpts.bake_vc_col_ref2_d1,wpl_vcOpts.bake_vc_col_ref2_d2,wpl_vcOpts.bake_vc_col_ref2_d3,wpl_vcOpts.bake_vc_col_ref2_d4,wpl_vcOpts.bake_vc_col_ref2_d5,wpl_vcOpts.bake_vc_col_ref2_d6,wpl_vcOpts.bake_vc_col_ref2_d7,wpl_vcOpts.bake_vc_col_ref2_d8]
		if self.opt_resetIdx-1 < len(predefsCols):
			wpl_vcOpts.bake_vc_col = predefsCols[self.opt_resetIdx-1]
		return {'FINISHED'}

class wplvc_selvccol(bpy.types.Operator):
	bl_idname = "mesh.wplvc_selvccol"
	bl_label = "Pick by color"
	bl_options = {'REGISTER', 'UNDO'}

	opt_target : EnumProperty(
		name="Target", default="COLORBR",
		items=(('COLORBR', "COLORBR", ""), ('COLORSL', "COLORSL", ""))
	)
	opt_colFuzz : FloatProperty(
		name	= "Color distance (HSV/PaletteId)",
		default	= 0.1
	)

	def execute( self, context ):
		active_obj = wla.active_object(["MESH"])
		if active_obj is None:
			self.report({'ERROR'}, "Select mesh object first")
			return {'CANCELLED'}

		wpl_vcOpts = context.scene.wpl_vcOpts
		active_mesh = active_obj.data
		if active_mesh.vertex_colors.get(wpl_vcOpts.vc_name) is None:
			self.report({'ERROR'}, "Target VC not found")
			return {'CANCELLED'}
		oldmode = wla_do.select_and_change_mode(active_obj,"OBJECT")
		basecol = Vector((wpl_vcOpts.bake_vc_col[0],wpl_vcOpts.bake_vc_col[1],wpl_vcOpts.bake_vc_col[2]))
		if self.opt_target == 'COLORSL':
			selfaces = wla.selected_facesIdx(active_mesh)
			pickedcol, _ = wla_attr.vc_obj_avgcolor(active_obj, wpl_vcOpts.vc_name, selfaces)
			if pickedcol is None:
				self.report({'ERROR'}, "Nothing selected")
				return {'FINISHED'}
			basecol = Vector((pickedcol[0],pickedcol[1],pickedcol[2]))
		color_map = active_mesh.vertex_colors.get(wpl_vcOpts.vc_name)
		active_mesh.vertex_colors.active = color_map
		vertx2sel = []
		facex2sel = []
		for ipoly in range(len(active_mesh.polygons)):
			for idx, lIdx in enumerate(active_mesh.polygons[ipoly].loop_indices):
				ivdx = active_mesh.polygons[ipoly].vertices[idx]
				if (ivdx not in vertx2sel) and (ipoly not in facex2sel):
					if (self.opt_target == 'COLORBR' or self.opt_target == 'COLORSL') and (color_map.data[lIdx].color is not None):
						vcol = color_map.data[lIdx].color
						dist = Vector((vcol[0],vcol[1],vcol[2]))
						if (dist-basecol).length <= self.opt_colFuzz:
							vertx2sel.append(ivdx)
		wla_do.select_and_change_mode(active_obj,"OBJECT")
		selfaces = 0
		selverts = 0
		if len(vertx2sel)>0:
			for idx in vertx2sel:
				active_mesh.vertices[idx].select = True
				selverts = selverts+1
		if len(facex2sel)>0:
			for idx in facex2sel:
				active_mesh.polygons[idx].select = True
				selfaces = selfaces+1
		wla_do.select_and_change_mode(active_obj,"EDIT")
		if len(facex2sel)>0:
			context.tool_settings.mesh_select_mode = (False, False, True) # 'FACE'
			#bpy.ops.mesh.select_mode(type="FACE", action='ENABLE')
		elif len(vertx2sel)>0:
			context.tool_settings.mesh_select_mode = (True, False, False) # 'VERT'
			#bpy.ops.mesh.select_mode(type='VERT', action='ENABLE')
		wla_do.select_and_change_mode(active_obj, oldmode)
		self.report({'INFO'}, 'Selected verts='+str(selverts)+' faces='+str(selfaces))
		return {'FINISHED'}

# class wplvc_makegrad(bpy.types.Operator):
# 	bl_idname = "mesh.wplvc_makegrad"
# 	bl_label = "Gradient from last"
# 	bl_options = {'REGISTER', 'UNDO'}

# 	def execute( self, context ):
# 		active_obj = wla.active_object(["MESH"])
# 		if active_obj is None:
# 			self.report({'ERROR'}, "Select mesh object first")
# 			return {'CANCELLED'}
		
# 		wpl_vcOpts = context.scene.wpl_vcOpts
# 		if active_obj is None or len(wpl_vcOpts.vc_name) == 0:
# 			return {'CANCELLED'}
# 		if "wpl_last_paint" not in active_obj:  # kWPLCustomPropTag... required
# 			self.report({'ERROR'}, "No previous paint operation found")
# 			return {'CANCELLED'}
# 		oldmode = wla_do.select_and_change_mode(active_obj,"OBJECT")
# 		active_mesh = active_obj.data
# 		selverts = wla.selected_vertsIdx(active_mesh)
# 		wla_do.select_and_change_mode(active_obj,"EDIT")
# 		bm = bmesh.from_edit_mesh( active_mesh )
# 		histVerts = wla_bm.bm_historyVertsIdx(bm)
# 		if len(histVerts) == 0:
# 			self.report({'ERROR'}, "No active vert found")
# 			return {'CANCELLED'}
# 		gradPnt2 = bm.verts[histVerts[0]].co
# 		gradCol2 = wpl_vcOpts.bake_vc_col
# 		wla_do.select_and_change_mode(active_obj,"OBJECT")
# 		color_map = active_mesh.vertex_colors.get(wpl_vcOpts.vc_name)
# 		if color_map is None:
# 			return {'CANCELLED'}
# 		gradCol1 = active_obj["wpl_last_paint"][1]
# 		gradPntRaw = active_obj["wpl_last_paint"][0]
# 		gradPnt1 = Vector((gradPntRaw[0],gradPntRaw[1],gradPntRaw[2]))
# 		gradDst = (gradPnt1-gradPnt2).length
# 		gradNrm = (gradPnt2-gradPnt1).normalized()
# 		gradinfo = {}
# 		for vIdx in selverts:
# 			v = active_mesh.vertices[vIdx]
# 			dst = wla.math_vecFaceProj(v.co, gradPnt1, gradNrm)
# 			infl = dst / gradDst
# 			gradinfo[v.index] = max(0.0, min(infl, 1.0))
# 		for poly in active_mesh.polygons:
# 			ipoly = poly.index
# 			for idx, lIdx in enumerate(active_mesh.polygons[ipoly].loop_indices):
# 				ivdx = active_mesh.polygons[ipoly].vertices[idx]
# 				if ivdx not in gradinfo:
# 					continue
# 				inf = gradinfo[ivdx]
# 				color_map.data[lIdx].color = Vector((gradCol2[0]*inf+gradCol1[0]*(1.0-inf),gradCol2[1]*inf+gradCol1[1]*(1.0-inf),gradCol2[2]*inf+gradCol1[2]*(1.0-inf),1))
# 		wla_do.select_and_change_mode(active_obj,oldmode)
# 		self.report({'INFO'}, color_map.name+': verts='+str(len(gradinfo)))
# 		return {'FINISHED'}

class wplvc_masspalupd(bpy.types.Operator):
	bl_idname = "mesh.wplvc_masspalupd"
	bl_label = "Propagate color on scene"
	bl_options = {'REGISTER', 'UNDO'}

	opt_objTargetVC : StringProperty(
		name = "Target VC",
		default = config.kWPLMeshColVC
	)
	opt_objmatOnly : StringProperty(
		name = "Target Materials (* for all, **/*** for Mat colors)",
		default = ""
	)
	opt_correctGamma : BoolProperty(
		name="Make Gamma correction",
		default=False
	)

	# Running as separate dialog
	def invoke(self, context, event):
		return context.window_manager.invoke_props_dialog(self, width = 200)

	def execute( self, context ):
		wpl_vcOpts = context.scene.wpl_vcOpts
		vcName = self.opt_objTargetVC
		if len(vcName) == 0:
			vcName = wpl_vcOpts.vc_name
		if len(self.opt_objmatOnly) == 0:
			self.report({'INFO'}, "Dry run: Target Materials")
			return {'FINISHED'}
		if len(vcName) == 0:
			self.report({'INFO'}, "Dry run: Target VC")
			return {'FINISHED'}
		objCount = 0
		meshDuples = {}
		selobjs = wla.selected_objects(['MESH','CURVE','FONT','!HIDE'])
		print("- Mass-color update", vcName, self.opt_objmatOnly, "objects:", len(selobjs))
		for io, objx in enumerate(selobjs):
			if objx.data.name in meshDuples:
				# already updated
				continue
			else:
				meshDuples[objx.data.name] = True
			print("- object", objx.name, str(io)+"/"+str(len(selobjs)), "data:", objx.data.name, "mats:", len(objx.material_slots))
			setCount = 0
			selfaces = None
			upd_color = wpl_vcOpts.bake_vc_col
			if objx.type == 'MESH':
				active_mesh = objx.data
				wla_attr.vc_obj_ensure(objx, vcName)
				if len(objx.material_slots) > 0:
					if self.opt_objmatOnly == "**" or self.opt_objmatOnly == "***":
						# using per-material color for update
						for idx, mt in enumerate(objx.material_slots):
							mat_active = mt.material
							if mat_active is None:
								continue
							if (self.opt_objmatOnly == "**") and (mat_active.library is not None):
								# lib materials are protected
								print("- skipped [", idx+1, mt.name, "]: library mat, protected")
								continue
							upd_color = mat_active.diffuse_color
							if self.opt_correctGamma:
								# need a gamma correction here -> or SVG colors too dark (comparing to PNG exports of same SVG)
								# inv: 1/2.2 power (0.4545)
								upd_color = (math.pow(upd_color[0], 1.0/2.2), math.pow(upd_color[1], 1.0/2.2), math.pow(upd_color[2], 1.0/2.2)  ) # To GAMMA
							selfaces= []
							for poly in active_mesh.polygons:
								slot = objx.material_slots[poly.material_index]
								mat = slot.material
								if mat.name == mat_active.name:
									selfaces.append(poly.index)
							if len(selfaces)>0:
								setCount = wla_attr.vc_obj_update(objx, 'FACE', vcName, upd_color, (1.0,1.0,1.0), 1.0, None, None, selfaces)
								if setCount > 0:
									print("- updated [", idx+1, mt.name, vcName, "]:", setCount,"verts,", len(selfaces),"faces, RGB:", upd_color[0], upd_color[1], upd_color[2])
						objCount = objCount+1
					else:
						# all faces on materials with this name
						if len(self.opt_objmatOnly) > 1:
							selfaces= []
							for poly in active_mesh.polygons:
								slot = objx.material_slots[poly.material_index]
								mat = slot.material
								if self.opt_objmatOnly in mat.name:
									selfaces.append(poly.index)
							print("- material faces:", mat.name, len(selfaces))
						else:
							selfaces = None
						setCount = wla_attr.vc_obj_update(objx,'FACE',vcName,upd_color,(1.0,1.0,1.0),1.0,None,None,selfaces)
						print("- updated ", setCount," verts")
						objCount = objCount+1
		print("- updated ",objCount," objects")
		self.report({'INFO'}, 'Updated = '+str(objCount))
		return {'FINISHED'}

# ==========================================
# ==========================================
def WPL_VCOPTS_vc_name_real_items(self, context):
	active_obj = wla.active_object(['MESH', 'CURVE', 'FONT'])
	lst = []
	if (active_obj is not None) and active_obj.type == 'MESH':
		for vc in active_obj.data.vertex_colors:
			lst.append((vc.name, vc.name, "vc"))
		if active_obj.data.vertex_colors.get(config.kWPLMeshColVC) is None:
			lst.append((config.kWPLMeshColVC, "// +"+config.kWPLMeshColVC, "vc missing"))
		if active_obj.data.vertex_colors.get(config.kWPLMeshColPVC) is None:
			lst.append((config.kWPLMeshColPVC, "// + "+config.kWPLMeshColPVC, "vc missing"))
		if active_obj.data.vertex_colors.get(config.kWPLMeshColDVC) is None:
			lst.append((config.kWPLMeshColDVC, "// +"+config.kWPLMeshColDVC, "vc missing"))
		if active_obj.data.vertex_colors.get(config.kWPLMeshColLVC) is None:
			lst.append((config.kWPLMeshColLVC, "// +"+config.kWPLMeshColLVC, "vc missing"))
	if (active_obj is not None) and active_obj.type == 'CURVE':
		lst.append((config.kWPLMeshColVC, config.kWPLMeshColVC, "vc/prop"))
		lst.append((config.kWPLMeshColPVC, config.kWPLMeshColPVC, "vc/prop"))
		lst.append((config.kWPLMeshColDVC, config.kWPLMeshColDVC, "vc/prop"))
		lst.append((config.kWPLMeshColLVC, config.kWPLMeshColLVC, "vc/prop"))
	if (active_obj is not None):
		for cpp in active_obj.keys():
			if config.kWPLAutoSetupCustomPropCol in cpp:
				lst.append((cpp, cpp, "prop"))
	while len(lst)<kWPL_VCLIST_MAXITEMS:
		lst.append((kWPL_VCLIST_NOOP, kWPL_VCLIST_NOOP, "..."))
	return lst

def WPL_VCOPTS_vc_name_real_update(self, context):
	wpl_vcOpts = context.scene.wpl_vcOpts
	if len(wpl_vcOpts.vc_name_real)>0:
		wpl_vcOpts.vc_name = wpl_vcOpts.vc_name_real

class WPL_VCOPTS(bpy.types.PropertyGroup):
	bake_vc_col : FloatVectorProperty(
		name="VC Color",
		subtype='COLOR_GAMMA', #'COLOR'
		min=0.0, max=1.0,
		default = (1.0,1.0,1.0)
		)
	bake_vc_col_ref2_d0 : FloatVectorProperty(name="P1", subtype='COLOR_GAMMA', min=0.0, max=1.0, default = (0.5,0.0,0.0))
	bake_vc_col_ref2_d1 : FloatVectorProperty(name="P2", subtype='COLOR_GAMMA', min=0.0, max=1.0, default = (0.0,0.5,0.0))
	bake_vc_col_ref2_d2 : FloatVectorProperty(name="P3", subtype='COLOR_GAMMA', min=0.0, max=1.0, default = (0.0,0.0,0.5))
	bake_vc_col_ref2_d3 : FloatVectorProperty(name="P4", subtype='COLOR_GAMMA', min=0.0, max=1.0, default = (1.0,0.0,0.0))
	bake_vc_col_ref2_d4 : FloatVectorProperty(name="P5", subtype='COLOR_GAMMA', min=0.0, max=1.0, default = (0.0,1.0,0.0))
	bake_vc_col_ref2_d5 : FloatVectorProperty(name="P6", subtype='COLOR_GAMMA', min=0.0, max=1.0, default = (0.0,0.0,1.0))
	bake_vc_col_ref2_d6 : FloatVectorProperty(name="P7", subtype='COLOR_GAMMA', min=0.0, max=1.0, default = (1.0,1.0,1.0))
	bake_vc_col_ref2_d7 : FloatVectorProperty(name="P8", subtype='COLOR_GAMMA', min=0.0, max=1.0, default = (0.5,0.5,0.5))
	bake_vc_col_ref2_d8 : FloatVectorProperty(name="P9", subtype='COLOR_GAMMA', min=0.0, max=1.0, default = (0.0,0.0,0.0))

	vc_name : StringProperty(
		name = "Target VC",
		default = ""
	)
	vc_name_real : EnumProperty(
		name="VC",
		items = WPL_VCOPTS_vc_name_real_items,
		update = WPL_VCOPTS_vc_name_real_update
	)


class WPL_PT_VCPanel(bpy.types.Panel):
	bl_idname = "WPL_PT_VCPanel"
	bl_label = "VC tools"
	bl_space_type = 'VIEW_3D'
	bl_region_type = 'UI'
	bl_category = "MATS"

	def draw(self, context):
		layout = self.layout
		wpl_vcOpts = context.scene.wpl_vcOpts
		active_obj = wla.active_object(['MESH', 'CURVE', 'FONT'])
		col = layout.column()
		
		obj_data = None
		if active_obj is not None:
			obj_data = active_obj.data
		box1 = col.box()
		row0 = box1.row()
		row0.prop(wpl_vcOpts, "vc_name")
		if active_obj is not None:
			#row0.prop_search(wpl_vcOpts, "vc_name_real", obj_data, "vertex_colors", icon='GROUP_VCOL')
			row0.prop(wpl_vcOpts, "vc_name_real", text = "", icon='GROUP_VCOL')
		box1.separator()
		box1.prop(wpl_vcOpts, "bake_vc_col", text="")
		box1.separator()
		if (active_obj is not None) and (active_obj.type != 'MESH'):
			op1 = box1.operator("mesh.wplvc_updcol", text="-> PROP")
			op1.opt_target = 'PROP'
			op1.opt_rgbMask = (1.0, 1.0, 1.0)
		elif wla.modf_by_type(active_obj, 'NODES') is not None:
			row3 = box1.row()
			op1 = row3.operator("mesh.wplvc_updcol", text="-> Faces")
			op1.opt_target = 'FACE'
			op1.opt_rgbMask = (1.0, 1.0, 1.0)
			op1 = row3.operator("mesh.wplvc_updcol", text="-> PROP")
			op1.opt_target = 'PROP'
			op1.opt_rgbMask = (1.0, 1.0, 1.0)
			op2 = box1.operator("mesh.wplvc_updcol", text="-> Verts")
			op2.opt_target = 'VERT'
			op2.opt_rgbMask = (1.0, 1.0, 1.0)
		else:
			op1 = box1.operator("mesh.wplvc_updcol", text="-> Faces")
			op1.opt_target = 'FACE'
			op1.opt_rgbMask = (1.0, 1.0, 1.0)
			op2 = box1.operator("mesh.wplvc_updcol", text="-> Verts")
			op2.opt_target = 'VERT'
			op2.opt_rgbMask = (1.0, 1.0, 1.0)
		box1.separator()
		row3 = box1.row()
		op1 = row3.operator("mesh.wplvc_updcol", text="+f R")
		op1.opt_target = 'FACE'
		op1.opt_rgbMask = (1.0, 0.0, 0.0)
		op1 = row3.operator("mesh.wplvc_updcol", text="+f G")
		op1.opt_target = 'FACE'
		op1.opt_rgbMask = (0.0, 1.0, 0.0)
		op1 = row3.operator("mesh.wplvc_updcol", text="+f B")
		op1.opt_target = 'FACE'
		op1.opt_rgbMask = (0.0, 0.0, 1.0)
		row3 = box1.row()
		op1 = row3.operator("mesh.wplvc_updcol", text="+v R")
		op1.opt_target = 'VERT'
		op1.opt_rgbMask = (1.0, 0.0, 0.0)
		op1 = row3.operator("mesh.wplvc_updcol", text="+v G")
		op1.opt_target = 'VERT'
		op1.opt_rgbMask = (0.0, 1.0, 0.0)
		op1 = row3.operator("mesh.wplvc_updcol", text="+v B")
		op1.opt_target = 'VERT'
		op1.opt_rgbMask = (0.0, 0.0, 1.0)
		box1.separator()
		if obj_data is not None:
			box1.operator("mesh.wplvc_pickcol")
			box1.operator("mesh.wplvc_selvccol", text="Mesh: Reselect by selection", icon='SELECT_SET').opt_target = 'COLORSL'
			#col.operator("mesh.wplvc_makegrad", text="Mesh: Draw gradient")
			box1.operator("mesh.wplvc_selvccol", text="Mesh: Reselect by brush").opt_target = 'COLORBR'
		box2 = box1 #col.box()
		row3 = box2.row()
		row3.operator("mesh.wplvc_resetvc", text="1").opt_resetIdx = 1
		row3.prop(wpl_vcOpts, "bake_vc_col_ref2_d0", text="")
		row3.operator("mesh.wplvc_resetvc", text="2").opt_resetIdx = 2
		row3.prop(wpl_vcOpts, "bake_vc_col_ref2_d1", text="")
		row3.operator("mesh.wplvc_resetvc", text="3").opt_resetIdx = 3
		row3.prop(wpl_vcOpts, "bake_vc_col_ref2_d2", text="")
		row4 = box2.row()
		row4.operator("mesh.wplvc_resetvc", text="4").opt_resetIdx = 4
		row4.prop(wpl_vcOpts, "bake_vc_col_ref2_d3", text="")
		row4.operator("mesh.wplvc_resetvc", text="5").opt_resetIdx = 5
		row4.prop(wpl_vcOpts, "bake_vc_col_ref2_d4", text="")
		row4.operator("mesh.wplvc_resetvc", text="6").opt_resetIdx = 6
		row4.prop(wpl_vcOpts, "bake_vc_col_ref2_d5", text="")
		row5 = box2.row()
		row5.operator("mesh.wplvc_resetvc", text="7").opt_resetIdx = 7
		row5.prop(wpl_vcOpts, "bake_vc_col_ref2_d6", text="")
		row5.operator("mesh.wplvc_resetvc", text="8").opt_resetIdx = 8
		row5.prop(wpl_vcOpts, "bake_vc_col_ref2_d7", text="")
		row5.operator("mesh.wplvc_resetvc", text="9").opt_resetIdx = 9
		row5.prop(wpl_vcOpts, "bake_vc_col_ref2_d8", text="")
		col.separator()
		if obj_data is not None and active_obj.type == 'MESH':
			box1 = col.box()
			row4 = box1.row()
			row4.operator("mesh.wplvc_cppaste", text="COPY VC+MAT", icon='COPYDOWN').opt_op = 'COPY'
			row4.operator("mesh.wplvc_cppaste", text="PASTE VC+MAT", icon='PASTEDOWN').opt_op = 'PASTE'

# ==========================================
# ==========================================

classes = (

	WPL_PT_VCPanel,
	WPL_VCOPTS,

	wplvc_updcol,
	wplvc_pickcol,
	wplvc_cppaste,
	wplvc_resetvc,
	wplvc_selvccol,
	#wplvc_makegrad,
	wplvc_masspalupd

)

def register():
	for cls in classes:
		bpy.utils.register_class(cls)
	#bpy.types.Object.DecorC = bpy.props.FloatVectorProperty(name = "Custom VC Color", size=3)
	bpy.types.Scene.wpl_vcOpts = bpy.props.PointerProperty(type=WPL_VCOPTS)

def unregister():
	for cls in reversed(classes):
		bpy.utils.unregister_class(cls)
	#del bpy.types.Object.DecorC
	del bpy.types.Scene.wpl_vcOpts

if __name__ == "__main__":
	register()