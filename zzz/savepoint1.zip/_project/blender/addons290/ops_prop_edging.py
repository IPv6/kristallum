import os, sys, time, datetime
import math, copy, string, random
import numpy as np
import bpy, bmesh, mathutils

import bpy.types
from mathutils import Vector, Matrix, Euler, Quaternion
from mathutils.bvhtree import BVHTree
from mathutils.kdtree import KDTree
from bpy_extras import view3d_utils
from bpy.props import *

from . import config
from .tools import wla
from .tools import wla_do
from .tools import wla_bm
from .tools import wla_attr
from .tools import wla_curve
from .tools import wla_meshwrap
from .tools import wla_vgbind
from .tools import wla_edger
from .tools import wla_vgs

kWPLDefaultEdgeProfile = (0.1,0.1,1.0)
kWPLEdgeAutoSubdiv = 0.05

# Outlines auto-adjust
kWPLEdgeOutlineSubshrink = 0.7
kWPLEdgeOutlineFixoff = 0.01
kWPLEdgeOutlineVisibleCol = "FFFFFF"
kWPLEdgeOutlineVisibleMt = "zzz_gpOutline_visible"
kWPLEdgeOutlineInvisibleCol = "101010"
kWPLEdgeOutlineInvisibleMt = "zzz_gpOutline_invisible"
kWPLEdgeLineArtCol = "ff0000"
kWPLEdgeLineArtMt = "zzz_gpLineart"
# kWPLEdgeSecondariesMt = "zzz_gpSecondaries"
# kWPLEdgeSecondariesCol = "AA0202"
# kWPLEdgeSecondariesTrackConName = "gpFill_track_source"
kWPLEdgeSysPrefix = "sys_"
kWPLEdgeTmpPrefix = "tmp_"
kWPLEdgeTmpTargetChange_uasKey = "#tmp:data_uas"

# Line Width calcualted in World space -> far lines must have width boost
kWPLEdgeDistanceLerp = (2.0, 50.0)
kWPLEdgeGpRadiusRange = (5, 200)
kWPLEdgeGpLineWidth = 1.0

kWPLArmEdgerBns_MLOW = 'bn_breast.L:ss1.5, bn_breast.R:ss1.5, bn_pelvis+bn_spine01:ss1.5'
kWPLArmEdgerBns_MLOW = kWPLArmEdgerBns_MLOW+', bn_hand.L:ss0.75, bn_hand.R:ss0.75'
kWPLArmEdgerBns_MLOW = kWPLArmEdgerBns_MLOW+', bn_thumb01.L+bn_thumb02.L+bn_thumb03.L:ss0.75, bn_thumb01.R+bn_thumb02.R+bn_thumb03.R:ss0.75'
kWPLArmEdgerBns_MLOW = kWPLArmEdgerBns_MLOW+', bn_pinky01.L+bn_pinky02.L+bn_pinky03.L:ss0.75, bn_pinky01.R+bn_pinky02.R+bn_pinky03.R:ss0.75'
kWPLArmEdgerBns_MLOW = kWPLArmEdgerBns_MLOW+', bn_ring01.L+bn_ring02.L+bn_ring03.L:ss0.75, bn_ring01.R+bn_ring02.R+bn_ring03.R:ss0.75'
kWPLArmEdgerBns_MLOW = kWPLArmEdgerBns_MLOW+', bn_middle01.L+bn_middle02.L+bn_middle03.L:ss0.75, bn_middle01.R+bn_middle02.R+bn_middle03.R:ss0.75'
kWPLArmEdgerBns_MLOW = kWPLArmEdgerBns_MLOW+', bn_index01.L+bn_index02.L+bn_index03.L:ss0.75, bn_index01.R+bn_index02.R+bn_index03.R:ss0.75'
kWPLArmEdgerBns_MLOW = kWPLArmEdgerBns_MLOW+', bn_spine01+bn_spine02+bn_spine03, bn_spine04+bn_spine05+bn_spine06+head+bn_shoulder.L+bn_shoulder.R'
kWPLArmEdgerBns_MLOW = kWPLArmEdgerBns_MLOW+', bn_upperarm01.L+bn_upperarm02.L, bn_upperarm01.R+bn_upperarm02.R, bn_forearm01.R+bn_forearm02.R, bn_forearm01.L+bn_forearm02.L'
kWPLArmEdgerBns_MLOW = kWPLArmEdgerBns_MLOW+', bn_thigh01.R+bn_thigh02.R, bn_thigh01.L+bn_thigh02.L, bn_shin01.L+bn_shin02.L, bn_shin01.R+bn_shin02.R, bn_foot.L+bn_toe.L, bn_foot.R+bn_toe.R'
kWPLArmEdgerBnsWei_MLOW = 0.2

kWPLEdgeTypeMapping_gpencil = [
	(config.kWPLObjCharFaceToken, None),
	("_loomis", None),
	("<sews>",                            0.3, ("sews", "21A619"), ""),
	# (config.kWPLObjVgsSkinPostfix,        0.3, ("vgs", "A62119"), ""), # stripes, rigids
	# (config.kWPLUdiWriwToken,             0.85, ("elem", "BE2548"), ""), # Glasses, additionals
	(config.kWPLObjCharHairsPostfix,      0.7, ("hair", "32BE25"), ""),
	(config.kWPLObjCharHeadPostfix,       1.0, ("body", "FF95F4"), ""),
	(config.kWPLObjCharBodyPostfix,       1.0, ("body", "FF95F4"), kWPLArmEdgerBns_MLOW),
	(config.kWPLObjCharDressPostfix,      1.2, ("dress", "6A86E0"), kWPLArmEdgerBns_MLOW),
	("*",                                 0.5, ("bgse", "BE2548"), "")
]
kWPLEdgeTypeProhibitOutlines = ["sews", "vgs", "bgse"]

def bones_expandDescription(all_deformBns, bonesDesc):
	boneSegments = [x.strip() for x in bonesDesc.split(",")]
	all_okBones = []
	for i_s, segm in enumerate(boneSegments):
		segm_extra = ""
		if ":" in segm:
			segm_pair = list(segm.split(":"))
			segm = segm_pair[0]
			segm_extra = segm_pair[1]
		toks = segm.split("+")
		affected = []
		for boneName in all_deformBns:
			if wla.isTokenInStr(toks, boneName):
				if boneName not in affected:
					affected.append(boneName)
		all_okBones.append( (affected, segm_extra) )
	#print("all_okBones", bonesDesc, all_okBones)
	# need bone order, defined by bonesDesc
	#all_okBones = sorted(all_okBones, key=lambda pr: str(pr[2]).zfill(3)+"_"+pr[0], reverse=False)
	return all_okBones

def mapping_getDescription(obj_name, useFallback):
	res = None
	for pr in kWPLEdgeTypeMapping_gpencil:
		if wla.isTokenInStr(pr[0], obj_name):
			res = pr
			break
		if useFallback and pr[0] == "*":
			res = pr
			break
	if res is not None and len(res) < 4:
		return None
	return res

def mapping_getDescriptionX(sel_obj, obj_name, useFallback):
	curve_mapping = mapping_getDescription(obj_name, True)
	if curve_mapping is None:
		# skipping object, not edging needed (EX: face)
		print("- mapping_getDescriptionX: no mapping, skipping", obj_name)
		return None, None, None, None, None
	camera_gCo, camera_gOrtho, _, _ = wla.active_camera()
	dist2obj_frac = 0.0
	dist2obj = (camera_gCo - sel_obj.matrix_world.to_translation()).length
	if camera_gOrtho == False:
		dist2obj_frac = (dist2obj - kWPLEdgeDistanceLerp[0])/(kWPLEdgeDistanceLerp[1] - kWPLEdgeDistanceLerp[0])
		dist2obj_frac = max(0.0, min(1.0, dist2obj_frac))
	curve_layerName = curve_mapping[2][0]
	curve_layerCol = curve_mapping[2][1]
	stroke_radius = wla.math_lerp1D(dist2obj_frac, kWPLEdgeGpRadiusRange[0], kWPLEdgeGpRadiusRange[1])*curve_mapping[1]
	return curve_mapping, curve_layerName, curve_layerCol, stroke_radius, kWPLEdgeAutoSubdiv

def GP_isObjectValidForEdging(sel_obj):
	if sel_obj is None:
		return "<ignored>"
	if wla.isTokenInStr(config.kWPLSystemOslIgnored + [config.kWPLSuppZZZZPrefix, config.kWPLObjVgsSewPostfix, config.kWPLObjManSewPostfix], sel_obj.name):
		# assets, itens, sys-objects, vgs-stripes, vgs-sews, etc
		return "<ignored>"
	if wla.isTokenInStr(config.kWPLObjCharFaceToken, wla.object_full_name(sel_obj)):
		# face edging is not automatic
		return "<ignored>"
	if wla.isTokenInStr(config.kWPLObjProtoToken, wla.object_full_name(sel_obj)):
		print("- PROBLEM: PROTO on object", wla.object_full_name(sel_obj))
		return 'PROTO not allowed: '+sel_obj.name
	if wla.modf_by_type(sel_obj,'MIRROR'):
		print("- PROBLEM: MIRROR on object", wla.object_full_name(sel_obj))
		return 'MIRROR not allowed: '+sel_obj.name
	if config.kWPLMatTokenWPV in sel_obj.name:
		# outline needs versioning
		print("- PROBLEM: version token in name", wla.object_full_name(sel_obj))
		return 'VERSION TOKEN not allowed: '+sel_obj.name
	return None

def GP_createforCurves(edges_res, stroke_radius, edg_curve_name, curve_layerName, curve_layerCol, edges_needTaper, edge_needPreSubd, sel_obj):
	if (edges_res is None):
		return None, None, None, []
	vert_curves = edges_res["curves"]
	vert_radius_scale = None
	if ("curves_radius" in edges_res):
		vert_radius_scale = edges_res["curves_radius"]
	#vert_curves_vIdx = edges_res["curves_vIdx"]
	if ("debug" in edges_res) and (edges_res["debug"] > 0):
		stroke_radius = stroke_radius*2
	print("- GP_createforCurves:", len(vert_curves))
	if len(vert_curves) == 0:
		return None, None, None, []
	# getting target curve object
	(edg_curve, edg_postMergeLayer, stroke_frame, stroke_mat_idx) = wla_edger.object_addEdgingGP(edg_curve_name, "_frm"+str(int(bpy.context.scene.frame_current)), curve_layerName, curve_layerCol, sel_obj)
	edg_postMergePoints = []
	# print("// ", edg_curve, edg_postMergeLayer)
	# adding curves to it
	vert_curves_fin = []
	for ii, curve in enumerate(vert_curves):
		stroke = stroke_frame.strokes.new()
		stroke.start_cap_mode = 'FLAT'
		stroke.end_cap_mode = 'FLAT'
		stroke.line_width = int(kWPLEdgeGpLineWidth)
		if stroke_mat_idx is not None:
			stroke.material_index = stroke_mat_idx
		# curveDist = 0
		# v_g_prev_co = None
		if edge_needPreSubd is not None:
			curve = wla.math_vecsSubd(curve, edge_needPreSubd)
		vert_curves_fin.append(curve)
		for jj, v_g in enumerate(curve):
			v_g_co = v_g
			stroke.points.add(1)
			stroke_pt = stroke.points[-1]
			v_co_l = edg_curve.matrix_world.inverted() @ v_g_co
			pt_co = (v_co_l[0], v_co_l[1], v_co_l[2])
			# print("- curve CO", pt_co)
			stroke_pt.co = pt_co
			scale_fac = 1.0
			if vert_radius_scale is not None:
				curve_rs = vert_radius_scale[ii]
				idx_presubd, idx_presubd2, idx_presubd_fac = wla.math_vecsSubdIdxToOrig(jj, curve, curve_rs)
				scale_fac = curve_rs[idx_presubd]
				scale_fac2 = curve_rs[idx_presubd2]
				scale_fac = wla.math_lerp1D(idx_presubd_fac, scale_fac, scale_fac2)
				# pt_fac = float(jj)/(len(curve)-1)
				# # need recalc index due possible subdivision
				# idx_presubd_raw = pt_fac * (len(curve_rs)-1)
				# idx_presubd = int(idx_presubd_raw)
				# scale_fac = curve_rs[idx_presubd]
				# if idx_presubd < len(curve_rs)-1:
				# 	# interpolating
				# 	scale_fac2 = curve_rs[idx_presubd+1]
				# 	scale_fac = wla.math_lerp1D(idx_presubd_raw-idx_presubd, scale_fac, scale_fac2)
			stroke_pt.pressure = stroke_radius*scale_fac
		if edges_needTaper:
			wla_curve.cu_rescale_radius(stroke.points, kWPLDefaultEdgeProfile, 0.5, 0.0)
		tip1_3d_co = copy.copy(stroke.points[0].co)
		tip2_3d_co = copy.copy(stroke.points[-1].co)
		edg_postMergePoints.append( (tip1_3d_co, '3D') )
		edg_postMergePoints.append( (tip2_3d_co, '3D') )
		tip1_2d_co = wla.math_vecCamProj(edg_curve, edg_curve.matrix_world @ tip1_3d_co, True, edg_curve.matrix_world.to_translation())
		tip2_2d_co = wla.math_vecCamProj(edg_curve, edg_curve.matrix_world @ tip2_3d_co, True, edg_curve.matrix_world.to_translation())
		edg_postMergePoints.append( (tip1_2d_co, '2D') )
		edg_postMergePoints.append( (tip2_2d_co, '2D') )
	return edg_curve, edg_postMergeLayer, edg_postMergePoints, vert_curves_fin

# ==================================================
class wplbind_cleanup_edging_cc_gp(bpy.types.Operator):
	bl_idname = "object.wplbind_cleanup_edging_cc_gp"
	bl_label = "Cleanup Auto-edging"
	bl_options = {'REGISTER', 'UNDO'}

	opt_onlySelected : BoolProperty(
		name="Check selected curves only",
		default=False
	)
	# opt_preNormalize : BoolProperty(
	# 	name="Pre-normalize",
	# 	default=True
	# )
	opt_preHide : BoolProperty(
		name="Pre-hide self",
		default=False
	)
	opt_castOpts : FloatVectorProperty(
		name = "Cast opts (fuzz-width, fuzz-qual)",
		size = 3,
		default	 = (3, 3, 0.005),
	)

	# Running as separate dialog
	def invoke(self, context, event):
		return context.window_manager.invoke_props_dialog(self, width = 200)

	def execute( self, context ):
		sel_all = wla.selected_objects(['CURVE', 'GPENCIL'])
		okCnt = 0
		opt_castFeatsFuzz = (self.opt_castOpts[0], self.opt_castOpts[1])
		#opt_castIndiff = self.opt_castOpts[2]
		#region, _ = wla.active_view_region()
		#eo_dir2cam_g = (region.view_rotation @ Vector((0.0, 0.0, -1.0)))
		#eo_dir2cam_l = matrix_world_norm.inverted() @ eo_dir2cam_g
		#proj_dir_g = eo_dir2cam_g.normalized()
		camera_gCo, camera_gOrtho, camera_gDir, camera_gDirUp = wla.active_camera()
		print("- clearing GP-edges, is ORTHO:", camera_gOrtho, camera_gDir)
		proj_dir_g = camera_gDir
		for sel_obj in sel_all:
			oldmod = wla_do.select_and_change_mode(sel_obj, 'OBJECT')
			# if self.opt_preNormalize and self.opt_onlySelected == False:
			# 	print("- prenormalizing curves") # curves must be ALREADY subdived
			# 	bpy.ops.curve.wplcurve_cnormalize(opt_reapplyShrinkw=False, opt_reapplyDistribute=False, opt_ensureSegmentLength = kWPLEdgeAutoSubdiv)
			wla_do.select_and_change_mode(sel_obj, 'OBJECT')
			if self.opt_preHide:
				sel_obj.hide_viewport = True
				wla_do.sys_update_view(True, False)
			depsgraph = bpy.context.evaluated_depsgraph_get() # after hide
			#matrix_world_inv = sel_obj.matrix_world.inverted()
			#matrix_world_norm = matrix_world_inv.transposed().to_3x3()
			active_mesh = wla_meshwrap.object_wrappedmesh(sel_obj)
			selvertsAll = []
			if self.opt_onlySelected:
				print("- checking selected points only")
				selvertsAll = active_mesh.selected_vertsIdx()
			else:
				selvertsAll = active_mesh.all_vertsIdx()
			if len(selvertsAll) == 0:
				continue
			print("- removing invisibles...", sel_obj.name, len(selvertsAll))
			needDbgEmpty = False
			for vIdx in selvertsAll:
				isVisible = True
				hit_min_dist = None
				hit_max_dist = None
				v = active_mesh.vertices[vIdx]
				v_co_g = (sel_obj.matrix_world @ v.co)
				proj_from_g = camera_gCo
				fuuzzFac = 1.0/10000.0
				if camera_gOrtho:
					fuuzzFac = 5.0/10000.0
					proj_from_g = v_co_g+camera_gDir*1
					proj_dir_g = -1*camera_gDir
				else:
					proj_dir_g = (v_co_g-camera_gCo).normalized()
				orig_dist = (v_co_g-proj_from_g).length
				if isVisible == True:
					hit_g_max, _ = wla_bm.bm_fuzzyBVHRayCast_v01(depsgraph, proj_from_g, proj_dir_g, abs(opt_castFeatsFuzz[0])*fuuzzFac, -1*int(opt_castFeatsFuzz[1]), 'MAX_ON_DIR')
					if (hit_g_max is not None):
						hit_max_dist = (hit_g_max-proj_from_g).length
						if hit_max_dist < orig_dist:
							isVisible = False
				if isVisible == False:
					# double check
					hit_g_min, _ = wla_bm.bm_fuzzyBVHRayCast_v01(depsgraph, proj_from_g, proj_dir_g, abs(opt_castFeatsFuzz[0])*fuuzzFac, -1*int(opt_castFeatsFuzz[1]), 'MIN_ON_DIR')
					if hit_g_min is not None:
						hit_min_dist = (hit_g_min-proj_from_g).length
						if hit_min_dist > orig_dist:
							isVisible = True
				# if isVisible == False:
				# 	print("- non visible found: ", hit_min_dist, hit_max_dist, orig_dist)
				# else:
				# 	print("- visible found: ", hit_min_dist, hit_max_dist, orig_dist)
				if isVisible == False:
					v.select = True # will be deleted
					okCnt = okCnt+1
				else:
					v.select = False
				if needDbgEmpty and hit_g_max is not None:
					zzz_name = "aaa"+str(vIdx)
					sysemptyxx = wla.sys_empty(zzz_name)
					sysemptyxx.location = hit_g_max
					wla_do.link_object_to_scene(sysemptyxx)
					print("- hitdst:", hit_min_dist, hit_max_dist, orig_dist, v_co_g, zzz_name)
			# saving selections
			active_mesh.to_mesh()
			if self.opt_preHide:
				sel_obj.hide_viewport = False
			wla_do.select_and_change_mode(sel_obj, 'EDIT')
			# deleting SELECTED points
			if sel_obj.type == 'CURVE':
				#bpy.ops.curve.select_less()
				bpy.ops.curve.delete(type='SEGMENT')
			else:
				#bpy.ops.gpencil.select_less()
				bpy.ops.gpencil.delete(type='POINTS')
			wla_do.select_and_change_mode(sel_obj, 'OBJECT')
			print("- normalizing...") # need to remove short curves, etc
			bpy.ops.curve.wplcurve_cnormalize(opt_reapplyShrinkw=False, opt_reapplyDistribute=False, opt_ensureSegmentLength = 0.0)
			wla_do.select_and_change_mode(sel_obj, oldmod)
		self.report({'INFO'}, "EdgeCleanups: removed "+str(okCnt)+" point")
		return {'FINISHED'}

# ==============================================================
class wplbind_lineart_edging(bpy.types.Operator):
	bl_idname = "object.wplbind_lineart_edging"
	bl_label = "GP: Add LineArt"
	bl_options = {'REGISTER', 'UNDO'}

	def execute( self, context ):
		okObjs = 0
		mainCam = wla.object_by_name(config.kWPLSystemMainCam)
		sel_all = wla.selected_objects(['MESH', 'CURVE'])
		for sel_obj in sel_all:
			isInvalid = GP_isObjectValidForEdging(sel_obj)
			if isInvalid == "<ignored>":
				continue
			if isInvalid is not None:
				self.report({'INFO'}, 'PROBLEM: '+isInvalid)
				return {"FINISHED"}
		post_sel = []
		for sel_obj in sel_all:
			lineart_obj_name = config.kWPLSuppZZZPrefix + sel_obj.name + config.kWPLObjEdgeLinArtToken
			if wla.object_by_name(lineart_obj_name) is not None:
				continue
			layer_name = "layer"+config.kWPLObjEdgeLinArtToken
			gpData = bpy.data.grease_pencils.new(name=lineart_obj_name)
			wla_edger.object_ensureGP(gpData)
			gpLayer = gpData.layers.new(layer_name, set_active=True)
			gpLayer.use_lights = False # important for DBG-View in Cycles
			if gpLayer.frames is None or len(gpLayer.frames) == 0:
				gpLayer.frames.new(frame_number = 0)
			edgeObj = bpy.data.objects.new(lineart_obj_name, object_data=gpData)
			wla_do.link_object_sideBySide(edgeObj, sel_obj)
			edgeObj.show_in_front = True
			wla_attr.mat_obj_ensureGpMat(edgeObj, kWPLEdgeLineArtMt, kWPLEdgeLineArtCol, False)
			matVis_mat = bpy.data.materials.get(kWPLEdgeLineArtMt)
			md = edgeObj.grease_pencil_modifiers.new(wla_edger.kWPL_EdgeModf_DBGLineArt, 'GP_LINEART')
			md.source_camera = mainCam
			md.use_custom_camera = True
			md.source_object = sel_obj
			md.source_type = 'OBJECT'
			md.show_render = False
			md.show_viewport = True
			md.show_in_editmode = False
			md.stroke_depth_offset = 0.0 #??use_offset_towards_custom_camera
			md.target_material = matVis_mat
			md.target_layer = layer_name
			md.thickness = 10
			md.use_back_face_culling = False # Cloth/Hairs may have backfaces, edging still needed
			md.use_fuzzy_intersections = True # Chaining: Less contour breaks
			md.use_edge_overlap = True # Fixes dots on hairs
			if wla.isTokenInStr([config.kWPLObjCharBodyPostfix, config.kWPLObjCharHeadPostfix], sel_obj.name):
				md.use_face_mark = True # freestyle for body ok
			else:
				md.use_face_mark = False # freestyle for cloth/etc - by VGS only
			md.use_material = False # Not usable after segmentation
			md.use_multiple_levels = False
			md.level_start = 0
			# diabling autosplits - may give extra spiraling contour edges
			if (sel_obj.type in ['MESH', 'CURVE']):
				edgeObj[kWPLEdgeTmpTargetChange_uasKey] = (1 if sel_obj.data.use_auto_smooth else 0)
				sel_obj.data.use_auto_smooth = False
			okObjs = okObjs+1
			post_sel.append(sel_obj)
			post_sel.append(edgeObj)
		wla_do.select_and_activate_multi(post_sel, None)
		self.report({'INFO'}, "LineArt added: "+str(okObjs)+" objs")
		return {'FINISHED'}

class wplbind_auto_edging_gp(bpy.types.Operator):
	bl_idname = "object.wplbind_auto_edging_gp"
	bl_label = "GP: Create Auto-edging"
	bl_options = {'REGISTER', 'UNDO'}

	# opt_useLineArt : BoolProperty(
	# 	name="Pre-hide self",
	# 	default=False
	# )

	opt_useLineArt : EnumProperty(
		name="Use LineArt", default="USE_N_DEL",
		items=(
			("USE_N_DEL", "Use && delete", ""),
			("USE_N_HIDE", "Use && hide", ""), 
			("IGNORE", "Do not use, ignore", ""))
	)

	opt_useCurveSews : EnumProperty(
		name="Use CurveSews", default="USE_N_DEL",
		items=(
			("USE_N_DEL", "Use && delete", ""),
			("USE_N_HIDE", "Use && hide", ""), 
			("IGNORE", "Do not use, ignore", ""))
	)

	# Running as separate dialog
	def invoke(self, context, event):
		return context.window_manager.invoke_props_dialog(self, width = 200)

	def execute( self, context ):
		okCnt = 0
		okObjs = 0
		modf_cache = {}
		sel_all_raw = wla.selected_objects(['MESH', 'CURVE', 'GPENCIL'])
		sel_all = []
		sel_all_sews = []
		sel_all_lineart = []
		for sel_obj in sel_all_raw:
			if wla.isTokenInStr([config.kWPLObjVgsSewPostfix, config.kWPLObjManSewPostfix], sel_obj.name):
				if self.opt_useCurveSews != 'IGNORE':
					sel_all_sews.append(sel_obj)
				continue
			if wla.isTokenInStr(config.kWPLObjEdgeLinArtToken, sel_obj.name):
				# even zzzz
				if self.opt_useLineArt != 'IGNORE':
					sel_all_lineart.append(sel_obj)
				continue
			isInvalid = GP_isObjectValidForEdging(sel_obj)
			if isInvalid == "<ignored>":
				continue
			if isInvalid is not None:
				self.report({'INFO'}, 'PROBLEM: '+isInvalid)
				return {"FINISHED"}
			sel_all.append(sel_obj)
		if len(sel_all_lineart) > 0:
			for sel_obj in sel_all_lineart:
				# generating lineart object
				print("- starting Lineart object...", sel_obj.name)
				md = wla.modf_by_type(sel_obj, None, wla_edger.kWPL_EdgeModf_DBGLineArt)
				if md is None:
					continue
				if md.source_object in sel_all:
					# no need for usual edging (zzzz also). Even for Freestyle - handled by LineArt modifier
					print("- LineArt for "+md.source_object.name+" found, ignoring original")
					sel_all.remove(md.source_object)
				if config.kWPLSuppZZZZPrefix in sel_obj.name:
					continue
				edg_curve_name = wla.strTemplateObj(kWPLEdgeTmpPrefix + "_<root>" + config.kWPLObjEdgeToken, sel_obj) # kWPLSystemOslIgnored
				edg_curve_name = edg_curve_name + config.kWPLFrameBindPostfix + str(int(bpy.context.scene.frame_current))
				curve_mapping, curve_layerName_this, curve_layerCol_this, stroke_radius_this, stroke_presubd = mapping_getDescriptionX(sel_obj, sel_obj.name, True)
				edges_res = wla_edger.generateLineartCurves(sel_obj)
				_, _, _, vert_curves = GP_createforCurves(edges_res, stroke_radius_this, edg_curve_name, curve_layerName_this, curve_layerCol_this, True, stroke_presubd, sel_obj)
				okCnt = okCnt + len(vert_curves)
				if kWPLEdgeTmpTargetChange_uasKey in sel_obj:
					targ_obj = md.source_object
					if sel_obj[kWPLEdgeTmpTargetChange_uasKey]:
						targ_obj.data.use_auto_smooth = True if (sel_obj[kWPLEdgeTmpTargetChange_uasKey] == 1) else False
				if self.opt_useLineArt == 'USE_N_DEL':
					sel_obj.hide_viewport = True
					bpy.data.objects.remove(sel_obj, do_unlink=True)
				else:
					sel_obj.name = config.kWPLSuppZZZZPrefix + wla.strReplaceTokenInStr([config.kWPLSuppZZZZPrefix, config.kWPLSuppZZZPrefix], sel_obj.name, "")
					sel_obj.hide_render = True
					sel_obj.hide_select = True
					sel_obj.hide_viewport = True
				okObjs = okObjs+1

		if len(sel_all_sews) > 0:
			for sel_obj in sel_all_sews:
				# generating sew-object GPs - hiding source as wplcurve_curve_2mesh
				print("- starting sew object...", sel_obj.name)
				edg_curve_name = wla.strTemplateObj(kWPLEdgeTmpPrefix + "_<root>" + config.kWPLObjEdgeToken + config.kWPLObjManSewPostfix, sel_obj)
				edg_curve_name = edg_curve_name + config.kWPLFrameBindPostfix + str(int(bpy.context.scene.frame_current))
				curve_mapping, curve_layerName_this, curve_layerCol_this, stroke_radius_this, stroke_presubd = mapping_getDescriptionX(sel_obj, "<sews>", False)
				edges_res = wla_edger.generateCurveCurves(sel_obj)
				_, _, _, vert_curves = GP_createforCurves(edges_res, stroke_radius_this, edg_curve_name, curve_layerName_this, curve_layerCol_this, False, stroke_presubd, sel_obj)
				okCnt = okCnt + len(vert_curves)
				if self.opt_useCurveSews == 'USE_N_DEL':
					sel_obj.hide_viewport = True
					bpy.data.objects.remove(sel_obj, do_unlink=True)
				else:
					sel_obj.name = config.kWPLSuppZZZZPrefix + wla.strReplaceTokenInStr([config.kWPLSuppZZZZPrefix, config.kWPLSuppZZZPrefix], sel_obj.name, "")
					sel_obj.hide_render = True
					sel_obj.hide_select = True
					sel_obj.hide_viewport = True
				okObjs = okObjs+1
				
		modfs_list_ini = ['SOLIDIFY','BEVEL','EDGE_SPLIT','MULTIRES','#vgs']
		for sel_obj in sel_all:
			modfs_list = copy.copy(modfs_list_ini)
			allow_backfaces = False
			if wla.isTokenInStr(config.kWPLObjCharHairsPostfix, sel_obj.name):
				allow_backfaces = True
				if wla.modf_by_type(sel_obj, 'NODES') is None:
					# no need for SUBSURF in old hairs (no GN)
					# BUT GN MAY need them
					modfs_list = modfs_list+['SUBSURF']
			verts_stable1 = wla_vgbind.obj_calcStableIdxMap(sel_obj, sel_obj.data)
			# MASK: NOT WORKIN AFTER EVAL - no masked vertexes already
			# so getting ORIGINAL verts if no modifiers, extend 1 loop -> openVerts for evaled object...
			# OK if not wla_do.kWPLModifsIndexBreakers without MASK
			# checking for actual MASK modifier existence - "transfer VG" may add kWPLSuppVGHideMaskM even when no masking present on mesh
			hidegeom_orig = None
			if (sel_obj.type == 'MESH') and wla.modf_by_type(sel_obj, 'MASK') is not None:
				hidegeom_incompats = ['SOLIDIFY','BEVEL','EDGE_SPLIT','MULTIRES','#vgs']
				for modfType in hidegeom_incompats:
					if wla.modf_by_type(sel_obj,modfType) is not None:
						hidegeom_incompats = None
						break
				if (hidegeom_incompats is not None):
					# can get original hidegeom verts
					_, hidegeom_orig, _ = wla_attr.vg_get_verts(sel_obj, config.kWPLSuppVGHideMaskM, 0.1, None)
					# extending verts 1 loop (original verts skipped in)
					bm_tmp = bmesh.new()
					bm_tmp.from_mesh(sel_obj.data)
					bm_tmp.verts.ensure_lookup_table()
					bm_tmp.verts.index_update()
					bm_tmp.edges.ensure_lookup_table()
					bm_tmp.edges.index_update()
					bm_tmp.faces.ensure_lookup_table()
					bm_tmp.faces.index_update()
					hidegeom_orig2 = set()
					for vIdx in hidegeom_orig:
						v = bm_tmp.verts[vIdx]
						for f in v.link_faces:
							for fv in f.verts:
								hidegeom_orig2.add(fv.index)
					bm_tmp.free()
					hidegeom_orig = hidegeom_orig2
			# curves main/base parameters
			curve_mapping,curve_layerName,curve_layerCol, stroke_radius, stroke_presubd = mapping_getDescriptionX(sel_obj, sel_obj.name, True)
			if curve_mapping is None:
				# skipping object, not edging needed (EX: face)
				print("- skipping", sel_obj.name)
				continue
			curve_segmentation = curve_mapping[3]
			edg_curve_name = wla.strTemplateObj(kWPLEdgeTmpPrefix + "_<root>" + config.kWPLObjEdgeToken, sel_obj) # kWPLSystemOslIgnored
			edg_curve_name = edg_curve_name + config.kWPLFrameBindPostfix + str(int(bpy.context.scene.frame_current))
			print("- starting...", sel_obj.name, "| base radius:", stroke_radius)
			# print("// mapping", curve_mapping)
			# print("// modfs disable", modfs_list)
			# if len(self.opt_vg2update) > 0:
			# 	wla_attr.vg_remove(sel_obj, self.opt_vg2update)
			wla_do.modf_toggle(sel_obj, modfs_list, False, modf_cache)
			depsgraph = bpy.context.evaluated_depsgraph_get()
			obj_eval = None
			mesh_eval = None
			if sel_obj.type == 'MESH':
				obj_eval = sel_obj.evaluated_get(depsgraph)
				mesh_eval = obj_eval.data
			else:
				# clone_evaluated_obj
				obj_eval = sel_obj.evaluated_get(depsgraph)
				mesh_eval = obj_eval.to_mesh()
				obj_eval[config.kWPLTempMesh] = mesh_eval
				print("- creating tmp mesh", mesh_eval)
			# bm_eval = bmesh.new()
			# bm_eval.from_mesh(mesh_eval)
			# wla_do.sys_dump_bmesh(obj_eval, bm_eval, None, "tmpEdgingMesh")
			if obj_eval is None:
				print("- no mesh, skipping", sel_obj.name)
				continue
			print("// mesh verts count:",len(mesh_eval.vertices))
			obj_vgs = None
			obj_vgs_verts = {}
			islands = []
			segmWithBones = False
			hidegeom_verts = set()
			verts_stable2 = wla_vgbind.obj_calcStableIdxMap(obj_eval, mesh_eval)
			_, verts_stableMap12 = wla_vgbind.obj_compareStableIdxMaps(verts_stable1, verts_stable2)
			if (hidegeom_orig is not None) and len(hidegeom_orig) > 0:
				# getting hidegeom verts (after eval)
				for v1Idx in hidegeom_orig:
					if v1Idx in verts_stableMap12:
						v2Idx = verts_stableMap12[v1Idx]
						hidegeom_verts.add(v2Idx)
				print("- using hidegeomed verts:", len(hidegeom_verts))
			segmentMap = "<island>_<mat_name>"
			if len(curve_segmentation) > 0:
				print("- preparing vg maps (bones)...")
				obj_vgs = wla_attr.vg_names_by_nameToken(obj_eval, "bn_")
				if len(obj_vgs) > 0:
					segmWithBones = True
					for vgname in obj_vgs:
						vgmap = wla_attr.vg_get_weightMap(obj_eval, vgname, kWPLArmEdgerBnsWei_MLOW)
						obj_vgs_verts[vgname] = set(vgmap.keys())
				else:
					print("- no bones vg found: using mat_id")
					segmentMap = "<island>_<mat_id>"
			if wla.isTokenInStr(config.kWPLObjVgsSkinPostfix, sel_obj.name):
				segmentMap = None
			facePerIslands = None
			if segmentMap is not None:
				print("- segmenting (mats: "+segmentMap+", bones: "+str(segmWithBones)+")...")
				_, _, facePerIslands = wla_edger.segmentMesh(sel_obj, mesh_eval, segmentMap)
			# print("- segment results", facePerIslands)
			bm_eval = bmesh.new()
			bm_eval.from_mesh(mesh_eval)
			bm_eval.verts.ensure_lookup_table()
			bm_eval.verts.index_update()
			bm_eval.edges.ensure_lookup_table()
			bm_eval.edges.index_update()
			bm_eval.faces.ensure_lookup_table()
			bm_eval.faces.index_update()
			if facePerIslands is not None:
				allVertsSet = set([v.index for v in bm_eval.verts])
				for islId, islFaces_orig in facePerIslands.items():
					islFaces = set(islFaces_orig)
					facesLeft = None
					if segmWithBones and len(obj_vgs) > 0:
						facesLeft = set(islFaces)
						all_okBones = bones_expandDescription(obj_vgs, curve_segmentation)
						if len(all_okBones) > 0:
							#print("- extra-islands", all_okBones)
							for bn_set, bn_setExtra in all_okBones:
								verts = set()
								for bnname in bn_set:
									if bnname in obj_vgs_verts:
										verts = verts.union( obj_vgs_verts[bnname] )
								if len(verts) == 0:
									continue
								bn_scale = 1.0
								if len(bn_setExtra)>0:
									bn_scale = wla.safeFloat(bn_setExtra, -1.0, ":ss")
									if bn_scale <= 0.0:
										bn_scale = 1.0
								bn_faces = set()
								# should not take part in edging: hidegeomed
								bn_openverts = set(hidegeom_verts)
								# should not take part in edging: all verts not affected by bones
								bn_openverts = bn_openverts.union( allVertsSet.difference(verts) )
								for fIdx in islFaces:
									f = bm_eval.faces[fIdx]
									#vidxes_all = [v.index for v in f.verts]
									vidxes_ok = [v.index for v in f.verts if v.index in verts]
									if len(vidxes_ok) > 0:
										bn_faces.add(fIdx)
										facesLeft.discard(fIdx)
										# problematic approach -> skips verts that MAY be useful -> holes always
										# if len(vidxes_ok) < len(vidxes_all):
										# 	bn_openverts.update(vidxes_all)
								if len(bn_faces) > 1:
									# faces related only to this bones
									islands.append( ( str(islId+1)+"_"+",".join(bn_set), list(bn_faces), list(bn_openverts), bn_scale) )
									#print("- bn_set", str(islId+1), ",".join(bn_set), len(bn_faces))
						if len(facesLeft) > 1:
							facesLeft = list(facesLeft)
							islands.append( ( str(islId+1)+"_leftovers", facesLeft, None, 1.0) )
					if (facesLeft is None):
						islands.append( ( str(islId+1), list(islFaces), None, 1.0) )
			# additional step for freestyle marks - not anymore, converted to sew curves
			# islands.append( ( "<sews>", None, None, 1.0) )
			print("- total islands count:", len(islands))
			for i_i, i_dat in enumerate(islands):
				# if islDesc != "3.0_bn_breast.L":
				# 	continue
				islDesc = i_dat[0]
				islFaces = i_dat[1]
				islOpenVerts = i_dat[2]
				islScal = i_dat[3]
				print("* Island:", i_i+1, "|", islDesc, "/", len(wla.coalesce(islFaces,[])), len(wla.coalesce(islOpenVerts,[])))
				if islOpenVerts is None:
					islOpenVerts = []
				stroke_radius_this = stroke_radius*islScal
				curve_layerName_this = curve_layerName
				curve_layerCol_this = curve_layerCol
				stroke_presubd_this = stroke_presubd
				edges_res = None
				edges_needTaper = True
				# if islDesc == "<sews>":
				# 	curve_mapping, curve_layerName_this, curve_layerCol_this, stroke_radius_this, stroke_presubd_this = mapping_getDescriptionX(sel_obj, islDesc, False)
				# 	edges_res = wla_edger.generateFreestyleCurves(obj_eval, bm_eval, None, {"island_desc": islDesc})
				# 	edges_needTaper = False
				# else:
				# full auto
				if islFaces is not None:
					edges_res = wla_edger.generateEdgingCurves(obj_eval, bm_eval, islFaces, {"open_edge_verts": islOpenVerts, "island_desc": islDesc, "allow_backfaces": allow_backfaces})
				_, _, _, vert_curves = GP_createforCurves(edges_res, stroke_radius_this, edg_curve_name, curve_layerName_this, curve_layerCol_this, edges_needTaper, stroke_presubd_this, sel_obj)
				okCnt = okCnt + len(vert_curves)
			bm_eval.free()
			if (config.kWPLTempMesh in obj_eval) and (obj_eval[config.kWPLTempMesh] != obj_eval.data):
				print("- removing tmp mesh...")
				del obj_eval[config.kWPLTempMesh]
				obj_eval.to_mesh_clear()
				mesh_eval = None
			wla_do.modf_toggle(sel_obj, modfs_list, None, modf_cache)
			okObjs = okObjs+1
			print("- Done:", sel_obj.name, okCnt)
		self.report({'INFO'}, "Generated "+str(okCnt)+" curves in "+str(okObjs)+" objs")
		return {'FINISHED'}

class wplbind_manual_edging_gp(bpy.types.Operator):
	bl_idname = "object.wplbind_manual_edging_gp"
	bl_label = "GP: Create edging manually"
	bl_options = {'REGISTER', 'UNDO'}

	opt_mode : EnumProperty(
		name="Mode", default="EDIT_SEL",
		items=(
			("EDIT_SEL", "Active selection", ""), 
			("EDIT_VHIST", "History vertex", ""), 
		)
	)

	opt_cuhLifting: StringProperty(
		name="Lifting CUH",
		default="111",
	)
	opt_cuhRadius: StringProperty(
		name="Radius CUH",
		default="999",
	)

	opt_mergeTips3DDst : FloatProperty(
		name="Auto-merge: 3D", 
		default=0.01,
		min=0.0, max=10000.0,
	)
	opt_mergeTips2DDst : FloatProperty(
		name="Auto-merge: 2D", 
		default=0.01,
		min=0.0, max=10000.0,
	)

	def execute( self, context ):
		okCnt = 0
		modf_cache = {}
		# camera_gCo, camera_gOrtho, _, _ = wla.active_camera()
		active_obj = wla.active_object(['MESH'])
		if active_obj is None:
			self.report({'ERROR'}, "Select mesh object first")
			return {'CANCELLED'}
		if config.kWPLMatTokenWPV in active_obj.name:
			# outline needs versioning
			print("- PROBLEM: version token in name", active_obj.name)
			self.report({'ERROR'}, "Version token in name")
			return {'CANCELLED'}
		oldmode = wla_do.select_and_change_mode(active_obj, 'OBJECT')
		sel_obj = active_obj
		verts_history1 = None
		verts_stable1 = wla_vgbind.obj_calcStableIdxMap(sel_obj, sel_obj.data)
		modfs_list = ['SOLIDIFY','BEVEL','EDGE_SPLIT','MULTIRES','#vgs']
		if self.opt_mode == 'EDIT_VHIST':
			bm_tmp = bmesh.new()
			bm_tmp.from_mesh(sel_obj.data)
			bm_tmp.verts.ensure_lookup_table()
			bm_tmp.verts.index_update()
			bm_tmp.edges.ensure_lookup_table()
			bm_tmp.edges.index_update()
			bm_tmp.faces.ensure_lookup_table()
			bm_tmp.faces.index_update()
			verts_history1 = wla_bm.bm_historyVertsIdx(bm_tmp)
			if len(verts_history1) < 2:
				verts_history1 = None
				wla_do.select_and_change_mode(active_obj, oldmode)
				print("- EDIT_VHIST: no history verts found")
				self.report({'ERROR'}, "No history verts found")
				return {'CANCELLED'}
			bm_tmp.free()
		curve_mapping, curve_layerName, curve_layerCol, stroke_radius, stroke_presubd = mapping_getDescriptionX(sel_obj, sel_obj.name, True)
		if curve_mapping is None:
			# skipping object, not edging needed (EX: face)
			self.report({'ERROR'}, "No curve mapping found")
			return {'CANCELLED'}
		edg_curve_name = wla.strTemplateObj("<root>" + config.kWPLObjEdgeToken+config.kWPLObjManPicksPostfix, sel_obj)
		edg_curve_name = edg_curve_name + config.kWPLFrameBindPostfix + str(int(bpy.context.scene.frame_current))
		print("- starting...", sel_obj.name, "| base radius:", stroke_radius, self.opt_cuhLifting, self.opt_cuhRadius)
		wla_do.modf_toggle(sel_obj, modfs_list, False, modf_cache)
		depsgraph = bpy.context.evaluated_depsgraph_get()
		obj_eval = sel_obj.evaluated_get(depsgraph)
		mesh_eval = obj_eval.data
		print("// mesh verts count:",len(mesh_eval.vertices))
		verts_stable2 = wla_vgbind.obj_calcStableIdxMap(obj_eval, mesh_eval)
		_, verts_stableMap12 = wla_vgbind.obj_compareStableIdxMaps(verts_stable1, verts_stable2)
		verts_line = None
		if self.opt_mode == 'EDIT_SEL':
			verts_history2 = []
			for v in mesh_eval.vertices:
				if v.select:
					verts_history2.append(v.index)
			if len(verts_history2) > 0:
				bm_eval = bmesh.new()
				bm_eval.from_mesh(mesh_eval)
				bm_eval.verts.ensure_lookup_table()
				bm_eval.verts.index_update()
				verts_history2 = wla_bm.bm_sortVertsByConnection(bm_eval, verts_history2, True, False)
				bm_eval.free()
				verts_line = verts_history2
		if self.opt_mode == 'EDIT_VHIST':
			verts_history2 = []
			# wee need keep original order
			for v1Idx in verts_history1:
				if v1Idx in verts_stableMap12:
					v2Idx = verts_stableMap12[v1Idx]
					verts_history2.append(v2Idx)
			verts_line = list(reversed(verts_history2))
		bm_eval = bmesh.new()
		bm_eval.from_mesh(mesh_eval)
		bm_eval.verts.ensure_lookup_table()
		bm_eval.verts.index_update()
		bm_eval.edges.ensure_lookup_table()
		bm_eval.edges.index_update()
		bm_eval.faces.ensure_lookup_table()
		bm_eval.faces.index_update()
		edges_res = wla_edger.generateFreestyleCurves(obj_eval, bm_eval, verts_line, {"cuh_lifting": self.opt_cuhLifting, "cuh_radius": self.opt_cuhRadius})
		edg_curve, edg_postMergeLayer, edg_postMergePoints, vert_curves = GP_createforCurves(edges_res, stroke_radius, edg_curve_name, curve_layerName, curve_layerCol, False, stroke_presubd, sel_obj)
		okCnt = okCnt + len(vert_curves)
		# if (edges_res is not None):
		# 	vert_curves = edges_res["curves"]
		# 	print("- result:", len(vert_curves), "curves.")
		# 	if len(vert_curves) > 0:
		# 		okCnt = okCnt + len(vert_curves)
		# 		# getting target curve object
		# 		(edg_curve, postMergeLayer, stroke_frame, stroke_mat_idx) = wla_edger.object_addEdgingGP(edg_curve_name, "_frm"+str(int(bpy.context.scene.frame_current)), curve_layerName, curve_layerCol, sel_obj)
		# 		print("// radius:", stroke_radius)
		# 		# adding curves to it
		# 		for curve in vert_curves:
		# 			if len(curve)<2:
		# 				continue
		# 			stroke = stroke_frame.strokes.new()
		# 			stroke.start_cap_mode = 'FLAT'
		# 			stroke.end_cap_mode = 'FLAT'
		# 			stroke.line_width = int(kWPLEdgeGpLineWidth)
		# 			if stroke_mat_idx is not None:
		# 				stroke.material_index = stroke_mat_idx
		# 			curve = wla.math_vecsSubd(curve, kWPLEdgeAutoSubdiv)
		# 			for i, v_g in enumerate(curve):
		# 				v_g_co = v_g
		# 				if len(stroke.points) <= i:
		# 					stroke.points.add(1)
		# 				v_co_l = edg_curve.matrix_world.inverted() @ v_g_co
		# 				stroke.points[i].co = (v_co_l[0], v_co_l[1], v_co_l[2])
		# 			# initializing scale
		# 			for i,v_g in enumerate(curve):
		# 				okPointsCnt = okPointsCnt+1
		# 				stroke.points[i].pressure = stroke_radius
		# 			wla_curve.cu_rescale_radius(stroke.points, kWPLDefaultEdgeProfile, 0.5, 0.0)
		# 			tip1_3d_co = copy.copy(stroke.points[0].co)
		# 			tip2_3d_co = copy.copy(stroke.points[-1].co)
		# 			postMergePoints.append( (tip1_3d_co, '3D') )
		# 			postMergePoints.append( (tip2_3d_co, '3D') )
		# 			tip1_2d_co = wla.math_vecCamProj(edg_curve, edg_curve.matrix_world @ tip1_3d_co, True, edg_curve.matrix_world.to_translation())
		# 			tip2_2d_co = wla.math_vecCamProj(edg_curve, edg_curve.matrix_world @ tip2_3d_co, True, edg_curve.matrix_world.to_translation())
		# 			postMergePoints.append( (tip1_2d_co, '2D') )
		# 			postMergePoints.append( (tip2_2d_co, '2D') )
		bm_eval.free()
		if (self.opt_mergeTips2DDst+self.opt_mergeTips3DDst) > 0 and edg_postMergeLayer is not None:
			wla_do.select_and_change_mode(edg_curve, 'OBJECT')
			layer_frame = edg_postMergeLayer.frames[0]
			max_tries = 10
			while max_tries > 0:
				max_tries = max_tries-1
				anyMerges = 0
				for pt_itm in edg_postMergePoints:
					wla_do.select_and_change_mode(edg_curve, 'EDIT')
					bpy.ops.gpencil.select_all(action='DESELECT')
					merge_pair = []
					for i2, polyline in enumerate(layer_frame.strokes):
						if(pt_itm[1] == '3D'):
							dst1 = (polyline.points[0].co - pt_itm[0]).length
							dst2 = (polyline.points[-1].co - pt_itm[0]).length
							if dst1 < self.opt_mergeTips3DDst or dst2 < self.opt_mergeTips3DDst:
								merge_pair.append(polyline)
						if(pt_itm[1] == '2D'):
							tip1_2d_co = wla.math_vecCamProj(edg_curve, edg_curve.matrix_world @ polyline.points[0].co, True, edg_curve.matrix_world.to_translation())
							tip2_2d_co = wla.math_vecCamProj(edg_curve, edg_curve.matrix_world @ polyline.points[-1].co, True, edg_curve.matrix_world.to_translation())
							dst1 = (tip1_2d_co - pt_itm[0]).length
							dst2 = (tip2_2d_co - pt_itm[0]).length
							if dst1 < self.opt_mergeTips2DDst or dst2 < self.opt_mergeTips2DDst:
								merge_pair.append(polyline)
					if len(merge_pair) >= 2:
						print("- merging curves: head-tail match found")
						merge_pair[0].points[0].select = True
						merge_pair[1].points[0].select = True
						bpy.ops.curve.wplcurve_merge(opt_postSubdiv = 0)
						anyMerges = anyMerges+1
				if anyMerges == 0:
					break
		wla_do.modf_toggle(sel_obj, modfs_list, None, modf_cache)
		# selecting adding curve for fast post-actions
		curve_cokeys = []
		for ii, curve in enumerate(vert_curves):
			for jj, v_g in enumerate(curve):
				v_g_co = v_g
				v_co_l = edg_curve.matrix_world.inverted() @ v_g_co
				curve_cokeys.append(wla.coToKey(v_co_l))
		wla_do.select_and_change_mode(edg_curve, 'EDIT')
		bpy.ops.gpencil.select_all(action='DESELECT')
		layer_frame = edg_postMergeLayer.frames[0]
		for i2, polyline in enumerate(layer_frame.strokes):
			for pt in polyline.points:
				ptkey = wla.coToKey(pt.co)
				if ptkey in curve_cokeys:
					pt.select = True
		# wla_do.select_and_change_mode(active_obj, oldmode) # This will break REDO
		self.report({'INFO'}, "Generated "+str(okCnt)+" curves")
		return {'FINISHED'}

# class wplbind_auto_fill_gp(bpy.types.Operator):
# 	bl_idname = "object.wplbind_auto_fill_gp"
# 	bl_label = "GP: Create Auto-Fills"
# 	bl_options = {'REGISTER', 'UNDO'}

# 	opt_mode : EnumProperty(
# 		name="Mode", default="ALL_FACES",
# 		items=(
# 			("ALL_FACES", "Object", ""), 
# 			("ALL_FACES_SUBD", "Subdived object", ""), 
# 			("EDIT_SEL", "Active selection", ""),
# 		)
# 	)

# 	opt_persubdivObj : BoolProperty(
# 		name="Pre-subdivide mesh",
# 		default = True
# 	)

# 	opt_ignoredMaterials : StringProperty(
# 		name="Ignored Materials",
# 		default = "Clear"
# 	)

# 	def execute( self, context ):
# 		active_obj = wla.active_object(['MESH', 'CURVE'])
# 		if active_obj is None:
# 			self.report({'ERROR'}, "Select proper object first")
# 			return {'CANCELLED'}
# 		if config.kWPLMatTokenWPV in active_obj.name:
# 			# outline needs versioning
# 			print("- PROBLEM: version token in name", active_obj.name)
# 			self.report({'ERROR'}, "Version token in name")
# 			return {'CANCELLED'}
# 		oldmode = wla_do.select_and_change_mode(active_obj, 'OBJECT')
# 		okCnt = 0
# 		okPointsCnt = 0
# 		modf2del = None
# 		if active_obj.type == 'MESH' and self.opt_mode == 'ALL_FACES_SUBD':
# 			modf2del = active_obj.modifiers.new(name = "Subsurf", type = 'SUBSURF')
# 			modf2del.subdivision_type = 'SIMPLE'
# 			modf2del.levels = 1
# 			modf2del.render_levels = 1
# 			wla_do.sys_update_mesh(active_obj)
# 		# getting finalized object (AMUST for GN-face)
# 		validFacesIdx = None
# 		depsgraph = bpy.context.evaluated_depsgraph_get()
# 		mesh_eval = None
# 		obj_eval = active_obj.evaluated_get(depsgraph)
# 		segmentMap = "<island>_<mat_name>"
# 		if obj_eval.type == 'MESH':
# 			mesh_eval = obj_eval.data
# 		if active_obj.type == 'CURVE':
# 			segmentMap = "<island>_<mat_id>"
# 			mesh_eval = bpy.data.meshes.new_from_object(obj_eval)
# 			#mesh_eval = obj_eval.to_mesh()
# 			obj_eval[config.kWPLTempMesh] = mesh_eval
# 			# wla_do.sys_dump_mesh(obj_eval, mesh_eval, "test")
# 			# return {'FINISHED'}
# 			# need to skip faces, covered by others - result broken anyway
# 			# validFacesIdx = []
# 			# tmp_cache = {}
# 			# for poly in mesh_eval.polygons:
# 			# 	v_co_g = obj_eval.matrix_world @ poly.center
# 			# 	castpts = [v_co_g]
# 			# 	for vidx in poly.vertices:
# 			# 		v_co_g = (obj_eval.matrix_world @ mesh_eval.vertices[vidx].co)
# 			# 		castpts.append(v_co_g)
# 			# 	isAnyVisible = False
# 			# 	for v_co_g in castpts:
# 			# 		isPtVis = wla_vgs.srcbvh_isPtSceneVisible(depsgraph, v_co_g, tmp_cache)
# 			# 		if isPtVis:
# 			# 			isAnyVisible = True
# 			# 			break
# 			# 	if isAnyVisible:
# 			# 		validFacesIdx.append(poly.index)
# 		islandsData, _, facePerIslands = wla_edger.segmentMesh(active_obj, mesh_eval, segmentMap, 0, validFacesIdx)
# 		if facePerIslands is None:
# 			print("- PROBLEM: Failed to segment mesh", active_obj.name)
# 			self.report({'ERROR'}, "Failed to segment mesh")
# 			return {'CANCELLED'}
# 		islandsMat2k = islandsData[1]
# 		bm_eval = bmesh.new()
# 		bm_eval.from_mesh(mesh_eval)
# 		bm_eval.verts.ensure_lookup_table()
# 		bm_eval.verts.index_update()
# 		bm_eval.edges.ensure_lookup_table()
# 		bm_eval.edges.index_update()
# 		bm_eval.faces.ensure_lookup_table()
# 		bm_eval.faces.index_update()
# 		for islId, islFaces_orig in facePerIslands.items():
# 			#print("- isl", islId, islandsMat2k[islId])
# 			if wla.isTokenInStr(self.opt_ignoredMaterials, islandsMat2k[islId]):
# 				print("- ignoring Island", islId, islandsMat2k[islId])
# 				continue
# 			islFaces = None
# 			if self.opt_mode == 'EDIT_SEL':
# 				islFaces = set()
# 				for fIdx in islFaces_orig:
# 					f = bm_eval.faces[fIdx]
# 					isAllSel = True
# 					for fv in f.verts:
# 						if fv.select == False:
# 							isAllSel = False
# 							break
# 					if isAllSel:
# 						islFaces.add(fIdx)
# 			else:
# 				islFaces = set(islFaces_orig)
# 			if len(islFaces) == 0:
# 				continue
# 			print("- GPing Island", islId, islandsMat2k[islId])
# 			layerCol = None
# 			layerName = None
# 			islAllVerts = set()
# 			for fIdx in islFaces:
# 				f = bm_eval.faces[fIdx]
# 				vidxes_all = set([v.index for v in f.verts])
# 				islAllVerts = islAllVerts.union(vidxes_all)
# 				if layerCol is None:
# 					if f.material_index >= 0 and f.material_index < len(active_obj.data.materials):
# 						mat = active_obj.data.materials[f.material_index]
# 						layerCol = mat.diffuse_color
# 						layerName = mat.name
# 			islBndVerts = set()
# 			for vIdx in islAllVerts:
# 				v = bm_eval.verts[vIdx]
# 				nonIslFaces = 0
# 				for f in v.link_faces:
# 					if f.index not in islFaces:
# 						nonIslFaces = nonIslFaces+1
# 				if nonIslFaces>0 or len(v.link_faces) <= 2:
# 					islBndVerts.add(vIdx)
# 			if len(islBndVerts) == 0:
# 				continue
# 			bnd_vIdx = wla_bm.bm_sortVertsByConnection(bm_eval, list(islBndVerts), True, False)
# 			bnd_co = [(obj_eval.matrix_world @ bm_eval.verts[vIdx].co) for vIdx in bnd_vIdx]
# 			edg_curve_name = wla.strTemplateObj(kWPLEdgeSysPrefix + "_<obj>" + config.kWPLObjEdgeFillsToken, active_obj)??
# 			edg_curve_name = edg_curve_name + config.kWPLFrameBindPostfix + str(int(bpy.context.scene.frame_current))
# 			for tk in config.kWPLObjProtoToken:
# 				edg_curve_name = edg_curve_name.replace(tk,"")
# 			edg_curve = wla.object_by_name(edg_curve_name)
# 			# if edg_curve is not None and self.opt_mode != 'EDIT_SEL':
# 			# 	bpy.data.objects.remove(edg_curve, do_unlink=True)
# 			# 	edg_curve = None
# 			(edg_curve, _, stroke_frame, _) = wla_edger.object_addEdgingGP(edg_curve_name, "_frm"+str(int(bpy.context.scene.frame_current)), "fill_"+wla.vectorRGBToHex(layerCol), None, active_obj)
# 			# adding target constraint
# 			# if edg_curve.constraints.get(kWPLEdgeSecondariesTrackConName) is None:
# 			# 	copyTraCon = edg_curve.constraints.new('COPY_TRANSFORMS')
# 			# 	copyTraCon.name = kWPLEdgeSecondariesTrackConName
# 			# 	copyTraCon.target = active_obj
# 			# 	#edg_curve.data.update()
# 			# 	wla_do.sys_update_view(True, False)
# 			# wla_attr.mat_obj_ensureGpMat(edg_curve, kWPLEdgeSecondariesMt, kWPLEdgeSecondariesCol, False) # for secondaries, etc
# 			stroke_mat_idx = None
# 			if layerCol is not None:
# 				matColorHex = wla.vectorRGBToHex(layerCol)
# 				if layerName is None:
# 					layerName = matColorHex
# 				else:
# 					# removing fg/etc - less chars and material matching in other ops will not pick wrong mats
# 					for tok in config.kWPLSystemOslIncluded:
# 						layerName = layerName.replace(tok,'')
# 					layerName = wla.strBareName(layerName, True, True, True, True, True, True)
# 				stroke_mat_idx = wla_attr.mat_obj_ensureGpMat(edg_curve, "zzz"+config.kWPLObjEdgeFillsToken+"_"+layerName, matColorHex, True)
# 			stroke = stroke_frame.strokes.new()
# 			stroke.start_cap_mode = 'FLAT'
# 			stroke.end_cap_mode = 'FLAT'
# 			stroke.line_width = int(kWPLEdgeGpLineWidth)
# 			stroke.use_cyclic = True
# 			if stroke_mat_idx is not None:
# 				stroke.material_index = stroke_mat_idx
# 			bnd_co = wla.math_vecsSubd(bnd_co, kWPLEdgeAutoSubdiv)
# 			for i, v_g_co in enumerate(bnd_co):
# 				if len(stroke.points) <= i:
# 					stroke.points.add(1)
# 				v_co_l = edg_curve.matrix_world.inverted() @ v_g_co
# 				stroke.points[i].co = (v_co_l[0], v_co_l[1], v_co_l[2])
# 		bm_eval.free()
# 		if (config.kWPLTempMesh in obj_eval) and (obj_eval[config.kWPLTempMesh] != obj_eval.data):
# 			# need to remove temp mesh
# 			del obj_eval[config.kWPLTempMesh]
# 			obj_eval.to_mesh_clear()
# 		if modf2del is not None:
# 			active_obj.modifiers.remove(modf2del)
# 		wla_do.select_and_change_mode(active_obj, oldmode)
# 		if wla.is_edit_mode() and self.opt_mode == 'EDIT_SEL':
# 			# to avoid recreating with next piece
# 			bpy.ops.mesh.select_all( action = 'DESELECT' )
# 		self.report({'INFO'}, "Generated "+str(okCnt)+" curves, "+str(okPointsCnt)+" points")
# 		return {'FINISHED'}

class wplbind_outline_edging_dup(bpy.types.Operator):
	bl_idname = "object.wplbind_outline_edging_dup"
	bl_label = "Duplicate edging for outline"
	bl_options = {'REGISTER', 'UNDO'}

	def execute( self, context ):
		selobj_all = wla.selected_objects(['GPENCIL'])
		if len(selobj_all) == 0:
			self.report({'ERROR'}, "Select gp-objects first")
			return {'CANCELLED'}
		#camera_gCo, camera_gOrtho, camera_gDir, camera_gDirUp = wla.active_camera()
		for active_obj in selobj_all:
			if config.kWPLMatTokenWPV in active_obj.name:
				print("- skipping object: version token in name", active_obj.name)
				continue
			cop_data = active_obj.data.copy() #bpy.data.grease_pencils.new(name=active_obj.name)
			cop_name = active_obj.name.replace(config.kWPLObjEdgeToken, "")
			cop_name = wla.strBareName(cop_name, False, False, True, False, True, True)
			cop_name = config.kWPLObjEdgeOutlToken + "_" + cop_name
			cop_name = cop_name + config.kWPLFrameBindPostfix + str(int(bpy.context.scene.frame_current))
			cop_obj = bpy.data.objects.new(name = cop_name, object_data=cop_data)
			#cop_obj.animation_data_clear()
			cop_obj.matrix_world = active_obj.matrix_world
			wla_do.link_object_sideBySide(cop_obj, active_obj)
			cop_obj.hide_render = active_obj.hide_render
			cop_obj.show_in_front = active_obj.show_in_front
			matVis_idx = wla_attr.mat_obj_ensureGpMat(cop_obj, kWPLEdgeOutlineVisibleMt, kWPLEdgeOutlineVisibleCol, False)
			cdlayers = list(cop_data.layers)
			for layer in cdlayers:
				if layer.info in kWPLEdgeTypeProhibitOutlines:
					cop_data.layers.remove(layer)
					continue
				layer.tint_color = wla.hexToVectorRGB(kWPLEdgeOutlineVisibleCol)
				layer.tint_factor = 1.0 # per-layer color not needed... but needed for export
				layer.use_lights = False
				layer.lock = False
				layer.hide = False
				layer_frame = layer.active_frame
				if layer_frame is None: # GPencilLayer GPencilFrames
					layer_frame = layer.frames[0]
				for i2, polyline in enumerate(layer_frame.strokes):
					polyline.material_index = matVis_idx
					for pt in polyline.points:
						pt.pressure = pt.pressure*kWPLEdgeOutlineSubshrink
						v_go_g = cop_obj.matrix_world @ pt.co
						pt.co = cop_obj.matrix_world.inverted() @ v_go_g # no need for extra push with bubbling
			wla_do.select_and_change_mode(cop_obj,"OBJECT")
			bpy.ops.object.wplheal_meshversion(opt_switchTo = "")
			bind_vers,_,_ = wla.sys_objdata_versions(cop_obj)
			if len(bind_vers) < 2:
				# again, need 2 versions to restore
				bpy.ops.object.wplheal_meshversion(opt_switchTo = "")
				bind_vers,_,_ = wla.sys_objdata_versions(cop_obj)
			print("- outline created, versions", bind_vers)
		return {'FINISHED'}

class wplbind_outline_rebound(bpy.types.Operator):
	bl_idname = "object.wplbind_outline_rebound"
	bl_label = "Bound outline to edging"
	bl_options = {'REGISTER', 'UNDO'}

	opt_factorW : FloatProperty(
		name="Width offset",
		min=0.0, max=10000.0,
		default=1.0,
	)

	opt_factorR : FloatProperty(
		name="Radius scaler",
		min=0.0, max=10000.0,
		default=6.0,
	)

	def execute( self, context ):
		camera_gCo, camera_gOrtho, camera_gDir, camera_gDirUp = wla.active_camera()
		if camera_gOrtho:
			# TBD: casting as in GP-cleanup
			self.report({'ERROR'}, "Ortho not supported yet")
			return {'CANCELLED'}
		selobj_all = wla.selected_objects(['GPENCIL'])
		if len(selobj_all) == 0:
			self.report({'ERROR'}, "Select gp-objects first")
			return {'CANCELLED'}
		for active_obj in selobj_all:
			bind_vers,_,_ = wla.sys_objdata_versions(active_obj)
			if len(bind_vers) < 2:
				self.report({'ERROR'}, "No versions found")
				return {'CANCELLED'}
			opt_castFeatsFuzz = (3, 3)
			wla_do.select_and_change_mode(active_obj,"OBJECT")
			bind_base_ver_name = bind_vers[0]
			print("- Outline reboud, mesh versions", bind_vers, "base", bind_base_ver_name)
			bind_base_meshdata = wla_meshwrap.object_wrappedmesh(active_obj, {wla_meshwrap.kWPL_MESHVERKey: bind_base_ver_name})
			bind_now_meshdata = wla_meshwrap.object_wrappedmesh(active_obj)
			maxRad = 0.0
			normWidth = self.opt_factorW/1000.0 # 0.001
			radiuWidth = self.opt_factorR/100000.0 # 0.00006
			for vIdx in bind_now_meshdata.all_vertsIdx():
				v0 = bind_base_meshdata.vertices[vIdx]
				maxRad = max(maxRad, v0.radius)
			visiblePts = []
			active_obj.hide_viewport = True
			wla_do.sys_update_view(True, False)
			depsgraph = bpy.context.evaluated_depsgraph_get()
			for vIdx in bind_now_meshdata.all_vertsIdx():
				v0 = bind_base_meshdata.vertices[vIdx]
				v1 = bind_now_meshdata.vertices[vIdx]
				v0_co_g = (active_obj.matrix_world @ (v0.co - (v1.co-v0.co)))
				proj0_from_g = camera_gCo
				proj0_dir_g = (v0_co_g-camera_gCo).normalized()
				hit0_g_min, _ = wla_bm.bm_fuzzyBVHRayCast_v01(depsgraph, proj0_from_g, proj0_dir_g, abs(opt_castFeatsFuzz[0])/10000, -1*int(opt_castFeatsFuzz[1]), 'MIN_ON_DIR')
				hit0_len = (hit0_g_min-proj0_from_g).length
				v1_co_g = (active_obj.matrix_world @ v1.co)
				proj1_from_g = camera_gCo
				proj1_dir_g = (v1_co_g-camera_gCo).normalized()
				hit1_g_min, _ = wla_bm.bm_fuzzyBVHRayCast_v01(depsgraph, proj1_from_g, proj1_dir_g, abs(opt_castFeatsFuzz[0])/10000, -1*int(opt_castFeatsFuzz[1]), 'MIN_ON_DIR')
				hit1_len = (hit1_g_min-proj1_from_g).length
				if hit1_len < hit0_len:
					# outline SHOULD be visible here
					visiblePts.append( ( v1.refIdx[0], v1.refIdx[1], 1, hit0_len, hit1_len) )
				if hit1_len > hit0_len:
					# outline SHOULD NOT be visible here
					visiblePts.append( ( v1.refIdx[0], v1.refIdx[1], -1, hit0_len, hit1_len) )
				diff = (v1.co-v0.co).normalized()
				normDist = normWidth*(v0.radius/maxRad) + normWidth * kWPLEdgeOutlineFixoff
				v1.radius = v1.radius * math.pow(v0.radius/maxRad,0.5)
				normDist = normDist + v1.radius*radiuWidth
				v1.co = v0.co + diff*normDist

			# marking invisible lines with material
			matVis_idx = wla_attr.mat_obj_ensureGpMat(active_obj, kWPLEdgeOutlineVisibleMt, kWPLEdgeOutlineVisibleCol, False)
			matInvis_idx = wla_attr.mat_obj_ensureGpMat(active_obj, kWPLEdgeOutlineInvisibleMt, kWPLEdgeOutlineInvisibleCol, False)
			matVis_mat = bpy.data.materials.get(kWPLEdgeOutlineVisibleMt)
			matVis_mat.grease_pencil.hide = False
			matInvis_mat = bpy.data.materials.get(kWPLEdgeOutlineInvisibleMt)
			matInvis_mat.grease_pencil.hide = True
			for i1, layer in enumerate(active_obj.data.layers):
				#layer.tint_factor = 0.0 # needed for export
				#print("- layer", i1, layer.info) # wla_do.sys_dump_pythonobj(layer) == name
				for i2, polyline in enumerate(layer.active_frame.strokes):
					# calcing number of invisibles
					visPts = 0
					invisPts = 0
					for pt_refIdx in visiblePts:
						if pt_refIdx[0] == i1 and pt_refIdx[1] == i2:
							# if active_obj.material_slots[polyline.material_index].name == 'xxx':
							# 	print("- pt", pt_refIdx)
							if pt_refIdx[2]>0:
								visPts = visPts+1
							else:
								invisPts = invisPts+1
					if visPts > invisPts:
						#print("- visible", i1, i2, visPts, len(polyline.points), active_obj.material_slots[polyline.material_index].name)
						polyline.material_index = matVis_idx
					else:
						#print("- invisible", i1, i2, visPts, len(polyline.points), active_obj.material_slots[polyline.material_index].name)
						polyline.material_index = matInvis_idx
			active_obj.hide_viewport = False
			bind_now_meshdata.to_mesh()
		return {'FINISHED'}

# ==========================================
# ==========================================

classes = (
	# wplbind_auto_fill_gp,
	wplbind_auto_edging_gp,
	wplbind_lineart_edging,
	wplbind_manual_edging_gp,
	wplbind_cleanup_edging_cc_gp,
	wplbind_outline_edging_dup,
	wplbind_outline_rebound
)

def register():
	for cls in classes:
		bpy.utils.register_class(cls)

def unregister():
	for cls in reversed(classes):
		bpy.utils.unregister_class(cls)

if __name__ == "__main__":
	register()