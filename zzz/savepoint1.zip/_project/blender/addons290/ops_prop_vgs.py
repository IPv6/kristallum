import os, sys, time, datetime
import math, copy, string, random
import numpy as np
import bpy, bmesh, mathutils

import bpy.types
from mathutils import Vector, Matrix, Euler, Quaternion
from mathutils.bvhtree import BVHTree
from mathutils.kdtree import KDTree
from bpy_extras import view3d_utils
from bpy.props import *

from . import config
from .tools import wla
from .tools import wla_do
from .tools import wla_bm
from .tools import wla_attr
from .tools import wla_curve
from .tools import wla_vgs
from .tools import wla_meshwrap
from .tools import wla_vgbind
from .tools import wla_edger
from .tools import wla_arma

kWPL_CutP_WriwDistance = 0.7
# kWPL_ATTR_FMOMCO = "gnPtCo"
# kWPL_ATTR_FMOMNRM = "gnPtNrm"

# -- commands --
# command names must be short -> vg name limited (max length)
# also custom prop - max 63 chars
# details: https://vk.com/topic-134845799_40266573

# #vgs: bind(<cage_obj_token>, <cage_obj_base_version>, <this_obj_base_version>)
# // Surface binding. cage object auto-searched in parent and parent of parents
# // Support: lattice, curves, gp, mesh (all can have versions)
# // xxx Special vg: "_rigids": Deform applied only via main vert (other verts rotated/moved but not bended)
# // UV used: Edges

# #vgs: stripe( <%pattern>, <affine>, <substeps>)
# // create face-stripe along curve on fixed distance
# // <%pattern>: see remap_pphash, extra data == CUH profile for stripe
# // <affine>: oc/ox/oy/etc shifts - per vertex (vertex-local space)
# // len?? - width of stripe
# // - default width kWPLDefStripe_width
# // center - stripe will be centered around curve
# // ring - rings instead of stripes
# // rigid - stripes from original curves (not exact surface bisect)

# #vgs: sew( <%pattern>, <affine>)
# // Create curve-object, good for edging/sews, AO-delimiters/lines/stripes, etc
# // <%pattern>: see remap_pphash, extra data ignored
# // <affine>: oc/ox/oy/etc shifts - per point  (vertex-local space)
# // len?? - width of curve
# // - default width kWPLDefSew_width

# #vgs: freestyle( <%pattern>, <affine> )
# creates single curve for freestyle edges
# same as sew(...)

# #vgs: fit( <affine>, <type>)
# // restoring/enforcing edge len
# // <affine>: len?? - desired width
# // works on non-regular edgnets (triangles, mess, etc)

# #vgs: cp( <obj_tag>, <affine>, <substeps>)
# #vgs: cw( <obj_tag>, <affine>, <substeps>)
# #vgs: sw( <obj_tag>, <affine>, <substeps>)
# // Copy mesh from other objects
# // cw: 'curve-wrap' mode -> soft-align mesh from cp source 
# // - oc/ox/oy/etc - per vertex (vertex-local space)
# // - source: LocalXZ layout expected (front view, as per character)
# // - cnt??: repeat source ?? times
# // sw: 'surface-wrap' mode -> align mesh according UV
# // - source: LocalXZ layout expected (front view, as per character)
# // - each curve - another copy, center of curve as pin point
# // - ou/ov - offset by U/V-axis
# // - su/sv - scale by U/V-axis
# // - oz/sz - offset/scale depth along normal
# // - ox/oy/oz - per paste center
# // - rx/ry/rz - per paste center, but following surface
# // - cnt - number of side-loops to check
# // side effects: <obj_tag> - renderability always OFF

# #vgs: align( <obj_tag>, <affine>, <substeps>)
# // Moving <obj_tag>-object to vgs-vertex

# -- affine transforms --
# offsets: ox??, oy??, oz??
# // ox - Along curve
# // oy - Perpendicular to curve
# // oz - Above surface
# // oc - To camera (limited support)
# scales: sx??, sy??, sz??, ss??
# // ss - uniform scale
# rotations: rx??, ry??, rz??, rr??
# // in degrees
# // rr - general rotation
#
# -- Curve building rules --
# w=1.0 -> main point (on vertex)
# w<1.0 -> secondary point, x-asis for vertex-local space
# curve direction - secondary with higher weight. Only start vert can be marked
# vertex-local space:
# // X - along path/curve
# // Y - on surface, perpendicular
# // Z - up direction
# necklace faces: auto-left vert (in ring)

# -- cp/cw/sw sources rules --
# copy gets "Local data", matching (0,0,0) to target space
# cw/sw expects LocalXZ-layout

# -- Special VGs (Mirror/etc overloads) --
# _cutline -> Looped curves will be cut at this vertexes
# ..., !mirror -> VG will not be mirrored by "Smart XMirror"
# _nomirror -> Vertexes will not be mirrored by "Smart XMirror"
# xxx onlyL.R -> Vgs-processing skips on right
# xxx onlyR.L -> Vgs-processing skips on left
# xxx _rigids -> special meaning for vgs-bind
# xxx Calcing dirs NOT USING REAL NORMALS - не используем реальные нормали
# - Assuming vertex normals always fucked up
# - unfortunately vertex normal still most reliable thing...


###########################################################################
#kWPL_MBindProjMAXDIST = 0.5 # or charb top-casts may hit the legs...
#kWPL_MBindProjBACKSTEP = 0.5

# def object_addVeil(sel_obj, cage_base_ver_tok, force):
# 	sel_obj_veil_ver_name = ""
# 	cage_vers,_,_ = wla.sys_objdata_versions(sel_obj)
# 	if cage_base_ver_tok == "<latest>":
# 		print("- getting latest version", cage_vers)
# 		if len(cage_vers) > 0:
# 			sel_obj_veil_ver_name = cage_vers[-1]
# 	else:
# 		for v in cage_vers:
# 			if cage_base_ver_tok in v:
# 				sel_obj_veil_ver_name = v
# 				break
# 	veiledmesh = bpy.data.meshes.get(sel_obj_veil_ver_name)
# 	if veiledmesh is None:
# 		print("// skipped: veiled mesh not found", sel_obj.name, sel_obj_veil_ver_name)
# 		return None
# 	# no special prefix (kWPLUdiWriwToken) - universal-z-offset enforced via Modifier
# 	veiledObjName = config.kWPLSuppZZZPrefix + sel_obj.name + "_veil"
# 	veiledObj = wla.object_by_name(veiledObjName)
# 	if force and veiledObj is not None:
# 		print("- removing previous veiled mesh", veiledObj.name)
# 		bpy.data.objects.remove(veiledObj, do_unlink=True)
# 		veiledObj = None
# 	if veiledObj is not None:
# 		print("// skipped, veiled mesh already created", veiledObj.name)
# 		return None
# 	bm2m = bpy.data.meshes.new(name = veiledObjName + "_mesh")
# 	veiledObj = bpy.data.objects.new(name = veiledObjName, object_data=bm2m)
# 	#wla_do.link_object_sideBySide(veiledObj, obj)
# 	helpers_obj = wla.sys_empty(config.kWPLSystemObjSysEHelpers+config.kWPLUdiWriwToken)
# 	wla_do.ensure_visible(helpers_obj, 2)
# 	wla_do.link_object_to_scene(veiledObj, helpers_obj, 1)
# 	veiledObj.data = veiledmesh
# 	for c in veiledObj.constraints:
# 		veiledObj.constraints.remove(c)
# 	veiledObj.matrix_world = Matrix.Identity(4)
# 	veiledObj.location = Vector((0,0, config.kWPLUdiSyscMeshOffset))
# 	# Source object may change positions between frames!
# 	# adding constraints, even scale - since original mesh used (upscaled)
# 	copySclCon = veiledObj.constraints.new('COPY_SCALE')
# 	copySclCon.target = sel_obj
# 	copyRotCon = veiledObj.constraints.new('COPY_ROTATION')
# 	copyRotCon.target = sel_obj
# 	copyLocCon = veiledObj.constraints.new('COPY_LOCATION')
# 	copyLocCon.target = sel_obj
# 	copyLocCon.use_offset = True
# 	print("- object veil updated: ", veiledObj.name)
# 	return veiledObj

# ==========================================
class wplbind_apply_vgbind(bpy.types.Operator):
	bl_idname = "object.wplbind_apply_vgbind"
	bl_label = "Hier: Apply vgBind"
	bl_options = {'REGISTER', 'UNDO'}

	def execute(self, context):
		okCnt = 0
		failCnt = 0
		opt_localY = Vector((0.0, 1.0, 0.0))
		cage_cache = {}
		cage_cache_pre = {}
		sel_all = wla.selected_objects()
		sel_all = wla_arma.all_mesh_hiers(sel_all, wla_meshwrap.kWPLMESHWRAP_TYPES)
		# need to sort objects in proper order for cascaded bindings (charb first)
		sel_all = sorted(sel_all, key=lambda obj: len(wla_attr.vg_names_by_nameToken(obj, config.kWPLObjCharBodyPostfix)), reverse=True)
		valid_bindsteps = []
		cages2finalize = {}
		for sel_obj in sel_all:
			if wla.isTokenInStr(config.kWPLSystemOslAssets, sel_obj.name) or wla.isTokenInStr(config.kWPLSuppZZZZPrefix, sel_obj.name):
				print("- asset object, skipping", sel_obj.name)
				continue
			if config.kWPLObjCharBodyPostfix in sel_obj.name:
				# checking charb even if no binding steps are present - for tmp-selfchecks
				sel_obj_nonoperable = wla.is_object_nonoperable(sel_obj, None)
				if sel_obj_nonoperable is not None:
					failCnt = failCnt+1
					print("// skipped, nonoperable:", sel_obj_nonoperable)
					continue
				# just checking non-duplications
				if wla_vgbind.obj_checkUnwrap(sel_obj, True) == False:
					failCnt = failCnt+1
					print("// duplication check failed:", sel_obj.name)
					continue
			vg_groups = wla_attr.vg_names_by_nameToken(sel_obj, config.kWPLSuppVGScriptToken)
			for vgname in vg_groups:
				if "bind(" in vgname:
					print("- found binding", sel_obj.name, vgname)
					st_def = wla.strExtractOuterBrackets(vgname)
					st_opts = wla.strToTokens(st_def, False)
					if len(st_opts) < 3:
						failCnt = failCnt+1
						print("// skipped, not enough parameters")
						continue
					sel_obj_nonoperable = wla.is_object_nonoperable(sel_obj, None)
					if sel_obj_nonoperable is not None:
						failCnt = failCnt+1
						print("// skipped, nonoperable:", sel_obj_nonoperable)
						continue
					if wla.modf_by_type(sel_obj, 'ARMATURE') is not None:
						# test armature - need to be removed first
						failCnt = failCnt+1
						print("// skipped, armature modifier found:", sel_obj.name)
						continue
					if wla.modf_by_type(sel_obj,'MIRROR') is not None:
						# binding may tear mirror-based objects
						failCnt = failCnt+1
						print("// skipped, MIRROR found:", sel_obj.name)
						continue
					wla_do.select_and_change_mode(sel_obj,"OBJECT")
					#print("- step:", st_opts)
					# getting bind object base vertex positions
					cage_base_name_tok = st_opts[0]
					cage_base_ver_tok = st_opts[1]
					bind_base_ver_tok = st_opts[2]
					# === cage checks
					# getting cage object name
					cage_obj = wla.find_child_by_name(sel_obj, cage_base_name_tok, True, config.kWPLSystemOslNoBbox)
					if cage_obj is None and sel_obj.parent is not None:
						all_near_objs = wla.all_childs_recursive(sel_obj.parent)
						all_near_objs = [obj for obj in all_near_objs if (cage_base_name_tok in obj.name) and (wla.isTokenInStr(config.kWPLSystemOslNoBbox, obj.name) == False)]
						if len(all_near_objs) > 1:
							failCnt = failCnt+1
							print("// skipped, cage obj: too many possibilities", cage_base_name_tok, [obj.name for obj in all_near_objs])
							continue
						#print("// deepsearch1, cage obj", cage_base_name_tok, [obj.name for obj in all_near_objs])
						if len(all_near_objs) == 1:
							cage_obj = all_near_objs[0]
						if cage_obj is None:
							# checking 2 parents - even for empty, dress near char
							all_near_objs = wla.all_childs_recursive(sel_obj.parent.parent)
							all_near_objs = [obj for obj in all_near_objs if (cage_base_name_tok in obj.name) and (wla.isTokenInStr(config.kWPLSystemOslNoBbox, obj.name) == False)]
							if len(all_near_objs) > 1:
								failCnt = failCnt+1
								print("// skipped, cage obj: too many possibilities", cage_base_name_tok, [obj.name for obj in all_near_objs])
								continue
							#print("// deepsearch2, cage obj", cage_base_name_tok, [obj.name for obj in all_near_objs])
							if len(all_near_objs) == 1:
								cage_obj = all_near_objs[0]
					if cage_obj is None:
						all_tok_objs = wla.all_objects_by_name(cage_base_name_tok, None)
						if len(all_tok_objs) == 1:
							# using single variant - ok for character blends
							cage_obj = all_tok_objs[0]
					if cage_obj is None:
						failCnt = failCnt+1
						print("// skipped, cage obj: not found", cage_base_name_tok, "referenced at: " + sel_obj.name)
						continue
					cage_obj_nonoperable = wla.is_object_nonoperable(cage_obj, None)
					if cage_obj_nonoperable is not None:
						failCnt = failCnt+1
						print("// skipped, cage obj: nonoperable", cage_obj.name, cage_obj_nonoperable)
						continue
					if wla_vgbind.obj_checkUnwrap(cage_obj, True) == False:
						failCnt = failCnt+1
						print("// skipped, cage obj: unwrap not valid", cage_obj.name)
						continue
					if wla.modf_by_type(cage_obj, 'ARMATURE') is not None:
						if wla.object_full_name(cage_obj) not in cages2finalize:
							print("// Active ARMATURE found: making cage duplicate")
							wla_do.select_and_change_mode(cage_obj,"OBJECT")
							wla_do.find_last_changed_objects(False)
							bpy.ops.object.duplicate( linked=False )
							dups = wla_do.find_last_changed_objects(True)
							if len(dups) != 1:
								print("// skipped, cage obj: duplication failed", cage_obj.name)
								continue
							cage_obj_new = dups[0]
							cage_obj_new.name = config.kWPLSuppZZZZPrefix + "prefin_" + cage_obj.name
						cages2finalize[wla.object_full_name(cage_obj)] = cage_obj
					# using separate cache since making version may change vertex (subdiv apply etc)
					islandsMappingCage, islandsListCage = wla_vgbind.obj_parseIslands(cage_obj, config.kWPLIslandsVC, cage_cache_pre)
					islandsMappingSel, islandsListSel = wla_vgbind.obj_parseIslands(sel_obj, config.kWPLIslandsVC, cage_cache_pre)
					if len(islandsListCage) <= 1 or len(islandsListSel) <= 1:
						valid_bindsteps.append( (sel_obj, cage_obj, cage_base_name_tok, cage_base_ver_tok, bind_base_ver_tok, vgname, None) )
					else:
						print("- islands found", islandsListCage, islandsListSel)
						islandsListCage = reversed(islandsListCage)
						for colhash in islandsListCage:
							# step per Islands color
							valid_bindsteps.append( ( sel_obj, cage_obj, cage_base_name_tok, cage_base_ver_tok, bind_base_ver_tok, vgname, colhash ) )
		if failCnt>0:
			self.report({'ERROR'}, "Skipped, problems found="+str(failCnt))
			return {'FINISHED'}
		if len(valid_bindsteps) == 0:
			self.report({'INFO'}, "Skipped, no valid vgBind steps found")
			return {'FINISHED'}
		for cf_kk in cages2finalize:
			cage_obj = cages2finalize[cf_kk]
			print("- autofinalizing cage object", cage_obj.name)
			wla_do.select_and_change_mode(cage_obj,"OBJECT")
			wla_do.ensure_visible(cage_obj, 1)
			bpy.ops.object.wplbind_apply_transf(opt_applySubd=True, opt_makeVersion=True, opt_applyConstrs=False, opt_applyMirror=True, opt_applyArmat=True, opt_applyHooks=True, opt_applyShrinks=True, opt_applyArrays=True)
		failCnt = 0
		for st_opts in valid_bindsteps:
			sel_obj = st_opts[0]
			cage_obj = st_opts[1]
			cage_base_name_tok = st_opts[2]
			cage_base_ver_tok = st_opts[3]
			bind_base_ver_tok = st_opts[4]
			bind_base_vgname = st_opts[5]
			islands_color_hash = st_opts[6]
			wla_do.select_and_change_mode(sel_obj, "OBJECT")
			vgmap_bind = None
			#vgmap_rigids = None
			#bind_rigids_remap = {}
			bindfull_verts = []
			#bindhalf_verts = []
			if sel_obj.type == 'MESH':
				vgmap_bind = wla_attr.vg_get_weightMap(sel_obj, bind_base_vgname)
				if len(vgmap_bind) == 0:
					vgmap_bind = None
				sel_mesh = sel_obj.data
				# vgmap_rigids = wla_attr.vg_get_weightMap(sel_obj, config.kWPLSuppVGScriptRigids)
				# if vgmap_rigids is not None and len(vgmap_rigids)>0:
				# 	_, islandPerFace, _ = wla_edger.segmentMesh(sel_obj, None, None)
				# 	rigids_isl2vert = {}
				# 	rigids_isl2vertMain = {}
				# 	for poly in sel_mesh.polygons:
				# 		isl = int(islandPerFace[poly.index])
				# 		if isl not in rigids_isl2vert:
				# 			rigids_isl2vert[isl] = set()
				# 			rigids_isl2vertMain[isl] = set()
				# 		for vIdx in poly.vertices:
				# 			if vIdx not in vgmap_rigids:
				# 				continue
				# 			rigids_isl2vert[isl].add(vIdx)
				# 			if vgmap_rigids[vIdx] > 0.9:
				# 				rigids_isl2vertMain[isl].add(vIdx)
				# 	for isl in rigids_isl2vert.keys():
				# 		if len(rigids_isl2vert[isl]) == 0:
				# 			continue
				# 		if len(rigids_isl2vertMain[isl]) > 0:
				# 			vIdxMain = list(rigids_isl2vertMain[isl])[0]
				# 		else:
				# 			vIdxMain = list(rigids_isl2vert[isl])[0]
				# 		for vIdx in rigids_isl2vert[isl]:
				# 			bind_rigids_remap[vIdx] = vIdxMain
			print("- cage:", cage_obj.name)
			cage_base_ver_name = ""
			cage_vers,_,_ = wla.sys_objdata_versions(cage_obj)
			for v in cage_vers:
				if cage_base_ver_tok in v:
					cage_base_ver_name = v
					break
			if len(cage_base_ver_name) == 0:
				failCnt = failCnt+1
				print("// skipped, cage obj: base version not found", cage_obj.name, cage_base_ver_tok)
				continue
			# in case of shapekeys - moving to first
			# shapekeys can be used for skin depenetration
			if cage_obj.data.shape_keys is not None and len(cage_obj.data.shape_keys.key_blocks) > 0:
				keys = cage_obj.data.shape_keys.key_blocks.keys()
				if cage_obj.active_shape_key_index > 0:
					print("// cage: switching shapekey:", keys[cage_obj.active_shape_key_index], keys[0])
					cage_obj.active_shape_key_index = 0
			if cage_obj.data.name == cage_base_ver_name:
				# switching to last version
				print("- reverting cage to version", cage_vers[-1])
				wla_do.select_and_change_mode(cage_obj,"OBJECT")
				bpy.ops.object.wplheal_meshversion(opt_switchTo = cage_vers[-1])
			# === bind object checks
			md_arm = wla.modf_by_type(sel_obj,'ARMATURE')
			if (md_arm is not None) and (md_arm.show_viewport == True or md_arm.show_render == True):
				failCnt = failCnt+1
				print("// bind obj: skipped, active armature found")
				continue
			bind_base_ver_name = ""
			bind_vers,_,_ = wla.sys_objdata_versions(sel_obj)
			if len(bind_vers) < 2:
				if config.kWPLMatTokenWPV in sel_obj.data.name:
					failCnt = failCnt+1
					print("// bind obj: skipped, obj not versioned, when its data has version", sel_obj.name, sel_obj.data.name)
					continue
				print("// bind obj: second version not found, creating", sel_obj.name, bind_vers)
				wla_do.select_and_change_mode(sel_obj,"OBJECT")
				bpy.ops.object.wplheal_meshversion(opt_switchTo = "")
				bind_vers,_,_ = wla.sys_objdata_versions(sel_obj)
				if len(bind_vers) < 2:# MUST be 2 now
					failCnt = failCnt+1
					print("// bind obj: skipped, can`t create second version", sel_obj.name)
					continue
			for v in bind_vers:
				if bind_base_ver_tok in v:
					bind_base_ver_name = v
					break
			if len(bind_base_ver_name) == 0:
				failCnt = failCnt+1
				print("// skipped, bind obj: base version not found", sel_obj.name, bind_base_ver_tok)
				continue
			bind_base_meshdata = wla_meshwrap.object_wrappedmesh(sel_obj, {wla_meshwrap.kWPL_MESHVERKey: bind_base_ver_name})
			if (bind_base_meshdata is None):
				failCnt = failCnt+1
				print("// skipped, bind obj: base version not found", sel_obj.name, bind_base_ver_name)
				continue
			if sel_obj.data.name == bind_base_ver_name: #  and self.opt_mode != 'RESETAPPL'
				# switching to last version
				print("- reverting bind to version", bind_vers[-1])
				wla_do.select_and_change_mode(sel_obj,"OBJECT")
				bpy.ops.object.wplheal_meshversion(opt_switchTo = bind_vers[-1])
			# === applying bind
			wla_do.select_and_change_mode(sel_obj,"OBJECT")
			# getting cage object mapping, cage_rVertsRemap
			cage_base_co_g, cage_base_nrm_g, cage_now_co_g, cage_now_nrm_g, bm_cage2bvh, bm_cageEdges = None, None, None, None, None, None
			if cage_obj.name in cage_cache:
				# cached, if calculated already
				cage_base_co_g, cage_base_nrm_g, cage_now_co_g, cage_now_nrm_g, bm_cage2bvh, bm_cageEdges = cage_cache[cage_obj.name]
			else:
				cage_base_co_g, cage_base_nrm_g, cage_now_co_g, cage_now_nrm_g, bm_cage2bvh, bm_cageEdges = wla_vgbind.bm_getBase2NowMappingGlobal(cage_obj, config.kWPLGridUV, cage_base_ver_name)
				cage_cache[cage_obj.name] = (cage_base_co_g, cage_base_nrm_g, cage_now_co_g, cage_now_nrm_g, bm_cage2bvh, bm_cageEdges)
			if cage_base_co_g is None:
				failCnt = failCnt+1
				print("// skipped, cage obj: no mapping/uv-dups", cage_obj.name, cage_base_ver_name)
				continue
			bind_now_meshdata = wla_meshwrap.object_wrappedmesh(sel_obj)
			if len(bind_base_meshdata.all_vertsIdx()) != len(bind_now_meshdata.all_vertsIdx()):
				failCnt = failCnt+1
				print("// skipped, bind obj: vert count does not match", sel_obj.name, bind_base_ver_name)
				continue
			# fulfilling for all types (not mesh only)
			for vIdx in bind_base_meshdata.all_vertsIdx():
				if (vgmap_bind is None):
					bindfull_verts.append(vIdx)
				elif (vIdx in vgmap_bind) and vgmap_bind[vIdx] > 0.1:
					bindfull_verts.append(vIdx)
				# if vgmap_bind[vIdx] > 0.49 and vgmap_bind[vIdx]<0.99:
				# 	bindhalf_verts.append(vIdx)
				# elif vgmap_bind[vIdx] >= 0.99:
				# 	bindfull_verts.append(vIdx)
			bind_base_co_g = {}
			bind_baseF_co_g = {}
			bind_baseF_nrm_g = {}
			selobj_mw = sel_obj.matrix_world
			selobj_mw_nrml = sel_obj.matrix_world.inverted().transposed().to_3x3()
			for vIdx in bindfull_verts:
				prev_v = bind_base_meshdata.vertices[vIdx]
				pt_coord = prev_v.co
				pt_coord_g = selobj_mw @ pt_coord
				bind_baseF_co_g[vIdx] = pt_coord_g
				bind_baseF_nrm_g[vIdx] = selobj_mw_nrml @ wla.coalesce(prev_v.normal, opt_localY)
				bind_base_co_g[vIdx] = pt_coord_g
			if islands_color_hash is not None:
				# removing verts, that do not match islads
				islandsMappingCage, islandsListCage = wla_vgbind.obj_parseIslands(cage_obj,config.kWPLIslandsVC,cage_cache)
				islandsMappingSel, islandsListSel = wla_vgbind.obj_parseIslands(sel_obj,config.kWPLIslandsVC,cage_cache)
				delInCage = 0
				delInBase = 0
				cage_base_co_g = copy.copy(cage_base_co_g)
				cage_base_nrm_g = copy.copy(cage_base_nrm_g)
				cage_now_co_g = copy.copy(cage_now_co_g)
				cage_now_nrm_g = copy.copy(cage_now_nrm_g)
				bind_base_co_g = copy.copy(bind_base_co_g)
				#bind_rigids_remap = copy.copy(bind_rigids_remap)
				for vIdx in islandsMappingCage:
					if islandsMappingCage[vIdx] != islands_color_hash:
						delInCage = delInCage+1
						cage_base_co_g.pop(vIdx, None)
						cage_base_nrm_g.pop(vIdx, None)
						cage_now_co_g.pop(vIdx, None)
						cage_now_nrm_g.pop(vIdx, None)
				for vIdx in islandsMappingSel:
					if islandsMappingSel[vIdx] != islands_color_hash:
						delInBase = delInBase+1
						bind_base_co_g.pop(vIdx, None)
						#bind_rigids_remap.pop(vIdx, None)
				if len(cage_base_co_g) == 0 or len(cage_now_co_g) == 0 or len(bind_base_co_g) == 0:
					print("- skipping island match, no verts for:", islands_color_hash)
					continue
				#print("- applying island",islands_color_hash,"Cage drops:", delInCage,"base drops:", delInBase, len(islandsMappingCage), len(islandsMappingSel), len(cage_obj.data.vertices), len(sel_obj.data.vertices))
			# testSameIndexes1 = set(bm_cageEdges.keys())
			# testSameIndexes2 = set(cage_base_co_g.keys())
			# print("- cage_rVertsRemap - same verts/indexes???", len(testSameIndexes1), len(testSameIndexes2), testSameIndexes1 ^ testSameIndexes2) # no diff == same
			cage_rVertsRemap = bm_cageEdges # cleanup to use only island-restricted side-verts - not needed, filtered in remapping
			#print("- surface remap", islands_color_hash, "len(cage_base_co_g)", len(cage_base_co_g), "len(cage_now_co_g)", len(cage_now_co_g), "len(bind_base_co_g)", len(bind_base_co_g))
			bind_now_co_g_final, _ = wla_vgbind.math_remapSurface(cage_base_co_g, cage_base_nrm_g, cage_now_co_g, cage_now_nrm_g, bind_base_co_g, cage_rVertsRemap)
			# new coords as is
			for vIdx in bind_now_co_g_final:
				v = bind_now_meshdata.vertices[vIdx]
				v.co = sel_obj.matrix_world.inverted() @ bind_now_co_g_final[vIdx]
			bind_now_meshdata.to_mesh()
			# if len(bindhalf_verts) > 0:
			# 	# bindhalf_verts are binded to mesh parts of bindfull_verts
			# 	print("- base remapped, binding second half", len(bind_now_co_g_final), len(bindhalf_verts))
			# 	bind_now_meshdata2 = wla_meshwrap.object_wrappedmesh(sel_obj) # to get updated normals
			# 	bind_now_nrm_g = {}
			# 	bindhalf_base_co_g = {}
			# 	for vIdx in bindhalf_verts:
			# 		prev_v = bind_base_meshdata.vertices[vIdx]
			# 		bindhalf_base_co_g[vIdx] = selobj_mw @ prev_v.co
			# 	for vIdx in bind_baseF_co_g:
			# 		if vIdx not in bind_now_co_g_final:
			# 			# copying positions/verts for non-projected verts
			# 			bind_now_co_g_final[vIdx] = bind_baseF_co_g[vIdx]
			# 			bind_now_nrm_g[vIdx] = bind_baseF_nrm_g[vIdx]
			# 	for vIdx in bind_now_co_g_final:
			# 		prev_v = bind_now_meshdata2.vertices[vIdx]
			# 		bind_now_nrm_g[vIdx] = selobj_mw_nrml @ wla.coalesce(prev_v.normal, opt_localY)
			# 	bindhalf_now_co_g_final, _ = wla_vgbind.math_remapSurface(bind_baseF_co_g, bind_baseF_nrm_g, bind_now_co_g_final, bind_now_nrm_g, bindhalf_base_co_g, None)
			# 	for vIdx in bindhalf_now_co_g_final:
			# 		v = bind_now_meshdata2.vertices[vIdx]
			# 		v.co = sel_obj.matrix_world.inverted() @ bindhalf_now_co_g_final[vIdx]
			# 	bind_now_meshdata2.to_mesh()
			okCnt = okCnt+1
		wla_do.select_and_activate_multi(sel_all, None)
		self.report({'INFO'}, "Done, steps="+str(okCnt)+", failed="+str(failCnt))
		return {'FINISHED'}

class wplbind_apply_vgscript(bpy.types.Operator):
	bl_idname = "object.wplbind_apply_vgscript"
	bl_label = "Apply vgScript"
	bl_options = {'REGISTER', 'UNDO'}

	def execute(self, context):
		sel_all = wla.selected_objects()
		sel_all = wla_arma.all_mesh_hiers(sel_all, ['MESH','CURVE','LATTICE'])
		if len(sel_all) == 0:
			self.report({'ERROR'}, "No selected objects found")
			return {'FINISHED'}
		oldmode = wla_do.select_and_change_mode(sel_all[0],"OBJECT")
		for obj in sel_all:
			if wla.isTokenInStr(config.kWPLSystemOslNoBbox, obj.name) == False:
				obj_nonoperable = wla.is_object_nonoperable(obj, ["obj_multi_user"])
				if obj_nonoperable is not None:
					# charb-cuts inherit charb scale
					# problems with skin/etc objects... scale inherited
					print("- problem:", obj_nonoperable)
					self.report({'ERROR'}, "Object not ready:" + obj_nonoperable)
					return {'CANCELLED'}
		okCnt = 0
		for obj in sel_all:
			if wla.isTokenInStr(config.kWPLSystemOslAssets, obj.name):
				print("- asset object, skipping", obj.name)
				continue
			wla_do.select_and_change_mode(obj, 'OBJECT')
			okCntObj = wla_vgs.execVgScriptOnObject(obj, True)
			if okCntObj is None:
				print("- failed to execute vgScript")
				continue
			print("- vgScript on",obj.name,"steps executed:",okCntObj)
			okCnt = okCnt+okCntObj
		if len(sel_all) > 1:
			wla_do.select_and_activate_multi(sel_all)
		else:
			wla_do.select_and_change_mode(sel_all[0],oldmode)
		self.report({'INFO'}, "Done, steps="+str(okCnt))
		return {'FINISHED'}

class wplbind_apply_transf(bpy.types.Operator):
	# Also used in joined mesh duplication
	bl_idname = "object.wplbind_apply_transf"
	bl_label = "Finalize objects"
	bl_options = {'REGISTER', 'UNDO'}

	opt_applyMirror : BoolProperty(
		name		= "Apply mirror (if any)",
		default	 = True
		)
	opt_applyArmat : BoolProperty(
		name		= "Apply armature (if any)",
		default	 = True
		)
	opt_applyHooks : BoolProperty(
		name		= "Apply hooks (if any)",
		default	 = True
		)
	opt_applyShrinks : BoolProperty(
		name		= "Apply shrinks (if any)",
		default	 = True
		)
	opt_applyArrays : BoolProperty(
		name		= "Apply arrays (if any)",
		default	 = True
		)
	opt_applySubd : BoolProperty(
		name		= "Apply subd (if any)",
		default	 = False
		)
	opt_applyConstrs : BoolProperty(
		name		= "Remove constraints (if any)",
		default	 = False
		)
	opt_makeVersion : BoolProperty(
		name		= "Make version",
		default	 = False
		)
	def execute( self, context ):
		active_obj = wla.active_object()
		sel_all = wla.selected_objects()
		sel_all = wla_arma.all_mesh_hiers(sel_all, ['LATTICE', 'MESH', 'CURVE'])
		if len(sel_all) == 0:
			self.report({'ERROR'}, "No objects selected")
			return {'CANCELLED'}
		okCnt = 0
		errCnt = 0
		if len(sel_all) == 1:
			# special cases
			lobj = sel_all[0]
			if lobj.type == 'LATTICE':
				sel_all = [obj for obj in bpy.context.scene.objects]
				for obj in sel_all:
					md_latt = wla.modf_by_type(obj,'LATTICE')
					if md_latt is not None and md_latt.object == lobj:
						print("- applying lattice", obj.name)
						wla_do.select_and_change_mode(obj,"OBJECT")
						bpy.ops.object.modifier_apply(modifier=md_latt.name)
						okCnt = okCnt+1
				wla_do.select_and_change_mode(lobj,"OBJECT")
				bpy.data.objects.remove(lobj, do_unlink=True)
				self.report({'INFO'}, "Objects updated: "+str(okCnt)+" of "+str(len(sel_all)))
				return {'FINISHED'}
		for i, lobj in enumerate(sel_all):
			if config.kWPLMatTokenWPV in lobj.name:
				self.report({'ERROR'}, "Some objects has token ["+config.kWPLMatTokenWPV+"]: "+ lobj.name)
				return {'CANCELLED'}
			if lobj.type in ['MESH'] and wla.object_useCount(lobj.data) > 1:
				self.report({'ERROR'}, "Some objects has multi-user data: "+ lobj.name)
				return {'CANCELLED'}
			isCharbObj = (wla.isTokenInStr([config.kWPLObjCharBodyPostfix], lobj.name) == True)
			if self.opt_makeVersion or isCharbObj:
				# # no subdiv -> original positions should match visuals for proper vgbind
				# if wla.modf_by_type(lobj,'SUBSURF') is not None:
				# 	self.report({'ERROR'}, "Subsurf found, must be applied before Armature")
				# 	return {'CANCELLED'}
				#print("- testing UV", self.opt_makeVersion, isCharbObj)
				wla_do.select_and_change_mode(lobj,"OBJECT")
				if wla_vgbind.obj_checkUnwrap(lobj, True) == False:
					self.report({'ERROR'}, "UV unwrap not ok: "+ lobj.name+", cant continue")
					return {'CANCELLED'}
				else:
					print("- Unwrap duplications check: all ok")
			if lobj.type == 'MESH' and lobj.data.shape_keys is not None and len(lobj.data.shape_keys.key_blocks)>0:
				#self.report({'ERROR'}, "Some objects has shapekeys: "+lobj.name)
				#return {'CANCELLED'}
				for shkn in range(0,len(lobj.data.shape_keys.key_blocks)):
					lobj.active_shape_key_index = 0
					sk = lobj.data.shape_keys.key_blocks[lobj.active_shape_key_index]
					lobj.shape_key_remove(sk)
		for i, lobj in enumerate(sel_all):
			if lobj.type == 'ARMATURE':
				continue
			if lobj.library is not None or lobj.hide_select:
				continue
			print("Finalizing",lobj.name)
			# if wla.object_useCount(lobj.data) > 1:
			# 	print("- skipped, multi-user data", lobj.name)
			# 	continue
			#print("- users:", lobj.name, wla.object_useCount(lobj.data))
			if lobj.type == 'MESH':
				lobj.data.use_mirror_x = False
				lobj.data.use_mirror_topology = False
			wla_do.select_and_change_mode(lobj,"OBJECT")
			if self.opt_makeVersion:
				print("- making version for", lobj.name)
				# vgs-bind specials: need fully applied subd+armature in BASE version for REST pose TOO!
				# so: making apply and setting back meshdata to reaply real modifiers on latest version again
				# subsurf neede AFTER armature -> smoothed deforms
				armatrOrig = None
				meshVerOrigCopy = None
				armaModfOrig = None
				subdModfOrig = None
				if self.opt_applyArmat and self.opt_applyShrinks:
					meshVerOrigCopy = lobj.data.copy()
					armaModfOrig = wla.modf_by_type(lobj,'ARMATURE')
					subdModfOrig = wla.modf_by_type(lobj,'SUBSURF')
					if armaModfOrig is not None and subdModfOrig is not None:
						armatrOrig = armaModfOrig.object
						print("- armature: temporary switching to REST", armatrOrig.name)
						armatrOrig.data.pose_position = 'REST'
						#subdModfOrig.uv_smooth = 'SMOOTH_ALL'
						subdModfOrig.uv_smooth = 'NONE' # AMUST for vgBIND unwrap
						armaModfTemp = lobj.modifiers.new("tmp_a", 'ARMATURE')
						wla_do.modf_copy_opts(armaModfTemp, armaModfOrig)
						armaModfOrig.show_viewport = False
						armaModfOrig.show_render = False
						subdModTemp = lobj.modifiers.new("tmp_s", 'SUBSURF')
						wla_do.modf_copy_opts(subdModTemp, subdModfOrig)
						subdModfOrig.show_viewport = False
						subdModfOrig.show_render = False
						wla_do.sys_update_mesh(lobj)
						armaModfTemp.name = "tmp_a"
						armaModfTemp.show_viewport = True
						armaModfTemp.show_render = True
						subdModTemp.name = "tmp_s"
						subdModTemp.show_viewport = True
						subdModTemp.show_render = True
						bpy.ops.object.modifier_apply(modifier="tmp_a")
						bpy.ops.object.modifier_apply(modifier="tmp_s")
						#print("- armature: temporary REST applyed")
				# saving version
				wla_do.select_and_change_mode(lobj,"OBJECT")
				bpy.ops.object.wplheal_meshversion(opt_switchTo = "")
				wla_do.select_and_change_mode(lobj,"OBJECT")
				if meshVerOrigCopy is not None:
					# replacing current version with copied original
					meshVerLatest = lobj.data
					meshVerLatestName = meshVerLatest.name
					print("- restoring base mesh",meshVerOrigCopy.name,"->",meshVerLatestName)
					lobj.data = meshVerOrigCopy # restoring non-applied base mesh
					meshVerLatest.use_fake_user = False
					meshVerLatest.name = config.kWPLSuppZZZPrefix + lobj.name
					meshVerOrigCopy.use_fake_user = True
					meshVerOrigCopy.name = meshVerLatestName
				if (armaModfOrig is not None) and (armatrOrig is not None):
					armaModfOrig.show_viewport = True
					armaModfOrig.show_render = True
					armatrOrig.data.pose_position = 'POSE'
				if subdModfOrig is not None:
					subdModfOrig.show_viewport = True
					subdModfOrig.show_render = True
				wla_do.sys_update_mesh(lobj)
			if self.opt_applyConstrs == True and len(lobj.constraints)>0:
				bpy.ops.object.visual_transform_apply()
				for c in lobj.constraints:
					if config.kWPLFrameBindPostfix in c.name:
						continue # This constraint is needed
					lobj.constraints.remove(c)
			#try:
			applMods = []
			remvMods = []
			mirrorMd = None
			for md in lobj.modifiers:
				if md.show_viewport == False and md.show_render == False:
					continue
				if wla.isTokenInStr(config.kWPLSuppVGScriptToken, md.name):
					continue
				if self.opt_applyMirror == True and md.type == 'MIRROR':
					mirrorMd = md
				if self.opt_applyHooks == True and md.type == 'HOOK':
					applMods.append(md.name)
				if self.opt_applyHooks == True and md.type == 'MESH_DEFORM':
					applMods.append(md.name)
				if self.opt_applyHooks == True and md.type == 'LATTICE':
					applMods.append(md.name)
				if self.opt_applyHooks == True and md.type == 'SURFACE_DEFORM' and lobj.type == 'MESH':
					applMods.append(md.name)
				if self.opt_applyHooks == True and md.type == 'CURVE':
					applMods.append(md.name)
				if self.opt_applyArrays == True and md.type == 'ARRAY':
					applMods.append(md.name)
				if self.opt_applyMirror == True and md.type == 'MIRROR' and lobj.type == 'MESH':
					applMods.append(md.name)
				if self.opt_applyArmat == True and md.type == 'CORRECTIVE_SMOOTH' and lobj.type == 'MESH':
					applMods.append(md.name)
				if self.opt_applyArmat == True and md.type == 'ARMATURE':
					applMods.append(md.name)
				if self.opt_applyArmat == True and md.type == 'SKIN':
					applMods.append(md.name)
				if self.opt_applyShrinks == True and (md.type == 'SHRINKWRAP' or md.type == 'SMOOTH' or md.type == 'DISPLACE' or md.type == 'SIMPLE_DEFORM'):
					applMods.append(md.name)
				if self.opt_applySubd == True and (md.type == 'SUBSURF' or md.type == 'MULTIRES'):
					applMods.append(md.name)
			if len(applMods) > 0:
				print("- applying selected modfs...")
				if wla.object_useCount(lobj.data) > 1:
					print("- Making single-user: [",lobj.name,"/",lobj.data.name,"]; current count=",lobj.data.users)
					bpy.ops.object.make_single_user(object=False, obdata=True)
				for mdname in applMods:
					print("- Applying",mdname)
					md = lobj.modifiers.get(mdname)
					if md.type == 'ARMATURE':
						# preserving armature in custom properties - so OPS can detect hiearchies
						lobj[config.kWPLSystemFinPrefix + "ARMATURE"] = md.object.name
					bpy.ops.object.modifier_apply(modifier=mdname)
			else:
				print("- skipped, no modfs to apply...")
			if mirrorMd is not None and lobj.type == 'CURVE':
				print("- Manual mirror")
				remvMods.append(mirrorMd)
				wla_curve.cu_apply_xmirror(lobj,False)
				wla_do.select_and_change_mode(lobj,"OBJECT")
			if len(remvMods) > 0:
				for md in remvMods:
					lobj.modifiers.remove(md)
			if len(applMods) > 0:
				#print("- UV check...")
				if wla_vgbind.obj_checkUnwrap(lobj, False) == False:
					print("- ERROR: Final UV unwrap not ok: "+ lobj.name)
					errCnt = errCnt+1
			okCnt = okCnt+1
		if errCnt>0:
			self.report({'ERROR'}, "Objects updated: errs:"+str(errCnt)+"/"+str(okCnt)+"/"+str(len(sel_all)))
		else:
			self.report({'INFO'}, "Objects updated: "+str(okCnt)+" of "+str(len(sel_all)))
		wla_do.select_and_activate_multi(sel_all, active_obj)
		return {'FINISHED'}

class wplbind_maskout(bpy.types.Operator):
	bl_idname = "mesh.wplbind_maskout"
	bl_label = "modf: HideGeom selection"
	bl_options = {'REGISTER', 'UNDO'}

	opt_vg2use : StringProperty(
		name = "Vertex group",
		default = ""
	)
	opt_extraAction : EnumProperty(
		name= "Extra action",
		default="HIDE",
		items = (
			("HIDE", "Hide selected", "", 1), 
			("UNHIDE", "Unhide selected", "", 2), 
			("SWAP", "UnHide and remove others", "", 3),
			("EXTRACT", "Extract to clean copy", "", 4),
		)
	)

	def execute( self, context ):
		active_obj = wla.active_object(['MESH', 'GPENCIL'])
		if active_obj is None:
			self.report({'ERROR'}, "Select mesh object first")
			return {'CANCELLED'}
		active_mesh = active_obj.data
		oldmode = wla_do.select_and_change_mode(active_obj,"OBJECT")
		vgname = self.opt_vg2use
		if len(vgname) == 0:
			vgname = config.kWPLSuppVGHideMaskM
		print("- Hidegeom", active_obj.name, active_obj.type, self.opt_extraAction)
		if active_obj.type == 'GPENCIL':
			# special case
			if self.opt_extraAction == 'EXTRACT':
				# removin temps, includin kWPLEdgeSysPrefix, kWPLEdgeTmpPrefix
				clean_neam = wla.strReplaceTokenInStr(config.kWPLSystemOslIgnored, active_obj.name, "")
				clean_obj = wla.object_by_name(clean_neam)
				if (clean_obj is not None) and (clean_obj == active_obj):
					self.report({'ERROR'}, "Object name must contain tmp tags")
					return {'CANCELLED'}
				modf_cache = {}
				wla_do.find_last_changed_objects(False)
				wla_do.select_and_change_mode(active_obj, 'EDIT')
				bpy.ops.gpencil.select_linked()
				bpy.ops.gpencil.stroke_separate(mode='STROKE')
				dups = wla_do.find_last_changed_objects(True)
				if len(dups) != 1:
					self.report({'ERROR'}, "Object separation goes wrong")
					return {'CANCELLED'}
				extracted_obj = dups[0]
				wla_edger.object_ensureGP(extracted_obj.data)
				wla_do.select_and_change_mode(extracted_obj, 'OBJECT')
				print("- extracted object:", extracted_obj)
				if clean_obj is None:
					clean_obj = extracted_obj
					clean_obj.name = clean_neam
				else:
					print("- joining extracted to existing:", extracted_obj, clean_obj)
					wla_edger.object_ensureGP(clean_obj.data)
					wla_edger.object_ensureGP(extracted_obj.data)
					wla_edger.object_removeGPmodf(extracted_obj)
					## wla_do.modf_toggle(extracted_obj, "*", False, modf_cache)
					## wla_do.modf_toggle(clean_obj, "*", False, modf_cache)
					## wla_do.sys_update_view(True, True)
					wla_do.select_and_activate_multi([clean_obj, extracted_obj], clean_obj)
					bpy.ops.object.join()
					wla_do.select_and_change_mode(clean_obj, 'OBJECT')
					wla_edger.object_optimizeGPLayers(clean_obj, True, True)
					wla_do.select_and_change_mode(clean_obj, 'EDIT')
					bpy.ops.gpencil.select_all(action='DESELECT')
					 # Copy-Paste not ok... layers must be set the same
					# wla_do.select_and_change_mode(extracted_obj, 'EDIT')
					# bpy.ops.gpencil.select_all(action='SELECT')
					# bpy.opscurve.wplcurve_strokes_copy(opt_mode = 'CUT')
					# wla_do.select_and_change_mode(clean_obj, 'EDIT')
					# bpy.opscurve.wplcurve_strokes_paste()
					# bpy.data.objects.remove(extracted_obj, do_unlink=True)
				# wla_do.modf_toggle(clean_obj, "*", True, None)
				wla_do.select_and_change_mode(active_obj, 'EDIT')
				self.report({'INFO'}, "Extracted to " + clean_obj.name)
				return {'FINISHED'}
			if self.opt_extraAction == 'HIDE':
				from . import ops_curves_edit
				vg = wla_attr.vg_get_or_new(active_obj, vgname)
				_, _, selected_polys_cu = wla_curve.cu_getSelectedStrokes(active_obj, False, True)
				ops_curves_edit.cu_desel_all(active_obj)
				for gps in selected_polys_cu:
					for i, pt in enumerate(gps.points):
						gps.points.weight_set(vertex_group_index=vg.index, point_index=i, weight=1.0)
				if wla.modf_by_type(active_obj, None, wla_edger.kWPL_EdgeModf_GPHideGeom) is None:
					md = active_obj.grease_pencil_modifiers.new(wla_edger.kWPL_EdgeModf_GPHideGeom, 'GP_OFFSET')
					md.location = (0,0,-100)
					md.scale = (-1, -1, -1)
					md.show_render = True
					md.show_viewport = True
					md.show_in_editmode = True
					md.vertex_group = vg.name
			if self.opt_extraAction == 'UNHIDE':
				modf = wla.modf_by_type(active_obj, None, wla_edger.kWPL_EdgeModf_GPHideGeom)
				if modf is not None:
					active_obj.grease_pencil_modifiers.remove(modf)
				wla_do.select_and_change_mode(active_obj, 'EDIT')
				vg = wla_attr.vg_get_or_new(active_obj, vgname)
				strokes = wla_curve.cu_getSplines(active_obj)
				# resetting weights!!! for reruns
				for gps in strokes:
					for i, pt in enumerate(gps.points):
						gps.points.weight_set(vertex_group_index=vg.index, point_index=i, weight=0.0)
			if self.opt_extraAction == 'SWAP':
				modf = wla.modf_by_type(active_obj, None, wla_edger.kWPL_EdgeModf_GPHideGeom)
				if modf is not None:
					active_obj.grease_pencil_modifiers.remove(modf)
				wla_do.select_and_change_mode(active_obj, 'EDIT')
				vg = wla_attr.vg_get_or_new(active_obj, vgname)
				bpy.ops.gpencil.select_all(action='DESELECT')
				strokes = wla_curve.cu_getSplines(active_obj)
				for gps in strokes:
					for i, pt in enumerate(gps.points):
						wei = 0.0
						try:
							wei = gps.points.weight_get(vertex_group_index=vg.index, point_index=i)
						except Exception as e:
							pass
						if wei < 0.1:
							pt.select = True
				bpy.ops.gpencil.delete(type='POINTS')
			wla_do.select_and_change_mode(active_obj, oldmode)
			return {'FINISHED'}
		selvertsAll = wla.selected_vertsIdx(active_mesh)
		if len(selvertsAll) == 0:
			self.report({'ERROR'}, "No selected vertices found")
			return {'FINISHED'}
		try:
			wpl_weigToolOpts = context.scene.wpl_uvvgOpts
			wpl_weigToolOpts.wei_gropnm = vgname
		except Exception as e:
			pass
		mask_group = wla_attr.vg_add_verts2vg(active_obj, vgname, selvertsAll, 1.0)
		mask_modifier = active_obj.modifiers.get(vgname)
		if mask_modifier is None:
			mask_modifier = active_obj.modifiers.new(name = vgname, type = 'MASK')
			mask_modifier.vertex_group = mask_group.name
			mask_modifier.invert_vertex_group = True
			mask_modifier.threshold = 0.1 # must be bigger 0.3!!! subsurf hafing vertex -> vgScript can`t normally work
			mask_modifier.show_in_editmode = True
			mask_modifier.show_on_cage = True
			mask_modifier.show_render = True
		wla_do.select_and_change_mode(active_obj, oldmode)
		active_mesh.update()
		self.report({'INFO'}, "Masked "+str(len(selvertsAll))+" verts")
		return {'FINISHED'}

# class wplbind_auto_veil(bpy.types.Operator):
# 	bl_idname = "object.wplbind_auto_veil"
# 	bl_label = "Add SysC-underveil"
# 	bl_options = {'REGISTER', 'UNDO'}

# 	opt_verToken : StringProperty(
# 		name = "Mesh version",
# 		default = "<latest>"
# 	)

# 	def execute( self, context ):
# 		active_obj = wla.active_object(['MESH'])
# 		if active_obj is None:
# 			self.report({'ERROR'}, "Select object first")
# 			return {'CANCELLED'}
# 		veiledObj = object_addVeil(active_obj, self.opt_verToken, True)
# 		if veiledObj is None:
# 			self.report({'ERROR'}, "Error: SysC-underveil NOT added")
# 			return {'FINISHED'}
# 		self.report({'INFO'}, "SysC-underveil added: "+veiledObj.name)
# 		return {'FINISHED'}

class wplbind_auto_uvbase_syse(bpy.types.Operator):
	bl_idname = "object.wplbind_auto_uvbase_syse"
	bl_label = "Generate alt-uv base"
	bl_options = {'REGISTER', 'UNDO'}

	opt_matReplace : StringProperty(
		name = "Replace Materials",
		default = ""
	)

	opt_removeBackf : BoolProperty(
		name="Remove invisible faces",
		default=False
	)
	opt_shift2cam : FloatProperty(
		name="Add Offset to Camera",
		default=0.1
	)

	# Running as separate dialog
	def invoke(self, context, event):
		return context.window_manager.invoke_props_dialog(self, width = 200)

	def execute( self, context ):
		camera_obj = wla.object_by_name(config.kWPLSystemMainCam)
		if camera_obj is None:
			self.report({'ERROR'}, "Camera not found: "+config.kWPLSystemMainCam)
			return {'CANCELLED'}
		tmp_cache = {}
		okCnt = 0
		sel_all = wla.selected_objects(["MESH"])
		# helpers_obj = wla.sys_empty(config.kWPLSystemObjSysEHelpers)
		# wla_do.ensure_visible(helpers_obj, 2)
		for active_obj in sel_all:
			# syse object... with pre-frame name
			ovl_name = config.kWPLSuppZZZPrefix + "altuv" + config.kWPLUdiSyseToken + "_" + active_obj.name + config.kWPLRQueueBindPostfix[0] + config.kWPLObjProtoToken[0]
			# ovl_name = ovl_name + config.kWPLFrameBindPostfix + str(int(bpy.context.scene.frame_current)) # not really
			# ovl_obj = wla.find_child_by_name(helpers_obj, ovl_name, False)
			obj_clone = wla_do.clone_evaluated_obj(active_obj, ovl_name, False, True, None)
			obj_clone.data.name = config.kWPLSuppZZZPrefix + "altuv" + "_" + active_obj.name # SHOULD NOT HAVE kWPLRQueueBindPostfix
			_, hidegeom_orig, _ = wla_attr.vg_get_verts(active_obj, config.kWPLSuppVGHideMaskM, 0.1, None)
			# wla_attr.attr3v_obj_ensure(obj_clone, kWPL_ATTR_FMOMCO)
			# wla_attr.attr3v_obj_ensure(obj_clone, kWPL_ATTR_FMOMNRM)
			wla_do.select_and_change_mode(obj_clone, 'EDIT')
			bm = bmesh.from_edit_mesh(obj_clone.data)
			bm.verts.ensure_lookup_table()
			bm.verts.index_update()
			bm.faces.ensure_lookup_table()
			bm.faces.index_update()
			if len(bm.verts) == 0:
				print("- WARNING: no verts in extracted mesh")
				self.report({'INFO'}, "No verts in copy")
				return {'FINISHED'}
			# shifting to cam
			for v in bm.verts:
				v.co = wla_vgs.srcbvh_offsetPtToCam(v.co, self.opt_shift2cam, active_obj, tmp_cache)
			if self.opt_removeBackf:
				# if ovl_obj is not None:
				# 	ovl_obj.hide_viewport = True
				wla_do.sys_update_view(True, False)
				depsgraph = bpy.context.evaluated_depsgraph_get() # after hide
				#camera_obj_l = obj_clone.matrix_world.inverted() @ camera_gCo
				# deleting backfaces (if all neighbours also backfaced)
				faces2del = set()
				f2test = set()
				for f in bm.faces:
					for v in f.verts:
						if v.index in hidegeom_orig:
							faces2del.add(f)
							break
					f2test.add(f)
				# print("- hidegeomed", len(faces2del)," faces2test", len(f2test))
				for f in f2test:
					isAnyVisible = False
					castpts = []
					for v in f.verts:
						v_co_g = (active_obj.matrix_world @ v.co)
						castpts.append(v_co_g)
					# opt_castDiffDist = 0.001
					# for e in f.edges:
					# 	opt_castDiffDist = max(opt_castDiffDist, e.calc_length()*0.33)
					castpts.append( active_obj.matrix_world @ f.calc_center_median() )
					# dbg_obj = []
					for v_co_g in castpts:
						isPtVis = wla_vgs.srcbvh_isPtSceneVisible(depsgraph, v_co_g, tmp_cache)
						if isPtVis:
							isAnyVisible = True
							break
					if isAnyVisible == False:
						faces2del.add(f)
						# print("- del face",f.index,dbg_obj)
				print("- deleting invisible faces",len(faces2del))
				if len(faces2del) > 0:
					bmesh.ops.delete(bm, geom=list(faces2del), context='FACES')
			bm.verts.ensure_lookup_table()
			bm.verts.index_update()
			bm.normal_update()
			bmesh.update_edit_mesh(obj_clone.data)
			wla_do.select_and_change_mode(obj_clone, 'OBJECT')
			mt_name = wla_attr.mat_find_any(self.opt_matReplace)
			if mt_name is not None:
				mt = bpy.data.materials.get(mt_name)
				print("- replacing materials", mt)
				for i, slt in enumerate(obj_clone.material_slots):
					slt.material = mt
			copyLocCon = obj_clone.constraints.new('COPY_LOCATION')
			copyLocCon.target = active_obj
			copyLocCon.use_offset = True
			# attr_fmomco = obj_clone.data.attributes.get(kWPL_ATTR_FMOMCO) #bm.verts.layers.float_vector.get(kWPL_ATTR_FMOMCO)
			# attr_fmomnrm = obj_clone.data.attributes.get(kWPL_ATTR_FMOMNRM) #bm.verts.layers.float_vector.get(kWPL_ATTR_FMOMNRM)
			# obc_mw = obj_clone.matrix_world
			# obc_mw_nrm_g = obj_clone.matrix_world.inverted().transposed().to_3x3()
			# for vert in obj_clone.data.vertices:
			# 	vIdx = vert.index
			# 	attr_fmomco.data[vIdx].vector = obc_mw @ vert.co
			# 	attr_fmomnrm.data[vIdx].vector = obc_mw_nrm_g @ vert.normal
			# if ovl_obj is None:
			# 	wla_do.select_and_change_mode(camera_obj, 'OBJECT')
			# 	bpy.ops.mesh.primitive_plane_add(size=0.1, align='WORLD', enter_editmode=False, location=Vector((0,0,-kWPL_CutP_WriwDistance)))
			# 	ovl_obj = wla.active_object()
			# 	ovl_obj.name = ovl_name
			# 	ovl_obj.data.name = ovl_name + "_cutmesh"
			# 	wla_do.link_object_to_scene(ovl_obj, helpers_obj, 1)
			# 	wla_do.set_object_noShadow(ovl_obj, False, False) # no shadow, but renderable
			# 	# ovl_obj.show_in_front = True # xray
			# 	wla_do.select_and_change_mode(ovl_obj, 'EDIT')
			# 	context.tool_settings.mesh_select_mode = (True, False, False) # 'VERT'
			# 	bpy.ops.mesh.select_all(action='SELECT')
			# 	bpy.ops.mesh.delete(type='VERT')
			# 	# # since camera may rotate and overlay SHOULD NOT rotate with camera - constraining overlay to target root
			# 	# obj_root = wla.object_sceneroot(active_obj)
			# 	# ovl_obj.matrix_world = obj_root.matrix_world
			# 	# print("- overlay: constraining to", obj_root.name)
			# 	# copyRotCon = ovl_obj.constraints.new('COPY_TRANSFORMS')
			# 	# copyRotCon.target = obj_root
			# ovl_obj.hide_viewport = False
			# wla_do.select_and_change_mode(ovl_obj, 'OBJECT')
			# # wla_attr.attr3v_obj_ensure(ovl_obj, kWPL_ATTR_FMOMCO)
			# # wla_attr.attr3v_obj_ensure(ovl_obj, kWPL_ATTR_FMOMNRM)
			# # merging to per-frame overlayed mesh
			# bpy.ops.object.select_all(action='DESELECT')
			# obj_clone.select_set(True)
			# ovl_obj.select_set(True)
			# wla_do.set_active_object(ovl_obj)
			# bpy.ops.object.join()
			# #bpy.data.objects.remove(obj_clone, do_unlink=True)
			# obj_clone = None # deleted by join
			okCnt = okCnt+1
		self.report({'INFO'}, "Alt-UV base added: "+ovl_name+", objs:"+str(okCnt))
		return {'FINISHED'}

class wplbind_auto_foldbase_verf(bpy.types.Operator):
	bl_idname = "object.wplbind_auto_foldbase_verf"
	bl_label = "Add folding version"
	bl_options = {'REGISTER', 'UNDO'}

	opt_matReplace : StringProperty(
		name = "Replace Materials",
		default = ""
	)

	def execute( self, context ):
		active_obj = wla.active_object()
		if active_obj is None:
			self.report({'ERROR'}, "Folding: select object first")
			return {'FINISHED'}
		c_scene = bpy.context.scene
		c_scene.cycles.preview_samples = 5 # for Folds preview
		obj_vers, _, _ = wla.sys_objdata_versions(active_obj)
		if (len(obj_vers) > 0) and wla.isTokenInStr(config.kWPLRQueueBindPostfix, obj_vers[-1]) == True:
			bpy.ops.object.wplheal_meshversion(opt_switchTo = obj_vers[-1])
			self.report({'INFO'}, "Switched to folding version")
			return {'FINISHED'}
		if wla.isTokenInStr(config.kWPLRQueueBindPostfix, active_obj.name):
			self.report({'INFO'}, "Folding: object already RQ-tagged, no folding base possible")
			return {'FINISHED'}
		if (len(obj_vers) == 0) or wla.isTokenInStr(config.kWPLRQueueBindPostfix, obj_vers[-1]) == False:
			# adding version and renaming - folding postfix
			wla_do.select_and_change_mode(active_obj,"OBJECT")
			bpy.ops.object.wplheal_meshversion(opt_switchTo = "")
			obj_vers,_,_ = wla.sys_objdata_versions(active_obj)
			if (len(obj_vers) == 0):
				self.report({'ERROR'}, "Folding: failed to add version")
				return {'FINISHED'}
			obj_dat = wla.sys_objdata_by_name(active_obj, obj_vers[-1])
			obj_dat.name = obj_dat.name + config.kWPLRQueueBindPostfix[-1]
			if len(self.opt_matReplace) > 0:
				mt_name = wla_attr.mat_find_any(self.opt_matReplace)
				if mt_name is not None:
					mt = bpy.data.materials.get(mt_name)
					print("- replacing materials", mt)
					for i, slt in enumerate(active_obj.material_slots):
						slt.material = mt
			# switching with all the bells and whistles
			bpy.ops.object.wplheal_meshversion(opt_switchTo = obj_dat.name)
			self.report({'INFO'}, "Folding version added: "+obj_dat.name)
			return {'FINISHED'}
		self.report({'INFO'}, "Folding: nothing to do")
		return {'FINISHED'}

# ==========================================
# ==========================================

class WPL_PT_BindPanel(bpy.types.Panel):
	bl_idname = "WPL_PT_BindPanel"
	bl_label = "Prop tools"
	bl_space_type = 'VIEW_3D'
	bl_region_type = 'UI'
	bl_category = "OBJ"

	def draw(self, context):
		layout = self.layout
		active_obj = wla.active_object()
		col = layout.column()
		box3 = col.box()
		row1 = box3.row()
		row1.operator("object.wplheal_tweakobj", icon="FILE_REFRESH", text="AutoSetup objects").opt_actionType = 'AUTOSETUPOBJ'
		row1.operator("object.wplheal_tweakobj", icon="FILE_REFRESH", text='Smooth shading').opt_actionType = 'SPLITSMOOTH'
		row1 = box3.row(align=True)
		finMirr = row1.operator("object.wplbind_apply_transf", text="[-] Cons/Mirr") # and mirror
		finMirr.opt_applyConstrs = True
		finMirr.opt_applyMirror = True
		finMirr.opt_applyArmat = False
		finMirr.opt_applyHooks = False
		finMirr.opt_applyShrinks = False
		finMirr.opt_applySubd = False
		finMirr.opt_makeVersion = False
		finSubd = row1.operator("object.wplbind_apply_transf", text="[-] Subdiv")
		finSubd.opt_applyConstrs = False
		finSubd.opt_applyMirror = False
		finSubd.opt_applyArmat = False
		finSubd.opt_applyHooks = False
		finSubd.opt_applyShrinks = False
		finSubd.opt_applySubd = True
		finSubd.opt_makeVersion = False
		row1 = box3.row()
		row1.operator("object.wplbind_apply_vgscript", text="Apply vgScript", icon='PARTICLEMODE')
		row1.operator("mesh.wpldeform_force_xmirr", text='Smart XMirror', icon='MOD_MIRROR')

		box3.separator()
		box3.operator("object.wpldeform_objlattice", text = 'Add ObjLattice').opt_mode = 'LATT'
		wpl_deformOpts = context.scene.wpl_deformOpts
		box3.prop_search(wpl_deformOpts, "bind_targ", context.scene, "objects", icon="SNAP_NORMAL")
		box3.operator("mesh.wpldeform_bindmodf", text="Bind surf/lattice/etc")
		if (active_obj is not None) and (active_obj.type in (wla_meshwrap.kWPLMESHWRAP_TYPES+['ARMATURE'])):
			col.separator()
			box3 = col.box()
			obj_vers, _, _ = wla.sys_objdata_versions(active_obj)
			#print("- obj version:", active_obj.name, obj_vers, nms_next)
			# curver = None
			# for nm in obj_vers:
			# 	if nm == active_obj.data.name:
			# 		curver = nm
			# if curver is not None:
			# 	box3.operator("object.wplheal_meshversion", text="VEIL: Pin ["+curver+"]", icon="SNAP_NORMAL").opt_switchTo = "VEIL:"+curver
			for nm in obj_vers:
				if nm == active_obj.data.name:
					row = box3.row()
					spl = row.split(align=True, factor=0.8)
					spl.column().operator("object.wplheal_meshversion", text="[ "+nm+" ]").opt_switchTo = nm
					spl.column().operator("object.wplheal_meshversion", text="***").opt_switchTo = "FIN:"+nm
				else:
					row = box3.row()
					spl = row.split(align=True, factor=0.8)
					spl.column().operator("object.wplheal_meshversion", text=nm).opt_switchTo = nm
					spl.column().operator("object.wplheal_meshversion", text="(del)").opt_switchTo = "DEL:"+nm
			if config.kWPLMatTokenWPV in active_obj.name:
				box3.operator("object.wplheal_meshversion", text="*** PROBLEM: Name Ambiguity ***", icon='APPEND_BLEND').opt_switchTo = ""
			else:
				box3.operator("object.wplheal_meshversion", text="MESH: Make version", icon='APPEND_BLEND').opt_switchTo = ""

# ==========================================
# ==========================================

classes = (
	WPL_PT_BindPanel,
	
	#wplbind_bind2surf,
	#wplbind_align2surf,
	wplbind_apply_transf,
	wplbind_maskout,
	#wplbind_auto_veil,
	wplbind_auto_uvbase_syse,
	wplbind_auto_foldbase_verf,

	wplbind_apply_vgbind,
	wplbind_apply_vgscript,
)

def register():
	for cls in classes:
		bpy.utils.register_class(cls)

def unregister():
	for cls in reversed(classes):
		bpy.utils.unregister_class(cls)

if __name__ == "__main__":
	register()