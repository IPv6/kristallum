# *** Blender ***
# _empty280 as "Startup file"
# BL settings:
# // Resets each new version on Blender
# Preferences: Interface: Python tooltips
# Preferences: Interface: Developer Extras
# Preferences: Viewport: 3D Viewport Axis: OFF
# Preferences: Themes: Node editor: Frame node: gray, not black
# Preferences: Navigation: Orbit method: Trackball
# Preferences: Navigation: Orbit around selection: ON
# Preferences: Navigation: Auto Perspective: ON, Auto Depth: ON
# Preferences: Navigation: Zoom to mouse position: ON
# Preferences: Keymap: Select With Mouse Button: Left Click
# Preferences: Keymap: Spacebar action: Tools
# Preferences: Keymap: Middle Mouse Action: Pan
# Preferences: Keymap: 3D View: 3D View (Global): Set 3D Cursor: Surface Project: ON, Orientation: Geometry
# Preferences: Keymap: 3D View: Object mode: 3D View Tool Cursor: Set 3D Cursor: Surface Project: ON, Orientation: Geometry
# Preferences: Keymap: Search "Hide Collection": Disable for 1,2...9,0
# Preferences: Save & Load: Auto Run Python Scripts // for Drivers to work
# Preferences: Save & Load: Compress Files: OFF // ON as default after 3.3?
# Preferences: Experimental: Asset indexing OFF
# Preferences: Viewport: Subdivision: GPU Subdivision OFF
# Q-Menu (Favourites):
# - GRAB rotation && GRAB 2active
# Addons: Looptools
# - Tab Category: 'Sculpt' # == bl_category
# Addons: Node Wrangler
# Addons: F2 (F extensions)
# Addons: Mira (WPL fork)
# Addons: Quadremesher ($)
# FTT:
# - Addons: IconViewer, MeasureIt
# - Addons: Snap_Utilities_line, Edit Mesh Tools
# - Addons: WPL forks (GP helpers, etc)
# - Addons: FaceCutter ($)
# Slow GPU/CPU extras:
# - https://vk.com/topic-134845799_48174068?post=3397
# - Preferences: Viewport: Antialisasing: OFF
# FFR: ensureSceneDefauts, setups for brushes, etc

# CG/SPRITE proto Importants:
# - ensureSceneDefauts/ensureWorkspDefauts
# - World shader: Strength == 0

# *** VsCode ***
# Addon: Gruntfuggly.todo-tree
# Addon: JacquesLucke.blender-development
# Addon: nadako.vshaxe
# Settings: Import/merge vscode-settings.json
# - breadcrumbs: sorting order: name
# - '*.tbd' -> Dart files

# Primary VC/UV
# must be used in zzz_Clear for indirect uses!!!
kWPLMeshColVC = "DecorC"
kWPLMeshColPVC = "DecorP"
kWPLMeshColLVC = "DecorL"
kWPLMeshColDVC = "DecorD"
kWPLMeshWriVC = "Wri"
kWPLGridUV = "Grid"
# also: Grid_DirU
# also: Grid_curvlen
# also: Grid_ALT
kWPLIslandsVC = "Islands"
# also: Islands_ZM
# * Islands_ZM - допинфа по исландам (макс-дистанция и мин-дистанция)
# ** camera-dependent!!! использование одного объекта с разных ракурсов может привести к проблемам
# ** мин-дистанция критична для нормального разблюра цветобазы под эджинг
# also gnPtCo gnPtNrm for FMOM
# also pff_* for PFF
# also gn* for engraveGN, 
# also gnGradients for eyes, lips, grass
kWPLEBoneFlowUV = "FlatNormal"

kWPLNodePrefix = "#"
kWPLMatTokenWPV = '_v'
kWPLMatTokenDedup = '.'
kWPLMatTokenLocal = 'local_'
kWPLMatTokenSVG = 'SVGMat'
kWPLAutoSetupCustomProp = "#opt:"
kWPLAutoSetupCustomPropCol = "#opt:col"
kWPLAutoSetupCustomPropVec = "#opt:vec"
kWPLAutoSetupCustomPropComm = "#opt:comment:"
kWPLFrameBindPostfix = "_##" # "_##1" "_##2"
kWPLFrameBindPostfixNo = "_##!"
kWPLRQueueBindPostfix = ["_#(A)", "_#(B)"] # RQ-A RQ-B
kWPLSystemNodeTagAovs = "#syslayers_aov:"
kWPLSystemNodeTagInject = "#inject:"
# kWPLSystemNodeTagObjId = "#obj_id:"
kWPLSystemNodeTagPFF = "#pff:"
kWPLSystemFinPrefix = "fin_"

kWPLSystemObjShapes = "zzz_shapes"
kWPLSystemObjMainHelpers = "zzz_helpers"
kWPLSystemObjSysEHelpers = "zzz_syse_hlp"
kWPLObjzRefToken = "zzz_ref"
kWPLObjWrapper = "wrapper"
kWPLObjFrameWrapper = "scene_"
kWPLObjFrameWrapperF0 = ["scene_f0", "scene_##0"] # frame/scene #0 SHOULD NOT be used for main render, all checks skipped
kWPLObjVgsSkinPostfix = "_#vgs_mesh" # as [_sysp], tracked for masks
kWPLObjVgsSewPostfix = "_#vgs_sew"
kWPLObjManSewPostfix = "_sews"
kWPLObjManPicksPostfix = "_picks"
kWPLUdiSysfToken = "_sysf"
kWPLUdiSyseToken = "_syse"
kWPLUdiSyspToken = "_sysp"
# kWPLUdiWriwToken = "_wriw"
# kWPLUdiWriwOvlToken = "_wriw_ovl"
# kWPLObjUvRefToken = "_uv_ref" # for Distance fields on "..._sysc_uv"
#kWPLUdiWriwMeshOffset = -400 # mesh data to be linked as Fold copy
#kWPLUdiSyscMeshOffset = -200 # mesh data to be linked as Veiled copy
kWPLUdiTrashMeshOffset = -100 # Z-level to hide from camera
kWPLUdiTrashMeshOffset2 = -10 # Z-level to hide from camera

kWPLSuppPffPrefix = "pff_"
kWPLSuppZZZPrefix = "zzz_"
kWPLSuppZZZZPrefix = "zzzz_"
kWPLSuppVGScriptToken = "#vgs"
kWPLSuppVGScriptRigids = "_rigids" # not used anymore, vgs-cp more useful
kWPLSuppVGScriptCutlin = "_cutline"
kWPLSuppVGNoMirror = "_nomirror"
kWPLSuppVGNoMirrorVG = "!mirror"
kWPLSuppVGHideMaskM = "_hidegeom_main"
kWPLSuppVGHideMaskV = "_hidegeom_secn"

kWPLObjEdgeToken = "_edges"
kWPLObjEdgeLinArtToken = "_gpLineart"
kWPLObjEdgeOutlToken = "_gpOutl"
kWPLObjEdgeFillsToken = "_gpFill"
kWPLObjCutpPostfix = "_cutplane"
kWPLObjDefrmPostfix = "_deform"
kWPLObjCharRefLoomis = "_loomis"
kWPLObjCharRefStickman = "_stickman"
kWPLObjCharBodyPostfix = "_charb"
kWPLObjCharHeadPostfix = "_charh"
kWPLObjCharHeadMainPostfix = "_head"
kWPLObjCharDressPostfix = "_dress,_garm"
kWPLObjCharHairsPostfix = "_hair"
kWPLObjCharFaceToken = ["face_","_face"]
kWPLObjCharFaceMouthToken = ["mouth_","_mouth"]
kWPLObjCharFaceEyesToken = ["eye_","_eye","eyes_","_eyes"]
kWPLObjProtoToken = ["_proto","proto_"]
kWPLObjStampToken = ["stamp_", "_stamp"] # pff brushes, randomizer sources, MT/Engrave patters
kWPLObjShapeToken = ["shape_", "_shape"]
kWPLSystemOslBgObj = ["bg_","_bg"]
kWPLObjShaperToken = ["shaper_", "_shaper", "asset_", "_asset", "item_","_item"] # as shape, but not for separate rooting, NON-renderable
kWPLSystemOslIncluded = ["_fg","fg_","_char"] # sysLayersM: only "_fg", "_bg", "_far" counts (on root)
kWPLSystemOslAssets = kWPLObjStampToken + kWPLObjShapeToken + kWPLObjShaperToken # Generaly may be rendered
kWPLSystemOslIgnored = ["zzz_","_zzz","_tmp","tmp_","sys_","_sys"] + kWPLSystemOslAssets + [kWPLObjCharRefLoomis, kWPLObjCharRefStickman, kWPLSuppPffPrefix, kWPLObjDefrmPostfix]
kWPLSystemOslNoBbox = kWPLSystemOslIgnored + ["far_", "_far", kWPLSuppZZZPrefix, kWPLSuppZZZZPrefix, kWPLObjVgsSkinPostfix, kWPLObjVgsSewPostfix, kWPLObjManSewPostfix] # +kWPLObjRingToken
kWPLSystemDBGToken = ["DBG:","dbg_"]

# baking constants
kWPLSystemMainColl = "zzzMain"
kWPLSystemSuppColl = "zzzSupport"
kWPLSystemFaceColl = "zzzFace"
kWPLSystemEdgeColl = "zzzEdge"
kWPLSystemRefsColl = "zzzRefs"
kWPLSystemPffColl = "zzzPFF"
kWPLSystemMainSun = "zzz_MainSun"
kWPLSystemMainCam = "zzz_MainCamera"
kWPLSystemPffCam = "zzz_PffCamera"
kWPLSystemDbgNum = "zzz_BuildNumber"
kWPLMatPlaceholder = 'zzz_Placeholder'
kWPLSystemMainWorld = "World"
kWPLSystemReestrToken = "Reestr"
kWPLSystemMainReestrObj = "zzz_MatReestr_sysLayers"

# sysLayersMain = Main + LightColl
kWPLLayerRenderPrefix = "sysLayers"
kWPLLayerRenderMain = "sysLayers_Main"
kWPLLayerRender_TEST_Step1 = "sysLayers_Main, sysLayersA, sysLayersB, sysLayersP, sysLayersM"
#kWPLLayerRender_ALPHA = "sysLayers_Main, sysLayersA, sysLayersB, sysLayersP, sysLayersD, sysLayersE, sysLayersM"
kWPLLayerRenderPrecreate = [kWPLLayerRenderMain, "sysLayersA", "sysLayersB", "sysLayersC", "sysLayersD", "sysLayersE", "sysLayersM", "sysLayersF", "sysLayersP"]
kWPLLayerRenderDefaultColls = [kWPLSystemMainColl, "_fg", "fg_", "_frame", "frame_", "_scene", "scene_"] + kWPLSystemOslBgObj # Coll name tokens
kWPLLayerRenderDefRefsColls = kWPLLayerRenderDefaultColls + [kWPLSystemRefsColl]
# Tags to relink objects to specific collections
kWPLLayerRenderCollLinkRules = {
	#"ALPHA:"+kWPLObjCharHeadPostfix: [kWPLSystemMainColl], # even un-proto-ed face parts required for alpha
	kWPLObjEdgeToken: [kWPLSystemEdgeColl],# gp/etc edges
	kWPLUdiSyseToken: [kWPLSystemEdgeColl],# altuv/altmesh/etc stuff
	kWPLUdiSysfToken: [kWPLSystemFaceColl], # wraps, patterns, etc
	kWPLObjCharFaceToken[0]: [kWPLSystemFaceColl], # char faces
	kWPLObjCharFaceToken[1]: [kWPLSystemFaceColl], # char faces
}
kWPLLayerRenderSetupRules = {
	"sysLayers_Main":		{"samples:RQ-A": 1.00, "factor:RQ-B":0.1, "colls": kWPLLayerRenderDefaultColls, "collsXt": ["zzzEmiMain"], "denoise": True },
	"sysLayers_Main_EmiA":	{"samples:RQ-A": 1.00, "factor:RQ-B":0.1, "colls": kWPLLayerRenderDefRefsColls, "collsXt": ["zzzEmiA"], "denoise": True },
	"sysLayers_Main_EmiB":	{"samples:RQ-A": 1.00, "factor:RQ-B":0.1, "colls": kWPLLayerRenderDefRefsColls, "collsXt": ["zzzEmiB"], "denoise": True },
	"sysLayers_Main_EmiC":	{"samples:RQ-A": 1.00, "factor:RQ-B":0.1, "colls": kWPLLayerRenderDefRefsColls, "collsXt": ["zzzEmiC"], "denoise": True },
	"sysLayersA":			{"samples:RQ-A": 0.00, "factor:RQ-B":1.0, "colls": kWPLLayerRenderDefRefsColls, "collsXt": []}, # no antialiasing (proper raycasts are set for OSL already)
	"sysLayersB":			{"samples:RQ-A": 0.00, "factor:RQ-B":1.0, "colls": kWPLLayerRenderDefRefsColls, "collsXt": []}, # no antialiasing (better skin shades are set for OSL already)
	"sysLayersC":			{"samples:RQ-A": 1.00, "factor:RQ-B":0.5, "colls": kWPLLayerRenderDefRefsColls, "collsXt": ["zzzEmiC"], "denoise": True },
	"sysLayersD":			{"samples:RQ-A": 0.00, "factor:RQ-B":1.0, "colls": kWPLLayerRenderDefRefsColls, "collsXt": []}, # no antialiasing (amust for Z-depths)
	"sysLayersE":			{"samples:RQ-A": 0.00, "factor:RQ-B":1.0, "colls": kWPLLayerRenderDefRefsColls, "collsXt": [kWPLSystemEdgeColl] }, # no antialiasing (UVZ/WRI)
	"sysLayersM":			{"samples:RQ-A": 0.00, "factor:RQ-B":1.0, "colls": kWPLLayerRenderDefRefsColls, "collsXt": []}, # no antialiasing (amust for Masks)
	"sysLayersP":			{"samples:RQ-A": 0.05, "factor:RQ-B":0.5, "colls": kWPLLayerRenderDefRefsColls, "collsXt": []},
	"sysLayersF":			{"samples:RQ-A": 0.05, "factor:RQ-B":0.5, "colls": [kWPLSystemRefsColl],        "collsXt": [kWPLSystemFaceColl] },
	"sysLayersT_FgFolds":	{"samples:RQ-A": 0.50, "factor:RQ-B":1.0, "colls": kWPLLayerRenderDefRefsColls, "collsXt": ["zzzEmiC"], "denoise": True },
	"sysLayersT_BgEdge":	{"samples:RQ-A": 0.05, "factor:RQ-B":1.0, "colls": kWPLLayerRenderDefRefsColls, "collsXt": []},
	"sysLayersT_BgReflect":	{"samples:RQ-A": 0.01, "factor:RQ-B":1.0, "colls": kWPLLayerRenderDefRefsColls, "collsXt": []},
	"sysLayersT_RefEmi":	{"samples:RQ-A": 0.00, "factor:RQ-B":0.1, "colls": kWPLLayerRenderDefRefsColls, "collsXt": []}, # no antialiasing (pure OSL raycasts for smoothing already. zzz_ref1/etc -> zzzEmiA/etc)
	"sysLayersT_RefSheenUV":{"samples:RQ-A": 0.01, "factor:RQ-B":1.0, "colls": kWPLLayerRenderDefRefsColls, "collsXt": []},
	"sysLayersT_RefAreaUV":	{"samples:RQ-A": 0.01, "factor:RQ-B":1.0, "colls": kWPLLayerRenderDefRefsColls, "collsXt": []},
	"sysLayersT_RefGlossUV":{"samples:RQ-A": 0.01, "factor:RQ-B":1.0, "colls": kWPLLayerRenderDefRefsColls, "collsXt": []},
	"sysLayersT_RefRIMs":	{"samples:RQ-A": 0.01, "factor:RQ-B":1.0, "colls": kWPLLayerRenderDefRefsColls, "collsXt": []},
	"sysLayersT_RefCast":	{"samples:RQ-A": 0.01, "factor:RQ-B":1.0, "colls": kWPLLayerRenderDefRefsColls, "collsXt": []},
	"sysLayersT_DecLines":	{"samples:RQ-A": 0.01, "factor:RQ-B":1.0, "colls": kWPLLayerRenderDefRefsColls, "collsXt": []},
	"sysLayersT_DecAmber":	{"samples:RQ-A": 0.05, "factor:RQ-B":1.0, "colls": kWPLLayerRenderDefRefsColls, "collsXt": []},
	"sysLayersT_DecCrystal":{"samples:RQ-A": 0.05, "factor:RQ-B":1.0, "colls": kWPLLayerRenderDefRefsColls, "collsXt": []},
} 
kWPLLayerRenderModeRules = {
	"TEST": {
		"renderPercentage": 50,
		"samples": 50,
		"qual_mul": 0.1
	},
	"FINAL_CG": {
		"renderPercentage": 100,
		"samples": 50,
		"qual_mul": 1.0
	},
	"FINAL_BG": {
		"renderPercentage": 100,
		"samples": 50,
		"qual_mul": 1.0
	},
	# FINAL ONLY: tokens for specific features
	"_qNORM":	{"max_bounces": 2, "qual_mul": 5.0, "qual_finalType":"NORM"},
	"_qGOOD":	{"max_bounces": 2, "qual_mul": 15.0, "adapt": (0.001,50), "qual_finalType":"GOOD"},
	"_qULTRA":	{"max_bounces": 1, "qual_mul": 100.0, "adapt": (0.001,50), "qual_finalType":"ULTRA"},
}

kWPLComposMainNodeTag = "wplc_sysLayers_"
kWPLComposMainNodeChecks = "fin_,rl_,lA_,lB_,lD_,lE_,lP_,lM_"
#kWPLComposTrafarefToken = "Frame,ref_,_col,_edg,_alpha,_pre"
kWPLComposTrafarefLenToken = "_len"

kWPLCustomPropTagDebug = "#isdebug" # - mainSun
#kWPLCustomPropTagAlpha = "#isalpha" # - mainSun
kWPLCustomPropTagSunIsPoint = "#sun_ispoint" # - mainSun
kWPLCustomPropTagCyUnitScale = "#sys_unitscale" # - mainSun, scale factor for AO distances, etc, additionally to root-empties scale
kWPLVirtualPropTagFrameNum = "#sys_frame" # - virtual custom prop for use with driver getter
kWPLCustomPropTagFrameQueue = "#sys_queue" # - render queue, 0=="_#(A)", 1=="_#(B)"
kWPLVirtualPropTagObjDatas = ["location[0]","location[1]","location[2]","axis_x[0]","axis_x[1]","axis_x[2]","axis_y[0]","axis_y[1]","axis_y[2]","axis_z[0]","axis_z[1]","axis_z[2]","scale[0]","scale[1]","scale[2]"] # order must match implementation!!!
kWPLVirtualPropTagObjDatas = kWPLVirtualPropTagObjDatas + ["is_ortho","is_visible"]
# used CustomProp: #emi_scale_strength # - scale factor for mesh emission materials
# used CustomProp: #wrir_displace_len # - universal displace factor by vc-Wri-R
# used CustomProp: #wrir_displace_pow # - universal R-pow for vc-Wri-R. Default 100 -> no "leaking" after bevels/subdivs

# MatRemap rules (opt_objmatReplRules):
kWPLSystemMatReplaceSVGDef = kWPLMatTokenSVG+":matPlasticVC" # SVGMat
kWPLSystemMatReplaceDef = kWPLSystemMatReplaceSVGDef
kWPLSystemMatReplaceDef = kWPLSystemMatReplaceDef + "_btnA:matBetonVA,_btnB:matBetonVB,_btnC:matBetonVC,_btnD:matBetonVD,_btn:matBetonVA"
kWPLSystemMatReplaceDef = kWPLSystemMatReplaceDef + ",_mtlA:matMetalVA,_mtlB:matMetalVB,_mtlC:matMetalVC,_mtlD:matMetalVD,_mtl:matMetalVA"
kWPLSystemMatReplaceDef = kWPLSystemMatReplaceDef + ",_plsA:matPlasticVA,_plsB:matPlasticVB,_plsC:matPlasticVC,_plsD:matPlasticVD,_pls:matPlasticVA"
kWPLSystemMatReplaceDef = kWPLSystemMatReplaceDef + ",_gls:matGlass,_bush:BlobBush"
kWPLSystemMatReplaceDef = kWPLSystemMatReplaceDef + ",_emb:emiBlue,_emr:emiRed,_emg:emiGreen"
kWPLSystemMatReplaceDef = kWPLSystemMatReplaceDef + ",_emiB:emiBlue,_emiR:emiRed,_emiG:emiGreen"
kWPLSystemMatReplaceDef = kWPLSystemMatReplaceDef + ",*:matPlasticVA"

kWPLSystemOslScript = "sys_sceneQuery"
kWPLMeshDeformMod = "wpl_deform"
kWPLGKey_vercolCP = "vcCopyPaste"
kWPLSaveSelVGroup = "_sel"
kWPLTempOrien = "_TEMP"
kWPLTempMesh = "_TEMPMESH"

kWPLOslQueryMaxObjs = 500
kWPLOslQueryMaxName = 20
kWPLRaycastEpsilon = 0.0001
kWPLCoordPrecision = 10000.0
kWPLUVPrecision = 10000.0
kWPLVGSMinViableWeight = 0.1

kWPLPostFINALRenderExtractor = [
	"/Users/ipv6/Documents/zzz_CloudFiles/WPLabs19/_project/scripts/exr_extract.py",
	"c:\\_WPLabs\\BitBucket\\wplabs-19\\_project\\scripts\\exr_extract.py"
]

# ======================================================================================

class WPL_G:
	store = {}

def init():
	WPL_G.store = {}
	print("Config: initialization")

def isMaterialRenamed(node_name):
	import bpy
	from .tools import wla
	from .tools import wla_attr
	if node_name is None:
		return None
	node_base_name = node_name
	parts = node_base_name.rpartition(kWPLMatTokenDedup)
	if parts[2].isnumeric():
		node_base_name = parts[0]
	if wla.isTokenInStr(["headHair_", "headHair1", "headHair2", "headHair3", "headHair4", "headHair5", "headHair6"], node_base_name):
		return wla_attr.mat_find_any("_headHairsGN")
	if wla.isTokenInStr(["bodyWrap","LogoPT"], node_base_name):
		return wla_attr.mat_find_any("fg_bodyElem")
	if "GrassGround" in node_base_name:
		return wla_attr.mat_find_any("ani_matGroundGrass")
	if "SandGround" in node_base_name:
		return wla_attr.mat_find_any("ani_matGroundSand")
	if "SeaGround" in node_base_name:
		return wla_attr.mat_find_any("ani_matGroundSea")
	if "matGround_" in node_base_name:
		return wla_attr.mat_find_any("ani_matGroundForest")
	if "matSnow_" in node_base_name:
		return wla_attr.mat_find_any("ani_matGroundSnow")
	if "ani_2dTreeBlob" in node_base_name:
		return wla_attr.mat_find_any("ani_2dBlobTree")
	if "ani_2dBushBlob" in node_base_name:
		return wla_attr.mat_find_any("ani_2dBlobBush")
	if "ani_2dCloudBlobE_v09" in node_base_name:
		return wla_attr.mat_find_any("ani_2dBlobCloud")
	if "GrassGround" in node_base_name:
		return wla_attr.mat_find_any("ani_matGroundGrass")
	if "Signboard" in node_base_name:
		return wla_attr.mat_find_any("PlasticDU")
	if ("Asph" in node_base_name) or ("ani_matBetonDN" in node_base_name):
		return wla_attr.mat_find_any("BetonDU")
	if ("WrapVC" in node_base_name) or ("FurnWood" in node_base_name) or ("matWood" in node_base_name):
		return wla_attr.mat_find_any("PlasticVC")
	if ("#mat:" in node_base_name):
		return wla_attr.mat_find_any(node_base_name.replace("#mat:",""),"#mat")
	if bpy.data.materials.get(node_base_name) is None or ("zzz_" in node_base_name):
		# hard-fuzzy matching (for old imports)
		if "metal" in node_base_name.lower():
			return wla_attr.mat_find_any("MetalVA")
		if "plastic" in node_base_name.lower():
			return wla_attr.mat_find_any("PlasticVA")
		if "beton" in node_base_name.lower():
			return wla_attr.mat_find_any("BetonVA")
		if "cloth" in node_base_name.lower():
			return wla_attr.mat_find_any("ClothVA")
	# geomnodes
	if node_name == "wplg_inplace_shift2cam":
		return "wplg_inplace_shift2cam_v01"
	if node_name == "wplg_make_curvesField":
		return "wplg_make_curvesField_v01"
	if node_name == "wplg_inplace_curveDeform":
		return "wplg_inplace_curveDeform_v01"
	if node_name == "wplg_inplace_array1d_v1":
		return "wplg_inplace_array1d_v01"
	if node_name == "wplg_inplace_array2d_v1":
		return "wplg_inplace_array2d_v01"
	if node_name == "wplg_inplace_arrayClone":
		return "wplg_inplace_arrayClone_v01"
	return None

def performOneTimeUpgrades(obj):
	# # 291: New Subsurf option
	# md_subs = wla.modf_by_type(obj,'SUBSURF')
	# if md_subs is not None:
	# 	md_subs.boundary_smooth = 'PRESERVE_CORNERS'
	# 	md_subs.uv_smooth = 'NONE'
	# 	md_subs.use_creases = True
	return
