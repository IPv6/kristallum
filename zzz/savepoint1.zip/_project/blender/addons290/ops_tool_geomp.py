import os, sys, time, datetime
import math, copy, string, random
import numpy as np
import bpy, bmesh, mathutils

import bpy.types
from mathutils import Vector, Matrix, Euler, Quaternion
from mathutils.bvhtree import BVHTree
from mathutils.kdtree import KDTree
from bpy_extras import view3d_utils
from bpy.props import *
import gpu, bgl
from gpu_extras.presets import draw_circle_2d
from gpu_extras.batch import batch_for_shader

from . import config
from .tools import wla
from .tools import wla_do
from .tools import wla_bm
from .tools import wla_attr
from .tools import wla_vgbind

kWPL_GEP_GRID_COLOR_ORI = (0.8, 0.8, 0.8, 0.25)
kWPL_GEP_GRID_COLOR_CUR = (0.9, 0.9, 0.9, 0.5)
kWPL_GEP_GRID_COLOR_CUREX = (0.2, 0.8, 0.2, 0.7)
kWPL_GEP_GRID_SW_SIZE1PX = 3
kWPL_GEP_GRID_SW_SIZE2PX = 6
kWPL_GEP_GRID_DEFAULT_OFFS = (0.0,0.0,0.03)
kWPL_GEP_SNAPDOT_COLOR = (0.2, 0.2, 0.8, 1.0)
kWPL_GEP_SNAPDOT_SIZEPX = 10
kWPL_GEP_CIRCLE_VERTS = 16
kWPL_GEP_LINE_LSIZEPX = 5
kWPL_GEP_LINE_COLOR = (0.2, 0.8, 0.2, 1.0)
kWPL_GEP_TSIZES = [0.1, 0.25, 0.5, 1.0, 1.5, 2.0, 3.0, 4.0, 5.0]
kWPL_GEP_ORIENTS_ROTLOC = ['LOCAL_XY','LOCAL_XZ','LOCAL_YZ']
kWPL_GEP_ORIENTS_ROTCUR = ['CUR3D_XY','CUR3D_XZ','CUR3D_YZ']
#kWPL_GEP_ORIENTS_SUFR = ['SUFR_5','SUFR_11','SUFR_21','SUFR_LAST']
kWPL_GEP_ORIENTS_VIEWGR = ['VIEW_GRID_11','VIEW_GRID_11_ADD']
kWPL_GEP_MATLIST_MAXITEMS = 10

class GEOMP_C:
	isActive = 0
	target_obj_name = ''
	grid_center = Vector((0,0,0))
	grid_offset = kWPL_GEP_GRID_DEFAULT_OFFS
	grid_sufrace_cache = None
	last_mouse_pt_g = None
	last_added_dots = []
	grid_plane_cache = None
	undo_steps = []

def get_draw_plane(context, scene_pt_g):
	# returns (CenterG, ForwardG,RightG,UpG, GridSize)
	axis_c = None
	axis_x = None
	axis_y = None
	axis_z = None
	if GEOMP_C.grid_sufrace_cache is not None:
		if scene_pt_g is not None:
			# getting closest point from cloud
			bake_verts = GEOMP_C.grid_sufrace_cache["verts"]
			#bake_gridarr = GEOMP_C.grid_sufrace_cache["gridarr"]
			b_pt_idx, b_pt_co = surface_cache_find_closest(scene_pt_g, None)
			#print("- get_draw_plane: closest", b_pt_idx)
			if b_pt_co is not None:
				axis_c = b_pt_co
				bv = bake_verts[b_pt_idx]
				axis_z = bv[1]
				axis_x = bv[2]
				axis_y = axis_z.cross(axis_x)
				#bv_xy = bv[3]
				# # side point on x
				# bv_line = bake_gridarr[bv_xy[1]]
				# checkNext = True
				# if bv_xy[0] > 0:
				# 	b_pt_idx_r = bv_line[bv_xy[0]-1]
				# 	if b_pt_idx_r in bake_verts:
				# 		checkNext = False
				# 		bv_r = bake_verts[b_pt_idx_r]
				# 		bv_r_co = bv_r[0]
				# 		axis_x = (bv_r_co-axis_c).normalized()
				# 		axis_y = axis_z.cross(axis_x)
				# if checkNext and bv_xy[0]+1 < len(bv_line):
				# 	b_pt_idx_l = bv_line[bv_xy[0]+1]
				# 	if b_pt_idx_l in bake_verts:
				# 		bv_l = bake_verts[b_pt_idx_l]
				# 		bv_l_co = bv_l[0]
				# 		axis_x = (axis_c-bv_l_co).normalized()
				# 		axis_y = axis_z.cross(axis_x)
		return (axis_c, axis_x, axis_y, axis_z)
	if GEOMP_C.grid_plane_cache is not None:
		return GEOMP_C.grid_plane_cache
	wpl_geompOpts = context.scene.wpl_geompOpts
	axis_c = GEOMP_C.grid_center
	if wpl_geompOpts.opt_gridorient in kWPL_GEP_ORIENTS_ROTLOC:
		# LOCAL_XY, default, Z is UP. Normalization is AMUST
		mw = Matrix.Identity(4)
		active_obj = wla.object_by_name(GEOMP_C.target_obj_name)
		if active_obj is not None:
			mw = active_obj.matrix_world
		mw_nrm_g = mw.inverted().transposed().to_3x3()
		axis_x = (mw_nrm_g @ Vector( (1,0,0) )).normalized()
		axis_y = (mw_nrm_g @ Vector( (0,1,0) )).normalized()
		axis_z = (mw_nrm_g @ Vector( (0,0,1) )).normalized()
		if wpl_geompOpts.opt_gridorient == 'LOCAL_XZ':
			# y is up
			tmp = axis_y
			axis_y = axis_z
			axis_z = tmp
		elif wpl_geompOpts.opt_gridorient == 'LOCAL_YZ':
			# x is up
			tmp = axis_x
			axis_x = axis_z
			axis_z = tmp
	if wpl_geompOpts.opt_gridorient in kWPL_GEP_ORIENTS_ROTCUR:
		mw = bpy.context.scene.cursor.matrix
		mw_nrm_g = mw.inverted().transposed().to_3x3()
		axis_x = (mw_nrm_g @ Vector( (1,0,0) )).normalized()
		axis_y = (mw_nrm_g @ Vector( (0,1,0) )).normalized()
		axis_z = (mw_nrm_g @ Vector( (0,0,1) )).normalized()
		if wpl_geompOpts.opt_gridorient == 'CUR3D_XZ':
			# y is up
			tmp = axis_y
			axis_y = axis_z
			axis_z = tmp
		elif wpl_geompOpts.opt_gridorient == 'CUR3D_YZ':
			# x is up
			tmp = axis_x
			axis_x = axis_z
			axis_z = tmp
	# orienting plane to camera
	region, _ = wla.active_view_region()
	regionZ_g = (region.view_rotation @ Vector((0.0, 0.0, 1.0)))
	#print("- viewZ", regionZ_g, "planeZ", axis_z, regionZ_g.dot(axis_z))
	if regionZ_g.dot(axis_z) < 0:
		axis_z = -1* axis_z
	GEOMP_C.grid_plane_cache = (axis_c, axis_x, axis_y, axis_z)
	return GEOMP_C.grid_plane_cache

def plane_pt_to_scene_pt(context, plane_pt):
	if GEOMP_C.grid_sufrace_cache is not None:
		bake_verts = GEOMP_C.grid_sufrace_cache["verts"]
		b_pt_idx = plane_pt[0]
		bv = bake_verts[b_pt_idx]
		pt = bv[0]
		return pt
	wpl_geompOpts = context.scene.wpl_geompOpts
	plane_tile = wpl_geompOpts.opt_gridsize
	plane_co, plane_x, plane_y, plane_z = get_draw_plane(context, None)
	pt = plane_co + plane_x*plane_pt[0]*plane_tile + plane_y*plane_pt[1]*plane_tile
	return pt

def scene_pt_to_plane_pt(context, scene_pt_g):
	if GEOMP_C.grid_sufrace_cache is not None:
		b_pt_idx, b_pt_co = surface_cache_find_closest(scene_pt_g, None)
		if b_pt_co is not None:
			return (b_pt_co, (b_pt_idx,0,0) )
		return None, None
	wpl_geompOpts = context.scene.wpl_geompOpts
	plane_tile = wpl_geompOpts.opt_gridsize
	plane_co, plane_x, plane_y, plane_z = get_draw_plane(context, None)
	plane_mw = wla.math_matrix4axis(plane_co, plane_x, plane_y, plane_z, 0)
	sltest = plane_mw.inverted() @ (scene_pt_g)
	scene_pt_local = plane_mw.inverted() @ (scene_pt_g + plane_x*math.copysign(plane_tile*0.5, sltest[0]) + plane_y*math.copysign(plane_tile*0.5, sltest[1]))
	plane_pt = ( int(scene_pt_local[0]/plane_tile), int(scene_pt_local[1]/plane_tile), int(scene_pt_local[2]/plane_tile) )
	scene_pt_g_snapped = plane_co + plane_x*plane_pt[0]*plane_tile + plane_y*plane_pt[1]*plane_tile + plane_z*plane_pt[2]*plane_tile
	return (scene_pt_g_snapped, plane_pt)

def surface_cache_find_closest(pt_start, pt_end):
	# can not use KDTree since point-line
	#bake_tree = GEOMP_C.grid_sufrace_cache["tree"]
	#b_pt_co, b_pt_idx, _ = bake_tree.find(scene_pt_g)
	# bruteforcing closest via distance to view line if pt_end set
	min_dist = 999
	min_dist_co = None
	min_dist_tvIdx = None
	bake_verts = GEOMP_C.grid_sufrace_cache["verts"]
	for tvIdx in bake_verts:
		bv = bake_verts[tvIdx]
		bv_co = bv[0]
		if pt_end is not None:
			proj_pr,_ = mathutils.geometry.intersect_point_line(bv_co, pt_start, pt_start+pt_end*10000)
			proj_dst = (proj_pr-bv_co).length
		else:
			proj_dst = (pt_start-bv_co).length
		if proj_dst < min_dist:
			min_dist = proj_dst
			min_dist_co = bv_co
			min_dist_tvIdx = tvIdx
	return min_dist_tvIdx, min_dist_co

def region_2d_to_scene_pt(context, co_2d):
	# https://blender.stackexchange.com/questions/150645/projection-of-point-on-plane
	# mira tools get_mouse_on_plane
	view_vec = view3d_utils.region_2d_to_vector_3d(context.region, context.space_data.region_3d, co_2d)
	#view_point = view3d_utils.region_2d_to_origin_3d(context.region, context.space_data.region_3d, co_2d)
	view_point = view3d_utils.region_2d_to_location_3d(context.region, context.space_data.region_3d, co_2d, view_vec)
	if GEOMP_C.grid_sufrace_cache is not None:
		#print("- casting", view_point, view_vec, context.space_data.region_3d.view_perspective)
		# if context.space_data.region_3d.view_perspective == 'ORTHO' or (context.space_data.region_3d.view_perspective == 'CAMERA' and context.space_data.region_3d.camera.data.type == 'ORTHO'):
		# 	view_point -= 1000 * view_vec
		_, closest_co = surface_cache_find_closest(view_point, view_point+view_vec*10000)
		return closest_co
	plane_co, _, _, plane_no = get_draw_plane(context, None)
	hit_co = mathutils.geometry.intersect_line_plane(view_point, view_point+view_vec*10000, plane_co, plane_no, False)
	if hit_co is not None:
		return hit_co
	return None

# ===============

def geomp_draw_callback2_px(self, context):
	if context.area != self.current_area:
		return
	if GEOMP_C.last_mouse_pt_g is None:
		return
	wpl_geompOpts = context.scene.wpl_geompOpts
	plane_tile = wpl_geompOpts.opt_gridsize
	pt_3d_snapped, pt_2d_local = scene_pt_to_plane_pt(context, GEOMP_C.last_mouse_pt_g)
	if pt_3d_snapped is None:
		return
	bgl.glEnable(bgl.GL_BLEND) # alpha support
	visible_tiles = max(3, int(wpl_geompOpts.opt_gridcells))
	visible_tiles_half = max(3, int(visible_tiles*0.5) )
	if GEOMP_C.grid_sufrace_cache is None:
		plane_co, plane_x, plane_y, _ = get_draw_plane(context, None)
		# grid xy around cursor
		grid_pts1 = []
		grid_pts1_extras = []
		for gi in range(0,visible_tiles_half):
			pt1y1 = pt_3d_snapped - plane_x*visible_tiles_half*plane_tile + plane_y*gi*plane_tile
			pt2y1 = pt_3d_snapped + plane_x*visible_tiles_half*plane_tile + plane_y*gi*plane_tile
			pt1y2 = pt_3d_snapped - plane_x*visible_tiles_half*plane_tile - plane_y*gi*plane_tile
			pt2y2 = pt_3d_snapped + plane_x*visible_tiles_half*plane_tile - plane_y*gi*plane_tile
			pt1x1 = pt_3d_snapped - plane_y*visible_tiles_half*plane_tile + plane_x*gi*plane_tile
			pt2x1 = pt_3d_snapped + plane_y*visible_tiles_half*plane_tile + plane_x*gi*plane_tile
			pt1x2 = pt_3d_snapped - plane_y*visible_tiles_half*plane_tile - plane_x*gi*plane_tile
			pt2x2 = pt_3d_snapped + plane_y*visible_tiles_half*plane_tile - plane_x*gi*plane_tile
			isX1_extra=False
			isX2_extra=False
			isY1_extra=False
			isY2_extra=False
			if len(GEOMP_C.last_added_dots) >= 0:
				for dot2d3d in GEOMP_C.last_added_dots:
					if int(dot2d3d[0][0]) == int(pt_2d_local[0]+gi):
						isX1_extra = True
					if int(dot2d3d[0][0]) == int(pt_2d_local[0]-gi):
						isX2_extra = True
					if int(dot2d3d[0][1]) == int(pt_2d_local[1]+gi):
						isY1_extra = True
					if int(dot2d3d[0][1]) == int(pt_2d_local[1]-gi):
						isY2_extra = True
			if isY1_extra:
				grid_pts1_extras = grid_pts1_extras+[ (pt1y1[0],pt1y1[1],pt1y1[2]), (pt2y1[0],pt2y1[1],pt2y1[2])]
			else:
				grid_pts1 = grid_pts1+[ (pt1y1[0],pt1y1[1],pt1y1[2]), (pt2y1[0],pt2y1[1],pt2y1[2])]
			if isY2_extra:
				grid_pts1_extras = grid_pts1_extras+[ (pt1y2[0],pt1y2[1],pt1y2[2]), (pt2y2[0],pt2y2[1],pt2y2[2])]
			else:
				grid_pts1 = grid_pts1+[ (pt1y2[0],pt1y2[1],pt1y2[2]), (pt2y2[0],pt2y2[1],pt2y2[2])]
			if isX1_extra:
				grid_pts1_extras = grid_pts1_extras+[ (pt1x1[0],pt1x1[1],pt1x1[2]), (pt2x1[0],pt2x1[1],pt2x1[2])]
			else:
				grid_pts1 = grid_pts1+[ (pt1x1[0],pt1x1[1],pt1x1[2]), (pt2x1[0],pt2x1[1],pt2x1[2])]
			if isX2_extra:
				grid_pts1_extras = grid_pts1_extras+[ (pt1x2[0],pt1x2[1],pt1x2[2]), (pt2x2[0],pt2x2[1],pt2x2[2])]
			else:
				grid_pts1 = grid_pts1+[ (pt1x2[0],pt1x2[1],pt1x2[2]), (pt2x2[0],pt2x2[1],pt2x2[2])]
		# grid xy around origin
		grid_pts2 = []
		
		for gi in range(0,visible_tiles):
			pt1 = plane_co - plane_x*visible_tiles*plane_tile + plane_y*gi*plane_tile
			pt2 = plane_co + plane_x*visible_tiles*plane_tile + plane_y*gi*plane_tile
			grid_pts2 = grid_pts2+[ (pt1[0],pt1[1],pt1[2]), (pt2[0],pt2[1],pt2[2])]
			pt1 = plane_co - plane_x*visible_tiles*plane_tile - plane_y*gi*plane_tile
			pt2 = plane_co + plane_x*visible_tiles*plane_tile - plane_y*gi*plane_tile
			grid_pts2 = grid_pts2+[ (pt1[0],pt1[1],pt1[2]), (pt2[0],pt2[1],pt2[2])]
			pt1 = plane_co - plane_y*visible_tiles*plane_tile + plane_x*gi*plane_tile
			pt2 = plane_co + plane_y*visible_tiles*plane_tile + plane_x*gi*plane_tile
			grid_pts2 = grid_pts2+[ (pt1[0],pt1[1],pt1[2]), (pt2[0],pt2[1],pt2[2])]
			pt1 = plane_co - plane_y*visible_tiles*plane_tile - plane_x*gi*plane_tile
			pt2 = plane_co + plane_y*visible_tiles*plane_tile - plane_x*gi*plane_tile
			grid_pts2 = grid_pts2+[ (pt1[0],pt1[1],pt1[2]), (pt2[0],pt2[1],pt2[2])]
		#print("- grid_pts", grid_pts)
		bgl.glLineWidth(2)
		batch = batch_for_shader(self.shader_3du, 'LINES', {"pos": grid_pts2})
		self.shader_3du.bind()
		self.shader_3du.uniform_float("color", kWPL_GEP_GRID_COLOR_ORI)
		batch.draw(self.shader_3du)
		if len(grid_pts1)>0:
			batch = batch_for_shader(self.shader_3du, 'LINES', {"pos": grid_pts1})
			self.shader_3du.bind()
			self.shader_3du.uniform_float("color", kWPL_GEP_GRID_COLOR_CUR)
			batch.draw(self.shader_3du)
		if len(grid_pts1_extras)>0:
			bgl.glLineWidth(3)
			batch = batch_for_shader(self.shader_3du, 'LINES', {"pos": grid_pts1_extras})
			self.shader_3du.bind()
			self.shader_3du.uniform_float("color", kWPL_GEP_GRID_COLOR_CUREX)
			batch.draw(self.shader_3du)
	if GEOMP_C.grid_sufrace_cache is not None:
		bake_verts = GEOMP_C.grid_sufrace_cache["verts"]
		# point cloud
		pts1 = []
		pts1_col = []
		pts2 = []
		pts2_col = []
		for tvIdx in bake_verts:
			bv = bake_verts[tvIdx]
			bv_co = Vector(bv[0])
			if (pt_3d_snapped - bv_co).length > plane_tile*3:
				pts1.append( bv_co )
				pts1_col.append(kWPL_GEP_GRID_COLOR_CUR)
			else:
				pts2.append( bv_co )
				pts2_col.append(kWPL_GEP_GRID_COLOR_CUREX)
		if len(pts1) > 0:
			batch = batch_for_shader(self.shader_3du_flat, 'POINTS', {"pos": pts1, "color": pts1_col })
			self.shader_3du_flat.bind()
			bgl.glPointSize(kWPL_GEP_GRID_SW_SIZE1PX)
			batch.draw(self.shader_3du_flat)
		if len(pts2) > 0:
			batch = batch_for_shader(self.shader_3du_flat, 'POINTS', {"pos": pts2, "color": pts2_col })
			self.shader_3du_flat.bind()
			bgl.glPointSize(kWPL_GEP_GRID_SW_SIZE2PX)
			batch.draw(self.shader_3du_flat)
		# # lines
		# bake_gridarr = GEOMP_C.grid_sufrace_cache["gridarr"]
		# grid_pts = []
		# for bkline in bake_gridarr:
		# 	for i in range(0, len(bkline)-1):
		# 		tvIdx1 = bkline[i]
		# 		tvIdx2 = bkline[i+1]
		# 		if tvIdx1 in bake_verts and tvIdx2 in bake_verts:
		# 			bv1 = bake_verts[tvIdx1]
		# 			bv2 = bake_verts[tvIdx2]
		# 			pt1 = bv1[0]
		# 			pt2 = bv2[0]
		# 			grid_pts = grid_pts+[ (pt1[0],pt1[1],pt1[2]), (pt2[0],pt2[1],pt2[2])]
		# if len(grid_pts)>0:
		# 	batch = batch_for_shader(self.shader_3du, 'LINES', {"pos": grid_pts})
		# 	self.shader_3du.bind()
		# 	self.shader_3du.uniform_float("color", kWPL_GEP_GRID_COLOR_CUR)
		# 	batch.draw(self.shader_3du)
	# point under cursor
	pt_co = pt_3d_snapped
	batch = batch_for_shader(self.shader_3du_flat, 'POINTS', {"pos": [pt_co], "color": [kWPL_GEP_SNAPDOT_COLOR] })
	self.shader_3du_flat.bind()
	bgl.glPointSize(kWPL_GEP_SNAPDOT_SIZEPX)
	batch.draw(self.shader_3du_flat)

	# # DBG: mouse position no snapping
	# pt_co = GEOMP_C.last_mouse_pt_g
	# batch = batch_for_shader(self.shader_3du_flat, 'POINTS', {"pos": [pt_co], "color": [kWPL_GEP_LINE_COLOR] })
	# self.shader_3du_flat.bind()
	# bgl.glPointSize(kWPL_GEP_SNAPDOT_SIZEPX)
	# batch.draw(self.shader_3du_flat)

	if wpl_geompOpts.opt_tooltype == 'RECTF' or wpl_geompOpts.opt_tooltype == 'RECTS':
		if len(GEOMP_C.last_added_dots) >= 1:
			bgl.glLineWidth(kWPL_GEP_LINE_LSIZEPX)
			rect_pts = []
			pt1_2d = GEOMP_C.last_added_dots[0][0]
			pt2_2d = pt_2d_local #GEOMP_C.last_added_dots[1][0]
			pt1 = plane_pt_to_scene_pt(context, pt1_2d)
			pt2 = plane_pt_to_scene_pt(context, (pt2_2d[0], pt1_2d[1], pt1_2d[2]) )
			pt3 = plane_pt_to_scene_pt(context, pt2_2d)
			pt4 = plane_pt_to_scene_pt(context, (pt1_2d[0], pt2_2d[1], pt1_2d[2]) )
			rect_pts = rect_pts + [ (pt1[0],pt1[1],pt1[2]), (pt2[0],pt2[1],pt2[2]) ]
			rect_pts = rect_pts + [ (pt2[0],pt2[1],pt2[2]), (pt3[0],pt3[1],pt3[2]) ]
			rect_pts = rect_pts + [ (pt3[0],pt3[1],pt3[2]), (pt4[0],pt4[1],pt4[2]) ]
			rect_pts = rect_pts + [ (pt4[0],pt4[1],pt4[2]), (pt1[0],pt1[1],pt1[2]) ]
			batch = batch_for_shader(self.shader_3du, 'LINES', {"pos": rect_pts})
			self.shader_3du.bind()
			self.shader_3du.uniform_float("color", kWPL_GEP_LINE_COLOR)
			batch.draw(self.shader_3du)

	if wpl_geompOpts.opt_tooltype == 'LINE' or wpl_geompOpts.opt_tooltype == 'POLYG':
		if len(GEOMP_C.last_added_dots) >= 1:
			bgl.glLineWidth(kWPL_GEP_LINE_LSIZEPX)
			dots2d3d_tmp = copy.copy(GEOMP_C.last_added_dots)
			dots2d3d_tmp.append( (pt_2d_local, pt_3d_snapped) )
			if wpl_geompOpts.opt_tooltype == 'POLYG':
				dots2d3d_tmp.append(dots2d3d_tmp[0])
			rect_pts = []
			for i in range(0, len(dots2d3d_tmp)-1):
				pt1 = dots2d3d_tmp[i][1]
				pt2 = dots2d3d_tmp[i+1][1]
				#pt1 = plane_pt_to_scene_pt(context, pt1_2d)
				#pt2 = plane_pt_to_scene_pt(context, pt2_2d)
				rect_pts = rect_pts + [ (pt1[0],pt1[1],pt1[2]), (pt2[0],pt2[1],pt2[2]) ]
			batch = batch_for_shader(self.shader_3du, 'LINES', {"pos": rect_pts})
			self.shader_3du.bind()
			self.shader_3du.uniform_float("color", kWPL_GEP_LINE_COLOR)
			batch.draw(self.shader_3du)

	# DBG (POST_PIXEL required)
	# coords = [ (0,0), (100,100), (800,300) ]
	# batch = batch_for_shader(self.shader_2du, 'LINE_LOOP', {"pos": coords}) !!! LINE_LOOP deprecated
	# self.shader_2du.bind()
	# self.shader_2du.uniform_float("color", kWPL_GEP_GRID_COLOR)
	# batch.draw(self.shader_2du)

	bgl.glDisable(bgl.GL_BLEND)
	# restore defaults... Not needed anymore?
	#bgl.glPointSize(1)
	#bgl.glLineWidth(1)

# ================

class wplgeomp_modalflow(bpy.types.Operator):
	bl_idname = "mesh.wplgeomp_modalflow"
	bl_label = "Paint geometry on grid"
	bl_options = {'REGISTER', 'UNDO'}

	opt_action : EnumProperty(
		items = [
			('NONE', "None", ""),
			('START', "Start", ""),
			('STOP', "Stop", ""),
			('SET_SUBDEPTH_M25', "Sub-depth: -25%", ""),
			('SET_SUBDEPTH_ZER', "Sub-depth: 0%", ""),
			('SET_SUBDEPTH_P5', "Sub-depth: 5%", ""),
			('SET_SUBDEPTH_P25', "Sub-depth: 25%", ""),
			('SET_SUBDEPTH_P50', "Sub-depth: 50%", ""),
		],
		name="Action",
		default='NONE',
	)

	def invoke(self, context, event):
		wpl_geompOpts = context.scene.wpl_geompOpts
		GEOMP_C.grid_plane_cache = None
		if self.opt_action == 'SET_SUBDEPTH_M25':
			GEOMP_C.grid_offset = (0,0,-0.25)
			return {'FINISHED'}
		if self.opt_action == 'SET_SUBDEPTH_ZER':
			GEOMP_C.grid_offset = (0,0,0.0)
			return {'FINISHED'}
		if self.opt_action == 'SET_SUBDEPTH_P5':
			GEOMP_C.grid_offset = (0,0,0.05)
			return {'FINISHED'}
		if self.opt_action == 'SET_SUBDEPTH_P25':
			GEOMP_C.grid_offset = (0,0,0.25)
			return {'FINISHED'}
		if self.opt_action == 'SET_SUBDEPTH_P50':
			GEOMP_C.grid_offset = (0,0,0.50)
			return {'FINISHED'}
		if self.opt_action == 'STOP':
			GEOMP_C.isActive = 0
			return {'FINISHED'}
		active_obj = wla.active_object(['MESH'])
		if active_obj is None:
			self.report({'ERROR'}, "Select mesh object first")
			return {'FINISHED'}
		active_mesh = active_obj.data
		selvertsIdx = wla.selected_vertsIdx(active_mesh)
		if wla.is_edit_mode() == False:
			wla_do.select_and_change_mode(active_obj,'EDIT')
		if self.opt_action != 'START':
			return {'FINISHED'}
		mw = active_obj.matrix_world
		ao_mw_nrm_g = active_obj.matrix_world.inverted().transposed().to_3x3()
		GEOMP_C.target_obj_name = active_obj.name
		GEOMP_C.grid_center = wla.active_context_cursor()
		GEOMP_C.grid_offset = kWPL_GEP_GRID_DEFAULT_OFFS
		GEOMP_C.last_mouse_pt_g = None
		GEOMP_C.last_added_dots = []
		GEOMP_C.grid_plane_cache = None
		GEOMP_C.undo_steps = []
		wpl_geompOpts.opt_toolmat = wpl_geompOpts.opt_toolmat2
		if (wpl_geompOpts.opt_gridorient in kWPL_GEP_ORIENTS_VIEWGR):
			# need to prepare grid - from GEOMP_C.grid_center
			# "gridarr" can not be calculated - Grid-ADD non compatible
			max_vertidx = 0
			grid_sufrace_prev = GEOMP_C.grid_sufrace_cache
			if grid_sufrace_prev is not None:
				max_vertidx = grid_sufrace_prev["max_vertidx"]
			GEOMP_C.grid_sufrace_cache = {}
			depsgraph = bpy.context.evaluated_depsgraph_get()
			region, axisLoc_g = wla.active_view_region(GEOMP_C.grid_center)
			region_gOrtho = not region.is_perspective
			axisX_g = (region.view_rotation @ Vector((1.0, 0.0, 0.0))).normalized()
			axisY_g = (region.view_rotation @ Vector((0.0, 1.0, 0.0))).normalized()
			axisZ_g = ( axisLoc_g - GEOMP_C.grid_center).normalized()
			if region_gOrtho:
				axisZ_g = -1 * (region.view_rotation @ Vector((0.0, 0.0, 1.0))).normalized()
			scale_fac = 1.0
			bake_verts = {}
			for ss_x in range(-wpl_geompOpts.opt_gridcells, wpl_geompOpts.opt_gridcells+1):
				for ss_y in range(-wpl_geompOpts.opt_gridcells, wpl_geompOpts.opt_gridcells+1):
					castPt = axisLoc_g + axisX_g*float(ss_x)*wpl_geompOpts.opt_gridsize*scale_fac + axisY_g*float(ss_y)*wpl_geompOpts.opt_gridsize*scale_fac
					#_, castPt = wla.active_view_region(GEOMP_C.grid_center + axisX_g*float(ss_x)*wpl_geompOpts.opt_gridsize*scale_fac + axisY_g*float(ss_y)*wpl_geompOpts.opt_gridsize*scale_fac)
					ress, loc_g, normal_g, _, loc_obj, _ = depsgraph.scene_eval.ray_cast(depsgraph, castPt - 10*axisZ_g, 1*axisZ_g)
					# print("- cast", axisLoc_g, castPt, axisZ_g)
					# print("- res", ress, loc_g, normal_g, loc_obj)
					if ress:
						max_vertidx = max_vertidx+1
						vIdx_co = loc_g.copy() # mw @ ???
						vIdx_nrm = normal_g.normalized() #(ao_mw_nrm_g @ ???).normalized()
						vIdx_x = axisZ_g.cross(normal_g).normalized()
						bake_verts[max_vertidx] = [vIdx_co, vIdx_nrm, vIdx_x, max_vertidx]
			print("- scene-cast: points found", len(bake_verts))
			if wpl_geompOpts.opt_gridorient == 'VIEW_GRID_11_ADD' and grid_sufrace_prev is not None:
				for vIdx in grid_sufrace_prev["verts"].keys():
					bake_verts[vIdx] = grid_sufrace_prev["verts"][vIdx]
			GEOMP_C.grid_sufrace_cache["max_vertidx"] = max_vertidx
			GEOMP_C.grid_sufrace_cache["verts"] = bake_verts
			GEOMP_C.grid_sufrace_cache["gridcnt"] = Vector(GEOMP_C.grid_center)
		else:
			GEOMP_C.grid_sufrace_cache = None
		# if (wpl_geompOpts.opt_gridorient in kWPL_GEP_ORIENTS_SUFR):
		# 	if wpl_geompOpts.opt_gridorient == 'SUFR_LAST':
		# 		if GEOMP_C.grid_sufrace_cache is None:
		# 			self.report({'ERROR'}, "Last surface grid not found")
		# 			return {'FINISHED'}
		# 	else:
		# 		# need to prepare grid
		# 		bm = bmesh.from_edit_mesh(active_mesh)
		# 		bm.verts.ensure_lookup_table()
		# 		bm.verts.index_update()
		# 		tempUV = None
		# 		zero_vIdx = None
		# 		tempUV_grid = None
		# 		subd = 0
		# 		# # max edge len compared to grid size
		# 		# edg_max = 0
		# 		# for vIdx in selvertsIdx:
		# 		# 	v = bm.verts[vIdx]
		# 		# 	for e in v.link_edges:
		# 		# 		# elen = e.calc_length() #need world-len
		# 		# 		elen = ((mw @ v.co)-(mw @ e.other_vert(v).co)).length
		# 		# 		edg_max = max(edg_max, elen)
		# 		# if edg_max > wpl_geompOpts.opt_gridsize * 3:
		# 		# 	subd = 2
		# 		# elif edg_max > wpl_geompOpts.opt_gridsize:
		# 		# 	subd = 1
		# 		if wpl_geompOpts.opt_gridorient == 'SUFR_5':
		# 			tempUV, tempUV_grid, zero_vIdx = wla_vgbind.gm_generateUVGrid(bm, selvertsIdx, {"steps": 2, "subd": subd})
		# 		if wpl_geompOpts.opt_gridorient == 'SUFR_11':
		# 			tempUV, tempUV_grid, zero_vIdx = wla_vgbind.gm_generateUVGrid(bm, selvertsIdx, {"steps": 5, "subd": subd})
		# 		if wpl_geompOpts.opt_gridorient == 'SUFR_21':
		# 			tempUV, tempUV_grid, zero_vIdx = wla_vgbind.gm_generateUVGrid(bm, selvertsIdx, {"steps": 10, "subd": subd})
		# 		if (tempUV is None) or (zero_vIdx is None):
		# 			self.report({'ERROR'}, "Can not construct surface grid")
		# 			return {'CANCELLED'}
		# 		GEOMP_C.grid_sufrace_cache = {}
		# 		bake_verts = {}
		# 		#bake_tree = KDTree(len(tempUV)) # not really usefull...
		# 		for tvIdx in tempUV:
		# 			vIdx_co = mw @ tempUV[tvIdx][0]
		# 			vIdx_nrm = (ao_mw_nrm_g @ tempUV[tvIdx][1]).normalized()
		# 			vIdx_xy = tempUV[tvIdx][3]
		# 			vIdx_xyw = ( vIdx_xy[0], vIdx_xy[1], 0 )
		# 			bake_verts[tvIdx] = [vIdx_co, vIdx_nrm, ??? (x_axis needed), vIdx_xyw]
		# 			#bake_tree.insert(vIdx_co, tvIdx)
		# 		#bake_tree.balance()
		# 		#GEOMP_C.grid_sufrace_cache["tree"] = bake_tree
		# 		GEOMP_C.grid_sufrace_cache["verts"] = bake_verts
		# 		GEOMP_C.grid_sufrace_cache["gridarr"] = tempUV_grid
		# 		zero_v = bm.verts[zero_vIdx]
		# 		zero_vCo = Vector(zero_v.co)
		# 		GEOMP_C.grid_center = active_obj.matrix_world @ zero_vCo
		# 		GEOMP_C.grid_sufrace_cache["gridcnt"] = Vector(GEOMP_C.grid_center)
		# else:
		#	GEOMP_C.grid_sufrace_cache = None
		# if no errors (surfgrid is ok) - then active
		GEOMP_C.isActive = 1
		wla_do.select_and_change_mode(active_obj, 'OBJECT')
		wla_attr.vc_obj_ensure(active_obj, config.kWPLMeshColVC)
		wla_do.select_and_change_mode(active_obj, 'EDIT')
		bpy.ops.mesh.select_all(action='DESELECT')
		#self.shader_2du = gpu.shader.from_builtin('2D_UNIFORM_COLOR') #POST_PIXEL required
		self.shader_3du = gpu.shader.from_builtin('3D_UNIFORM_COLOR')
		self.shader_3du_flat = gpu.shader.from_builtin('3D_FLAT_COLOR')
		self.ob = context.object
		self.gp = self.ob.data
		self.refresh_trigger = {'MOUSEMOVE'}
		args = (self, context)
		self.current_area = context.area
		self._handle = bpy.types.SpaceView3D.draw_handler_add(geomp_draw_callback2_px, args, 'WINDOW', 'POST_VIEW')
		context.window_manager.modal_handler_add(self)
		context.area.tag_redraw()
		return {'RUNNING_MODAL'}

	def exit(self, context):
		print("- GeomP: finished")
		GEOMP_C.isActive = 0
		bpy.context.window.cursor_set("DEFAULT")
		bpy.types.SpaceView3D.draw_handler_remove(self._handle, 'WINDOW')
		context.area.header_text_set(None)
		context.area.tag_redraw()

	def modal(self, context, event):
		wpl_geompOpts = context.scene.wpl_geompOpts
		if GEOMP_C.isActive == 0 or wla.is_edit_mode() == False:
			self.exit(context)
			return {'FINISHED'}
		if event.type in {'SPACE', 'RET', 'ESC'}:
			if event.value == 'PRESS':
				if len(GEOMP_C.last_added_dots) > 0:
					if event.type in ('SPACE', 'RET'):
						if wpl_geompOpts.opt_tooltype == 'LINE' or wpl_geompOpts.opt_tooltype == 'POLYG':
							self.onToolPointAdded(context, 1)
					# resetting current line/etc anyway (for all!)
					GEOMP_C.last_added_dots = []
					return {'RUNNING_MODAL'}
				self.exit(context)
				return {'FINISHED'}
			return {'RUNNING_MODAL'}
		default_result = {'PASS_THROUGH'}
		if event.type == 'Z' and (event.ctrl or event.oskey):
			if event.value == 'PRESS':
				print("- GeomP: Undo last step")
				if len(GEOMP_C.undo_steps) > 0:
					facesIdx = GEOMP_C.undo_steps.pop()
					self.delMeshFaces(facesIdx)
			return {'RUNNING_MODAL'}
		if bpy.context.area is None:
			return {"PASS_THROUGH"}
		if wla.sys_ismouse_in_view3d_window(event):
			bpy.context.window.cursor_set("PAINT_BRUSH")
		else:
			bpy.context.window.cursor_set("DEFAULT")
			return {"PASS_THROUGH"}
		if event.type == 'RIGHT_BRACKET':
			default_result = {'RUNNING_MODAL'}
			if event.value == 'PRESS':
				size_greater = [s for s in kWPL_GEP_TSIZES if s > wpl_geompOpts.opt_toolsize]
				if len(size_greater) > 0:
					wpl_geompOpts.opt_toolsize = size_greater[0]
					context.area.tag_redraw()
		if event.type == 'LEFT_BRACKET':
			default_result = {'RUNNING_MODAL'}
			if event.value == 'PRESS':
				size_lesser = [s for s in kWPL_GEP_TSIZES if s < wpl_geompOpts.opt_toolsize]
				if len(size_lesser) > 0:
					wpl_geompOpts.opt_toolsize = size_lesser[-1]
					context.area.tag_redraw()
		if event.type in ('ONE'):
			default_result = {'RUNNING_MODAL'}
			if event.value == 'PRESS':
				wpl_geompOpts.opt_tooltype = 'LINE'
				context.area.tag_redraw()
		if event.type in ('TWO'):
			default_result = {'RUNNING_MODAL'}
			if event.value == 'PRESS':
				wpl_geompOpts.opt_tooltype = 'POLYG'
				context.area.tag_redraw()
		if event.type in ('THREE'):
			default_result = {'RUNNING_MODAL'}
			if event.value == 'PRESS':
				wpl_geompOpts.opt_tooltype = 'RECTS'
				context.area.tag_redraw()
		if event.type in ('FOUR'):
			default_result = {'RUNNING_MODAL'}
			if event.value == 'PRESS':
				wpl_geompOpts.opt_tooltype = 'RECTF'
				context.area.tag_redraw()
		if event.type in ('FIVE'):
			default_result = {'RUNNING_MODAL'}
			if event.value == 'PRESS':
				wpl_geompOpts.opt_tooltype = 'CIRCLE'
				context.area.tag_redraw()
		if event.type in ('F'): # 'NUMPAD_0' - no, switch to camera
			default_result = {'RUNNING_MODAL'}
			if event.value == 'PRESS':
				self.flipPlaneToggled(context)
		if event.type == 'RIGHTMOUSE':
			if event.value == 'RELEASE':
				mouse = Vector((event.mouse_region_x, event.mouse_region_y))
				#print("- mouse_region position", mouse)
				gco_ini = GEOMP_C.grid_offset
				GEOMP_C.grid_offset = (0,0,0)
				GEOMP_C.grid_plane_cache = None
				hit_3d = region_2d_to_scene_pt(context, mouse)
				pt_3d_snapped, pt_2d_local = scene_pt_to_plane_pt(context, hit_3d)
				if pt_3d_snapped is not None:
					if (pt_3d_snapped-GEOMP_C.grid_center).length < wpl_geompOpts.opt_gridsize*2.1:
						self.flipPlaneToggled(context)
					else:
						GEOMP_C.grid_center = pt_3d_snapped
					GEOMP_C.grid_offset = gco_ini
					GEOMP_C.grid_plane_cache = None
					# no need for baked grids, grids can be added - more intuitive
					# if GEOMP_C.grid_sufrace_cache is not None:
					# 	# need recalc positions
					# 	pre_gridcnt = GEOMP_C.grid_sufrace_cache["gridcnt"]
					# 	bake_verts = GEOMP_C.grid_sufrace_cache["verts"]
					# 	for tvIdx in bake_verts:
					# 		bv = bake_verts[tvIdx]
					# 		bv_co = bv[0] + (GEOMP_C.grid_center - pre_gridcnt)
					# 		bv[0] = bv_co
					# 	GEOMP_C.grid_sufrace_cache["gridcnt"] = Vector(GEOMP_C.grid_center)
				context.area.tag_redraw()
			return {'RUNNING_MODAL'}
		context.area.tag_redraw()
		context.area.header_text_set('GeomPainter | Tool: ['+wpl_geompOpts.opt_tooltype+'] | Size: ['+f'{wpl_geompOpts.opt_toolsize:.2f}'+'] | Mat: ['+wpl_geompOpts.opt_toolmat+'] | Hotkeys: [ ] 1..5 F')
		if event.type in self.refresh_trigger:
			mouse = Vector((event.mouse_region_x, event.mouse_region_y))
			hit_3d = region_2d_to_scene_pt(context, mouse)
			GEOMP_C.last_mouse_pt_g = hit_3d
		if event.type == 'LEFTMOUSE':
			if event.value == 'RELEASE':
				pt_3d_snapped, pt_2d_local = scene_pt_to_plane_pt(context, GEOMP_C.last_mouse_pt_g)
				if pt_3d_snapped is not None:
					isSame = False
					if len(GEOMP_C.last_added_dots) > 0:
						dot2d3d_last = GEOMP_C.last_added_dots[-1]
						if wla.coToKey(dot2d3d_last[0]) == wla.coToKey(pt_2d_local):
							isSame = True
					if isSame == False:
						# GEOMP_C.last_added_dots.append( (pt_2d_local, pt_3d_snapped) )
						self.addToolPoint(context, pt_2d_local, pt_3d_snapped, True )
						print("- adding point", pt_2d_local, len(GEOMP_C.last_added_dots))
						self.onToolPointAdded(context, 0)
					else:
						print("- skipping point, same")
						self.onToolPointAdded(context, 2)
			return {'RUNNING_MODAL'}
		return default_result

	def flipPlaneToggled(self, context):
		wpl_geompOpts = context.scene.wpl_geompOpts
		# rotating orientation - not for surface wrap
		if wpl_geompOpts.opt_gridorient in kWPL_GEP_ORIENTS_ROTLOC:
			idx = kWPL_GEP_ORIENTS_ROTLOC.index(wpl_geompOpts.opt_gridorient)
			wpl_geompOpts.opt_gridorient = kWPL_GEP_ORIENTS_ROTLOC[(idx+1) % len(kWPL_GEP_ORIENTS_ROTLOC)]
			GEOMP_C.grid_plane_cache = None
			context.area.tag_redraw()
		elif wpl_geompOpts.opt_gridorient in kWPL_GEP_ORIENTS_ROTCUR:
			idx = kWPL_GEP_ORIENTS_ROTCUR.index(wpl_geompOpts.opt_gridorient)
			wpl_geompOpts.opt_gridorient = kWPL_GEP_ORIENTS_ROTCUR[(idx+1) % len(kWPL_GEP_ORIENTS_ROTCUR)]
			GEOMP_C.grid_plane_cache = None
			context.area.tag_redraw()

	def delMeshFaces(self, facesIdx):
		active_obj = wla.object_by_name(GEOMP_C.target_obj_name)
		if active_obj is None:
			return
		bm = bmesh.from_edit_mesh(active_obj.data)
		bm.verts.ensure_lookup_table()
		bm.faces.ensure_lookup_table()
		if len(facesIdx)>0:
			faces2del = []
			for fIdx in facesIdx:
				f = bm.faces[fIdx]
				faces2del.append(f)
			bmesh.ops.delete(bm, geom=faces2del, context='FACES')
			bm.normal_update()
			bmesh.update_edit_mesh(active_obj.data)
			bm.faces.index_update()
			bm.faces.ensure_lookup_table()
			print("- removed faces",len(faces2del))
			
	def setupMeshFaces(self, context, bm, faces, doWeld):
		# set matIdx
		# clear WriW/Tex if present
		print("- setupMeshFaces", len(faces))
		wri_map = bm.loops.layers.color.get(config.kWPLMeshWriVC)
		# texdir_map = bm.loops.layers.color.get(config.kWPLTexDirVC)
		decorc_map = bm.loops.layers.color.get(config.kWPLMeshColVC)
		
		active_obj = wla.object_by_name(GEOMP_C.target_obj_name)
		wpl_geompOpts = context.scene.wpl_geompOpts
		wpl_vcOpts = context.scene.wpl_vcOpts
		decorc_col = (wpl_vcOpts.bake_vc_col[0], wpl_vcOpts.bake_vc_col[1], wpl_vcOpts.bake_vc_col[2], 1)
		faceMatIdx = -1
		mt_name = wla_attr.mat_find_any(wpl_geompOpts.opt_toolmat)
		if (active_obj is not None) and (mt_name is not None):
			for idx, mt in enumerate(active_obj.material_slots):
				if mt.name == mt_name:
					faceMatIdx = idx
					break
		fverts = set()
		fvertsCo = set()
		for f in faces:
			if faceMatIdx >= 0:
				f.material_index = faceMatIdx
			if (wri_map is not None) or (decorc_map is not None):
				for loop in f.loops:
					if decorc_map is not None:
						loop[decorc_map] = decorc_col
					if wri_map is not None:
						loop[wri_map] = (0,0,0,1)
					# if texdir_map is not None:
					# 	loop[texdir_map] = (0,0,0,1)
			f.select = True
			for v in f.verts:
				v.select = True
				fverts.add(v)
				fvertsCo.add(wla.coToKey(v.co))
			for e in f.edges:
				e.select = True
		if doWeld: 
			# WORKS with undo most of time - faces && face indexes are not changed
			# but not always -> reselecting with fvertsCo
			print("- removing doubles")
			bmesh.ops.remove_doubles(bm, verts = list(fverts), dist = wpl_geompOpts.opt_gridsize*0.01)
			# reselecting in case of merged verts (faces are deselected)
			_, _, pp_f =  wla_bm.bm_selectVertEdgesFaces(bm, None, list(fvertsCo))
			faces = list(pp_f)
		bm.verts.index_update()
		bm.verts.ensure_lookup_table()
		bm.faces.index_update()
		bm.faces.ensure_lookup_table()
		undo_faces = []
		for f in faces:
			undo_faces.append(f.index)
		GEOMP_C.undo_steps.append(undo_faces)
		return

	def addToolPoint(self, context, pt2d, pt3d, adjust3d):
		if pt3d is None:
			pt3d = plane_pt_to_scene_pt(context, pt2d)
		if adjust3d:
			plane_co, plane_x, plane_y, plane_z = get_draw_plane(context, pt3d)
			wpl_geompOpts = context.scene.wpl_geompOpts
			if plane_x is not None:
				pt3d = pt3d + plane_x * GEOMP_C.grid_offset[0] * wpl_geompOpts.opt_gridsize
			if plane_y is not None:
				pt3d = pt3d + plane_y * GEOMP_C.grid_offset[1] * wpl_geompOpts.opt_gridsize
			if plane_z is not None:
				pt3d = pt3d + plane_z * GEOMP_C.grid_offset[2] * wpl_geompOpts.opt_gridsize
		GEOMP_C.last_added_dots.append( (pt2d, pt3d) )

	def onToolPointAdded(self, context, isFinalType):
		if len(GEOMP_C.last_added_dots) == 0:
			return
		active_obj = wla.object_by_name(GEOMP_C.target_obj_name)
		if active_obj is None or active_obj.type != 'MESH':
			print("- invalid object")
			return
		mw = active_obj.matrix_world
		mw_inv = mw.inverted()
		bm = bmesh.from_edit_mesh(active_obj.data)
		bm.verts.ensure_lookup_table()
		bm.faces.ensure_lookup_table()
		bm.verts.index_update()
		wpl_geompOpts = context.scene.wpl_geompOpts
		plane_tile = wpl_geompOpts.opt_gridsize
		tool_dst = max(plane_tile * wpl_geompOpts.opt_toolsize, plane_tile*0.01)
		if wpl_geompOpts.opt_tooltype == 'CIRCLE':
			# adding circle primitive with proper material and size
			# pt_2d = GEOMP_C.last_added_dots[0][0]
			# center_co_g = plane_pt_to_scene_pt(context, pt_2d)
			center_co_g = GEOMP_C.last_added_dots[0][1]
			circ_verts = []
			_, plane_x, plane_y, plane_z = get_draw_plane(context, center_co_g)
			for i in range(0, kWPL_GEP_CIRCLE_VERTS):
				ang = math.pi*2.0*float(i)/kWPL_GEP_CIRCLE_VERTS
				tool_dst = plane_tile*wpl_geompOpts.opt_toolsize
				pt1 = center_co_g + plane_x*math.cos(ang)*tool_dst + plane_y*math.sin(ang)*tool_dst
				v = bm.verts.new( mw_inv @ pt1 )
				circ_verts.append(v)
			newf = bm.faces.new(circ_verts)
			self.setupMeshFaces(context, bm, [newf], False)
			bmesh.update_edit_mesh(active_obj.data)
			GEOMP_C.last_added_dots = []
			return
		if wpl_geompOpts.opt_tooltype == 'RECTF':
			if len(GEOMP_C.last_added_dots) >= 2:
				pt1_2d = GEOMP_C.last_added_dots[0][0]
				pt2_2d = GEOMP_C.last_added_dots[1][0]
				pt1 = plane_pt_to_scene_pt(context, pt1_2d)
				pt2 = plane_pt_to_scene_pt(context, (pt2_2d[0], pt1_2d[1], pt1_2d[2]) )
				pt3 = plane_pt_to_scene_pt(context, pt2_2d)
				pt4 = plane_pt_to_scene_pt(context, (pt1_2d[0], pt2_2d[1], pt1_2d[2]) )
				v1 = bm.verts.new( mw_inv @ pt1 )
				v2 = bm.verts.new( mw_inv @ pt2 )
				v3 = bm.verts.new( mw_inv @ pt3 )
				v4 = bm.verts.new( mw_inv @ pt4 )
				newf = bm.faces.new( [v1, v2, v3, v4])
				self.setupMeshFaces(context, bm, [newf], True)
				bmesh.update_edit_mesh(active_obj.data)
				GEOMP_C.last_added_dots = []
			return
		if (wpl_geompOpts.opt_tooltype in ['LINE', 'POLYG']) and (isFinalType == 0):
			return
		if wpl_geompOpts.opt_tooltype in ['LINE', 'POLYG', 'RECTS']:
			if len(GEOMP_C.last_added_dots) >= 2:
				if wpl_geompOpts.opt_tooltype == 'POLYG': # or (isFinalType == 2 and wpl_geompOpts.opt_tooltype == 'LINE'):
					# duplicating last point
					#GEOMP_C.last_added_dots.append( GEOMP_C.last_added_dots[0] )
					self.addToolPoint(context, GEOMP_C.last_added_dots[0][0], GEOMP_C.last_added_dots[0][1], False )
				if wpl_geompOpts.opt_tooltype == 'RECTS':
					# making rect stroke adding all 4 points for ringed line
					pt1_2d = GEOMP_C.last_added_dots[0][0]
					pt2_2d = GEOMP_C.last_added_dots[1][0]
					pt1_2d_2 = ( pt2_2d[0], pt1_2d[1], pt1_2d[2] )
					pt2_2d_2 = ( pt1_2d[0], pt2_2d[1], pt1_2d[2] )
					GEOMP_C.last_added_dots = []
					self.addToolPoint(context, pt1_2d, None, True )
					self.addToolPoint(context, pt1_2d_2, None, True )
					self.addToolPoint(context, pt2_2d, None, True )
					self.addToolPoint(context, pt2_2d_2, None, True )
					self.addToolPoint(context, pt1_2d, None, True )
				if wpl_geompOpts.opt_tooltype == 'POLYG':
					polyg_verts = []
					for dot2d3d in GEOMP_C.last_added_dots:
						#pt1 = plane_pt_to_scene_pt(context, pt1_2d)
						pt1 = dot2d3d[1]
						v = bm.verts.new( mw_inv @ pt1 )
						polyg_verts.append(v)
					newf = bm.faces.new(polyg_verts)
					self.setupMeshFaces(context, bm, [newf], False)
				if wpl_geompOpts.opt_tooltype in ['LINE', 'RECTS']:
					line_makeRinged = False
					dot2d3d_first = GEOMP_C.last_added_dots[0]
					dot2d3d_last = GEOMP_C.last_added_dots[-1]
					if wla.coToKey(dot2d3d_first[0]) == wla.coToKey(dot2d3d_last[0]):
						line_makeRinged = True
					# making stripe
					stripe_pair_pts = []
					for i in range(0, len(GEOMP_C.last_added_dots)):
						pt0 = None
						pt2 = None
						if i > 0:
							pt0 = GEOMP_C.last_added_dots[i-1][1]
							#pt0_2d = GEOMP_C.last_added_dots[i-1][0]
							#pt0 = plane_pt_to_scene_pt(context, pt0_2d)
						elif line_makeRinged:
							pt0 = GEOMP_C.last_added_dots[-2][1]
							#pt0_2d = GEOMP_C.last_added_dots[-2] # very last && very first are doubled
							#pt0 = plane_pt_to_scene_pt(context, pt0_2d)
						pt1_g = GEOMP_C.last_added_dots[i][1]
						#pt1_2d = GEOMP_C.last_added_dots[i]
						#pt1 = plane_pt_to_scene_pt(context, pt1_2d)
						if i < len(GEOMP_C.last_added_dots)-1:
							pt2 = GEOMP_C.last_added_dots[i+1][1]
							#pt2_2d = GEOMP_C.last_added_dots[i+1]
							#pt2 = plane_pt_to_scene_pt(context, pt2_2d)
						elif line_makeRinged:
							pt2 = GEOMP_C.last_added_dots[1][1]
							#pt2_2d = GEOMP_C.last_added_dots[1] # very last && very first are doubled
							#pt2 = plane_pt_to_scene_pt(context, pt2_2d)
						dir_flow = None
						if pt0 is not None:
							dir_flow = (pt1_g-pt0).normalized()
						else:
							dir_flow = (pt2-pt1_g).normalized()
						_, plane_x, plane_y, plane_z = get_draw_plane(context, pt1_g)
						dir_side = plane_z.cross(dir_flow).normalized()
						pt1_l = wla.math_vecOffsetClipped(pt1_g, dir_side*tool_dst, pt0, pt2, 1)
						pt1_r = wla.math_vecOffsetClipped(pt1_g, -1*dir_side*tool_dst, pt0, pt2, 1)
						stripe_pair_pts.append( (pt1_l, pt1_r) )
					stripe_faces = []
					for i in range(0, len(stripe_pair_pts)-1):
						pt1 = stripe_pair_pts[i][0]
						pt2 = stripe_pair_pts[i+1][0]
						pt3 = stripe_pair_pts[i+1][1]
						pt4 = stripe_pair_pts[i][1]
						v1 = bm.verts.new( mw_inv @ pt1 )
						v2 = bm.verts.new( mw_inv @ pt2 )
						v3 = bm.verts.new( mw_inv @ pt3 )
						v4 = bm.verts.new( mw_inv @ pt4 )
						newf = bm.faces.new( [v1, v2, v3, v4])
						stripe_faces.append(newf)
					self.setupMeshFaces(context, bm, stripe_faces, True)
				bmesh.update_edit_mesh(active_obj.data)
				GEOMP_C.last_added_dots = []
			return


# ==========================================
# ==========================================

def WPL_GEOMPOPTS_matlist_items(self, context):
	lst = []
	active_obj = wla.active_object()
	if active_obj is not None:
		for idx, mt in enumerate(active_obj.material_slots):
			if (mt is None) or (len(mt.name) == 0):
				continue
			lst.append((mt.name, mt.name, "tool material"))
			if idx >= kWPL_GEP_MATLIST_MAXITEMS:
				break
	while len(lst)<kWPL_GEP_MATLIST_MAXITEMS:
		lst.append(('...', '...', "tool material"))
	return lst
def WPL_GEOMPOPTS_matlist_update(self, context):
	wpl_geompOpts = context.scene.wpl_geompOpts
	wpl_geompOpts.opt_toolmat = wpl_geompOpts.opt_toolmat2
	print("- GeomP: material updated", wpl_geompOpts.opt_toolmat)

class WPL_GEOMPOPTS(bpy.types.PropertyGroup):
	opt_gridsize : FloatProperty(
		name="Grid Size",
		default = 0.1
	)
	opt_gridcells : IntProperty(
		name="Grid Cells",
		default = 10
	)
	opt_gridorient : EnumProperty(
		items = [
			('LOCAL_XY', "Local XY", ""),
			('LOCAL_XZ', "Local XZ", ""),
			('LOCAL_YZ', "Local YZ", ""),
			('CUR3D_XY', "Cursor XY", ""),
			('CUR3D_XZ', "Cursor XZ", ""),
			('CUR3D_YZ', "Cursor YZ", ""),
			# ('SUFR_5', "Surface 5v", ""),
			# ('SUFR_11', "Surface 11v", ""),
			# ('SUFR_21', "Surface 21v", ""),
			# ('SUFR_LAST', "Surface Last", ""),
			('VIEW_GRID_11', "View-Grid", ""),
			('VIEW_GRID_11_ADD', "View-Grid Append", ""),
		],
		name="Grid Align",
		default='LOCAL_XZ',
	)

	opt_tooltype : EnumProperty(
		items = [
			('LINE', "(1) Line", ""),
			('POLYG', "(2) Poligon", ""),
			('RECTS', "(3) Stroked Rectangle", ""),
			('RECTF', "(4) Filled Rectangle", ""),
			('CIRCLE', "(5) Circle", ""),
		],
		name="Active tool",
		default='LINE',
	)
	opt_toolmat: StringProperty(
		name="Tool material",
		default = ""
	)
	opt_toolmat2: EnumProperty(
		name="Tool material",
		items = WPL_GEOMPOPTS_matlist_items,
		update = WPL_GEOMPOPTS_matlist_update
	)
	opt_toolsize : FloatProperty(
		name="Tool Size, relative",
		default = 1.0
	)

def uilayout_geompBox(col, context):
	col.label(text = "GeomP")
	wpl_geompOpts = context.scene.wpl_geompOpts
	wpl_vcOpts = context.scene.wpl_vcOpts
	if GEOMP_C.isActive == 0:
		col.prop(wpl_geompOpts, "opt_gridsize", text = "Grid size")
	else:
		row1 = col.row()
		row1.label(text="Extra height")
		row1.operator("mesh.wplgeomp_modalflow", text='-25%').opt_action = 'SET_SUBDEPTH_M25'
		row1.operator("mesh.wplgeomp_modalflow", text='0%').opt_action = 'SET_SUBDEPTH_ZER'
		row1.operator("mesh.wplgeomp_modalflow", text='5%').opt_action = 'SET_SUBDEPTH_P5'
		row1.operator("mesh.wplgeomp_modalflow", text='25%').opt_action = 'SET_SUBDEPTH_P25'
		row1.operator("mesh.wplgeomp_modalflow", text='50%').opt_action = 'SET_SUBDEPTH_P50'
	row1 = col.row()
	row1.prop(wpl_vcOpts, "bake_vc_col", text = "Color")
	row1 = col.row()
	row1.prop(wpl_geompOpts, "opt_tooltype", text = "Tool")
	row1.prop(wpl_geompOpts, "opt_toolsize", text = "")
	# if len(str(wpl_geompOpts.opt_toolmat2)) == 0:
	# 	toolmat2_list = WPL_GEOMPOPTS_matlist_items(None, None)
	# 	if len(toolmat2_list) > 0:
	# 		wpl_geompOpts.opt_toolmat2 = toolmat2_list[0][0]
	col.prop(wpl_geompOpts, "opt_toolmat2", text = "Material")
	if GEOMP_C.isActive > 0:
		col.separator()
		col.operator("mesh.wplgeomp_modalflow", text='GeomP: Stop', icon = 'VIEW_PERSPECTIVE').opt_action = 'STOP'
	else:
		row1 = col.row()
		row1.prop(wpl_geompOpts, "opt_gridorient", text = "Type")
		row1.prop(wpl_geompOpts, "opt_gridcells", text = "Radius")
		col.operator("mesh.wplgeomp_modalflow", text='GeomP: Start', icon = 'VIEW_PERSPECTIVE').opt_action = 'START'

class WPL_PT_GeompPanel1(bpy.types.Panel):
	bl_idname = "WPL_PT_GeompPanel1"
	bl_label = "GeomPainters"
	bl_space_type = 'VIEW_3D'
	bl_region_type = 'UI'
	bl_category = 'Sculpt'

	def draw(self, context):
		from . import ops_tool_stampp
		layout = self.layout
		col = layout.column()
		box1 = None
		if ops_tool_stampp.STAMP_C.isActive == 0:
			box1 = col.box()
			uilayout_geompBox(box1, context)
		if GEOMP_C.isActive == 0:
			if box1 is not None:
				col.separator()
			box1 = col.box()
			ops_tool_stampp.uilayout_stamppBox(box1, context, False)

# ==========================================
# ==========================================

classes = (
	WPL_GEOMPOPTS,
	WPL_PT_GeompPanel1,

	wplgeomp_modalflow,
)

def register():
	for cls in classes:
		bpy.utils.register_class(cls)
	bpy.types.Scene.wpl_geompOpts = bpy.props.PointerProperty(type=WPL_GEOMPOPTS)

def unregister():
	for cls in reversed(classes):
		bpy.utils.unregister_class(cls)
	del bpy.types.Scene.wpl_geompOpts

if __name__ == "__main__":
	register()