import os, sys, time, datetime
import math, copy, string, random
import numpy as np
import bpy, bmesh, mathutils

import bpy.types
from mathutils import Vector, Matrix, Euler, Quaternion
from mathutils.bvhtree import BVHTree
from mathutils.kdtree import KDTree
from bpy_extras import view3d_utils
from bpy.props import *

from . import config
from .tools import wla
from .tools import wla_do

# ==========================================

kWPLNodeMenuSubChar = '_'
class WPL_G_NODES:
	ngstore = {}
	rowstr = {}
	nodecopy = {}

kWPLSupportedTrees = ['ShaderNodeTree',  'CompositorNodeTree',  'GeometryNodeTree']
kWPLSupportedGroup = ['ShaderNodeGroup', 'CompositorNodeGroup', 'GeometryNodeGroup']
kWPLSupportedTypes = ['SHADER',          'COMPOSITING',         'GEOMETRY']

# ==========================================
# related: https://github.com/JacquesLucke/animation_nodes/blob/a51752168a801660f3015f70b022b95d1679e746/animation_nodes/ui/node_menu.py

class WPL_MT_NodeGroups(bpy.types.Menu):
	bl_label = "WPL Groups"
	bl_idname = "WPL_MT_NodeGroups"
	
	def draw(self, context):
		# menu type
		tree_type = context.space_data.tree_type
		typeFilter = kWPLSupportedTypes[0]
		addnodeType = kWPLSupportedGroup[0]
		if tree_type == kWPLSupportedTrees[1]:
			typeFilter = kWPLSupportedTypes[1]
			addnodeType = kWPLSupportedGroup[1]
		if tree_type == kWPLSupportedTrees[2]:
			typeFilter = kWPLSupportedTypes[2]
			addnodeType = kWPLSupportedGroup[2]
		# hierlevel
		nameFilter = ""
		try:
			row = context.hier
			nameFilter = WPL_G_NODES.rowstr[row]
		except:
			pass
		if len(nameFilter) == 0:
			WPL_G_NODES.rowstr = {} # resetting to free objects
		#print("WPL_G_NODES.rowstr len=",len(WPL_G_NODES.rowstr))
		layout = self.layout
		all_ngroups = bpy.data.node_groups
		all_ngroups_mtt = []
		next_hiercounts = {}
		for ng in all_ngroups:
			ui_name = ng.name
			if ng.type != typeFilter:
				# ignoring improper nodes
				#print("Unknown node type",ng.type)
				continue
			if ng.library is not None:
				ui_name = "L: "+ng.name
			if len(nameFilter) > 0 and not ui_name.startswith(nameFilter):
				continue
			bpy.types.WindowManager.ngstore[ui_name] = ng
			
			ui_name_nofil = ui_name
			if len(nameFilter) > 0:
				ui_name_nofil = ui_name_nofil.replace(nameFilter,"")
			ng_hier = ui_name_nofil.split(kWPLNodeMenuSubChar)
			ng_hier_str = ""
			if len(ng_hier)>0:
				ng_hier_str = nameFilter+ng_hier[0]+kWPLNodeMenuSubChar
			if ng_hier_str not in next_hiercounts:
				next_hiercounts[ng_hier_str] = 0
			next_hiercounts[ng_hier_str] = next_hiercounts[ng_hier_str]+1
			item = {"item": ng, "ui_name": ui_name, "hier": ng_hier_str}
			all_ngroups_mtt.append(item)
		all_ngroups_mtt = sorted(all_ngroups_mtt, key=lambda k: k["ui_name"])
		
		if len(nameFilter) == 0:
			n_op_start = layout.operator("node.add_node", text = "Frame")
			n_op_start.type = "NodeFrame"
			n_op_start.use_transform = True
			n_op_start = layout.operator("node.add_node", text = "Reroute")
			n_op_start.type = "NodeReroute"
			n_op_start.use_transform = True
		else:
			n_op_start = layout.operator("node.add_node", text = nameFilter+"...")
			n_op_start.type = "NodeReroute"
			n_op_start.use_transform = True
		layout.separator()
		for item in all_ngroups_mtt:
			ng = item["item"]
			ng_ui = item["ui_name"]
			ng_hier = item["hier"]
			if len(ng_hier) == 0 or next_hiercounts[ng_hier] < 2:
				n_op = layout.operator("node.add_node", text = ng_ui) #bpy.ops.node.add_node
				n_op.type = addnodeType
				n_op.use_transform = True
				n_op_set = n_op.settings.add()
				n_op_set.name = "node_tree"
				# !!!-->> not using node name here! Local and Library items can have EXACT THE SAME NAME <<--!!!
				n_op_set.value = "bpy.types.WindowManager.ngstore['"+ng_ui+"']" #"bpy.data.node_groups['"+item.name+"']"
			else:
				if next_hiercounts[ng_hier] < 999:
					next_hiercounts[ng_hier] = 999
					row = layout.row()
					#n_op_set2 = n_op_start.settings.add()
					#n_op_set2.name = "hier["+ng_ui+"]"
					#n_op_set2.value = ng_hier
					WPL_G_NODES.rowstr[row] = ng_hier
					row.context_pointer_set("hier", row)
					row.menu("WPL_MT_NodeGroups", text = item["hier"]+"...")

def drawNodeGroupsRootMenu(self, context):
	if context.space_data.type != 'NODE_EDITOR':
		return
	tree_type = context.space_data.tree_type
	if (tree_type not in kWPLSupportedTrees):
		#print("tree_type",tree_type)
		return

	layout = self.layout
	layout.separator()
	#layout.label(text = "tt:" + tree_type)
	layout.operator_context = 'INVOKE_REGION_WIN'
	layout.menu(WPL_MT_NodeGroups.bl_idname)

# ================

class wplheal_dedupmats(bpy.types.Operator):
	bl_idname = "object.wplheal_dedupmats"
	bl_label = "Dedupe Materials"
	bl_options = {'REGISTER', 'UNDO'}

	opt_skipIfParts : StringProperty(
		name = "Objects to skip",
		default = config.kWPLSystemReestrToken
	)

	opt_upgrMats : BoolProperty(
		name="Upgrade '_v' mats",
		default=True
	)
	opt_upgrToLinked : BoolProperty(
		name="Prefer linked groups/mats/scripts",
		default=True
	)
	opt_upgrRenamesMats : BoolProperty(
		name="Upgrade renames",
		default=True
	)

	def getLibraryAnalogMat(self, mewmat, matsAll):
		if mewmat is None:
			return None
		if mewmat.library is None:
			for ngt in matsAll:
				if ngt.library is not None and ngt.name == mewmat.name:
					mewmat = ngt
		return mewmat

	def getMatByName(self, mat_name, matsAll):
		if mat_name is None:
			return None
		mewmat = matsAll.get(mat_name)
		return mewmat

	def isObjUpdatable(self,obj,skipNameParts):
		canContinue = True
		for snp in skipNameParts:
			if obj.name.lower().find(snp) >= 0:
				canContinue = False
				break
		return canContinue

	def execute( self, context ):
		mats = bpy.data.materials
		itogo_ok = 0
		itogo_skip = 0
		skipNameParts = wla.strToTokens(self.opt_skipIfParts)
		for obj in bpy.data.objects:
			if not self.isObjUpdatable(obj,skipNameParts):
				continue
			for slt in obj.material_slots:
				part = slt.name.rpartition(config.kWPLMatTokenDedup)
				if part[2].isnumeric() and part[0] in mats:
					print("- %s: '%s' -> '%s'" % (obj.name, slt.name, part[0]))
					slt.material = self.getMatByName(part[0],mats)
					itogo_ok = itogo_ok+1
				elif len(part[0])>0 and len(part[2])>0:
					itogo_skip = itogo_skip+1
					print("- %s: Skipping '%s'" % (obj.name, slt.name), part)
		# upgrading AFTER deduping
		if self.opt_upgrMats:
			# checking mat_override in render layers
			for lr in bpy.context.scene.view_layers:
				if lr.material_override is not None:
					slt_old_name = lr.material_override.name
					part = slt_old_name.rpartition(config.kWPLMatTokenWPV)
					if part[2].isnumeric():
						ver = int(part[2])
						for upgStep in reversed(range(1,100)):
							nextMatName = part[0]+part[1]+str(ver+upgStep).rjust(2, '0')
							if nextMatName in mats:
								print("- %s: '%s' -> '%s'" % ("material_override", slt_old_name, nextMatName))
								lr.material_override = self.getMatByName(nextMatName,mats)
								itogo_ok = itogo_ok+1
								break
					if self.opt_upgrToLinked == True:
						lr.material_override = self.getLibraryAnalogMat(lr.material_override,mats)
			for obj in bpy.data.objects:
				if not self.isObjUpdatable(obj,skipNameParts):
					continue
				for slt in obj.material_slots:
					slt_old_name = slt.name
					part = slt_old_name.rpartition(config.kWPLMatTokenWPV)
					if part[2].isnumeric():
						ver = int(part[2])
						for upgStep in reversed(range(1,100)):
							nextMatName = part[0]+part[1]+str(ver+upgStep).rjust(2, '0')
							if nextMatName in mats:
								print("- %s: '%s' -> '%s'" % (obj.name, slt_old_name, nextMatName))
								slt.material = self.getMatByName(nextMatName,mats)
								itogo_ok = itogo_ok+1
								break
					elif len(part[0])>0 and len(part[2])>0:
						itogo_skip = itogo_skip+1
						print("- %s: Skipping '%s'" % (obj.name, slt.name), part)
				# checking geomnodes
				for md in obj.modifiers:
					if md.type == 'NODES':
						print("- ???", md.node_group)
						if md.node_group is not None:
							renam = config.isMaterialRenamed(md.node_group.name)
							if renam is not None:
								nd_renam = bpy.data.node_groups.get(renam)
								if nd_renam is not None:
									print("- %s: '%s' -> '%s'" % (obj.name, md.node_group.name, nd_renam.name))
									md.node_group = nd_renam
									itogo_ok = itogo_ok+1
		if self.opt_upgrToLinked == True:
			for obj in bpy.data.objects:
				if not self.isObjUpdatable(obj,skipNameParts):
					continue
				for slt in obj.material_slots:
					slt.material = self.getLibraryAnalogMat(slt.material,mats)
		if self.opt_upgrRenamesMats == True:
			for obj in bpy.data.objects:
				if not self.isObjUpdatable(obj,skipNameParts):
					continue
				for slt in obj.material_slots:
					if slt.material is not None:
						renam = config.isMaterialRenamed(slt.material.name)
						renamMat = self.getMatByName(renam, mats)
						if renamMat is not None:
							if self.opt_upgrToLinked == True:
								renamMat = self.getLibraryAnalogMat(renamMat, mats)
							print("- %s: '%s' -> '%s'" % (obj.name, slt.name, renamMat))
							slt.material = renamMat
							itogo_ok = itogo_ok+1
		self.report({'INFO'}, "Materials updated: "+str(itogo_ok)+", skipped: "+str(itogo_skip))
		return {'FINISHED'}

class wplnode_dedupnodes(bpy.types.Operator):
	bl_idname = "object.wplnode_dedupnodes"
	bl_label = "Dedupe NodeGroups"
	bl_options = {'REGISTER', 'UNDO'}

	opt_upgrToLinked : BoolProperty(
		name="Prefer linked groups/mats/scripts",
		default=True
	)
	opt_upgrNodeGroups : BoolProperty(
		name="Upgrade '_v' groups",
		default=True
	)
	opt_upgrNodeScripts : BoolProperty(
		name="Upgrade '_v' scripts",
		default=False
	)
	opt_upgrRenamesScripts : BoolProperty(
		name="Upgrade renames",
		default=True
	)

	def getHigherVerName(self, node_name, nodeAll):
		part = node_name.rpartition(config.kWPLMatTokenWPV)
		if part[2].isnumeric():
			ver = int(part[2])
			for upgStep in reversed(range(1,100)):
				nextMat = part[0]+part[1]+str(ver+upgStep).rjust(2, '0')
				if nextMat in nodeAll:
					return nextMat
		return None

	def getLibraryAnalog(self,node_name,nodeAll):
		for ngt in nodeAll:
			if ngt.library is not None and ngt.name == node_name:
				return ngt
		return None

	def dedupeScript(self, node, parentName):
		#print("Checking ",node.name,node.script)
		script_texts = bpy.data.texts
		oldscript = node.script
		if oldscript is not None:
			(base, sep, ext) = oldscript.name.rpartition(config.kWPLMatTokenDedup)
			# Replace the numeric duplicate
			if ext.isnumeric():
				if base in script_texts:
					print("- '%s': Replace script '%s' with '%s'" % (parentName, oldscript.name, base))
					node.script = script_texts.get(base)
					node.update()
				else:
					print("- '%s': Rename script '%s' to '%s'" % (parentName, oldscript.name, base))
					oldscript.name = base
				return True
		return False

	def upgradeScript(self, node, upgradeVersion, checkLibAtls, upgradeRenames, parentName):
		script_texts = bpy.data.texts
		if checkLibAtls and node.script is not None and node.script.library is None:
			ngt = self.getLibraryAnalog(node.script.name, script_texts)
			if ngt is not None:
				print("- '%s': Warning: library analog found: '%s' -> '%s'" % (parentName, node.script.name, ngt.name))
				node.script = ngt
				print("// Upgraded to library analog")
		if node.script is not None:
			# renam = config.isMaterialRenamed(node.script.name)
			# if renam is not None:
			# 	print("- '%s': Warning: upgradable script item '%s' -> '%s'" % (parentName, node.script.name, renam))
			# 	if upgradeRenames:
			# 		node.script = script_texts.get(renam)
			# 		print("// Upgraded to '%s'" % (renam))
			# 	return True
			upgrName = self.getHigherVerName(node.script.name, script_texts)
			if upgrName is not None:
				print("- '%s': Warning: upgradable script item '%s' -> '%s'" % (parentName, node.script.name, upgrName))
				if upgradeVersion:
					node.script = script_texts.get(upgrName)
					print("// Upgraded to '%s'" % (upgrName))
				return True
		return False

	def dedupeNodeGroup(self, node, parentName):
		#print("Checking ",node.name,node.node_tree.name)
		node_groups = bpy.data.node_groups
		nn_tree = node.node_tree
		(base, sep, ext) = nn_tree.name.rpartition(config.kWPLMatTokenDedup)
		if ext.isnumeric():
			if base in node_groups:
				print("- '%s': Replace nodegroup '%s' with '%s'" % (parentName, nn_tree.name, base))
				node.node_tree.use_fake_user = False
				node.node_tree = node_groups.get(base)
			else:
				print("- '%s': Rename nodegroup '%s' to '%s'" % (parentName, nn_tree.name, base))
				node.node_tree.name = base
			return True
		return False

	def upgradeNodeGroup(self, node, doRealUpgrade, checkLibAtls, parentName):
		# 00-padding must be present
		# ..._v01 -> ..._v02 - ok. ..._v1 -> ..._v2 - wrong!
		node_groups = bpy.data.node_groups
		if checkLibAtls and node.node_tree.library is None:
			ngt = self.getLibraryAnalog(node.node_tree.name, node_groups)
			if ngt is not None:
				print("- '%s': Warning: library analog found: '%s' -> '%s'" % (parentName, node.node_tree.name, ngt.name))
				node.node_tree = ngt
				print("// Upgraded to library analog")
		upgrName = self.getHigherVerName(node.node_tree.name,node_groups)
		if upgrName is not None:
			print("- '%s': Warning: upgradable item '%s' -> '%s'" % (parentName, node.node_tree.name, upgrName))
			if doRealUpgrade:
				node.node_tree = node_groups.get(upgrName)
				print("// Upgraded to '%s'" % (upgrName))
			return True
		return False


	def execute( self, context ):
		itogos = {}
		itogos["cln"] = 0
		itogos["upg"] = 0
		itogos["prb"] = 0
		def checkNode(node, refname):
			if node.bl_idname == 'ShaderNodeScript':
				if  node.mode != 'EXTERNAL' and node.script is None:
					print("- Warning: Broken node, no script in %s" % (refname))
					itogos["prb"] = itogos["prb"]+1
					return
				if self.dedupeScript(node,refname):
					itogos["cln"] = itogos["cln"]+1
				if self.upgradeScript(node,self.opt_upgrNodeScripts,self.opt_upgrToLinked,self.opt_upgrRenamesScripts,refname):
					itogos["upg"] = itogos["upg"]+1
			elif node.bl_idname == 'ShaderNodeGroup' or node.bl_idname == 'CompositorNodeGroup': #node.type == 'GROUP'
				if node.node_tree is None or len(node.node_tree.nodes) == 0:
					print("- Warning: Broken node, no nodetree in", node.name, " mat:", refname)
					itogos["prb"] = itogos["prb"]+1
					return
				if self.dedupeNodeGroup(node,refname):
					itogos["cln"] = itogos["cln"]+1
				if self.upgradeNodeGroup(node, self.opt_upgrNodeGroups, self.opt_upgrToLinked, refname):
					itogos["upg"] = itogos["upg"]+1
				if len(node.node_tree.nodes) < 2:
					# badly linked node, at least input/output should be present!
					print("- Warning: Broken node, no subnodes in", node.node_tree.name, " mat:", refname)
					itogos["prb"] = itogos["prb"]+1
		#--- Search for duplicates in actual node groups - same as mat_getAllNodes
		node_groups = bpy.data.node_groups
		for group in node_groups:
			if len(group.nodes) < 2:
				# badly linked node, at least input/output should be present!
				print("- Warning: Broken node, no subnodes in", group.name, ", users:", group.users, group.use_fake_user)
				itogos["prb"] = itogos["prb"]+1
				continue
			nodes = group.nodes
			for node in nodes:
				checkNode(node, group.name)
		#--- Search for duplicates in materials
		mats_all = wla.mat_getAll()
		for mat in mats_all:
			if mat.use_nodes:
				nodes = mat.node_tree.nodes
				for node in nodes:
					checkNode(node, mat.name)
		#--- Search for duplicates in light objects
		for obj in bpy.data.objects:
			if (obj.type in ['LIGHT']) and (obj.data is not None and obj.data.node_tree is not None):
				# print("- light check", obj.name, obj.data.node_tree.bl_idname)
				nodes = obj.data.node_tree.nodes
				for node in nodes:
					checkNode(node, obj.name)
		#--- composnodes
		compostree = bpy.context.scene.node_tree
		for node in compostree.nodes:
			checkNode(node, "compositor")
		# Scripts text cleanup
		allTexts = bpy.data.texts.keys()
		for scriptname in allTexts:
			script_block = bpy.data.texts.get(scriptname)
			(base, sep, ext) = scriptname.rpartition(config.kWPLMatTokenDedup)
			if ext.isnumeric():
				if base in bpy.data.texts:
					print("- Text cleanup: Removing", scriptname, " - base script found")
					bpy.data.texts.remove(script_block)
					script_block = None
					itogos["cln"] = itogos["cln"]+1
			if self.opt_upgrToLinked and script_block is not None and script_block.library is None:
				ngt = self.getLibraryAnalog(scriptname, bpy.data.texts)
				if ngt is not None:
					print("- Text cleanup: Removing", scriptname, " - libanalog found")
					bpy.data.texts.remove(script_block)
					script_block = None
					itogos["cln"] = itogos["cln"]+1
		self.report({'INFO'}, "NodeGroups deduped, dupes: "+str(itogos["cln"])+", upgr: "+str(itogos["upg"])+", problems: "+str(itogos["prb"]))
		return {'FINISHED'}

class wplnode_findnodeuse(bpy.types.Operator):
	bl_idname = "object.wplnode_findnodeuse"
	bl_label = "Test nodes"
	bl_options = {'REGISTER', 'UNDO'}

	# '?' prefix - search for linked outputs/inputs
	nameSubstrs : StringProperty(
		name	= "Tokens to search",
		default	 = "<name>, ?<output>"
	)
	makeAllLocal : BoolProperty(
		name		= "DBG: Make local ALL",
		default	 = False
	)
	recompScript : BoolProperty(
		name		= "OSL: Recompile matches",
		default	 = False
	)

	# Running as separate dialog
	def invoke(self, context, event):
		return context.window_manager.invoke_props_dialog(self, width = 200)

	def testNode( self, nd, src_info, testNames, debug_logs, debug_logs2):
		if self.makeAllLocal:
			#if nd.bl_idname == 'ShaderNodeScript' and nd.library:
			#	nd.make_local()
			if nd.bl_idname == 'ShaderNodeGroup' and nd.node_tree.library:
				nd.node_tree.make_local()
		if nd.bl_idname == 'ShaderNodeScript' and nd.mode != 'EXTERNAL' and nd.script is None:
			log_str = "- !!! found broken node (script) "+nd.name+" in "+src_info
			debug_logs.append(log_str)
			return
		if nd.bl_idname == 'ShaderNodeGroup' and (nd.node_tree is None or len(nd.node_tree.nodes) == 0):
			log_str = "- !!! found broken node (ngroup) "+nd.name+" in "+src_info
			debug_logs.append(log_str)
			return
		subnames = []
		for tn_sock in testNames:
			if '?' in tn_sock:
				tn = tn_sock.replace('?','').lower()
				subnames.append(tn)
		isAnyTestPresent = None
		for tn in testNames:
			#if tn.lower() in nd.bl_idname.lower():
			#	isAnyTestPresent = "id:"+nd.bl_idname
			if tn in nd.name.lower():
				isAnyTestPresent = "name:"+nd.name
			if tn in nd.label.lower():
				isAnyTestPresent = "label:"+nd.label
			if nd.bl_idname == 'ShaderNodeGroup' and nd.node_tree.animation_data is not None:
				for d in nd.node_tree.animation_data.drivers:
					if tn != "*" and tn in d.driver.expression.lower():# '*' match any multiplication
						isAnyTestPresent = "node driver:"+nd.node_tree.name+" "+d.driver.expression
						break
			if nd.bl_idname == 'ShaderNodeScript':
				if nd.script is not None and tn in nd.script.name.lower():
					isAnyTestPresent = "script:"+nd.script.name
					if self.recompScript:
						print("- recompiling", src_info, nd.script.name)
						#bpy.ops.render.update_script_node(node=nd)
						#node_override = context.copy()
						node_override = bpy.context.copy()
						node_override["node"] = nd
						node_override["active_node"] = None
						node_override["selected_nodes"] = None
						node_override["edit_text"] = nd.script
						bpy.ops.node.shader_script_update(node_override)
						wla_do.sys_update_view(True, False)
				if nd.filepath is not None and tn in nd.filepath.lower():
					isAnyTestPresent = "file:"+nd.filepath
			if nd.bl_idname == 'ShaderNodeGroup' and tn in nd.node_tree.name.lower():
				isAnyTestPresent = "nodetree:"+nd.node_tree.name
			if nd.bl_idname == 'ShaderNodeAttribute' and wla.isTokenInStr(subnames, nd.attribute_name):
				isAnyTestPresent = "attrib:"+nd.attribute_name
			if nd.bl_idname == 'ShaderNodeUVMap' and wla.isTokenInStr(subnames, nd.uv_map):
				isAnyTestPresent = "attrib:"+nd.uv_map
			if isAnyTestPresent is None and ("*" in testNames) and len(subnames) > 0:
				# need to check inputs/outputs of scripts/etc
				isAnyTestPresent = "?"
		if isAnyTestPresent is None:
			return
		log_str = nd.name+" in "+src_info
		if isAnyTestPresent != "?": # real match with any token
			#log_str = log_str+"; id:"+nd.bl_idname
			debug_logs.append("- " + log_str + " ["+isAnyTestPresent+"]")
		for tn in subnames:
			for inpt in nd.inputs:
				#print("input:", inpt, inpt.type, wla_do.sys_dump_pythonobj(inpt))
				if inpt.is_linked:
					if tn in inpt.name.lower():
						log_str2 = " -> found linked input "+inpt.name
						debug_logs.append("... " + log_str + log_str2)
						debug_logs2.append("- " + log_str + log_str2)
				elif inpt.type == 'STRING':
					#print("input: string", inpt, inpt.default_value, inpt.name)
					if len(inpt.default_value) > 0:
						if tn in inpt.name.lower():
							log_str2 = " -> found input "+inpt.name+" = "+inpt.default_value
							debug_logs.append("... " + log_str + log_str2)
							debug_logs2.append("- " + log_str + log_str2)
						if tn in inpt.default_value.lower():
							log_str2 = " -> found value of input "+inpt.name+" = "+inpt.default_value
							debug_logs.append("... " + log_str + log_str2)
							debug_logs2.append("- " + log_str + log_str2)
			for outp in nd.outputs:
				if outp.is_linked:
					if tn in outp.name.lower():
						log_str2 = " -> found linked output "+outp.name
						debug_logs.append("... " + log_str + log_str2)
						debug_logs2.append("- " + log_str + log_str2)
		return

	def execute( self, context ):
		if self.recompScript:
			print("- locking interface")
			bpy.types.RenderSettings.use_lock_interface = True
		stringTokens = []
		if len(self.nameSubstrs)>0:
			stringTokens = wla.strToTokens(self.nameSubstrs)
		print("Test tokens:",stringTokens)
		debug_logs = []
		debug_logs2 = []
		node_groups = bpy.data.node_groups
		mats_all = wla.mat_getAll()
		if self.makeAllLocal:
			for mat in mats_all:
				if mat.use_nodes and mat.library is not None:
					mat.make_local()
		for group in node_groups:
			if len(group.nodes) == 0:
				log_str = "- !!! found broken nodegroup "+group.name
				debug_logs.append(log_str)
			for node in group.nodes:
				self.testNode(node,"Grp:"+group.name,stringTokens,debug_logs,debug_logs2)
		for mat in mats_all:
			if mat.use_nodes:
				for node in mat.node_tree.nodes:
					self.testNode(node,"Mat:"+mat.name,stringTokens,debug_logs,debug_logs2)
		for l in debug_logs:
			print(l)
		if "?" in self.nameSubstrs:
			if len(debug_logs2) > 0:
				print("\n--- POI")
				for l in debug_logs2:
					print(l)
			else:
				print("\n---\nPOI: found nothing")
		if self.recompScript:
			print("- unlocking interface")
			bpy.types.RenderSettings.use_lock_interface = False
		self.report({'INFO'}, "Results: "+str(len(debug_logs))+", See console")
		return {'FINISHED'}

# ================

class wplnode_nodeval_copy(bpy.types.Operator):
	bl_idname = "object.wplnode_nodeval_copy"
	bl_label = "Copy #values"
	bl_options = {'REGISTER', 'UNDO'}

	@classmethod
	def poll(cls, context):
		space = context.space_data
		return space.type == 'NODE_EDITOR'

	def execute( self, context ):
		keys_found = WPL_G_NODES.nodecopy
		selnodes = context.selected_nodes
		if len(selnodes) == 0:
			self.report({'INFO'}, "Select some nodes first")
			return {'FINISHED'}
		for node in selnodes:
			if config.kWPLNodePrefix in node.label:
				#wla_do.sys_dump_pythonobj(node)
				if node.bl_idname == 'ShaderNodeRGB':
					keys_found[node.label] = (node.bl_idname, list(node.outputs[0].default_value))
				elif node.bl_idname == 'ShaderNodeCombineXYZ':
					keys_found[node.label] = (node.bl_idname, [node.inputs[0].default_value, node.inputs[1].default_value, node.inputs[2].default_value])
				elif node.bl_idname == 'ShaderNodeValue':
					keys_found[node.label] = (node.bl_idname, node.outputs[0].default_value)
				elif node.bl_idname == 'ShaderNodeVectorCurve':
					cmapping = {}
					cmapping["curves"] = []
					for curve in node.mapping.curves:
						ccurve = {}
						ccurve["points"] = []
						for point in curve.points:
							cpoint = {}
							cpoint["handle_type"] = point.handle_type
							cpoint["location"] = copy.copy(point.location)
							cpoint["select"] = point.select
							ccurve["points"].append(cpoint)
						cmapping["curves"].append(ccurve)
					keys_found[node.label] = (node.bl_idname, cmapping)
				else:
					self.report({'ERROR'}, "Can not copy node value: "+node.label)
					return {'CANCELLED'}
		print("Copied node values", keys_found)
		self.report({'INFO'}, "Values copied="+str(len(keys_found)))
		return {'FINISHED'}

class wplnode_nodeval_paste(bpy.types.Operator):
	bl_idname = "object.wplnode_nodeval_paste"
	bl_label = "Paste #values"
	bl_options = {'REGISTER', 'UNDO'}

	opt_dryRun : BoolProperty(
			name = "Do nothing, dry run",
			default = False
	)
	opt_nodeTag : StringProperty(
			name = "Paste tagged only",
			default = ""
	)
	opt_curvesXSym : BoolProperty(
			name = "Curves: apply X symmetry",
			default = False
	)
	
	@classmethod
	def poll(cls, context):
		space = context.space_data
		return space.type == 'NODE_EDITOR'

	def execute( self, context ):
		keys_found = WPL_G_NODES.nodecopy
		if len(keys_found) == 0:
			self.report({'INFO'}, "Copy some values first")
			return {'FINISHED'}
		pasted_values = {}
		selnodes = context.selected_nodes
		if len(selnodes) == 0:
			self.report({'INFO'}, "Select some nodes first")
			return {'FINISHED'}
		if self.opt_dryRun:
			self.report({'INFO'}, "Dry run: Operation skipped (F6)")
			return {'FINISHED'}
		tag2check = self.opt_nodeTag
		isForcePasteAll = False
		if "<forceall>" in self.opt_nodeTag:
			isForcePasteAll = True
			tag2check = ""
		for node in selnodes:
			if config.kWPLNodePrefix in node.label:
				#wla_do.sys_dump_pythonobj(node)
				if node.bl_idname == 'ShaderNodeAttribute':
					# not pastable
					continue
				if isForcePasteAll == False and (node.label not in keys_found):
					print("- Skipping node, not in clipboard", node.label, node.bl_idname)
					continue
				if len(tag2check) > 0 and not(tag2check in node.label):
					print("- Skipping node, not tagged", node.label, tag2check)
					continue
				val_items = None
				if node.label in keys_found:
					val_items = keys_found[node.label]
				else:
					# TBD: by node type
					val_items = keys_found[list(keys_found.keys())[0]]
				#print("- val:", val)
				if node.bl_idname != val_items[0]:
					print("- Skipping node, saved type not compatible with node", node.label, node.bl_idname, val_items[0])
					continue
				val = val_items[1]
				pasted_values[node.label] = val
				if node.bl_idname == 'ShaderNodeRGB':
					node.outputs[0].default_value = val
				if node.bl_idname == 'ShaderNodeCombineXYZ':
					node.inputs[0].default_value = val[0]
					node.inputs[1].default_value = val[1]
					node.inputs[2].default_value = val[2]
				if node.bl_idname == 'ShaderNodeValue':
					node.outputs[0].default_value = val
				if node.bl_idname == 'ShaderNodeVectorCurve':
					if len(node.mapping.curves) == 0 or len(val["curves"]) == 0:
						print("- Skipping node, missing curves", node.label, len(node.mapping.curves), len(val["curves"]))
						self.report({'ERROR'}, "Can not paste curve: "+node.label)
						return {'CANCELLED'}
					if len(node.mapping.curves) != len(val["curves"]):
						print("! Warning: curves count not the same", node.label, len(node.mapping.curves), len(val["curves"]))
					# https://docs.blender.org/api/2.79/bpy.types.CurveMapPoint.html#bpy.types.CurveMapPoint
					for i, node_curv in enumerate(node.mapping.curves):
						if i >= len(val["curves"]):
							break
						val_curv = val["curves"][i]
						#print("..Handling curve point",node_curv,val_curv)
						while len(node_curv.points) > len(val_curv["points"]):
							p = node_curv.points[0]
							#print("..Removing point",p)
							node_curv.points.remove(p)
						while len(node_curv.points) < len(val_curv["points"]):
							#print("..Adding point")
							node_curv.points.new(0,0)
						pnt_len = len(val_curv["points"])
						for i in range(0, pnt_len):
							val_point = val_curv["points"][i]
							node_point = node_curv.points[i]
							pst_location = copy.copy(val_point["location"])
							if self.opt_curvesXSym and pst_location[0] < 0:
								# getting value from x>0 side
								symPnt = val_curv["points"][pnt_len-i-1]
								symPnt_loc = copy.copy(symPnt["location"])
								symPnt_loc = (-1*symPnt_loc[0],symPnt_loc[1])
								pst_location = symPnt_loc
							#print("..Copy from",val_point,"to",node_point)
							node_point.handle_type = val_point["handle_type"]
							node_point.location = pst_location
							node_point.select = val_point["select"]
							#wla_do.sys_dump_pythonobj(val_point)
							#wla_do.sys_dump_pythonobj(node_point)
					node.mapping.update()
		self.report({'INFO'}, "Values pasted="+str(len(pasted_values))+"; in clipboard: "+str(len(keys_found)))
		return {'FINISHED'}

# ==========================================
# ==========================================

class WPL_PT_Dedups(bpy.types.Panel):
	bl_idname = "WPL_PT_Dedups"
	bl_label = "Housekeeping"
	bl_space_type = 'VIEW_3D'
	bl_region_type = 'UI'
	bl_category = 'FINALS'

	def draw(self, context):
		col = self.layout.column()
		col.operator("object.wplheal_dedupmats", text="Scene: Dedupe materials")
		col.operator("object.wplheal_remunusdats", text="Scene: Cleanup unused")
		col.separator()
		col.operator("object.wplnode_dedupnodes", text="Dedupe NodeGroups")
		col.operator("object.wplnode_findnodeuse", text="Test nodes")

class WPL_PT_NodeCopyPaste(bpy.types.Panel):
	bl_idname = "WPL_PT_NodeCopyPaste"
	bl_label = "Node helpers"
	bl_space_type = 'NODE_EDITOR'
	bl_region_type = 'UI'
	bl_category = 'WPL'

	def draw(self, context):
		col = self.layout.column()
		col.operator("object.wplnode_nodeval_copy", text="Copy #values")
		col.operator("object.wplnode_nodeval_paste", text="Paste Tagged #values").opt_curvesXSym = False
		col.operator("object.wplnode_nodeval_paste", text="SymPaste Tagged #values").opt_curvesXSym = True
		col.operator("object.wplnode_nodeval_paste", text="Paste All/Non-tagged").opt_nodeTag = "<forceall>"
		
		col.separator()
		col.operator("object.wplnode_dedupnodes", text="Dedupe NodeGroups")
		col.operator("object.wplnode_findnodeuse", text="Test nodes")

# ==========================================
# ==========================================

classes = (
	WPL_MT_NodeGroups,

	WPL_PT_Dedups,
	wplheal_dedupmats,
	wplnode_dedupnodes,
	wplnode_findnodeuse,

	WPL_PT_NodeCopyPaste,
	wplnode_nodeval_copy,
	wplnode_nodeval_paste
)

def register():
	for cls in classes:
		bpy.utils.register_class(cls)
	try:
		ngstore = bpy.types.WindowManager.ngstore
	except:
		# print("Adding NodeGroups submenu...")
		bpy.types.NODE_MT_add.append(drawNodeGroupsRootMenu)
		bpy.types.WindowManager.ngstore = WPL_G_NODES.ngstore

def unregister():
	for cls in reversed(classes):
		bpy.utils.unregister_class(cls)
	try:
		ngstore = bpy.types.WindowManager.ngstore
		del bpy.types.WindowManager.ngstore
		bpy.types.NODE_MT_add.remove(drawNodeGroupsRootMenu)
	except:
		pass

if __name__ == "__main__":
	register()