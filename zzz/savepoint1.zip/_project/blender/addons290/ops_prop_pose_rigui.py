import os, sys, time, datetime
import math, copy, string, random
import numpy as np
import bpy, bmesh, mathutils

import bpy.types
from mathutils import Vector, Matrix, Euler, Quaternion
from mathutils.bvhtree import BVHTree
from mathutils.kdtree import KDTree
from bpy_extras import view3d_utils
from bpy.props import *

from . import config
from .tools import wla
from .tools import wla_do
from .tools import wla_attr
from .tools import wla_arma

kWPLArmHandBns_MLOW = "ctrl-thumb, ctrl-index, ctrl-middle, ctrl-ring, ctrl-pinky"
kWPLArmPartsBns_MLOW = "ctrl-elbow, ctrl-hand_IK"
kWPLLegPartsBns_MLOW = "ctrl-knee, ctrl-foot_IK"
kWPLPropsBns_MLOW = "ctrl-hand_IK, ctrl-foot_IK, rig-properties"

# ==========================================

class wplpose_ar_select(bpy.types.Operator):
	bl_idname = "object.wplpose_ar_select"
	bl_label = "Select bones by substr"
	bl_options = {'REGISTER', 'UNDO'}

	opt_bonesScope : StringProperty(
		name = "Scope Tokens",
		default = ""
	)
	opt_bones2sel : StringProperty(
		name = "Bones to select",
		default = ""
	)
	opt_execFlags : StringProperty(
		name = "Execution Flags",
		default = ""
	)

	def execute( self, context ):
		active_obj = wla.active_object()
		armatr = wla_arma.related_arma(active_obj)
		if armatr is None:
			self.report({'ERROR'}, "Works on Armature only")
			return {'CANCELLED'}
		# wla_do.select_and_change_mode(armatr,'POSE')
		bpy.ops.object.wplpose_ar_toggle(opt_postAction = 'POSE_ON')
		bpy.ops.pose.reveal()
		bpy.ops.pose.select_all(action = 'DESELECT')
		boneNames = armatr.pose.bones.keys()
		amust_val = wla.getTokenForStr(self.opt_bonesScope,"AMUST", None, None)
		layer_activate = wla.getTokenForStr(self.opt_execFlags,"LAYER", None, None)
		if layer_activate is not None:
			armatr.data.layers[int(layer_activate)] = True
		postSel = []
		hideAllOthers = False
		if "HIDEOTHERS" in self.opt_execFlags:
			hideAllOthers = True
		for boneName in boneNames:
			bone = armatr.data.bones[boneName]
			pbone = armatr.pose.bones[boneName]
			if (amust_val is not None) and not (amust_val in pbone.name):
				continue
			if wla.isTokenInStr(self.opt_bonesScope, pbone.name):
				if wla.isTokenInStr(self.opt_bones2sel, pbone.name):
					postSel.append(bone)
				elif hideAllOthers:
					# selecting all others to hide
					bone.select = True
		if hideAllOthers:
			bpy.ops.pose.hide(unselected=False)
		for psb in postSel:
			psb.select = True
		return {'FINISHED'}

class wplpose_ar_addcomm(bpy.types.Operator):
	bl_idname = "object.wplpose_ar_addcomm"
	bl_label = "Add comment"
	bl_options = {'REGISTER', 'UNDO'}

	opt_commentText : StringProperty(
		name = "Comment text",
		default = ""
	)

	def execute( self, context ):
		active_obj = wla.active_object()
		armatr = wla_arma.related_arma(active_obj)
		if armatr is None:
			self.report({'ERROR'}, "Works on Armature only")
			return {'CANCELLED'}
		
		free_idx_key = None
		for i in range(1,100):
			opt_key_obj = config.kWPLAutoSetupCustomPropComm+str(i).zfill(2)
			if opt_key_obj in armatr:
				continue
			free_idx_key = opt_key_obj
			break
		if free_idx_key is not None:
			armatr[free_idx_key] = self.opt_commentText
		return {'FINISHED'}

######################
## Rig Properties ##
######################
class MLOWRIG_PT_Toggle(bpy.types.Panel):
	"""Creates a Rig Properties Panel (Pose Bone Custom Properties)"""
	bl_label = "Rig Properties"
	bl_idname = "MLOWRIG_PT_Toggle"
	bl_space_type = 'VIEW_3D'
	bl_region_type = 'UI'
	bl_options = {'DEFAULT_CLOSED'}
	#bl_category = "SimpleRigUI"
	bl_category = "CHAR"

	@classmethod
	def poll(self, context):
		if context.mode != 'POSE':
			return False
		try:
			#return (context.active_object.type == 'ARMATURE')
			return (wla_arma.related_arma(context.active_object) is not None)
		except (TypeError):
			return False

	def draw(self, context):
		layout = self.layout
		#pose_bones = context.active_object.pose.bones
		try:
			selected_bones = [bone.name for bone in context.selected_pose_bones]
			selected_bones += [context.active_pose_bone.name]
		except (AttributeError, TypeError):
			return

		# def assign_props(row, val, key):
		# 	row.property = key
		# 	row.data_path = "pose_bone"
		# 	try:
		# 		row.value = str(val)
		# 	except:
		# 		pass
		#active_pose_bone = context.active_pose_bone
		# Iterate through selected bones add each prop property of each bone to the panel.
		for bone in context.selected_pose_bones:
			if len(bone.keys()) > 0:
				box = layout.box()
			for key in bone.keys():
				if key not in '_RNA_UI':
					val = bone.get(key, "value")
					row = box.row()
					spl = row.split(align=True, factor=0.3)
					spl.column().label(text=key, translate=False)
					spl.column().prop(bone, f'["{key}"]', text = "", slider=True)
					#print("- rig ui:", bone.name, key, val)
					
######################
## Rig Layer Panels ##
######################
class MLOWRIG_PT_Panel(bpy.types.Panel):
	bl_idname = "MLOWRIG_PT_Panel"
	bl_space_type = 'VIEW_3D'
	bl_region_type = 'UI'
	bl_label = "Rig props"
	#bl_category = 'SimpleRigUI'
	bl_category = "CHAR"
	
	@classmethod
	def poll(self, context):
		try:
			# return (context.active_object.data.get("Character_rig_id") == Character_rig_id)
			return (wla_arma.related_arma(context.active_object) is not None)
		except (AttributeError, KeyError, TypeError):
			return False

	def draw(self, context):
		arma = wla_arma.related_arma(context.active_object)
		layout = self.layout
		row = layout.row()
		col = row.column(align=True)
		col.prop(arma.data, 'layers', index=0, toggle=True, text='Head')
		col.prop(arma.data, 'layers', index=16, toggle=True, text='Body(Main)')
		row_ff = col.row(align=True)
		row_ff.prop(arma.data, 'layers', index=17, toggle=True, text='Body(Tweak)')
		row_ff.prop(arma.data, 'layers', index=1, toggle=True, text='Body(Neck)')

		row = layout.row()
		col = row.column(align=True)
		if arma.pose.bones["rig-properties"]["IK-->FK (Arm R)"] == 0:
			col.prop(arma.data, 'layers', index=21, toggle=True, text='Arm R(IK)')
			row_ff = col.row(align=True)
			p1 = row_ff.operator("object.wplpose_ar_select", text="@tip")
			p1.opt_bonesScope = kWPLArmPartsBns_MLOW+", AMUST:.R"
			p1.opt_bones2sel = wla.getTokensAsList(kWPLArmPartsBns_MLOW)[1]
			p1.opt_execFlags = "LAYER:21"
			p0 = row_ff.operator("object.wplpose_ar_select", text="@mid")
			p0.opt_bonesScope = kWPLArmPartsBns_MLOW+", AMUST:.R"
			p0.opt_bones2sel = wla.getTokensAsList(kWPLArmPartsBns_MLOW)[0]
			p0.opt_execFlags = "LAYER:21"
		else:
			col.prop(arma.data, 'layers', index=20, toggle=True, text='Arm R(FK)')
		row_ff = col.row(align=True)
		row_ff.prop(arma.data, 'layers', index=22, toggle=True, text='Tweak')
		row_ff.prop(arma.data, 'layers', index=23, toggle=True, text='Finger') 
		row_ff = col.row(align=True)
		p0 = row_ff.operator("object.wplpose_ar_select", text="T")
		p0.opt_bonesScope = kWPLArmHandBns_MLOW + ", AMUST:.R"
		p0.opt_bones2sel = wla.getTokensAsList(kWPLArmHandBns_MLOW)[0]
		p0.opt_execFlags = "HIDEOTHERS, LAYER:23"
		p1 = row_ff.operator("object.wplpose_ar_select", text="1")
		p1.opt_bonesScope = kWPLArmHandBns_MLOW + ", AMUST:.R"
		p1.opt_bones2sel = wla.getTokensAsList(kWPLArmHandBns_MLOW)[1]
		p1.opt_execFlags = "HIDEOTHERS, LAYER:23"
		p2 = row_ff.operator("object.wplpose_ar_select", text="2")
		p2.opt_bonesScope = kWPLArmHandBns_MLOW + ", AMUST:.R"
		p2.opt_bones2sel = wla.getTokensAsList(kWPLArmHandBns_MLOW)[2]
		p2.opt_execFlags = "HIDEOTHERS, LAYER:23"
		p3 = row_ff.operator("object.wplpose_ar_select", text="3")
		p3.opt_bonesScope = kWPLArmHandBns_MLOW + ", AMUST:.R"
		p3.opt_bones2sel = wla.getTokensAsList(kWPLArmHandBns_MLOW)[3]
		p3.opt_execFlags = "HIDEOTHERS, LAYER:23"
		p4 = row_ff.operator("object.wplpose_ar_select", text="4")
		p4.opt_bonesScope = kWPLArmHandBns_MLOW + ", AMUST:.R"
		p4.opt_bones2sel = wla.getTokensAsList(kWPLArmHandBns_MLOW)[4]
		p4.opt_execFlags = "HIDEOTHERS, LAYER:23"

		col = row.column(align=True)
		if arma.pose.bones["rig-properties"]["IK-->FK (Arm L)"] == 0:
			col.prop(arma.data, 'layers', index=5, toggle=True, text='Arm L(IK)')
			row_ff = col.row(align=True)
			p1 = row_ff.operator("object.wplpose_ar_select", text="@tip")
			p1.opt_bonesScope = kWPLArmPartsBns_MLOW+", AMUST:.L"
			p1.opt_bones2sel = wla.getTokensAsList(kWPLArmPartsBns_MLOW)[1]
			p1.opt_execFlags = "LAYER:5"
			p0 = row_ff.operator("object.wplpose_ar_select", text="@mid")
			p0.opt_bonesScope = kWPLArmPartsBns_MLOW+", AMUST:.L"
			p0.opt_bones2sel = wla.getTokensAsList(kWPLArmPartsBns_MLOW)[0]
			p0.opt_execFlags = "LAYER:5"
		else:
			col.prop(arma.data, 'layers', index=4, toggle=True, text='Arm L(FK)')
		row_ff = col.row(align=True)
		row_ff.prop(arma.data, 'layers', index=6, toggle=True, text='Tweak')
		row_ff.prop(arma.data, 'layers', index=7, toggle=True, text='Finger') 
		row_ff = col.row(align=True)
		p0 = row_ff.operator("object.wplpose_ar_select", text="T")
		p0.opt_bonesScope = kWPLArmHandBns_MLOW + ", AMUST:.L"
		p0.opt_bones2sel = wla.getTokensAsList(kWPLArmHandBns_MLOW)[0]
		p0.opt_execFlags = "HIDEOTHERS, LAYER:7"
		p1 = row_ff.operator("object.wplpose_ar_select", text="1")
		p1.opt_bonesScope = kWPLArmHandBns_MLOW + ", AMUST:.L"
		p1.opt_bones2sel = wla.getTokensAsList(kWPLArmHandBns_MLOW)[1]
		p1.opt_execFlags = "HIDEOTHERS, LAYER:7"
		p2 = row_ff.operator("object.wplpose_ar_select", text="2")
		p2.opt_bonesScope = kWPLArmHandBns_MLOW + ", AMUST:.L"
		p2.opt_bones2sel = wla.getTokensAsList(kWPLArmHandBns_MLOW)[2]
		p2.opt_execFlags = "HIDEOTHERS, LAYER:7"
		p3 = row_ff.operator("object.wplpose_ar_select", text="3")
		p3.opt_bonesScope = kWPLArmHandBns_MLOW + ", AMUST:.L"
		p3.opt_bones2sel = wla.getTokensAsList(kWPLArmHandBns_MLOW)[3]
		p3.opt_execFlags = "HIDEOTHERS, LAYER:7"
		p4 = row_ff.operator("object.wplpose_ar_select", text="4")
		p4.opt_bonesScope = kWPLArmHandBns_MLOW + ", AMUST:.L"
		p4.opt_bones2sel = wla.getTokensAsList(kWPLArmHandBns_MLOW)[4]
		p4.opt_execFlags = "HIDEOTHERS, LAYER:7"
		
		row = layout.row()
		col = row.column(align=True)
		if arma.pose.bones["rig-properties"]["IK-->FK (Leg R)"] == 0:
			col.prop(arma.data, 'layers', index=9, toggle=True, text='Leg R(IK)')
			row_ff = col.row(align=True)
			p1 = row_ff.operator("object.wplpose_ar_select", text="@tip")
			p1.opt_bonesScope = kWPLLegPartsBns_MLOW+", AMUST:.R"
			p1.opt_bones2sel = wla.getTokensAsList(kWPLLegPartsBns_MLOW)[1]
			p1.opt_execFlags = "LAYER:9"
			p0 = row_ff.operator("object.wplpose_ar_select", text="@mid")
			p0.opt_bonesScope = kWPLLegPartsBns_MLOW+", AMUST:.R"
			p0.opt_bones2sel = wla.getTokensAsList(kWPLLegPartsBns_MLOW)[0]
			p0.opt_execFlags = "LAYER:9"
		else:
			col.prop(arma.data, 'layers', index=8, toggle=True, text='Leg R(FK)')
		col.prop(arma.data, 'layers', index=10, toggle=True, text='Tweak') 
		
		col = row.column(align=True)
		if arma.pose.bones["rig-properties"]["IK-->FK (Leg L)"] == 0:
			col.prop(arma.data, 'layers', index=25, toggle=True, text='Leg L(IK)')
			row_ff = col.row(align=True)
			p1 = row_ff.operator("object.wplpose_ar_select", text="@tip")
			p1.opt_bonesScope = kWPLLegPartsBns_MLOW+", AMUST:.L"
			p1.opt_bones2sel = wla.getTokensAsList(kWPLLegPartsBns_MLOW)[1]
			p1.opt_execFlags = "LAYER:25"
			p0 = row_ff.operator("object.wplpose_ar_select", text="@mid")
			p0.opt_bonesScope = kWPLLegPartsBns_MLOW+", AMUST:.L"
			p0.opt_bones2sel = wla.getTokensAsList(kWPLLegPartsBns_MLOW)[0]
			p0.opt_execFlags = "LAYER:25"
		else:
			col.prop(arma.data, 'layers', index=24, toggle=True, text='Leg L(FK)')
		col.prop(arma.data, 'layers', index=26, toggle=True, text='Tweak')
		
		row = layout.row()
		# col = row.column(align=True)
		spl = row.split(align=True, factor = 0.8)
		spl.prop(arma.data, 'layers', index=11, toggle=True, text='Root')
		p0 = spl.operator("object.wplpose_ar_select", text="@opts")
		p0.opt_bonesScope = kWPLPropsBns_MLOW
		p0.opt_bones2sel = kWPLPropsBns_MLOW
		p0.opt_execFlags = ""

		# Armature comments
		col = layout.column()
		col.separator()
		box = col.box()
		for i in range(1,100):
			opt_key_obj = config.kWPLAutoSetupCustomPropComm+str(i).zfill(2)
			if opt_key_obj in arma:
				box.prop(arma, f'["{opt_key_obj}"]', text = "// "+str(i).zfill(2))
		box.operator("object.wplpose_ar_addcomm", text="Add Comment")

classes = (
	MLOWRIG_PT_Panel,
	MLOWRIG_PT_Toggle,
	wplpose_ar_select,
	wplpose_ar_addcomm
)

def register():
	for cls in classes:
		bpy.utils.register_class(cls)

def unregister():
	for cls in reversed(classes):
		bpy.utils.unregister_class(cls)

if __name__ == "__main__":
	register()