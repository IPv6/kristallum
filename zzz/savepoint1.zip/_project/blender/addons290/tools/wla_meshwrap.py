import os, sys, time, datetime
import math, copy, string, random
import hashlib
import numpy as np
import bpy, bmesh, mathutils

import bpy.types
from mathutils import Vector, Matrix, Euler, Quaternion
from mathutils.bvhtree import BVHTree
from mathutils.kdtree import KDTree
from bpy_extras import view3d_utils
from bpy.props import *

from . import wla
from . import wla_do
from . import wla_bm
from . import wla_curve
from .. import config

kWPLMESHWRAP_TYPES = ['MESH', 'CURVE', 'LATTICE', 'GPENCIL']
kWPL_MESHVERKey = "mesh_version"
kWPL_OBJNAMEKey = "obj_name"
kWPL_NoFocusChanges = "no_focus_changes"
GG_MAXPOINT_ON_CURVE = 1000
GP_MAXPOINT_ON_CURVE = 1000
GP_STROKES_ON_LAYER = 1000000
# ======================================================
# Idea/code parts taken from MESH_OT_bezier_mesh_shaper
# xxx remove refIdx? mesh/lattice: not needed, curve i*1000+j -> mapping ok
# TBD: shapekey support?
# TBD: Support NURBSSurface?

def meshwrap_objData(psb_obj):
	if isinstance(psb_obj, (BMSNormalMesh, BMSCurveMesh, BMSLatticeMesh, BMSGpencilMesh)):
		opts = psb_obj.opts
		obj = wla.object_by_name(opts[kWPL_OBJNAMEKey])
		if obj is None:
			return None, None
		if opts is not None:
			if kWPL_MESHVERKey in opts:
				return obj, wla.sys_objdata_by_name(obj, opts[kWPL_MESHVERKey])
	else:
		obj = psb_obj
	return obj, obj.data

class BMSVirtualVertex:
	GG_VVIDX = 1
	def __init__(self, co, normal, radius, vIndex, refIdx):
		if vIndex is None:
			self.index = BMSVirtualVertex.GG_VVIDX
			BMSVirtualVertex.GG_VVIDX = BMSVirtualVertex.GG_VVIDX+1
		else:
			# for binding stable index is REQUIRED
			self.index = vIndex
		self.refIdx = refIdx
		self.normal = copy.copy(normal)
		self._co = copy.copy(co)
		self._radius = radius
		self._hide = False
		self._select = False
		self.dirty_co = False
		self.dirty_sel = False
		self.dirty_rad = False

	@property
	def co(self):
		return self._co
	@co.setter
	def co(self, value):
		self._co = value
		self.dirty_co = True

	@property
	def radius(self):
		return self._radius
	@radius.setter
	def radius(self, value):
		self._radius = value
		self.dirty_rad = True

	@property
	def select(self):
		return self._select
	@select.setter
	def select(self, value):
		self._select = value
		self.dirty_sel = True

	@property
	def hide(self):
		return self._hide
	@hide.setter
	def hide(self, value):
		self._hide = value
		self.dirty_sel = True
# ---
class BMSNormalMesh:
	def __init__(self, obj, opts):
		if opts is None:
			opts = {}
		opts[kWPL_OBJNAMEKey] = obj.name
		self.opts = opts
		self.vertices = {}
		self.vvindexes = []
		self.vvindexes_sel = []
		# self.vvindexes_hid = []
		# self.vvindexes_nonhid = []
		obj, obj_dat = meshwrap_objData(self)
		for v in obj_dat.vertices:
			vv = BMSVirtualVertex(co=v.co, normal=v.normal, radius=0.0, vIndex=v.index, refIdx=v.index)
			self.vvindexes.append(vv.index)
			self.vertices[vv.index] = vv
			if v.select:
				vv._select = True
				self.vvindexes_sel.append(vv.index)
			# if v.hide:
			# 	vv._hide = True
			# 	self.vvindexes_hid.append(vv.index)
			# else:
			# 	self.vvindexes_nonhid.append(vv.index)
		# print("BMSNormalMesh: all:"+str(len(self.vvindexes))+" sel:"+str(len(self.vvindexes_sel))+" hid:"+str(len(self.vvindexes_hid)))

	def all_vertsIdx(self):
		return self.vvindexes
	def selected_vertsIdx(self):
		return self.vvindexes_sel
	# def hidden_vertsIdx(self, isHidden):
	# 	if isHidden == False:
	# 		return self.vvindexes_nonhid
	# 	return self.vvindexes_hid
	def vert_unwrap(self, vv):
		_, obj_dat = meshwrap_objData(self)
		v = obj_dat.vertices[vv.refIdx]
		return (v)
	def to_mesh(self):
		# getting object by name - or obj links may be broken by UNDO
		obj, obj_dat = meshwrap_objData(self)
		if (kWPL_NoFocusChanges not in self.opts) or self.opts[kWPL_NoFocusChanges] == False:
			wla_do.select_and_change_mode(obj,'OBJECT')
		dirty_verts = 0
		dirty_verts_sel = 0
		verts_sel_new = {}
		for vvIdx in self.vvindexes:
			vv = self.vertices[vvIdx]
			if vv.dirty_co:
				v = obj_dat.vertices[vv.refIdx]
				v.co = vv._co
				vv.dirty_co = False
				dirty_verts = dirty_verts+1
			if vv._select:
				verts_sel_new[vv.refIdx] = vv._select
			if vv.dirty_sel:
				vv.dirty_sel = False
				dirty_verts_sel = dirty_verts_sel+1
		if dirty_verts_sel > 0:
			#bpy.ops.mesh.select_all(action = 'DESELECT')
			for polygon in obj_dat.polygons:
				polygon.select = False
			for edge in obj_dat.edges:
				edge.select = False
			for vert in obj_dat.vertices:
				if vert.index in verts_sel_new:
					vert.select = verts_sel_new[vert.index]
				else:
					vert.select = False
			# for pp in dirty_verts_sel:
			# 	v = obj_dat.vertices[pp[0]]
			# 	v.select = True
			# wla_do.select_and_change_mode(obj,'EDIT')
			# bm = bmesh.from_edit_mesh(obj_dat)
			# bm.verts.ensure_lookup_table()
			# bm.verts.index_update()
			# for pp in dirty_verts_sel:
			# 	v = bm.verts[pp[0]]
			# 	v.select = False #pp[1]
			# bmesh.update_edit_mesh(obj_dat)
			# wla_do.select_and_change_mode(obj,'OBJECT')
		#print("- DBG: to_mesh: updated verts:", dirty_verts, len(self.vvindexes), len(dirty_verts_sel))
# ---
class BMSCurveMesh:
	def __init__(self, obj, opts):
		if opts is None:
			opts = {}
		opts[kWPL_OBJNAMEKey] = obj.name
		self.opts = opts
		self.vertices = {}
		self.vvindexes = []
		self.vvindexes_sel = []
		#self.vvindexes_active = []
		# self.vvindexes_hid = []
		# self.vvindexes_nonhid = []
		obj, obj_dat = meshwrap_objData(self)
		camera_gCo, _, _, _ = wla.active_camera()
		camera_lCo = obj.matrix_world.inverted() @ camera_gCo
		for i, polyline in enumerate(obj_dat.splines):
			allpt = wla_curve.cu_getPoints(polyline)
			if len(allpt) < 2:
				continue
			selpt = wla_curve.cu_getPointsSel(polyline)
			#isActiveFound = False
			for j, p in enumerate(allpt):
				pt_co = p.co.to_3d()
				pr_dir = Vector((0,0,1))
				if j < len(allpt)-1:
					ptn_co = allpt[j+1].co.to_3d()
					pr_dir = ptn_co-pt_co
				else:
					ptp_co = allpt[j-1].co.to_3d()
					pr_dir = pt_co-ptp_co
				pt_tan = pr_dir.normalized()
				pt_camd = (camera_lCo-pt_co).normalized()
				pt_no = pt_camd.cross(pt_tan).cross(pt_camd).normalized()
				refIdx = (i,j)
				vv = BMSVirtualVertex(co=pt_co, normal=pt_no, radius=p.radius, vIndex=i*GG_MAXPOINT_ON_CURVE+j, refIdx=refIdx)
				self.vertices[vv.index] = vv
				self.vvindexes.append(vv.index)
				if p in selpt:
					vv._select = True
					self.vvindexes_sel.append(vv.index)
					# if isActiveFound == False:
					# 	isActiveFound = True
					# self.vvindexes_active.append(vv.index)
				# if p.hide:
				# 	vv._hide = True
				# 	self.vvindexes_hid.append(vv.index)
				# else:
				# 	self.vvindexes_nonhid.append(vv.index)

	def all_vertsIdx(self):
		return self.vvindexes
	def selected_vertsIdx(self):
		return self.vvindexes_sel
	# def hidden_vertsIdx(self, isHidden):
	# 	if isHidden == False:
	# 		return self.vvindexes_nonhid
	# 	return self.vvindexes_hid
	# def recent_vertsIdx(self):
	# 	return self.vvindexes_active
	def vert_unwrap(self, vv):
		_, obj_dat = meshwrap_objData(self)
		polyline = obj_dat.splines[ vv.refIdx[0] ]
		allpt = wla_curve.cu_getPoints(polyline)
		point = allpt[ vv.refIdx[1] ]
		return (point, polyline)
	def to_mesh(self):
		_, obj_dat = meshwrap_objData(self)
		for vIdx in self.vvindexes:
			vv = self.vertices[vIdx]
			if vv.dirty_co:
				polyline = obj_dat.splines[ vv.refIdx[0] ]
				allpt = wla_curve.cu_getPoints(polyline)
				point = allpt[ vv.refIdx[1] ]
				point.co[:3] = vv._co
				vv.dirty_co = False
			if vv.dirty_rad:
				polyline = obj_dat.splines[ vv.refIdx[0] ]
				allpt = wla_curve.cu_getPoints(polyline)
				point = allpt[ vv.refIdx[1] ]
				point.radius = vv._radius
				vv.dirty_rad = False
			if vv.dirty_sel:
				polyline = obj_dat.splines[ vv.refIdx[0] ]
				allpt = wla_curve.cu_getPoints(polyline)
				point = allpt[ vv.refIdx[1] ]
				wla_curve.cu_setSel(point, vv._select)
				vv.dirty_sel = False
# ---
class BMSLatticeMesh:
	def __init__(self, obj, opts):
		if opts is None:
			opts = {}
		opts[kWPL_OBJNAMEKey] = obj.name
		self.opts = opts
		self.vertices = {}
		self.vvindexes = []
		self.vvindexes_sel = []
		obj, obj_dat = meshwrap_objData(self)
		for i, point in enumerate(obj_dat.points):
			# normal - LocalZ или по наименьшей размерности
			norml = Vector((0,0,1)) # obj.data.point_w < min(obj.data.point_u, obj.data.point_v):
			if obj.data.point_u < min(obj.data.point_v, obj.data.point_w):
				norml = Vector((1,0,0))
			if obj.data.point_v < min(obj.data.point_u, obj.data.point_w):
				norml = Vector((0,1,0))
			vv = BMSVirtualVertex(co=point.co_deform.copy(), normal=norml, radius=0.0, vIndex=i, refIdx=i)
			self.vvindexes.append(vv.index)
			self.vertices[vv.index] = vv
			if point.select:
				self.vvindexes_sel.append(vv.index)

	def all_vertsIdx(self):
		return self.vvindexes
	def selected_vertsIdx(self):
		return self.vvindexes_sel
	# def hidden_vertsIdx(self, isHidden):
	# 	return None
	# def recent_vertsIdx(self):
	# 	return None
	def vert_unwrap(self, vv):
		_, obj_dat = meshwrap_objData(self)
		v = obj_dat.points[vv.refIdx]
		return (v)
	def to_mesh(self):
		# getting object by name - or obj links may be broken by UNDO
		_, obj_dat = meshwrap_objData(self)
		dirty_verts = 0
		for vvIdx in self.vvindexes:
			vv = self.vertices[vvIdx]
			if vv.dirty_co:
				v = obj_dat.points[vv.refIdx]
				v.co_deform = vv._co
				vv.dirty_co = False
				dirty_verts = dirty_verts+1
# ---
class BMSGpencilMesh:
	def __init__(self, obj, opts):
		if opts is None:
			opts = {}
		opts[kWPL_OBJNAMEKey] = obj.name
		self.opts = opts
		self.vertices = {}
		self.vvindexes = []
		self.vvindexes_sel = []
		obj, obj_dat = meshwrap_objData(self)
		camera_gCo, _, _, _ = wla.active_camera()
		camera_lCo = obj.matrix_world.inverted() @ camera_gCo
		for i1, layer in enumerate(obj_dat.layers):
			for i2, polyline in enumerate(layer.active_frame.strokes):
				allpt = wla_curve.cu_getPoints(polyline)
				if len(allpt) < 2:
					continue
				selpt = wla_curve.cu_getPointsSel(polyline)
				for j, p in enumerate(allpt):
					pt_co = p.co.to_3d()
					pr_dir = Vector((0,0,1))
					if j < len(allpt)-1:
						ptn_co = allpt[j+1].co.to_3d()
						pr_dir = ptn_co-pt_co
					else:
						ptp_co = allpt[j-1].co.to_3d()
						pr_dir = pt_co-ptp_co
					pt_tan = pr_dir.normalized()
					pt_camd = (camera_lCo-pt_co).normalized()
					pt_no = pt_camd.cross(pt_tan).cross(pt_camd).normalized()
					refIdx = (i1,i2,j) # order used in outline rebounds
					vv = BMSVirtualVertex(co=pt_co, normal=pt_no, radius=p.pressure, vIndex=i1*GP_STROKES_ON_LAYER + i2*GP_MAXPOINT_ON_CURVE + j, refIdx=refIdx)
					self.vertices[vv.index] = vv
					self.vvindexes.append(vv.index)
					if p in selpt:
						vv._select = True
						self.vvindexes_sel.append(vv.index)

	def all_vertsIdx(self):
		return self.vvindexes
	def selected_vertsIdx(self):
		return self.vvindexes_sel
	def vert_unwrap(self, vv):
		_, obj_dat = meshwrap_objData(self)
		layer = obj_dat.layers[ vv.refIdx[0] ]
		polyline = layer.active_frame.strokes[ vv.refIdx[1] ]
		allpt = wla_curve.cu_getPoints(polyline)
		point = allpt[ vv.refIdx[2] ]
		return (point, polyline, layer)
	def to_mesh(self):
		_, obj_dat = meshwrap_objData(self)
		for vIdx in self.vvindexes:
			vv = self.vertices[vIdx]
			if vv.dirty_co:
				layer = obj_dat.layers[ vv.refIdx[0] ]
				polyline = layer.active_frame.strokes[ vv.refIdx[1] ]
				allpt = wla_curve.cu_getPoints(polyline)
				point = allpt[ vv.refIdx[2] ]
				point.co[:3] = vv._co
				vv.dirty_co = False
			if vv.dirty_rad:
				layer = obj_dat.layers[ vv.refIdx[0] ]
				polyline = layer.active_frame.strokes[ vv.refIdx[1] ]
				allpt = wla_curve.cu_getPoints(polyline)
				point = allpt[ vv.refIdx[2] ]
				point.pressure = vv._radius
				vv.dirty_rad = False
			if vv.dirty_sel:
				layer = obj_dat.layers[ vv.refIdx[0] ]
				polyline = layer.active_frame.strokes[ vv.refIdx[1] ]
				allpt = wla_curve.cu_getPoints(polyline)
				point = allpt[ vv.refIdx[2] ]
				point.select = vv._select
				vv.dirty_sel = False
# ==============================================================

def object_wrappedmesh(obj, opts = None):
	if bpy.context.mode != 'OBJECT':
		print("- object_wrappedmesh: WARNING: reswitching to OBJECT mode")
		wla_do.select_and_change_mode(obj,'OBJECT')
	if obj.type == 'MESH':
		return BMSNormalMesh(obj, opts)
	if obj.type == 'CURVE':
		return BMSCurveMesh(obj, opts)
	if obj.type == 'LATTICE':
		return BMSLatticeMesh(obj, opts)
	if obj.type == 'GPENCIL':
		return BMSGpencilMesh(obj, opts)
	return None

# def objectm_shpverts(obj, cacher):
# 	# shapekey support
# 	if obj is None or obj.type != 'MESH':
# 		return None, None, None
# 	if cacher is not None and ("omv_"+obj.name+"_v" in cacher):
# 		return cacher["omv_"+obj.name+"_v"] #, cacher["omv_"+obj.name+"_n"], cacher["omv_"+obj.name+"_i"]
# 	normals = {}
# 	# bmesg - shape_lay = bm.verts.layers.shape["Key.001"]!!
# 	if obj.active_shape_key is not None:
# 		# https://github.com/JoshRBogart/unreal_tools/blob/66dce507507b0560b79b2262eb8eb90f52a151b8/mesh_morpher.py
# 		verts = obj.active_shape_key.data
# 		#normals_tris = obj.active_shape_key.normals_vertex_get()
# 		#normals_list = list(zip(*[iter(normals_tris)]*3))
# 		#vertidx = []
# 		# for v in obj.data.vertices:
# 		# 	vertidx.append(v.index)
# 		# for n in normals_list:
# 		# 	normals.append(Vector((n[0], n[1], n[2])))
# 		if cacher is not None:
# 			cacher["omv_"+obj.name+"_v"] = verts
# 			#cacher["omv_"+obj.name+"_n"] = normals
# 			#cacher["omv_"+obj.name+"_i"] = vertidx
# 		return verts #, normals, vertidx
# 	verts = obj.data.vertices
# 	# for v in obj.data.vertices:
# 	# 	normals[v.index] = v.normal
# 	# vertidx = []
# 	# for v in obj.data.vertices:
# 	# 	vertidx.append(v.index)
# 	if cacher is not None:
# 		cacher["omv_"+obj.name+"_v"] = verts
# 		# cacher["omv_"+obj.name+"_n"] = normals
# 		# cacher["omv_"+obj.name+"_i"] = vertidx
# 	return verts #, normals, vertidx

def objectm_extractEdgesByType(src_obj):
	if src_obj is None or src_obj.type != 'MESH':
		return None, None
	fs_edgesIdx = []
	sh_edgesIdx = []
	for e in src_obj.data.edges:
		if e.use_freestyle_mark:
			fs_edgesIdx.append(e.index)
		if e.use_edge_sharp:
			sh_edgesIdx.append(e.index)
	# e.use_seam
	return fs_edgesIdx, sh_edgesIdx

def objectm_extractVertsByType(src_obj):
	if src_obj is None or src_obj.type != 'MESH':
		return None, None
	# for i in f.loop_indices:
	# 	fe = copyObj.data.edges[copyObj.data.loops[i].edge_index]
	# 	if fe.use_seam:
	# 		for fevIdx in f.vertices:
	seam_vertsIdx = []
	crease_vertsIdx = []
	for e in src_obj.data.edges:
		if e.crease > 0.1:
			for evIdx in e.vertices:
				if (evIdx not in crease_vertsIdx):
					crease_vertsIdx.append(evIdx)
		if e.use_seam:
			for evIdx in e.vertices:
				if (evIdx not in seam_vertsIdx):
					seam_vertsIdx.append(evIdx)
	return seam_vertsIdx, crease_vertsIdx

def objectm_polygonsOfVerts(src_obj, vertsIdx, countOnAnyVert):
	wla_do.select_and_change_mode(src_obj, 'OBJECT')
	faces = set()
	for f in src_obj.data.polygons:
		if countOnAnyVert:
			if any([ (vIdx in vertsIdx) for vIdx in f.vertices]):
				faces.add(f.index)
		else:
			if all([ (vIdx in vertsIdx) for vIdx in f.vertices]):
				faces.add(f.index)
	return list(faces)

def objectm_vertsOfPolygons(src_obj, facesIdx):
	wla_do.select_and_change_mode(src_obj, 'OBJECT')
	verts = set()
	for fIdx in facesIdx:
		f = src_obj.data.polygons[fIdx]
		for fevIdx in f.vertices:
			fev = src_obj.data.vertices[fevIdx]
			verts.add(fev)
	return list(verts)

def objectm_edgesOfPolygons(src_obj, facesIdx):
	wla_do.select_and_change_mode(src_obj, 'OBJECT')
	edges = set()
	for fIdx in facesIdx:
		f = src_obj.data.polygons[fIdx]
		for i in f.loop_indices:
			fe = src_obj.data.edges[src_obj.data.loops[i].edge_index]
			edges.add(fe)
	return list(edges)

def objectm_polygonsStepOut(cnt, src_obj, facesIdx):
	faceVrtsIdx = set()
	for f in src_obj.data.polygons:
		if f.index not in facesIdx:
			continue
		faceVrtsIdx = faceVrtsIdx.union(f.vertices)
	while cnt>0:
		cnt = cnt-1
		facesIdx2 = set()
		faceVrtsIdx2 = set(faceVrtsIdx)
		isAnyAdded = 0
		for f in src_obj.data.polygons:
			if any( [vIdx in faceVrtsIdx for vIdx in f.vertices] ):
				facesIdx2.add(f.index)
				faceVrtsIdx2 = faceVrtsIdx2.union(f.vertices)
				if f.index not in facesIdx:
					isAnyAdded = isAnyAdded+1
		if isAnyAdded == 0:
			break
		#print(" - step out", cnt, len(facesIdx), len(facesIdx2))
		facesIdx = facesIdx2
		faceVrtsIdx = faceVrtsIdx2
	return list(facesIdx)

def objectm_vertsStepOut(cnt, src_obj, vertsIdx):
	facesIdx = objectm_polygonsOfVerts(src_obj, vertsIdx, True)
	facesIdx2 = objectm_polygonsStepOut(cnt, src_obj, facesIdx)
	verts2 = objectm_vertsOfPolygons(src_obj, facesIdx2)
	vertsIdx2 = [v.index for v in verts2]
	return vertsIdx2, facesIdx2

def objectm_selection_to_bmStrands(src_obj):
	wla_do.select_and_change_mode(src_obj, 'OBJECT')
	active_mesh = src_obj.data
	vertsIdx = wla.selected_vertsIdx(active_mesh)
	edgesIdx = wla.selected_edgesIdx(active_mesh)
	if len(vertsIdx) == 0:
		return None, None
	wla_do.select_and_change_mode(src_obj,'EDIT')
	bm = bmesh.from_edit_mesh(active_mesh)
	bm.verts.ensure_lookup_table()
	bm.verts.index_update()
	bm.edges.ensure_lookup_table()
	bm.edges.index_update()
	strands_vidx = None
	if len(edgesIdx) < len(vertsIdx)-1:
		# some verts - no edges -> using history verts
		hist_vertsIdx = wla_bm.bm_historyVertsIdx(bm)
		if len(hist_vertsIdx) > 2:
			hist_vertsIdx = list(reversed(hist_vertsIdx))
			if len(hist_vertsIdx) > len(vertsIdx):
				hist_vertsIdx = hist_vertsIdx[:len(vertsIdx)]
			strands_vidx = [hist_vertsIdx]
	if strands_vidx is None:
		opt_flowDir = Vector((0,0,-1))
		_, strands_vidx = wla_bm.bm_edgesAsStrands_v04(src_obj, bm, vertsIdx, edgesIdx, opt_flowDir, None)
	return bm, strands_vidx

def meshwrap_recent_vertsIdx(meshwrap):
	obj, obj_dat = meshwrap_objData(meshwrap)
	if obj is None or obj.type != 'MESH':
		return []
	wla_do.select_and_change_mode(obj,'EDIT')
	bm = bmesh.from_edit_mesh(obj_dat)
	bm.verts.ensure_lookup_table()
	bm.verts.index_update()
	histVertsIdx = wla_bm.bm_historyVertsIdx(bm)
	wla_do.select_and_change_mode(obj,'OBJECT')
	vv_history = []
	if len(histVertsIdx) > 0:
		for rvIdx in histVertsIdx:
			for vvIdx in meshwrap.vvindexes:
				vv = meshwrap.vertices[vvIdx]
				if vv.refIdx == rvIdx:
					vv_history.append(vv.index)
	return vv_history

def meshwrap_vertsStepOut(meshwrap, vvIdxes, nearLoops):
	obj, obj_dat = meshwrap_objData(meshwrap)
	if obj is None:
		return []
	if obj.type != 'MESH':
		return meshwrap.all_vertsIdx()
	vertsIdx = []
	for vvIdx in vvIdxes:
		vv = meshwrap.vertices[vvIdx]
		vertsIdx.append(vv.refIdx)
	vertsIdx, _ = objectm_vertsStepOut(nearLoops, obj, vertsIdx)
	#vertsIdx = [v.index for v in verts2]
	# wla_do.select_and_change_mode(obj,'EDIT')
	# bm = bmesh.from_edit_mesh(obj_dat)
	# bm.verts.ensure_lookup_table()
	# bm.verts.index_update()
	# #vertsIdx = wla_bm.bm_historyVertsIdx(bm)
	# vertsIdx = set()
	# for vvIdx in vvIdxes:
	# 	vv = meshwrap.vertices[vvIdx]
	# 	v = bm.verts[vv.refIdx]
	# 	nearVerts = set()
	# 	wla_bm.bm_vertExtendByFaces(v, nearVerts, nearLoops, ignoreHidden)
	# 	for v2 in nearVerts:
	# 		vertsIdx.add(v2.index)
	# wla_do.select_and_change_mode(obj,'OBJECT')
	#vertsIdx = list(vertsIdx)
	vv_verts = []
	if len(vertsIdx) > 0:
		for rvIdx in vertsIdx:
			for vvIdx in meshwrap.vvindexes:
				vv = meshwrap.vertices[vvIdx]
				if vv.refIdx == rvIdx:
					vv_verts.append(vv.index)
	return vv_verts

# def object_meshfKey(active_mesh, meshf):
# 	vcos = []
# 	for vi in meshf.vertices:
# 		v = active_mesh.vertices[vi]
# 		vcos.append(wla.coToKey(v.co))
# 	vcos.sort()
# 	return ",".join(vcos)

def meshwrap_objCoHash(obj):
	meshwrap = object_wrappedmesh(obj)
	if meshwrap is None:
		return ''
	cokks = set()
	for vvIdx in meshwrap.vvindexes:
		vv = meshwrap.vertices[vvIdx]
		cokks.add(wla.coToKey(vv.co))
	cokks = ''.join(sorted(cokks))
	return hashlib.md5(cokks.encode()).hexdigest()

def objectm_vertsAvgCo(obj, deflCo, onlySel, withDeforms):
	active_pos = deflCo
	if obj is None:
		return active_pos
	if obj.type == 'GPENCIL':
		from . import wla_curve
		# special case
		pos = Vector((0, 0, 0))
		pos_cnt = 0.0
		splines = wla_curve.cu_getSplines(obj)
		for i, polyline in enumerate(splines):  # for strand point
			points = wla_curve.cu_getPoints(polyline)
			for pt in points:
				if pt.select:
					pos = pos + pt.co
					pos_cnt = pos_cnt+1.0
		if pos_cnt > 0:
			pos_g = obj.matrix_world @ (pos / pos_cnt)
			return pos_g
	if obj.type != 'MESH':
		return active_pos
	selverts = wla.selected_vertsIdx(obj.data)
	if len(selverts) > 0:
		pos = Vector((0, 0, 0))
		pos_cnt = 0.0
		if withDeforms:
			depsgraph = bpy.context.evaluated_depsgraph_get()
			bm_tmp = bmesh.new()
			bm_tmp.from_object( obj, depsgraph )
			bm_tmp.verts.ensure_lookup_table()
			for v in bm_tmp.verts:
				if onlySel == False or v.select:
					pos = pos + v.co
					pos_cnt = pos_cnt+1.0
			bm_tmp.free()
		else:
			for v in obj.data.vertices:
				if onlySel == False or v.select:
					pos = pos + v.co
					pos_cnt = pos_cnt+1.0
		if pos_cnt > 0:
			active_pos = obj.matrix_world @ (pos/pos_cnt)
	return active_pos
