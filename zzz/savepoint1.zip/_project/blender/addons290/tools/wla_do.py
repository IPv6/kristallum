import os, sys, time, datetime
import math, copy, string, random
import numpy as np
import bpy, bmesh, mathutils
from mathutils import Vector, Matrix, Euler, Quaternion

import importlib, glob, logging
import subprocess

from .. import config
from . import wla
from . import wla_attr

kWPLModifsHeavies = ['SUBSURF','SOLIDIFY','BEVEL','EDGE_SPLIT','MULTIRES','NODES','#vgs'] # config.kWPLSuppVGScriptToken
kWPLModifsIndexBreakers = ['MASK','SOLIDIFY','BEVEL','EDGE_SPLIT','MULTIRES','NODES','#vgs'] # SUBSURF ok!!!
kWPLModifsIndexBreakersStrict = ['SUBSURF'] + kWPLModifsIndexBreakers
kWPLSuppVGScriptPropDefValue = 1

# ===============================
# related: https://github.com/animate1978/MB-Lab/blob/a668937260929cc16633ea118cbe3834dc79ea7f/algorithms.py

def deselect_all_objects():
	for obj in bpy.data.objects:
		obj.select_set(False)

def set_active_object(obj):
	if obj:
		if bpy.context.view_layer.objects.get(obj.name) is None:
			print("- set_active_object: skipped, object", obj.name,"not in",bpy.context.view_layer.name)
			return False
		bpy.context.view_layer.objects.active = obj
		return True
	return False

def ensure_visible(obj, forced):
	if obj is None:
		return
	if obj.hide_viewport == True:
		obj.hide_viewport = False
	obj.hide_set(False)
	need_vlupd = False
	if forced >= 1:
		if wla.is_local_view() and obj.local_view_get(bpy.context.space_data) == False:
			# moving into local view - or many ops will fail
			#print("- ensure_visible: moving into local view", obj.name)
			obj.local_view_set(bpy.context.space_data, state = True)
			need_vlupd = True
		if forced >= 2:
			# all collections for this object must be active in current view_layer
			active_vl = bpy.context.view_layer
			obj_colnames = [col.name for col in obj.users_collection]
			lc_all = view_layer_asllchildren(active_vl.layer_collection.children, False)
			for lc in lc_all:
				if lc.exclude and lc.name in obj_colnames:
					print("- ensure_visible: enabling collection",lc.name,"for object",obj.name)
					lc.hide_viewport = False
					lc.exclude = False
					need_vlupd = True
	if need_vlupd:
		bpy.context.view_layer.update()

def select_and_activate_multi(select_objs, active_obj = None):
	if select_objs is None or len(select_objs) == 0:
		if active_obj is not None:
			select_and_change_mode(active_obj, 'OBJECT')
		return
	select_and_change_mode(select_objs[0], 'OBJECT')
	for obj in select_objs:
		obj.select_set(True)
	if active_obj is not None:
		active_obj.select_set(True)
		set_active_object(active_obj)

def select_and_change_mode(obj, obj_mode):
	old_mode = bpy.context.mode
	if obj_mode == "EDIT_MESH" or obj_mode == "EDIT_CURVE" or obj_mode == "EDIT_ARMATURE" or obj_mode == "EDIT_LATTICE":
		obj_mode = "EDIT"
	if obj_mode == "PAINT_VERTEX":
		obj_mode = "VERTEX_PAINT"
	if obj_mode == "PAINT_WEIGHT":
		obj_mode = "WEIGHT_PAINT"
	if obj.type == 'GPENCIL' and obj_mode == "EDIT":
		obj_mode = "EDIT_GPENCIL"
	if (obj is not None and bpy.context.view_layer.objects.active != obj) or old_mode != 'OBJECT':
		# stepping out from currently active object mode, or switch may fail
		try:
			bpy.ops.object.mode_set(mode='OBJECT')
		except Exception as e:
			#print("select_and_change_mode: failed to prep mode", obj.name, old_mode, e)
			pass
	deselect_all_objects()
	if obj:
		ensure_visible(obj, 0)
		obj.select_set(True)
		set_active_object(obj)
		try:
			bpy.ops.object.mode_set(mode=obj_mode)
			#print("select_and_change_mode: Select and change mode of", obj.name, obj_mode)
		except Exception as e:
			print("select_and_change_mode: Can't change the mode of", obj.name, obj_mode, e)
	return old_mode

def select_objs_by_name(names):
	deselect_all_objects()
	for name in names:
		if name in bpy.data.objects:
			obj = bpy.data.objects[name]
			obj.select_set(True)

def unlink_object_from_coll(obj, prohib_colls):
	obj_colls = obj.users_collection
	for coll in obj_colls:
		if prohib_colls is None:
			coll.objects.unlink(obj)
		else:
			for coll2 in obj_colls:
				if coll2 in coll.name:
					coll.objects.unlink(obj)
					break

def link_object_to_scene(obj, parentobj_or_collname = None, coll_exclusive = 0):
	if obj is None:
		return
	ensure_visible(obj, 2)
	childlist = wla.all_childs_recursive(obj)
	childlist.append(obj)
	if parentobj_or_collname is None:
		print("- link_object_to_scene:", obj.name, "-> scene", len(childlist))
		coll_objs = bpy.context.scene.collection.objects
		if coll_exclusive > 0:
			for obj_ch in childlist:
				if coll_objs.get(obj_ch.name) is None or len(obj_ch.users_collection) > 1:
					unlink_object_from_coll(obj_ch, None)
		# with all childs
		for obj_ch in childlist:
			if coll_objs.get(obj_ch.name) is None:
				coll_objs.link(obj_ch)
		bpy.context.view_layer.update()
		return
	if isinstance(parentobj_or_collname, str): # collection
		coll_objs = wla.sys_collection(parentobj_or_collname).objects
		if coll_exclusive > 0:
			for obj_ch in childlist:
				if coll_objs.get(obj_ch.name) is None or len(obj_ch.users_collection) > 1:
					unlink_object_from_coll(obj_ch, None)
		if coll_objs.get(obj.name) is None:
			print("- link_object_to_scene:", obj.name, "->", parentobj_or_collname, len(childlist))
			# with all childs
			for obj_ch in childlist:
				if coll_objs.get(obj_ch.name) is None:
					coll_objs.link(obj_ch)
			bpy.context.view_layer.update()
		return
	# parentobj_or_collname = object
	objType = getattr(parentobj_or_collname, 'type', '')
	if (objType is not None) and (obj.parent != parentobj_or_collname or coll_exclusive > 1):
		if coll_exclusive > 0:
			# with all childs
			for obj_ch in childlist:
				if len(obj_ch.users_collection) > 0:
					unlink_object_from_coll(obj_ch, None)
		# parenting and adding to same collections
		if obj.parent != parentobj_or_collname:
			#print("- reparenting", obj.parent, parentobj_or_collname)
			obj.parent = parentobj_or_collname
		for coll in parentobj_or_collname.users_collection:
			print("- link_object_to_scene:", obj.name, "->", coll.name, len(childlist))
			coll_objs = coll.objects
			for obj_ch in childlist:
				if coll_objs.get(obj_ch.name) is None:
					coll_objs.link(obj_ch)
		print("- link_object_to_scene:", obj.name, "->", parentobj_or_collname.name)
		bpy.context.view_layer.update()
	return

def link_object_to_samecolls(obj, objTo):
	unlink_object_from_coll(obj, None)
	for coll in objTo.users_collection:
		if coll.objects.get(obj.name) is None:
			coll.objects.link(obj)
	c_scene = bpy.context.scene
	if (c_scene.collection.objects.get(obj.name) is not None) and (c_scene.collection.objects.get(objTo.name) is None):
		c_scene.collection.objects.unlink(obj)
	return

def link_object_sideBySide(obj, objTo):
	if obj is None:
		return
	ensure_visible(obj, 2)
	ensure_visible(objTo, 2)
	if objTo.parent is not None:
		link_object_to_scene(obj, objTo.parent)
		link_object_to_samecolls(obj, objTo)
		obj.matrix_world = objTo.matrix_world
		return
	# no parent, just to same collections
	obj.matrix_world = objTo.matrix_world
	link_object_to_samecolls(obj, objTo)
	bpy.context.view_layer.update()
	return

def view_layer_asllchildren(vl_lc_c, recursive):
	colls = []
	if vl_lc_c is not None:
		for lc in vl_lc_c: #vl.layer_collection.children:
			colls.append(lc)
			if recursive and (lc.children is not None) and len(lc.children) > 0:
				subcolls = view_layer_asllchildren(lc.children, True)
				colls = colls+subcolls
	return colls

def set_object_noShadow(c_object, andWire, andNoRender):
	c_object.visible_camera = True
	c_object.visible_diffuse = False
	c_object.visible_glossy = False
	c_object.visible_transmission = False
	c_object.visible_volume_scatter = False
	c_object.visible_shadow = False
	if andWire is not None and andWire == True:
		c_object.display_type = 'WIRE'
	if andNoRender is not None:
		c_object.hide_render = andNoRender
		c_object.visible_camera = not andNoRender

def modf_toggle_multi(c_objects, modfNameTypeToken, onOff, prepstate):
	for obj in c_objects:
		modf_toggle(obj, modfNameTypeToken, onOff, prepstate)

def modf_toggle(c_object, modfNameTypeToken, onOff, prepstate):
	if isinstance(c_object, str):
		c_object = wla.object_by_name(c_object)
	if c_object is None:
		return
	if "show_wire" in modfNameTypeToken:
		show_wire_key = "modf_"+c_object.name+"_show_wire"
		if onOff == False:
			if prepstate is not None:
				prepstate[show_wire_key] = c_object.show_wire
			c_object.show_wire = False
		if onOff == True:
			if prepstate is not None:
				prepstate[show_wire_key] = c_object.show_wire
			c_object.show_wire = True
			c_object.show_all_edges = True
		if (onOff is None) and (prepstate is not None) and (show_wire_key in prepstate):
			c_object.show_wire = prepstate[show_wire_key]
	foundMds = []
	isGP = False
	c_object_modfs = []
	if c_object.type == 'GPENCIL':
		isGP = True
		c_object_modfs = c_object.grease_pencil_modifiers
	else:
		c_object_modfs = c_object.modifiers
	for md in c_object_modfs:
		md_key = "modf_"+c_object.name+"|"+md.name
		if modfNameTypeToken == '*' or (md.type in modfNameTypeToken) or (wla.isTokenInStr(modfNameTypeToken, md.name)):
			foundMds.append(md)
			if onOff is None and prepstate is None:
				# just counting!
				continue
			if (onOff is not None) and (prepstate is not None):
				if isGP:
					prepstate[md_key] = (md.show_in_editmode,md.show_viewport,md.show_render)
				else:
					prepstate[md_key] = (md.show_in_editmode,md.show_viewport,md.show_render,md.show_on_cage)
			if onOff == False:
				print("- disabling", md.name,md.type)
				md.show_in_editmode = False
				md.show_viewport = False
				md.show_render = False
				if isGP == False:
					md.show_on_cage = False
			if onOff == True:
				print("- enabling", md.name, md.type)
				md.show_in_editmode = True
				md.show_viewport = True
				md.show_render = True
				if isGP == False:
					md.show_on_cage = True
			if (onOff is None) and (prepstate is not None) and (md_key in prepstate):
				if md_key in prepstate:
					print("- restoring", md.name, md.type, prepstate[md_key])
					md.show_in_editmode = prepstate[md_key][0]
					md.show_viewport = prepstate[md_key][1]
					md.show_render = prepstate[md_key][2]
					if isGP == False:
						md.show_on_cage = prepstate[md_key][3]
	return foundMds

def modf_sendBackByName(c_object, modname, sendToBottom = True):
	if modname is None or wla.modf_by_type(c_object, None, modname) is None:
		return
	set_active_object(c_object)
	if c_object.type == 'GPENCIL':
		if len(c_object.grease_pencil_modifiers) < 2:
			return
		if sendToBottom:
			bpy.ops.object.gpencil_modifier_move_to_index(modifier=modname, index = len(c_object.grease_pencil_modifiers)-1)
		else:
			bpy.ops.object.gpencil_modifier_move_to_index(modifier=modname, index = 0)
	else:
		if len(c_object.modifiers) < 2:
			return
		if sendToBottom:
			bpy.ops.object.modifier_move_to_index(modifier=modname, index = len(c_object.modifiers)-1)
			# while c_object.modifiers[-1].name != modname:
			# 	bpy.ops.object.modifier_move_down(modifier=modname)
		else:
			bpy.ops.object.modifier_move_to_index(modifier=modname, index=0)

def modf_sendBackByType(c_object, modType, sendToBottom = True):
	md = wla.modf_by_type(c_object, modType)
	if md is not None:
		modf_sendBackByName(c_object, md.name, sendToBottom)

def modf_copy_opts(md, md_from):
	# https://blender.stackexchange.com/questions/4878/how-to-copy-modifiers-with-attribute-values-from-active-object-to-selected-objec
	md.name = md_from.name
	md.show_on_cage = md_from.show_on_cage
	md.show_in_editmode = md_from.show_in_editmode
	md.show_viewport = md_from.show_viewport
	md.show_render = md_from.show_render
	if md.type == 'SUBSURF' and md_from.type == 'SUBSURF':
		md.levels = md_from.levels
		md.render_levels = md_from.render_levels
		md.quality = md_from.quality
		md.boundary_smooth = md_from.boundary_smooth # 'PRESERVE_CORNERS'
		md.uv_smooth = md_from.uv_smooth
		md.use_creases = md_from.use_creases
	if md.type == 'ARMATURE' and md_from.type == 'ARMATURE':
		md.object = md_from.object
		md.use_deform_preserve_volume = md_from.use_deform_preserve_volume
		md.use_vertex_groups = md_from.use_vertex_groups
		md.use_bone_envelopes = md_from.use_bone_envelopes

def attach_objToSourceObject(edgeObj, sel_obj, asChild, withShrinkw, withSubd):
	if len(edgeObj.data.materials) == 0 and len(sel_obj.data.materials)>0:
		edgeObj.data.materials.append(sel_obj.data.materials[0])
	if asChild:
		edgeObj.parent = sel_obj
		edgeObj.matrix_local = Matrix.Identity(4)
	else:
		edgeObj.parent = sel_obj.parent
		edgeObj.matrix_world = sel_obj.matrix_world
	if withSubd > 0:
		edgeModifiers = edgeObj.modifiers
		if (edgeModifiers.get('WPL_EdgeSubd') is None) and (sel_obj.type != 'CURVE'):
			subdiv_modifier = edgeModifiers.new(name = "WPL_EdgeSubd", type = 'SUBSURF')
			subdiv_modifier.levels = withSubd
			subdiv_modifier.render_levels = withSubd
	if withShrinkw:
		edgeModifiers = edgeObj.modifiers
		if (edgeModifiers.get('WPL_Edge2src') is None) and (sel_obj.type != 'CURVE'):
			shrinkwrap_modifier = edgeModifiers.new(name = "WPL_Edge2src", type = 'SHRINKWRAP')
			shrinkwrap_modifier.offset = 0.0
			shrinkwrap_modifier.target = sel_obj
			shrinkwrap_modifier.wrap_method = 'NEAREST_SURFACEPOINT'
			shrinkwrap_modifier.wrap_mode = 'ABOVE_SURFACE'
			shrinkwrap_modifier.use_apply_on_spline = True

def hide_objects_with_childs(obj,ishide):
	obj.hide_viewport = ishide
	obj.hide_render = ishide
	if len(obj.children)>0:
		for ch in obj.children:
			hide_objects_with_childs(ch,ishide)

def transfer_data(from_obj, to_obj, transferVG, transferVC):
	# vgroups important for bone-normals
	print("- transfer_data", from_obj.name, "->", to_obj.name)
	select_and_change_mode(to_obj, 'OBJECT')
	if from_obj.type != 'MESH' or to_obj.type != 'MESH':
		print("- ERROR: can`t transfer, meshes needed", from_obj, to_obj)
		return
	modname = "sys_dataTransfer"
	dt_modifier = to_obj.modifiers.new(name = modname, type = 'DATA_TRANSFER')
	dt_modifier.object = from_obj
	dt_modifier.use_object_transform = True # AMUST for armatured bodies -> scaled always
	if transferVG:
		dt_modifier.use_vert_data = True
		dt_modifier.data_types_verts = {'VGROUP_WEIGHTS'}
		dt_modifier.vert_mapping = 'POLYINTERP_NEAREST' # ?POLY_NEAREST ?POLYINTERP_VNORPROJ
		dt_modifier.layers_vgroup_select_src = 'ALL'
		dt_modifier.layers_vgroup_select_dst = 'NAME'
	if transferVC:
		# POLYINTERP_NEAREST interpolation break sharpness (vertex-blur)
		dt_modifier.use_loop_data = True
		dt_modifier.data_types_loops = {'VCOL'}
		dt_modifier.loop_mapping = 'NEAREST_POLY' # ?POLYINTERP_NEAREST ?POLYINTERP_LNORPROJ
		dt_modifier.layers_vcol_loop_select_src = 'ALL' # layers_vcol_select_src prior BL3.2
		dt_modifier.layers_vcol_loop_select_dst = 'NAME' # layers_vcol_select_dst prior BL3.2
		dt_modifier.mix_mode = 'REPLACE'
	# while to_obj.modifiers[0].name != modname:
	# 	bpy.ops.object.modifier_move_up(modifier=modname)
	#wla_do.sys_update_mesh(from_obj)
	#wla_do.sys_update_mesh(to_obj)
	bpy.ops.object.datalayout_transfer(modifier=modname)
	bpy.ops.object.modifier_apply(modifier=modname)
	if transferVG and to_obj.type == 'MESH' and len(to_obj.vertex_groups) > 0:
		print("- cleaning verts", to_obj.name)
		wla_attr.vg_cleanup_groups(to_obj)

def transfer_vc_fromProp(from_obj, to_obj, vc_name):
	if vc_name in from_obj:
		if to_obj.type == 'MESH':
			# removing attribs with same name (can be produced by GN)
			prevAttr = to_obj.data.attributes.get(vc_name)
			if prevAttr is not None:
				to_obj.data.attributes.remove(prevAttr)
			# filling faces with color - better for debugging
			#wla_do.select_and_change_mode(to_obj, 'OBJECT')
			upd_color = from_obj[vc_name]
			# opt_correctGamma - convertation needed here
			upd_color = (math.pow(upd_color[0], 1.0/2.2), math.pow(upd_color[1], 1.0/2.2), math.pow(upd_color[2], 1.0/2.2)  )
			wla_attr.vc_obj_ensure(to_obj, vc_name)
			wla_attr.vc_obj_update(to_obj,'FACE', vc_name, upd_color, (1.0,1.0,1.0), 1.0, None, None, None)
		else:
			to_obj[vc_name] = from_obj[vc_name]

def transfer_modf(from_obj, to_obj, excepts):
	# custom parameters transfer (DecorC)
	transfer_vc_fromProp(from_obj, to_obj, config.kWPLMeshColVC)
	transfer_vc_fromProp(from_obj, to_obj, config.kWPLMeshColPVC)
	transfer_vc_fromProp(from_obj, to_obj, config.kWPLMeshColDVC)
	transfer_vc_fromProp(from_obj, to_obj, config.kWPLMeshColLVC)
	md_edgsp = wla.modf_by_type(from_obj,'EDGE_SPLIT')
	if md_edgsp is not None and ('EDGE_SPLIT' not in excepts):
		md = to_obj.modifiers.new("Edge Split", 'EDGE_SPLIT')
		modf_copy_opts(md, md_edgsp)
	md_mirr = wla.modf_by_type(from_obj,'MIRROR')
	if md_mirr is not None and ('MIRROR' not in excepts):
		md = to_obj.modifiers.new("Mirror", 'MIRROR')
		modf_copy_opts(md, md_mirr)
	md_subs = wla.modf_by_type(from_obj,'SUBSURF')
	if md_subs is not None and ('SUBSURF' not in excepts):
		md = to_obj.modifiers.new("Subsurf", 'SUBSURF')
		modf_copy_opts(md, md_subs)

def link_with_vgsbind(objFrom, objTo):
	bindName = objFrom.name
	if wla.isTokenInStr(config.kWPLObjCharBodyPostfix, objFrom.name):
		bindName = config.kWPLObjCharBodyPostfix
	else:
		# if srcObject already have binding - getting bindname from it
		srcBinds = wla_attr.vg_names_by_nameToken(objFrom, "bind(")
		if len(srcBinds) == 1:
			st_def = wla.strExtractOuterBrackets(srcBinds[0])
			st_opts = wla.strToTokens(st_def, False)
			bindName = st_opts[0]
			#print("- extracted bind", bindName, st_def)
	if objTo.type == 'MESH':
		if (wla.isTokenInStr(config.kWPLObjCharBodyPostfix, objFrom.name) or wla.isTokenInStr(config.kWPLObjCharDressPostfix, objFrom.name)):
			vgs_binding_vg = config.kWPLSuppVGScriptToken+": bind("+bindName+", v01, v01)"
			print("- adding MESH vgs-bind:", vgs_binding_vg)
			wla_attr.vg_get_or_new(objTo, vgs_binding_vg)
	else:
		# saving binding
		vgs_binding_vg = config.kWPLSuppVGScriptToken+": bind("+bindName+", v01, v01)"
		print("- adding CUSTOMPROP vgs-bind:", vgs_binding_vg)
		objTo[vgs_binding_vg] = kWPLSuppVGScriptPropDefValue
	return

def clone_evaluated_obj(active_obj, new_name, delPrevs, tranfVertxData, invalidModfs):
	if delPrevs:
		mfcOld = wla.object_by_name(new_name)
		if mfcOld is not None:
			bpy.data.objects.remove(mfcOld, do_unlink=True)
	if invalidModfs is None:
		invalidModfs = kWPLModifsIndexBreakersStrict
	obj_modstate = {}
	modf_toggle(active_obj, invalidModfs, False, obj_modstate)
	depsgraph = bpy.context.evaluated_depsgraph_get()
	active_obj_eval = active_obj.evaluated_get(depsgraph)
	active_obj_eval_tmpMesh = bpy.data.meshes.new_from_object(active_obj_eval)
	meshedObj = bpy.data.objects.new(name=new_name, object_data=active_obj_eval_tmpMesh)
	active_obj_eval.to_mesh_clear()
	link_object_to_scene(meshedObj, active_obj.parent)
	meshedObj.matrix_world = active_obj.matrix_world
	meshedObj.color = active_obj.color
	meshedObj.visible_camera = active_obj.visible_camera
	meshedObj.visible_diffuse = active_obj.visible_diffuse
	meshedObj.visible_glossy = active_obj.visible_glossy
	meshedObj.visible_transmission = active_obj.visible_transmission
	meshedObj.visible_volume_scatter = active_obj.visible_volume_scatter
	meshedObj.visible_shadow = active_obj.visible_shadow
	if tranfVertxData:
		# VC transfer not needed -> active_obj_eval_tmpMesh has all VCOLS copied!
		# only VG transfer needed
		transfer_data(active_obj, meshedObj, True, False)
	modf_toggle(active_obj, invalidModfs, None, obj_modstate)
	transfer_modf(active_obj, meshedObj, ['MIRROR']) # evaluated mesh already mirrored
	return meshedObj

def find_last_changed_objects(isFinally): # added objects
	if isFinally == False:
		namemap = {}
		config.WPL_G.store["obj_names"] = namemap
		for obj in bpy.data.objects:
			namemap[obj.name] = True
		return None
	if not ("obj_names" in config.WPL_G.store):
		return None
	namemap = config.WPL_G.store["obj_names"]
	newobjs = []
	for obj in bpy.data.objects:
		if obj.name not in namemap:
			newobjs.append(obj)
	#objects_before = {o for o in bpy.data.objects}
	#bpy.ops.object.duplicates_make_real()
	#created_objects = {o for o in bpy.data.objects}.difference(objects_before)
	return newobjs

def switch_orientation(orientType, pivotMode):
	if orientType is not None:
		bpy.context.scene.transform_orientation_slots[0].type = orientType #'LOCAL'
	if pivotMode is not None:
		bpy.context.scene.tool_settings.transform_pivot_point = pivotMode #'MEDIAN_POINT'
		bpy.context.scene.cursor.rotation_mode = 'XYZ'
		bpy.context.scene.cursor.rotation_euler = mathutils.Euler((0,0,0), 'XYZ')
		bpy.context.scene.tool_settings.proportional_edit_falloff = 'SMOOTH'
		bpy.context.scene.tool_settings.use_proportional_connected = True
		# bpy.context.space_data.show_gizmo_object_translate = False
	return

def create_temp_orientation():
	try:
		bpy.ops.transform.create_orientation(name=config.kWPLTempOrien, use=True, overwrite=True)
	except Exception as e:
		# if nothing selected in EDIT mode this is possible...
		#print("- create_temp_orientation: fallback to object", e)
		active_obj = wla.active_object()
		if active_obj is None:
			active_obj = wla.object_by_name(config.kWPLSystemMainCam)
		if active_obj is not None:
			select_and_change_mode(active_obj, 'OBJECT')
			bpy.ops.transform.create_orientation(name=config.kWPLTempOrien, use=True, overwrite=True)
	return

# *************************************

def pip_ensure_install(module):
	if not pip_is_installed(module):
		#  --user --upgrade --force-reinstall
		#  --no-cache-dir
		return pip_install(module, "--no-deps")
	return True

def pip_is_installed(module):
	"""
	Checks if given module is installed
	Parameters:
		module (str): Module name
	Returns:
		True if installed; False otherwise
	"""
	try:
		importlib.import_module(module)
		return True
	except Exception as e:
		# ImportError
		print("- pip_is_installed: error", module, e)
		return False

def pip_install(module: str, options: str = None):
	"""
	Installs given module with pip
	Parameters:
		module (str):  Module name
		options (str): Command line options for pip (e.g. '--no-deps -r')
	Returns:
		True if installation succeeded; False otherwise
	"""
	# Determine the path to Blender's Python interpreter.
	executable = None
	try:
		# There may be several executables!!! https://developer.blender.org/T95502
		# favoring latest one
		for path in reversed(glob.glob('{}/bin/python*'.format(sys.exec_prefix))):
			if os.access(path, os.X_OK) and not path.lower().endswith('dll'):
				executable = path
				break
	except Exception as e:
		logging.error(e)
	if executable is None:
		print('- Unable to locate Python interpreter')
		print("- pip install failed")
		return False

	# Install Python package manager.
	if pip_is_installed('ensurepip'):
		subprocess.call([executable, '-m', 'ensurepip'])
	elif not pip_is_installed('pip'):
		print("- installing pip")
		url = 'https://bootstrap.pypa.io/get-pip.py'
		filepath = '{}/get-pip.py'.format(os.getcwd())
		try:
			requests = importlib.import_module('requests')
			response = requests.get(url)
			with open(filepath, 'w') as f:
				f.write(response.text)
			subprocess.call([executable, filepath])
		except Exception as e:
			logging.error(e)
		finally:
			if os.path.isfile(filepath):
				os.remove(filepath)

	# Install given module.
	if not pip_is_installed(module) and executable is not None:
		print("- pip: installing module:", executable, options, module)
		try:
			if options is None or options.strip() == '':
				subprocess.call([executable, '-m', 'pip', 'install', module])
			else:
				execArgs = [executable, '-m', 'pip', 'install']
				execArgs = execArgs+(options.split(" "))
				execArgs = execArgs+[module]
				subprocess.call(execArgs)
		except Exception as e:
			logging.error(e)
			print("- pip install failed")
			return False
	return pip_is_installed(module)

# *************************************

def sys_update_mesh(obj):
	if obj is not None:
		obj.update_tag()
		if obj.type in ['MESH']:
			obj.data.update()
	depth = bpy.context.evaluated_depsgraph_get()
	depth.update()
	sys_update_view(True, True)

def sys_update_view(doVL, doRG):
	# depth = bpy.context.evaluated_depsgraph_get()
	# depth.update()
	#for vl in c_scene.view_layers:
	#	vl.update()
	if doVL:
		bpy.context.view_layer.update()
	if doRG:
		for area in bpy.context.screen.areas:
			if area.type == 'VIEW_3D':
				area.spaces.active.region_3d.update()

def sys_dump_pythonobj(obj):
	print("- object Dump:")
	for attr in dir(obj):
		if hasattr( obj, attr ):
			print( "...%s = %s" % (attr, getattr(obj, attr)))

def sys_dump_mesh(active_obj, curveMesh, testname):
	from_name = "???"
	mw = None
	if active_obj is not None:
		from_name = active_obj.name
		mw = active_obj.matrix_world
	print("- sys_dump_mesh", from_name, "->", testname)
	tmp_ground_data = bpy.data.meshes.new_from_object(active_obj) # materials saved that way!!!
	# bm = bmesh.new()
	# bm.from_mesh(curveMesh)
	# tmp_ground_data=bpy.data.meshes.new(name='testMesh')
	# bm.to_mesh(tmp_ground_data)
	test_ob = bpy.data.objects.new(name = testname, object_data=tmp_ground_data)
	if mw is not None:
		test_ob.matrix_world = mw
	bpy.context.scene.collection.objects.link(test_ob)

def sys_dump_bmesh(active_obj, bm2test, facesIds, testname):
	from_name = "???"
	mw = None
	if active_obj is not None:
		from_name = active_obj.name
		mw = active_obj.matrix_world
	print("- sys_dump_bmesh", from_name, "->", testname, len(bm2test.verts), len(bm2test.edges), len(bm2test.faces))
	bm2test_mesh = bpy.data.meshes.new(name=testname)
	bm2test_ob = bpy.data.objects.new(name=testname, object_data=bm2test_mesh)
	if mw is not None:
		bm2test_ob.matrix_world = mw
	bpy.context.scene.collection.objects.link(bm2test_ob)
	if (facesIds is not None) and (len(facesIds) > 0):
		print("// sys_dump_bmesh: faces limit", len(facesIds))
		# deleting all except this
		bm2test = bm2test.copy()
		bm2test.verts.ensure_lookup_table()
		bm2test.verts.index_update()
		bm2test.faces.ensure_lookup_table()
		bm2test.faces.index_update()
		faces2del = []
		for f in bm2test.faces:
			if f.index not in facesIds:
				faces2del.append(f)
		bmesh.ops.delete(bm2test, geom=faces2del, context='FACES')
	bm2test.to_mesh(bm2test_mesh)
	return bm2test_ob