import os, sys, time, datetime
import math, copy, string, random
import numpy as np
import bpy, bmesh, mathutils

import bpy.types
from mathutils import Vector, Matrix, Euler, Quaternion
from mathutils.bvhtree import BVHTree
from mathutils.kdtree import KDTree
from bpy_extras import view3d_utils
from bpy.props import *

from .. import config
from . import wla
from . import wla_do

# ===============================

def vg_get_by_name(obj, group_name):
	if group_name in obj.vertex_groups:
		return obj.vertex_groups[group_name]
	return None

def vg_names_by_nameToken(obj, token):
	res = []
	if obj is None or token is None:
		return res
	if obj.type == 'MESH':
		for vg in obj.vertex_groups:
			#print("- vg_names_by_nameToken:", token, vg.name, wla.isTokenInStr(token, vg.name))
			if wla.isTokenInStr(token, vg.name):
				res.append(vg.name)
	# checking custom props for special cases - lattice, curve
	# max 63 chars!!!
	for cp_name in obj.keys():
		if wla.isTokenInStr(token, cp_name):
			res.append(cp_name)
	#print("- vg_names_by_nameToken", token, res)
	return res

def vg_remove(obj, group_name):
	vertgroup = vg_get_by_name(obj, group_name)
	if vertgroup:
		print("- vg_remove: deleting", vertgroup.name)
		obj.vertex_groups.remove(vertgroup)

def vg_get_or_new(obj, group_name):
	vertgroup = vg_get_by_name(obj, group_name)
	if vertgroup is None:
		vertgroup = obj.vertex_groups.new(name=group_name)
	return vertgroup

def vg_get_verts(obj, vertgroup, limit, cache):
	if isinstance(vertgroup, str):
		vertgroup = vg_get_by_name(obj, vertgroup)
	def get_weights(ob, vgroup):
		group_index = vgroup.index
		for i, v in enumerate(ob.data.vertices):
			for g in v.groups:
				if g.group == group_index:
					yield (v, g.weight)
					break
	vertsCo = []
	vertsIdx = []
	vertsW = {}
	if vertgroup is not None:
		cache_key = obj.name + vertgroup.name + str(limit)
		if (cache is not None) and cache_key in cache:
			(vertsCo,vertsIdx,vertsW) = cache[cache_key]
			return copy.copy(vertsCo), copy.copy(vertsIdx), copy.copy(vertsW)
		for v, w in get_weights(obj, vertgroup):
			if w >= limit:
				vertsCo.append( v.co.copy() )
				vertsIdx.append(v.index)
				vertsW[v.index] = w
		if cache is not None:
			cache[cache_key] = (copy.copy(vertsCo), copy.copy(vertsIdx), copy.copy(vertsW) )
	return vertsCo, vertsIdx, vertsW

def vg_get_weightMapByTok(active_obj, vgname):
	vgs = vg_names_by_nameToken(active_obj, vgname)
	if len(vgs) == 0:
		return {}, None
	vgname = vgs[0]
	wmap = vg_get_weightMap(active_obj, vgname)
	return wmap, vgname

def vg_get_weightMap(active_obj, vgname, wei_limit = 0.001):
	weights = {}
	if vgname in active_obj:
		# special case: empty VG
		# for lattice, curve, etc
		return weights
	vgroup = vg_get_by_name(active_obj, vgname)
	if vgroup is not None:
		for index, vert in enumerate(active_obj.data.vertices):
			for group in vert.groups:
				if (group.group == vgroup.index) and group.weight >= wei_limit:
					weights[vert.index] = group.weight
	return weights

def vg_add_verts2vg(active_obj, vgname, vertsIdx, newVal, fullReplace = False):
	if fullReplace:
		vg_remove(active_obj, vgname)
	mask_group = vg_get_or_new(active_obj, vgname)
	if fullReplace:
		mask_group.add(vertsIdx, newVal, 'ADD')
		return mask_group
	oldval = 0
	for idx in vertsIdx:
		wmod = 'REPLACE'
		try:
			oldval = mask_group.weight(idx)
		except Exception as e:
			oldval = 0
			wmod = 'ADD'
		mask_group.add([idx], newVal, wmod)
	return mask_group

def vg_cleanup_groups(obj):
	if (obj is None) or len(obj.vertex_groups) == 0:
		return 0
	wla_do.select_and_change_mode(obj, 'EDIT')
	bpy.ops.mesh.select_all( action = 'SELECT' )
	wla_do.select_and_change_mode(obj, 'OBJECT')
	bpy.ops.object.vertex_group_clean(group_select_mode='ALL', limit = 0.01)
	vg2del = []
	for vg in obj.vertex_groups:
		if wla.isTokenInStr(config.kWPLSuppVGScriptToken, vg.name):
			continue
		vm = vg_get_weightMap(obj, vg.name)
		if len(vm) == 0:
			#print("- empty vg, deleting", vg.name)
			vg2del.append(vg)
	for vg in vg2del:
		obj.vertex_groups.remove(vg)
	if len(obj.vertex_groups)>0: # all can be deleted!!!
		bpy.ops.object.vertex_group_sort(sort_type='NAME')
	return len(vg2del)

def uv_obj_ensure(targetObj, uvName):
	if targetObj is None:
		return None
	active_mesh = None
	if (targetObj.type == 'MESH'):
		active_mesh = targetObj.data
	if (targetObj.type != 'MESH') and (config.kWPLTempMesh in targetObj):
		active_mesh = targetObj[config.kWPLTempMesh]
	if active_mesh is None:
		return None
	uv_map = active_mesh.uv_layers.get(uvName)
	if uv_map is not None:
		return uv_map
	oldmode = wla_do.select_and_change_mode(targetObj, 'OBJECT')
	active_mesh.uv_layers.new(name = uvName)
	wla_do.select_and_change_mode(targetObj, oldmode)
	uv_map = active_mesh.uv_layers.get(uvName)
	print("- created UV", uvName, uv_map)
	return uv_map

def uv_resetUV(bm, uvName, facesIdx, resetVal):
	bm.faces.index_update()
	bm.faces.ensure_lookup_table()
	uv_layer_ob = bm.loops.layers.uv.get(uvName)
	if uv_layer_ob is not None:
		for fIdx in facesIdx:
			face = bm.faces[fIdx]
			for loop in face.loops:
				loop[uv_layer_ob].uv = (resetVal[0], resetVal[1])
	return

def attr3f_obj_ensure(targetObj, attrName):
	if targetObj is None:
		return None
	active_mesh = None
	if (targetObj.type == 'MESH'):
		active_mesh = targetObj.data
	if (targetObj.type != 'MESH') and (config.kWPLTempMesh in targetObj):
		active_mesh = targetObj[config.kWPLTempMesh]
	if active_mesh is None:
		return None
	attr_map = active_mesh.attributes.get(attrName)
	if attr_map is not None:
		return attr_map
	oldmode = wla_do.select_and_change_mode(targetObj, 'OBJECT')
	attr_map = active_mesh.attributes.new(attrName,'FLOAT_VECTOR','FACE')
	# attr_map.data.foreach_set('vector', Vector((0,0,0)))
	for poly in active_mesh.polygons:
		ipoly = poly.index
		attr_map.data[ipoly].vector = Vector((0,0,0))
	wla_do.select_and_change_mode(targetObj, oldmode)
	attr_map = active_mesh.attributes.get(attrName)
	print("- created ATTR-face", attrName, attr_map)
	return attr_map

def attr3v_obj_ensure(targetObj, attrName):
	# Attributes with BMESH: https://blender.stackexchange.com/questions/231749/add-custom-vertex-attribute-with-bmesh-without-using-context
	if targetObj is None:
		return None
	active_mesh = None
	if (targetObj.type == 'MESH'):
		active_mesh = targetObj.data
	if (targetObj.type != 'MESH') and (config.kWPLTempMesh in targetObj):
		active_mesh = targetObj[config.kWPLTempMesh]
	if active_mesh is None:
		return None
	attr_map = active_mesh.attributes.get(attrName)
	if attr_map is not None:
		return attr_map
	oldmode = wla_do.select_and_change_mode(targetObj, 'OBJECT')
	attr_map = active_mesh.attributes.new(attrName,'FLOAT_VECTOR','POINT')
	for vert in active_mesh.vertices:
		vIdx = vert.index
		attr_map.data[vIdx].vector = Vector((0,0,0))
	wla_do.select_and_change_mode(targetObj, oldmode)
	attr_map = active_mesh.attributes.get(attrName)
	print("- created ATTR-vert", attrName, attr_map)
	return attr_map

def attr3fc_obj_ensure(targetObj, attrName):
	if targetObj is None:
		return None
	active_mesh = None
	if (targetObj.type == 'MESH'):
		active_mesh = targetObj.data
	if (targetObj.type != 'MESH') and (config.kWPLTempMesh in targetObj):
		active_mesh = targetObj[config.kWPLTempMesh]
	if active_mesh is None:
		return None
	attr_map = active_mesh.attributes.get(attrName)
	if attr_map is not None:
		return attr_map
	oldmode = wla_do.select_and_change_mode(targetObj, 'OBJECT')
	attr_map = active_mesh.attributes.new(attrName,'FLOAT_VECTOR','CORNER')
	for poly in active_mesh.polygons:
		ipoly = poly.index
		for idx, lIdx in enumerate(active_mesh.polygons[ipoly].loop_indices):
			attr_map.data[lIdx].vector = Vector((0,0,0))
	wla_do.select_and_change_mode(targetObj, oldmode)
	attr_map = active_mesh.attributes.get(attrName)
	print("- created ATTR-face-loop", attrName, attr_map)
	return attr_map

def vc_obj_ensure(targetObj, vcName):
	if targetObj is None:
		return None
	active_mesh = None
	if (targetObj.type == 'MESH'):
		active_mesh = targetObj.data
	if (targetObj.type != 'MESH') and (config.kWPLTempMesh in targetObj):
		active_mesh = targetObj[config.kWPLTempMesh]
	if active_mesh is None:
		return None
	color_map = active_mesh.vertex_colors.get(vcName)
	if color_map is not None:
		return color_map
	oldmode = wla_do.select_and_change_mode(targetObj, 'OBJECT')
	color_map = active_mesh.vertex_colors.new(name = vcName)
	# filling with zeros
	for poly in active_mesh.polygons:
		ipoly = poly.index
		for idx, lIdx in enumerate(active_mesh.polygons[ipoly].loop_indices):
			color_map.data[lIdx].color = Vector((0,0,0,1))
	wla_do.select_and_change_mode(targetObj, oldmode)
	color_map = active_mesh.vertex_colors.get(vcName)
	print("- created VC", vcName, color_map)
	return color_map

def vc_obj_resetvcs(targetObj, vcName, selfaces):
	if targetObj is None or targetObj.type != 'MESH':
		return None
	active_mesh = targetObj.data
	oldmode = wla_do.select_and_change_mode(targetObj, 'OBJECT')
	for color_map in active_mesh.vertex_colors:
		if vcName is not None and color_map.name != vcName:
			continue
		# filling with zeros
		for poly in active_mesh.polygons:
			ipoly = poly.index
			if selfaces is not None and ipoly not in selfaces:
				continue
			for idx, lIdx in enumerate(active_mesh.polygons[ipoly].loop_indices):
				color_map.data[lIdx].color = Vector((0,0,0,1))
	wla_do.select_and_change_mode(targetObj, oldmode)
	return color_map

def vc_obj_setPropCol(targetObj, vcName, newcol, modeGammaCorrected):
	print("- vc_obj_setPropCol", targetObj.name, 'PROP', vcName, newcol, modeGammaCorrected)
	# vc_obj_update(obj, 'PROP', vcName, newcol ,(1,1,1), 1.0, None, None, None) -> Darker if not corrected
	if 'COL_FROM_GAMMA' in modeGammaCorrected:
		newcol = (math.pow(newcol[0], 1.0/2.2), math.pow(newcol[1], 1.0/2.2), math.pow(newcol[2], 1.0/2.2)  )
	if 'COL_TO_GAMMA' in modeGammaCorrected:
		newcol = (math.pow(newcol[0], 2.2), math.pow(newcol[1], 2.2), math.pow(newcol[2], 2.2)  )
	subt = 'COLOR_GAMMA'
	if 'PROP_NON_GAMMA' in modeGammaCorrected:
		subt = 'COLOR'
	targetObj[vcName] = newcol
	ui_data = targetObj.id_properties_ui(vcName)
	ui_data.update( subtype = subt, min = 0.0, max = 1.0 )
	targetObj[vcName] = newcol # again

def vc_obj_update(targetObj, method, vcName, newcol, rgbMask, infl, infl4vert, selverts, selfaces):
	def newColorWith(col1,col2,channelMask,vcInfl):
		oldcol = Vector((col1[0],col1[1],col1[2],1.0))
		R = col2[0]*channelMask[0] + oldcol[0]*(1.0-channelMask[0])
		G = col2[1]*channelMask[1] + oldcol[1]*(1.0-channelMask[1])
		B = col2[2]*channelMask[2] + oldcol[2]*(1.0-channelMask[2])
		newcol2 = Vector((R,G,B,1.0))
		newcol3 = oldcol+(newcol2-oldcol)*vcInfl
		return newcol3
	if method == 'PROP' or targetObj.type == 'CURVE' or targetObj.type == 'FONT':
		fincol = newColorWith((0,0,0,1), newcol, rgbMask, infl)
		#targetObj[vcName] = (fincol[0],fincol[1],fincol[2])
		vc_obj_setPropCol(targetObj, vcName, fincol, 'PROP_NON_GAMMA')
		return 1
	if targetObj.type != 'MESH':
		return -1
	active_mesh = targetObj.data
	color_map = active_mesh.vertex_colors.get(vcName)
	if (color_map is None):
		return -1
	#oldmode = wla_do.select_and_change_mode(targetObj, 'OBJECT')
	setCount = 0
	for poly in active_mesh.polygons:
		ipoly = poly.index
		if (method == 'VERT') or (selfaces is None) or (ipoly in selfaces):
			for idx, lIdx in enumerate(active_mesh.polygons[ipoly].loop_indices):
				ivdx = active_mesh.polygons[ipoly].vertices[idx]
				if (method == 'FACE') or (selverts is None) or (ivdx in selverts):
					if lIdx < len(color_map.data):
						col = color_map.data[lIdx].color
						v_infl = infl
						if infl4vert is not None and ivdx in infl4vert:
							v_infl = v_infl * infl4vert[ivdx]
						lerped = newColorWith(col, newcol, rgbMask, v_infl)
						color_map.data[lIdx].color = lerped
						setCount = setCount+1
	# if oldmode != 'OBJECT':
	# 	wla_do.select_and_change_mode(targetObj, oldmode)
	return setCount

def vc_obj_avgcolor(targetObj, vc_name, selfaces):
	if targetObj is None or targetObj.type != 'MESH':
		return None, None
	if selfaces is None or len(selfaces) == 0:
		return None, None
	active_mesh = targetObj.data
	color_map = active_mesh.vertex_colors.get(vc_name)
	pickedMat = None
	pickedCol = None
	cols_idx = {}
	mats_idx = {}
	for ipoly in range(len(active_mesh.polygons)):
		fpoly = active_mesh.polygons[ipoly]
		if fpoly.material_index not in mats_idx:
			mats_idx[fpoly.material_index] = 0
		if ipoly in selfaces:
			mats_idx[fpoly.material_index] = mats_idx[fpoly.material_index]+1
			if color_map is not None:
				for idx, lIdx in enumerate(fpoly.loop_indices):
					col = mathutils.Vector(color_map.data[lIdx].color)
					col_key = wla.coToKey(col)
					if col_key not in cols_idx:
						cols_idx[col_key] = [0, col]
					cols_idx[col_key][0] = cols_idx[col_key][0]+1
	max_used_col_cnt = 0
	for cIdx in cols_idx.keys():
		if cols_idx[cIdx][0] > max_used_col_cnt:
			max_used_col_cnt = cols_idx[cIdx][0]
			pickedCol = cols_idx[cIdx][1]
	max_used_mat_idx = -1
	max_used_mat_cnt = 0
	for mIdx in mats_idx.keys():
		if mats_idx[mIdx] > max_used_mat_cnt:
			max_used_mat_cnt = mats_idx[mIdx]
			max_used_mat_idx = mIdx
	if max_used_mat_idx >= 0:
		if max_used_mat_idx >= len(targetObj.material_slots):
			print("- ERROR: material index higer than number of material slots", max_used_mat_idx, len(targetObj.material_slots))
			return pickedCol, None
		mat = targetObj.material_slots[max_used_mat_idx]
		pickedMat = mat.name
	#print("- vc_obj_avgcolor: mats_idx", max_used_mat_idx, pickedMat, mats_idx)
	#print("- vc_obj_avgcolor: picked", pickedCol, pickedMat)
	return pickedCol, pickedMat

def vc_glob_rand_colors(islandId):
	if 'wpluvvg_randomc' not in config.WPL_G.store:
		randCols = 500.0
		colorsR = []
		colorsG = []
		colorsB = []
		for colIdx in range(0, int(randCols)):
			colorsR.append(0.10+0.84*(colIdx/randCols))
			colorsG.append(0.12+0.82*(colIdx/randCols))
			colorsB.append(0.14+0.80*(colIdx/randCols))
		random.shuffle(colorsR)
		random.shuffle(colorsG)
		random.shuffle(colorsB)
		colsArray = [colorsR, colorsG, colorsB]
		random.shuffle(colsArray)
		config.WPL_G.store['wpluvvg_randomc'] = colsArray
		config.WPL_G.store['wpluvvg_randomc_idx'] = 0
	colorsRGB = []
	colorsR = config.WPL_G.store['wpluvvg_randomc'][0]
	colorsG = config.WPL_G.store['wpluvvg_randomc'][1]
	colorsB = config.WPL_G.store['wpluvvg_randomc'][2]
	colorsIdx = config.WPL_G.store['wpluvvg_randomc_idx']
	for islfrac in range(0, int(islandId)+1):
		newcolor = Vector((colorsR[colorsIdx], colorsG[colorsIdx], colorsB[colorsIdx]))
		colorsRGB.append(newcolor)
		colorsIdx = colorsIdx+1
		if colorsIdx >= len(colorsR):
			colorsIdx = 0
			random.shuffle(colorsR)
			random.shuffle(colorsG)
			random.shuffle(colorsB)
	config.WPL_G.store['wpluvvg_randomc_idx'] = colorsIdx
	return colorsRGB

def mat_find_any(nameTok, namesExcept = None):
	if nameTok is None or len(nameTok) == 0:
		return None
	for mat in bpy.data.materials:
		if namesExcept is not None:
			if wla.isTokenInStr(namesExcept, mat.name):
				continue
		if wla.isTokenInStr(nameTok, mat.name):
			#print("- mat replacement", nameTok, mat.name, wla_do.sys_dump_pythonobj(mat))
			if mat.node_tree is not None:# broken materials (M) may be present, but without node-tree
				return mat.name
	return None

def mat_obj_ensureGpMat(targetObj, matName, matCol, isFill):
	gp_mat = None
	mat_idx = None
	if matName in bpy.data.materials.keys():
		gp_mat = bpy.data.materials.get(matName)
	elif matCol is not None:
		gp_mat = bpy.data.materials.new(matName)
		# convert material to be grease pencil compatible
		bpy.data.materials.create_gpencil_data(gp_mat)
		color = (0,0,0,1)
		if matCol is not None:
			if isinstance(matCol, str):
				color = wla.hexToVectorRGB(matCol)
			else:
				color = matCol
		#print("- mat_obj_ensureGpMat: adding gp-material", matName, gp_mat, color)
		color = (math.pow(color[0], 2.2), math.pow(color[1], 2.2), math.pow(color[2], 2.2), 1) # From GAMMA
		gp_mat.grease_pencil.color = color
		gp_mat.grease_pencil.fill_color = color
		if isFill:
			gp_mat.grease_pencil.show_fill = True
			gp_mat.grease_pencil.show_stroke = False
		else:
			gp_mat.grease_pencil.show_fill = False
			gp_mat.grease_pencil.show_stroke = True
	if gp_mat is not None and targetObj is not None:
		mat_idx = mat_obj_ensuremat(targetObj, gp_mat.name, False)
	return mat_idx

def mat_obj_ensuremat(targetObj, matName, forceNewSlot):
	faceMatIdx = -1
	isMatFound = False
	if (targetObj is None) or (matName is None) or (len(matName) == 0):
		return faceMatIdx
	for idx, mt in enumerate(targetObj.material_slots):
		if mt.name == matName:
			isMatFound = True
			faceMatIdx = idx
			break
	if isMatFound == False or forceNewSlot:
		#adding material
		mt = bpy.data.materials.get(matName)
		if mt is None:
			matName2 = config.isMaterialRenamed(matName)
			if matName2 is not None:
				mt = bpy.data.materials.get(matName2)
		if mt is None and matName != config.kWPLMatPlaceholder:
			# defaulting to some other material...
			# important for copy-paste between scenes when materials lost
			print("- WARNING: Unknown material:", matName, " -> ", config.kWPLMatPlaceholder)
			#mt = bpy.data.materials.get(config.kWPLMatPlaceholder)
			return mat_obj_ensuremat(targetObj, config.kWPLMatPlaceholder, False)
		if mt is None:
			print("- Unknown material:", matName)
			return -1
		print("- Adding material:", matName)
		targetObj.data.materials.append(mt)
		faceMatIdx = len(targetObj.material_slots)-1
	return faceMatIdx

def mat_segmentFaces(targetObj, selfaces):
	facespasted = 0
	active_mesh = targetObj.data
	_, pmat = vc_obj_avgcolor(targetObj, config.kWPLMeshColVC, selfaces)
	if pmat is not None:
		mtIdx = mat_obj_ensuremat(targetObj, pmat, True)
		active_mesh = targetObj.data
		for ipoly in range(len(active_mesh.polygons)):
			if (ipoly in selfaces):
				active_mesh.polygons[ipoly].material_index = mtIdx
				facespasted = facespasted+1
	else:
		return -1
	return facespasted

def get_driver_list(obj):
	# https://blender.stackexchange.com/questions/192902/how-to-check-the-pose-bone-have-property-which-is-driven
	# https://blender.stackexchange.com/questions/4994/check-if-a-property-is-animated-or-has-a-driver
	drvs = obj.animation_data.drivers
	li = []
	if drvs is not None:
		for drv in drvs:
			drv_path = drv.data_path
			li.append(drv_path)
	return li
