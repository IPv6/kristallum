import os, sys, time, datetime
import math, copy, string, random
import numpy as np
import bpy, bmesh, mathutils

import bpy.types
from mathutils import Vector, Matrix, Euler, Quaternion
from mathutils.bvhtree import BVHTree
from mathutils.kdtree import KDTree
from bpy_extras import view3d_utils
from bpy.props import *

from . import wla
from . import wla_do
from . import wla_bm
from . import wla_attr
from . import wla_meshwrap
from . import wla_curve
from .. import config

kWPL_EdgeOrthoRevOffset = 10

kWPL_optCCurveMinLen = 2
kWPL_optVertMaxL1diff = 5 # near loops to check for final edging WITH Z-step
kWPL_optVertMaxL2diff = 5 # near loops to check for final edging WITHOUT Z-step
kWPL_optVertTstLdiff = 1 # near loops to check for early rejection test
kWPL_optVertRcvLdiff = 1 # near loops to construct curves

# contour detection opts (z-diff, I.vN-skip, I.e-skip2)
kWPL_optMaxZdiff = 0.001
kWPL_optMaxInNoDot = -0.5
#kWPL_optEdgeTunnlDot = 0.9
# kWPLEdgeCastShiftDelta/cast_shift_delta: must correlate to curve radius 
# - so curve can "cover" distance to edge
# // small values -> vertexes on edge line can be missed
# // big values -> several rows of verts on edge line
kWPLEdgeCastShiftDelta = 0.001

# 2D conversion plane offset
kWPL_optCamProjZShift_v4 = 0.5

kWPL_optCamBubblingFuzzy = (0.00051, 3)

kWPL_cfg_v4 = {
	"BASE": {

		# curve pre-optimize: merge near vertex to camera-closest one
		# need more factor to work ok...
		#"vv_merge_by_dst": 0.001,

		# curve merger: nearness factors
		"vv_fac_2d_dst": 1.0,
		"vv_fac_3d_dst": 0.1,
		"vv_fac_3d_ds_tocam": 0.001,
		"vv_fac_opendir_dot": 0.1,
		"vv_fac_loops_cnt": 1.0,

		# curve post-optimize: merge distance (camera-projected space)
		"curve_break_openside_dot": 1.0,
		"curve_break_use_loopdiff": kWPL_optVertMaxL1diff,
	},
	"HAIRS": {
		# curve optimize: less aggresive merging
		#"vv_merge_by_dst": 0.001,
	},

	# DBG: produce DEBUG dots/curves (for check)
	"DBG_LEVEL": 0, # 1, 2, 3, 4
	"DBG_DUMP_MESHES": 0,
	"GENID": 0
}

#kWPL_EdgeModf_ExportSimplify = "Export: Simplify"
kWPL_EdgeModf_DBGBold = config.kWPLSystemDBGToken[1]+"Extra_Thinkness"
kWPL_EdgeModf_DBGBold_Scaler = 8.0 # valid for SPRITE edging
kWPL_EdgeModf_GPHideGeom = config.kWPLSystemDBGToken[1]+"Hidegeom_Offset"
kWPL_EdgeModf_DBGLineArt = config.kWPLSystemDBGToken[1]+"Lineart"

# =============

def getEdgOpt(src_obj, opt_name):
	val = kWPL_cfg_v4["BASE"][opt_name]
	if wla.isTokenInStr(config.kWPLObjCharHairsPostfix, src_obj.name):
		if opt_name in kWPL_cfg_v4["HAIRS"]:
			val = kWPL_cfg_v4["HAIRS"][opt_name]
			#print("- DBG: HAIR opt", opt_name, val)
	cpname = ("#edges:"+opt_name)
	if cpname in src_obj:
		val = src_obj[cpname]
		#print("- DBG: CUP opt", opt_name, val)
	return val

def segmentMesh(active_obj, active_mesh, segmentMap, islandsId0 = 0, validFacesIdx = None):
	if active_mesh is None:
		if (active_obj.type == 'MESH'):
			active_mesh = active_obj.data
		if (active_obj.type != 'MESH') and (config.kWPLTempMesh in active_obj):
			active_mesh = active_obj[config.kWPLTempMesh]
	if active_mesh is None:
		return None, None, None
	wla_do.select_and_change_mode(active_obj,'OBJECT')
	if (segmentMap is None) or len(segmentMap) == 0:
		segmentMap = "<island>"
	# Islands calcs:
	islandIdV = islandsId0
	islandIdF = islandsId0
	islandPerVert = {}
	islandPerFace = {}
	facePerIslands = {}
	bm = bmesh.new()
	bm.from_mesh(active_mesh)
	bm.verts.ensure_lookup_table()
	bm.verts.index_update()
	selVertsIslandsed = wla_bm.bm_expandVertsToIslands_v02(bm, None, None)
	bm.free()
	for meshlist in selVertsIslandsed:
		islandIdV = islandIdV+1.0
		for vidx in meshlist:
			islandPerVert[vidx] = islandIdV
	#print("- segmentMesh: islands", islandIdV)
	usedMtl = {}
	mtlToIslMap = {}
	for poly in active_mesh.polygons:
		ipoly = poly.index
		if validFacesIdx is not None and ipoly not in validFacesIdx:
			continue
		mtl_idx = active_mesh.polygons[ipoly].material_index
		mtl_key = segmentMap
		if poly.vertices[0] in islandPerVert:
			mtl_key = mtl_key.replace("<island>", str(int(islandPerVert[poly.vertices[0]])) )
		mtl_key = mtl_key.replace("<mat_id>",str(mtl_idx))
		if mtl_idx < len(active_obj.material_slots):
			mtl_key = mtl_key.replace("<mat_name>",active_obj.material_slots[mtl_idx].name)
		else:
			mtl_key = mtl_key.replace("<mat_name>","none")
		if mtl_key not in usedMtl:
			islandIdF = islandIdF+1.0
			usedMtl[mtl_key] = islandIdF
			mtlToIslMap[islandIdF] = mtl_key
			#print("- segmentMesh: mat-isl", islandIdF, mtl_key)
		polyisl = usedMtl[mtl_key]
		islandPerFace[ipoly] = polyisl
		if polyisl not in facePerIslands:
			facePerIslands[polyisl] = []
		facePerIslands[polyisl].append(ipoly)
	#print("- segmentMesh: islands+mat", islandIdF)
	return (islandIdF, mtlToIslMap), islandPerFace, facePerIslands

def getBMeshLinkedVerts(v, cache):
	linkverts = []
	for vf in v.link_faces:
		for sv in vf.verts:
			if sv != v and (sv not in linkverts):
				linkverts.append(sv)
	return linkverts

def edgeViewIniMeasure(v):
	return -1*v.co[2]

def edgeVertNearedVert(v, nearLoops, cache):
	if "allowedNearVertMap" not in cache:
		cache["allowedNearVertMap"] = {}
	cache_dict = cache["allowedNearVertMap"]
	if nearLoops not in cache_dict:
		cache_dict[nearLoops] = {}
	cache_dict_anvm = cache_dict[nearLoops]
	if v in cache_dict_anvm:
		return cache_dict_anvm[v]
	allowedNearVerts = set()
	wla_bm.bm_vertExtendByFaces(v, allowedNearVerts, nearLoops, True)
	cache_dict_anvm[v] = allowedNearVerts
	return allowedNearVerts

def edgeVert2VertDst(v1, v2, maxloops, cache, noPathVal):
	if "edgeVert2VertDst" not in cache:
		cache["edgeVert2VertDst"] = {}
	cache_dict = cache["edgeVert2VertDst"]
	# strong ordering: strong key, less cache misses
	if v1.index > v2.index:
		tmp = v2
		v2 = v1
		v1 = tmp
	v1_v2_key = str(v1.index)+"_"+str(v2.index)
	#v1_v2_noh_key = str(v1.index)+"_"+str(v2.index)+"_"+str(maxloops)
	if v1_v2_key in cache_dict:
		return cache_dict[v1_v2_key]
	# if v1_v2_noh_key in cache_dict:
	# 	return cache_dict[v1_v2_noh_key]
	for loopi in range(1,maxloops):
		va_nears = edgeVertNearedVert(v1, loopi, cache)
		if v2 in va_nears:
			cache_dict[v1_v2_key] = loopi
			return loopi
	loopi = noPathVal
	cache_dict[v1_v2_key] = loopi
	return loopi

def edgeVertNearedFaceIdx(v, nearLoops, cache):
	if "allowedNearFaceIdxMap" not in cache:
		cache["allowedNearFaceIdxMap"] = {}
	cache_dict = cache["allowedNearFaceIdxMap"]
	if nearLoops in cache_dict:
		anfim = cache_dict[nearLoops]
	else:
		anfim = {}
		cache_dict[nearLoops] = anfim
	if v in anfim:
		return anfim[v]
	allowedNearFaceIdx = set()
	allowedNearVerts = edgeVertNearedVert(v, nearLoops, cache)
	for ld_v in allowedNearVerts:
		for ld_f in ld_v.link_faces:
			allowedNearFaceIdx.add(ld_f.index)
	anfim[v] = allowedNearFaceIdx
	return allowedNearFaceIdx

def edgeVertNearedVertAvgLen(v, nearLoops, cache):
	if "allowedNearVertAvglenMap" not in cache:
		cache["allowedNearVertAvglenMap"] = {}
	allowedNearVertAvglenMap = cache["allowedNearVertAvglenMap"]
	if nearLoops in allowedNearVertAvglenMap:
		anvm = allowedNearVertAvglenMap[nearLoops]
	else:
		anvm = {}
		allowedNearVertAvglenMap[nearLoops] = anvm
	if v in anvm:
		return anvm[v]
	allowedNearVerts = edgeVertNearedVert(v,nearLoops,cache)
	sumlen = 0.0
	cntlen = 0.0
	for vv in allowedNearVerts:
		if vv.index == v.index:
			continue
		sumlen = sumlen+(vv.co-v.co).length
		cntlen = cntlen+1.0
	avglen = sumlen/cntlen
	anvm[v] = avglen
	return avglen

def edgeCreateCurves_v4(src_obj, in_edgeVerts, vertsEdgeType, vertsEdgeOpDir_l, verts2CamDst, hitcache):
	# curve-recreate approach
	# - merge by distance (in camera-plane projected space)
	# - start point - most sharp angle on others
	if len(in_edgeVerts) == 0:
		#print("- edgeCreateCurves_v4: no edgeVerts, skipping")
		return []
	possibleHeadVerts = None
	# if hitcache is not None and "possibleHeadVerts" in hitcache:
	# 	possibleHeadVerts = list(hitcache["possibleHeadVerts"])
	#optVVMergeDst = getEdgOpt(src_obj, "vv_merge_by_dst")
	optVVDst_2d = getEdgOpt(src_obj, "vv_fac_2d_dst")
	optVVDst_3d = getEdgOpt(src_obj, "vv_fac_3d_dst")
	optVVDst_cam = getEdgOpt(src_obj, "vv_fac_3d_ds_tocam")
	optVVDst_opendirdot = getEdgOpt(src_obj, "vv_fac_opendir_dot")
	optVVDst_loopsc = getEdgOpt(src_obj, "vv_fac_loops_cnt")
	curvb_UseLoopDiff = getEdgOpt(src_obj, "curve_break_use_loopdiff")
	optVVDst_loopsc_max = max(curvb_UseLoopDiff, 4)
	if "<EDIT_SEL>" in hitcache:
		curvb_UseLoopDiff = 0 # no need
	#optVVMergeDst = 0 # DBG
	#curvb_UseLoopDiff = 0 # DBG
	v2d_co = {}
	def vv_dst(v1, v2):
		prj1_co = v2d_co[v1]
		prj2_co = v2d_co[v2]
		eod1 = vertsEdgeOpDir_l[v1]
		eod2 = vertsEdgeOpDir_l[v2]
		dd_dst = (1.0-eod1.dot(eod2))
		dst2d = (prj2_co-prj1_co).length
		dst3d = ((src_obj.matrix_world @ v1.co) - (src_obj.matrix_world @ v2.co)).length
		edg_dst = edgeVert2VertDst(v1, v2, optVVDst_loopsc_max, hitcache, 999)
		if edg_dst == 999:
			edg_dst = optVVDst_loopsc_max+1.0
		dst_2cam = verts2CamDst[v1]+verts2CamDst[v2]
		# less value == more affinity
		return dst2d*optVVDst_2d + dst3d*optVVDst_3d + dd_dst*optVVDst_opendirdot + edg_dst*optVVDst_loopsc + dst_2cam*optVVDst_cam
	curves_all_v = []
	v2d_proj_cnt_g = Vector((0,0,0))
	# separating by vertsEdgeType
	usedVrtTypes = []
	for v1 in in_edgeVerts:
		et = vertsEdgeType[v1]
		v2d_proj_cnt_g = v2d_proj_cnt_g+v1.co
		if et not in usedVrtTypes:
			usedVrtTypes.append(et)
	# @as105:f3: FUCKUP с близкой камерой и вычислением проекций точек
	# - проекция ЗА камеру -> странности с детектом расстояний
	# - и ложные срабатывания merge by distance - потому что все проецируется в ОЧЕНЬ маленькую зону (с переворотом)
	# т.е. для объектов впритык к камере обратный каст ломает систему - нужен оффсет
	_, _, camera_gDir, _ = wla.active_camera()
	#v2d_proj_cnt_g = src_obj.matrix_world.to_translation() - camera_gDir*kWPL_optCamProjZShift_v4
	v2d_proj_cnt_g = src_obj.matrix_world @ (v2d_proj_cnt_g / len(in_edgeVerts)) + camera_gDir*kWPL_optCamProjZShift_v4
	#print("// Used vtypes:", usedVrtTypes)
	# if curvb_UseEtype < 1.0:
	# 	print("// - using ALL")
	# 	usedVrtTypes = ["*"] # no difference
	for ii, valid_et in enumerate(usedVrtTypes):
		#print("// i:",ii+1,"of",len(usedVrtTypes))
		in_edgeVerts2 = []
		for v1 in in_edgeVerts:
			et = vertsEdgeType[v1]
			if valid_et != "*" and et != valid_et:
				continue
			# calcing with offset: иначе проблемы с близкими ракурсами (@as105-f3)
			prj_co_l = wla.math_vecCamProj(src_obj, src_obj.matrix_world @ v1.co, True, v2d_proj_cnt_g)
			v2d_co[v1] = prj_co_l
			# if optVVMergeDst > 0.0:
			# 	# more factors to consider??? after bubbling?
			# 	for i in range(len(in_edgeVerts2)):
			# 		v2 = in_edgeVerts2[i]
			# 		prj2_co = v2d_co[v2]
			# 		if (prj2_co-prj_co_l).length < optVVMergeDst:
			# 			# ignoring this vert
			# 			prj_co_l = None
			# 			# replacing with camera-closest in in_edgeVerts2, if needed
			# 			if verts2CamDst[v2] > verts2CamDst[v1]:
			# 				in_edgeVerts2[i] = v1
			# 			break
			if prj_co_l is not None:
				in_edgeVerts2.append(v1)
		if len(in_edgeVerts2) == 0:
			# no verts of such type
			continue
		# first point
		# v1: most sharp angle from point to all others
		# v2: most difference direction of openside comparing to all other -> better for hairs, at least
		# v3: random probing, full search takes too long
		print("// searching first...", valid_et) # pow3 compexity
		# if (possibleHeadVerts is not None):
		# 	edgi = set(possibleHeadVerts).intersection(set(in_edgeVerts2))
		# 	if len(edgi) > 0:
		# 		# unsing verts as starting point
		# 		print("// - possible start points: using intersection", len(edgi))
		# 		possibleHeadVerts = list(edgi)
		# 	else:
		# 		print("// - possible start points: no use, ignoring")
		# 		possibleHeadVerts = None
		if (possibleHeadVerts is None):
			possibleHeadVerts = in_edgeVerts2
		# search_pts_len = len(possibleHeadVerts)
		# if search_pts_len > 150:
		# 	# randomizing - big meshes not bruteforcable
		# 	print("// - limiting, too much verts", search_pts_len)
		# 	search_pts_len = 150
		basePoints2 = []
		#sumDot = None
		search_pts_len = len(possibleHeadVerts)
		for i0 in range(0, 3):
			random.shuffle(possibleHeadVerts)
			for i1 in range(0, search_pts_len):
				sp1 = possibleHeadVerts[i1]
				sp2 = possibleHeadVerts[(i1+1) % len(possibleHeadVerts)]
				sp3 = possibleHeadVerts[(i1+2) % len(possibleHeadVerts)]
				sp1co = v2d_co[sp1]
				sp2co = v2d_co[sp2]
				sp3co = v2d_co[sp3]
				sp1dir = vertsEdgeOpDir_l[sp1]
				sp2dir = vertsEdgeOpDir_l[sp2]
				sp3dir = vertsEdgeOpDir_l[sp3]
				ddot = wla.math_remapRanged(sp1dir.dot(sp2dir) + sp1dir.dot(sp3dir), -2.0, 2.0, 1.0, -1.0) # bad cases - the better
				ddot = ddot * (100.0 - ((sp2co-sp1co).length+(sp3co-sp1co).length) ) # if close points - badliest case
				basePoints2.append((sp1, ddot))
		if len(basePoints2) == 0:
			continue
		basePoints2 = sorted(basePoints2, key=lambda itm:itm[1], reverse=True)
		basePoints_start = basePoints2[0][0]
		print("// merging points...") # pow2 compexity
		in_edgeVerts3 = []
		in_edgeVerts3.append(basePoints_start)
		while len(in_edgeVerts3) < len(in_edgeVerts2):
			sp1 = in_edgeVerts3[-1]
			nextp = None
			nextpDist = 999
			for sp2 in in_edgeVerts2:
				if sp2 in in_edgeVerts3:
					continue
				sp12len = vv_dst(sp1, sp2)
				if sp12len < nextpDist:
					nextpDist = sp12len
					nextp = sp2
			if nextp is None:
				break
			in_edgeVerts3.append(nextp)
		# optimizing curves
		curve = []
		for v in in_edgeVerts3:
			if curvb_UseLoopDiff > 0:
				if len(curve) > 0:
					v2v_loops = edgeVert2VertDst(v, curve[-1], curvb_UseLoopDiff, hitcache, 999)
					if v2v_loops == 999:
						# breaking here
						curves_all_v.append(curve)
						curve = []
			curve.append(v)
		curves_all_v.append(curve)
	hitcache["v2d_co"] = v2d_co
	return curves_all_v

def edgeOptimizeCurves_v4(src_obj, curves_all_v_ini, vertsEdgeOpDir_l, hitcache):
	#print("// start", len(curves_all_v_ini) )
	if "<EDIT_SEL>" in hitcache:
		return curves_all_v_ini
	if "v2d_co" not in hitcache:
		return curves_all_v_ini
	#v2d_co = hitcache["v2d_co"]
	bmesh_bvh_ini_l = None
	if hitcache is not None and "bmesh_bvh_ini_l" in hitcache:
		bmesh_bvh_ini_l = hitcache["bmesh_bvh_ini_l"]
	v3d_co = {}
	if "v3d_co" in hitcache:
		v3d_co = hitcache["v3d_co"]
	camera_gCo, camera_gOrtho, camera_gDir, _ = wla.active_camera()
	camera_lCo = src_obj.matrix_world.inverted() @ camera_gCo
	optOpeSideDot = getEdgOpt(src_obj, "curve_break_openside_dot")
	curves_all_v = []
	for curve_ini in curves_all_v_ini:
		curve2add = []
		for i,v in enumerate(curve_ini):
			isBreakHere = False
			if i > 0 and i < len(curve_ini)-1:
				dir2externs0 = vertsEdgeOpDir_l[curve_ini[i-1]]
				dir2externs1 = vertsEdgeOpDir_l[v]
				dir2externs2 = vertsEdgeOpDir_l[curve_ini[i+1]]
				if (1.0-dir2externs0.dot(dir2externs1)) + (1.0-dir2externs0.dot(dir2externs2)) > optOpeSideDot:
					isBreakHere = True
			if isBreakHere:
				if len(curve2add) >= kWPL_optCCurveMinLen:
					curves_all_v.append(curve2add)
				curve2add = []
			if bmesh_bvh_ini_l is not None:
				# bubbling points
				if camera_gOrtho == False:
					bmesh_co_l = camera_lCo
					bmesh_dir_l = (v.co - camera_lCo).normalized() # Perspective
				else:
					bmesh_co_l = v.co - camera_gDir*1.0
					bmesh_dir_l = camera_gDir
				#hit_l, _, _, _ = bmesh_bvh_ini_l.ray_cast(camera_lCo, bmesh_dir_l)
				hit_l,_ = wla_bm.bm_fuzzyBVHRayCast_v01(bmesh_bvh_ini_l, bmesh_co_l, bmesh_dir_l, kWPL_optCamBubblingFuzzy[0], kWPL_optCamBubblingFuzzy[1], 'MIN_ON_DIR')
				if hit_l is not None:
					#print("- bubbled2", v.index, (hit_l-v.co).length)
					v3d_co[v.index] = hit_l
			#hit_g, _ = wla_bm.bm_fuzzyBVHRayCast_v01(depsgraph, proj_from_g, proj_dir_g, abs(opt_castFeatsFuzz[0])/10000, int(opt_castFeatsFuzz[1]), 'MAX_ON_DIR')
			curve2add.append(v)
		if len(curve2add) > 0:
			if len(curve2add) >= kWPL_optCCurveMinLen:
				curves_all_v.append(curve2add)
			curve2add = []
	hitcache["v3d_co"] = v3d_co
	return curves_all_v

# ==============================

def generateLineartCurves(src_obj, opts = None):
	curves_all = []
	md = wla.modf_by_type(src_obj, None, kWPL_EdgeModf_DBGLineArt)
	if md is  None:
		return None
	wla_do.select_and_change_mode(src_obj, 'OBJECT')
	src_obj.hide_viewport = False
	src_obj.hide_render = False
	md.show_render = True
	md.show_viewport = True
	src_obj_mw = src_obj.matrix_world
	wla_do.sys_update_view(True, False)
	depsgraph = bpy.context.evaluated_depsgraph_get()
	obj_eval = src_obj.evaluated_get(depsgraph)
	# print("- gp original:", src_obj, src_obj.data)
	# print("- gp evaluated:", obj_eval, obj_eval.data)
	splines = wla_curve.cu_getSplines(obj_eval)
	for i, polyline in enumerate(splines):
		points = wla_curve.cu_getPoints(polyline)
		if len(points)<2:
			continue
		curve = []
		for pt in points:
			v_co = Vector( (pt.co[0], pt.co[1], pt.co[2]) )
			curve.append( src_obj_mw @ v_co )
		curves_all.append(curve)
	return {"curves": curves_all}

def generateCurveCurves(src_obj, opts = None):
	# reapplying shrinkwrap first, if any
	src_obj_mw = src_obj.matrix_world
	wla_do.select_and_change_mode(src_obj, 'OBJECT')
	bpy.ops.curve.wplcurve_cnormalize(opt_reapplyShrinkw=True, opt_reapplyDistribute=False, opt_ensureSegmentLength = 0.0)
	curves_all = []
	curves_all_rad = []
	splines = wla_curve.cu_getSplines(src_obj)
	min_rad = 999
	for i, polyline in enumerate(splines):
		points = wla_curve.cu_getPoints(polyline)
		if len(points)<2:
			continue
		curve = []
		curve_rad = []
		for pt in points:
			v_co = Vector( (pt.co[0], pt.co[1], pt.co[2]) )
			curve.append( src_obj_mw @ v_co )
			rad = max(pt.radius, 0.00001)
			min_rad = min(min_rad, rad)
			curve_rad.append(rad)
		curves_all.append(curve)
		curves_all_rad.append(curve_rad)
	# normalizing radius - need relative scale only
	for curve_rad in curves_all_rad:
		for i in range(len(curve_rad)):
			curve_rad[i] = curve_rad[i]/min_rad
	return {"curves": curves_all, "curves_radius": curves_all_rad}

def generateFreestyleCurves(src_obj, src_bm, verts_ovl, opts):
	src_obj_mw = src_obj.matrix_world
	cuh_lifting = None
	cuh_radius = None
	if opts is not None:
		if "cuh_lifting" in opts:
			cuh_lifting = opts["cuh_lifting"]
		if "cuh_radius" in opts:
			cuh_radius = opts["cuh_radius"]
	curves_all = []
	curves_radius =[]
	if verts_ovl is None:
		# # freestyle edges - not needed anymore
		# # src_bm MUST match src_obj!!! Indexes are important
		# (edgesIdx, _) = wla_meshwrap.objectm_extractEdgesByType(src_obj)
		# if edgesIdx is None:
		# 	return {"curves": []}
		# # ??? need edges from BMesh - since indexes may be not the same anymore
		# # fs = src_bm.edges.layers.freestyle.active
		# # for e in src_bm.edges:
		# # 	print(e[fs]) -> not implemented
		# opt_flowDir = Vector((0.0,0.0,-1.0))
		# vertsIdx = []
		# for eIdx in edgesIdx:
		# 	e = src_bm.edges[eIdx]
		# 	if e.verts[0].index not in vertsIdx:
		# 		vertsIdx.append(e.verts[0].index)
		# 	if e.verts[1].index not in vertsIdx:
		# 		vertsIdx.append(e.verts[1].index)
		# strands_points, strands_vidx = wla_bm.bm_edgesAsStrands_v04(src_obj, src_bm, vertsIdx, edgesIdx, opt_flowDir, src_obj)
		# if strands_points is not None:
		# 	for strand_vids in strands_vidx:
		# 		if len(strand_vids) < 2:
		# 			continue
		# 		curve_co = []
		# 		curve_radius = []
		# 		for i, vIdx in enumerate(strand_vids):
		# 			v_fac = float(i)/float(len(strand_vids)-1)
		# 			v = src_bm.verts[vIdx]
		# 			v_co = v.co
		# 			v_rad = 1.0
		# 			if cuh_lifting is not None:
		# 				v_co = v_co + v.normal * wla.remap_curve_hash(cuh_lifting, v_fac)
		# 			if cuh_radius is not None:
		# 				v_rad = v_rad * wla.remap_curve_hash(cuh_radius, v_fac)
		# 			curve_co.append( src_obj_mw @ v_co )
		# 			curve_radius.append(v_rad)
		# 		curves_all.append(curve_co)
		# 		curves_radius.append(curve_radius)
		# return {"curves": curves_all, "curves_radius": curves_radius } #, "curves_vIdx": curves_vIdx
		return {"curves": []}
	curve_co = []
	curve_radius = []
	for i,vIdx in enumerate(verts_ovl):
		if vIdx < 0:
			# broken non-matched vert
			print("- generateFreestyleCurves: unmatched vert")
			continue
		v_fac = float(i)/float(len(verts_ovl)-1)
		v = src_bm.verts[vIdx]
		v_co = v.co
		v_rad = 1.0
		if cuh_lifting is not None:
			v_co = v_co + v.normal * wla.remap_curve_hash(cuh_lifting, v_fac)
		if cuh_radius is not None:
			v_rad = v_rad * wla.remap_curve_hash(cuh_radius, v_fac)
		curve_co.append( src_obj_mw @ v_co )
		curve_radius.append(v_rad)
	curves_all.append(curve_co)
	curves_radius.append(curve_radius)
	return {"curves": curves_all, "curves_radius": curves_radius }

def object_ensureGP(gpData):
	gpData.stroke_depth_order = '3D'
	gpData.pixel_factor = 0.1
	gpData.stroke_thickness_space = 'WORLDSPACE'
def object_removeGPmodf(edg_curve):
	mds = list(edg_curve.grease_pencil_modifiers)
	for md in edg_curve.grease_pencil_modifiers:
		edg_curve.grease_pencil_modifiers.remove(md)
def object_optimizeGPLayers(edg_curve, doSort, doMergeSames):
	gpData = edg_curve.data
	if doSort:
		print("- GP: sorting layers")
		maxBubble = 0
		while maxBubble < 100:
			isAnyChange = 0
			for li in range(0, len(gpData.layers)-1):
				layer1 = gpData.layers[li]
				layer2 = gpData.layers[li+1]
				info1 = layer1.info
				info2 = layer2.info
				if "." not in info1:
					info1 = info1+".000"
				if "." not in info2:
					info2 = info2+".000"
				if info1 > info2:# layer name
					bpy.ops.gpencil.layer_change(layer=layer1.info)
					# print("- GP: switching", maxBubble, li, layer1.info, layer2.info, gpData.layers.active)
					bpy.ops.gpencil.layer_move(type='UP')
					isAnyChange = isAnyChange+1
					maxBubble = maxBubble+1
			if isAnyChange == 0:
				break
		print("- GP: sorting done at", maxBubble)
	if doMergeSames:
		print("- GP: merging layers")
		maxBubble = 0
		while maxBubble < 100:
			isAnyChange = 0
			for li in range(0, len(gpData.layers)-1):
				layer1 = gpData.layers[li]
				layer2 = gpData.layers[li+1]
				info1 = wla.strBareName(layer1.info, True, True, True, False, False, False)
				info2 = wla.strBareName(layer2.info, True, True, True, False, False, False)
				if info1 == info2:
					bpy.ops.gpencil.layer_change(layer=layer2.info)
					print("- GP: merging", maxBubble, li, layer1.info, layer2.info, gpData.layers.active)
					bpy.ops.gpencil.layer_merge(mode='ACTIVE')
					isAnyChange = isAnyChange+1
					maxBubble = maxBubble+1
					break
			if isAnyChange == 0:
				break
		print("- GP: merging done at", maxBubble)

def object_addEdgingGP(edg_curve_name, root_pref, layer_name, matColorHex, refObj):
	# https://github.com/elias-schwarze/fritzi-toolbox/blob/7a22793c9d86cd4534e3c416ee209d57597ae2a5/default_setup/ftb_default_lineart_op.py
	edg_curve = wla.object_by_name(edg_curve_name)
	gpData = None
	if edg_curve is None:
		# deleting data-block, if any - manual deletion was performed
		gpData = bpy.data.grease_pencils.get(edg_curve_name)
		if gpData is not None:
			bpy.data.grease_pencils.remove(gpData)
	gpData = bpy.data.grease_pencils.get(edg_curve_name)
	if gpData is None:
		gpData = bpy.data.grease_pencils.new(name=edg_curve_name)
	if edg_curve is None:
		edg_curve = bpy.data.objects.new(edg_curve_name, gpData)
		edg_curve.show_in_front = True
		if refObj is not None:
			edg_curve.matrix_world = Matrix.LocRotScale(refObj.matrix_world.to_translation(), Matrix.Identity(3), Vector((1,1,1)))
		# not for now, too much "broken" lines
		# md = edg_curve.grease_pencil_modifiers.new(kWPL_EdgeModf_ExportSimplify, 'GP_SIMPLIFY')
		# md.mode = 'ADAPTIVE'
		# md.factor = 0.005
		md = edg_curve.grease_pencil_modifiers.new(kWPL_EdgeModf_DBGBold, 'GP_THICK')
		md.thickness_factor = kWPL_EdgeModf_DBGBold_Scaler
		md.show_render = False
		md.show_viewport = False
		md.show_in_editmode = True
		helpers_obj = wla.sys_empty(config.kWPLSystemObjSysEHelpers+root_pref)
		wla_do.ensure_visible(helpers_obj, 2)
		wla_do.link_object_to_scene(edg_curve, helpers_obj, 1)
		wla_do.set_object_noShadow(edg_curve, False, True) # no shadow, no render
		#wla_attr.vc_obj_update(edg_curve, 'PROP', config.kWPLMeshColVC, wla.hexToVectorRGB("#000000") ,(1,1,1), 1.0, None, None, None)
		wla_attr.vc_obj_setPropCol(edg_curve, config.kWPLMeshColVC, wla.hexToVectorRGB("#000000"), 'PROP_NON_GAMMA')
	# wla_do.select_and_change_mode(edg_curve,'EDIT')
	gpData = edg_curve.data # MAY CHANGE!
	object_ensureGP(gpData)
	if gpData.layers is not None and gpData.layers.get(layer_name) is not None:
		gpLayer = gpData.layers.get(layer_name)
		gpData.layers.active = gpLayer
		# gpData.layers.active_index = wla.arrIndexOf(gpData.layers, gpLayer, 0)
	else:
		gpLayer = gpData.layers.new(layer_name, set_active=True)
	gpLayer.use_lights = False # important for DBG-View in Cycles
	if matColorHex is not None:
		color = wla.hexToVectorRGB(matColorHex)
		color = (math.pow(color[0], 2.2), math.pow(color[1], 2.2), math.pow(color[2], 2.2) ) # From GAMMA
		gpLayer.color = color
		gpLayer.tint_color = color
		gpLayer.tint_factor = 1.0
	if gpLayer.frames is None or len(gpLayer.frames) == 0:
		gpLayer.frames.new(frame_number = 0, active = True)
		gpLayerFrame = gpLayer.frames[0]
	else:
		# gpLayer.frames.new(frame_number = 0, active = True)
		gpLayerFrame = gpLayer.frames[-1]
		# # wla_do.sys_update_view(True, True)
		# gpLayerFrame = gpLayer.active_frame
		# if (gpLayerFrame is None) or (gpLayerFrame.frame_number != 0): # gpLayer GPencilFrames
		# 	# can be non-0 при разных операциях
		# 	gpLayerFrame = gpLayer.frames[0]
	if gpLayer.active_frame != gpLayerFrame or len(gpLayer.frames) > 1:
		print("- WTF frames:", gpLayerFrame, gpLayer.active_frame, gpLayer.frames)
	# 	#wla_do.sys_dump_pythonobj(gpLayer)
	mat_idx = None
	if matColorHex is not None:
		matName = "zzz_gp_"+layer_name+"_"+matColorHex	
		mat_idx = wla_attr.mat_obj_ensureGpMat(edg_curve, matName, matColorHex, False)
	wla_do.ensure_visible(edg_curve, 2)
	#wla_do.sys_update_mesh(edg_curve)
	# bpy.context.active_gpencil_frame = gpLayerFrame
	return (edg_curve, gpLayer, gpLayerFrame, mat_idx)

def object_addEdgingCurve(edg_curve_name, root_pref, sel_obj, separated, defMat):
	edg_curve = wla.object_by_name(edg_curve_name) # ??? + config.kWPLObjProtoToken[0]
	if edg_curve is not None:
		return edg_curve
	print("- edging curve: adding new", edg_curve_name, separated)
	curveDataName = edg_curve_name+'_curve'
	curveData = bpy.data.curves.new(curveDataName, type='CURVE')
	curveData.dimensions = '3D'
	curveData.fill_mode = 'FULL'
	curveData.bevel_resolution = 2
	curveData.use_fill_caps = True
	curveData.use_auto_texspace = True
	curveData.bevel_depth = 1.0
	curveData.splines.clear()
	edg_curve = bpy.data.objects.new(edg_curve_name, curveData)
	if separated:
		helpers_obj = wla.sys_empty(config.kWPLSystemObjSysEHelpers+root_pref)
		wla_do.ensure_visible(helpers_obj, 2)
		wla_do.link_object_to_scene(edg_curve, helpers_obj, 1)
	else:
		wla_do.link_object_sideBySide(edg_curve, sel_obj)
	wla_do.set_object_noShadow(edg_curve, False, False) # no shadow, but renderable
	#wla_attr.vc_obj_update(edg_curve, 'PROP', config.kWPLMeshColVC, wla.hexToVectorRGB("#000000") ,(1,1,1), 1.0, None, None, None)
	wla_attr.vc_obj_setPropCol(edg_curve, config.kWPLMeshColVC, wla.hexToVectorRGB("#000000"), 'PROP_NON_GAMMA')
	# shrinkwrap_modifier2 = edg_curve.modifiers.new(name = "WPL_Edge2src2", type = 'SHRINKWRAP')
	# shrinkwrap_modifier2.offset = curve_radius*0.3
	# shrinkwrap_modifier2.target = sel_obj
	# shrinkwrap_modifier2.use_apply_on_spline = True
	# shrinkwrap_modifier2.wrap_method = 'NEAREST_SURFACEPOINT'
	# shrinkwrap_modifier2.wrap_mode = 'ABOVE_SURFACE'
	#matrix_world = wla.math_matrixReplace(edg_curve.matrix_world, None, None, (1.0, 1.0, 1.0))
	#edg_curve.matrix_world = matrix_world
	# copyRotCon = edg_curve.constraints.new('COPY_ROTATION')
	# copyRotCon.target = sel_obj
	# copyLocCon = edg_curve.constraints.new('COPY_LOCATION')
	# copyLocCon.target = sel_obj
	# copyLocCon.use_offset = False
	#copyRotCon = edg_curve.constraints.new('COPY_TRANSFORMS')
	#copyRotCon.target = sel_obj
	if separated:
		obj_root = wla.object_sceneroot(sel_obj)
		edg_curve.matrix_world = obj_root.matrix_world
		print("// constraining to", obj_root.name, edg_curve.name)
		copyRotCon = edg_curve.constraints.new('COPY_TRANSFORMS')
		copyRotCon.target = obj_root
	else:
		edg_curve.matrix_world = sel_obj.matrix_world
	# important to have any (for universal displacements to work)
	if defMat is None:
		if len(sel_obj.data.materials) > 0:
			curveMat = sel_obj.data.materials[0]
			edg_curve.data.materials.append(curveMat)
	else:
		edgingMat = wla_attr.mat_find_any(defMat)
		wla_attr.mat_obj_ensuremat(sel_obj, edgingMat, True)
	return edg_curve

# ==============================

def generateEdgingCurves(src_obj, src_bm, src_faces, opts):
	camera_gCo, camera_gOrtho, camera_gDir, camera_gDirUp = wla.active_camera()
	if camera_gCo is None:
		return None
	kWPL_cfg_v4["GENID"] = kWPL_cfg_v4["GENID"]+1
	src_obj_mw = src_obj.matrix_world
	src_obj_mw_nrm_g = src_obj_mw.inverted().transposed().to_3x3()
	camera_lCo = src_obj_mw.inverted() @ camera_gCo
	camera_lDir = src_obj_mw_nrm_g.inverted() @ camera_gDir
	def getRayOpts_l(v):
		if camera_gOrtho:
			bmesh_orig = v.co + camera_lDir*kWPL_EdgeOrthoRevOffset
			bmesh_dir = -1*camera_lDir
		else:
			bmesh_orig = camera_lCo
			bmesh_dir = (v.co - camera_lCo).normalized()
		return(bmesh_orig, bmesh_dir)
	post_nrm_offset = 0
	open_edge_verts = []
	allow_backfaces = False
	hitcache = {}
	if opts is not None:
		if "post_nrm_offset" in opts:
			post_nrm_offset = opts["post_nrm_offset"]
		if "open_edge_verts" in opts:
			open_edge_verts = opts["open_edge_verts"]
		if "allow_backfaces" in opts:
			allow_backfaces = opts["allow_backfaces"]
		if "island_desc" in opts:
			if "<EDIT_SEL>" in opts["island_desc"]:
				# special stuff must be disabled
				hitcache["<EDIT_SEL>"] = True
	cast_shift_delta = kWPLEdgeCastShiftDelta
	src_bm_vertIslId = {}
	# src_bm_islandId = 1
	# src_bm_meshIslands = wla_bm.bm_expandVertsToIslands_v02(src_bm, None, None)
	# print("- generateEdgingCurves: calced islands", len(src_bm_meshIslands))
	# for meshlist in src_bm_meshIslands:
	# 	if len(meshlist)>0:
	# 		src_bm_islandId = src_bm_islandId+1
	# 		for vidx in meshlist:
	# 			src_bm_vertIslId[vidx] = src_bm_islandId
	#print("- cast_shift_delta:", cast_shift_delta)
	# creating BVHTrees for nearness raycasting
	# !!! epsilon==0.0, local coords
	# **: FromBMesh Not ok for hairs, need separated BVH with src_faces ONLY
	#bmesh_bvh_ini_l = BVHTree.FromBMesh(src_bm, epsilon=0.0)
	if kWPL_cfg_v4["DBG_DUMP_MESHES"] != 0:
		wla_do.sys_dump_bmesh(src_obj, src_bm, src_faces, "_edgeTest"+str(kWPL_cfg_v4["GENID"])+"_"+opts["island_desc"])
	bmesh_bvh_ini_l, bvh_polySel = wla_bm.bm_BVHFromFaces(src_bm, src_faces)
	#zForward = (src_obj.matrix_world.to_translation() - camera_gCo).normalized()
	perp1_g = camera_gDir.cross(camera_gDirUp)
	perp2_g = perp1_g.cross(camera_gDir)
	perp1 = src_obj_mw_nrm_g.inverted() @ perp1_g
	perp2 = src_obj_mw_nrm_g.inverted() @ perp2_g
	shiftBVH_l = []
	shiftDirs = [(0,0,0),perp1,perp2,-1*perp1,-1*perp2]
	shiftDirs.extend([(perp1+perp2),(perp1-perp2),(-1*perp1+perp2),(-1*perp1-perp2)])
	for sdir in shiftDirs:
		shiftBVH_l.append((bmesh_bvh_ini_l, Vector(sdir).normalized()*cast_shift_delta))
	# 1) getting initial verts cloud
	print("- Filtering verts, (verts: "+str(len(src_bm.verts))+")")
	curves_all = []
	verts2CamDst = {}
	verts2CamDir = {}
	allVertsCnd = []
	walkedVerts = set()
	possibleHeadVerts = set()
	for v in src_bm.verts:
		# if not in selected faces -> Ignoring
		if camera_gOrtho:
			direction = camera_lDir
			v_cam_proj = v.co-(direction.dot(v.co-camera_lCo)*direction)
			verts2CamDst[v] = (v_cam_proj-v.co).length
		else:
			direction = (camera_lCo-v.co).normalized()
			verts2CamDst[v] = (camera_lCo-v.co).length
		verts2CamDir[v] = direction
		if allow_backfaces == False:
			v2cd = direction.dot(v.normal)
			if (kWPL_optMaxInNoDot is not None) and (v2cd < kWPL_optMaxInNoDot):
				# blocked from traversing anyway
				walkedVerts.add(v)
				continue
		if v.index in open_edge_verts:
			# not for edging
			walkedVerts.add(v)
			for e in v.link_edges:
				possibleHeadVerts.add(e.other_vert(v).index)
			continue
		isVertOk = False
		for f in v.link_faces:
			if (src_faces is None) or (f.index in src_faces):
				isVertOk = True
				break
		if isVertOk == False:
			walkedVerts.add(v)
			continue
		if (v not in allVertsCnd):
			allVertsCnd.append(v)
	# 2) removing definitely inner verts 
	# from backfaces and overlapped by front part
	allVertsCnd2 = []
	for v in allVertsCnd:
		if v not in verts2CamDst:
			print("- WARNING: vert not in verts2CamDst",v)
			continue
		isAnyHitGotNearFace = False
		bmesh_orig_l, bmesh_dir_l = getRayOpts_l(v)
		for i in range(1,len(shiftBVH_l)):
			bmesh_bvh = shiftBVH_l[i][0]
			bmesh_sht_l = shiftBVH_l[i][1]
			hit, normal, bvh_findex, distance = bmesh_bvh.ray_cast(bmesh_orig_l+bmesh_sht_l, bmesh_dir_l)
			findex = None
			if bvh_findex is not None:
				findex = bvh_polySel[bvh_findex]
			if hit is not None:
				allowedNearFaceIdx = edgeVertNearedFaceIdx(v, kWPL_optVertTstLdiff, hitcache)
				if len(allowedNearFaceIdx)>0 and (findex in allowedNearFaceIdx):
					isAnyHitGotNearFace = True
					break
		if isAnyHitGotNearFace:
			allVertsCnd2.append(v)
	allVertsCnd = allVertsCnd2
	allVertsCnd = sorted(allVertsCnd,key=lambda v:verts2CamDst[v], reverse=False)
	if len(allVertsCnd) == 0:
		print("- Getting contours... skipped, no bndverts")
		return {"curves": []}
	if kWPL_cfg_v4["DBG_LEVEL"] == 1:
		for i,v in enumerate(allVertsCnd):
			#curves_all.append([v,allVertsCnd[(i+1)%len(allVertsCnd)],allVertsCnd[(i+2)%len(allVertsCnd)]])
			curves_all.append([src_obj_mw @ v.co, src_obj_mw @ (v.co+v.normal*0.01) ])
		print("- DBG: ok points:", len(allVertsCnd))
		return {"curves": curves_all, "debug": 1}

	print("- Getting contours... (bndverts: "+str(len(allVertsCnd))+")")
	# 3) getting contours
	edgeVerts = []
	maxRootFirst = -1
	#nonEdgeVerts = []
	vertsEdgeType = {}
	vertsEdgeOpDir_l = {}
	for av in allVertsCnd:
		if maxRootFirst == 0:
			# print("- stopping, rootfirsts limit")
			break
		#print("-- Starting rootfirst",abs(maxRootFirst))
		maxRootFirst = maxRootFirst-1
		if av in walkedVerts:
			continue
		# first point
		walklist = [av]
		while (len(walklist)>0):
			v = walklist.pop(0)
			walkedVerts.add(v)
			isAnyEdge = 0
			isEdge = False
			if isEdge == False:
				bmesh_orig_l, bmesh_dir_l = getRayOpts_l(v)
				distance0 = (bmesh_orig_l-v.co).length
				for i in range(1,len(shiftBVH_l)):
					isEdge = False
					if isEdge == False:
						bmesh_bvh = shiftBVH_l[i][0]
						bmesh_sht_l = shiftBVH_l[i][1]
						hit, normal, bvh_findex, distance = bmesh_bvh.ray_cast(bmesh_orig_l+bmesh_sht_l, bmesh_dir_l)
						findex = None
						if bvh_findex is not None:
							findex = bvh_polySel[bvh_findex]
						if hit is not None and (normal.dot(v.normal) < 0):
							hit = None
						if hit is None:
							isEdge = True
							vertsEdgeType[v] = "et:open"
						elif distance>distance0:
							if isEdge == False:
								if (hit - v.co).length >= kWPL_optMaxZdiff:
									# is this "far" point several loops away?
									# or a backface face
									allowedNearFaceIdx = edgeVertNearedFaceIdx(v, kWPL_optVertMaxL1diff, hitcache)
									if (len(allowedNearFaceIdx)>0 and (findex is not None and findex not in allowedNearFaceIdx)):
										isEdge = True
										vertsEdgeType[v] = "et:zdiff"
					if isEdge == True:
						if v.index in src_bm_vertIslId:
							vertsEdgeType[v] = vertsEdgeType[v] + "_" + str(src_bm_vertIslId[v.index])
						isAnyEdge = isAnyEdge+1
						if bmesh_sht_l is not None:
							if v not in vertsEdgeOpDir_l:
								vertsEdgeOpDir_l[v] = Vector((0,0,0))
							vertsEdgeOpDir_l[v] = vertsEdgeOpDir_l[v] + bmesh_sht_l
			if isAnyEdge > 0:
				if (v not in edgeVerts):
					edgeVerts.append(v)
					# blocking all verts on sight -> must select most far on dir... not possible in advance
					# cro = getRayOpts_l(v)
					# cro_dir = cro[1]
					# vnv = edgeVertNearedVert(v, kWPL_optVertMaxL1diff, hitcache)
					# for sv in vnv:
					# 	svv = (sv.co - v.co).normalized()
					# 	if abs(svv.dot(cro_dir)) > kWPL_optEdgeTunnlDot:
					# 		walkedVerts.add(sv)
			if isAnyEdge == 0:
				#nonEdgeVerts.append(v)
				linkv = getBMeshLinkedVerts(v, hitcache)
				for sv in linkv:
					if (sv not in walklist) and (sv not in walkedVerts):
						walklist.append(sv)

	# normalizing openside direction
	for v in vertsEdgeOpDir_l:
		vertsEdgeOpDir_l[v] = vertsEdgeOpDir_l[v].normalized()
	edgeVerts = sorted(edgeVerts, key=lambda v:edgeViewIniMeasure(v), reverse=False)
	if kWPL_cfg_v4["DBG_LEVEL"] == 2:
		for i,v in enumerate(edgeVerts):
			dst = 0.003 #+0.002*int(vertsEdgeType[v])
			dir = vertsEdgeOpDir_l[v]
			v_co = v.co
			curves_all.append([src_obj_mw @ v_co, src_obj_mw @ (v_co+dir*dst) ])
		print("- DBG: Pre-curve points: "+str(len(curves_all)))
		return {"curves": curves_all, "debug": 1}
	
	# 4) building curves
	if len(edgeVerts) > 1000:
		print("- Building curves(v4): SKIPPED, too many (edgeverts: "+str(len(edgeVerts))+")")
		return {"curves": curves_all}
	print("- Building curves(v4)... (edgeverts: "+str(len(edgeVerts))+")")
	hitcache["bmesh_bvh_ini_l"] = bmesh_bvh_ini_l
	#hitcache["possibleHeadVerts"] = possibleHeadVerts
	curves_all_v = edgeCreateCurves_v4(src_obj, edgeVerts, vertsEdgeType, vertsEdgeOpDir_l, verts2CamDst, hitcache)
	flat_list_curves_all_v = [item for sublist in curves_all_v for item in sublist]
	if kWPL_cfg_v4["DBG_LEVEL"] == 3 and "v2d_co" in hitcache:
		v2d_co = hitcache["v2d_co"]
		for i,v in enumerate(flat_list_curves_all_v):
			dst = 0.003 #+0.002*int(vertsEdgeType[v])
			dir = vertsEdgeOpDir_l[v]
			v_co = v2d_co[v] #v.co
			curves_all.append([src_obj_mw @ v_co, src_obj_mw @ (v_co+dir*dst) ])
		print("- DBG: Pre-curve points: "+str(len(curves_all)))
		return {"curves": curves_all, "debug": 1}

	# 5) rejoining and optimizing curves
	print("- Optimizing curves(v4)... (curves: "+str(len(curves_all_v))+", pts: "+str(len(flat_list_curves_all_v))+")")
	curves_all_v = edgeOptimizeCurves_v4(src_obj, curves_all_v, vertsEdgeOpDir_l, hitcache)
	v3d_co = None # vert positionss can be "optimized" during build
	if "v3d_co" in hitcache:
		v3d_co = hitcache["v3d_co"]
	for v_curve in curves_all_v:
		curve_co = []
		for v in v_curve:
			v_co = v.co
			if v3d_co is not None and v.index in v3d_co:
				v_co = v3d_co[v.index]
			dir2externs = vertsEdgeOpDir_l[v]
			curve_co.append( src_obj_mw @ (v_co + post_nrm_offset * dir2externs) )
		curves_all.append(curve_co)
	if kWPL_cfg_v4["DBG_LEVEL"] == 4:
		# marking starting points
		for v_curve in curves_all_v:
			for v in v_curve:
				dst = 0.005
				dir = vertsEdgeOpDir_l[v]
				v_co = v.co # 3D coord, not projected v2d_co[v] coord
				if v3d_co is not None and v.index in v3d_co:
					v_co = v3d_co[v.index]
				curves_all.append([src_obj_mw @ v_co, src_obj_mw @ (v_co+dir*dst) ])
				break
	return {"curves": curves_all}
