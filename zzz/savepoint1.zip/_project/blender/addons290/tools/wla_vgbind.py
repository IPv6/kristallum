import os, sys, time, datetime
import math, copy, string, random
import numpy as np
import bpy, bmesh, mathutils

import bpy.types
from mathutils import Vector, Matrix, Euler, Quaternion
from mathutils.bvhtree import BVHTree
from mathutils.kdtree import KDTree
from bpy_extras import view3d_utils
from bpy.props import *

from . import wla
from . import wla_do
from . import wla_bm
from .. import config

kBindNearVertsLim = 14
kBindScaleFac = 1000.0
kBindWeightDstPow = 2.0
#kBindWeightDropFac = 0.9
kBindAxisDotDropFac = 0.9
	
def obj_checkUnwrap(active_obj, forced = False):
	if active_obj.type != 'MESH':
		return True
	if wla.isTokenInStr(config.kWPLObjCharHairsPostfix, active_obj.name):
		# no need to check
		return True
	if wla.isTokenInStr([config.kWPLObjCharBodyPostfix, config.kWPLObjCharHeadPostfix], active_obj.name) or forced:
		# checking for non-duplicated UV-unwrap
		_, _, vertDupes = bm_getUvMappingAtMeshData(active_obj.data, config.kWPLGridUV)
		if (vertDupes is None):
			print("- Problem: UV unwrap not found:", active_obj.name)
			if forced:
				return False
			return True
		if len(vertDupes) > 0:
			print("- Problem: UV duplications found:", active_obj.name)
			print("//", vertDupes)
			if forced:
				for vIdx in vertDupes:
					v = active_obj.data.vertices[vIdx]
					v.select = True
			return False
	return True

def obj_calcStableIdxMap(cage_base, cage_base_meshdata):
	# uvmap_inv_base: uvmap_inv_base[vIdx] = key
	if cage_base.type != 'MESH':
		return None
	_, uvmap_inv_base, _ = bm_getUvMappingAtMeshData(cage_base_meshdata, config.kWPLGridUV)
	if uvmap_inv_base is None:
		uvmap_inv_base = {}
		# fallback to co2key. Not working with subdivisions/deforms
		bm_tmp = bmesh.new()
		bm_tmp.from_mesh(cage_base_meshdata)
		bm_tmp.verts.ensure_lookup_table()
		bm_tmp.verts.index_update()
		bm_tmp.edges.ensure_lookup_table()
		bm_tmp.edges.index_update()
		bm_tmp.faces.ensure_lookup_table()
		bm_tmp.faces.index_update()
		for v in bm_tmp.verts:
			uvmap_inv_base[v.index] = wla.coToKey(v.co)
		bm_tmp.free()
	return uvmap_inv_base

def obj_compareStableIdxMaps(uvmap_base1, uvmap_base2):
	if uvmap_base1 is None or uvmap_base2 is None:
		return None, None
	inv1 = {uvmap_base1[k] : k for k in uvmap_base1}
	inv2 = {uvmap_base2[k] : k for k in uvmap_base2}
	map_new2old = {}
	for v2Idx in uvmap_base2.keys():
		v2Key = uvmap_base2[v2Idx]
		if v2Key in inv1:
			map_new2old[v2Idx] = inv1[v2Key]
	map_old2new = {}
	for v1Idx in uvmap_base1.keys():
		v1Key = uvmap_base1[v1Idx]
		if v1Key in inv2:
			map_old2new[v1Idx] = inv2[v1Key]
	return map_new2old, map_old2new

def bm_getUvMappingAtMeshData(cage_base_meshdata, uvId):
	if cage_base_meshdata is None:
		return None, None, None
	uv_base = cage_base_meshdata.uv_layers.get(uvId)
	if uv_base is None:
		# config.kWPLGridUV
		return None, None, None
	# uv -> vertex index on base mesh
	uvmap_base = {}
	uvmap_inv_base = {}
	uvmap_base_dups = set()
	uvmap_base_loos = set()
	face_verts = set()
	for poly in cage_base_meshdata.polygons:
		ipoly = poly.index
		for idx, lIdx in enumerate(cage_base_meshdata.polygons[ipoly].loop_indices):
			vIdx = cage_base_meshdata.polygons[ipoly].vertices[idx]
			luv = uv_base.data[lIdx].uv
			luv_kk = wla.uvToKey(luv)
			if luv_kk == "u0_v0":
				# new face, added post-factum has NO uv unwrap -> can be ignored
				# print("- skip", vIdx, luv_kk)
				continue
			if (luv_kk in uvmap_base) and (uvmap_base[luv_kk] != vIdx):
				# duplications!!!
				#print("- dupe", vIdx, luv_kk, uvmap_base[luv_kk])
				uvmap_base_dups.add(vIdx)
			uvmap_base[luv_kk] = vIdx
			uvmap_inv_base[vIdx] = luv_kk
		for vIdx in poly.vertices:
			face_verts.add(vIdx)
	# checking for loose verts and wire-edges
	for v in cage_base_meshdata.vertices:
		if v.index not in face_verts:
			uvmap_base_loos.add(v.index)
	if len(uvmap_base_dups)>0:
		print("- dups verts found", len(uvmap_base_dups))
	if len(uvmap_base_loos)>0:
		print("- loose verts found", len(uvmap_base_loos))
	return uvmap_base, uvmap_inv_base, uvmap_base_dups.union(uvmap_base_loos)

def bm_getBase2NowMappingGlobal(cage_obj, uvId, version_name_base):
	wla_do.select_and_change_mode(cage_obj,'OBJECT')
	if version_name_base is None or len(version_name_base) == 0:
		print("- cage: no base version")
		return None,None,None,None,None,None
	# uv -> vertex index on base mesh
	cage_base_meshdata = wla.sys_objdata_by_name(cage_obj, version_name_base)
	cage_now_meshdata = cage_obj.data
	# pre-calcing BVH
	bm_cage_base = bmesh.new()
	bm_cage_base.from_mesh(cage_base_meshdata)
	bm_cage_base.verts.ensure_lookup_table()
	bm_cage_base.verts.index_update()
	base_cage2bvh = BVHTree.FromBMesh(bm_cage_base, epsilon = 0.0) # precise, or some exact verts WILL fail
	bm_cage_base.free()
	bm_cage_now = bmesh.new()
	bm_cage_now.from_mesh(cage_now_meshdata)
	bm_cage_now.verts.ensure_lookup_table()
	bm_cage_now.verts.index_update()
	bm_cageEdges = {} # cage_rVertsRemap
	for v1 in bm_cage_now.verts:
		vedg = []
		usedv = set()
		usedv.add(v1.index)
		for f in v1.link_faces:
			for fv in f.verts:
				if fv.index in usedv:
					continue
				usedv.add(fv.index)
				vedg.append( ( fv.index, (fv.co-v1.co).length ) )
		vedg.sort(key=lambda np: np[1], reverse=False)
		bm_cageEdges[v1.index] = [pr[0] for pr in vedg]
		#bm_cageEdges[v1.index] = (vedg[0][0], vedg[-1][0])
	bm_cage_now.free()
	uvmap_base, _, uvmap_base_dups = bm_getUvMappingAtMeshData(cage_base_meshdata, uvId)
	# if needRemoveTempMeshdata:
	# 	cage_base_meshdata.user_clear()
	# 	bpy.data.meshes.remove(cage_base_meshdata)
	if uvmap_base is None:
		print("- cage: no UV on base version:", uvId, version_name_base)
		return None,None,None,None,None,None
	# uv -> vertex index on now mesh
	uvmap_now, uvmap_inv_now, uvmap_now_dups = bm_getUvMappingAtMeshData(cage_now_meshdata, uvId)
	if uvmap_now is None:
		print("- cage: no UV:", uvId)
		return None,None,None,None,None,None
	if len(uvmap_base_dups)+len(uvmap_now_dups) > 0:
		print("- cage: UV duplications found:", uvId, len(uvmap_base_dups), len(uvmap_now_dups))
		return None,None,None,None,None,None
	cage_mw = cage_obj.matrix_world
	cage_mw_nrml = cage_obj.matrix_world.inverted().transposed().to_3x3()
	now_co_l, now_nrm_l = wla_bm.bm_getDeformedCos(cage_obj)
	base_co_g = {}
	base_nrm_g = {}
	now_co_g = {}
	now_nrm_g = {}
	vert_skips = 0
	for vIdx in now_co_l:
		if vIdx not in uvmap_inv_now:
			# its ok (cage-fixing convex, etc)
			vert_skips = vert_skips+1
			#print("- cage: UV mismatch: idx:", vIdx)
			#print("// now-vert not in base-verts. Loose verts in base?")
			#return None,None,None,None,None
			continue
		luv_kk = uvmap_inv_now[vIdx]
		if luv_kk not in uvmap_base:
			# its ok (cage-fixing convex, subdiv, cuts, etc)
			vert_skips = vert_skips+1
			continue
		vIdx_base = uvmap_base[luv_kk]
		v_base = cage_base_meshdata.vertices[vIdx_base]
		now_co_g[vIdx] = cage_mw @ now_co_l[vIdx]
		now_nrm_g[vIdx] = cage_mw_nrml @ now_nrm_l[vIdx]
		base_co_g[vIdx] = cage_mw @ v_base.co
		base_nrm_g[vIdx] = cage_mw_nrml @ v_base.normal
	if vert_skips > 0:
		print("- cage: skipped verts (no match in original)", vert_skips)
	print("- cage: mapping extracted", len(now_co_g))
	return base_co_g, base_nrm_g, now_co_g, now_nrm_g, base_cage2bvh, bm_cageEdges

def math_remapSurface(cage_base_co_g, cage_base_nrm_g, cage_now_co_g, cage_now_nrm_g, bind_base_co_g, cage_rVertsRemap):
	#print("- math_remapSurface", len(cage_base_co_g), len(cage_now_co_g), len(bind_base_co_g))
	# print("- math_remapSurface cbase",cage_base_co_g, cage_base_nrm_g)
	# print("- math_remapSurface cnow",cage_now_co_g, cage_now_nrm_g)
	# print("- math_remapSurface base",bind_base_co_g)
	kdtree_nearVerts = kBindNearVertsLim
	cage_base_co_g_tree = KDTree(len(cage_base_co_g))
	for cage_vIdx in cage_base_co_g:
		cage_base_co_g_tree.insert(cage_base_co_g[cage_vIdx], cage_vIdx)
	cage_base_co_g_tree.balance()
	bind_base_offsets = {}
	for pt_idx in bind_base_co_g:
		pt_co_g = bind_base_co_g[pt_idx]
		# pt_co_g_real = None
		# if (bind_rigidsRemap is not None) and (pt_idx in bind_rigidsRemap):
		# 	if bind_rigidsRemap[pt_idx] in bind_base_co_g: # can be lost with islands
		# 		pt_co_g_real = pt_co_g
		# 		pt_co_g = bind_base_co_g[ bind_rigidsRemap[pt_idx] ]
		nearpts = None
		if kdtree_nearVerts < 0:
			nearpts = cage_base_co_g_tree.find_range(pt_co_g, -1.0*kdtree_nearVerts)
		else:
			nearpts = cage_base_co_g_tree.find_n(pt_co_g, kdtree_nearVerts)
		if (nearpts is not None) and len(nearpts) >= 3:
			nearpts.sort(key=lambda np: np[2], reverse=False)
			cage_mw_zv_p1 = nearpts[0][1]
			cage_mw_zv_p2 = None
			cage_mw_zv_p3 = None
			cage_mw_zv1 = None
			cage_mw_zv2 = None
			# using cage_rVertsRemap for 2nd && 3rd vert
			if (cage_rVertsRemap is not None) and (cage_mw_zv_p1 in cage_rVertsRemap):
				verEdg = cage_rVertsRemap[cage_mw_zv_p1]
				if len(verEdg) >= 2:
					cage_mw_zv_v1_base_co = cage_base_co_g[cage_mw_zv_p1]
					for vvidx in verEdg:
						if (vvidx in cage_base_co_g) and (vvidx in cage_now_co_g):
							cage_mw_zv_p2 = vvidx # longest, from start
							break
					for vvidx in reversed(verEdg):
						if (vvidx in cage_base_co_g) and (vvidx in cage_now_co_g):
							cage_mw_zv_p3 = vvidx # shortest, from end
							break
					if cage_mw_zv_p2 is not None:
						cage_mw_zv_v2_base_co = cage_base_co_g[cage_mw_zv_p2]
						cage_mw_zv1 = (cage_mw_zv_v2_base_co - cage_mw_zv_v1_base_co).normalized()
					if cage_mw_zv_p3 is not None:
						cage_mw_zv_v3_base_co = cage_base_co_g[cage_mw_zv_p3]
						cage_mw_zv2 = (cage_mw_zv_v3_base_co - cage_mw_zv_v1_base_co).normalized()
					if (cage_mw_zv_p2 is None) or (cage_mw_zv_p3 is None) or (cage_mw_zv_p2 == cage_mw_zv_p3) or abs(cage_mw_zv2.dot(cage_mw_zv1)) >= kBindAxisDotDropFac:
						# not good
						cage_mw_zv_p2 = None
						cage_mw_zv_p3 = None
			if (cage_mw_zv_p2 is None) or (cage_mw_zv_p3 is None):
				# autodetection from closest
				cage_mw_zv_p2 = nearpts[1][1]
				cage_mw_zv_v2_base_co = cage_base_co_g[cage_mw_zv_p2]
				cage_mw_zv_v1_base_co = cage_base_co_g[cage_mw_zv_p1]
				cage_mw_zv1 = (cage_mw_zv_v2_base_co - cage_mw_zv_v1_base_co).normalized()
				# last pt MUST be non-collinear...
				for pp_i in range(2, len(nearpts)):
					cage_mw_zv_p3 = nearpts[pp_i][1]
					cage_mw_zv_v3_base_co = cage_base_co_g[cage_mw_zv_p3]
					cage_mw_zv2 = (cage_mw_zv_v3_base_co - cage_mw_zv_v1_base_co).normalized()
					if abs(cage_mw_zv2.dot(cage_mw_zv1)) < kBindAxisDotDropFac:
						break
			if cage_mw_zv_p2 is None or cage_mw_zv_p3 is None:
				print("- can`t bind to vert (no axis found)", cage_mw_zv_p1, len(nearpts))
				continue
			bind_item = {
				"refverts": [pt_idx, cage_mw_zv_p1, cage_mw_zv_p2, cage_mw_zv_p3],
				"refmatr": []
			}
			dist_min = nearpts[0][2]
			dist_max = nearpts[-1][2]
			dist_min_ll = 999
			dist_max_ll = 0
			# problem: axis for local recalcs are calcualted to the 3-most closest point (not per EVERY point)
			# also no strict collinearity -> change in aspect may "blow" coords
			# Good enough but may give spikes for faces moving contrary to closest-verts movement
			for nearpt in nearpts:
				gp_idx1 = nearpt[1]
				gp1 = nearpt[0]
				gp1_n1 = cage_base_nrm_g[gp_idx1]
				gp1_n2 = cage_mw_zv1
				gp1_n3 = cage_mw_zv2
				gp_sm1 = wla.math_matrix4axis(None, gp1_n1, gp1_n2, gp1_n3, 0)
				if (gp_sm1 is None) or abs(gp_sm1.determinant()) < 0.00001:
					print("- can`t bind to vert (math_matrix4axis=null/zero determ), bad axises?", gp_idx1, gp1_n1, gp1_n2, gp1_n3)
					continue
				pt_co_l = (pt_co_g - gp1) * kBindScaleFac
				pt_co_cm = gp_sm1.inverted() @ pt_co_l
				pt_co_cm2_rigids_pair = None
				# if pt_co_g_real is not None:
				# 	pt_co_l2 = (pt_co_g_real - pt_co_g) * kBindScaleFac
				# 	pt_co_cm2_len = pt_co_l2.length
				# 	pt_co_cm2 = (gp_sm1.inverted().transposed().to_3x3().inverted() @ pt_co_l2).normalized()
				# 	pt_co_cm2_rigids_pair = (pt_co_cm2, pt_co_cm2_len)
				dist_gg = (pt_co_g - gp1).length
				pt_co_cm_wei = (1.0 - (dist_gg-dist_min)/(dist_max-dist_min))
				if pt_co_cm_wei < 0.001:# clamping non-improtants
					#print("- distance weights are off", gp_idx1, pt_co_cm_wei, dist_gg, dist_min, dist_max)
					continue
				pt_axis_set = [gp_idx1, pt_co_cm_wei, pt_co_cm, pt_co_cm2_rigids_pair ]
				dist_ll = pt_co_cm.length
				dist_min_ll = min(dist_min_ll,dist_ll)
				dist_max_ll = max(dist_max_ll,dist_ll)
				# if pt_idx == 230:
				# 	print("- DBG: bind_item pt_axis_pre", pt_idx, (gp_idx1, cage_mw_zv_p1, cage_mw_zv_p2, cage_mw_zv_p3), gp1_n1, gp1_n2, gp1_n3, '->', pt_co_cm, pt_co_cm_wei)
				bind_item["refmatr"].append(pt_axis_set)
			# recalcing weights according distance in LOCAL (verts-axis) space
			# 3D dist only -> spikes in bad/hard/heavy-mixed zones
			for pt_axis_set in bind_item["refmatr"]:
				pt_co_cm = pt_axis_set[2]
				dist_ll = pt_co_cm.length
				pt_co_cm_wei = (1.0 - (dist_ll-dist_min_ll)/(dist_max_ll-dist_min_ll))
				# v1: Remap with clamping
				#pt_co_cm_wei = wla.math_remapRanged(pt_co_cm_wei,kBindWeightDropFac,1.0,0.0,1.0)
				pt_co_cm_wei = min(1.0, max(0.0,pt_co_cm_wei))
				# v2: BOTH weights matter (114, 155 - ok, including sews)
				pt_co_cm_wei_fin = pt_co_cm_wei*pt_axis_set[1]
				pt_co_cm_wei_fin = pow(pt_co_cm_wei_fin, kBindWeightDstPow)
				pt_axis_set[1] = pt_co_cm_wei_fin
			bind_base_offsets[pt_idx] = bind_item
			#print("- bind_item",pt_idx,bind_item)
	bind_now_co_g_final = {}
	bind_now_ttnrm_g_final = {}
	#print("- bind_base_offsets", bind_base_offsets)
	for pt_idx in bind_base_co_g:
		if pt_idx not in bind_base_offsets:
			print("- ??? pt_idx not in bind_base_offsets")
			continue
		bind_inf = bind_base_offsets[pt_idx]
		spl_pn = bind_inf["refverts"]
		cage_mw_zv_p1 = spl_pn[1]
		cage_mw_zv_p2 = spl_pn[2]
		cage_mw_zv_p3 = spl_pn[3]
		if (cage_mw_zv_p1 not in cage_now_co_g) or (cage_mw_zv_p2 not in cage_now_co_g) or (cage_mw_zv_p3 not in cage_now_co_g):
			print("- unknown vert found (cageMw)", cage_mw_zv_p1, cage_mw_zv_p2, cage_mw_zv_p3)
			continue
		cage_mw_zv_v1_now_co = cage_now_co_g[cage_mw_zv_p1]
		cage_mw_zv_v2_now_co = cage_now_co_g[cage_mw_zv_p2]
		cage_mw_zv_v3_now_co = cage_now_co_g[cage_mw_zv_p3]
		cage_mw_zv1 = ( cage_mw_zv_v2_now_co - cage_mw_zv_v1_now_co ).normalized()
		cage_mw_zv2 = ( cage_mw_zv_v3_now_co - cage_mw_zv_v1_now_co ).normalized()
		bind_co_g_ver_xyz = []
		bind_co_g_ver_nrm = []
		bind_co_g_ver_wei = []
		bind_co_g_ver_wei_sum = 0
		for bind_inf_v in bind_inf["refmatr"]:
			odx1_idx = bind_inf_v[0]
			if odx1_idx not in cage_now_co_g:
				print("- unknown vert found (odx)", odx1_idx, bind_inf_v)
				continue
			gp_idx1 = odx1_idx
			gp1 = cage_now_co_g[gp_idx1]
			gp1_n1 = cage_now_nrm_g[gp_idx1]
			gp1_n2 = cage_mw_zv1
			gp1_n3 = cage_mw_zv2
			gp_sm1 = wla.math_matrix4axis(None, gp1_n1, gp1_n2, gp1_n3, 0)
			if gp_sm1 is None:
				print("- target axis problem (odx)", odx1_idx, bind_inf_v, gp1_n1, gp1_n2, gp1_n3)
				continue
			odx1_wei = bind_inf_v[1]
			if odx1_wei < 0.001:
				continue
			pt_co_cm = Vector(bind_inf_v[2])
			pt_co_now_l = (gp_sm1 @ pt_co_cm)
			pt_co_now_g = gp1 + pt_co_now_l / kBindScaleFac
			# pt_co_cm2_rigids_pair = bind_inf_v[3]
			# if pt_co_cm2_rigids_pair is not None:
			# 	pt_co_cm2 = Vector(pt_co_cm2_rigids_pair[0])
			# 	pt_co_cm2_len = pt_co_cm2_rigids_pair[1]
			# 	pt_co_now2_l = (gp_sm1.inverted().transposed().to_3x3() @ pt_co_cm2)
			# 	pt_co_now_g = pt_co_now_g + pt_co_now2_l.normalized() * (pt_co_cm2_len / kBindScaleFac) # pt_co_g_real
			# 	# if odx1_wei>bind_co_g_ver_wei_sum:
			# 	# 	bind_co_g_ver_wei_sum = odx1_wei
			# 	# 	bind_co_g_ver_xyz = [ (pt_co_now_g[0], pt_co_now_g[1], pt_co_now_g[2], gp_idx1) ]
			# 	# 	bind_co_g_ver_nrm = [ (gp1_n1[0], gp1_n1[1], gp1_n1[2], gp_idx1) ]
			# 	# 	bind_co_g_ver_wei = [ odx1_wei ]
			#print("- unbind pt_axis_post", pt_idx, (gp_idx1, cage_mw_zv_p1, cage_mw_zv_p2, cage_mw_zv_p3), gp1_n1, gp1_n2, gp1_n3, '@', pt_co_cm, '->', pt_co_now_l)
			bind_co_g_ver_wei_sum = bind_co_g_ver_wei_sum + odx1_wei
			bind_co_g_ver_xyz.append( (pt_co_now_g[0], pt_co_now_g[1], pt_co_now_g[2], gp_idx1) )
			bind_co_g_ver_nrm.append( (gp1_n1[0], gp1_n1[1], gp1_n1[2], gp_idx1) )
			bind_co_g_ver_wei.append( odx1_wei )
		# if pt_idx == 230:
		# 	print("- DBG: out", gp1, gp_idx1, pt_co_cm)
		# 	print("- DBG: out", bind_co_g_ver_xyz, bind_co_g_ver_wei)
		if len(bind_co_g_ver_xyz)>0 and bind_co_g_ver_wei_sum > 0.0:
			x = np.average([co[0] for co in bind_co_g_ver_xyz],weights=bind_co_g_ver_wei)
			y = np.average([co[1] for co in bind_co_g_ver_xyz],weights=bind_co_g_ver_wei)
			z = np.average([co[2] for co in bind_co_g_ver_xyz],weights=bind_co_g_ver_wei)
			bind_now_co_g_final[pt_idx] = Vector((x,y,z))
			x = np.average([co[0] for co in bind_co_g_ver_nrm],weights=bind_co_g_ver_wei)
			y = np.average([co[1] for co in bind_co_g_ver_nrm],weights=bind_co_g_ver_wei)
			z = np.average([co[2] for co in bind_co_g_ver_nrm],weights=bind_co_g_ver_wei)
			bind_now_ttnrm_g_final[pt_idx] = Vector((x,y,z)).normalized()
			#print("- unbind avg", pt_idx, bind_co_g_ver_xyz, bind_co_g_ver_wei)
	return bind_now_co_g_final, bind_now_ttnrm_g_final

def gm_generateUVGrid(bm, selvertsIdx, extras):
	if (selvertsIdx is None) or len(selvertsIdx) < 3:
		return None, None, None
	deform_verts = None
	deform_verts_nrm = None
	if extras is not None and "verts_co" in extras:
		deform_verts = extras["verts_co"]
	if extras is not None and "verts_nrm" in extras:
		deform_verts_nrm = extras["verts_nrm"]
	extend_steps = 5
	if extras is not None and "steps" in extras:
		extend_steps = extras["steps"]
	post_subd = 0
	if extras is not None and "subd" in extras:
		post_subd = extras["subd"]
	selvertsIdx = wla_bm.bm_sortVertsByConnection(bm, selvertsIdx, True, False)
	zero_vIdx = selvertsIdx[int(len(selvertsIdx)/2)]
	selvertsIdx_curves = wla_bm.bm_splitVertsByConnection(bm, selvertsIdx, True, None, None)
	selvertsIdx_curve = selvertsIdx_curves[0]
	vertDistMapU, vertStepMapU, vertLeftListU, vertOrigMapU = wla_bm.bm_geodesicDistmap_v05(bm, [selvertsIdx_curve], extend_steps, None, False, True)
	vertDistMapV, vertStepMapV, vertLeftListV = wla_bm.bm_geodesicDistmapAlong_v01(bm, [zero_vIdx], [selvertsIdx], vertOrigMapU, True)
	tempUV = {}
	tmp_idx = 0
	deform_verts = None
	deform_verts_nrm = None
	for vIdx in vertDistMapU:
		if (vIdx not in vertOrigMapU):
			continue
		# ignoring verts reffered to first and last - no way to set proper XY on them
		if (vertOrigMapU[vIdx] == selvertsIdx_curve[0]) or (vertOrigMapU[vIdx] == selvertsIdx_curve[-1]):
			isNonGriddable = True
			if (vIdx == selvertsIdx_curve[0] or vIdx == selvertsIdx_curve[-1]):
				isNonGriddable = False
			else:
				v = bm.verts[vIdx]
				for e in v.link_edges:
					vOtherIdx = e.other_vert(v).index
					if vOtherIdx in vertOrigMapU:
						if (vertOrigMapU[vOtherIdx] != selvertsIdx_curve[0]) and (vertOrigMapU[vOtherIdx] != selvertsIdx_curve[-1]):
							isNonGriddable = False
							break
			if isNonGriddable:
				continue
		vB = bm.verts[vIdx]
		tmp_idx = tmp_idx+1
		uv_x = 0
		if vIdx in vertStepMapU:
			uv_x = vertStepMapU[vIdx]-1
		uv_y = 0
		if vIdx in vertStepMapV:
			uv_y = vertStepMapV[vIdx]
		# targetScale
		dstU = vertDistMapU[vIdx]
		if vIdx in vertLeftListU:
			dstU = -1 * dstU
			uv_x = -1 * uv_x
		dstV = vertDistMapV[vIdx]
		if vIdx in vertLeftListV:
			dstV = -1 * dstV
			uv_y = -1 * uv_y
		#tempUV[tmp_idx] = (dstV/targetScale[0] - self.opt_postOffset[0], dstU/targetScale[1] - self.opt_postOffset[1])
		vb_co = None
		if deform_verts is not None:
			vb_co = deform_verts[vIdx]
		else:
			vb_co = vB.co
		vb_nrm = None
		if deform_verts_nrm is not None:
			vb_nrm = deform_verts_nrm[vIdx]
		else:
			vb_nrm = vB.normal
		tempUV[tmp_idx] = [Vector(vb_co), Vector(vb_nrm), (dstV, dstU), (uv_x, uv_y), vIdx]
		#print("- pt", vIdx, uv_x, uv_y, "->", tmp_idx)
	#print("- vertStepMapU", vertStepMapU, "zero_vIdx", zero_vIdx, (uv_x_min, uv_x_max), (uv_y_min, uv_y_max))
	#print("- vertStepMapV", vertStepMapV, vertLeftListV)
	def getGridFromTempUV(uvmap):
		uvgrid2d = []
		uv_none = -999
		uv_x_min = 999
		uv_x_max = -999
		uv_y_min = 999
		uv_y_max = -999
		for vtIdx in uvmap:
			pt_xy = uvmap[vtIdx][3]
			uv_x_min = min(uv_x_min, pt_xy[0])
			uv_y_min = min(uv_y_min, pt_xy[1])
			uv_x_max = max(uv_x_max, pt_xy[0])
			uv_y_max = max(uv_y_max, pt_xy[1])
		uvmap_keys = list(uvmap.keys())
		for vtIdx in uvmap_keys:
			pt_xy = uvmap[vtIdx][3]
			pt_x = pt_xy[0]-uv_x_min
			pt_y = pt_xy[1]-uv_y_min
			while len(uvgrid2d) <= pt_y:
				uvgrid2d.append([])
			grid_2d_line = uvgrid2d[pt_y]
			while len(grid_2d_line) <= pt_x:
				grid_2d_line.append(uv_none)
			if grid_2d_line[pt_x] != uv_none:
				print("- gm_generateUVGrid: double-match, ignoring", (pt_x, pt_y), (grid_2d_line[pt_x], vtIdx))
				del uvmap[vtIdx]
				continue
			grid_2d_line[pt_x] = vtIdx
			# saving coordinates with [0-max] ranges
			uvmap[vtIdx][3] = (pt_x, pt_y)
		return uvgrid2d
	grid_2d = getGridFromTempUV(tempUV)
	#print("- grid_2d", grid_2d, tempUV)
	while post_subd > 0:
		post_subd = post_subd-1
		# making copy
		tmp_idx2 = 0
		tempUV2 = {}
		xy_offs = [ (1, 0), (1, 1), (0, 1) ]
		for tmp_idx in tempUV:
			tmp_idx2 = tmp_idx2+1
			pt_co = tempUV[tmp_idx][0]
			pt_nrm = tempUV[tmp_idx][1]
			pt_dst = tempUV[tmp_idx][2]
			pt_xy = tempUV[tmp_idx][3]
			pt_vIdx = tempUV[tmp_idx][4]
			tempUV2[tmp_idx2] = [ pt_co, pt_nrm, pt_dst, [pt_xy[0]*2, pt_xy[1]*2], pt_vIdx]
			for xy_off in xy_offs:
				pt_xy_sub = (pt_xy[0]+xy_off[0], pt_xy[1]+xy_off[1])
				if pt_xy_sub[1] < len(grid_2d) and pt_xy_sub[0] < len(grid_2d[pt_xy_sub[1]]):
					tmp_idx_sub = grid_2d[pt_xy_sub[1]][pt_xy_sub[0]]
					if tmp_idx_sub in tempUV:
						tmp_idx2 = tmp_idx2+1
						pt_co_sub = tempUV[tmp_idx_sub][0]
						pt_nrm_sub = tempUV[tmp_idx_sub][1]
						pt_dst_sub = tempUV[tmp_idx_sub][2]
						pt_co_sub = (pt_co+pt_co_sub)*0.5
						pt_nrm_sub = (pt_nrm+pt_nrm_sub).normalized()
						pt_dst_sub = ( (pt_dst[0]+pt_dst_sub[0])*0.5, (pt_dst[1]+pt_dst_sub[1])*0.5 )
						tempUV2[tmp_idx2] = [ pt_co_sub, pt_nrm_sub, pt_dst_sub, [pt_xy[0]*2+xy_off[0], pt_xy[1]*2+xy_off[1]], pt_vIdx]
		tempUV = tempUV2
		grid_2d = getGridFromTempUV(tempUV)
	return tempUV, grid_2d, zero_vIdx

def obj_parseIslands(obj, vcName, cache):
	cache_key = "pi_"+obj.name+vcName
	if cache_key in cache:
		return cache[cache_key]
	if (obj is None) or (obj.type != 'MESH'):
		cache[cache_key] = ({}, [])
		return cache[cache_key]
	active_mesh = obj.data
	vc_layer = active_mesh.vertex_colors.get(vcName)
	if vc_layer is None:
		cache[cache_key] = ({}, [])
		return cache[cache_key]
	islMap = {}
	islMapFull = {}
	islList = []
	for poly in active_mesh.polygons:
		for idx, lIdx in enumerate(poly.loop_indices):
			vIdx = poly.vertices[idx]
			vCol = vc_layer.data[lIdx].color
			vCol = Vector((vCol[0], vCol[1], vCol[2]))
			vColHash = str(int(vCol[0]*100))+"_"+str(int(vCol[1]*100))+"_"+str(int(vCol[2]*100))
			if vColHash not in islList:
				islList.append(vColHash)
			if vIdx not in islMap:
				islMap[vIdx] = vColHash
				islMapFull[vIdx] = vCol
			else:
				if islMapFull[vIdx].length < vCol.length:
					# replacing with brighter color
					islMap[vIdx] = vColHash
					islMapFull[vIdx] = vCol
	cache[cache_key] = (islMap, islList)
	return cache[cache_key]