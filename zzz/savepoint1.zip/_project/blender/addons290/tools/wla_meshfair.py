import math
import sys
import collections
import importlib
import glob
import logging
import os
import subprocess
from typing import Dict, List, Optional, Set, Tuple

import bmesh
import bpy.types
import mathutils
from mathutils import Vector
from mathutils.bvhtree import BVHTree
from mathutils.kdtree import KDTree
from bpy.props import *

from . import wla
from . import wla_do
from .. import config

# stripped from https://github.com/fedackb/mesh-fairing to work on 2.79b - 2.91
class BoundaryAlignedRemesher:
	def __init__(self, obj_bm, vIdxLimit, vIdxFreeze, bvh_hull):
		self.bm = obj_bm
		self.bvh = bvh_hull
		if self.bvh is None:
			self.bvh = BVHTree.FromBMesh(self.bm)
		self.limit2verts = vIdxLimit
		self.freeze4verts = vIdxFreeze
		# Boundary_data is a list of directions and locations of boundaries.
		# This data will serve as guidance for the alignment
		self.boundary_data = []
		self.boundary_verts = []
		# Fill the data using boundary edges as source of directional data.
		for edge in self.bm.edges:
			if (edge.verts[0].index not in self.limit2verts) or (edge.verts[1].index not in self.limit2verts):
				continue
			isBnd = False
			if vIdxFreeze is not None:
				#print("- test", edge.verts[0].index, edge.verts[1].index)
				if (edge.verts[0].index in vIdxFreeze) and (edge.verts[1].index in vIdxFreeze):
					isBnd = True
			if edge.is_boundary:
				isBnd = True
			for f in edge.link_faces:
				for fv in f.verts:
					if (fv.index not in self.limit2verts):
						isBnd = True
						break
			if isBnd:
				if edge.verts[0].index not in self.boundary_verts:
					self.boundary_verts.append(edge.verts[0].index)
				if edge.verts[1].index not in self.boundary_verts:
					self.boundary_verts.append(edge.verts[1].index)
				vec = (edge.verts[0].co - edge.verts[1].co).normalized()
				center = (edge.verts[0].co + edge.verts[1].co) / 2
				self.boundary_data.append((center, vec))
		print("- BoundaryRemesh", len(self.limit2verts), len(self.boundary_verts))
		# Create a Kd Tree to easily locate the nearest boundary point
		self.boundary_kd_tree = KDTree(len(self.boundary_data))
		for index, (center, vec) in enumerate(self.boundary_data):
			self.boundary_kd_tree.insert(center, index)
		self.boundary_kd_tree.balance()
	def nearest_boundary_vector(self, location):
		""" Gets the nearest boundary direction """
		location, index, dist = self.boundary_kd_tree.find(location)
		if index is None or index not in self.boundary_data:
			return Vector((0,0,1))
		location, vec = self.boundary_data[index]
		return vec
	def align_verts(self, rule=(-1, -2, -3, -4)):
		# Align verts to the nearest boundary by averaging neigbor vert locations selected
		# by a specific rule,
		# Rules work by sorting edges by angle relative to the boundary.
		# Eg1. (0, 1) stands for averagiing the biggest angle and the 2nd biggest angle edges.
		# Eg2. (-1, -2, -3, -4), averages the four smallest angle edges
		for vert in self.bm.verts:
			if (vert.index not in self.limit2verts):
				continue
			if (vert.index in self.freeze4verts):
				continue
			if vert.index not in self.boundary_verts and len(vert.link_edges) > 0:
				vec = self.nearest_boundary_vector(vert.co)
				neighbor_locations = [edge.other_vert(vert).co for edge in vert.link_edges]
				best_locations = sorted(neighbor_locations, 
										key = lambda n_loc: abs((n_loc - vert.co).normalized().dot(vec)))
				co = vert.co.copy()
				le = len(vert.link_edges)
				for i in rule:
					co += best_locations[i % le]
				co /= len(rule) + 1
				co -= vert.co
				co -= co.dot(vert.normal) * vert.normal
				vert.co += co
	def reproject(self, influence):
		""" Recovers original shape """
		for vert in self.bm.verts:
			if (vert.index not in self.limit2verts):
				continue
			if (vert.index in self.freeze4verts):
				continue
			location, normal, index, dist = self.bvh.find_nearest(vert.co)
			if location:
				vert.co = vert.co.lerp(location, influence)
		self.bm.normal_update()
	def remesh(self, iterations=30, quads=True):
		""" Coordenates remeshing """
		if len(self.boundary_data) == 0:
			print("- skipping remesh, no boundary data found")
			return
		if quads:
			rule = (-1,-2, 0, 1)
		else:
			rule = (0, 1, 2, 3)
		for _ in range(iterations):
			self.align_verts(rule=rule)
			self.reproject(0.5)
		# if quads:
		# 	bmesh.ops.join_triangles(self.bm, faces=self.bm.faces,
		# 								angle_face_threshold=3.14,
		# 								angle_shape_threshold=3.14)
		return self.bm

## =================================================================
class Solver():

	def solve(self, A: Dict[Tuple[int], float], b: List[List[float]]):
		# Solves the Ax=b linear system of equations
		# Parameters:
		# 	A (Dict[Tuple[int], float]): Coefficient matrix A
		# 	b (List<List<float>>): Right hand side of the linear system
		# Returns:
		# 	numpy.ndarray: Variables matrix (x); None if unsuccessful
		# Raises: NotImplementedError
		raise NotImplementedError


class NumPySolver(Solver):
	# Linear system solver implemented with NumPy library
	# Attributes:
	# 	numpy (importlib.type.ModuleType): NumPy library
	def __init__(self, *args, **kwargs):
		# Initializes this linear system solver
		super().__init__(*args, **kwargs)
		self.numpy = importlib.import_module('numpy')

	def solve(self, A: Dict[Tuple[int], float], b: List[List[float]]):
		# Solves the Ax=b linear system of equations using NumPy library
		# Parameters:
		# 	A (Dict[Tuple[int], float]): Coefficient matrix A
		# 	b (List[List[float]]): Right hand side of the linear system
		# Returns:
		# 	numpy.ndarray: Variables matrix (x); None if unsuccessful
		x = None
		n = len(b)
		# Attempt to solve the linear system with NumPy library.
		try:
			A_numpy = self.numpy.zeros((n, n), dtype = 'd')
			b = self.numpy.asarray(b, dtype = 'd')
			for key, val in A.items():
				A_numpy[key] = val
			x = self.numpy.linalg.solve(A_numpy, b)
		except Exception as e:
			print(e)

		return x

class SciPySolver(Solver):
    # Linear system solver implemented with SciPy library
    # Attributes:
    #     scipy (importlib.type.ModuleType): SciPy library
    def __init__(self, *args, **kwargs):
        # Initializes this linear system solver
        super().__init__(*args, **kwargs)
        self.scipy = importlib.import_module('scipy')
        importlib.import_module('scipy.sparse.linalg')

    def solve(self, A: Dict[Tuple[int], float], b: List[List[float]]):
        # Solves the Ax=b linear system of equations using SciPy library
        # Parameters:
        #     A (Dict[Tuple[int], float]): Coefficient matrix A
        #     b (List[List[float]]): Right hand side of the linear system
        # Returns:
        #     numpy.ndarray: Variables matrix (x); None if unsuccessful
        x = None
        n = len(b)

        # Attempt to solve the linear system with SciPy libary.
        try:
            A_scipy = self.scipy.sparse.dok_matrix((n, n), dtype = 'd')
            A_scipy._update(A)
            A_scipy = A_scipy.tocsc()
            b = self.scipy.array(b, dtype = 'd')
            factor = self.scipy.sparse.linalg.splu(
                A_scipy, diag_pivot_thresh = 0.00001)
            x = factor.solve(b)
        except Exception as e:
            logging.warn(e)

        return x

solver = None
class Cache(dict):
	# Data structure for caching values, essentially functioning as a dictionary
	# where values can be calculated for keys not present in the collection
	# Attributes:
	# 	_calc (typing.Callable): Caching function to calculate values

	def __init__(self, calc, calc_param, *args, **kwargs):
		# Initializes this cache
		# Parameters:
		# 	calc (callable): Caching function to calculate values
		super().__init__(*args, **kwargs)
		if calc is None:
			raise TypeError('A caching function is required')
		else:
			self._calc = calc
			self._calc_param = calc_param

	def __getitem__(self, key):
		# Gets cached value or calculates a value if not already cached
		# Returns:
		# 	Any: Cached value
		if key not in self:
			self[key] = self._calc(key, self._calc_param)
		return super().__getitem__(key)

	def get(self, key):
		# Gets cached value or calculates a value if not already cached
		# Returns:
		# 	Any: Cached value
		return self[key]

############################

def calc_circumcenter(a: mathutils.Vector,
					  b: mathutils.Vector,
					  c: mathutils.Vector):
	# Calculates the 3-dimensional circumcenter of three points https://gamedev.stackexchange.com/a/60631
	# Parameters
	# 	a, b, c (mathutils.Vector) Points of a triangle
	# Returns:
	# 	mathutils.Vector: Circumcenter point
	ab = b - a
	ac = c - a
	ab_cross_ac = ab.cross(ac)
	if ab_cross_ac.length_squared > 0:
		d = ac.length_squared * ab_cross_ac.cross(ab)
		d += ab.length_squared * ac.cross(ab_cross_ac)
		d /= 2 * ab_cross_ac.length_squared
		return a + d
	else:
		return a

def calc_uniform_vertex_weight(v: bmesh.types.BMVert, stop_vertsIdx):
	# Calculates uniform weight of the given vertex
	# Parameters:
	# 	v (bmesh.types.BMVert): Vertex for which to calculate the weight
	# Returns:
	# 	float: Uniform vertex weight
	n = 0 #len(v.link_edges)
	for l in v.link_loops:
		if (l.edge.is_boundary or (l.edge.verts[0].index in stop_vertsIdx) or (l.edge.verts[1].index in stop_vertsIdx)):
			continue
		n = n+1
	return (1 / n) if (n != 0) else sys.maxsize

def calc_barycentric_vertex_weight(v: bmesh.types.BMVert, stop_vertsIdx):
	# Calculates inverse Barycentric area weight of the given vertex
	# Parameters:
	# 	v (bmesh.types.BMVert): Vertex
	# Returns:
	# 	float: Inverse Barycentric area vertex weight

	area = 0
	a = v.co
	for l in v.link_loops:
		if (l.edge.is_boundary or (l.edge.verts[0].index in stop_vertsIdx) or (l.edge.verts[1].index in stop_vertsIdx)):
			continue
		b = l.link_loop_next.vert.co
		c = l.link_loop_prev.vert.co
		area += mathutils.geometry.area_tri(a, b, c) / 3
	return 1 / area if area != 0 else 1e12


def calc_voronoi_vertex_weight(v: bmesh.types.BMVert, stop_vertsIdx):
	# Calculates inverse Voronoi area weight of the given vertex
	# Parameters:
	# 	v (bmesh.types.BMVert): Vertex
	# Returns:
	# 	float: Inverse Voronoi area vertex weight

	area = 0
	a = v.co
	acute_threshold = math.pi / 2
	for l in v.link_loops:
		if (l.edge.is_boundary or (l.edge.verts[0].index in stop_vertsIdx) or (l.edge.verts[1].index in stop_vertsIdx)):
			continue
		b = l.link_loop_next.vert.co
		c = l.link_loop_prev.vert.co
		if l.calc_angle() < acute_threshold:
			d = calc_circumcenter(a, b, c)
		else:
			d = (b + c) / 2
		area += mathutils.geometry.area_tri(a, (a + b) / 2, d)
		area += mathutils.geometry.area_tri(a, d, (a + c) / 2)
	return 1 / area if area != 0 else 1e12


def calc_cotangent_loop_weight(l: bmesh.types.BMLoop, stop_vertsIdx):
	# Calculates cotangent weight of the given loop
	# Parameters:
	# 	l (bmesh.types.BMLoop): Loop
	# Returns:
	# 	float: Cotangent loop weight
	weight = 0
	co_a = l.vert.co
	co_b = l.link_loop_next.vert.co
	coords = [l.link_loop_prev.vert.co]
	if not (l.edge.is_boundary or (l.edge.verts[0].index in stop_vertsIdx) or (l.edge.verts[1].index in stop_vertsIdx)):
		coords.append(l.link_loop_radial_next.link_loop_next.link_loop_next.vert.co)
	for co_c in coords:
		try:
			angle = (co_a - co_c).angle(co_b - co_c)
			weight += 1 / math.tan(angle)
		except (ValueError, ZeroDivisionError):
			weight += 1e-4
	weight /= 2
	return weight

def calc_unif_loop_weight(l: bmesh.types.BMLoop, stop_vertsIdx):
	return 1

def calc_mvc_loop_weight(l: bmesh.types.BMLoop, stop_vertsIdx):
	# Calculates mean value coordinate weight of the given loop
	# Parameters:
	# 	l (bmesh.types.BMLoop): Loop
	# Returns:
	# 	float: Mean value coordinate loop weight
	weight = 0
	length = l.edge.calc_length()
	if length > 0:
		weight += math.tan(l.calc_angle() / 2)
		if not (l.edge.is_boundary or (l.edge.verts[0].index in stop_vertsIdx) or (l.edge.verts[1].index in stop_vertsIdx)):
			weight += math.tan(l.link_loop_radial_next.link_loop_next.calc_angle() / 2)
		weight /= length
	return weight

def fair(bm, verts: List[bmesh.types.BMVert],
		 order: int,
		 vert_weights: Dict[bmesh.types.BMVert, float],
		 loop_weights: Dict[bmesh.types.BMLoop, float],
		 freeze_vertsIdx, status = None):
	# Displaces given vertices to form a smooth-as-possible mesh patch
	# Parameters:
	# 	verts (List[bmesh.types.BMVert]):				Vertices to act upon
	# 	order (int):									Laplace-Beltrami
	# 													operator order
	# 	vert_weights (Dict[bmesh.types.BMVert, float]): Vertex weights
	# 	loop_weights (Dict[bmesh.types.BMLoop, float]): Loop weights
	# 	status (Optional[types.Property]):				Status message
	# Returns:
	# 	bool: True if fairing succeeded; False otherwise
	# Setup the linear system.
	interior_verts = []
	for vertex in verts:
		if vertex.is_wire:
			continue
		if vertex.index in freeze_vertsIdx:
			continue
		interior_verts.append(vertex)
	print("- interior verts", len(interior_verts))
	# interiors preps
	vert_col_map = {v: col for col, v in enumerate(interior_verts)}
	A = dict()
	b = [[0 for i in range(3)] for j in range(len(vert_col_map))]
	for v, col in vert_col_map.items():
		#print("- Setting up linear system ({:>3}%)".format(int((col + 1) / len(vert_col_map) * 100)))
		setup_fairing(v, col, A, b, 1, order, vert_col_map, vert_weights, loop_weights, freeze_vertsIdx)

	# Solve the linear system.
	print("- Solving linear system")
	x = solver.solve(A, b)
	print("- Solved")
	# Apply results.
	if x is not None:
		print("- Applying results")
		for v, col in vert_col_map.items():
			v.co = x[col]
		return True
	return False

def setup_fairing(v: bmesh.types.BMVert,
				  i: int,
				  A: Dict[Tuple[int], float],
				  b: List[List[float]],
				  multiplier: float,
				  depth: int,
				  vert_col_map: Dict[bmesh.types.BMVert, int],
				  vert_weights: Dict[bmesh.types.BMVert, float],
				  loop_weights: Dict[bmesh.types.BMLoop, float],
				  freeze_vertsIdx):
	# Recursive helper function to build a linear system that represents the
	# discretized fairing problem
	# Implementation details are based on CGAL source code available on GitHub:
	# 	cgal/Polygon_mesh_processing/include/CGAL/Polygon_mesh_processing/internal/fair_impl.h
	# Parameters:
	# 	v (bmesh.types.BMVert):							Vertex
	# 	i (int):										Row index of A
	# 	A (Dict[Tuple[int], float]):					Coefficient matrix A
	# 	b (List[List[float]]):							Right hand side of the
	# 													linear system
	# 	multiplier (float):								Recursive multiplier
	# 	depth (int):									Recursion depth
	# 	vert_col_map (Dict[bmesh.types.BMVert, int]):	Maps each vertex to a
	# 													column index j of A
	# 	vert_weights (Dict[bmesh.types.BMVert, float]): Vertex weights
	# 	loop_weights (Dict[bmesh.types.BMLoop, float]): Loop weights

	if depth == 0:
		# Set the coefficient of an internal vertex.
		if v in vert_col_map:
			j = vert_col_map[v]
			if (i, j) not in A:
				A[i, j] = 0
			A[i, j] -= multiplier
		# Set the value of a boundary vertex.
		else:
			b[i][0] += multiplier * v.co.x
			b[i][1] += multiplier * v.co.y
			b[i][2] += multiplier * v.co.z
	else:
		w_ij_sum = 0
		w_i = vert_weights[v]
		# Recursively compute adjacent vertices.
		for l in v.link_loops:
			w_ij = loop_weights[l]
			w_ij_sum += w_ij
			other = l.link_loop_next.vert
			setup_fairing(other, i, A, b, w_i * w_ij * multiplier, depth - 1, vert_col_map, vert_weights, loop_weights, freeze_vertsIdx)
		# Recursively compute this vertex.
		setup_fairing(v, i, A, b, -1 * w_i * w_ij_sum * multiplier, depth - 1, vert_col_map, vert_weights, loop_weights, freeze_vertsIdx)

class VertexWeight():
	# Defines the enumeration of vertex weight types
	UNIFORM = 1
	BARYCENTRIC = 2
	VORONOI = 3

	@classmethod
	def create_cache(cls, cachetype, stop_vertsIdx):
		"""
		Factory method for creating a vertex weight cache

		Returns:
			Cache: Vertex weight cache
		"""
		if cachetype == VertexWeight.UNIFORM:
			return Cache(calc_uniform_vertex_weight, stop_vertsIdx)
		elif cachetype == VertexWeight.BARYCENTRIC:
			return Cache(calc_barycentric_vertex_weight, stop_vertsIdx)
		elif cachetype == VertexWeight.VORONOI:
			return Cache(calc_voronoi_vertex_weight, stop_vertsIdx)

class LoopWeight():
	"""
	Defines the enumeration of loop weight types
	"""
	UNIFORM = 1
	COTAN = 2
	MVC = 3

	@classmethod
	def create_cache(cls, cachetype, stop_vertsIdx):
		"""
		Factory method for creating a loop weight cache

		Returns:
			Cache: Loop weight cache
		"""
		if cachetype == LoopWeight.UNIFORM:
			return Cache(calc_unif_loop_weight, stop_vertsIdx) #Cache(lambda l: 1)
		elif cachetype == LoopWeight.MVC:
			return Cache(calc_mvc_loop_weight, stop_vertsIdx)
		elif cachetype == LoopWeight.COTAN:
			return Cache(calc_cotangent_loop_weight, stop_vertsIdx)

def do_fair(bm, opt_continutyOrder, affected_verts, freeze_vertsIdx):
	global solver
	if solver is None:
		wla_do.pip_ensure_install("scipy")
		solver = SciPySolver()
	stop_vertsIdx = set()
	for f in bm.faces:
		if f.hide:
			for vv in f.verts:
				stop_vertsIdx.add(vv.index)
	# Determine which vertices are affected.
	affected_verts = [v for v in bm.verts if v.select]
	# Pre-fair affected vertices for consistent results.
	fair(bm, affected_verts, 1, #types.Continuity.POS.value,
		VertexWeight.create_cache(VertexWeight.UNIFORM, stop_vertsIdx), LoopWeight.create_cache(LoopWeight.UNIFORM, stop_vertsIdx),
		freeze_vertsIdx, None)

	print("Fairing started...")
	fair(bm, affected_verts, opt_continutyOrder,
		VertexWeight.create_cache(VertexWeight.VORONOI, stop_vertsIdx), LoopWeight.create_cache(LoopWeight.COTAN, stop_vertsIdx),
		#VertexWeight.create_cache(VertexWeight.BARYCENTRIC, stop_vertsIdx), LoopWeight.create_cache(LoopWeight.MVC, stop_vertsIdx),
		freeze_vertsIdx, None)

# ======================================== Quad-Sword_Remeshing

def bisect_gen_lines(numberCuts, p1, p2, norml):
	lines = []
	if numberCuts<3:
		return lines
	for i in range(int(numberCuts)+1):
		pp = p1.lerp(p2, i/numberCuts)
		lines.append( (pp, norml) )
	return lines

def bisect_make_mass(bm, cutplanes):
	print("- Bisecting. planes:",len(cutplanes))
	verts_protect_co = []
	for cutpp in cutplanes:
		bm.verts.index_update()
		bm.verts.ensure_lookup_table()
		bm.edges.index_update()
		bm.edges.ensure_lookup_table()
		bm.faces.index_update()
		bm.faces.ensure_lookup_table()
		bisectFaces = [f for f in bm.faces if f.hide == False]
		geom_in_v = []
		geom_in_e = []
		geom_in_f = []
		for f in bisectFaces:
			geom_in_v.extend(f.verts)
			geom_in_e.extend(f.edges)
			geom_in_f.append(f)
		geom_in = set(geom_in_v[:]+geom_in_e[:]+geom_in_f[:])
		print("- Bisecting faces", len(geom_in_f), cutpp)
		res = bmesh.ops.bisect_plane(bm, geom=list(geom_in), dist=config.kWPLRaycastEpsilon, plane_co=cutpp[0], plane_no=cutpp[1], use_snap_center=False, clear_outer=False, clear_inner=False)
		# FFR: TBD: need to calc PROTECTED verts (angle != 180)
		# bisect_v = set()
		# bisect_e = set()
		# for elem in res["geom"]:
		# 	if isinstance(elem, bmesh.types.BMEdge):
		# 		bisect_e.add(elem)
		# 	if isinstance(elem, bmesh.types.BMVert):
		# 		bisect_v.add(elem)
	return verts_protect_co
