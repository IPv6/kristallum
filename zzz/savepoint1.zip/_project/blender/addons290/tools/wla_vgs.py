import os, sys, time, datetime
import math, copy, string, random
import numpy as np
import bpy, bmesh, mathutils
import colorsys

import bpy.types
from mathutils import Vector, Matrix, Euler, Quaternion
from mathutils.bvhtree import BVHTree
from mathutils.kdtree import KDTree
from bpy_extras import view3d_utils
from bpy.props import *

from . import wla
from . import wla_do
from . import wla_bm
from . import wla_attr
from . import wla_meshwrap
from . import wla_edger
from . import wla_vgbind
from .. import config

# OLD: Not used anymore
# #vgs: mt(<obj_tag>, <affine>)
# #vgs: pt(<obj_tag>, <affine>)
# // Material pattern with solidify layers
# // <obj_tag> - pattern object
# // source/pattern: LocalXY layout expected (top view)
# // dd??: number of solidify layers (0,2,4, etc), depth
# // dw/dh - pattern tile-grid size (1x1 by default)
# // deep??: deepness of solidify layers
# // ou/ov - pattern offset by U/V-axis
# // su/sv - pattern scale by U/V-axis
# // side effects: <obj_tag> - renderability always ON
# // UV used: Islands_VGS

kWPLGKey_VGS = "vgScriptCP"
kWPLSubsOffsFac = 0.001
kWPLSubsScalFac = 0.01
kWPLDefSew_width = 0.0005
kWPLDefStripe_width = 5*kWPLSubsOffsFac

def parseVgScriptOffsets(step):
	step = step.strip()
	opt_postOffset = [0,0,0]
	opt_postScale = [1,1,1]
	opt_dops = {}
	opt_dops["ou"] = 0.0 # offset UV-U
	opt_dops["ov"] = 0.0 # offset UV-V
	opt_dops["su"] = 1.0 # scale UV-U
	opt_dops["sv"] = 1.0 # scale UV-V
	opt_dops["len"] = 0.0
	opt_dops["cnt"] = 0.0
	opt_dops["min"] = 0.0
	opt_dops["max"] = 0.0
	opt_dops["rx"] = 0.0
	opt_dops["ry"] = 0.0
	opt_dops["rz"] = 0.0
	opt_dops["dw"] = 0.0
	opt_dops["dh"] = 0.0
	opt_dops["dl"] = 0.0
	opt_dops["dd"] = 0.0
	opt_dops["dx"] = 0.0
	opt_dops["dy"] = 0.0
	opt_dops["dz"] = 0.0
	opt_dops["deep"] = 0.0 # bump-depth, mt-layers-depth, sew-radius
	opt_dops["%"] = "" # sew-lines "pattern"
	#opt_dops["w"] = 0.0
	#opt_dops["infl"] = 0.0
	opt_dops["oc"] = 0.0 # shift to camera
	if len(step) == 0:
		return opt_postOffset, opt_postScale, opt_dops
	if step.replace('.','',1).isdigit():
		opt_dops["cnt"] = wla.safeFloat(step)
		return opt_postOffset, opt_postScale, opt_dops
	stepVals = wla.strToTokensBracketed(step, False)
	#print("parseVgScriptOffsets", stepVals)
	for i in range(len(stepVals)):
		substep = stepVals[i].lower()
		substepVal = wla.safeFloat(substep) #float(wla.strToInt(substep))
		# print("- substep", substep, substepVal)
		if substep.startswith("ox"):
			opt_postOffset[0] = opt_postOffset[0] + substepVal * kWPLSubsOffsFac
		if substep.startswith("oy"):
			opt_postOffset[1] = opt_postOffset[1] + substepVal * kWPLSubsOffsFac
		if substep.startswith("oz"):
			opt_postOffset[2] = opt_postOffset[2] + substepVal * kWPLSubsOffsFac
		if substep.startswith("sx"):
			opt_postScale[0] = opt_postScale[0] * substepVal * kWPLSubsScalFac
		if substep.startswith("sy"):
			opt_postScale[1] = opt_postScale[1] * substepVal * kWPLSubsScalFac
		if substep.startswith("sz"):
			opt_postScale[2] = opt_postScale[2] * substepVal * kWPLSubsScalFac
		if substep.startswith("ss"):
			opt_postScale[0] = opt_postScale[0] * substepVal * kWPLSubsScalFac
			opt_postScale[1] = opt_postScale[1] * substepVal * kWPLSubsScalFac
			opt_postScale[2] = opt_postScale[2] * substepVal * kWPLSubsScalFac
		if substep.startswith("dw"):
			opt_dops["dw"] = opt_dops["dw"] + substepVal
		if substep.startswith("dh"):
			opt_dops["dh"] = opt_dops["dh"] + substepVal
		if substep.startswith("dl"):
			opt_dops["dl"] = opt_dops["dl"] + substepVal
		if substep.startswith("dx"):
			opt_dops["dx"] = opt_dops["dx"] + substepVal
		if substep.startswith("dy"):
			opt_dops["dy"] = opt_dops["dy"] + substepVal
		if substep.startswith("dz"):
			opt_dops["dz"] = opt_dops["dz"] + substepVal
		if substep.startswith("dd"):
			opt_dops["dd"] = opt_dops["dd"] + substepVal
		if substep.startswith("rx"):
			opt_dops["rx"] = opt_dops["rx"] + substepVal
		if substep.startswith("ry"):
			opt_dops["ry"] = opt_dops["ry"] + substepVal
		if substep.startswith("rz"):
			opt_dops["rz"] = opt_dops["rz"] + substepVal
		if substep.startswith("rr"):
			opt_dops["rx"] = opt_dops["rx"] + substepVal
			opt_dops["ry"] = opt_dops["ry"] + substepVal
			opt_dops["rz"] = opt_dops["rz"] + substepVal
		if substep.startswith("ou"):
			opt_dops["ou"] = opt_dops["ou"] + substepVal * kWPLSubsOffsFac
		if substep.startswith("ov"):
			opt_dops["ov"] = opt_dops["ov"] + substepVal * kWPLSubsOffsFac
		if substep.startswith("su"):
			opt_dops["su"] = opt_dops["su"] * substepVal * kWPLSubsScalFac
		if substep.startswith("sv"):
			opt_dops["sv"] = opt_dops["sv"] * substepVal * kWPLSubsScalFac
		if substep.startswith("deep"):
			opt_dops["deep"] = opt_dops["deep"] + substepVal * kWPLSubsScalFac
		if substep.startswith("len"):
			opt_dops["len"] = opt_dops["len"] + substepVal * kWPLSubsOffsFac
		if substep.startswith("min"):
			opt_dops["min"] = opt_dops["min"] + substepVal * kWPLSubsOffsFac
		if substep.startswith("max"):
			opt_dops["max"] = opt_dops["max"] + substepVal * kWPLSubsOffsFac
		if substep.startswith("cnt"):
			opt_dops["cnt"] = opt_dops["cnt"] + substepVal
		if substep.startswith("%"):
			opt_dops["%"] = stepVals[i][1:] # NOT substep!!! Lowercased not ok
		# if substep.startswith("infl"):
		# 	opt_dops["infl"] = opt_dops["infl"] + substepVal * kWPLSubsScalFac
		# if substep.startswith("w"):
		# 	if substepVal>1.0:
		# 		opt_dops["w"] = substepVal * kWPLSubsScalFac
		# 	else:
		# 		opt_dops["w"] = substepVal
		if substep.startswith("oc"):
			opt_dops["oc"] = opt_dops["oc"] + substepVal * kWPLSubsOffsFac
	opt_dops["postOffset"] = opt_postOffset
	opt_dops["postScale"] = opt_postScale
	return opt_postOffset, opt_postScale, opt_dops

# -- substeps: MESH --
# mat(<mattok>)
# - setting material
# col(#FFDDCC)
# - Forced recolor, DecorC
# hsl(h, s, l)
# - Color HSL change (DecorC)
# // Example: hsl( 10, 10, -20): +0.1 hue, +0.1 sat, -0.2 lightness
# wri(#FFFFFF)
# - Forced recolor, Wri
# === Not used for now ===
# wire(ox??, oy??, sharp)
# // make wireframe, ox/len = wire size, oy = wire offset (normal)
# ring(ox??, oy??)
# // combination: extend bounds(ox) + inset(oy, hole) + solidify(oz)
# subd(cnt??), subd(2)
# // subdivision
# source-cap(min??, max??)
# // limit verts distance to source surface
# source-slide(ox??), s-s(ox??)
# // shift verts shrinkwrapped (bvh-distance) to original surface 
# outers-extend(ox??), o-e(ox??)
# // boundary verts pushed futher (by ox)
# inners-dissolve(), i-d()
# // non-boundary verts dissolved
# sol(ox??)
# // solidifying
# inset(ox??, oy??, <type>)
# // insetting 
# // <type> == hole: optional inside-hole after insetting
def applySubsteps(step_full, vgs_obj_skin, addedFaces, substepExtras):
	if vgs_obj_skin is None:
		return
	# called with each new dup/cp island
	# selection - active zone. Non-selected verts should be changed!!!
	copiedFacesVC = substepExtras["copiedFacesVC"]
	copiedFacesVC = None
	if "copiedFacesMat" in substepExtras:
		copiedFacesMat = substepExtras["copiedFacesMat"]
	if copiedFacesVC is None:
		copiedFacesVC = (0,0,0)
	srcBVH_obj = substepExtras["srcBVH_obj"]
	# srcBVH = substepExtras["srcBVH"]
	# srcBVH_mw = srcBVH_obj.matrix_world
	# srcL2R = substepExtras["srcL2R"][0]
	# srcL2R_dirs = substepExtras["srcL2R"][1] # vertsL2R_dirs
	#print("srcL2R", srcL2R)
	# checking substeps
	stepVals = wla.strToTokensBracketed(step_full, False)
	#print("- substeps:", stepVals)
	ii = 0
	while ii < len(stepVals):
		step = stepVals[ii]
		ii = ii+1
		if "(" not in step:
			continue
		#print("// ",step)
		# setting up selection
		# if vgs_obj_skin.type == 'MESH':
		# 	wla_do.select_and_change_mode(vgs_obj_skin, 'EDIT')
		# 	bpy.ops.mesh.select_all(action='DESELECT')
		# 	wla_do.select_and_change_mode(vgs_obj_skin, 'OBJECT')
		# 	wla_do.select_and_change_mode(vgs_obj_skin, 'EDIT')
		if step.startswith("mat("):
			stepVals2 = wla.strExtractOuterBrackets(step)
			stepVals2a = wla.strToTokensBracketed(stepVals2, False)
			mat_name = wla_attr.mat_find_any(stepVals2a)
			if mat_name is None:
				print("// mat: no material for token:", stepVals2a)
			else:
				print("// mat: material:", mat_name)
				wla_do.select_and_change_mode(vgs_obj_skin, 'OBJECT')
				faceMatIdx = wla_attr.mat_obj_ensuremat(vgs_obj_skin, mat_name, None)
				for meshf in vgs_obj_skin.data.polygons:
					if meshf.index in addedFaces:
						meshf.material_index = faceMatIdx
		if step.startswith("hsl("):
			stepVals2 = wla.strExtractOuterBrackets(step)
			stepVals2a = wla.strToTokensBracketed(stepVals2, False)
			if len(stepVals2a) == 3 and "colDecorC" in substepExtras:
				facesColIni = substepExtras["colDecorC"]
				stepVals2a = (float(stepVals2a[0]) * kWPLSubsScalFac, float(stepVals2a[1]) * kWPLSubsScalFac, float(stepVals2a[2]) * kWPLSubsScalFac)
				tempHSV = colorsys.rgb_to_hsv(facesColIni[0], facesColIni[1], facesColIni[2])
				tempHSV = [tempHSV[0]+stepVals2a[0], tempHSV[1]+stepVals2a[1], tempHSV[2]+stepVals2a[2]]
				facesCol = colorsys.hsv_to_rgb(tempHSV[0], tempHSV[1], tempHSV[2])
				print("// hsl: altering color", stepVals2a, facesColIni, facesCol)
				wla_do.select_and_change_mode(vgs_obj_skin, 'OBJECT')
				wla_attr.vc_obj_ensure(vgs_obj_skin, config.kWPLMeshColVC)
				wla_attr.vc_obj_update(vgs_obj_skin,'FACE',config.kWPLMeshColVC,facesCol,(1.0,1.0,1.0),1.0,None,None,addedFaces)
		# if step == "col(systw)" or step == "col(texdirw)":
		# 	# recolor
		# 	facesCol = wla.hexToVectorRGB("#FFFFFF")
		# 	print("// recoloring", step, config.kWPLTexDirVC, facesCol)
		# 	wla_do.select_and_change_mode(vgs_obj_skin, 'OBJECT')
		# 	wla_attr.vc_obj_ensure(vgs_obj_skin, config.kWPLTexDirVC)
		# 	wla_attr.vc_obj_update(vgs_obj_skin,'FACE',config.kWPLTexDirVC,facesCol,(1.0,1.0,1.0),1.0,None,None,addedFaces)
		# elif step == "col(sysp)":
		# 	# recolor
		# 	facesCol = wla.hexToVectorRGB("#FFFF00")
		# 	print("// recoloring", step, config.kWPLTexDirVC, facesCol)
		# 	wla_do.select_and_change_mode(vgs_obj_skin, 'OBJECT')
		# 	# wla_attr.vc_obj_resetvcs(vgs_obj_skin, None, addedFaces) # NO!!! Will kill copied DecorC/etc
		# 	wla_attr.vc_obj_ensure(vgs_obj_skin, config.kWPLTexDirVC)
		# 	wla_attr.vc_obj_update(vgs_obj_skin,'FACE',config.kWPLTexDirVC,facesCol,(1.0,1.0,1.0),1.0,None,None,addedFaces)
		elif step == "col(wriw)":
			# recolor
			#facesCol = wla.hexToVectorRGB(wla.strExtractOuterBrackets(step))
			facesCol = wla.hexToVectorRGB("#FFFFFF")
			print("// recoloring", step, config.kWPLMeshWriVC, facesCol)
			wla_do.select_and_change_mode(vgs_obj_skin, 'OBJECT')
			wla_attr.vc_obj_ensure(vgs_obj_skin, config.kWPLMeshWriVC)
			wla_attr.vc_obj_update(vgs_obj_skin,'FACE',config.kWPLMeshWriVC,facesCol,(1.0,1.0,1.0),1.0,None,None,addedFaces)
		elif step.startswith("col("):
			# recolor
			facesCol = wla.hexToVectorRGB(wla.strExtractOuterBrackets(step))
			print("// recoloring", config.kWPLMeshColVC, facesCol)
			wla_do.select_and_change_mode(vgs_obj_skin, 'OBJECT')
			wla_attr.vc_obj_ensure(vgs_obj_skin, config.kWPLMeshColVC)
			wla_attr.vc_obj_update(vgs_obj_skin,'FACE',config.kWPLMeshColVC,facesCol,(1.0,1.0,1.0),1.0,None,None,addedFaces)
		# if step.startswith("texdir("):
		# 	# recolor
		# 	facesCol = wla.hexToVectorRGB(wla.strExtractOuterBrackets(step))
		# 	print("// recoloring", config.kWPLTexDirVC, facesCol)
		# 	wla_do.select_and_change_mode(vgs_obj_skin, 'OBJECT')
		# 	wla_attr.vc_obj_ensure(vgs_obj_skin, config.kWPLTexDirVC)
		# 	wla_attr.vc_obj_update(vgs_obj_skin,'FACE',config.kWPLTexDirVC,facesCol,(1.0,1.0,1.0),1.0,None,None,addedFaces)
		# vertMap = {}
		# vertMapCenterCo = Vector((0,0,0))
		# vertMapCenterCnt = 0.0
		# for meshf in vgs_obj_skin.data.polygons:
		# 	if meshf.index in addedFaces:
		# 		meshf.select = True # reselecting to last changed verts/faces
		# 		for vi in meshf.vertices:
		# 			v = vgs_obj_skin.data.vertices[vi]
		# 			vertMap[wla.coToKey(v.co)] = vi
		# 			vertMapCenterCo = vertMapCenterCo+v.co
		# 			vertMapCenterCnt = vertMapCenterCnt+1.0
		# if vertMapCenterCnt > 0.0:
		# 	vertMapCenterCo = vertMapCenterCo/vertMapCenterCnt
		#if step.startswith("fill("):
		# 	bpy.ops.mesh.edge_face_add()
		# if step.startswith("even("):
		# 	wla_bm.bm_vertsDistribute(bm, curve)
		# if step.startswith("xband("):
		# 	# extrude (ox) + offset(oy) above source surface + del non-extruded + solidify(oz)
		# 	stepInner = wla.strExtractOuterBrackets(step)
		# 	opt_postXY, _, _ = parseVgScriptOffsets(stepInner)
		# 	opt_postXY[0] = max(opt_postXY[0],0.001)
		# 	#makeHole = False
		# 	# if ("hole" in stepInner):
		# 	# 	makeHole = True
		# 	print("- making xband", opt_postXY)
		# 	wla_bm.find_last_changed_faces(vgs_obj_skin, False)
		# 	bm = bmesh.from_edit_mesh(vgs_obj_skin.data)
		# 	bm.verts.ensure_lookup_table()
		# 	bm.edges.ensure_lookup_table()
		# 	bm.faces.ensure_lookup_table()
		# 	f2del = []
		# 	vTos = []
		# 	e2ext = []
		# 	vFroms = []
		# 	# e2ext_h = []
		# 	# vFroms_h = []
		# 	for f in bm.faces:
		# 		if f.select:
		# 			f2del.append(f)
		# 	for v in bm.verts:
		# 		if v.select:
		# 			for e in v.link_edges:
		# 				if e.is_boundary:
		# 					if (wla.coToKey(e.verts[0].co) in srcHiddens) or (wla.coToKey(e.verts[1].co) in srcHiddens):
		# 						continue
		# 						# if v not in vFroms_h:
		# 						# 	vFroms_h.append(v)
		# 						# if e not in e2ext_h:
		# 						# 	e2ext_h.append(e)
		# 					else:
		# 						if v not in vFroms:
		# 							vFroms.append(v)
		# 						if e not in e2ext:
		# 							e2ext.append(e)
		# 	# if makeHole == False and len(e2ext_h) > 0:
		# 	# 	# should extrude edges, hidden in original
		# 	# 	vFroms = vFroms_h
		# 	# 	e2ext = e2ext_h
		# 	if len(e2ext) > 0:
		# 		ret = bmesh.ops.extrude_edge_only(bm, edges = e2ext, use_normal_flip = False, use_select_history = False)
		# 		vTos =  [ele for ele in ret["geom"] if isinstance(ele, bmesh.types.BMVert)]
		# 		for v in vTos:
		# 			for e in v.link_edges:
		# 				vFrom = e.verts[0]
		# 				if vFrom not in vFroms:
		# 					vFrom = e.verts[1]
		# 				if vFrom not in vFroms:
		# 					continue
		# 				vTo = e.other_vert(vFrom)
		# 				cloL, cloR, cloL_nrm = srcbvh_findClosestL2R(srcBVH_obj, srcL2R, srcL2R_dirs, vgs_obj_skin, vFrom.co)
		# 				v_co_src = srcBVH_obj.matrix_world.inverted() @ (vgs_obj_skin.matrix_world @ v.co)
		# 				cloL_src = srcBVH_obj.matrix_world.inverted() @ (vgs_obj_skin.matrix_world @ cloL)
		# 				cloR_src = srcBVH_obj.matrix_world.inverted() @ (vgs_obj_skin.matrix_world @ cloR)
		# 				v_from, v_slided = wla_bm.bm_vertFindOnBvh(srcBVH, v_co_src, (cloR_src-cloL_src).normalized() * opt_postXY[0])
		# 				if v_slided is not None:
		# 					vFrom.co = vgs_obj_skin.matrix_world.inverted() @ (srcBVH_obj.matrix_world @ v_from)
		# 					vTo.co = vgs_obj_skin.matrix_world.inverted() @ (srcBVH_obj.matrix_world @ v_slided)
		# 					vFrom.co = vFrom.co - cloL_nrm * opt_postXY[1]
		# 					vTo.co = vTo.co - cloL_nrm * opt_postXY[1]
		# 		if len(f2del)>0:
		# 			# deleting non-extruded faces
		# 			bmesh.ops.delete(bm, geom=f2del, context='FACES')
		# 		bmesh.update_edit_mesh(vgs_obj_skin.data)
		# 		addedFaces = wla_bm.find_last_changed_faces(vgs_obj_skin, True)
		# 		wla_do.select_and_change_mode(vgs_obj_skin, 'OBJECT')
		# 		for meshf in vgs_obj_skin.data.polygons:
		# 			if meshf.index in addedFaces:
		# 				meshf.select = True
		# 		wla_do.select_and_change_mode(vgs_obj_skin, 'EDIT')
		# 		bpy.ops.mesh.normals_make_consistent(inside=False) # or solidify can go mad
		# 		if abs(opt_postXY[2]) > 0:
		# 			stepVals.insert(ii+0, "sol(ox"+str(opt_postXY[2]/kWPLSubsOffsFac)+")")
		# if step.startswith("source-slide(") or step.startswith("s-s("):
		# 	print("// sliding on surface")
		# 	stepInner = wla.strExtractOuterBrackets(step)
		# 	opt_postXY, _, _ = parseVgScriptOffsets(stepInner)
		# 	opt_postXY[0] = max(opt_postXY[0],0.001)
		# 	bm = bmesh.from_edit_mesh(vgs_obj_skin.data)
		# 	bm.verts.ensure_lookup_table()
		# 	for v in bm.verts:
		# 		if v.select:
		# 			cloL, cloR, _ = srcbvh_findClosestL2R(srcBVH_obj, srcL2R, srcL2R_dirs, vgs_obj_skin, v.co)
		# 			v_co_src = srcBVH_obj.matrix_world.inverted() @ (vgs_obj_skin.matrix_world @ v.co)
		# 			cloL_src = srcBVH_obj.matrix_world.inverted() @ (vgs_obj_skin.matrix_world @ cloL)
		# 			cloR_src = srcBVH_obj.matrix_world.inverted() @ (vgs_obj_skin.matrix_world @ cloR)
		# 			_, v_slided = wla_bm.bm_vertFindOnBvh(srcBVH, v_co_src, (cloR_src-cloL_src).normalized() * opt_postXY[0])
		# 			#v_slided = cloR_src
		# 			if v_slided is not None:
		# 				v.co = vgs_obj_skin.matrix_world.inverted() @ (srcBVH_obj.matrix_world @ v_slided)
		# 	bmesh.update_edit_mesh(vgs_obj_skin.data)
		# if step.startswith("source-cap(") or step.startswith("s-c("):
		# 	print("// capping distance")
		# 	stepInner = wla.strExtractOuterBrackets(step)
		# 	_, _, opt_postDops = parseVgScriptOffsets(stepInner)
		# 	capMin = opt_postDops["min"]
		# 	capMax = opt_postDops["max"]
		# 	bm = bmesh.from_edit_mesh(vgs_obj_skin.data)
		# 	bm.verts.ensure_lookup_table()
		# 	for v in bm.verts:
		# 		if v.select:
		# 			location_ll, normal, index, distance = srcBVH.find_nearest(v.co, 999)
		# 			if location_ll is not None:
		# 				location_l = vgs_obj_skin.matrix_world.inverted() @ (srcBVH_mw @ location_ll)
		# 				distance = (location_l-v.co).length
		# 				if distance >= capMin and distance <= capMin:
		# 					# distance ok!
		# 					continue
		# 				distance = max(distance, capMin)
		# 				distance = min(distance, capMax)
		# 				v.co = location_l + ((v.co-location_l).normalized()*distance)
		# 	bmesh.update_edit_mesh(vgs_obj_skin.data)
		# if step.startswith("outers-extend(") or step.startswith("o-e("):
		# 	print("// extending bounds")
		# 	stepInner = wla.strExtractOuterBrackets(step)
		# 	opt_postXY, _, _ = parseVgScriptOffsets(stepInner)
		# 	opt_postXY[0] = max(opt_postXY[0],0.001)
		# 	bm = bmesh.from_edit_mesh(vgs_obj_skin.data)
		# 	bm.verts.ensure_lookup_table()
		# 	for v in bm.verts:
		# 		if v.select and v.is_boundary == True:
		# 			push_dir = Vector((0,0,0))
		# 			push_cnt = 0.0
		# 			for ve in v.link_edges:
		# 				if ve.other_vert(v).is_boundary == False:
		# 					push_dir = push_dir+(v.co - ve.other_vert(v).co).normalized()
		# 					push_cnt = push_cnt+1.0
		# 			if push_cnt < 1.0:
		# 				push_cnt = 1.0
		# 				push_dir = (v.co - vertMapCenterCo).normalized()
		# 			push_dir = (push_dir/push_cnt).normalized()
		# 			v.co = v.co + push_dir*opt_postXY[0]
		# 	bmesh.update_edit_mesh(vgs_obj_skin.data)
		# if step.startswith("inners-dissolve") or step.startswith("i-d"):
		# 	print("// dissolving inners")
		# 	bm = bmesh.from_edit_mesh(vgs_obj_skin.data)
		# 	bm.verts.ensure_lookup_table()
		# 	v2d = []
		# 	for v in bm.verts:
		# 		if v.select and v.is_boundary == False:
		# 			v2d.append(v)
		# 	if len(v2d) > 0:
		# 		bmesh.ops.dissolve_verts(bm, verts = v2d, use_face_split = False, use_boundary_tear = False)
		# 		bmesh.update_edit_mesh(vgs_obj_skin.data)
		# 	#wla_do.select_and_change_mode(vgs_obj_skin, 'OBJECT')
		# 	#wla_do.select_and_change_mode(vgs_obj_skin, 'EDIT')
		# 	#bpy.ops.mesh.select_all(action='SELECT')
		# if step.startswith("subd("):
		# 	stepInner = wla.strExtractOuterBrackets(step)
		# 	_, _, opt_postDops = parseVgScriptOffsets(stepInner)
		# 	subdLevel = int(max(1, opt_postDops["cnt"]))
		# 	print("// subdividing", subdLevel)
		# 	wla_bm.find_last_changed_faces(vgs_obj_skin, False)
		# 	bpy.ops.mesh.subdivide(number_cuts = subdLevel, smoothness = 1.0, ngon = True, quadcorner='STRAIGHT_CUT')
		# 	addedFaces = wla_bm.find_last_changed_faces(vgs_obj_skin, True)
		# if step.startswith("wire("):
		# 	# checking for postWireframing
		# 	stepInner = wla.strExtractOuterBrackets(step)
		# 	opt_postWireframeSm = True
		# 	opt_postXY = None
		# 	if "sharp" in stepInner:
		# 		opt_postWireframeSm = False
		# 	opt_postXY, _, opt_dops = parseVgScriptOffsets(stepInner)
		# 	opt_postXY[0] = max(max(opt_postXY[0], opt_dops["len"]),0.005)
		# 	print("// wireframe", stepInner, opt_postXY)
		# 	wla_bm.find_last_changed_faces(vgs_obj_skin, False)
		# 	bpy.ops.mesh.wireframe(use_boundary=True, use_replace=True, use_relative_offset = False, use_even_offset = True, thickness = opt_postXY[0], offset = opt_postXY[1])
		# 	if opt_postWireframeSm:
		# 		bpy.ops.mesh.faces_shade_smooth()
		# 	addedFaces = wla_bm.find_last_changed_faces(vgs_obj_skin, True)
		# 	if copiedFacesVC is not None:
		# 		wla_do.select_and_change_mode(vgs_obj_skin, 'OBJECT')
		# 		wla_attr.vc_obj_ensure(vgs_obj_skin, config.kWPLMeshColVC)
		# 		wla_attr.vc_obj_update(vgs_obj_skin,'FACE',config.kWPLMeshColVC,copiedFacesVC,(1.0,1.0,1.0),1.0,None,None,addedFaces)
		# if step.startswith("inset("):
		# 	stepInner = wla.strExtractOuterBrackets(step)
		# 	# checking for inset
		# 	opt_postXY, _, _ = parseVgScriptOffsets(stepInner)
		# 	opt_postXY[0] = max(opt_postXY[0],0.005)
		# 	print("// inseting", stepInner, opt_postXY)
		# 	wla_bm.find_last_changed_faces(vgs_obj_skin, False)
		# 	bpy.ops.mesh.inset(thickness=opt_postXY[0], depth=opt_postXY[1], use_relative_offset=False, use_edge_rail=False, use_outset=False, use_select_inset=False, use_individual=False, use_interpolate=True)
		# 	if "hole" in stepInner:
		# 		bpy.ops.mesh.delete(type='FACE')
		# 	addedFaces = wla_bm.find_last_changed_faces(vgs_obj_skin, True)
		# if step.startswith("sol("):
		# 	stepInner = wla.strExtractOuterBrackets(step)
		# 	opt_postXY, _, _ = parseVgScriptOffsets(stepInner)
		# 	if opt_postXY[0] >= 0.0:
		# 		opt_postXY[0] = max(opt_postXY[0],0.001)
		# 	print("// solidifying", stepInner, opt_postXY)
		# 	wla_bm.find_last_changed_faces(vgs_obj_skin, False)
		# 	bpy.ops.mesh.solidify(thickness=opt_postXY[0])
		# 	addedFaces = wla_bm.find_last_changed_faces(vgs_obj_skin, True)
		# if step.startswith("ring("):
		# 	# extend bounds, inners-dissolve(), inset(ox50,hole), sol(ox80)
		# 	stepInner = wla.strExtractOuterBrackets(step)
		# 	opt_postXY, _, _ = parseVgScriptOffsets(stepInner)
		# 	opt_postXY[0] = max(opt_postXY[0],0.001)
		# 	opt_postXY[1] = max(opt_postXY[1],0.001)
		# 	if abs(opt_postXY[2]) < config.kWPLRaycastEpsilon:
		# 		opt_postXY[2] = opt_postXY[1]*2.0
		# 	opt_postXY[2] = max(opt_postXY[2],0.001)
		# 	stepVals.insert(ii+0, "outers-extend(ox"+str(opt_postXY[1]/kWPLSubsOffsFac)+")")
		# 	#stepVals.insert(ii+1, "inners-dissolve()")
		# 	stepVals.insert(ii+1, "inset(ox"+str(opt_postXY[2]/kWPLSubsOffsFac)+", hole)")
		# 	stepVals.insert(ii+2, "sol(ox"+str(opt_postXY[0]/kWPLSubsOffsFac)+")")
		# if step.startswith("conv("):
		# 	print("// convexing")
		# 	#wla_bm.find_last_changed_faces(vgs_obj_skin, False)
		# 	bpy.ops.mesh.convex_hull(use_existing_faces = False)
		# 	#addedFaces = wla_bm.find_last_changed_faces(vgs_obj_skin, True)
		# 	# calculating newly added faces (and not changed, but from convex) via verts map
		# 	addedFaces = []
		# 	wla_do.select_and_change_mode(vgs_obj_skin, 'OBJECT')
		# 	for meshf in vgs_obj_skin.data.polygons:
		# 		for vi in meshf.vertices:
		# 			v = vgs_obj_skin.data.vertices[vi]
		# 			if wla.coToKey(v.co) in vertMap:
		# 				addedFaces.append(meshf.index)
		# 	if copiedFacesVC is not None:
		# 		wla_do.select_and_change_mode(vgs_obj_skin, 'OBJECT')
		# 		wla_attr.vc_obj_ensure(vgs_obj_skin, config.kWPLMeshColVC)
		# 		setCount = wla_attr.vc_obj_update(vgs_obj_skin,'FACE',config.kWPLMeshColVC,copiedFacesVC,(1.0,1.0,1.0),1.0, None, None, addedFaces)
		# # if step.startswith("wri(w)"):
		# # 	wla_do.select_and_change_mode(vgs_obj_skin, 'OBJECT')
		# # 	wla_attr.vc_obj_ensure(vgs_obj_skin, config.kWPLMeshWriVC)
		# # 	setCount = wla_attr.vc_obj_update(vgs_obj_skin,'FACE',config.kWPLMeshWriVC,(1.0,1.0,1.0),(1.0,1.0,1.0),1.0, None, None, addedFaces)
		# # 	print("// adding Wri White, faces:",str(setCount))
	return addedFaces

def srcbvh_offsetPtToCam(v_co, poc, localInObject, cache):
	if abs(poc) < 0.0001:
		return v_co
	if cache is not None:
		if "srcbvh_isPtSceneVisible" in cache:
			camera_gCo, camera_gOrtho, camera_gDir = cache["srcbvh_isPtSceneVisible"]
		else:
			camera_gCo, camera_gOrtho, camera_gDir, _ = wla.active_camera()
			cache["srcbvh_isPtSceneVisible"] = (camera_gCo, camera_gOrtho, camera_gDir)
	else:
		camera_gCo, camera_gOrtho, camera_gDir, _ = wla.active_camera()
	if localInObject is not None:
		matrix_world = localInObject.matrix_world
		matrix_world_inv = matrix_world.inverted()
		matrix_world_norm = matrix_world_inv.transposed().to_3x3()
		camera_lCo = matrix_world_inv @ camera_gCo
		camera_lDir = matrix_world_norm.inverted() @ camera_gDir
	else:
		camera_lCo = camera_gCo
		camera_lDir = camera_gDir
	if camera_gOrtho:
		camOffset = camera_lDir
	else:
		camOffset = (camera_lCo - v_co).normalized()
	v_co = v_co + camOffset*poc
	return v_co

def srcbvh_isPtSceneVisible(depsgraph, v_co_g, cache):
	# casting from vertex to camera 
	# - MUCH more robust than in other way
	# - TBD: ORTHO - ??? dist to plane!!!
	if cache is not None:
		if "srcbvh_isPtSceneVisible" in cache:
			camera_gCo, camera_gOrtho, camera_gDir = cache["srcbvh_isPtSceneVisible"]
		else:
			camera_gCo, camera_gOrtho, camera_gDir, _ = wla.active_camera()
			cache["srcbvh_isPtSceneVisible"] = (camera_gCo, camera_gOrtho, camera_gDir)
	else:
		camera_gCo, camera_gOrtho, camera_gDir, _ = wla.active_camera()
	proj_from_g = v_co_g
	if camera_gOrtho:
		proj_dir_g = camera_gDir
	else:
		proj_dir_g = (camera_gCo-v_co_g).normalized()
	cast_pt = proj_from_g + proj_dir_g*config.kWPLRaycastEpsilon
	hit_res, hit_g, hit_normal_g, _, hit_obj, _ = depsgraph.scene_eval.ray_cast(depsgraph, cast_pt, proj_dir_g)
	if (hit_res is None) or (hit_obj is None):
		return True
	if (hit_g-v_co_g).length > (camera_gCo-v_co_g).length*0.99:
		return True
	# if hit_obj is not None:
	# 	dbg_obj.append(hit_obj.name+" / "+str((hit_g-v_co_g).length/(camera_gCo-v_co_g).length))
	return False

def srcbvh_castClosestNears(srcBVH, v1_co, vUpDir, srcFacesFar):
	v1_cast_pos0, v1_cast_nrm0, _, _ = srcBVH.find_nearest(v1_co, 999)
	v1_cast_pos1, v1_cast_nrm1, v1_cast_fIdx1, _ = srcBVH.ray_cast(v1_co - vUpDir*0.001, vUpDir)
	v1_cast_pos2, v1_cast_nrm2, v1_cast_fIdx2, _ = srcBVH.ray_cast(v1_co + vUpDir*0.001, -1*vUpDir)
	if (v1_cast_fIdx1 is not None) and (v1_cast_fIdx1 not in srcFacesFar):
		v1_cast_fIdx1 = None
		v1_cast_pos1 = None
	if (v1_cast_fIdx1 is not None) and (v1_cast_nrm1.dot(vUpDir) < 0):
		v1_cast_fIdx1 = None
		v1_cast_pos1 = None
	if (v1_cast_fIdx1 is not None) and (v1_cast_fIdx1 not in srcFacesFar):
		v1_cast_fIdx1 = None
		v1_cast_pos1 = None
	if (v1_cast_fIdx2 is not None) and (v1_cast_nrm2.dot(vUpDir) < 0):
		v1_cast_fIdx2 = None
		v1_cast_pos2 = None
	if (v1_cast_fIdx2 is not None) and (v1_cast_fIdx2 not in srcFacesFar):
		v1_cast_fIdx2 = None
		v1_cast_pos2 = None
	possibles = []
	possibles.append( (v1_co, 999) )
	if v1_cast_pos1 is not None:
		possibles.append( (v1_cast_pos1, (v1_cast_pos1-v1_co).length))
	if v1_cast_pos2 is not None:
		possibles.append( (v1_cast_pos2, (v1_cast_pos2-v1_co).length))
	if v1_cast_pos0 is not None:
		possibles.append( (v1_cast_pos0, (v1_cast_pos0-v1_co).length))
	possibles.sort(key=lambda ia: ia[1], reverse=False)
	return possibles[0][0]

def srcbvh_findClosestL2R(src_obj, src_vertsL2R, src_vertsL2R_dirs, copy_obj, copy_v_co):
	# srcL2R_dirs
	max_dst = 999
	clo_vIdx = 0
	cmw = copy_obj.matrix_world
	cmwi = copy_obj.matrix_world.inverted()
	smw = src_obj.matrix_world
	for src_vIdx in src_vertsL2R.keys():
		src_v = src_obj.data.vertices[src_vIdx]
		src_dst = ( (smw @ src_v.co)- (cmw @ copy_v_co) ).length
		if src_dst < max_dst:
			max_dst = src_dst
			clo_vIdx = src_vIdx
	#print("// closests:", clo_vIdx)
	src_vL = src_obj.data.vertices[clo_vIdx]
	closest_src_coL = cmwi @ (smw @ src_vL.co)
	closest_src_coR = None
	src_nrm = None
	if clo_vIdx in src_vertsL2R_dirs:
		l2r_dirs = src_vertsL2R_dirs[clo_vIdx]
		up_ortho = src_vL.co + l2r_dirs[3]
		r_ortho = src_vL.co + l2r_dirs[4]
		closest_src_coR = cmwi @ (smw @ r_ortho) # fake perpendicular position
		closest_src_coLUp = cmwi @ (smw @ up_ortho)
		src_nrm = (closest_src_coL - closest_src_coLUp).normalized() # in vgs_obj_skin local coords
	else:
		src_vR = src_obj.data.vertices[src_vertsL2R[clo_vIdx]]
		src_dir = (src_vR.co-src_vL.co).normalized()
		src_tan = src_dir.cross(src_vL.normal)
		src_nrm = src_tan.cross(src_dir)
		closest_src_coR = cmwi @ (smw @ src_vR.co)
		closest_src_coLUp = cmwi @ (smw @ (src_vL.co+src_nrm))
		src_nrm = (closest_src_coLUp-closest_src_coL).normalized() # in vgs_obj_skin local coords
	return closest_src_coL, closest_src_coR, src_nrm

# def srcbvh_orientToSurroundFaces(active_obj, vIdx, vcoN_l, hiddenVerts):
# 	faceNrms = Vector((0,0,0))
# 	faceNrmsCnt = 0
# 	if active_obj is not None:
# 		for f in active_obj.data.polygons:
# 			isValidFace = True
# 			if hiddenVerts is not None:
# 				for idx in f.vertices:
# 					if idx in hiddenVerts:
# 						isValidFace = False
# 			if isValidFace:
# 				for idx in f.vertices:
# 					if idx == vIdx:
# 						faceNrms = faceNrms+f.normal
# 						faceNrmsCnt = faceNrmsCnt+1
# 	if faceNrmsCnt > 0:
# 		faceNrms = (faceNrms / faceNrmsCnt).normalized()
# 	else:
# 		print("// srcbvh_orientToSurroundFaces: no valid faces found for", vIdx)
# 		faceNrms = Vector((0,0,1))
# 	if vcoN_l is None:
# 		return faceNrms
# 	if vcoN_l.dot(faceNrms) < 0:
# 		vcoN_l = copy.copy(-1 * vcoN_l)
# 	return vcoN_l

# def wirefold_followEdgeToTheEnd(bm, startVert, startEdge):
# 	# NOT including startVert
# 	nextVerts = []
# 	while (startEdge is not None) and (startVert is not None):
# 		nextV = startEdge.other_vert(startVert)
# 		nextVerts.append(nextV)
# 		startVert = None
# 		# next vert - on edge that not share any faces with startEdge
# 		for nextEdge in nextV.link_edges:
# 			if len(nextEdge.link_faces) == 0:
# 				# wire edges not needed
# 				continue
# 			isNextStart = True
# 			for nef in nextEdge.link_faces:
# 				for sef in startEdge.link_faces:
# 					if sef == nef:
# 						isNextStart = False
# 						break
# 			if isNextStart:
# 				startEdge = nextEdge
# 				startVert = nextV
# 				break
# 	return nextVerts
# def wirefold_segmentEdgesToFlow(bm, v, forward_dir_l):
# 	forward_dir_l = forward_dir_l.normalized()
# 	edgesByAng = []
# 	for e in v.link_edges:
# 		if len(e.link_faces) == 0:
# 			continue
# 		edirdot = (e.other_vert(v).co-v.co).normalized().dot(forward_dir_l)
# 		edgesByAng.append( (e, edirdot) )
# 	if len(edgesByAng) < 2:
# 		return None, None, None, None
# 	edgesByAng.sort(key=lambda ia: ia[1], reverse=True)
# 	forwE = None
# 	side1E = None
# 	side2E = None
# 	backwE = None
# 	sideFrom = 0
# 	sideTo = len(edgesByAng)-1
# 	if edgesByAng[0][1] > 0.5:
# 		# ok for forward
# 		forwE = edgesByAng[0][0]
# 		sideFrom = sideFrom+1
# 	if edgesByAng[-1][1] < -0.5:
# 		backwE = edgesByAng[-1][0]
# 		sideTo = sideTo-1
# 	if sideFrom <= sideTo:
# 		side1E = edgesByAng[sideFrom][0]
# 	if sideFrom+1 <= sideTo:
# 		side2E = edgesByAng[sideTo][0]
# 	return forwE, side1E, side2E, backwE
# def wirefold_islandToVertGraph(bm, startVert, forward_dir_l):
# 	forward_dir_l = forward_dir_l.normalized()
# 	forwE, side1E, side2E, backwE = wirefold_segmentEdgesToFlow(bm, startVert, forward_dir_l)
# 	if (forwE is None) and (backwE is None):
# 		# no clear direction, skipping
# 		print("// failed to segment for forward/backward")
# 		return [], []
# 	if (side1E is not None) and (side2E is not None):
# 		# not a bounding vert... looking for bound vert
# 		sideToEnd1 = wirefold_followEdgeToTheEnd(bm, startVert, side1E)
# 		sideToEnd2 = wirefold_followEdgeToTheEnd(bm, startVert, side2E)
# 		# getting shortest for stability
# 		if sideToEnd1 is None and sideToEnd2 is not None:
# 			sideToEnd1 = sideToEnd2
# 		elif (sideToEnd1 is not None) and (sideToEnd2 is not None) and len(sideToEnd2)<len(sideToEnd1):
# 			sideToEnd1 = sideToEnd2
# 		if sideToEnd1 is None or len(sideToEnd1) == 0:
# 			print("// failed to find direction to the bound edges")
# 			return [], []
# 		startVert = sideToEnd1[-1]
# 	forwE, side1E, side2E, backwE = wirefold_segmentEdgesToFlow(bm, startVert, forward_dir_l)
# 	if (side1E is None) and (side2E is None):
# 		# no sides... WTF???
# 		print("// failed to find profile")
# 		return [], []
# 	nextForw = []
# 	nextBckw = []
# 	forwToEnd = wirefold_followEdgeToTheEnd(bm, startVert, forwE)
# 	bckwToEnd = wirefold_followEdgeToTheEnd(bm, startVert, backwE)
# 	# initial line - first in forwards
# 	forwToEnd.insert(0, startVert)
# 	print("// forwToEnd", [v.index for v in forwToEnd])
# 	print("// bckwToEnd", [v.index for v in bckwToEnd])
# 	checkingOrder = [ (forwToEnd, nextForw), (bckwToEnd, nextBckw) ]
# 	for i, check in enumerate(checkingOrder):
# 		checkVerts = check[0]
# 		checkSides = check[1]
# 		if checkVerts is not None:
# 			for v in checkVerts:
# 				for e in v.link_edges:
# 					if (len(e.link_faces) == 0):
# 						continue
# 					if (e.other_vert(v) in forwToEnd):
# 						continue
# 					if (e.other_vert(v) in bckwToEnd):
# 						continue
# 					sideToEnd = wirefold_followEdgeToTheEnd(bm, v, e)
# 					sideToEnd.insert(0, v)
# 					checkSides.append(sideToEnd)
# 					#print("// checkSides", i, [v.index for v in sideToEnd])
# 	return nextForw, nextBckw

def wirefold_getCurvePtDirs(bm, i, curve_vIdx, vertsL2R): # vertsL2R_dirs
	if i < 0 or i >= len(curve_vIdx):
		return None, None, None, None, None, None
	vIdx = curve_vIdx[i]
	vL = bm.verts[vIdx]
	vLDir = Vector( (0,0,0) )
	vLDirCnt = 0.0
	if i < len(curve_vIdx)-1:
		vLnext = bm.verts[curve_vIdx[i+1]]
		vLDirThis = (vLnext.co - vL.co).normalized()
		vLDir = vLDir + vLDirThis
		vLDirCnt = vLDirCnt+1.0
		#print("- 692: next", curve_vIdx[i+1], vLDirThis)
	if i > 0:
		vLprev = bm.verts[curve_vIdx[i-1]]
		vLDirThis = (vL.co - vLprev.co).normalized()
		vLDir = vLDir + vLDirThis
		vLDirCnt = vLDirCnt+1.0
		#print("- 692: prev", curve_vIdx[i-1], vLDirThis)
	if vLDirCnt > 0.0:
		vLDir = (vLDir/vLDirCnt).normalized()
	if vIdx not in vertsL2R:
		# half-baked data - ok for fallbacks
		vR = wla_bm.bm_vertSecondAxisVert(vL, curve_vIdx, False )
		#print("- r-vert: fallback on",vL.index, vR)
		if vR is not None:
			vRDir = (vR.co-vL.co).normalized()
			vUpDir = vRDir.cross(vLDir).normalized()
			vRDirOrtho = vLDir.cross(vUpDir).normalized()
			if vUpDir.dot(vL.normal) < 0.0:
				vUpDir = -1.0*vUpDir
			return vL, vR, vLDir, vRDir, vUpDir, vRDirOrtho
		return None, None, None, None, None, None
	vR = bm.verts[vertsL2R[vIdx]]
	vRDir = (vR.co-vL.co).normalized()
	if vLDirCnt == 0.0:
		# possible for 1pt curves - for align, etc
		if vLDirCnt == 0.0:
			# 1. getting from bound edges, if present
			for e in vL.link_edges:
				if len(e.link_faces) == 1:
					vLDirThis = (e.verts[1].co-e.verts[0].co).normalized()
					if vRDir.cross(vL.normal).dot(vLDirThis)<0:
						vLDirThis = -1*vLDirThis
					vLDir = vLDir + vLDirThis
					vLDirCnt = vLDirCnt+1
		if vLDirCnt == 0.0:
			# 2. getting from seam edges, if present
			for e in vL.link_edges:
				if e.seam:
					vLDirThis = (e.verts[1].co-e.verts[0].co).normalized()
					if vRDir.cross(vL.normal).dot(vLDirThis)<0:
						vLDirThis = -1*vLDirThis
					vLDir = vLDir + vLDirThis
					vLDirCnt = vLDirCnt+1
		if vLDirCnt > 0.0:
			vLDir = (vLDir/vLDirCnt).normalized()
		else:
			# fallback
			vLDir = vRDir.cross(vL.normal)
	vUpDir = vRDir.cross(vLDir).normalized()
	vRDirOrtho = vLDir.cross(vUpDir).normalized()
	if vUpDir.dot(vL.normal) < 0.0:
		vUpDir = -1.0*vUpDir
	#vUpDir = srcbvh_orientToSurroundFaces(active_obj, vIdx, vUpDir, None)
	return vL, vR, vLDir, vRDir, vUpDir, vRDirOrtho

def execVgScriptOnObject(active_obj, allowNonReentrables):
	camera_gCo, camera_gOrtho, camera_gDir, _ = wla.active_camera()
	if camera_gCo is None:
		print("- Camera not found: "+config.kWPLSystemMainCam)
		return None
	if active_obj is None:
		print("- Object not found")
		return None
	if active_obj.type not in ['MESH', 'CURVE']:
		return None
	wla_do.select_and_change_mode(active_obj, 'OBJECT')
	depsgraph = bpy.context.evaluated_depsgraph_get()
	matrix_world = active_obj.matrix_world
	matrix_world_inv = matrix_world.inverted()
	matrix_world_norm = matrix_world_inv.transposed().to_3x3()
	# camera_lCo = matrix_world_inv @ camera_gCo
	# camera_lDir = matrix_world_norm.inverted() @ camera_gDir
	deform_verts, deform_verts_nrm = wla_bm.bm_getDeformedCos(active_obj)
	active_mesh = active_obj.data # after deforms
	if active_obj.type == 'MESH': 
		if len(wla_attr.vg_names_by_nameToken(active_obj, "sw("))>0: # len(wla_attr.vg_names_by_nameToken(active_obj, "mt("))>0 or len(wla_attr.vg_names_by_nameToken(active_obj, "pt("))>0 or 
			edgesUVMap = active_obj.data.uv_layers.get(config.kWPLGridUV)
			if edgesUVMap is None:
				print("- Warning: Unwrap not found:", config.kWPLGridUV)
				#return None
	vgicutline_verts, _ = wla_attr.vg_get_weightMapByTok(active_obj, config.kWPLSuppVGScriptCutlin)
	vg_groups = wla_attr.vg_names_by_nameToken(active_obj, config.kWPLSuppVGScriptToken)
	# uvband() preparations
	# uv_stripes = None
	# uv_stripes_dataVerts = None
	# if active_obj.type == 'MESH' and len(wla_attr.vg_names_by_nameToken(active_obj, "uvband("))>0:
	# 	uv_stripes = config.kWPLGridUV+"_VGS" # Grid_VGS
	# 	uv_stripes_dataVerts = {}
	# 	for vert in active_mesh.vertices:
	# 		uv_stripes_dataVerts[vert.index] = [-999.0, -999.0]
	# # mt() pt() preparations
	# uv_mtpt = None
	# uv_mtpt_deep = 0
	# uv_mtpt_cnt = 0
	# uv_mtpt_dataCnt = 0
	# uv_mtpt_dataPolys = None
	# if active_obj.type == 'MESH' and (len(wla_attr.vg_names_by_nameToken(active_obj, "mt("))>0 or len(wla_attr.vg_names_by_nameToken(active_obj, "pt("))>0):
	# 	uv_mtpt = config.kWPLIslandsVC+"_VGS" # Islands_VGS
	# 	uv_mtpt_dataPolys = {}
	# 	for poly in active_mesh.polygons:
	# 		uv_mtpt_dataPolys[poly.index] = [0.0,0.0]
	wla_do.select_and_change_mode(active_obj, 'EDIT')
	bm = bmesh.from_edit_mesh(active_mesh)
	bm.verts.ensure_lookup_table()
	bm.edges.ensure_lookup_table()
	bm.faces.ensure_lookup_table()
	bm4curves = None
	okCnt = 0
	cpSteps = []
	skSteps = []
	alSteps = []
	edSteps = []
	#print("- vg_groups:", vg_groups)
	for vgname_base in vg_groups:
		vgname = vgname_base.replace(" ","")
		if wla.isTokenInStr(config.kWPLSuppVGNoMirror, vgname):
			# or (config.kWPLSuppVGFoldProfileLen in vgname) or (config.kWPLSuppVGFoldProfileRr in vgname)
			# service groups, nothing to do
			continue
		if wla.isTokenInStr([config.kWPLSuppVGScriptCutlin, config.kWPLSuppVGScriptRigids], vgname):
			# service groups, nothing to do
			continue
		# vgname = vgname.replace("_",",") # NOP, cp can have object names...
		if wla.isTokenInStr(config.kWPLSuppVGScriptToken, vgname):
			# # skips for Applied mirror modifier -> not really needed
			# # alternatively "safe XMirror !mirror" can be used -> easier, result is the same
			# if ("onlyL" in vgname) and (".L" not in vgname):
			# 	continue
			# if ("onlyR" in vgname) and (".R" not in vgname):
			# 	continue
			if ("bind(" in vgname):
				# binding - via separate step
				continue
			print("- vgScript found:", vgname_base)
			vgsteps = wla.strToTokensBracketed(vgname, False)
			# simple steps, curves not needed
			# okCntSimple = 0
			# for step in vgsteps:
			# 	if ("wire(" in step):
			# 		okCnt = okCnt+1
			# 		okCntSimple = okCntSimple+1
			# 		st_def = wla.strExtractOuterBrackets(step)
			# 		opt_postOffset, opt_postScale, opt_dops = parseVgScriptOffsets(st_def)
			# 		stepVals = wla.strToTokens(st_def, False)
			# 		nameTok = stepVals[0]
			# 		bumpZ = opt_postOffset[2]
			# 		if abs(bumpZ) < 0.0001:
			# 			bumpZ = 0.003
			# 		mdWire_name = config.kWPLSuppVGScriptToken+":wire:"+nameTok
			# 		mdWire = wla.modf_by_type(active_obj, None, mdWire_name)
			# 		if mdWire is None:
			# 			mdWire = active_obj.modifiers.new(name = mdWire_name, type = 'WIREFRAME')
			# 		mdWire.offset = 0.0
			# 		mdWire.use_boundary = True
			# 		mdWire.use_replace = True
			# 		mdWire.thickness = bumpZ
			# 		mdWire.vertex_group = vgname_base #wla_attr.vg_get_by_name(vgname)
			# 		mdWire.thickness_vertex_group = 0.0
			# 		mdWire.show_on_cage = True
			# 		# need to be visible for edge editing
			# 		mdWire.show_in_editmode = True
			# 		wla_do.modf_sendBackByName(active_obj, mdWire_name, True)
			# 	if ("bump(" in step):
			# 		okCnt = okCnt+1
			# 		okCntSimple = okCntSimple+1
			# 		st_def = wla.strExtractOuterBrackets(step)
			# 		opt_postOffset, opt_postScale, opt_dops = parseVgScriptOffsets(st_def)
			# 		stepVals = wla.strToTokens(st_def, False)
			# 		nameTok = stepVals[0]
			# 		bumpW = max(max(opt_postOffset[0], opt_postOffset[1]), 0.003)
			# 		bumpZ = opt_postOffset[2]
			# 		if abs(bumpZ) < 0.0001:
			# 			bumpZ = 0.001
			# 		bumpDepth = opt_dops["deep"]
			# 		mdBvl1_name = config.kWPLSuppVGScriptToken+":bvl:"+nameTok
			# 		mdBvl1 = wla.modf_by_type(active_obj, None, mdBvl1_name)
			# 		if mdBvl1 is None:
			# 			mdBvl1 = active_obj.modifiers.new(name = mdBvl1_name, type = 'BEVEL')
			# 		mdBvl1.affect = 'EDGES'
			# 		mdBvl1.limit_method = 'VGROUP'
			# 		mdBvl1.vertex_group = vgname_base #wla_attr.vg_get_by_name(vgname)
			# 		mdBvl1.width = bumpW
			# 		mdBvl1.segments = 2
			# 		mdBvl1.vmesh_method = 'ADJ' # 'CUTOFF' can explode
			# 		mdBvl1.mark_sharp = True
			# 		mdBvl1.use_clamp_overlap = True
			# 		mdBvl1.show_in_editmode = False
			# 		mdBvl1.show_on_cage = False
			# 		mdWclamp_name = config.kWPLSuppVGScriptToken+":wfix:"+nameTok
			# 		mdWclamp = wla.modf_by_type(active_obj, None, mdWclamp_name)
			# 		if mdWclamp is None:
			# 			mdWclamp = active_obj.modifiers.new(name = mdWclamp_name, type = 'VERTEX_WEIGHT_EDIT')
			# 		mdWclamp.vertex_group = vgname_base #wla_attr.vg_get_by_name(vgname)
			# 		mdWclamp.use_remove = True
			# 		mdWclamp.remove_threshold = 0.999
			# 		mdWclamp.show_in_editmode = False
			# 		mdWclamp.show_on_cage = False
			# 		if "wire" in st_def:
			# 			mdWire_name = config.kWPLSuppVGScriptToken+":wire:"+nameTok
			# 			mdWire = wla.modf_by_type(active_obj, None, mdWire_name)
			# 			if mdWire is None:
			# 				mdWire = active_obj.modifiers.new(name = mdWire_name, type = 'WIREFRAME')
			# 			mdWire.offset = 0.0
			# 			mdWire.use_boundary = True
			# 			mdWire.use_replace = True
			# 			mdWire.thickness = bumpZ
			# 			mdWire.vertex_group = vgname_base
			# 			mdWire.thickness_vertex_group = 0.0
			# 			mdWire.show_on_cage = True
			# 			# need to be visible for edge editing
			# 			mdWire.show_in_editmode = True
			# 			wla_do.modf_sendBackByName(active_obj, mdWire_name, True)
			# 		else:
			# 			mdDispl_name = config.kWPLSuppVGScriptToken+":displ:"+nameTok
			# 			mdDispl = wla.modf_by_type(active_obj, None, mdDispl_name)
			# 			if mdDispl is None:
			# 				mdDispl = active_obj.modifiers.new(name = mdDispl_name, type = 'DISPLACE')
			# 			mdDispl.vertex_group = vgname_base #wla_attr.vg_get_by_name(vgname)
			# 			mdDispl.mid_level = 0.5
			# 			mdDispl.strength = bumpZ
			# 			mdDispl.show_in_editmode = False
			# 			mdDispl.show_on_cage = False
			# 			mdBvl2_name = config.kWPLSuppVGScriptToken+":bvl_len:"+nameTok
			# 			if bumpDepth > 0.0:
			# 				mdBvl2 = wla.modf_by_type(active_obj, None, mdBvl2_name)
			# 				if mdBvl2 is None:
			# 					mdBvl2 = active_obj.modifiers.new(name = mdBvl2_name, type = 'BEVEL')
			# 				mdBvl2.affect = 'EDGES'
			# 				mdBvl2.limit_method = 'VGROUP'
			# 				mdBvl2.vertex_group = vgname_base #wla_attr.vg_get_by_name(vgname)
			# 				mdBvl2.width = bumpDepth * bumpW
			# 				mdBvl2.segments = 1
			# 				mdBvl2.vmesh_method = 'ADJ'
			# 				mdBvl2.use_clamp_overlap = True
			# 				mdBvl2.show_in_editmode = False
			# 				mdBvl2.show_on_cage = False
			# 				wla_do.modf_sendBackByName(active_obj, mdBvl2_name, False)
			# 			wla_do.modf_sendBackByName(active_obj, mdDispl_name, False)
			# 		wla_do.modf_sendBackByName(active_obj, mdWclamp_name, False)
			# 		wla_do.modf_sendBackByName(active_obj, mdBvl1_name, False)
			# if okCntSimple>0:	# no need build curves
			# 	continue
			# populating curves
			vertsL = []
			vertsR = []
			vertsL2R = {}
			vertsL2R_dirs = {}
			# vertsLislands = None
			vertsLcurves = None
			if "freestyle(" in vgname_base:
				(fsEdgesIdx, _) = wla_meshwrap.objectm_extractEdgesByType(active_obj)
				for fseIdx in fsEdgesIdx:
					e = bm.edges[fseIdx]
					if e.verts[0].index not in vertsL:
						vertsL.append(e.verts[0].index)
					if e.verts[1].index not in vertsL:
						vertsL.append(e.verts[1].index)
			else:
				vgmap = wla_attr.vg_get_weightMap(active_obj, vgname_base)
				for vIdx in vgmap.keys():
					if vgmap[vIdx] > 1.0-config.kWPLVGSMinViableWeight:
						vertL = bm.verts[vIdx]
						vertsL.append(vertL.index)
			vertsStepAll = vertsL #+vertsLcutline -> vertsLcutline are automatically used at bm_splitVertsByConnection
			# calculating R-verts for all L-verts (including ignores)
			for vIdx in vertsStepAll:
				vertL = bm.verts[vIdx]
				vertR = None
				#print("// vL", vIdx)
				if vertR is None:
					# 1) edge with no faces AND other_vert with no faces
					# to quikly overload vg lines for one-shot fixes
					# fold(wire) island connection should be ignored!!!!
					for e in vertL.link_edges:
						if e.is_wire and len(e.other_vert(vertL).link_faces) == 0:
							vertR = e.other_vert(vertL)
							break
				if vertR is None:
					# 2) checking same map, max among lower weight
					# 0.99 -> or an be problems with floats comparisons...
					maxWeight = config.kWPLVGSMinViableWeight
					for e in vertL.link_edges:
						vertLsec = e.other_vert(vertL)
						if vertLsec.index in vertsL:
							continue
						if (vertLsec.index in vgmap) and (vgmap[vertLsec.index] > maxWeight) and (vgmap[vertLsec.index] < vgmap[vertL.index]*0.99):
							maxWeight = vgmap[vertLsec.index]
							vertR = vertLsec
				if vertR is None:
					# 3) Usual rules (as for PASTE) - seam edges, etc
					vertR = wla_bm.bm_vertSecondAxisVert(vertL, vertsStepAll, False )
					# print("// vL -> vR", vertL.index, vertR)
					if vertR is not None:
						# Rechecking. None L-verts in R-curves!!!
						if (vertR.index in vgmap) and vgmap[vertR.index]>1.0-config.kWPLVGSMinViableWeight:
							vertR = None
					# else:
					# 	print("// R-vert not found: last resort", vertL.index)
				# verts pair
				if vertR is not None:
					#vertR.select = True # DBG
					vertsL2R[vertL.index] = vertR.index
					vertsR.append(vertR.index)
				# else: # DO NOTHING, perfectly valid in some cases
			vertsLcurves = wla_bm.bm_splitVertsByConnection(bm, vertsL, False, None, vgicutline_verts)
			for curve in vertsLcurves:#+vertsLislands
				# reversing curves if direction not ok
				# R-vert weight at start should be less or same
				if (curve[0] in vertsL2R) and (curve[-1] in vertsL2R):
					w1 = 0
					if vertsL2R[curve[0]] in vgmap:
						w1 = vgmap[ vertsL2R[curve[0]] ]
					w2 = 0
					if vertsL2R[curve[-1]] in vgmap:
						w2 = vgmap[ vertsL2R[curve[-1]] ]
					if w1 < w2:
						# need reverse curve!
						curve.reverse()
			for curve in vertsLcurves:
				# curves CAN be even 1pt - for align/cp
				#print("// preparing curve", curve)
				for i, vIdx in enumerate(curve):
					vL, vR, vLDir, vRDir, vUpDir, vRDirOrtho = wirefold_getCurvePtDirs(bm, i, curve, vertsL2R)
					if (vL is not None) and (vR is not None):
						vLco_deformed = deform_verts[vL.index]
						vRco_deformed = deform_verts[vR.index]
						vertsL2R_dirs[vIdx] = (vR.index, vLDir, vRDir, vUpDir, vRDirOrtho, vLco_deformed, vRco_deformed)
					elif vRDir is not None:
						# faking... easier than calc in each method
						vIdx = curve[i]
						vL = bm.verts[vIdx]
						vLco_deformed = deform_verts[vL.index]
						vRco_deformed = vLco_deformed+vRDir
						vertsL2R_dirs[vIdx] = (None, vLDir, vRDir, vUpDir, vRDirOrtho, vLco_deformed, vRco_deformed)
			print("// L-curves:", len(vertsLcurves))
			#foldVertOriginMap = None
			for step in vgsteps:
				if ("fit(" in step):
					okCnt = okCnt+1
					st_def = wla.strExtractOuterBrackets(step)
					opt_postOffset, opt_postScale, opt_dops = parseVgScriptOffsets(st_def)
					stripe_len = max(max(max(opt_postOffset[0],opt_postOffset[1]),opt_postOffset[2]), max(opt_dops["len"], kWPLDefSew_width))
					print("// applying", step, stripe_len)
					# def findClosestOnCurve(co,curve):
					for curve in vertsLcurves:
						handledVrts = {}
						for i,vIdx in enumerate(curve):
							vL = bm.verts[vIdx]
							vRDirOrtho = None
							if vIdx not in vertsL2R_dirs:
								print("// fit() problem: vert:", vIdx,": no right-vert found")
								continue
							vRidx, vLDir, vRDir, vUpDir, vRDirOrtho, _, _ = vertsL2R_dirs[vIdx]
							vR = bm.verts[vRidx]
							vco_prev = None
							vco_next = None
							if i > 0 and curve[i-1] in vertsL2R_dirs:
								_, _, _, _, _, vco_prev, _ = vertsL2R_dirs[curve[i-1]]
							if i < len(curve)-1 and curve[i+1] in vertsL2R_dirs:
								_, _, _, _, _, vco_next, _ = vertsL2R_dirs[curve[i+1]]
							for vf in vL.link_faces:
								vf_verts = [ v.index for v in vf.verts ]
								if vRidx not in vf_verts:
									# face not in line
									continue
								for e in vf.edges:
									nv = e.other_vert(vL)
									if (vL not in e.verts) or (nv.index in curve) or (nv.index in handledVrts):
										continue
									vco_this = vL.co
									vco_nv = nv.co
									vco_nv_new = None
									# Finding point on the edge
									if vco_prev is not None:
										pt_closest_dat = mathutils.geometry.intersect_point_line(vco_nv, vco_this, vco_prev)
										pt_closest = pt_closest_dat[0]
										vco_nv_new_test = pt_closest+(vco_nv-pt_closest).normalized()*stripe_len
										if (vco_nv_new is None) or (vco_nv-vco_nv_new_test).length < (vco_nv-vco_nv_new).length:
											vco_nv_new = vco_nv_new_test
									if vco_next is not None:
										pt_closest_dat = mathutils.geometry.intersect_point_line(vco_nv, vco_this, vco_next)
										pt_closest = pt_closest_dat[0]
										vco_nv_new_test = pt_closest+(vco_nv-pt_closest).normalized()*stripe_len
										if (vco_nv_new is None) or (vco_nv-vco_nv_new_test).length < (vco_nv-vco_nv_new).length:
											vco_nv_new = vco_nv_new_test
									if vco_nv_new is not None:
										handledVrts[nv.index] = vco_nv_new
						for nvIdx in handledVrts:
							nv = bm.verts[nvIdx]
							nv.co = handledVrts[nvIdx]
				if ("align(" in step):
					al_def = wla.strExtractOuterBrackets(step)
					if al_def is not None:
						okCnt = okCnt+1
						alSteps.append((al_def, vertsLcurves, (vertsL2R, vertsL2R_dirs, deform_verts) ))
				# if ("fold(wire)" in step) and allowNonReentrables:
				# 	okCnt = okCnt+1
				# 	if foldVertProfileLen is None:
				# 		foldVertProfileLen, _ = wla_attr.vg_get_weightMapByTok(active_obj, config.kWPLSuppVGFoldProfileLen)
				# 	for curve in vertsLcurves:
				# 		if len(curve) < 2:
				# 			continue
				# 		for i, vIdx in enumerate(curve):
				# 			if vIdx not in vertsL2R_dirs:
				# 				continue
				# 			vL = bm.verts[vIdx]
				# 			vLR_dirs = vertsL2R_dirs[vIdx]
				# 			vLDir = vLR_dirs[1]
				# 			vRDir = vLR_dirs[4] #or2
				# 			vUpDir = vLR_dirs[3]
				# 			#print("// curvePTs", vL, vR, vLDir, vertsL2R)
				# 			# is any wire edge linking to fold island?
				# 			linkV = None
				# 			for e in vL.link_edges:
				# 				if len(e.link_faces) == 0:
				# 					linkV = e.other_vert(vL)
				# 					# yep! getting profile verts and aligning to curve
				# 					forwProflV, bckwProflV = wirefold_islandToVertGraph(bm, linkV, vLDir)
				# 					if len(forwProflV) == 0 or len(forwProflV)+len(bckwProflV) < 2: # should be at least current profile + something else to align
				# 						print("// fold(wire): skipped, failed to get profile")
				# 						continue
				# 					# calcing reference custom axis
				# 					# not using any normals!!! unreliable with wire edges
				# 					zMul = 1.0
				# 					vlAxisX = vRDir.normalized()
				# 					vlAxisY = vLDir.normalized()
				# 					vlAxisZ = vUpDir
				# 					if vlAxisY.dot( (linkV.co-vL.co).normalized() ) < 0:
				# 						zMul = -1.0
				# 					vlAxisZ = vlAxisZ*zMul
				# 					vlAxisMat = wla.math_matrix4axis(None, vlAxisX, vlAxisY, vlAxisZ)
				# 					baseProfilVerts = forwProflV[0]
				# 					startFromL = i-len(bckwProflV)
				# 					profilVertsAll = []
				# 					profilVertsAll.extend(list(reversed(bckwProflV)))
				# 					profilVertsAll.extend(forwProflV)
				# 					ji = 0
				# 					for jj in range(startFromL, startFromL+len(profilVertsAll)):
				# 						if curve[jj] not in vertsL2R_dirs:
				# 							ji = ji+1 # skipping fold-island profile, not data in Lcurve...
				# 							continue
				# 						j_vL = bm.verts[curve[jj]]
				# 						j_vLR_dirs = vertsL2R_dirs[curve[jj]]
				# 						j_vlAxisX = j_vLR_dirs[4] #or2
				# 						j_vlAxisY = j_vLR_dirs[1]
				# 						j_vlAxisZ = j_vLR_dirs[3] * zMul
				# 						j_vlAxisMat = wla.math_matrix4axis(None, j_vlAxisX, j_vlAxisY, j_vlAxisZ)
				# 						if j_vlAxisMat is None:
				# 							print("// can`t get local matrix")
				# 							continue
				# 						thisProfilVerts = profilVertsAll[ji]
				# 						#print("// pt", i, jj, vL.index, j_vL.index)
				# 						#print(">", vlAxisX, vlAxisY, vlAxisZ, vL.index, vR.index)
				# 						#print(">", vlAxisMat)
				# 						#print(">", j_vlAxisX, j_vlAxisY, j_vlAxisZ, j_vL.index, j_vR.index)
				# 						#print(">", j_vlAxisMat)
				# 						for jk in range(min(len(thisProfilVerts), len(baseProfilVerts))):
				# 							bp_v = baseProfilVerts[jk]
				# 							tp_v = thisProfilVerts[jk]
				# 							local_co_from = vlAxisMat.inverted() @ (bp_v.co - vL.co)
				# 							fold_len = 1.0
				# 							if tp_v.index in foldVertProfileLen:
				# 								fold_len = fold_len * foldVertProfileLen[tp_v.index]
				# 							# applying scale
				# 							local_co_from = local_co_from*fold_len
				# 							tp_v.co = j_vL.co + ( j_vlAxisMat @ local_co_from)
				# 							# tp_v.select = True
				# 						ji = ji+1
				# if ("fold(" in step) and allowNonReentrables:
				# 	st_def = wla.strExtractOuterBrackets(step)
				# 	okCnt = okCnt+1
				# 	if foldVertOriginMap is None:
				# 		_, _, _, foldVertOriginMap = wla_bm.bm_geodesicDistmap_v05(bm, [vertsL], 5, None, False, True)
				# 	# if foldVertProfileLen is None:
				# 	# 	foldVertProfileLen, _ = wla_attr.vg_get_weightMapByTok(active_obj,config.kWPLSuppVGFoldProfileLen)
				# 	# if foldVertProfileRR is None:
				# 	# 	foldVertProfileRR, _ = wla_attr.vg_get_weightMapByTok(active_obj,config.kWPLSuppVGFoldProfileRr)
				# 	opt_postOffset, opt_postScale, opt_dops = parseVgScriptOffsets(st_def)
				# 	for vIdxStp in foldVertOriginMap.keys():
				# 		vIdx = (foldVertOriginMap[vIdxStp])
				# 		if (vIdxStp in vertsL) or (vIdxStp in vertsR):
				# 			continue
				# 		if (vIdxStp not in vgmap):
				# 			#print("// fold vIdxStp mismatch:", vIdxStp, vgmap, opt_dops)
				# 			continue
				# 		if abs(vgmap[vIdxStp]-opt_dops["w"]) > 0.05:
				# 			continue
				# 		if vIdx in vertsL2R:
				# 			vS = bm.verts[vIdxStp]
				# 			# vS.select = True
				# 			vL = bm.verts[vIdx]
				# 			vR = bm.verts[vertsL2R[vIdx]]
				# 			fold_len = opt_dops["len"]
				# 			fold_rr = opt_postRotate[0]???
				# 			# if vS.index in foldVertProfileLen:
				# 			# 	fold_len = fold_len * foldVertProfileLen[vS.index]
				# 			# if vS.index in foldVertProfileRR:
				# 			# 	fold_rr = fold_rr * foldVertProfileRR[vS.index]
				# 			crossAxis = (vR.co-vL.co).normalized().cross(vR.normal).normalized()
				# 			rotMat = Matrix.Rotation( math.radians(fold_rr), 4, crossAxis)
				# 			rotOff = fold_len*vR.normal
				# 			rotOff.rotate(rotMat)
				# 			#rotOff = opt_postScale[0]*crossAxis
				# 			vS.co = vL.co + rotOff
				if (("cp(" in step) or ("cw(" in step) or ("sw(" in step)) and allowNonReentrables:
					cp_def = wla.strExtractOuterBrackets(step)
					if cp_def is not None:
						okCnt = okCnt+1
						#print("// found cp:", cp_def)
						if ("cw(" in step):
							cp_def = cp_def+",@cw()"
						elif ("sw(" in step):
							cp_def = cp_def+",@sw()"
						elif ("cp(" in step):
							cp_def = cp_def+",@cp()"
						cpSteps.append((cp_def, vertsLcurves, (vertsL2R, vertsL2R_dirs, deform_verts, deform_verts_nrm), vgmap))
				if ("stripe(" in step) and allowNonReentrables: # stripe()
					dup_def = wla.strExtractOuterBrackets(step)
					if dup_def is not None:
						okCnt = okCnt+1
						if bm4curves is None:
							bm4curves = bmesh.new()
							bm4curves.from_mesh(active_mesh)
							bm4curves.verts.ensure_lookup_table()
							bm4curves.edges.ensure_lookup_table()
							bm4curves.faces.ensure_lookup_table()
						skSteps.append((dup_def, vertsLcurves, (vertsL2R, vertsL2R_dirs, deform_verts) ))
				if (("sew(" in step) or ("freestyle(" in step)) and allowNonReentrables:
					ed_def = wla.strExtractOuterBrackets(step)
					if ed_def is not None:
						okCnt = okCnt+1
						edSteps.append((ed_def, vertsLcurves, (vertsL2R, vertsL2R_dirs, deform_verts) ))
				# if ("mt(" in step or "pt(" in step) and (uv_mtpt is not None):
				# 	# uv_mtpt_ob = bm.loops.layers.uv.get(uv_mtpt)
				# 	# if uv_mtpt_ob is None:
				# 	# 	print("// mt: can`t create uv-map, skipping", step, uv_mtpt)
				# 	# 	continue
				# 	okCnt = okCnt+1
				# 	st_def = wla.strExtractOuterBrackets(step).lower()
				# 	opt_postOffset, opt_postScale, opt_dops = parseVgScriptOffsets(st_def)
				# 	stepVals = wla.strToTokens(st_def, False)
				# 	cpSrc_mesh = None
				# 	cpSrc_real = wla.find_child_by_name(active_obj, stepVals[0], True)
				# 	if cpSrc_real is None:
				# 		print("- mt/pt step skipped: no source:", stepVals[0])
				# 		continue
				# 	uv_mtpt_cnt_this = max(opt_dops["dd"], opt_dops["cnt"])
				# 	uv_mtpt_deep = max(0.003, max(uv_mtpt_deep, opt_dops["deep"]))
				# 	uv_mtpt_cnt = max(uv_mtpt_cnt, uv_mtpt_cnt_this)
				# 	cpSrc_real.hide_render = False # SHOULD be rendered
				# 	# Patterns AMUST properties: Visible, in global orientation always
				# 	# must be set BEFORE getting location/dims/etc
				# 	# setting up GLOBAL orientation
				# 	cpAmustConstr = config.kWPLSuppVGScriptToken+": ensure_global_"
				# 	#if wla.isTokenInStr(config.kWPLObjFrameWrapperF0 wla.object_full_name(cpSrc_real)) == False:
				# 	cc = None
				# 	if cpSrc_real.constraints.get(cpAmustConstr+"s") is None:
				# 		cc = cpSrc_real.constraints.new('LIMIT_SCALE')
				# 		cc.name = cpAmustConstr+"s"
				# 		cc.use_min_x = True
				# 		cc.use_max_x = True
				# 		cc.min_x = 1.0
				# 		cc.max_x = 1.0
				# 		cc.use_min_y = True
				# 		cc.use_max_y = True
				# 		cc.min_y = 1.0
				# 		cc.max_y = 1.0
				# 		cc.use_min_z = True
				# 		cc.use_max_z = True
				# 		cc.min_z = 1.0
				# 		cc.max_z = 1.0
				# 		#cc.target = wla.object_by_name(config.kWPLSystemMainReestrObj)
				# 	if cpSrc_real.constraints.get(cpAmustConstr+"r") is None:
				# 		cc = cpSrc_real.constraints.new('LIMIT_ROTATION')
				# 		cc.name = cpAmustConstr+"r"
				# 		cc.use_limit_x = True
				# 		cc.min_x = 0
				# 		cc.max_x = 0
				# 		cc.use_limit_y = True
				# 		cc.min_y = 0
				# 		cc.max_y = 0
				# 		cc.use_limit_z = True
				# 		cc.min_z = 0
				# 		cc.max_z = 0
				# 		#cc.target = wla.object_by_name(config.kWPLSystemMainReestrObj)
				# 	if cc is not None:
				# 		wla_do.sys_update_view(True, False)
				# 	cpSrc_loc = cpSrc_real.matrix_world.to_translation() # global coords
				# 	cpScr_bbox, _ = wla.object_bounds_recursive(cpSrc_real, None)
				# 	#cpSrc_dims = [cpSrc_real.dimensions[0], cpSrc_real.dimensions[1], cpSrc_real.dimensions[2]]
				# 	# dimensions: only positive side. Ignoring positions<0!!!
				# 	cpSrc_dims = [ max([p[0] for p in cpScr_bbox])-cpSrc_loc[0], max([p[1] for p in cpScr_bbox])-cpSrc_loc[1], max([p[2] for p in cpScr_bbox])-cpSrc_loc[2]]
				# 	print("// mt/pt: using pattern", cpSrc_real.name, "pos:", cpSrc_loc, "dims:", cpSrc_dims,"layers:",uv_mtpt_cnt_this,"/",uv_mtpt_deep, opt_dops["dw"], opt_dops["dh"])
				# 	# mt-material need: Solidify layers count, Pattern Location, Pattern bounds, UV Shift, UV Scale
				# 	# saving into custom prop with prefix for mt-osl material autosetup
				# 	uv_mtpt_dataCnt = int(uv_mtpt_dataCnt+1)
				# 	srcFaces = []
				# 	for f in bm.faces:
				# 		isVerticesInIsl = any([v.index in vertsStepAll for v in f.verts])
				# 		# isVerticesInIsl = True
				# 		# for v in f.verts:
				# 		# 	if v.index not in vertsStepAll:
				# 		# 		isVerticesInIsl = False
				# 		# 		break
				# 		if isVerticesInIsl:
				# 			srcFaces.append(f.index)
				# 			uv_mtpt_dataPolys[f.index][0] = uv_mtpt_dataCnt # never zero on baked faces
				# 	active_obj["#osl_mt_deep"+str(uv_mtpt_dataCnt)] = (uv_mtpt_cnt, max(1.0, opt_dops["dw"]), max(1.0, opt_dops["dh"]))
				# 	active_obj["#osl_mt_loc"+str(uv_mtpt_dataCnt)] = (cpSrc_loc[0], cpSrc_loc[1], cpSrc_loc[2])
				# 	active_obj["#osl_mt_dim"+str(uv_mtpt_dataCnt)] = list(cpSrc_dims)
				# 	active_obj["#osl_mt_ouov"+str(uv_mtpt_dataCnt)] = (opt_dops["ou"],opt_dops["ov"],0.0)
				# 	active_obj["#osl_mt_susv"+str(uv_mtpt_dataCnt)] = (opt_dops["su"],opt_dops["sv"],0.0)
				# if ("uvband(" in step) and (uv_stripes is not None):
				# 	# uv_layer_ob = bm.loops.layers.uv.get(uv_stripes)
				# 	# if uv_layer_ob is None:
				# 	# 	print("// stripe: can`t create uv-map, skipping", step, uv_stripes)
				# 	# 	continue
				# 	okCnt = okCnt+1
				# 	st_def = wla.strExtractOuterBrackets(step).lower()
				# 	st_def = st_def.replace("-","")
				# 	opt_postOffset, opt_postScale, opt_dops = parseVgScriptOffsets(st_def)
				# 	stripe_len = float(max(kWPLDefStripe_width, max(max(max(opt_postOffset[0],opt_postOffset[1]),opt_postOffset[2]), opt_dops["len"]) ))
				# 	ssvertMapU = {}
				# 	ssvertMapV = {}
				# 	ssvertMapThis = ssvertMapU
				# 	if (",v" in st_def) or ("v," in st_def) or (st_def == 'v'):
				# 		# step no spaces
				# 		ssvertMapThis = ssvertMapV
				# 	ifLeftOk = False
				# 	ifRightOk = False
				# 	if ("ronly" in st_def):
				# 		ifRightOk = True
				# 	if ("lonly" in st_def):
				# 		ifLeftOk = True
				# 	if ifLeftOk == False and ifRightOk == False:
				# 		ifLeftOk = True
				# 		ifRightOk = True
				# 	# calcing EACH CURVE SEPARATELY
				# 	# or problems with mesh-over-mesh (cloth layers!!)
				# 	for curve in vertsLcurves:
				# 		# extended set of vertices
				# 		vertDistMap, _, ssvertLeftList, vertOriginMap = wla_bm.bm_geodesicDistmap_v05(bm, [curve], 3, None, True, True)
				# 		#print("// ssvertLeftList", ssvertLeftList)
				# 		ssvertAllExtended = vertDistMap.keys()
				# 		# recalc for real distances: good for bad edgenet, but rounds corners and may produce bad results too...
				# 		#vertDistMap = wla_bm.bm_regularDistmap_v01(bm, curve, ssvertAllExtended, None, deform_verts)
				# 		for vIdx in ssvertAllExtended:
				# 			if vIdx in curve:
				# 				ssvertMapThis[vIdx] = 1.0
				# 				continue
				# 			if vIdx in vertDistMap:
				# 				lenScale = 1.0
				# 				# double-len on boundary lines
				# 				if vIdx in vertOriginMap:
				# 					vIdxOrig = (vertOriginMap[vIdx])
				# 					vOrig = bm.verts[vIdxOrig]
				# 					for e in vOrig.link_edges:
				# 						if e.other_vert(vOrig).index in curve and e.is_boundary:
				# 							lenScale = 0.5
				# 							break
				# 				# even values<0 should be properly saved - for perfect interpolations
				# 				ssvertMapThis[vIdx] = ( (stripe_len-vertDistMap[vIdx])*lenScale )/stripe_len
				# 		#print("// ssvertMapThis", ssvertMapThis)
				# 		for face in bm.faces:
				# 			isValidFace = True
				# 			if ifLeftOk == False:
				# 				# checking no verts in left size
				# 				for v in face.verts:
				# 					if v.index in curve:
				# 						continue
				# 					if v.index in ssvertLeftList:
				# 						isValidFace = False
				# 						break
				# 			if ifRightOk == False:
				# 				# checking no verts in left size
				# 				for v in face.verts:
				# 					if v.index in curve:
				# 						continue
				# 					if (v.index not in ssvertLeftList):
				# 						isValidFace = False
				# 						break
				# 			if isValidFace == False:
				# 				continue
				# 			for loop in face.loops:
				# 				vert = loop.vert
				# 				if (vert.index in ssvertMapThis):
				# 					#uvVal = [loop[uv_layer_ob].uv[0], loop[uv_layer_ob].uv[1]]
				# 					uvVal = uv_stripes_dataVerts[vert.index]
				# 					if ssvertMapThis == ssvertMapU:
				# 						uvVal[0] = max(uvVal[0], ssvertMapU[vert.index])
				# 					if ssvertMapThis == ssvertMapV:
				# 						uvVal[1] = max(uvVal[1], ssvertMapV[vert.index])
				# 					#print("// uvVal", uvVal)
	bm.normal_update()
	# prepping Bvh, etc
	substepExtras = {}
	substepExtras["copiedFacesVC"] = None
	srcBVH = BVHTree.FromBMesh(bm, epsilon = 0)
	substepExtras["srcBVH_obj"] = active_obj
	substepExtras["srcBVH"] = srcBVH
	substepExtras["srcL2R"] = None
	def sk_co_shift(v_coX, v_idxL, dops):
		if dops is None:
			return v_coX
		if (v_idxL is not None):
			# using vRDir to allow stay over mesh in corners
			offs = dops["postOffset"]
			_, vLDir, vRDir, vUpDir, vRDirOrtho, _, _ = vertsL2R_dirs[v_idxL]
			v_coX = v_coX + vLDir*(offs[0])
			v_coX = v_coX + vRDirOrtho*(offs[1])
			v_coX = v_coX + vUpDir*(offs[2])
		poc = dops["oc"]
		if abs(poc) > 0.0001:
			v_coX = srcbvh_offsetPtToCam(v_coX, poc, active_obj, substepExtras)
			# if camera_gOrtho:
			# 	camOffset = camera_lDir
			# else:
			# 	camOffset = (camera_lCo - v_coX).normalized()
			# v_coX = v_coX + camOffset*poc
		return v_coX
	bmesh.update_edit_mesh(active_mesh)
	vgs_obj_skin = None
	vgs_obj_skin_prev = None
	vgs_obj_edgcurve = None
	vgs_obj_edgcurve_prev = None
	wla_do.select_and_change_mode(active_obj, 'OBJECT')
	bm = None
	copiedFacesVC = (0, 0, 0)
	if len(cpSteps) + len(skSteps) > 0:
		# preparing duplication mesh
		vgs_obj_skin_mesh = None
		vgs_obj_skin_name = active_obj.name + config.kWPLObjVgsSkinPostfix # + config.kWPLObjProtoToken[0]
		vgs_obj_skin = wla.find_child_by_name(active_obj, vgs_obj_skin_name, True)
		if vgs_obj_skin is not None:
			vgs_obj_skin_prev = vgs_obj_skin
			vgs_obj_skin_prev.name = vgs_obj_skin_prev.name+"_tmp"
			vgs_obj_skin_prev.data.name = vgs_obj_skin_prev.data.name+"_tmp"
			vgs_obj_skin = None
		if vgs_obj_skin is None:
			vgs_obj_skin_mesh = bpy.data.meshes.new(name = active_obj.name + config.kWPLObjVgsSkinPostfix + "_mesh")
			vgs_obj_skin = bpy.data.objects.new(name = vgs_obj_skin_name, object_data=vgs_obj_skin_mesh)
			wla_do.link_object_sideBySide(vgs_obj_skin, active_obj)
			wla_do.set_object_noShadow(vgs_obj_skin, False, False)
			vgs_obj_skin.modifiers.new("Edge Split", 'EDGE_SPLIT')
			print("// cp/dup: added skin object [",vgs_obj_skin.name,"]")
		else:
			print("// cp/dup: using skin object [",vgs_obj_skin.name,"]")
		if vgs_obj_skin is not None:
			wla_do.ensure_visible(vgs_obj_skin, 2) # deal with local_view
			vgs_obj_skin_mesh = vgs_obj_skin.data
			# deleting all
			wla_do.select_and_change_mode(vgs_obj_skin, 'EDIT')
			bpy.ops.mesh.select_all(action='SELECT')
			bpy.ops.mesh.delete(type='VERT')
			wla_do.select_and_change_mode(active_obj, 'OBJECT')
			wla_attr.vc_obj_ensure(vgs_obj_skin, config.kWPLMeshColVC)
	if len(edSteps) > 0:
		vgs_obj_edgcurve_name = active_obj.name + config.kWPLObjVgsSewPostfix
		vgs_obj_edgcurve = wla.object_by_name(vgs_obj_edgcurve_name)
		if vgs_obj_edgcurve is not None:
			vgs_obj_edgcurve_prev = vgs_obj_edgcurve
			vgs_obj_edgcurve_prev.name = vgs_obj_edgcurve_prev.name+"_tmp"
			vgs_obj_edgcurve_prev.data.name = vgs_obj_edgcurve_prev.data.name+"_tmp"
			vgs_obj_edgcurve = None
		vgs_obj_edgcurve = wla_edger.object_addEdgingCurve(vgs_obj_edgcurve_name, "", active_obj, False, None)
	if len(skSteps) > 0 and (vgs_obj_skin is not None) and (bm4curves is not None):
		print("// applying stripe() steps")
		for stStep in skSteps:
			step = stStep[0]
			vertsLcurves = stStep[1]
			vertsL2R = stStep[2][0]
			vertsL2R_dirs = stStep[2][1]
			vertsL2R_deform = stStep[2][2]
			substepExtras["srcL2R"] = stStep[2]
			srcBVH = substepExtras["srcBVH"]
			#isCumulativeConvex = cpStep[3]
			alignCenter = False
			if "center" in step.lower():
				alignCenter = True
			modeRing = False
			if "ring" in step.lower():
				modeRing = True
			modeBisect = True
			if "rigid" in step.lower():
				modeBisect = False
			totalAdded = []
			opt_postOffset, opt_postScale, opt_dops = parseVgScriptOffsets(step)
			opt_postRotate = (opt_dops["rx"], opt_dops["ry"], opt_dops["rz"])
			def addV(bm, co_vec, v_set):
				co_k = wla.coToKey(co_vec)
				if co_k in opt_dops:
					v = opt_dops[co_k]
					if (v_set is not None):
						v_set.append(v)
					return opt_dops[co_k]
				v =  bm.verts.new(co_vec)
				opt_dops[co_k] = v
				if (v_set is not None):
					v_set.append(v)
				return v
			def addF(bm, v_set, faceMatIdx):
				f_verts = []
				for v in v_set:
					if v not in f_verts:
						f_verts.append(v)
				f_cc = bm.faces.new(f_verts)
				f_cc.smooth = True
				if faceMatIdx >= 0:
					f_cc.material_index = faceMatIdx
				bm.faces.index_update()
				bm.verts.ensure_lookup_table()
				bm.edges.ensure_lookup_table()
				bm.faces.ensure_lookup_table()
				return f_cc
			stripe_len = kWPLDefStripe_width
			if opt_dops["len"] > 0:
				stripe_len = opt_dops["len"]
			pattrn = opt_dops["%"]
			stripe_minoff = 0.001
			pattrn_offsets, pattrn_len = wla.remap_pphash(pattrn, stripe_len)
			# print("- pattern stops:", pattrn_offsets, pattrn_len)
			# doCast = False
			# doCastLoopsLim = 10
			for ii, curve in enumerate(vertsLcurves): # stripe()
				print("// ...", step, ":", pattrn, len(curve))
				srcFaces = [] # faces to grab color
				for f in active_obj.data.polygons:
					isAdjFace = False
					for idx in f.vertices:
						if idx in curve:
							isAdjFace = True
							break
					if isAdjFace:
						srcFaces.append(f.index)
				curve_len = {}
				curve_len_co_jj = None
				curve_len_co_dd = 0.0
				for jj, vIdx in enumerate(curve):
					if vIdx in vertsL2R_dirs:
						_, vLDir, vRDir, vUpDir, vRDirOrtho, v_co, _ = vertsL2R_dirs[vIdx]
						if curve_len_co_jj is None:
							curve_len_co_jj = v_co
							curve_len_co_dd = 0.0
							curve_len[vIdx] = curve_len_co_dd
							continue
						jj_len = (v_co - curve_len_co_jj).length
						curve_len_co_jj = v_co
						curve_len[vIdx] = curve_len_co_dd + jj_len
						curve_len_co_dd = curve_len[vIdx]
				# _, srcFacesFar = wla_meshwrap.objectm_vertsStepOut(doCastLoopsLim, active_obj, curve)
				copiedFacesVC, copiedFacesMat = wla_attr.vc_obj_avgcolor(active_obj, config.kWPLMeshColVC, srcFaces)
				substepExtras["copiedFacesVC"] = copiedFacesVC
				substepExtras["copiedFacesMat"] = None
				faceMatIdx = -1
				if copiedFacesMat is not None:
					faceMatIdx = wla_attr.mat_obj_ensuremat(vgs_obj_skin, copiedFacesMat, False)
					substepExtras["copiedFacesMat"] = copiedFacesMat
				for pattrn_imt in pattrn_offsets:
					curv_v1_set = []
					curv_v2_set = []
					pattrn_offset = max(stripe_minoff, pattrn_imt[0])
					pattrn_stripeLen_this = pattrn_imt[1]
					if alignCenter:
						pattrn_offset = pattrn_offset - pattrn_len*0.5
					print("// adding stripe at", pattrn_offset, pattrn_stripeLen_this)
					addedFaces = []
					wla_do.select_and_change_mode(vgs_obj_skin, 'EDIT')
					bm = bmesh.from_edit_mesh(vgs_obj_skin.data)
					bm.verts.ensure_lookup_table()
					bm.edges.ensure_lookup_table()
					bm.faces.ensure_lookup_table()
					if modeBisect:
						_, joinVertsData1_raw, _ = wla_bm.bm_geodesicBisecter(bm4curves, [curve], 100, pattrn_offset, True)
						joinVertsData1 = [ itm[0] for itm in joinVertsData1_raw ]
						_, joinVertsData2_raw, _ = wla_bm.bm_geodesicBisecter(bm4curves, [curve], 100, pattrn_offset+pattrn_stripeLen_this, True)
						joinVertsData2 = [ itm[0] for itm in joinVertsData2_raw ]
						extralen = min(len(joinVertsData1), len(joinVertsData2))*3
						joinVertsData1 = wla.math_vecsSubdNormalize(joinVertsData1, extralen, True)
						joinVertsData2 = wla.math_vecsSubdNormalize(joinVertsData2, extralen, True)
						# joinVertsData2, _ = wla.math_vecsMapClosest(joinVertsData2, None, joinVertsData1)
						joinVertsData1, _ = wla.math_vecsMapClosest(joinVertsData1, None, joinVertsData2)
						joinVertsData_stable_fin = joinVertsData2 # samelen, for index recalc to raw
						joinVertsData_stable_raw = joinVertsData1_raw
						for jj,v1_co in enumerate(joinVertsData1):
							if joinVertsData_stable_fin is not None:
								idx_presubd, _, _ = wla.math_vecsSubdIdxToOrig(jj, joinVertsData_stable_fin, joinVertsData_stable_raw)
								# idx_presubd = int( len(joinVertsData_stable_raw) * float(jj) / float(len(joinVertsData_stable_fin)) )
								data_raw = joinVertsData_stable_raw[ idx_presubd ]
							v1_co_shf = sk_co_shift(v1_co, data_raw[2], opt_dops)
							addV(bm, v1_co_shf, curv_v1_set)
						for jj,v2_co in enumerate(joinVertsData2):
							v2_co_shf = v2_co
							if joinVertsData_stable_fin is not None:
								# idx_presubd = int( len(joinVertsData_stable_raw) * float(jj) / float(len(joinVertsData_stable_fin)) )
								idx_presubd, _, _ = wla.math_vecsSubdIdxToOrig(jj, joinVertsData_stable_fin, joinVertsData_stable_raw)
								data_raw = joinVertsData_stable_raw[ idx_presubd ]
								v2_co_shf = sk_co_shift(v2_co, data_raw[2], opt_dops)
							addV(bm, v2_co_shf, curv_v2_set)
					else:
						for jj, vIdx in enumerate(curve):
							if vIdx in vertsL2R_dirs:
								_, vLDir, vRDir, vUpDir, vRDirOrtho, v_co, _ = vertsL2R_dirs[vIdx]
								vco_prev = None
								vco_next = None
								if (jj > 0) and (curve[jj-1] in vertsL2R_dirs):
									_, _, _, _, _, vco_prev, _ = vertsL2R_dirs[curve[jj-1]]
								if (jj < len(curve)-1) and (curve[jj+1] in vertsL2R_dirs):
									_, _, _, _, _, vco_next, _ = vertsL2R_dirs[curve[jj+1]]
								rdir_offset = pattrn_stripeLen_this
								if pattrn_imt[2] is not None:
									# changing according to CUH
									v_relpos = curve_len[vIdx]/curve_len_co_dd
									v_proffac = wla.remap_curve_hash(pattrn_imt[2], v_relpos)
									rdir_offset = rdir_offset*v_proffac
								v_co_offset = vLDir*opt_postOffset[0] + vRDirOrtho*(opt_postOffset[1]+pattrn_offset)
								v1_co = wla.math_vecOffsetClipped(v_co, v_co_offset, vco_prev, vco_next, 1)
								v2_co = wla.math_vecOffsetClipped(v_co, v_co_offset+vRDir*rdir_offset, vco_prev, vco_next, 1)
								# if doCast:
								# 	v1_co = srcbvh_castClosestNears(srcBVH, v1_co, vUpDir, srcFacesFar)
								# if doCast:
								# 	v2_co = srcbvh_castClosestNears(srcBVH, v2_co, vUpDir, srcFacesFar)
								v1_co = v1_co + vUpDir*(opt_postOffset[2])
								v1_co = sk_co_shift(v1_co, None, opt_dops)
								addV(bm, v1_co, curv_v1_set)
								v2_co = v2_co + vUpDir*(opt_postOffset[2])
								v2_co = sk_co_shift(v2_co, None, opt_dops)
								addV(bm, v2_co, curv_v2_set)
							else:
								print("// stripe() problem: vert:", vIdx,": no right-vert found")
								continue
					for v in curv_v1_set+curv_v2_set:
						v.select = True
					if modeRing == False:
						# creating stripe
						if len(curv_v1_set) >= 3 and len(curv_v2_set) >= 3:
							for jj in range(min(len(curv_v2_set), len(curv_v1_set))-1):
								v1 = curv_v1_set[jj]
								v2 = curv_v1_set[jj+1]
								v3 = curv_v2_set[jj+1]
								v4 = curv_v2_set[jj]
								f_cc = addF(bm, [v1,v2,v3,v4], faceMatIdx)
								addedFaces.append(f_cc.index)
					else:
						# creating rings
						if len(curv_v1_set) >= 3:
							f_cc = addF(bm, curv_v1_set, faceMatIdx)
							addedFaces.append(f_cc.index)
						# if len(curv_v2_set) >= 3:
						#   f_cc = addF(bm, curv_v2_set, faceMatIdx)
						# 	addedFaces.append(f_cc.index)
					bmesh.ops.recalc_face_normals(bm, faces = [bm.faces[fIdx] for fIdx in addedFaces] )
					bmesh.update_edit_mesh(vgs_obj_skin.data)
					wla_do.select_and_change_mode(vgs_obj_skin, 'OBJECT')
					if copiedFacesVC is not None:
						substepExtras["colDecorC"] = copiedFacesVC
						wla_attr.vc_obj_resetvcs(vgs_obj_skin, None, addedFaces)
						wla_attr.vc_obj_ensure(vgs_obj_skin, config.kWPLMeshColVC)
						wla_attr.vc_obj_update(vgs_obj_skin,'FACE', config.kWPLMeshColVC, copiedFacesVC, (1.0,1.0,1.0),1.0, None, None, addedFaces)
					applySubsteps(step, vgs_obj_skin, addedFaces, substepExtras)
					totalAdded.extend(addedFaces)
	if len(cpSteps) > 0 and vgs_obj_skin is not None:
		print("// applying copy-paste steps")
		for cpStep in cpSteps:
			step = cpStep[0]
			vertsLcurves = cpStep[1]
			vertsL2R = cpStep[2][0]
			vertsL2R_dirs = cpStep[2][1]
			vertsL2R_deform = cpStep[2][2]
			#vertsL2R_deform_nrm = cpStep[2][3]
			substepExtras["srcL2R"] = cpStep[2]
			vgmap = cpStep[3]
			stepVals = wla.strToTokens(step, False)
			cpSrc_mesh = None
			cpSrc_real = wla.find_child_by_name(active_obj, stepVals[0], True)
			if cpSrc_real is None:
				all_obj = wla.all_objects_by_name(stepVals[0])
				if len(all_obj) == 1:
					cpSrc_real = all_obj[0]
			if cpSrc_real is None:
				print("// cp step skipped: no exact source:", cpStep[0])
				continue
			cpSrc_real.hide_render = True # Usually kWPLSystemOslAssets, In this case (only) should NOT be rendered
			print("// cp source: [", cpSrc_real.name, "] target: [", active_obj.name, "]","L-curves:", len(vertsLcurves))
			if (len(cpSrc_real.modifiers) > 0) or (cpSrc_real.type != 'MESH'):
				print("// cp source: using evaluated data")
				cpSrc = cpSrc_real.evaluated_get(depsgraph)
				# if (cpSrc_real.type != 'MESH'):
				cpSrc_mesh = cpSrc.to_mesh()
				cpSrc[config.kWPLTempMesh] = cpSrc_mesh
				# else:
				# 	cpSrc_mesh = cpSrc.data
				# 	cpSrc[config.kWPLTempMesh] = cpSrc.data # so later methods know this is temp
				if config.kWPLMeshColVC in cpSrc_real:
					selFacesVC = cpSrc_real[config.kWPLMeshColVC]
					# adding VC - without switching MODES!!!
					# wla_attr.vc_obj_ensure - but manually, no mode changes
					color_map = cpSrc_mesh.vertex_colors.get(config.kWPLMeshColVC)
					if color_map is None:
						color_map = cpSrc_mesh.vertex_colors.new(name = config.kWPLMeshColVC)
					for poly in cpSrc_mesh.polygons:
						ipoly = poly.index
						for idx, lIdx in enumerate(cpSrc_mesh.polygons[ipoly].loop_indices):
							color_map.data[lIdx].color = Vector((selFacesVC[0],selFacesVC[1],selFacesVC[2],1.0))
			else:
				cpSrc = cpSrc_real
			srcVerts = []
			if cpSrc_mesh is None:
				cpSrc_mesh = cpSrc.data
			for f in cpSrc_mesh.polygons:
				if f.hide:
					continue
				for vfIdx in f.vertices:
					if vfIdx not in srcVerts:
						srcVerts.append(vfIdx)
			copiedFaces, _ = wla_bm.bm_copyFaces(cpSrc, kWPLGKey_VGS, srcVerts, Matrix.Identity(4), Vector((0,0,0)))
			if (config.kWPLTempMesh in cpSrc) and (cpSrc[config.kWPLTempMesh] != cpSrc.data):
				# need to remove temp mesh
				del cpSrc[config.kWPLTempMesh]
				cpSrc.to_mesh_clear()
			if copiedFaces < 1:
				print("// cp step skipped: no faces:", cpStep[0])
				continue
			substepExtras["copiedFacesVC"] = None
			substepExtras["copiedFacesMat"] = None
			opt_postOffset, opt_postScale, opt_dops = parseVgScriptOffsets(step)
			opt_postRotate = (opt_dops["rx"], opt_dops["ry"], opt_dops["rz"])
			if ("@cw()" in step):
				# mapping rot/scale/offset from vertex-local to source-local
				opt_postRotate = [opt_postRotate[0], opt_postRotate[2], opt_postRotate[1]]
				opt_postOffset = [opt_postOffset[0], opt_postOffset[2], opt_postOffset[1]]
				opt_postScale = [opt_postScale[0], opt_postScale[2], opt_postScale[1]]
			#print("// step parse", step, opt_postOffset, opt_postRotate, opt_postScale, opt_dops)
			#print("// step vertsL2R_dirs", vertsL2R_dirs)
			print("// cp: copied", copiedFaces, "faces")
			pasteCnt = 0
			#sw_uvcahes = {}
			if "@sw()" in step:
				addedFacesPerCurve = {}
				for ic, curve in enumerate(vertsLcurves):
					addedFaces = wla_bm.bm_pasteFaces(vgs_obj_skin, kWPLGKey_VGS, vgs_obj_skin.matrix_world)
					if addedFaces is None:
						print("// sw: Failed to paste FACES")
						return None
					addedVerts = wla_meshwrap.objectm_vertsOfPolygons(vgs_obj_skin, addedFaces)
					addedVerts = [v.index for v in addedVerts]
					addedFacesPerCurve[ic] = (addedFaces, addedVerts)
				extend_steps = 5
				if int(opt_dops["cnt"]) > 0:
					extend_steps = int(opt_dops["cnt"])
				tempUV = None
				for ic, curve in enumerate(vertsLcurves):
					if len(curve) < 3:
						print("// sw: curve too short, at least 3 verts needed")
						continue
					# calcing local UV
					wla_do.select_and_change_mode(active_obj, 'EDIT')
					bm = bmesh.from_edit_mesh(active_obj.data)
					bm.verts.ensure_lookup_table()
					bm.edges.ensure_lookup_table()
					bm.faces.ensure_lookup_table()
					tempUV, _, zero_vIdx = wla_vgbind.gm_generateUVGrid(bm, curve, {"steps": extend_steps, "verts_co": deform_verts, "verts_nrm": deform_verts_nrm})
					if (zero_vIdx is None or tempUV is None):
						print("// sw(): grid problem, skipping", step)
						continue
					# Moving pasted verts to new positions
					_, zero_vTang, zero_vRdir, zero_vNo, vRDirOrtho, zero_vCo, _ = vertsL2R_dirs[zero_vIdx]
					addedFaces, addedVerts = addedFacesPerCurve[ic]
					startUV = (0.0, 0.0)
					# preparing "virtual verts" for binding
					cage_base_co_g = {}
					cage_base_nrm_g = {}
					cage_now_co_g = {}
					cage_now_nrm_g = {}
					bind_base_co_g = {}
					for vtIdx in tempUV:
						vIdx_co = tempUV[vtIdx][0]
						vIdx_nrm = tempUV[vtIdx][1]
						vIdx_uv = tempUV[vtIdx][2]
						vIdx_uv = ((vIdx_uv[0] - startUV[0] + opt_dops["ou"])/opt_dops["su"], (vIdx_uv[1] - startUV[1] + opt_dops["ov"])/opt_dops["sv"] )
						cage_base_co_g[vtIdx] = Vector(( vIdx_uv[0], 0.0, vIdx_uv[1] ))
						cage_base_nrm_g[vtIdx] = Vector(( 0.0, -1.0, 0.0 ))
						cage_now_co_g[vtIdx] = vIdx_co
						cage_now_nrm_g[vtIdx] = vIdx_nrm
					wla_do.select_and_change_mode(vgs_obj_skin, 'OBJECT')
					bm = None
					# bm = bmesh.from_edit_mesh(vgs_obj_skin.data)
					# bm.verts.ensure_lookup_table()
					# bm.edges.ensure_lookup_table()
					# bm.faces.ensure_lookup_table()
					for vIdx in addedVerts:
						vP = vgs_obj_skin.data.vertices[vIdx]
						# X == U, Z == V, Y = inverted depth
						vco_new = Vector( (vP.co[0]*opt_postScale[0], vP.co[1]*opt_postScale[2], vP.co[2]*opt_postScale[1]) )
						if abs(opt_postRotate[0])+abs(opt_postRotate[1])+abs(opt_postRotate[2])>0.01:
							rot_center = Vector((0,0,0)) # zero_vCo
							vco_diff = vco_new - rot_center
							vco_diff.rotate( mathutils.Quaternion( Vector((1,0,0)), math.radians(opt_postRotate[0])))
							vco_diff.rotate( mathutils.Quaternion( Vector((0,0,1)), math.radians(opt_postRotate[1])))
							vco_diff.rotate( mathutils.Quaternion( Vector((0,1,0)), math.radians(opt_postRotate[2])))
							vco_new = rot_center + vco_diff
						bind_base_co_g[vIdx] = vco_new
						#bind_base_co_g[vIdx] = Vector( (vP.co[0], 0.0, vP.co[2]) )
					# repositioning verts according to UV
					bind_now_co_g_final, _ = wla_vgbind.math_remapSurface(cage_base_co_g, cage_base_nrm_g, cage_now_co_g, cage_now_nrm_g, bind_base_co_g, None)
					if False:# debug
						zero_vIdxNears = list(tempUV.keys())
						print("// vZeroIdxNears", len(zero_vIdxNears))
						for vIdx in zero_vIdxNears: # DBG
							#print("- origin uv", vIdx, cage_base_co_g[vIdx])
							vP = active_mesh.vertices[vIdx]
							vP.co = cage_base_co_g[vIdx] #+Vector((0,-0.21,0))
							vP.select = True
						# wla_do.select_and_change_mode(vgs_obj_skin, 'EDIT')
						# bm = bmesh.from_edit_mesh(vgs_obj_skin.data)
						# bm.verts.ensure_lookup_table()
						# bm.edges.ensure_lookup_table()
						# bm.faces.ensure_lookup_table()
						# for vIdx in bind_base_co_g:
						# 	vP = bm.verts[vIdx]
						# 	vP.co = bind_now_co_g_final[vIdx]
						# for vIdx in zero_vIdxNears:
						# 	bm2v1 = bm.verts.new(cage_now_co_g[vIdx])
						# 	bm2v2 = bm.verts.new(cage_now_co_g[vIdx]+cage_now_nrm_g[vIdx]*0.021)
						# 	bm.edges.new( [bm2v1, bm2v2] )
						# bmesh.update_edit_mesh(vgs_obj_skin.data)
					else:
						for vIdx in bind_now_co_g_final:
							vP = vgs_obj_skin.data.vertices[vIdx] #bm.verts[vIdx]
							if vIdx not in bind_now_co_g_final:
								print("- unknown vert")
								continue
							# new position already takes localY into account
							vco_new = Vector(bind_now_co_g_final[vIdx])
							vco_new = vco_new + opt_postOffset[0]*zero_vTang + opt_postOffset[1]*zero_vRdir + opt_postOffset[2]*zero_vNo
							vP.co = vco_new
					# if len(vertsIdx2del) > 0:
					# 	verts2del = []
					# 	for vIdx in vertsIdx2del:
					# 		verts2del.append(bm.verts[vIdx])
					# 	print("// sw: deleted unused verts:", len(verts2del))
					# 	bmesh.ops.delete(bm, geom=verts2del, context='VERTS')
					# bm.normal_update()
					# bmesh.update_edit_mesh(vgs_obj_skin.data)
					#wla_do.select_and_change_mode(vgs_obj_skin, 'OBJECT')
					applySubsteps(step, vgs_obj_skin, addedFaces, substepExtras)
					pasteCnt = pasteCnt+1
			if "@cw()" in step:
				opt_postRotate_Eul = mathutils.Euler((math.radians(opt_postRotate[0]),math.radians(opt_postRotate[1]),math.radians(opt_postRotate[2])), 'XYZ')
				opt_postRotate_Mat = opt_postRotate_Eul.to_quaternion().to_matrix().to_4x4()
				for curve in vertsLcurves:
					# edge-to-edge soft wrap mode
					# saving curve points for smooth lerping
					curve_cache = {}
					curve_len = 0.0
					#print("// step curve", curve)
					for i, vIdx in enumerate(curve):
						if vIdx in vertsL2R_dirs:
							# vco = active_mesh.vertices[vIdx].co
							_, vLDir, vRDir, vUpDir, vRDirOrtho, vco, _ = vertsL2R_dirs[vIdx]
							curve_len = wla.math_lerpCurveAdd(vco, [vco, vLDir, vRDir, vUpDir, vRDirOrtho], curve_cache)
						else:
							print("// cw: curve vert not in vertsL2R_dirs", vIdx)
					#print("- cw: curve_cache", curve, curve_len, curve_cache)
					if curve_len < 0.0001:
						print("// cp: skipping curve wrap, target curve not marked well.", cpSrc.name)
					else:
						# bm_pasteFaces in GLOBAL coords as is => making local coords of cpSrc
						addedFaces = wla_bm.bm_pasteFaces(vgs_obj_skin, kWPLGKey_VGS, vgs_obj_skin.matrix_world)
						if addedFaces is None:
							print("// cw: Failed to paste FACES")
							return None
						# getting min-max, for cnt-repeat if needed
						addedXMin = 999
						addedXMax = -999
						addedXMinSeam = 999
						addedXMaxSeam = -999
						addedSeamsFound = 0
						addedVerts = wla_meshwrap.objectm_vertsOfPolygons(vgs_obj_skin, addedFaces)
						addedEdges = wla_meshwrap.objectm_edgesOfPolygons(vgs_obj_skin, addedFaces)
						for fev in addedVerts:
							addedXMin = min(addedXMin,fev.co[0])
							addedXMax = max(addedXMax,fev.co[0])
						for fe in addedEdges:
							if fe.use_seam:
								for fevIdx in fe.vertices:
									fev = vgs_obj_skin.data.vertices[fevIdx]
									addedXMinSeam = min(addedXMinSeam,fev.co[0])
									addedXMaxSeam = max(addedXMaxSeam,fev.co[0])
									addedSeamsFound = addedSeamsFound+1
						if addedSeamsFound > 0:
							# using from all verts
							addedXMin = addedXMinSeam
							addedXMax = addedXMaxSeam
						else:
							if addedXMin<0:
								# left to (0,0,0) - backward Starting block
								addedXMin = 0
						# resetting X-offset for easier calculations
						print("// cw addedXMin addedXMax", addedXMin, addedXMax, addedSeamsFound)
						addedVerts = wla_meshwrap.objectm_vertsOfPolygons(vgs_obj_skin, addedFaces)
						addedXMinOfPaste = addedXMin
						for fev in addedVerts:
							fev.co = Vector((fev.co[0] - addedXMinOfPaste, fev.co[1], fev.co[2]))
						addedXMax = addedXMax-addedXMin
						addedXMin = addedXMin-addedXMin
						addedXStepWidth = addedXMax-addedXMin
						if opt_dops["cnt"] > 1.0:
							addedSteps = int(opt_dops["cnt"])
							for cntT in range(1, addedSteps):
								addedFaces2 = wla_bm.bm_pasteFaces(vgs_obj_skin, kWPLGKey_VGS, vgs_obj_skin.matrix_world)
								print("// pasted additional segment", cntT*addedXStepWidth)
								addedVerts2 = wla_meshwrap.objectm_vertsOfPolygons(vgs_obj_skin, addedFaces2)
								for fev2 in addedVerts2:
									fev2.co = Vector((fev2.co[0] - addedXMinOfPaste + cntT*addedXStepWidth, fev2.co[1], fev2.co[2]))
								addedFaces = addedFaces+addedFaces2
								addedXMax = addedXMax+addedXStepWidth
						wla_do.select_and_change_mode(vgs_obj_skin, 'EDIT')
						bm = bmesh.from_edit_mesh(vgs_obj_skin.data)
						bm.verts.ensure_lookup_table()
						bm.edges.ensure_lookup_table()
						bm.faces.ensure_lookup_table()
						addedVerts = []
						for f in bm.faces:
							if f.index not in addedFaces:
								continue
							for fv in f.verts:
								if fv not in addedVerts:
									addedVerts.append(fv)
									v_ll = copy.copy(fv.co)
									fv.co = v_ll
						# bbox calculated, reposition
						for v in addedVerts:
							v_relpos = (v.co[0]-addedXMin)/(addedXMax-addedXMin)
							trg_co = wla.math_lerpCurveGet(v_relpos, 0, curve_cache)
							# front-view axis
							targetNormalX_g = wla.math_lerpCurveGet(v_relpos, 1, curve_cache).normalized()
							targetNormalY_g = wla.math_lerpCurveGet(v_relpos, 3, curve_cache).normalized()
							targetNormalZ_g = wla.math_lerpCurveGet(v_relpos, 4, curve_cache).normalized() # 2 - real rDir, 4 - ortho rDir
							targetOrient_g = wla.math_matrix4axis(None, targetNormalX_g, targetNormalY_g, targetNormalZ_g)
							if targetOrient_g is None:
								print("// cw: failed to get target orientation", v_relpos, targetNormalX_g, targetNormalY_g, targetNormalZ_g)
								continue
							v_ll = Vector( ( 0, -1 * v.co[1] * opt_postScale[1], v.co[2] * opt_postScale[2] ) )
							v_ll = opt_postRotate_Mat @ v_ll
							# Offset more useful AFTER toration - to push curved mesh above target vertex, not source axis
							v_ll = v_ll + Vector( ( opt_postOffset[0], opt_postOffset[1], opt_postOffset[2] ) )
							v.co = trg_co + (targetOrient_g @ v_ll)
						bm.normal_update()
						bmesh.update_edit_mesh(vgs_obj_skin.data)
						wla_do.select_and_change_mode(vgs_obj_skin, 'OBJECT')
						applySubsteps(step, vgs_obj_skin, addedFaces, substepExtras)
						pasteCnt = pasteCnt+1
			if "@cp()" in step:
				cp_mw_nrm_g = vgs_obj_skin.matrix_world.inverted().transposed().to_3x3()
				for curve in vertsLcurves:
					for vIdx in curve:
						vco1 = vertsL2R_deform[vIdx]
						if (vIdx in vertsL2R):
							_, vLDir, vRDir, vUpDir, vRDirOrtho, _, _ = vertsL2R_dirs[vIdx]
							# vLDir = vUpDir.cross(vRDirOrtho) #targetBiTangent_l
							# source expected to be LocalXZ (front view)
							targetNormalX_g = (cp_mw_nrm_g @ vLDir).normalized()
							targetNormalY_g = (cp_mw_nrm_g @ vUpDir).normalized() * (-1)
							targetNormalZ_g = (cp_mw_nrm_g @ vRDirOrtho).normalized()
							if ("localxy" in step):
								targetNormalX_g = (cp_mw_nrm_g @ vLDir).normalized()
								targetNormalY_g = (cp_mw_nrm_g @ vRDirOrtho).normalized()
								targetNormalZ_g = (cp_mw_nrm_g @ vUpDir).normalized()
							targetOrient_g = wla.math_matrix4axis(None, targetNormalX_g, targetNormalY_g, targetNormalZ_g, 0)
						else:
							print("// cp() problem: vert:", vIdx,": no right-vert found")
							continue
						vco1 = sk_co_shift(vco1, vIdx, opt_dops)
						targetCenter_g = matrix_world @ vco1
						addedFaces = wla_bm.bm_pasteFaces(vgs_obj_skin, kWPLGKey_VGS, vgs_obj_skin.matrix_world, targetCenter_g, None, opt_postRotate, opt_postScale, targetOrient_g)
						if addedFaces is None:
							print("// cp: Failed to paste FACES")
							return None
						applySubsteps(step, vgs_obj_skin, addedFaces, substepExtras)
						pasteCnt = pasteCnt+1
			print("// cp: pasted", pasteCnt, "times")
	if len(edSteps) > 0 and vgs_obj_edgcurve is not None:
		curveData = vgs_obj_edgcurve.data
		for cpStep in edSteps: # sew()
			step = cpStep[0]
			vertsLcurves = cpStep[1]
			vertsL2R = cpStep[2][0]
			vertsL2R_dirs = cpStep[2][1]
			vertsL2R_deform = cpStep[2][2]
			substepExtras["srcL2R"] = cpStep[2]
			opt_postOffset, opt_postScale, opt_dops = parseVgScriptOffsets(step)
			minScale = min(opt_postScale[0], min(opt_postScale[1], opt_postScale[2]))
			stripe_len = max(opt_dops["len"], kWPLDefSew_width)
			pattrn = opt_dops["%"]
			pattrn_offsets, pattrn_len = wla.remap_pphash(pattrn, stripe_len)
			for pattrn_imt in pattrn_offsets:
				pattrn_offset = pattrn_imt[0]
				pattrn_stripeLen_this = pattrn_imt[1]
				for curve in vertsLcurves:
					polyline = curveData.splines.new('NURBS')
					polyline.use_endpoint_u = True
					polyline.order_u = 2 # if>2 -> sharp-angles will require edge fixes
					polyline.resolution_u = 10
					polyline.use_smooth = True
					polyline.material_index = 0
					for i, vIdx in enumerate(curve):
						vco1 = vertsL2R_deform[vIdx]
						targetCenter_g = matrix_world @ vco1
						targetOrient_g = None
						targetCenter_g_prev = None
						targetCenter_g_next = None
						if i > 0:
							targetCenter_g_prev = matrix_world @ vertsL2R_deform[ curve[i-1] ]
						if i < len(curve)-1:
							targetCenter_g_next = matrix_world @ vertsL2R_deform[ curve[i+1] ]
						if vIdx in vertsL2R_dirs:
							_, vLDir, vRDir, vUpDir, vRDirOrtho, vco, _ = vertsL2R_dirs[vIdx]
							targetNormalX_g = (matrix_world_norm @ vLDir).normalized()
							targetNormalY_g = (matrix_world_norm @ vRDirOrtho).normalized()
							targetNormalZ_g = (matrix_world_norm @ vUpDir).normalized()
							targetOrient_g = wla.math_matrix4axis(None, targetNormalX_g, targetNormalY_g, targetNormalZ_g)
						if targetOrient_g is None:
							print("// sew() problem: vert:", vIdx,": no right-vert found")
							continue
						targetCenter_g_off = (targetOrient_g @ Vector( (opt_postOffset[0], opt_postOffset[1]+pattrn_offset, opt_postOffset[2])))
						targetCenter_g_fin = wla.math_vecOffsetClipped(targetCenter_g, targetCenter_g_off, targetCenter_g_prev, targetCenter_g_next, 1)
						v_co_l = vgs_obj_edgcurve.matrix_world.inverted() @ targetCenter_g_fin
						v_co_l2, _, _, _ = srcBVH.find_nearest(v_co_l, 999)
						if v_co_l2 is not None:
							v_co_l = v_co_l2 + vUpDir*opt_postOffset[2]
						v_co_l = sk_co_shift(v_co_l, None, opt_dops)
						if len(polyline.points) <= i:
							polyline.points.add(1)
						ptI = len(polyline.points)-1
						#print("- v_co_l", v_co_l, ptI, minScale)
						polyline.points[ptI].co = (v_co_l[0], v_co_l[1], v_co_l[2], 1)
						polyline.points[ptI].radius = pattrn_stripeLen_this*minScale
			applySubsteps(step, vgs_obj_edgcurve, None, substepExtras)
	if len(alSteps) > 0:
		print("- applying align steps")
		movedObjecs = []
		for alStep in alSteps: # align()
			step = alStep[0]
			vertsLcurves = alStep[1]
			vertsL2R = alStep[2][0]
			vertsL2R_dirs = alStep[2][1]
			vertsL2R_deform = alStep[2][2]
			substepExtras["srcL2R"] = alStep[2]
			stepVals = wla.strToTokens(step, False)
			alSrc = wla.find_child_by_name(active_obj, stepVals[0], True)
			if alSrc is None:
				print("- align step skipped: no object:", stepVals[0])
				continue
			if alSrc.name in movedObjecs:
				print("- align step skipped: object already aligned:", stepVals[0])
				continue
			wla_do.ensure_visible(alSrc, 2)
			movedObjecs.append(alSrc.name)
			print("- align object: [", alSrc.name, "] target: [", active_obj.name, "]", vertsLcurves)
			opt_postOffset, opt_postScale, opt_dops = parseVgScriptOffsets(step)
			opt_postRotate = (opt_dops["rx"], opt_dops["ry"], opt_dops["rz"])
			vIdx = vertsLcurves[0][0] # first vert of curve only
			targetOrient_g = None
			if vIdx in vertsL2R_dirs:
				_, vLDir, vRDir, vUpDir, vRDirOrtho, vco1, _ = vertsL2R_dirs[vIdx]
				targetNormalX_g = (matrix_world_norm @ vLDir).normalized()
				targetNormalY_g = (matrix_world_norm @ vRDirOrtho).normalized()
				targetNormalZ_g = (matrix_world_norm @ vUpDir).normalized()
				targetOrient_g = wla.math_matrix4axis(None, targetNormalX_g, targetNormalY_g, targetNormalZ_g)
			if targetOrient_g is None:
				print("// align() problem: vert:", vIdx,": no right-vert found")
				continue
			targetCenter_g = matrix_world @ vco1
			targetCenter_g = targetCenter_g + (targetOrient_g @ Vector(opt_postOffset))
			# also: view lattice orientation calcs: # PY: view-orientation-3axis
			alSrc.rotation_mode = 'QUATERNION'
			_, tog_rot, tog_sca = targetOrient_g.decompose()
			if abs(opt_postRotate[0])+abs(opt_postRotate[1])+abs(opt_postRotate[2])>0.01:
				tog_rot.rotate( mathutils.Quaternion( targetNormalX_g, math.radians(opt_postRotate[0])))
				tog_rot.rotate( mathutils.Quaternion( targetNormalY_g, math.radians(opt_postRotate[1])))
				tog_rot.rotate( mathutils.Quaternion( targetNormalZ_g, math.radians(opt_postRotate[2])))
			tog_sca = alSrc.scale
			if abs((abs(opt_postScale[0])-1.0))+abs(abs(opt_postScale[1])-1.0)+abs(abs(opt_postScale[2])-1.0)>0.01:
				tog_sca = opt_postScale
			alSrc_mat = mathutils.Matrix.LocRotScale(targetCenter_g, tog_rot, tog_sca)
			alSrc.matrix_world = alSrc_mat
	# if uv_mtpt is not None:
	# 	uv_mtpt_ob = wla_attr.uv_obj_ensure(active_obj, uv_mtpt)
	# 	if uv_mtpt_ob is None:
	# 		print("- ERROR: failed to create UV",uv_mtpt)
	# 	active_mesh = active_obj.data
	# 	for poly in active_mesh.polygons:
	# 		ipoly = poly.index
	# 		for idx, lIdx in enumerate(active_mesh.polygons[ipoly].loop_indices):
	# 			uv_mtpt_ob.data[lIdx].uv = Vector(uv_mtpt_dataPolys[poly.index])
	# 	if uv_mtpt_cnt > 0:
	# 		# adding solidify modifiers
	# 		solidfLayers = 0.0
	# 		while solidfLayers<uv_mtpt_cnt:
	# 			solidfLayers = max(1.0, solidfLayers) * 2.0
	# 			mdSolid_name = config.kWPLSuppVGScriptToken+":mt_sol"+str(int(solidfLayers))
	# 			mdSolid = wla.modf_by_type(active_obj, None, mdSolid_name)
	# 			if mdSolid is None:
	# 				mdSolid = active_obj.modifiers.new(name = mdSolid_name, type = 'SOLIDIFY')
	# 			mdSolid.thickness = uv_mtpt_deep
	# 			mdSolid.offset = 1.0
	# 			mdSolid.show_on_cage = True
	# 			mdSolid.show_in_editmode = True
	# 			mdSolid.show_viewport = True
	# 			mdSolid.show_render = True
	# 			uv_mtpt_deep = uv_mtpt_deep*0.5
	# if uv_stripes is not None:
	# 	uv_stripes_ob = wla_attr.uv_obj_ensure(active_obj, uv_stripes)
	# 	if uv_stripes_ob is None:
	# 		print("- ERROR: failed to create UV",uv_stripes_ob)
	# 	active_mesh = active_obj.data
	# 	for poly in active_mesh.polygons:
	# 		ipoly = poly.index
	# 		for idx, lIdx in enumerate(active_mesh.polygons[ipoly].loop_indices):
	# 			ivdx = active_mesh.polygons[ipoly].vertices[idx]
	# 			uv_stripes_ob.data[lIdx].uv = Vector(uv_stripes_dataVerts[ivdx])
	if vgs_obj_skin is not None:
		oha = wla_meshwrap.meshwrap_objCoHash(vgs_obj_skin)
		vgs_obj_skin["vgs_co_hash"] = oha
	if vgs_obj_edgcurve is not None:
		oha = wla_meshwrap.meshwrap_objCoHash(vgs_obj_edgcurve)
		vgs_obj_edgcurve["vgs_co_hash"] = oha
	# removing previous objects/leftovers, if any
	if vgs_obj_skin_prev is not None:
		needDel = True
		if ("vgs_co_hash" in vgs_obj_skin_prev):
			oha_prev0 = wla_meshwrap.meshwrap_objCoHash(vgs_obj_skin_prev)
			oha_prev = vgs_obj_skin_prev["vgs_co_hash"]
			if oha_prev0 != oha_prev:
				needDel = False
				print("- WARNING: previous skin object was modified", vgs_obj_skin_prev)
		if needDel:
			bpy.data.objects.remove(vgs_obj_skin_prev, do_unlink=True)
	if vgs_obj_edgcurve_prev is not None:
		needDel = True
		if ("vgs_co_hash" in vgs_obj_edgcurve_prev):
			oha_prev0 = wla_meshwrap.meshwrap_objCoHash(vgs_obj_edgcurve_prev)
			oha_prev = vgs_obj_edgcurve_prev["vgs_co_hash"]
			if oha_prev0 != oha_prev:
				needDel = False
				print("- WARNING: previous skin object was modified", vgs_obj_edgcurve_prev)
		if needDel:
			bpy.data.objects.remove(vgs_obj_edgcurve_prev, do_unlink=True)
	if bm4curves is not None:
		bm4curves.free()
	wla_do.select_and_change_mode(active_obj, 'OBJECT')
	return okCnt