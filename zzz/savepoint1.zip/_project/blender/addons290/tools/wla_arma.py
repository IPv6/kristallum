import os, sys, time, datetime
import math, copy, string, random
import numpy as np
import bpy, bmesh, mathutils

import bpy.types
from mathutils import Vector, Matrix, Euler, Quaternion
from mathutils.bvhtree import BVHTree
from mathutils.kdtree import KDTree
from bpy_extras import view3d_utils
from bpy.props import *

from . import wla
from . import wla_meshwrap
from . import wla_attr
from . import wla_do
from .. import config

def related_arma(obj):
	if obj is None:
		return None
	if obj.type == 'ARMATURE':
		return obj
	for md in obj.modifiers:
		if md.type == 'ARMATURE':
			return md.object
	# parent chain
	obj_tt = obj
	while obj_tt is not None:
		if obj_tt.data is not None and isinstance(obj_tt.data, bpy.types.Armature):
			return obj_tt
		obj_tt = obj_tt.parent
	# nothing found, searching near hierarchies...
	obj_tt = None
	if obj_tt is None and obj.type == 'EMPTY':
		obj_tt = wla.find_child_by_type(obj,'ARMATURE')
	if obj_tt is None and obj.parent is not None and obj.parent.type == 'EMPTY':
		obj_tt = wla.find_child_by_type(obj.parent,'ARMATURE')
	if obj_tt is None and obj.parent is not None and obj.parent.parent is not None and obj.parent.parent.type == 'EMPTY':
		obj_tt = wla.find_child_by_type(obj.parent.parent,'ARMATURE')
	return obj_tt

def related_armas(objs):
	armas = []
	for obj in objs:
		arma = related_arma(obj)
		if arma not in armas:
			armas.append(arma)
	return armas

def select_by_arma(obj, opt_mb, opt_mlow, opt_unk):
	armatr = related_arma(obj)
	if armatr is None:
		return opt_unk
	rootbnames = [b.name.lower() for b in armatr.data.bones if not b.parent]
	if "bn_spine01" in rootbnames:
		return opt_mlow
	if "root" in rootbnames:
		return opt_mb
	return opt_unk
	
def is_mlow_arma(obj):
	tmp = select_by_arma(obj, False, True, False)
	return tmp

def is_has_arma_vgs(obj):
	if obj is not None:
		vg_layer_ob = obj.vertex_groups.get("head")
		if vg_layer_ob is not None:
			return True
		vg_layer_ob = obj.vertex_groups.get("bn_spine01")
		if vg_layer_ob is not None:
			return True
	return False

def posebone_parentchain(bone):
	# ??? parent_recursive
	chain = []
	tt = bone
	while tt.parent is not None:
		chain.append(tt.parent)
		tt = tt.parent
	return chain

def posebone_localpos(pbone, arma):
	# v1
	# headInBoneSpace = Vector( (0, 0, 0) )
	# tailInBoneSpace = Vector( (0, pbone.length, 0) )
	# phead = pbone.matrix @ headInBoneSpace # pbone.head
	# ptail = pbone.matrix @ tailInBoneSpace # pbone.tail
	# v2
	# headm = arma.convert_space(pose_bone=pbone, matrix=pbone.matrix,  from_space='POSE', to_space='WORLD')
	# tailm = arma.convert_space(pose_bone=pbone, matrix=Matrix.Translation(pbone.y_axis*pbone.length) @ pbone.matrix,  from_space='POSE', to_space='WORLD')
	# phead = arma.matrix_world.inverted() @ headm.to_translation()
	# ptail = arma.matrix_world.inverted() @ tailm.to_translation()
	# v3
	headm = arma.convert_space(pose_bone=pbone, matrix=pbone.matrix, from_space='POSE', to_space='WORLD')
	phead = arma.matrix_world.inverted() @ headm.to_translation()
	ptail = phead + (pbone.tail-pbone.head)
	result = [phead, ptail]
	# ??? bone_h = pbone.matrix @ Vector((0,0,0))
	# ??? bone_t = pbone.matrix @ Vector((0,pbone.length,0))
	return result

def find_refarm_object(extra_ref_toks):
	selObjs = wla.selected_objects(wla_meshwrap.kWPLMESHWRAP_TYPES, False)
	if len(selObjs) == 0:
		print("- error: nothing selected")
		return None, None
	fromObj = None
	for obj in selObjs:
		fromObjX = None
		md_arm = wla.modf_by_type(obj,'ARMATURE')
		if (md_arm is not None) and (md_arm.show_viewport == True or md_arm.show_render == True):
			#print("- object with armature", obj.name)
			fromObjX = obj
		else:
			finArmaCustomProp = config.kWPLSystemFinPrefix + "ARMATURE"
			if finArmaCustomProp in obj:
				fromObjX = obj
		if (extra_ref_toks is not None) and len(extra_ref_toks)>0 and wla.isTokenInStr(extra_ref_toks, obj.name):
			#print("- object with token", obj.name)
			fromObjX = obj
		if fromObjX is not None:
			if (fromObj is not None) and (fromObj.name != fromObjX.name):
				print("- error: too many cages", fromObj, fromObjX)
				return None, None
			fromObj = fromObjX
	# if fromObj is None:
	# 	# looking for saved cage (on BIND)
	# 	for obj in selObjs:
	# 		if kWPL_MBindCageNameKey in obj:
	# 			fromObj = wla.object_by_name(obj[kWPL_MBindCageNameKey])
	# 		if fromObj is not None:
	# 			break
	if fromObj is None:
		print("- error: cage not found")
		return None, None
	sortedObjs = []
	for obj in selObjs:
		if obj == fromObj:
			continue
		sortedObjs.append(obj)
	print("- cage object:", fromObj.name)
	return fromObj, sortedObjs

def is_posebone_hidden(arma, pbone):
	ebone = pbone.bone
	# bone on these layers
	layers = [i for i, l in enumerate(ebone.layers) if l]
	return ebone.hide or not any(arma.data.layers[i] for i in layers)

def arm_bonenames_tok(arma, token):
	bn_names = []
	if arma.mode == 'EDIT' or token == "<edit_sel>":
		boneNames = arma.data.edit_bones.keys()
		for boneName in boneNames:
			bone = arma.data.edit_bones[boneName]
			if (token == "*") or (token == "<sel>" and bone.select) or (token == "<edit_sel>" and bone.select) or (wla.isTokenInStr(token, boneName)):
				bn_names.append(boneName)
	else:
		boneNames = arma.data.bones.keys()
		for boneName in boneNames:
			bone = arma.data.bones[boneName]
			if (token == "*") or (token == "<sel>" and bone.select) or (token == "<pose_sel>" and bone.select) or (wla.isTokenInStr(token, boneName)):
				bn_names.append(boneName)
	# print("- arm_bonenames_tok", token, bn_names)
	return bn_names

def move_bn2layer(arma, bn_name, moveToIdx):
	if arma.mode == 'EDIT':
		bn = arma.data.edit_bones[bn_name]
		bn.layers = wla.arrBools(len(bn.layers), False, [moveToIdx])
		return
	bn = arma.data.bones[bn_name]
	bn.layers = wla.arrBools(len(bn.layers), False, [moveToIdx])
	return

def is_bone_driven_paths(obj, bn):
	paths = []
	li = wla_attr.get_driver_list(obj)
	bn_path = obj.pose.bones[bn].path_from_id()
	for path in li:
		if bn_path in path:
			paths.append(path)
			#print("- is_bone_driven", bn_path, "in" , path)
			#break
	return paths

def all_mesh_hiers(sel_all, validTypes = None):
	if validTypes is None:
		validTypes = ['MESH']
	sel_all_cleaned = []
	sel_all = wla.all_objects_hier(sel_all)
	for sel_obj in sel_all:
		if (sel_obj.type not in validTypes):
			continue
		if wla.isTokenInStr(config.kWPLObjCharFaceToken, wla.object_full_name(sel_obj)):
			continue
		sel_all_cleaned.append(sel_obj)
	return sel_all_cleaned