import os, sys, time, datetime
import math, copy, string, random
import numpy as np
import bpy, bmesh, mathutils
import re

import importlib, glob, logging
import subprocess

import bpy.types
from mathutils import Vector, Matrix, Euler, Quaternion
from mathutils.bvhtree import BVHTree
from mathutils.kdtree import KDTree
from bpy_extras import view3d_utils
from bpy.props import *

from .. import config

kWPLHullIncKey = "wpl_helperobjs"

def coalesce(obj, ifNone):
	if obj is None:
		return ifNone
	if isinstance(obj, float) and math.isnan(obj):
		return ifNone
	return obj

def is_edit_mode():
	if ('EDIT' in bpy.context.mode):
		return True
	return False
def is_object_mode():
	if ('OBJECT' in bpy.context.mode):
		return True
	return False
def is_pose_mode():
	if ('POSE' in bpy.context.mode):
		return True
	return False
def is_local_view():
	# related: https://devtalk.blender.org/t/solved-adding-new-objects-from-python-while-in-local-view/4703/9
	if bpy.context.space_data.local_view is not None:
		return True
	return False

def is_object_valid(obj, minokscale = 0.000001):
	if obj is None:
		return False
	scalemat = obj.matrix_world.to_scale()
	if abs(scalemat[0])+abs(scalemat[1])+abs(scalemat[2]) < minokscale:
		return False
	objloc = obj.matrix_world.to_translation()
	if math.isnan(objloc[0]) or math.isnan(objloc[1]) or math.isnan(objloc[2]):
		return False
	return True

def is_object_nonoperable(obj, allows):
	if obj is None:
		return "select_object_first"
	if is_object_valid(obj) == False:
		return "object_not_operable"
	from . import wla_meshwrap
	if (obj.type in wla_meshwrap.kWPLMESHWRAP_TYPES) and object_useCount(obj.data) > 1:
		if (allows is None) or ("obj_multi_user" not in allows):# is multi-user
			return "obj_multi_user: "+obj.name
	if obj.type in ['MESH'] and (obj.data.shape_keys is not None) and len(obj.data.shape_keys.key_blocks) > 0:
		if (allows is None) or ("obj_shapekeys" not in allows):# has shapekeys (modifiers NOT APPLIABLE)
			return "obj_shapekeys: "+obj.name
	if (allows is None) or ("obj_scale_not_applied" not in allows):
		if (abs(obj.scale[0])-1.0)+(abs(obj.scale[1])-1.0)+(abs(obj.scale[2])-1.0) > 0.001:
			return "obj_scale_not_applied: "+obj.name
	return None

def active_object(validTypes = None):
	obj = bpy.context.view_layer.objects.active
	if (obj is not None) and (validTypes is not None):
		if not (obj.type in validTypes):
			return None
		if (obj.type == 'CURVE'):
			isOkCurve = True
			if ('2D' in validTypes) or ('3D' in validTypes):
				if not (obj.data.dimensions in validTypes):
					isOkCurve = False
			if ('POLY' in validTypes) or ('NURBS' in validTypes) or ('BEZIER' in validTypes):
				# validTypes should contain proper types
				for polyline in obj.data.splines:
					if not (polyline.type in validTypes):
						isOkCurve = False
						break
			if isOkCurve == False:
				return None
	return obj

def selected_objects(validTypes = None, returnOnlyNames = False):
	objs = []
	allowHide = True
	if (validTypes is not None) and ('!HIDE' in validTypes):
		allowHide = False
	active_obj = bpy.context.view_layer.objects.active
	sle_obj = list(bpy.context.selected_objects)
	if active_obj not in sle_obj:# Possible with GP
		sle_obj.append(active_obj)
	for obj in sle_obj:
		if allowHide == False and obj.hide_viewport == True:
			# hidden skipped
			continue
		if (obj is not None) and (validTypes is not None):
			if ("!"+obj.name in validTypes):
				# except this object
				continue
			if not (obj.type in validTypes):
				# type not ok
				continue
			if (obj.type == 'CURVE'):
				isOkCurve = True
				if ('2D' in validTypes) or ('3D' in validTypes):
					if not (obj.data.dimensions in validTypes):
						isOkCurve = False
				if ('POLY' in validTypes) or ('NURBS' in validTypes) or ('BEZIER' in validTypes):
					# validTypes should contain proper types
					for polyline in obj.data.splines:
						if not (polyline.type in validTypes):
							isOkCurve = False
							break
				if isOkCurve == False:
					# type not ok
					continue
		if returnOnlyNames:
			objs.append(obj.name)
		else:
			objs.append(obj)
	return objs

def all_objects_hier(sel_all):
	sel_all_hier = set()
	if sel_all is not None:
		for obj in sel_all:
			sel_all_hier.add(obj)
			childs = all_childs_recursive(obj)
			for ch_obj in childs:
				sel_all_hier.add(ch_obj)
	return list(sel_all_hier)

def all_childs_recursive(obj, childlist = None):
	#print("- all_childs_recursive", obj.name)
	if childlist is None:
		childlist = []
	# for ob in bpy.data.objects:
	# 	if object_useCount(obj) == 0:
	# 		continue
	# 	if ob.parent == obj:
	# 		if ob not in childlist:
	# 			#print("- all_childs_recursive >> ", ob.name, len(ob.children))
	# 			childlist.append(ob)
	# 			for child in ob.children:
	# 				if child not in childlist:
	# 					childlist.append(child)
	# 				all_childs_recursive(child, childlist)
	if obj is not None:
		for child in obj.children:
			if child not in childlist:
				childlist.append(child)
			all_childs_recursive(child, childlist)
	return childlist

def all_objects_by_name(okToks, skipToks = None):
	res = []
	for objx in bpy.data.objects:
		if (skipToks is not None) and isTokenInStr(skipToks, objx.name):
			continue
		if object_useCount(objx) == 0:
			continue
		if isTokenInStr(okToks, objx.name):
			res.append(objx)
	return res

def find_child_by_name(obj, childName, andSideBySide = False, skipToks = None):
	if obj is not None:
		# looking childs
		if len(obj.children)>0:
			for objx in obj.children:
				if (skipToks is not None) and isTokenInStr(skipToks, objx.name):
					continue
				if childName in objx.name:
					return objx
		# looking at side-by-side:
		if andSideBySide:
			for objx in bpy.data.objects:
				if objx.parent == obj.parent:
					if (skipToks is not None) and isTokenInStr(skipToks, objx.name):
						continue
					if childName in objx.name:
						return objx
	# looking in all objects
	for objx in bpy.data.objects:
		if (obj is not None) and (obj.name not in objx.name):
			continue
		if (skipToks is not None) and isTokenInStr(skipToks, objx.name):
			continue
		if object_useCount(objx) == 0:
			continue
		if isTokenInStr(childName, objx.name):
			return objx
	return None

def find_child_by_type(obj, childType):
	if obj is None:
		return None
	if obj.type == childType:
		return obj
	# looking childs
	if len(obj.children)>0:
		for ch in obj.children:
			if ch.type == childType:
				return ch
	return None

def sys_collection(subname = None):
	if subname is None or len(subname) == 0:
		subname = config.kWPLSystemSuppColl
	sysColl = bpy.data.collections.get(subname)
	if sysColl is None:
		sysColl = bpy.data.collections.new(subname)
		bpy.context.scene.collection.children.link(sysColl)
	return sysColl

def sys_empty(emptyname):
	sysColl = sys_collection()
	if isTokenInStr(config.kWPLSystemObjMainHelpers,emptyname):
		sysColl = sys_collection(config.kWPLSystemMainColl)
	if isTokenInStr(config.kWPLSystemObjShapes,emptyname):
		sysColl = sys_collection(config.kWPLSystemSuppColl)
	if isTokenInStr(config.kWPLSystemObjSysEHelpers,emptyname):
		sysColl = sys_collection(config.kWPLSystemEdgeColl)
	empty = bpy.data.objects.get(emptyname)
	if empty is None:
		empty = bpy.data.objects.new(emptyname, None)
		empty.empty_display_size = 0.45
		empty.empty_display_type = 'PLAIN_AXES'
		sysColl.objects.link(empty)
	else:
		if sysColl not in empty.users_collection:
			print("- sys_empty: relinking to collection", empty.name, sysColl.name)
			from . import wla_do
			wla_do.unlink_object_from_coll(empty, None)
			sysColl.objects.link(empty)
	return empty

def selected_vertsIdx(active_mesh):
	bpy.ops.object.mode_set(mode='OBJECT')
	selectedVertsIdx = [e.index for e in active_mesh.vertices if e.select]
	return selectedVertsIdx

def selected_edgesIdx(active_mesh):
	bpy.ops.object.mode_set(mode='OBJECT')
	selectedEdgesIdx = [e.index for e in active_mesh.edges if e.select]
	return selectedEdgesIdx

def selected_facesIdx(active_mesh):
	# find selected faces
	bpy.ops.object.mode_set(mode='OBJECT')
	selectedFacesIdx = [f.index for f in active_mesh.polygons if f.select]
	# print("selected faces: ", faces)
	return selectedFacesIdx

def hidden_vertsIdx(active_mesh, hideState):
	bpy.ops.object.mode_set(mode='OBJECT')
	selectedVertsIdx = [e.index for e in active_mesh.vertices if e.hide == hideState]
	return selectedVertsIdx

def modf_by_type(c_object, modType, modName = None):
	# https://docs.blender.org/api/current/bpy.types.Modifier.html#bpy.types.Modifier
	if (c_object is not None) and isinstance(c_object, str):
		c_object = object_by_name(c_object)
	if c_object is None:
		return None
	mdfs = c_object.modifiers
	if c_object.type == 'GPENCIL':
		mdfs = c_object.grease_pencil_modifiers
	for md in mdfs:
		isNameOk = True
		isTypeOk = True
		if modType is not None and md.type != modType:
			isTypeOk = False
		if modName is not None and (modName not in md.name):
			isNameOk = False
		if isNameOk and isTypeOk:
			return md
	return None

def active_context_cursor():
	# scene = bpy.context.scene
	# space = bpy.context.space_data
	# v3ds = (space if space and space.type == 'VIEW_3D' else scene)
	# if v3ds is None:
	# 	return None
	# cursor = v3ds.cursor.location
	cursor = bpy.context.scene.cursor.location.copy()
	return cursor

def active_context_orient(withName = None):
	# scene = bpy.context.scene
	# space = bpy.context.space_data
	# v3ds = (space if space and space.type == 'VIEW_3D' else scene)
	# if v3ds is None or v3ds.current_orientation is None:
	# 	return None
	# cu_matrix = v3ds.current_orientation.matrix.copy()
	custom_ori = None
	if withName is None:
		orient_slot = bpy.context.scene.transform_orientation_slots[0]
		custom_ori = orient_slot.custom_orientation
	else:
		for orient_slot in bpy.context.scene.transform_orientation_slots:
			if orient_slot.custom_orientation is not None:
				if (orient_slot.custom_orientation.name == withName) or (orient_slot.type == withName):
					#print ("orient_slot", orient_slot, orient_slot.type, orient_slot.custom_orientation.name)
					custom_ori = orient_slot.custom_orientation
					break
	return custom_ori

def active_view_region(pt_co_g = None):
	region = bpy.context.region
	region3d = bpy.context.region_data
	# region3d = bpy.context.space_data.region_3d # SAME as bpy.context.region_data -> RegionView3D
	# if region3d is None:
	# 	for area in bpy.context.screen.areas:
	# 		if area.type == 'VIEW_3D':
	# 			region3d = area.spaces.active.region_3d
	# 			break
	# both Orth && Perpective
	# === ver1
	view_vec = Vector((0,0,0))
	co_2d = (region.x+region.width*0.5, region.y+region.height*0.5)
	if pt_co_g is not None:
		co_2d = view3d_utils.location_3d_to_region_2d(region, region3d, pt_co_g)
	# view_vec = view3d_utils.region_2d_to_vector_3d(region, region3d, co_2d) * 0.0001
	region_co = view3d_utils.region_2d_to_location_3d(region, region3d, co_2d, view_vec)
	#region_co = view3d_utils.region_2d_to_origin_3d(region, region3d, co_2d)
	# === ver2
	# https://github.com/bblanimation/assemblme/blob/master/functions/common/blender.py
	# viewport_matrix = region3d.view_matrix.inverted()
	# region_co = viewport_matrix.to_translation()
	return region3d, region_co

def active_camera():
	camera_obj = object_by_name(config.kWPLSystemMainCam)
	if camera_obj is None:
		# self.report({'ERROR'}, "Camera not found: "+config.kWPLSystemMainCam)
		return None, None, None
	camera_gCo = camera_obj.matrix_world.to_translation() #NOT camera_obj.location
	#camera_gDir = camera_obj.matrix_world.to_3x3() @ Vector((0.0, 0.0, 1.0))
	#camera_gDirUp = camera_obj.matrix_world.to_3x3() @ Vector((0.0, 1.0, 0.0))
	camera_gDir = camera_obj.matrix_world.inverted().transposed().to_3x3() @ Vector((0.0, 0.0, 1.0))
	camera_gDirUp = camera_obj.matrix_world.inverted().transposed().to_3x3() @ Vector((0.0, 1.0, 0.0))
	camera_gOrtho = False
	if camera_obj.data.type == 'ORTHO':
		camera_gOrtho = True
	return camera_gCo, camera_gOrtho, camera_gDir, camera_gDirUp

def object_by_name(name):
	if (name is None) or (len(name) == 0):
		return None
	return bpy.data.objects.get(name)

def object_full_name(obj):
	if obj is None:
		return ''
	names = []
	names.append(obj.name.lower())
	rootp = obj.parent
	while (rootp is not None):
		names.append(rootp.name.lower())
		rootp = rootp.parent
	return ",".join(names)

def object_parent_chain(obj):
	if obj is None:
		return []
	pchain = []
	rootp = obj.parent
	while (rootp is not None):
		pchain.append(rootp)
		rootp = rootp.parent
	return pchain

def object_root_data(obj):
	if obj is None:
		return None, None
	rootp = obj
	scenep = obj
	#objtag = object_tagFromName(obj.name)
	if (obj.parent is not None):
		scenep = obj.parent
		while (scenep is not None):
			# if objtag is None:
			# 	objtag = object_tagFromName(scenep.name)
			if isTokenInStr(config.kWPLObjFrameWrapper, scenep.name):
				# root search stops here
				break
			rootp = scenep # last non-scene
			scenep = scenep.parent
	return scenep, rootp

def object_sceneroot(obj):
	_, rootp = object_root_data(obj)
	return rootp

def object_helperId(context):
	if kWPLHullIncKey not in context.scene:
		context.scene[kWPLHullIncKey] = 1
	curId = context.scene[kWPLHullIncKey]
	context.scene[kWPLHullIncKey] = context.scene[kWPLHullIncKey]+1
	return curId

def object_isInCollections(obj, coll_list):
	inColls = 0
	for collname in coll_list:
		coll_objs = sys_collection(collname).objects
		if coll_objs.get(obj.name) is None:
			return False
		inColls = inColls+1
	if len(obj.users_collection) != inColls:
		return False
	return True

def object_useCount(objdata):
	if objdata is None:
		return 0
	#users = bpy.data.user_map(subset=(objdata, ))
	#print("- users:", users, objdata.users)
	cnt = objdata.users
	if objdata.use_fake_user:
		cnt = cnt - 1
	return cnt

debugBBC = None #"pip"
def object_bounds_recursive(obj, bounds_cache):
	if (bounds_cache is not None) and (obj.name in bounds_cache):
		cres = bounds_cache[obj.name]
		return cres[0], cres[1]
	bbc = []
	bbc_ok = False
	if (not is_object_valid(obj)):
		# no bounds, zero-scaled object
		return bbc, bbc_ok
	if not (obj.hide_render and obj.hide_viewport):
		# bound_box is TOTALLY wrong for non-evaluated objects (not visible, etc)
		# curves after finalization in hairs, for example
		if obj.type == 'MESH' or obj.type == 'CURVE' or obj.type == 'FONT' or obj.type == 'GPENCIL':
			bbc_ok = True
			bbc.extend([obj.matrix_world @ Vector(corner) for corner in obj.bound_box])
	if len(obj.children)>0:
		for chi in obj.children:
			if isTokenInStr(config.kWPLSystemOslNoBbox, chi.name):
				# should NOT contribute to parents
				continue
			bbc_c, bbc_c_ok = object_bounds_recursive(chi, bounds_cache)
			if bbc_c_ok:
				bbc_ok = True # if anychild ok
				bbc.extend(bbc_c)
	if len(bbc) == 0:
		# fallback
		# even cameras/lights/empties should have BBox position
		# or they will be skipped
		objloc = obj.matrix_world.to_translation()
		bbc = [objloc]
		if debugBBC is not None and debugBBC in obj.name:
			print("// DBG: bbc-loc", obj.name, objloc )
	if bounds_cache is not None:
		bounds_cache[obj.name] = (bbc, bbc_ok)
		if debugBBC is not None and debugBBC in obj.name:
			bbc_min_pt = [ min(item[0] for item in bbc), min(item[1] for item in bbc), min(item[2] for item in bbc)]
			bbc_max_pt = [ max(item[0] for item in bbc), max(item[1] for item in bbc), max(item[2] for item in bbc)]
			maxX = abs(bbc_max_pt[0]-bbc_min_pt[0])
			maxY = abs(bbc_max_pt[1]-bbc_min_pt[1])
			maxZ = abs(bbc_max_pt[2]-bbc_min_pt[2])
			print("// DBG: bbc", obj.name, (maxX, maxY, maxZ), bbc )
	return bbc, bbc_ok

def objects_sort_by_dist(obj_names, co_g):
	def sortkey4obj(obj):
		if isinstance(obj, str):
			obj = bpy.data.objects.get(obj)
		return (obj.matrix_world.to_translation() - co_g).length
	obj_names = sorted(obj_names, key=lambda k: sortkey4obj(k))
	return obj_names

def coToKey(co_vec):
	key = "x"+str(int(co_vec[0] * config.kWPLCoordPrecision))+"_y"+str(int(co_vec[1] * config.kWPLCoordPrecision))+"_z"+str(int(co_vec[2] * config.kWPLCoordPrecision))
	return key

def uvToKey(uv_vec):
	key = "u"+str(int(uv_vec[0] * config.kWPLUVPrecision))+"_v"+str(int(uv_vec[1] * config.kWPLUVPrecision))
	return key

def idxToKey(co_idx):
	key = "i"+str(int(co_idx * config.kWPLCoordPrecision))
	return key

def remap_F_M_T_linear(curve_fac, mid_fac, F3c): # curve_fac in [0.0,1.0], (0, mid_fac, 1.0) -> F_M_T
	radiusAtStart = F3c[0]
	radiusAtMid = F3c[1]
	radiusAtEnd = F3c[2]
	value = 0.0
	if curve_fac < mid_fac:
		value = radiusAtStart+(radiusAtMid-radiusAtStart)*(float(curve_fac)/max(0.001, mid_fac))
	else:
		value = radiusAtMid+(radiusAtEnd-radiusAtMid)*(float(curve_fac-mid_fac)/max(0.001, 1.0-mid_fac))
	return value

def remap_F_M_T_smooth(curve_fac, mid_fac, pow_fac, F3c): # curve_fac in [0.0,1.0], (0, mid_fac, 1.0) -> F_M_T
	radiusAtStart = F3c[0]
	radiusAtMid = F3c[1]
	radiusAtEnd = F3c[2]
	RadTotal = radiusAtMid
	if curve_fac < mid_fac:
		curve_fac1 = (curve_fac/mid_fac)
		curve_fac1 = min(1.0, curve_fac1 * (2.0 - curve_fac1))
		curve_fac2 = pow(curve_fac1, pow_fac)
		RadTotal = radiusAtStart+(RadTotal-radiusAtStart)*curve_fac2
	else:
		curve_fac1 = 1.0-(curve_fac-mid_fac)/(1.0-mid_fac)
		curve_fac1 = min(1.0, curve_fac1 * (2.0 - curve_fac1))
		curve_fac2 = pow(curve_fac1, pow_fac)
		RadTotal = RadTotal+(radiusAtEnd-RadTotal)*(1.0-curve_fac2)
	return RadTotal

def remap_pphash(pattrn, step_len):
	# -- %-coded pattern format --
	# Example: %AB(1562)AaddD(919)aaZ
	# // - A, B, C... to make stripe line, width vary (A-scaled)
	# // - a, b, c... to make empty space, gap length vary (A-scaled)
	# // - (..) extra data (CUH-profile) for this stripe
	if (pattrn is None) or len(pattrn) == 0:
		pattrn = "A"
	pattrn_offset = 0
	pattrn_offset_next = 0
	pattrn_stops = []
	pattrn_offset_dir = 1.0
	ii = 0
	while ii < len(pattrn):
		patChar = pattrn[ii]
		ii = ii+1
		if patChar >= 'a' and patChar <= 'z':
			# gap
			pattrn_sewScale = (ord(patChar)-ord('a')+1)
			pattrn_offset = pattrn_offset + pattrn_offset_dir*step_len*pattrn_sewScale
			continue
		pattrn_extra = None
		pattrn_offset_next = pattrn_offset
		pattrn_stripeLen_this = step_len
		if patChar < 'A' or patChar > 'Z':
			continue
		pattrn_sewScale = (ord(patChar)-ord('A')+1)
		pattrn_stripeLen_this = pattrn_stripeLen_this*pattrn_sewScale
		pattrn_offset_next = pattrn_offset+pattrn_offset_dir*step_len*pattrn_sewScale
		if (ii < len(pattrn)) and pattrn[ii] == '(':
			idxTo = arrIndexOf(pattrn[ii+1:], ')')
			if idxTo >= 0:
				pattrn_extra = pattrn[(ii+1):(ii+1+idxTo)]
				ii = ii+len(pattrn_extra)
		pattrn_stops.append( (pattrn_offset, pattrn_stripeLen_this, pattrn_extra) )
		pattrn_offset = pattrn_offset_next
	pattrn_len = pattrn_offset
	return pattrn_stops, pattrn_len

def remap_curve_hash(curve_hash, curve_fac): # CUH
	# '15951': CUH string 1->0.0, 9->1.0
	# // linear interpolation by default
	# '-...': result = -1 * result // same as GN-cuh
	# '...0': cuh string mirror-Xed // same as GN-cuh
	# '!...': curve_fac inverted (start<->end) // PY only
	# '%...': pp-pattern, result = 0 || 1 // PY only
	# '... * float': result = result*float // PY only
	if(curve_hash is not None) and ((' ' in curve_hash) or (';' in curve_hash)):
		curve_hash = curve_hash.replace(" ","")
		curve_hash = curve_hash.replace(";","")
	if (curve_hash is None) or len(curve_hash) == 0:
		return 1.0
	result_scale = 1.0
	if '*' in curve_hash:
		mul_pair = curve_hash.split("*")
		curve_hash = mul_pair[0]
		result_scale = safeFloat(mul_pair[1])
	if len(curve_hash) >= 1 and curve_hash[0] == '%':
		pattrn_stops, pattrn_len = remap_pphash(curve_hash[1:], 1)
		for pattrn_imt in pattrn_stops:
			stop_pos1 = pattrn_imt[0]/pattrn_len
			stop_pos2 = (pattrn_imt[0]+pattrn_imt[1])/pattrn_len
			if (curve_fac >= stop_pos1) and (curve_fac < stop_pos2):
				return result_scale*1.0
		return 0.0
	def facAtPos(idx):
		ff = ord(curve_hash[idx])-ord('0')
		ff = math_remapRanged(ff, 1.0, 9.0, 0.0, 1.0)
		ff = min(max(ff,0.0),1.0)
		return ff
	out_fac = 1.0
	isInv = False
	if len(curve_hash) >= 2 and curve_hash[-1] == '0':
		ll = len(curve_hash)
		curve_hash = curve_hash[0:-1]+  "".join(reversed(curve_hash[0:-2]))
	if len(curve_hash) >= 1 and curve_hash[0] == '-':
		curve_hash = curve_hash[1:]
		result_scale = -1.0*result_scale
	if len(curve_hash) >= 1 and curve_hash[0] == '!':
		curve_hash = curve_hash[1:]
		isInv = True
	if len(curve_hash) == 1:
		curve_fac = 0.0
	curve_fac = min(max(curve_fac,0.0),1.0)
	if isInv:
		curve_fac = 1.0-curve_fac
	if len(curve_hash) > 1:
		hash_max_idx = (len(curve_hash)-1)
		pt1 = math.floor( hash_max_idx * curve_fac)
		pt2 = pt1 + 1
		if pt2 >= len(curve_hash):
			pt2 = pt1
			pt1 = pt1 - 1
		#print("- pt1 pt2", curve_fac, pt1, pt2)
		pt_mix = (curve_fac - pt1/hash_max_idx)/(pt2/hash_max_idx - pt1/hash_max_idx)
		out_fac = math_lerp1D(pt_mix, facAtPos(pt1), facAtPos(pt2))
	else:
		out_fac = facAtPos(math.floor(curve_fac))
	# print("- remap_curve_hash", curve_hash, curve_fac, out_fac)
	return out_fac * result_scale

# def math_matrixIsSame(mat1, mat2):
# 	matlist1 = [inner for outer in mat1 for inner in outer]
# 	matlist2 = [inner for outer in mat2 for inner in outer]
# 	isSame = np.allclose(matlist1,matlist2)
# 	return isSame

def math_matrix4axis(v_origin, a, b, c, renormAll = 1): # customaxis generation, custommatrix
	#https://blender.stackexchange.com/questions/30808/how-do-i-construct-a-transformation-matrix-from-3-vertices
	#def make_matrix(v_origin, v2, v3):
	#a = v2-v_origin
	#b = v3-v_origin
	if (b is None) and (c is not None):
		b = a.cross(c)
	if (c is None) and (b is not None):
		c = a.cross(b)
	if v_origin is None:
		v_origin = Vector ( (0,0,0))
	if a.magnitude == 0 or b.magnitude == 0 or c.magnitude == 0:
		#raise BaseException("A B C are colinear")
		return None
	if renormAll == -1:
		c = a.cross(b)
		a2 = a.normalized()
		b2 = b.normalized()
		c2 = c.normalized()
	elif renormAll == 1:
		a2 = a.normalized()
		b2 = b.normalized()
		c2 = c.normalized()
	else:
		a2 = a
		b2 = b
		c2 = c
	#print("- math_matrix4axis", a2, b2, c2)
	m = Matrix([a2, b2, c2]).transposed()
	s = a.magnitude
	m = Matrix.Translation(v_origin) @ Matrix.Scale(s,4) @ m.to_4x4()
	return m

def math_matrixReplace(mw, newPos, newRotMat, newScale):
	# Also: edg_curve.matrix_world = Matrix.LocRotScale(refObj.matrix_world.to_translation(), Matrix.Identity(3), Vector((1,1,1)))
	aLocV, aRotQ, aScaV = mw.decompose()
	aRotM = aRotQ.to_matrix().to_4x4()
	if newPos is not None:
		aLocV = newPos
	if newRotMat is not None:
		aRotM = newRotMat
	if newScale is not None:
		aScaV = newScale
	aLocM = mathutils.Matrix.Translation(aLocV)
	aScaM = Matrix().Scale(aScaV[0], 4, Vector((1,0,0)))
	aScaM = aScaM @ Matrix().Scale(aScaV[1], 4, Vector((0,1,0)))
	aScaM = aScaM @ Matrix().Scale(aScaV[2], 4, Vector((0,0,1)))
	mw_new = aLocM @ aRotM @ aScaM
	return mw_new

def math_vecIsLeft(testDir, localX, localZ):
	# also: mathutils.Vector angle_signed
	localY = localX.normalized().cross(localZ.normalized())
	dirDot = testDir.normalized().dot(localY)
	#print("- leftTest", dirDot)
	if dirDot > 0.0:
		return 1.0
	if dirDot < 0.0:
		return -1.0
	return 0.0

def math_vecPack2(nrm_g, cameraSpace):
	# unpack in detVecStuff
	if (nrm_g is None) or (nrm_g.length == 0):
		return (-999,-999)
	nrmX = nrm_g[0]
	nrmY = nrm_g[1]
	if cameraSpace:
		camera_obj = object_by_name(config.kWPLSystemMainCam)
		#nrm_l = (camera_obj.matrix_world.inverted()).inverted().transposed().to_3x3() @ nrm
		nrm_l = camera_obj.matrix_world.transposed().to_3x3() @ nrm_g # .inverted()).inverted()
		nrmX = 32.0+nrm_l[0]
		nrmY = 32.0+nrm_l[1]
	else:
		if nrm_g[2]>=0:
			nrmX = 22.0+nrmX
			nrmY = 22.0+nrmY
		else:
			nrmX = 12.0+nrmX
			nrmY = 12.0+nrmY
	nrmPacked = (nrmX, nrmY) # only z-positive semisphere
	return nrmPacked

def math_clamp(num, min_value, max_value):
	# https://docs.blender.org/api/current/bl_math.html
	return max(min(num, max_value), min_value)

def math_lerp1D(x, range_min, range_max): # float lerp
	# https://docs.blender.org/api/current/bl_math.html
	return range_min+(range_max-range_min)*x

def math_remapRanged( x, inMin, inMax, outMin, outMax ):
	#range check
	if inMin == inMax:
		#print "Warning: Zero input range"
		return None
	if outMin == outMax:
		#print "Warning: Zero output range"
		return None
	#check reversed input range
	reverseInput = False
	oldMin = min( inMin, inMax )
	oldMax = max( inMin, inMax )
	if not oldMin == inMin:
		reverseInput = True
	#check reversed output range
	reverseOutput = False   
	newMin = min( outMin, outMax )
	newMax = max( outMin, outMax )
	if not newMin == outMin :
		reverseOutput = True
	portion = (x-oldMin)*(newMax-newMin)/(oldMax-oldMin)
	if reverseInput:
		portion = (oldMax-x)*(newMax-newMin)/(oldMax-oldMin)
	result = portion + newMin
	if reverseOutput:
		result = newMax - portion
	return result

def math_clipFraction(val, prec):
	val = math.copysign( math.floor( abs(val) * prec ) / prec, val )
	return val

def math_vecSwizzlePick(vec, pickType):
	if pickType is None:
		pickType = "XZ"
	pickType = pickType.lower()
	res = []
	for cc in pickType:
		if (cc == 'x'):
			res.append(vec[0])
		elif cc == 'y':
			res.append(vec[1])
		elif cc == 'z':
			res.append(vec[2])
		elif cc == 'w':
			res.append(vec[3])
		else:
			res.append(0.0)
	return res

def math_lerpCurveAdd(pt_co, pt_vals, curve_cache):
	if "len" not in curve_cache:
		curve_cache["len"] = 0
		curve_cache["pt_x"] = []
		curve_cache["pt_last"] = None
	len_trg = curve_cache["len"]
	t_xp = curve_cache["pt_x"]
	pt_last = curve_cache["pt_last"]
	if pt_last is not None:
		len_trg = len_trg+(pt_last-pt_co).length
	t_xp.append(len_trg)
	pt_last = pt_co
	curve_cache["pt_last"] = pt_last
	curve_cache["len"] = len_trg
	# adding vals at current position
	for i, vec in enumerate(pt_vals):
		ik = ("val"+str(i))
		if ik+"px" not in curve_cache:
			curve_cache[ik+"px"] = []
			curve_cache[ik+"py"] = []
			curve_cache[ik+"pz"] = []
			curve_cache[ik+"co"] = []
		curve_cache[ik+"px"].append(vec[0])
		curve_cache[ik+"py"].append(vec[1])
		curve_cache[ik+"pz"].append(vec[2])
		curve_cache[ik+"co"].append(copy.copy(vec))
	return len_trg

def math_lerpCurveGet(t_pos_rel, val_idx, curve_cache):
	if t_pos_rel < 0:
		# extending backwrads symmetricall
		pt_co0 = math_lerpCurveGet(0.0, val_idx, curve_cache)
		pt_co1 = math_lerpCurveGet(-1 * t_pos_rel, val_idx, curve_cache)
		return pt_co0 - (pt_co1-pt_co0)
	len_trg = curve_cache["len"]
	t_xp = curve_cache["pt_x"]
	ik = ("val"+str(val_idx))
	t_yp_px = curve_cache[ik+"px"]
	t_yp_py = curve_cache[ik+"py"]
	t_yp_pz = curve_cache[ik+"pz"]
	pt_co = Vector((np.interp(t_pos_rel*len_trg, t_xp, t_yp_px), np.interp(t_pos_rel*len_trg, t_xp, t_yp_py), np.interp(t_pos_rel*len_trg, t_xp, t_yp_pz)))
	return pt_co

def math_vecsMapClosest(vects, vectsMeta, vectsRef):
	extralen = min(len(vectsRef), len(vects))
	vects_out = []
	vectsMeta_out = None
	if vectsMeta is not None:
		vectsMeta_out = []
	# used_jjs = []
	for ii in range(extralen):
		co_ref = vectsRef[ii]
		mindist = 9999
		exhpos = -1
		if exhpos < 0:
			for jj in range(len(vects)):
				dir = (vects[jj] - co_ref)
				dist = dir.length
				# if ii>0 and ii<len(vects)-1:
				# 	dir2 = (co_ref-vectsRef[ii-1]).normalized()
				# 	dir3 = (vectsRef[ii+1]-co_ref).normalized()
				# 	dist_dd2 = dir.normalized().dot(dir2)
				# 	dist_dd3 = dir.normalized().dot(dir3)
				# 	dist = dist * (1.0 + abs(dist_dd2)) * (1.0 + abs(dist_dd3))
				# if jj in used_jjs:
				# 	# dist = dist*1.01
				# 	continue
				if dist < mindist:
					mindist = dist
					exhpos = jj
		# if exhpos < 0: # checing all
		# 	for jj in range(len(vects)):
		# 		dist = (vects[jj] - co_ref).length
		# 		if dist<mindist:
		# 			mindist = dist
		# 			exhpos = jj
		if exhpos >= 0:
			# used_jjs.append(exhpos)
			vects_out.append(vects[exhpos])
			if vectsMeta_out is not None:
				vectsMeta_out.append(vectsMeta[exhpos])
	return vects_out, vectsMeta_out

def math_vecsSubdNormalize(vects, ensureCount, ensureDistrib):
	if vects is None or len(vects) < 2:
		return vects
	if ensureCount is not None:
		while len(vects) < ensureCount:
			# subdiving lengthest
			max_len = -999
			max_len_idx = -1
			for i in range(0, len(vects)-1):
				v1 = Vector(vects[i])
				v2 = Vector(vects[i+1])
				segLen = (v1-v2).length
				if segLen > max_len:
					max_len = segLen
					max_len_idx = i
			if max_len_idx < 0:
				# not possible WTF
				break
			v1_2 = ( Vector(vects[max_len_idx])+Vector(vects[max_len_idx+1]) )*0.5
			vects.insert(max_len_idx+1, v1_2)
	if ensureDistrib:
		curve_cache = {}
		for v_co in vects:
			math_lerpCurveAdd(v_co, [v_co], curve_cache)
		newlen = len(vects)
		newvects = []
		for j in range(0, newlen):
			posFac = float(j)/float(newlen-1)
			# posFac = math.pow(float(j)/float(newlen-1),2) # DBG
			v_co = math_lerpCurveGet(posFac, 0, curve_cache)
			newvects.append(v_co)
		vects = newvects
	return vects

def math_vecsSubd(vects, maxSegmentLen):
	vects2 = []
	co_last = None
	for co in vects:
		if co_last is None:
			co_last = co
			vects2.append(co)
			continue
		v1 = Vector(co)
		v2 = Vector(co_last)
		segLen = (v1-v2).length
		if maxSegmentLen is None or segLen <= maxSegmentLen:
			co_last = co
			vects2.append(co)
			continue
		# interpolating. Skipping first - already in vects2
		newPtsCount = int(segLen/maxSegmentLen)
		for i in range(newPtsCount):
			fac = float(i+1)/float(newPtsCount)
			v3 = v2.lerp(v1, fac)
			vects2.append(v3)
		co_last = co
		#vects2.append(co)
	return vects2

def math_vecsSubdIdxToOrig(vects_vects_subdived_idx, vects_subdived, vects_original):
	# index in vects_original: need recalc index due subdivision
	pt_fac = float(vects_vects_subdived_idx)/(len(vects_subdived)-1)
	idx_presubd_raw = pt_fac * (len(vects_original)-1)
	idx_presubd1 = int(idx_presubd_raw)
	idx_presubd2 = idx_presubd1
	idx_presubd_fac = 0.0
	if idx_presubd1 < len(vects_original)-1:
		# interpolating
		idx_presubd2 = idx_presubd1+1
		idx_presubd_fac = idx_presubd_raw-idx_presubd1
	return idx_presubd1, idx_presubd2, idx_presubd_fac

# mathutils.geometry.intersect_point_line
# def projectPointOnPlaneByNormal(pOrig, pTarg, planeNrm):
# 	vec = pTarg-pOrig
# 	pTargProjected = pTarg - dot(vec, planeNrm) * planeNrm
# 	return pTargProjected
def math_vecFaceProj(vec_in, vec_in2, vec_axis):
	# vec_in - point, vec_in2 - point on face, vec_axis - face normal
	# https://stackoverflow.com/questions/9605556/how-to-project-a-3d-point-to-a-3d-plane
	# p - (n . (p - o)) . n
	# Also: mathutils.geometry.distance_point_to_plane
	nrm = vec_axis.normalized()
	vec_faceproj = vec_in -( nrm.dot(vec_in-vec_in2) * nrm )
	vec_facedist = (vec_in-vec_faceproj).length
	return vec_faceproj, vec_facedist

def math_vecCamProj(cutp_obj, cutp_pos_g, useCameraPlane, cutp_origin):
	camera_obj = object_by_name(config.kWPLSystemMainCam)
	camera_gOrtho = False
	if camera_obj.data.type == 'ORTHO':
		camera_gOrtho = True
	axisMatrix = None
	if useCameraPlane:
		axisMatrix = camera_obj.matrix_world.copy()
		if cutp_origin is not None:
			axisMatrix = math_matrixReplace(axisMatrix, cutp_origin, None, (1.0,1.0,1.0))
		else:
			axisMatrix = math_matrixReplace(axisMatrix, cutp_obj.matrix_world.to_translation(), None, (1.0,1.0,1.0))
	else:
		axisMatrix = cutp_obj.matrix_world.copy()
		if cutp_origin is not None:
			axisMatrix = math_matrixReplace(axisMatrix, cutp_origin, None, (1.0,1.0,1.0))
	p1 = axisMatrix @ Vector((0,0,0))
	p2 = axisMatrix @ Vector((1,0,0))
	p3 = axisMatrix @ Vector((0,1,0))
	cutp_pos_gPrj = None
	if abs(mathutils.geometry.distance_point_to_plane(cutp_pos_g, p1, ((axisMatrix @ Vector((0,0,1))) - p1).normalized() )) < config.kWPLRaycastEpsilon:
		# point already on plane
		#print("- math_vecCamProj: ALREADY ON PLANE")
		cutp_pos_gPrj = cutp_pos_g
	elif camera_gOrtho:
		camera_gDir = camera_obj.matrix_world.to_3x3() @ Vector((0.0, 0.0, 1.0))
		cutp_pos_gPrj = mathutils.geometry.intersect_ray_tri(p1, p2, p3, camera_gDir, cutp_pos_g, False)
		if cutp_pos_gPrj is None:
			#print("// ", p1, p2, p3, camera_gDir, cutp_pos_g)
			# object quite near, inverting direction
			# possible camera too close to target object
			# print("- math_vecCamProj: WARNING: fallback to backdirection (o)")
			cutp_pos_gPrj = mathutils.geometry.intersect_ray_tri(p1, p2, p3, -1*camera_gDir, cutp_pos_g, False)
	else:
		camera_gCo = camera_obj.matrix_world.to_translation()
		camera_gDir = (camera_gCo - cutp_pos_g).normalized()
		cutp_pos_gPrj = mathutils.geometry.intersect_ray_tri(p1, p2, p3, camera_gDir, cutp_pos_g, False)
		if cutp_pos_gPrj is None:
			#print("// ", p1, p2, p3, camera_gDir, cutp_pos_g)
			# object quite near, inverting direction
			# possible camera too close to target object
			# print("- math_vecCamProj: WARNING: fallback to backdirection (p)")
			cutp_pos_gPrj = mathutils.geometry.intersect_ray_tri(p1, p2, p3, -1*camera_gDir, cutp_pos_g, False)
	if cutp_pos_gPrj is None:
		print("- math_vecCamProj: WARNING: no projection found")
		return None
	cutp_pos_l = cutp_obj.matrix_world.inverted() @ cutp_pos_gPrj
	return cutp_pos_l

def math_vecOffsetClipped(pt, pt_offset, pt_prev = None, pt_next = None, enforce_equdistance = 0):
	if enforce_equdistance >= 1:
		pt_side = pt_prev
		if pt_side is None:
			pt_side = pt_next
		if pt_side is not None:
			pt_closest_dat = mathutils.geometry.intersect_point_line(pt+pt_offset, pt, pt_side)
			pt_closest = pt_closest_dat[0]
			pt_reproj = pt_closest + (pt+pt_offset - pt_closest).normalized()*pt_offset.length
			pt_offset = pt_reproj-pt_closest
			# if enforce_equdistance >= 2:
			# 	pt_offset_orig = pt_offset
			# 	if pt_prev is None or pt_next is None:
			# 		# start or end... should trim position to original direction to avoid point jump-out
			# 		pt_closest_pair = mathutils.geometry.intersect_line_line(pt, pt+pt_offset_orig, pt+pt_offset, pt_side+pt_offset)
			# 		if pt_closest_pair is not None:
			# 			return pt_closest_pair[0]
	if pt_prev is not None and pt_next is not None:
		# intersection with plane to next edge
		pt_cross = mathutils.geometry.intersect_line_plane(pt_prev+pt_offset, pt+pt_offset, pt, ((pt_prev-pt).normalized()+(pt-pt_next).normalized()).normalized(), True)
		if pt_cross is not None:
			return pt_cross
		else:
			print("- WARN: math_vecOffsetClipped: noncrossed!!!")
		# pt_crosses = mathutils.geometry.intersect_line_sphere(pt_prev+pt_offset, pt+pt_offset, pt, pt_offset.length, True)
		# if pt_crosses is not None:
		# 	if pt_crosses[1] is not None:
		# 		return pt_crosses[1]
		# 	if pt_crosses[0] is not None:
		# 		return pt_crosses[0]
	return pt+pt_offset

# ********************************************************************

def mat_getAll():
	mats = list(bpy.data.materials)
	worlds = list(bpy.data.worlds)
	all_mat = mats+worlds
	all_mat = sorted(all_mat, key=lambda k: k.name)
	return all_mat

def mat_getAllNodes(useNG, useMAT, useCOMP):
	all_nodes = set()
	if useNG:
		node_groups = bpy.data.node_groups
		for group in node_groups:
			for node in group.nodes:
				if node not in all_nodes:
					all_nodes.add(node)
	if useMAT:
		all_mat = mat_getAll()
		for mat in all_mat:
			if mat.use_nodes:
				for node in mat.node_tree.nodes:
					if node not in all_nodes:
						all_nodes.add(node)
	if useCOMP:
		compostree = bpy.context.scene.node_tree
		if compostree is not None:
			for node in compostree.nodes:
				if node not in all_nodes:
					all_nodes.add(node)
	return list(all_nodes)

def getTokensAsList(toks):
	toksList = None
	if isinstance(toks, str):
		toksList = [x.strip() for x in toks.split(",")]
	else:
		toksList = toks
	return toksList

def getTokenForStr(toks, nme, deflYes, deflNo = None):
	if toks is None or len(toks) == 0 or (nme is None) or len(nme) == 0:
		return deflNo
	nmeLower = nme.lower()
	toksList = getTokensAsList(toks)
	for tok in toksList:
		tok2check = tok
		okres = deflYes
		if okres is None:
			okres = tok
		if ":" in tok2check:
			pair = tok2check.split(":")
			tok2check = pair[0]
			okres = pair[1]
		if tok2check.lower() in nmeLower:
			return okres
	return deflNo

def isTokenInStr(toks, nme):
	if toks is None or len(toks) == 0 or (nme is None) or len(nme) == 0:
		return False
	# tok4str = getTokenForStr(toks, nme, None, False)
	# if tok4str == False:
	# 	return False
	# simple check DOES NOT treat ":" as delimiter
	toksList = getTokensAsList(toks)
	nmeLower = nme.lower()
	#print("- comparing", toks, toksList, nmeLower)
	for tok in toksList:
		if tok.lower() in nmeLower:
			return True
	return False

def strReplaceTokenInStr(toks, str_orig, replacer):
	str_new = str_orig
	toksList = getTokensAsList(toks)
	for ss in toksList:
		str_new = str_new.replace(ss, replacer)
	return str_new

def strToTokens(substrParts, forceLowerscase = True):
	if substrParts is None or len(substrParts) == 0:
		return []
	substrParts = substrParts.replace(";",",")
	substrParts = substrParts.replace(" ,",",")
	substrParts = substrParts.replace(" ,",",")
	substrParts = substrParts.replace(", ",",")
	substrParts = substrParts.replace(", ",",")
	substrParts = substrParts.replace(",,",",")
	substrParts = substrParts.replace(",,",",")
	stringTokens = []
	# split: empty tokens parsed too! ",,," -> ["", "", ""]
	# But empty tokens NOT NEEDED -> manual walk
	# tringTokens = [x.strip() for x in substrParts.split(",")]
	parts = substrParts.split(",")
	for p in parts:
		pp = p.strip()
		if len(pp) == 0:
			continue
		if forceLowerscase:
			pp = pp.lower()
		stringTokens.append(pp)
	return stringTokens

def strTokensMapStr(substrParts, subKey, checkPartialKey, defaultVal = ""):
	if isinstance(substrParts, str):
		substrParts = strTokensMap(substrParts, None)
	res = defaultVal
	subKey = subKey.lower()
	if subKey in substrParts:
		res = substrParts[subKey]
	elif checkPartialKey == True:
		checkAsterics = True
		keysLengthyFirst = sorted(substrParts.keys(), key=lambda k: len(k), reverse=True)
		for substrKey in keysLengthyFirst:
			if (subKey in substrKey) or (substrKey in subKey):
				res = substrParts[substrKey]
				checkAsterics = False
				break
		if checkAsterics and ("*" in substrParts):
			res = substrParts["*"]
	return res

def strTokensMapFloat(substrParts, subKey, checkPartialKey, defaultVal = 0.0):
	res = strTokensMapStr(substrParts, subKey, checkPartialKey, None)
	if res is None: 
		return defaultVal
	return float(res)

def strTokensMap(substrParts, defaultVal, forceLowerscase = True):
	boneWScale = {}
	boneWScalePairs = strToTokens(substrParts, forceLowerscase)
	for tk in boneWScalePairs:
		if ":" in tk:
			wscaPair = tk.split(":")
			if len(wscaPair) == 2:
				boneWScale[wscaPair[0]] = wscaPair[1]
			elif defaultVal is not None:
				boneWScale[tk] = defaultVal
		elif defaultVal is not None:
			boneWScale[tk] = defaultVal
	return boneWScale

def strBareName(objname, makeLower, removeSpace, remove001, removeAllDigits, removeHashTagAndComments, removeVersions):
	if removeHashTagAndComments:
		idx = None
		if config.kWPLFrameBindPostfix in objname: # from '_'
			idx = objname.find(config.kWPLFrameBindPostfix)
		elif '_#' in objname: # kWPLRQueueBindPostfix
			idx = objname.find('_#')
		elif '#' in objname: # kWPLNodePrefix && comments
			idx = objname.find('#')
		if idx is not None:
			objname = objname[0:idx]
	if removeVersions and config.kWPLMatTokenWPV in objname:
		part = objname.rpartition(config.kWPLMatTokenWPV)
		objname = part[0]
	if makeLower:
		objname = objname.lower()
	if removeSpace:
		objname = objname.replace(" ","")
		objname = objname.replace("_","")
	if remove001:
		# .001 .002 should be ignored!!!
		objname = re.sub('\.\d+', '', objname)
		objname = objname.replace(".","")
	if removeAllDigits:
		objname = re.sub('[0-9]', '', objname)
	return objname

def strTemplateObj(str_templ, obj):
	_, rootp = object_root_data(obj)
	str_templ = str_templ.replace("<obj>", strBareName(obj.name, True, True, True, False, True, True))
	if rootp is not None:
		str_templ = str_templ.replace("<root>", strBareName(rootp.name, True, True, True, False, True, True))
	else:
		str_templ = str_templ.replace("<root>", "_")
	str_templ = str_templ.replace("___","_")
	str_templ = str_templ.replace("__","_")
	return str_templ

# def strToInt(intWithPrefix):
# 	if len(intWithPrefix) == 0:
# 		return 0
# 	res = ''.join(c for c in intWithPrefix if c.isdigit())
# 	if len(res) == 0:
# 		return 0
# 	res = int(res)
# 	if "-" in intWithPrefix:
# 		res = -1*res
# 	return res

def safeFloat(valWithPrefix, deflVal = 0.0, prefixedBy = None):
	if valWithPrefix is None or len(valWithPrefix) == 0:
		return deflVal
	# getting first number after any prefix... 
	# but stopping on brakets
	if prefixedBy is not None:
		# checking if present
		idx = valWithPrefix.find(prefixedBy)
		if idx < 0:
			# no prefix - no result
			return deflVal
		valWithPrefix = valWithPrefix[idx+len(prefixedBy):]
	res = ""
	prefLen = 0
	numLen = 0
	canMinus = True
	for c in valWithPrefix:
		if (c in bracket_openers) or (c in bracket_closers):
			break
		if (c.isdigit() or c=='.' or (c=='-' and canMinus)):
			canMinus = False
			res = res + c
			if c.isdigit():
				# only for real digits
				numLen = numLen+1
		else:
			if numLen > 0:
				break
			prefLen = prefLen+1
	if len(res) == 0 or numLen == 0:
		return deflVal
	#print("- safeFloat", valWithPrefix, "->", res)
	res = float(res)
	return res

def strMultiSplit(input_string, separators):
	# https://stackoverflow.com/questions/1059559/split-strings-into-words-with-multiple-word-boundary-delimiters
	buffer = [input_string]
	for sep in separators:
		strings = buffer
		buffer = []  # reset the buffer
		for s in strings:
			sepParts = s.split(sep)
			for part in sepParts:
				r_fin = part.strip()
				if len(r_fin) == 0:
					continue
				buffer.append(r_fin)
	return buffer

bracket_openers = '[{(<'
bracket_closers = ']})>'
def strBracketedSplit(substrParts, delimiter, returnInnersOnly):
	# https://stackoverflow.com/questions/21662474/splitting-a-string-with-brackets-using-regular-expression-in-python
	opener_to_closer = dict(zip(bracket_openers, bracket_closers))
	opening_bracket = dict()
	#closing_bracket = dict()
	current_string = ''
	depth = 0
	#print("strBracketedSplit:", substrParts)
	for idx, c in enumerate(substrParts):
		if c in bracket_openers:
			depth += 1
			opening_bracket[depth] = (c, idx+1)
			# if strip_brackets and depth == 1:
			#     continue
		elif c in bracket_closers:
			assert depth > 0, f"You exited more brackets that we have entered in string {substrParts}"
			assert c == opener_to_closer[opening_bracket[depth][0]], f"Closing bracket {c} did not match opening bracket {opening_bracket[depth]} in string {substrParts}"
			opening_bracket[depth] = (opening_bracket[depth][0], opening_bracket[depth][1], idx)
			depth -= 1
			# if strip_brackets and depth == 0:
			#     continue
		if depth == 0 and (c == delimiter or (delimiter is None and len(opening_bracket) > 0)):
			if delimiter is None:
				# brackets content: before/prefix, inside, afters
				prefix = substrParts[ : (opening_bracket[depth+1][1]-1) ]
				inners = substrParts[ opening_bracket[depth+1][1] : idx ]
				afters = substrParts[ (idx+1): ]
				yield inners
				# else:
				# 	yield prefix
				# 	yield inners
				# 	yield afters
				return
			if returnInnersOnly and ((depth+1)in opening_bracket):
				current_string = substrParts[ opening_bracket[depth+1][1] : opening_bracket[depth+1][2] ]
			yield current_string
			current_string = ''
		else:
			current_string += c
	assert depth == 0, f'You did not close all brackets in string {substrParts}'
	if returnInnersOnly and ((depth+1)in opening_bracket):
		current_string = substrParts[ opening_bracket[depth+1][1] : opening_bracket[depth+1][2] ]
	yield current_string

def strToTokensBracketed(substrParts, returnInnersOnly):
	res = list(strBracketedSplit(substrParts, ",", returnInnersOnly))
	res_fin = []
	for r in res:
		r_fin = r.strip()
		if len(r_fin) == 0:
			continue
		res_fin.append(r_fin)
	return res_fin

def strExtractOuterBrackets(substrParts):
	res = list(strBracketedSplit(substrParts, None, True))
	#print("strExtractOuterBrackets:", substrParts,res)
	if len(res) == 0:
		return ""
	#print("strExtractOuterBrackets: ==", res[0])
	return res[0]

def arrIndexOf(list_val, test_val, idxIfFalse = -1, idxIfTrue = None):
	if (list_val is None) or (test_val is None):
		return idxIfFalse
	if test_val not in list_val:
		return idxIfFalse
	if idxIfTrue is not None:
		return idxIfTrue
	return list_val.index(test_val)

def arrBools(size, defValue, invDefIndexes = None):
	res = [defValue]*size
	if invDefIndexes is not None:
		for idx in invDefIndexes:
			res[idx] = not defValue
	return res

def hexToVectorRGB(hex_string):
	if hex_string[0] == "#":
		hex_string = hex_string[1:]
	r_hex = hex_string[0:2]
	g_hex = hex_string[2:4]
	b_hex = hex_string[4:6]
	veccol = Vector(( float(int(r_hex, 16))/255.0, float(int(g_hex, 16))/255.0, float(int(b_hex, 16))/255.0 ))
	return veccol

def vectorRGBToHex(vec):
	if vec is None:
		return ""
	colhex = '%02x%02x%02x' % (int(vec[0]*255), int(vec[1]*255), int(vec[2]*255))
	return colhex

def sys_objdata_by_name(obj, data_name):
	if data_name is None or len(data_name) == 0:
		return obj.data
	# must support all types of wla_meshwrap.kWPLMESHWRAP_TYPES
	obj_type = obj.type
	if obj_type == 'MESH':
		return bpy.data.meshes.get(data_name)
	if obj_type == 'CURVE':
		return bpy.data.curves.get(data_name)
	if obj_type == 'LATTICE':
		return bpy.data.lattices.get(data_name)
	if obj_type == 'ARMATURE':
		return bpy.data.armatures.get(data_name)
	if obj_type == 'GPENCIL':
		return bpy.data.grease_pencils.get(data_name)
	return None

def sys_objdata_versions(active_obj):
	names = []
	namenext = None
	namenextIdx = -1
	active_obj_name = active_obj.name
	active_obj_name = active_obj_name.replace(".","_") # .001 etc
	# no kWPLFrameBindPostfix tags, kWPLRQueueBindPostfix, etc
	active_obj_name = strBareName(active_obj_name, False, False, False, False, True, True)
	for i in range(1,11):
		vername = active_obj_name+config.kWPLMatTokenWPV+str(i)
		if sys_objdata_by_name(active_obj, vername) is not None:
			# support old manual versions
			names.append(vername)
			continue
		vername = active_obj_name+config.kWPLMatTokenWPV+str(i).zfill(2)
		vername_QF = vername + config.kWPLRQueueBindPostfix[-1] # _#(F)
		if sys_objdata_by_name(active_obj, vername) is not None:
			names.append(vername)
		elif sys_objdata_by_name(active_obj, vername_QF) is not None:
			names.append(vername_QF)
		else:
			if namenext is None:
				namenext = vername
				namenextIdx = i
	return names, namenext, namenextIdx

def sys_ismouse_in_view3d_window(event):
	regions = dict()
	for region in bpy.context.area.regions:
		regions[region.type] = region
	mouse_pos = Vector((event.mouse_x, event.mouse_y))
	window_dimensions = Vector((
		regions["WINDOW"].width - regions["UI"].width,
		regions["WINDOW"].height - regions["HEADER"].height
	))
	return (
		regions["TOOLS"].width < mouse_pos.x < window_dimensions.x and
		mouse_pos.y < window_dimensions.y
	)
	
def sys_findImg(node_tag, withFuzzyPartials):
	node_tag = node_tag.replace('.png', '')
	node_tag = node_tag.replace('.jpg', '')
	node_tag = node_tag.replace('.jpeg', '')
	node_tag = node_tag.replace('.tiff', '')
	node_tag = node_tag.replace('.tif', '')
	img = bpy.data.images.get(node_tag)
	if img is None:
		img = bpy.data.images.get(node_tag+".png")
	if img is None:
		img = bpy.data.images.get(node_tag+".jpg")
	if img is None:
		img = bpy.data.images.get(node_tag+".jpeg")
	if img is None:
		img = bpy.data.images.get(node_tag+".tiff")
	if img is None:
		img = bpy.data.images.get(node_tag+".tif")
	if (img is None) and withFuzzyPartials:
		for ii in bpy.data.images:
			iin = ii.name.lower()
			iin = iin.replace('.png', '')
			iin = iin.replace('.jpg', '')
			iin = iin.replace('.jpeg', '')
			iin = iin.replace('.tiff', '')
			iin = iin.replace('.tif', '')
			if iin in node_tag.lower():
				img = ii
				break
	return img

def sys_filesWithSubd(path, extensions):
	files = []
	# os.listdir - not recursive
	# r=root, d=directories, f = files
	for r, d, f in os.walk(path):
		for file_name in f:
			for extn in extensions:
				if '.'+extn.lower() in file_name.lower():
					fpath = os.path.join(r, file_name)
					fpath = os.path.abspath(fpath)
					files.append(fpath)
					break
	return files