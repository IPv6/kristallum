import os, sys, time, datetime
import math, copy, string, random
import numpy as np
import bpy, bmesh, mathutils
from time import time
from operator import itemgetter
from itertools import groupby

import bpy.types
from mathutils import Vector, Matrix, Euler, Quaternion

from . import wla
from . import wla_do
from . import wla_attr
from .. import config

def convertAttr(Attr):
	'''Convert given value to a Json serializable format'''
	if isinstance(Attr, (mathutils.Vector,mathutils.Color)):
		return Attr[:]
	elif isinstance(Attr, mathutils.Matrix):
		return [v[:] for v in Attr]
	elif isinstance(Attr,bpy.types.bpy_prop_array):
		return [Attr[i] for i in range(0,len(Attr))]
	else:
		return(Attr)

def cu_getSplines(objCurve):
	curveData = objCurve.data
	if objCurve.type == 'GPENCIL':
		splines = []
		for i1, layer in enumerate(curveData.layers):
			if layer.hide or layer.lock:
				continue
			layer_frame = layer.active_frame
			if layer_frame is None: # GPencilLayer GPencilFrames
				layer_frame = layer.frames[0]
			for i2, polyline in enumerate(layer_frame.strokes):
				splines.append(polyline)
		return splines
	return curveData.splines

def cu_getPoints(polyline):
	if isinstance(polyline, bpy.types.GPencilStroke):
		return polyline.points
	if polyline.type == 'NURBS' or polyline.type == 'POLY':
		points = polyline.points
	else:
		points = polyline.bezier_points
	return points

def cu_getPointsSel(polyline, ignoreHids = False):
	if isinstance(polyline, bpy.types.GPencilStroke):
		points = [point for point in polyline.points if point.select]
		return points
	points = cu_getPoints(polyline)
	if polyline.type == 'NURBS' or polyline.type == 'POLY':
		points = [point for point in points if (point.select and (ignoreHids == False or point.hide == 0))]
	else:# bezier
		points = [point for point in points if (point.select_control_point and (ignoreHids == False or point.hide == 0))]
	return points

def cu_setSel(pt, selected):
	if isinstance(pt, bpy.types.BezierSplinePoint):
		pt.select_control_point = True
		pt.select_left_handle = True
		pt.select_right_handle = True
		return
	pt.select = selected

def cu_setCo(pt,pt_x,pt_y,pt_z):
	v_co = None
	if isinstance(pt, bpy.types.GPencilStrokePoint):
		v_co = Vector((pt_x,pt_y,pt_z))
		pt.co = v_co
	elif isinstance(pt, bpy.types.BezierSplinePoint):
		v_co = Vector((pt_x,pt_y,pt_z))
		pt.co = v_co
	else:
		v_co = Vector((pt_x,pt_y,pt_z,1))
		pt.co = v_co
	return v_co

def cu_getSelectedStrokes(curveObj, ignoreHids, treat1ptAsFull):
	selected_pnt_all = []
	selected_pnt_sel = []
	selected_polys_cu = []
	splines = cu_getSplines(curveObj)
	if curveObj.type == 'GPENCIL':
		for polyline in splines:
			points_sel = [point for point in polyline.points if point.select]
			if treat1ptAsFull and len(points_sel) == 1:
				points_sel = [point for point in polyline.points] # all points
			if len(points_sel)>0:
				points_all = [point for point in polyline.points]
				selected_polys_cu.append(polyline)
				selected_pnt_all.append(points_all)
				selected_pnt_sel.append(points_sel)
	else:
		for polyline in curveObj.data.splines:
			pts = cu_getPoints(polyline)
			points_sel = cu_getPointsSel(polyline, ignoreHids)
			if treat1ptAsFull and len(points_sel) == 1:
				points_sel = [point for point in pts] # all points
			if len(points_sel)>0:
				points_all = [point for point in pts if (ignoreHids == False or point.hide == 0)]
				selected_polys_cu.append(polyline)
				selected_pnt_all.append(points_all)
				selected_pnt_sel.append(points_sel)
	return (selected_pnt_all, selected_pnt_sel, selected_polys_cu)

def cu_apply_xmirror(objCurve,onlySelected):
	wla_do.select_and_change_mode(objCurve, 'EDIT')
	splines = cu_getSplines(objCurve)
	initialCount = len(splines)
	for i in range(initialCount):
		polylineI =splines[i]
		points = cu_getPoints(polylineI)
		if onlySelected:
			points = cu_getPointsSel(polylineI)
		if len(points)>1:
			polylineC = None
			if len(polylineI.bezier_points) > 0:
				polylineC = objCurve.data.splines.new('BEZIER')
			else:
				polylineC = objCurve.data.splines.new('NURBS')
			for j in range(len(points)):
				pointI = points[j]
				if len(polylineI.bezier_points) > 0:
					if len(polylineC.bezier_points) <= j:
						polylineC.bezier_points.add(1)
					cu_setCo(polylineC.bezier_points[j], -1.0*pointI.co[0], pointI.co[1], pointI.co[2])
					polylineC.bezier_points[j].radius = pointI.radius
					polylineC.bezier_points[j].tilt = pointI.tilt
					polylineC.bezier_points[j].handle_left =  (-1.0*pointI.handle_left[0], pointI.handle_left[1], pointI.handle_left[2])
					polylineC.bezier_points[j].handle_right =  (-1.0*pointI.handle_right[0], pointI.handle_right[1], pointI.handle_right[2])
				else:
					if len(polylineC.points) <= j:
						polylineC.points.add(1)
					cu_setCo(polylineC.points[j], -1.0*pointI.co[0], pointI.co[1], pointI.co[2])
					polylineC.points[j].radius = pointI.radius
					polylineC.points[j].tilt = pointI.tilt
			polylineC.use_endpoint_u = polylineI.use_endpoint_u
			polylineC.use_bezier_u = polylineI.use_bezier_u
			polylineC.use_cyclic_u = polylineI.use_cyclic_u
			polylineC.resolution_u = polylineI.resolution_u
			polylineC.use_smooth = polylineI.use_smooth
			polylineC.order_u = polylineI.order_u
	return

def cu_rescale_radius(poly_or_gp_points, radF3c, mid_fac, baseRadius):
	if baseRadius<=0.0001:
		for p in poly_or_gp_points:
			if isinstance(p, bpy.types.GPencilStrokePoint):
				baseRadius = max(baseRadius, p.pressure)
			else:
				baseRadius = max(baseRadius, p.radius)
		#print("- rescale: max radius:", baseRadius)
	radiusAtStart = radF3c[0]
	radiusAtEnd = radF3c[1]
	radiusPow = radF3c[2]
	if radiusPow < 0.01:
		radiusPow = 1.0
	curveLength = float(len(poly_or_gp_points))
	if curveLength>1:
		mid_fac = min(0.99,max(0.01,mid_fac))
		curveDistTotal = 0
		pprev = None
		for i,p in enumerate(poly_or_gp_points):
			if pprev is not None:
				curveDistTotal = curveDistTotal+(p.co-pprev.co).length
			pprev = p
		if curveDistTotal > 0.0:
			pprev = None
			curveDist = 0
			for i,p in enumerate(poly_or_gp_points):
				if pprev is not None:
					curveDist = curveDist+(p.co-pprev.co).length
				pprev = p
				#curve_fac = float(i) / (curveLength-1)
				curve_fac = curveDist / curveDistTotal
				RadTotal = wla.remap_F_M_T_smooth(curve_fac, mid_fac, radiusPow, (radiusAtStart, 1.0, radiusAtEnd))
				RadTotal = max(0.00001,RadTotal)
				if isinstance(p, bpy.types.GPencilStrokePoint):
					# grease pencil
					p.pressure = RadTotal*baseRadius
				else:
					p.radius = RadTotal*baseRadius
	return baseRadius

def gp_getLayerMatrix(gpObj, layer) :
	matrix = None
	if layer is not None and layer.is_parented:
		# armature parenting?
		if layer.parent_type == 'BONE':
			object = layer.parent
			bone = object.pose.bones[layer.parent_bone]
			matrix = bone.matrix * object.matrix_world
			matrix = matrix.copy() * layer.matrix_inverse
		else :
			matrix = layer.parent.matrix_world * layer.matrix_inverse
	if matrix is None:
		matrix = gpObj.matrix_world
	return matrix

def gp_dump_point(gpObj, p, l):
	'''add properties of a given points to a dic and return it'''
	pdic = {}
	#point_attr_list = ('co', 'pressure', 'select', 'strength') #select#'rna_type'
	#for att in point_attr_list:
	#    pdic[att] = convertAttr(getattr(p, att))
	mat = gp_getLayerMatrix(gpObj, None)
	if l.is_parented:
		mat = gp_getLayerMatrix(gpObj, l)
	pdic['co'] = convertAttr(mat @ getattr(p,'co'))
	pdic['pressure'] = convertAttr(getattr(p,'pressure'))
	pdic['select'] = convertAttr(getattr(p,'select'))
	pdic['strength'] = convertAttr(getattr(p,'strength'))
	return pdic

# def gp_dump_stroke(gpObj, s, l):
# 	'''Get a grease pencil stroke and return a dic with attribute (points attribute being a dic of dics to store points and their attributes)'''
# 	stroke_attr_list = ('use_cyclic', 'display_mode', 'line_width', 'points', ) #'select'#read-only: 'triangles'
# 	sdic = {}
# 	for att in stroke_attr_list:
# 		sdic[att] = getattr(s, att)
# 	points = []
# 	for p in s.points:
# 		points.append(gp_dump_point(gpObj, p,l))
# 	sdic['points'] = points
# 	return sdic

def gp_dump_stroke_range(gpObj, s, sid, l):
	'''Get a grease pencil stroke and return a dic with attribute (points attribute being a dic of dics to store points and their attributes)'''
	stroke_attr_list = ('use_cyclic', 'display_mode', 'line_width', 'points', ) #'select'#read-only: 'triangles'
	sdic = {}
	for att in stroke_attr_list:
		sdic[att] = getattr(s, att)
	points = []
	for pid in sid:
		points.append(gp_dump_point(gpObj, s.points[pid],l))
	sdic['points'] = points
	if l is not None:
		sdic['layer_name'] = l.info
	if s.material_index >= 0 and s.material_index < len(gpObj.material_slots):
		mat = gpObj.material_slots[s.material_index]
		if mat is not None:
			sdic['stroke_mat'] = mat.name
	print("- copied points", len(points), sdic['layer_name'], sdic['stroke_mat'])
	return sdic

def gp_copycut_strokes(gpObj, layers=None, copy=True, keep_empty=True):# (mayber allow filter)
	'''
	copy all visibles selected strokes
	if keep_empty is False the frame is deleted when all strokes are cutted
	'''
	t0 = time()
	### must iterate in all layers ! (since all layers are selectable / visible !)
	scene = bpy.context.scene
	gp = gpObj.data
	gpl = gp.layers
	# if not color:#get active color name
	#     color = gp.palettes.active.colors.active.name
	if not layers:
		#by default all visible layers
		layers = [l for l in gpl if not l.hide and not l.lock]#[]
	if not isinstance(layers, list):
		#if a single layer object is send put in a list
		layers = [layers]
	stroke_list = [] #one stroke list for all layers.
	for l in layers:
		f = l.active_frame
		if f:#active frame can be None
			if not copy:
				staylist = []#init part of strokes that must survive on this layer
			for s in f.strokes:
				if s.select:
					# separate in multiple stroke if parts of the strokes a selected.
					sel = [i for i, p in enumerate(s.points) if p.select]
					if len(sel) == 1:
						# single point == whole stroke
						sel = [i for i, p in enumerate(s.points)]
					substrokes = []
					for k, g in groupby(enumerate(sel), lambda x:x[0]-x[1]):
						group = list(map(itemgetter(1), g))
						substrokes.append(group)

					for ss in substrokes:
						if len(ss) > 1:#avoid copy isolated points
							stroke_list.append(gp_dump_stroke_range(gpObj, s, ss, l))

					#Cutting operation
					if not copy:
						maxindex = len(s.points)-1
						if len(substrokes) == maxindex+1:#si un seul substroke, c'est le stroke entier
							f.strokes.remove(s)
						else:
							#neg = [i for i, p in enumerate(s.points) if not p.select]
							neg = [i for i, p in enumerate(s.points) if (i not in sel)]
							staying = []
							for k, g in groupby(enumerate(neg), lambda x:x[0]-x[1]):
								group = list(map(itemgetter(1), g))
								#extend group to avoid gap when cut, a bit dirty
								if group[0] > 0:
									group.insert(0,group[0]-1)
								if group[-1] < maxindex:
									group.append(group[-1]+1)
								staying.append(group)
							for ns in staying:
								if len(ns) > 1:
									staylist.append(gp_dump_stroke_range(gpObj, s, ns, l))
							#make a negative list containing all last index
			if not copy:
				print('- cut: restoring points')
				# delete all selected strokes...
				for s in f.strokes:
					if s.select:
						f.strokes.remove(s)
				# ...recreate these uncutted ones
				#pprint(staylist)
				if staylist:
					gp_paste_multiple_strokes(gpObj, staylist, l, True)
			#if nothing left on the frame choose to leave an empty frame or delete it (let previous frame appear)
			if not copy and not keep_empty:#
				if not len(f.strokes):
					l.frames.remove(f)
	print('- strokes copied in', time()-t0, 'sec. strokes:', len(stroke_list))
	#print(stroke_list)
	return stroke_list


def gp_paste_stroke(gpObj, s, frame, layer):
	'''add stroke on a given frame, (layer is for parentage setting)'''
	#print(3*'-',s)
	ns = frame.strokes.new()
	for att, val in s.items():
		if att not in ['points', 'layer_name', 'stroke_mat']:
			setattr(ns, att, val)
	pts_to_add = len(s['points'])
	#print(pts_to_add, 'points')#dbg
	ns.points.add(pts_to_add)
	#patch pressure 1
	pressure_flat_list = [di['pressure'] for di in s['points']] #get all pressure flatened
	mat_inv = gp_getLayerMatrix(gpObj, None).inverted()
	if layer.is_parented:
		mat_inv = gp_getLayerMatrix(gpObj, layer).inverted()
	for i, pt in enumerate(s['points']):
		for k, v in pt.items():
			setattr(ns.points[i], k, v)
		ns.points[i].co = mat_inv @ ns.points[i].co
	ns.points.foreach_set('pressure', pressure_flat_list)
	# set material if present
	if 'stroke_mat' in s:
		mat_idx = wla_attr.mat_obj_ensureGpMat(gpObj, s['stroke_mat'], None, False)
		if mat_idx is not None:
			ns.material_index = mat_idx

def gp_paste_multiple_strokes(gpObj, stroke_list, use_layer, use_current_frame):
	'''
	add a list of strokes to active frame of given layer
	if no layer specifief, active layer is used
	if use_current_frame is True, a new frame will be created only if needed
	'''
	scene = bpy.context.scene
	gp = gpObj.data
	gpl = gp.layers
	for s in stroke_list:
		#default: active
		layer = use_layer
		if not layer and ('layer_name' in s):
			layer_name = s['layer_name']
			layer = gpObj.data.layers.get(layer_name)
			if layer is None:
				# adding layer
				layer = gpObj.data.layers.new(layer_name, set_active=True)
		if not layer:
			layer = gpl.active
		fnum = scene.frame_current
		target_frame = False
		act = layer.active_frame
		if act:
			if use_current_frame or act.frame_number == fnum:
				#work on current frame if exists
				# use current frame anyway if one key exist at this scene.frame
				target_frame = act
		if not target_frame:
			#no active frame
			#or active exists but not aligned scene.current with use_current_frame disabled
			target_frame = layer.frames.new(fnum)
		#print('- pasting stroke. layer:', layer.info)
		gp_paste_stroke(gpObj, s, target_frame, layer)
	print('- strokes pasted', len(stroke_list))
	return

def gp_get_annots():
	strokes = []
	for gpd in bpy.data.grease_pencils:
		#print("- gpd", gpd.name)
		if ("Annotations" in gpd.name) and gpd.users > 0:
			for i1, layer in enumerate(gpd.layers):
				layer_frame = layer.active_frame
				if layer_frame is None:
					layer_frame = layer.frames[0]
				for i2, polyline in enumerate(layer_frame.strokes):
					strt = []
					for pt in polyline.points:
						strt.append( Vector( (pt.co[0], pt.co[1], pt.co[2]) ) )
					strokes.append(strt)
	return strokes

def cu_copycut_strokes(cvObj, copy=True):
	selected_polys_all, selected_polys_sel, selected_polys_cu = cu_getSelectedStrokes(cvObj, False, True)
	data = {}
	data['cu_splines'] = []
	splines2del = []
	splines_pts = selected_polys_sel
	if copy == False:
		splines_pts = selected_polys_all
	for i, curve_pts in enumerate(splines_pts):
		polylineI = selected_polys_cu[i]
		data_spl = {}
		data_spl["pts"] = []
		for pt in curve_pts:
			data_pt = {}
			data_pt["co_g"] = list(cvObj.matrix_world @ Vector( (pt.co[0], pt.co[1], pt.co[2]) ))
			data_pt["radius"] =  pt.radius
			data_pt["tilt"] =  pt.tilt
			data_spl["pts"].append(data_pt)
		data_spl["use_endpoint_u"] = polylineI.use_endpoint_u
		data_spl["use_bezier_u"] = polylineI.use_bezier_u
		data_spl["use_cyclic_u"] = polylineI.use_cyclic_u
		data_spl["resolution_u"] = polylineI.resolution_u
		data_spl["use_smooth"] = polylineI.use_smooth
		data_spl["order_u"] = polylineI.order_u
		splines2del.append(polylineI)
		data['cu_splines'].append(data_spl)
	if copy == False:
		# deleting splines
		for pl in splines2del:
			cvObj.data.splines.remove(pl)
	return data

def cu_paste_multiple_strokes(cvObj, data):
	splines = data['cu_splines']
	for spl_data in splines:
		polylineC = cvObj.data.splines.new('NURBS')
		spl_pts = spl_data["pts"]
		for j in range(len(spl_pts)):
			pt_dat = spl_pts[j]
			if len(polylineC.points) <= j:
				polylineC.points.add(1)
			pt_co = cvObj.matrix_world.inverted() @ Vector( pt_dat["co_g"] )
			polylineC.points[j].co = (pt_co[0], pt_co[1], pt_co[2], 1)
			polylineC.points[j].radius = pt_dat["radius"]
			polylineC.points[j].tilt = pt_dat["tilt"]
		polylineC.use_endpoint_u = spl_data["use_endpoint_u"]
		polylineC.use_bezier_u = spl_data["use_bezier_u"]
		polylineC.use_cyclic_u = spl_data["use_cyclic_u"]
		polylineC.resolution_u = spl_data["resolution_u"]
		polylineC.use_smooth = spl_data["use_smooth"]
		polylineC.order_u = spl_data["order_u"]
	return

# Copy all from frame to frame
# ??? https://blender.stackexchange.com/questions/204636/moving-gpencil-frames-in-time-with-python-causes-viewport-issues