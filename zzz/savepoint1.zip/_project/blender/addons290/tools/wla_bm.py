import os, sys, time, datetime
import math, copy, string, random
import numpy as np
import bpy, bmesh, mathutils

import bpy.types
from mathutils import Vector, Matrix, Euler, Quaternion
from mathutils.bvhtree import BVHTree
from mathutils.kdtree import KDTree
from bpy_extras import view3d_utils
from bpy.props import *

from .. import config
from . import wla
from . import wla_do
from . import wla_attr
EPS = np.finfo(float).eps

kWPL_PINCONVEXKey = "convex_last_used"

def bm_historyVertsIdx(active_bmesh):
	active_bmesh.verts.ensure_lookup_table()
	active_bmesh.verts.index_update()
	selectedVertsIdx = []
	for elem in reversed(active_bmesh.select_history):
		if isinstance(elem, bmesh.types.BMVert) and elem.select and elem.hide == 0:
			selectedVertsIdx.append(elem.index)
	# first selected - last in list
	return selectedVertsIdx
	
def bm_historyEdgesIdx(active_bmesh):
	active_bmesh.edges.ensure_lookup_table()
	active_bmesh.edges.index_update()
	selectedEdgesIdx = []
	for elem in reversed(active_bmesh.select_history):
		if isinstance(elem, bmesh.types.BMEdge) and elem.select and elem.hide == 0:
			selectedEdgesIdx.append(elem.index)
	return selectedEdgesIdx

def bm_historyFaceIdx(active_bmesh):
	active_bmesh.faces.ensure_lookup_table()
	active_bmesh.faces.index_update()
	selectedFacesIdx = []
	for elem in reversed(active_bmesh.select_history):
		if isinstance(elem, bmesh.types.BMFace) and elem.select and elem.hide == 0:
			selectedFacesIdx.append(elem.index)
	return selectedFacesIdx

def bm_historyRefCo(active_bmesh):
	active_bmesh.verts.ensure_lookup_table()
	active_bmesh.verts.index_update()
	active_bmesh.edges.ensure_lookup_table()
	active_bmesh.edges.index_update()
	histVertsIdx = []
	histFacesIdx = []
	histEdgesIdx = []
	if bpy.context.tool_settings.mesh_select_mode[2] == True:
		histFacesIdx = bm_historyFaceIdx(active_bmesh)
	elif bpy.context.tool_settings.mesh_select_mode[1] == True:
		histEdgesIdx = bm_historyEdgesIdx(active_bmesh)
	else:
		histVertsIdx = bm_historyVertsIdx(active_bmesh)
	if len(histFacesIdx)+len(histVertsIdx)+len(histEdgesIdx) == 0:
		return None
	fltCenter = Vector((0,0,0))
	fltNormal = Vector((0,0,0))
	fltAxe = None
	if len(histFacesIdx)>0:
		f = active_bmesh.faces[histFacesIdx[0]]
		fltCenter = f.calc_center_median()
		fltNormal = f.normal
	elif len(histEdgesIdx)>0:
		e = active_bmesh.edges[histEdgesIdx[0]]
		fltCenter = (e.verts[0].co+e.verts[1].co)*0.5
		fltNormal = (e.verts[0].normal+e.verts[1].normal)*0.5
		fltAxe = (e.verts[0].co-e.verts[1].co).normalized()
	else:
		v = active_bmesh.verts[histVertsIdx[0]]
		fltCenter = v.co
		fltNormal = v.normal
	return (fltCenter,fltNormal,fltAxe)

def bm_edgesAsStrands_v04(active_obj, bm, vertsIdx, edgesIdx, opt_flowDirP, obj_forWrldMat = None):
	bm.verts.ensure_lookup_table()
	bm.verts.index_update()
	bm.edges.ensure_lookup_table()
	bm.edges.index_update()
	if edgesIdx is None:
		# # all edges
		# edgesIdx = []
		# for e in bm.edges:
		# 	edgesIdx.append(e.index)
		return None, None
	# looking for bounding verts
	if opt_flowDirP is None:
		opt_flowDir = Vector( (0,0,1) )
	else:
		opt_flowDir = Vector(opt_flowDirP)
		opt_flowDir = opt_flowDir.normalized()
	def calc_boundVerts(verts2cut):
		bndVertsTest = []
		for vIdx in vertsIdx:
			v = bm.verts[vIdx]
			edgeDirs = []
			for e in v.link_edges:
				if e.index in edgesIdx:
					if e.other_vert(v).index in verts2cut:
						continue
					flowfir = (e.other_vert(v).co-v.co).normalized()
					flowdot = flowfir.dot(opt_flowDir)
					flowang = math.acos(flowdot)
					edgeDirs.append(flowang)
			if len(edgeDirs) == 1:
				bndVertsTest.append((vIdx, edgeDirs[0]))
		bndVertsTest.sort(key=lambda ia: ia[1], reverse=False)
		return bndVertsTest
	vgicutline_verts = []
	if active_obj is not None:
		# using cutline
		vgicutline_verts, _ = wla_attr.vg_get_weightMapByTok(active_obj, config.kWPLSuppVGScriptCutlin)
	bndVerts = calc_boundVerts(vgicutline_verts)
	if len(bndVerts)<2 and len(edgesIdx)>1:
		# loops... breaking edgesIdx somewhere
		dropVertIdx = None
		if dropVertIdx is None and (active_obj is not None):
			# breaking most far from camera
			camera_gCo, _, _, _ = wla.active_camera()
			if camera_gCo is not None:
				maxDst = -1
				for vIdx in vertsIdx:
					v = bm.verts[vIdx]
					vDst = ((active_obj.matrix_world @ v.co) - camera_gCo).length
					if vDst>maxDst:
						maxDst = vDst
						dropVertIdx = vIdx
		if dropVertIdx is None:
			dropVertIdx = vertsIdx[0]
		#histVerts = bm_historyVertsIdx(bm)
		#if len(histVerts) > 0:
		#	dropVertIdx = histVerts[0] # most recent active vert
		# isDropped = False
		# for eIdx in edgesIdx:
		# 	e = bm.edges[eIdx]
		# 	if e.verts[0].index == dropVertIdx or e.verts[1].index == dropVertIdx:
		# 		edgesIdx.remove(eIdx)
		# 		isDropped = True
		# 		break
		# if isDropped == False:
		# 	edgesIdx.remove(edgesIdx[0])
		bndVerts = calc_boundVerts([dropVertIdx])
	if len(bndVerts)<2:
		# something wrong
		return None, None
	strands_points = []
	strands_vidx = []
	checked_verts = []
	#print("bndVerts", bndVerts)
	for ia in bndVerts:
		vIdx = ia[0]
		points_co = None
		points_idx = None
		canContinue = True
		while canContinue == True:
			#print("Checking vIdx", vIdx)
			if vIdx in checked_verts:
				canContinue = False
				continue
			checked_verts.append(vIdx)
			if points_co is None:
				points_co = []
				points_idx = []
				strands_points.append(points_co)
				strands_vidx.append(points_idx)
			v = bm.verts[vIdx]
			points_idx.append(v.index)
			v_co = copy.copy(v.co)
			if obj_forWrldMat is not None:
				v_co = obj_forWrldMat.matrix_world @ v_co
			points_co.append(v_co)
			canContinue = False
			for e in v.link_edges:
				if e.index in edgesIdx:
					vIdx = e.other_vert(v).index
					if vIdx not in checked_verts:
						canContinue = True
						break
	return strands_points, strands_vidx

def bm_expandVertsToIslands_v02(bm, selverts, stopverts):
	totalIslands = []
	#totalIslandsCenterCo = []
	verts2walk = []
	usedverts = []
	if selverts is None:
		selverts = []
		for v in bm.verts:
			selverts.append(v.index)
	for rvidx in selverts:
		if rvidx in usedverts:
			continue
		mi = []
		mi.append(rvidx)
		#v = bm.verts[rvidx]
		#miCenter = v.co
		verts2walk.append(rvidx)
		while len(verts2walk)>0:
			verts2walkNext = []
			for vIdx in verts2walk:
				if vIdx in usedverts:
					continue
				usedverts.append(vIdx)
				v = bm.verts[vIdx]
				if vIdx not in mi:
					mi.append(vIdx)
					#miCenter = miCenter+v.co
				for edge in v.link_edges:
					ov = edge.other_vert(v)
					if ov.index in usedverts:
						continue
					if stopverts is not None and ov.index in stopverts:
						continue
					verts2walkNext.append(ov.index)
			verts2walk = verts2walkNext
		if len(mi)>0:
			totalIslands.append(mi)
			#totalIslandsCenterCo.append(miCenter/len(mi))
	# islandPerVert = {}
	# islandId = 0.0
	# for meshlist in totalIslands:
	# 	if len(meshlist)>0:
	# 		islandId = islandId+1.0
	# 		for vidx in meshlist:
	# 			islandPerVert[vidx] = islandId, totalIslandsCenterCo
	return totalIslands

def bm_calcSectorZone(bm, vertsIdx, connDir):
	zoneVertsIdx = []
	bm.verts.ensure_lookup_table()
	bm.verts.index_update()
	for v in bm.verts:
		if v.index in vertsIdx:
			continue
		avgDir = Vector((0,0,0))
		for ref_vIdx in vertsIdx:
			vr = bm.verts[ref_vIdx]
			avgDir = avgDir+(vr.co-v.co)
		avgDir = (avgDir/len(vertsIdx)).normalized()
		if avgDir.dot(connDir.normalized()) > 0:
			zoneVertsIdx.append(v.index)
	return zoneVertsIdx

def bm_sortVertsByConnection(bm, vertsIdx, smartFirst, walkFacesToo):
	bm.verts.ensure_lookup_table()
	bm.verts.index_update()
	bm.edges.ensure_lookup_table()
	bm.edges.index_update()
	bm.faces.ensure_lookup_table()
	bm.faces.index_update()
	if len(vertsIdx)<3:
		return vertsIdx
	if smartFirst:
		for i in range(0, len(vertsIdx)):
			v = bm.verts[vertsIdx[i]]
			selothors = 0
			for e in v.link_edges:
				if e.other_vert(v).index in vertsIdx:
					selothors = selothors+1
			if selothors == 1:
				if i == 0:
					# do nothing, already ok
					# important for manually presorted (UV - EdgeGRID unwrap)
					break
				# first vert must be "start vert"
				t = vertsIdx[0]
				vertsIdx[0] = vertsIdx[i]
				vertsIdx[i] = t
				break
	for i in range(len(vertsIdx)-1):
		v = bm.verts[vertsIdx[i]]
		mindst = 9999
		exhpos = -1
		# looking in connected islands first
		for j in range(i+1,len(vertsIdx)):
			vo = bm.verts[vertsIdx[j]]
			if walkFacesToo:
				for f in v.link_faces:
					if vo in f.verts:
						if (vo.co-v.co).length < mindst:
							mindst = (vo.co-v.co).length
							exhpos = j
			else:
				for e in v.link_edges:
					if vo == e.other_vert(v):
						if (vo.co-v.co).length < mindst:
							mindst = (vo.co-v.co).length
							exhpos = j
		if exhpos < 0:
			# looking in rest vertices with very single near-point (another edgeline start)
			for j in range(i+1,len(vertsIdx)):
				vo = bm.verts[vertsIdx[j]]
				linkedVerts = 0
				for e in vo.link_edges:
					if e.other_vert(vo).index in vertsIdx:
						linkedVerts = linkedVerts+1
				if linkedVerts != 1:
					continue
				if (vo.co-v.co).length < mindst:
					mindst = (vo.co-v.co).length
					exhpos = j
		if exhpos < 0:
			# looking in all of the rest vertices
			for j in range(i+1,len(vertsIdx)):
				vo = bm.verts[vertsIdx[j]]
				if (vo.co-v.co).length < mindst:
					mindst = (vo.co-v.co).length
					exhpos = j
		if exhpos >= 0:
			t = vertsIdx[i+1]
			vertsIdx[i+1] = vertsIdx[exhpos]
			vertsIdx[exhpos] = t
	return vertsIdx

def bm_splitVertsByConnection(bm, vertsIdxAll, breakByIsland, breakByEdgeList, cutlineVerts):
	vertsIdx = vertsIdxAll
	vertsIdx_cutline = []
	if cutlineVerts is not None:
		vertsIdx = []
		for vIdx in vertsIdxAll:
			if cutlineVerts is not None and (vIdx in cutlineVerts):
				vertsIdx_cutline.append(vIdx)
			else:
				vertsIdx.append(vIdx)
	vertsIdx = bm_sortVertsByConnection(bm, vertsIdx, True, False)
	curvesSplit = []
	if len(vertsIdx) == 0:
		return curvesSplit
	curve = None
	curve = []
	curvesSplit.append(curve)
	for vIdx in vertsIdx:
		if len(curve) == 0:
			curve.append(vIdx)
		else:
			isSameCurve = False
			v = bm.verts[vIdx]
			if breakByIsland:
				# checking all curve points
				for e in v.link_edges:
					if (breakByEdgeList is not None) and (e.index not in breakByEdgeList):
						continue
					other_v_idx = e.other_vert(v).index
					if other_v_idx in curve:
						isSameCurve = True
						break
				if isSameCurve == False:
					# possibly one of past curves? Switching back
					for pcurv in curvesSplit:
						for e in v.link_edges:
							if (breakByEdgeList is not None) and (e.index not in breakByEdgeList):
								continue
							other_v_idx = e.other_vert(v).index
							if other_v_idx in pcurv:
								curve = pcurv
								isSameCurve = True
								break
			else:
				# checking only last point
				prevIdx = curve[-1]
				for e in v.link_edges:
					if (breakByEdgeList is not None) and (e.index not in breakByEdgeList):
						continue
					other_v_idx = e.other_vert(v).index
					if other_v_idx == prevIdx:
						isSameCurve = True
						break
				if isSameCurve == False:
					# possibly one of past curves? Switching back
					for pcurv in curvesSplit:
						prevIdx = pcurv[-1]
						for e in v.link_edges:
							if (breakByEdgeList is not None) and (e.index not in breakByEdgeList):
								continue
							other_v_idx = e.other_vert(v).index
							if other_v_idx == prevIdx:
								curve = pcurv
								isSameCurve = True
								break
			if isSameCurve == False:
				# curve/island ended
				curve = []
				curvesSplit.append(curve)
			curve.append(vIdx)

	if len(vertsIdx_cutline) > 0:
		# adding cutline verts if they are linked with any curves
		# Useful in vgs, so cw(), fit(), stripe() can handle full radius
		# AFTER checking for head-tail
		for curve in curvesSplit:
			for vIgnIdx in vertsIdx_cutline:
				vIgn = bm.verts[vIgnIdx]
				for e in vIgn.link_edges:
					vIgnOther = e.other_vert(vIgn)
					if curve[0] == vIgnOther.index:
						curve.insert(0, vIgnIdx)
					if curve[-1] == vIgnOther.index:
						curve.append(vIgnIdx)
	return curvesSplit

def bm_averageEdgeLen(bm, vertsIdx, deflen):
	edgelenSum = 0
	edgelenCnt = 0
	edgelenSumAll = 0
	edgelenCntAll = 0
	for vIdx in vertsIdx:
		v = bm.verts[vIdx]
		for e in v.link_edges:
			edgelenSumAll = edgelenSumAll+e.calc_length()
			edgelenCntAll = edgelenCntAll+1
			if e.other_vert(v).index in vertsIdx:
				continue
			edgelenSum = edgelenSum+e.calc_length()
			edgelenCnt = edgelenCnt+1
	edgelenAvg = deflen
	if edgelenCnt>0:
		edgelenAvg = edgelenSum/edgelenCnt
	elif edgelenCntAll>0:
		edgelenAvg = edgelenSumAll/edgelenCntAll
	return edgelenAvg

def bm_selectVertEdgesFaces(bm, verts2sel, verts2selByCoKey = None):
	# flush selection/propagate selection/ensure selection/reselect all
	bpy.context.tool_settings.mesh_select_mode = (True, False, False) # 'VERT'
	bm.verts.ensure_lookup_table()
	bm.verts.index_update()
	bm.edges.ensure_lookup_table()
	bm.edges.index_update()
	bm.faces.ensure_lookup_table()
	bm.faces.index_update()
	bm_v = set()
	bm_e = set()
	bm_f = set()
	if verts2sel is None and verts2selByCoKey is not None:
		verts2sel = []
		for v in bm.verts:
			if wla.coToKey(v.co) in verts2selByCoKey:
				verts2sel.append(v.index)
	for vIdx in verts2sel:
		try:
			v = bm.verts[vIdx]
			v.select = True
			bm_v.add(v)
		except Exception as e:
			print("- bm_selectVertEdgesFaces: WARNING: invalid vert", vIdx)
			pass
	for edge in bm.edges:
		if (edge.verts[0] in bm_v) and (edge.verts[1] in bm_v):
			bm_e.add(edge)
			edge.select = True
	for face in bm.faces:
		e_sels = 0
		for e in face.edges:
			if e in bm_e:
				e_sels = e_sels+1
		if e_sels == len(face.edges):
			face.select = True
			bm_f.add(face)
	return bm_v, bm_e, bm_f

def bm_setPinmapFastIdx(active_obj, bm, pinId):
	bm.verts.ensure_lookup_table()
	bm.verts.index_update()
	bm.faces.ensure_lookup_table()
	bm.faces.index_update()
	pins_f = []
	pins_v = {}
	pins_f_disk = []
	for vert in bm.verts:
		pindat = {}
		isSelect = 0
		if vert.select:
			isSelect = 1
		isHide = 0
		if vert.hide>0:
			isHide = 1
		isSeam = 0
		for e in vert.link_edges:
			if e.seam:
				isSeam = 1
				break
		pindat["co"] = copy.copy(vert.co)
		vert_co_g = active_obj.matrix_world @ vert.co
		pindat["co_g"] = vert_co_g
		pindat["se"] = isSelect
		pindat["hi"] = isHide
		pindat["sm"] = isSeam
		# pindat["v-infl"] = 1.0 # Iterative Pin
		pins_v[vert.index] = pindat
	for f in bm.faces:
		if not f.select:
			continue
		if f.hide:
			continue
		faceverts = []
		f_radius_g = 0
		f_co_g = active_obj.matrix_world @ f.calc_center_median()
		f_no_g = (active_obj.matrix_world.inverted().transposed().to_3x3() @ f.normal).normalized()
		for vert in f.verts:
			v_co_g = active_obj.matrix_world @ vert.co
			faceverts.append(v_co_g)
			f_radius_g = max(f_radius_g, ( v_co_g - f_co_g ).length)
		pins_f.append(faceverts)
		pins_f_disk.append( (f_co_g, f_no_g, f_radius_g) )
	config.WPL_G.store[pinId] = pins_v
	config.WPL_G.store[pinId+"_selfaces"] = pins_f
	#config.WPL_G.store[pinId+"_selfaces_disk"] = pins_f_disk

def bm_getPinmapFastIdx(active_obj, bm, pinId):
	if pinId == '<pinconv>':
		bm2 = bmesh.new()
		hullv = []
		if kWPL_PINCONVEXKey not in config.WPL_G.store:
			return None, None
		lastVerts = config.WPL_G.store[kWPL_PINCONVEXKey]
		for v_co_g in lastVerts:
			v_co = v_co_g
			bm2v = bm2.verts.new(v_co)
			hullv.append(bm2v)
		if len(hullv) < 3:
			return None, None
		bm2.verts.ensure_lookup_table()
		bm2.verts.index_update()
		bmesh.ops.convex_hull(bm2, input=hullv, use_existing_faces = False)
		bm2.faces.ensure_lookup_table()
		bm2.faces.index_update()
		collFaces = []
		for f in bm2.faces:
			faceverts = []
			for vert in f.verts:
				v_co_g = copy.copy(vert.co)
				faceverts.append(v_co_g)
			collFaces.append(faceverts)
		return None, collFaces
	if pinId == "<collider>": # or pinId == "<collider-i>" or pinId == "<collider-b>":
		collFaces = []
		objs2checkAll = [obj for obj in bpy.data.objects]
		for obj in objs2checkAll:
			if obj.name == active_obj.name:
				continue
			if obj.hide_viewport == True or obj.type != 'MESH':
				continue
			isColl = False
			if "_collider" in obj.name:
				isColl = True
			if wla.modf_by_type(obj,'COLLISION'):
				isColl = True
			if isColl:
				print("- Collider found:",obj.name)
				modf_cache = {}
				wla_do.modf_toggle(obj, wla_do.kWPLModifsIndexBreakers, False, modf_cache)
				depsgraph = bpy.context.evaluated_depsgraph_get()
				bm_collide = bmesh.new()
				bm_collide.from_object(obj, depsgraph, cage = False, face_normals = True)
				if bm_collide is not None:
					# llayer = None
					# llayer_refcol = Vector((1,1,1)) # white
					# if pinId == "<collider-i>" or pinId == "<collider-b>":
					# 	llayer = bm_collide.loops.layers.color.get(config.kWPLTexDirVC)
					for f in bm_collide.faces:
						if f.hide:
							continue
						# if llayer is not None:
						# 	isWhiteIsland = False
						# 	for loop in f.loops:
						# 		col = Vector((loop[llayer][0],loop[llayer][1],loop[llayer][2]))
						# 		if (col-llayer_refcol).length < 0.01:
						# 			isWhiteIsland = True
						# 	if pinId == "<collider-b>":
						# 		isWhiteIsland = not isWhiteIsland
						# 	if isWhiteIsland == False:
						# 		continue
						faceverts = []
						for vert in f.verts:
							v_co_g = obj.matrix_world @ vert.co
							faceverts.append(v_co_g)
						collFaces.append(faceverts)
				wla_do.modf_toggle(obj, wla_do.kWPLModifsIndexBreakers, None, modf_cache)
		#print("- Collider faces:",len(collFaces))
		return None, collFaces
	if (pinId not in config.WPL_G.store):
		return None, None
	pins_v = config.WPL_G.store[pinId]
	verts_dat = {}
	faces_dat = []
	if pinId+"_selfaces" in config.WPL_G.store:
		faces_dat = config.WPL_G.store[pinId+"_selfaces"]
	if (bm is not None):
		bm.verts.ensure_lookup_table()
		bm.verts.index_update()
		bm.faces.ensure_lookup_table()
		bm.faces.index_update()
		for vert in bm.verts:
			verts_dat[vert.index] = {}
			if vert.index not in pins_v:
				verts_dat[vert.index]["co"] = Vector(vert.co)
				verts_dat[vert.index]["co_g"] = active_obj.matrix_world @ vert.co
				verts_dat[vert.index]["se"] = 0
				verts_dat[vert.index]["hi"] = 0
				verts_dat[vert.index]["sm"] = 0
				verts_dat[vert.index]["idx"] = 0
			else:
				idxpin = pins_v[vert.index]
				verts_dat[vert.index] = idxpin # need SAME object for "v-infl" to work
				verts_dat[vert.index]["co"] = Vector(idxpin["co"])
				verts_dat[vert.index]["co_g"] = Vector(idxpin["co_g"])
				# verts_dat[vert.index]["se"] = idxpin["se"]
				# verts_dat[vert.index]["hi"] = idxpin["hi"]
				# verts_dat[vert.index]["sm"] = idxpin["sm"]
				verts_dat[vert.index]["idx"] = vert.index
	return verts_dat, faces_dat

# def bm_edgeSegmented(active_bmesh, edgIdxList, opt_angleprc):
# 	active_bmesh.verts.ensure_lookup_table()
# 	active_bmesh.verts.index_update()
# 	active_bmesh.edges.ensure_lookup_table()
# 	active_bmesh.edges.index_update()
# 	segments = []
# 	def findEdgeChain(eIdx):
# 		for chn in segments:
# 			if (chn is not None) and (eIdx in chn):
# 				return chn
# 		return None
# 	def findEdgeNextFromVert(e1, e1v):
# 		edgeAngls = []
# 		for e2 in e1v.link_edges:
# 			if e2 == e1:
# 				continue
# 			if e2.index not in edgIdxList:
# 				continue
# 			# if edges share same face - not a chain.
# 			if not set(e1.link_faces).isdisjoint(set(e2.link_faces)):
# 				continue
# 			vec1 = (e1v.co-e1.other_vert(e1v).co).normalized()
# 			vec2 = (e2.other_vert(e1v).co-e1v.co).normalized()
# 			flowdot = vec2.dot(vec1)
# 			flowang = math.acos(max(min(flowdot,1.0),-1.0))
# 			edgeAngls.append( (e2, flowang, math.degrees(flowang)) )
# 		edgeAngls = sorted(edgeAngls, key=lambda pr: pr[1], reverse=False)
# 		if len(edgeAngls) > 0:
# 			edgNext = edgeAngls[0][0]
# 			if edgeAngls[0][1] < opt_angleprc or len(edgeAngls) == 1:
# 				#print("? edgeAngls", edgeAngls)
# 				return edgNext
# 		return None
# 	allPossibleConnections = {}
# 	for eIdx in edgIdxList:
# 		segments.append([eIdx])
# 		ed = active_bmesh.edges[eIdx]
# 		edNext1 = findEdgeNextFromVert(ed, ed.verts[0])
# 		edNext2 = findEdgeNextFromVert(ed, ed.verts[1])
# 		if edNext1 is not None:
# 			edNext1A = findEdgeNextFromVert(edNext1, edNext1.verts[0])
# 			edNext1B = findEdgeNextFromVert(edNext1, edNext1.verts[1])
# 			if (edNext1A is not None and edNext1A == ed) or (edNext1B is not None and edNext1B == ed):
# 				conn_key = str(min(eIdx, edNext1.index))+"_"+str(max(eIdx, edNext1.index))
# 				if conn_key not in allPossibleConnections:
# 					allPossibleConnections[conn_key] = [ed.index, edNext1.index]
# 		if edNext2 is not None:
# 			edNext2A = findEdgeNextFromVert(edNext2, edNext2.verts[0])
# 			edNext2B = findEdgeNextFromVert(edNext2, edNext2.verts[1])
# 			if (edNext2A is not None and edNext2A == ed) or (edNext2B is not None and edNext2B == ed):
# 				conn_key = str(min(eIdx, edNext2.index))+"_"+str(max(eIdx, edNext2.index))
# 				if conn_key not in allPossibleConnections:
# 					allPossibleConnections[conn_key] = [ed.index, edNext2.index]
# 	print("Segmenting edges, cnt:", len(edgIdxList),"allConns:", len(allPossibleConnections))
# 	for conn_key in allPossibleConnections:
# 		merge_pair = allPossibleConnections[conn_key]
# 		chn1 = findEdgeChain(merge_pair[0])
# 		chn2 = findEdgeChain(merge_pair[1])
# 		if (chn1 is not None) and (chn2 is not None) and chn1 != chn2:
# 			for eccIdx in chn2:
# 				chn1.append(eccIdx)
# 			del chn2[:]
# 	segments_noEmpty = []
# 	segments = sorted(segments, key=lambda pr: len(pr), reverse=True)
# 	segments_byLen = {}
# 	for chn in segments:
# 		if chn is not None and len(chn) > 0:
# 			if len(chn) not in segments_byLen:
# 				segments_byLen[len(chn)] = 0
# 			segments_byLen[len(chn)] = segments_byLen[len(chn)]+1
# 			segments_noEmpty.append(chn)
# 	print("- found segments:", segments_byLen)
# 	return segments_noEmpty


def bm_vertsToKdtree(obj, bm, ignoreIdx):
	research_tree = KDTree(len(bm.verts))
	for vert in bm.verts:
		if ignoreIdx is not None and vert.index in ignoreIdx:
			continue
		if obj is not None:
			research_tree.insert(obj.matrix_world @ vert.co, vert.index)
		else:
			research_tree.insert(vert.co, vert.index)
	research_tree.balance()
	return research_tree

def bm_sceneColldersBVH(forObj, allowSelf):
	# if forObj == None -> BVH is Global
	matrix_world_inv = None
	if forObj is not None:
		matrix_world = forObj.matrix_world
		matrix_world_inv = matrix_world.inverted()
	objs2checkAll = [obj for obj in bpy.data.objects]
	bvh2collides = []
	depsgraph = bpy.context.evaluated_depsgraph_get()
	for obj in objs2checkAll:
		if allowSelf == False and forObj is not None and obj.name == forObj.name:
			continue
		if obj.hide_viewport == True: #  or (obj.hide_viewport and obj.hide_render)
			continue
		isColl = False
		if "_collider" in obj.name:
			isColl = True
		if wla.modf_by_type(obj,'COLLISION'):
			isColl = True
		if isColl:
			print("- Collider found:",obj.name)
			bm_collide = None
			if obj.type != 'MESH':
				continue
			# 	sel_mesh = None
			# 	try:
			# 		sel_mesh = obj.to_mesh(bpy.context.scene, True, 'PREVIEW')
			# 	except:
			# 		pass
			# 	if sel_mesh is not None:
			# 		bm_collide = bmesh.new()
			# 		bm_collide.from_mesh(sel_mesh)
			# 		bpy.data.meshes.remove(sel_mesh)
			else:
				bm_collide = bmesh.new()
				bm_collide.from_object(obj, depsgraph, cage = False, face_normals = True)
			if bm_collide is not None:
				hiddenFaces = []
				for bm2f in bm_collide.faces:
					if bm2f.hide and bm2f not in hiddenFaces:
						hiddenFaces.append(bm2f)
				if len(hiddenFaces)>0:
					bmesh.ops.delete(bm_collide, geom=hiddenFaces, context='FACES')
				bm_collide.transform(obj.matrix_world)
				if matrix_world_inv is not None:
					bm_collide.transform(matrix_world_inv)
				bmesh.ops.recalc_face_normals(bm_collide, faces=bm_collide.faces)
				bm_collide.verts.ensure_lookup_table()
				bm_collide.faces.ensure_lookup_table()
				bm_collide.verts.index_update()
				bvh_collide = BVHTree.FromBMesh(bm_collide, epsilon = config.kWPLRaycastEpsilon)
				bm_collide.free()
				bvh2collides.append(bvh_collide)
	return bvh2collides

def bm_fuzzyBVHRayCast_v01(bvh_or_depg, vFrom, vDir, fuzzyVal, fuzzyQual, fuzzyMethod):
	depsgraph = None
	if isinstance(bvh_or_depg, bpy.types.Depsgraph):
		depsgraph = bvh_or_depg
		bvh_or_depg = None
	vDir = vDir.normalized()
	vDirs = [ (vFrom, vDir) ]
	if fuzzyQual is not None and int(fuzzyQual) != 0:
		# fuzzyQual>0: conus fuziness. From-point not altering
		# fuzzyQual<0: plane fuziness. Direction not altering
		isConusAltering = True
		if fuzzyQual<0:
			isConusAltering = False
			fuzzyQual = abs(fuzzyQual)
		fuzzyQual = int(fuzzyQual)
		_, _, _, camera_gDirUp = wla.active_camera()
		if(math.fabs(vDir.dot(camera_gDirUp)) > 0.9):
			camera_gDirUp = mathutils.Vector((0,1,0))
		perp1 = vDir.cross(camera_gDirUp).normalized()
		perp2 = vDir.cross(perp1).normalized()
		if perp1.length < 0.0001 or perp2.length < 0.0001:
			print("fuzzySceneRayCast: failed to get perps", vDir)
			return (None, None)
		#print("fuzzySceneRayCast: perp preps", vDir, perp1, perp2, fuzzyVal)
		vDirs = []
		for i in range(-fuzzyQual,fuzzyQual+1):
			for j in range(-fuzzyQual,fuzzyQual+1):
				facI = (float(i)/float(fuzzyQual))
				facJ = (float(j)/float(fuzzyQual))
				if isConusAltering:
					vDir_shift = vDir + facI*perp1*fuzzyVal + facJ*perp2*fuzzyVal
					#print("- shootDir", vDir_shift, facI, facJ)
					vDirs.append( (vFrom, vDir_shift.normalized()) )
				else:
					vFrom_shift = vFrom + facI*perp1*fuzzyVal + facJ*perp2*fuzzyVal
					vDirs.append( (vFrom_shift, vDir) )
		# vDirs = [vDir]
		# for i in range(0,fuzzyQual):
		# 	delim = float(i+1)/float(fuzzyQual)
		# 	for j in range(0,fuzzyQual):
		# 		rotang = math.pi*2*float(j)/float(fuzzyQual)
		# 		rot = Matrix.Rotation(rotang, 4, vDir)
		# 		perp1r = rot @ perp1
		# 		perp2r = rot @ perp2
		# 		dirslices = [(vDir+delim*perp1r*fuzzyVal).normalized(), (vDir-delim*perp1r*fuzzyVal).normalized(), (vDir+delim*perp2r*fuzzyVal).normalized(), (vDir-delim*perp2r*fuzzyVal).normalized()]
		# 		#print("fuzzySceneRayCast part", vDir, fuzzyVal, delim, rotang, perp1r, perp2r, dirslices)
		# 		vDirs.extend(dirslices)
	hits = []
	for shootItm in vDirs:
		shootDir = shootItm[1]
		shootPos = shootItm[0]
		loc_g = None
		normal_g = None
		if bvh_or_depg is not None:
			loc_g, normal_g, _, _ = bvh_or_depg.ray_cast(shootPos + shootDir*config.kWPLRaycastEpsilon, shootDir)
			#print("fuzzySceneRayCast bvh", vFrom, shootDir, loc_g)
		elif depsgraph is not None:
			# scene cast
			# per-pixel cast: https://blender.stackexchange.com/questions/115285/how-to-do-a-ray-cast-from-camera-originposition-to-object-in-scene-in-such-a-w
			ress, loc_g, normal_g, _, loc_obj, _ = depsgraph.scene_eval.ray_cast(depsgraph, shootPos + shootDir*config.kWPLRaycastEpsilon, shootDir)
			if ress == False:
				ress = True # Faking hit to far plane
				loc_g = vFrom + vDir*999
				normal_g = -1*vDir
			#print("fuzzySceneRayCast scene", ress, shootPos, shootDir, loc_g, loc_obj)
		if loc_g is not None:
			hits.append( (loc_g, normal_g) )
	if len(hits)>0:
		gCount = len(hits)
		gResultCo = mathutils.Vector((0,0,0))
		gResultNormal = mathutils.Vector((0,0,0))
		for hit_dat in hits:
			gResultCo = gResultCo+hit_dat[0]
			gResultNormal = gResultNormal+hit_dat[1]
		gResultCo = gResultCo/gCount
		gResultNormal = (gResultNormal/gCount).normalized()
		if fuzzyMethod == 'MIN_ON_DIR' or fuzzyMethod == 'AVG_ON_DIR' or fuzzyMethod == 'MAX_ON_DIR':
			# closest/avg point + shift on dir
			maxDir = -999
			minDir = 999
			avgDir = 0
			for hit_dat in hits:
				dst = (vFrom - hit_dat[0]).length
				minDir = min(minDir, dst)
				maxDir = max(maxDir, dst)
				avgDir = avgDir + dst
				gResultNormal = gResultNormal+hit_dat[1]
			if fuzzyMethod == 'MIN_ON_DIR':
				gResultCo = vFrom+vDir*minDir
			if fuzzyMethod == 'AVG_ON_DIR':
				gResultCo = vFrom+vDir*(avgDir / gCount)
			if fuzzyMethod == 'MAX_ON_DIR':
				gResultCo = vFrom+vDir*maxDir
			return (gResultCo, gResultNormal)
		return (gResultCo, gResultNormal)
	return (None, None)


def bm_BVHFromFaces(src_bm, src_faces):
	# https://github.com/oscurart/BlenderAddons/blob/0f732228e45593bde1670c46d8e3e070e992a76c/oscurart_select_intersect_faces.py
	# bvhIndex != bm.face index!!!
	bvh_polySel = [poly.index for poly in src_bm.faces if poly.index in src_faces]
	bvh_vertSel = list(set([v.index for pIdx in bvh_polySel for v in src_bm.faces[pIdx].verts]))
	bvh_vertSel.sort()
	bvh_vertIdx = {v:i for i,v in enumerate(bvh_vertSel)}
	bvh_coVerts = [src_bm.verts[vIdx].co[:] for vIdx in bvh_vertSel]
	bvh_polyVerts = [[bvh_vertIdx[v.index] for v in src_bm.faces[pIdx].verts] for pIdx in bvh_polySel]
	bmesh_bvh_ini_l = BVHTree.FromPolygons(bvh_coVerts,bvh_polyVerts)
	return bmesh_bvh_ini_l, bvh_polySel

def bm_BVHFromFacesIdx(obj, bm, facesIdx, useWorld):
	if (facesIdx is None) or (len(facesIdx) == 0) or (bm is None):
		return None
	bm2 = bmesh.new()
	bm2vmap = {}
	bm2conv = []
	for f in bm.faces:
		#if f.select == False:
		#	continue
		if f.index not in facesIdx:
			continue
		f_v_set = []
		f_v_set_ko = []
		for v in f.verts:
			v_co = v.co
			if useWorld and obj is not None:
				v_co = obj.matrix_world @ v_co
			vert_index = wla.coToKey(v_co)
			if vert_index not in bm2vmap:
				v_cc = bm2.verts.new(v_co)
				bm2vmap[vert_index] = v_cc
			else:
				v_cc = bm2vmap[vert_index]
			if v_cc not in f_v_set:
				f_v_set.append(v_cc)
				f_v_set_ko.append(vert_index)
		if len(f_v_set) >= 3:
			f_v_set_ko = sorted(f_v_set_ko)
			f_v_set_ko = ",".join(f_v_set_ko)
			if f_v_set_ko not in bm2vmap:
				bm2vmap[f_v_set_ko] = f_v_set
				f_cc = bm2.faces.new(f_v_set)
	bm2.normal_update()
	bvh_orig = BVHTree.FromBMesh(bm2, epsilon = config.kWPLRaycastEpsilon)
	bm2.free()
	return bvh_orig

# def bm_vertFindOnBvh(srcBVH, originCo, originVec):
# 	#return originCo, originCo+originVec
# 	# need point on bm/bvh that is originVec from originCo - but shrinkwrapped on same distance
# 	o_shrw_loc, o_shrw_nrm, _, _ = srcBVH.find_nearest(originCo, 999)
# 	if o_shrw_loc is None:
# 		return None, None
# 	originLen = originVec.length
# 	s_shrw_loc = o_shrw_loc + originVec.normalized()*originLen
# 	# for i in range(2):
# 	# 	s_shrw_loc, _, _, _ = srcBVH.find_nearest(s_shrw_loc, 999)
# 	# 	s_shrw_loc = o_shrw_loc+(s_shrw_loc-o_shrw_loc).normalized()*originLen
# 	s_shrw_loc, _, _, _ = srcBVH.find_nearest(s_shrw_loc, 999)
# 	return o_shrw_loc, s_shrw_loc 

# *** *** *** *** *** *** *** *** *** *** *** *** *** *** *** *** *** ***

def bm_vertsPropagations_v02(bm, initialVertsIdx, max_loops):
	# propagation through edges and VISIBLE verts
	propagation_stages = []
	allWalkedVerts = []
	vertsFromIdx = {}
	#vertsFromRootIdx = {}
	vertsAddWeight = {}
	checked_verts = copy.copy(initialVertsIdx)
	for stage in range(1,int(max_loops)+1):
		stage_verts = []
		checked_verts_cc = copy.copy(checked_verts)
		for v_idx in checked_verts_cc:
			v = bm.verts[v_idx]
			allWalkedVerts.append(v_idx)
			for edg in v.link_edges:
				v2 = edg.other_vert(v)
				if v2.hide == 0 and v2.index not in checked_verts_cc:
					if v2.index not in checked_verts:
						checked_verts.append(v2.index)
					if(v2.index not in stage_verts):
						vertsAddWeight[v2.index] = 1.0-(1.0+len(propagation_stages))/(1.0+max_loops)
						stage_verts.append(v2.index)
						vertsFromIdx[v2.index] = []
					if v_idx not in vertsFromIdx[v2.index]:
						vertsFromIdx[v2.index].append(v_idx)
		if len(stage_verts) == 0:
			break
		propagation_stages.append(stage_verts)
	return (propagation_stages, vertsAddWeight, allWalkedVerts, vertsFromIdx)

def bm_vertExtendByFaces(v, verts_set_out, max_loops, ignoreHidden):
	if (v in verts_set_out):
		return
	verts_set_out.add(v)
	for f in v.link_faces:
		if ignoreHidden == False and f.hide == True:
			continue
		for ov in f.verts:
			if (ov is None) or (ov in verts_set_out):
				continue
			if ignoreHidden == False and ov.hide == True:
				continue
			if max_loops > 0:
				bm_vertExtendByFaces(ov, verts_set_out, max_loops-1, ignoreHidden)

def bm_vertExtendByEdges(v, edges_set_out, max_loops, ignoreHidden, limit2verts):
	for e in v.link_edges:
		if ignoreHidden and e.hide:
			continue
		if (e in edges_set_out):
			continue
		vOther = e.other_vert(v)
		if (limit2verts is not None) and (vOther.index not in limit2verts):
			continue
		edges_set_out.add(e)
		if max_loops > 0:
			bm_vertExtendByEdges(vOther, edges_set_out, max_loops-1, ignoreHidden, limit2verts)


def bm_vertsInitSeamBnd(bm, selvertsAll):
	originalPos = {}
	originalNrm = {}
	bound_verts = []
	seam_verts = []
	for vIdx in selvertsAll:
		v = bm.verts[vIdx]
		originalPos[vIdx] = Vector(v.co)
		originalNrm[vIdx] = Vector(v.normal)
		isNonSelLink = False
		for e in v.link_edges:
			if e.seam:
				seam_verts.append(vIdx)
			if not(e.other_vert(v).index in selvertsAll):
				isNonSelLink = True
				break
		for f in v.link_faces:
			if f.hide:
				isNonSelLink = True
				break
			# for fv in f.verts:
			# 	if not(fv in selvertsAll) or fv.hide:
			# 		isNonSelLink = True
			# 		break
		if isNonSelLink or v.is_boundary:
			bound_verts.append(vIdx)
	return bound_verts, seam_verts, originalPos, originalNrm

def bm_vertIsBoundary(bm_v, checkBnd, checkSeam, checkVertsIdx):
	if checkVertsIdx is not None:
		for e in bm_v.link_edges:
			if e.other_vert(bm_v).index not in checkVertsIdx:
				return True
	if checkBnd:
		if bm_v.is_boundary:
			return True
		if len(bm_v.link_faces) <= 2:
			return True
	if checkSeam:
		for e in bm_v.link_edges:
			if e.seam:
				return True
	return False

def bm_vertIsNecklace(bm_v):
	if len(bm_v.link_faces) == 1:
		if all([ len(e.link_faces) == 1 for e in bm_v.link_faces[0].edges]):
			return True
	return False

def bm_vertSecondAxisVert(bm_v, referVerts, ignoreHidden):
	# stable selection of reference vertex
	# necklace face -> "left" vert
	# wire -> bound -> seam -> shortest
	if bm_vertIsNecklace(bm_v):
		#print("- necklace case")
		# necklace-face: using "left" vertex as refpoint for consistency
		neck_f = bm_v.link_faces[0]
		f_center = neck_f.calc_center_median()
		for e in bm_v.link_edges:
			eDir = (bm_v.co-e.other_vert(bm_v).co).normalized()
			if wla.math_vecIsLeft(eDir, f_center-bm_v.co, neck_f.normal):
				return e.other_vert(bm_v)
		return bm_v.link_edges[0].other_vert(bm_v)
	# different checks to enforce priority
	for e in bm_v.link_edges:
		v2 = e.other_vert(bm_v)
		if e.is_wire:
			return v2
	verts2skip = []
	for e in bm_v.link_edges:
		v2 = e.other_vert(bm_v)
		if (referVerts is not None) and (v2.index in referVerts):
			verts2skip.append(v2.index)
			continue
		if ignoreHidden and v2.hide:
			verts2skip.append(v2.index)
			continue
	for e in bm_v.link_edges:
		v2 = e.other_vert(bm_v)
		if (v2.index in verts2skip):
			continue
		if bm_vertIsBoundary(v2, True, False, None):
			return v2
	for e in bm_v.link_edges:
		v2 = e.other_vert(bm_v)
		if (v2.index in verts2skip):
			continue
		if bm_vertIsBoundary(v2, False, True, None):
			return v2
	# last restorts
	for e in bm_v.link_edges:
		v2 = e.other_vert(bm_v)
		if (referVerts is not None):
			# possible RVert must have at least 2 verts in common
			# or edgelines may pick bad verts on head/tail
			commv = []
			for v2f in v2.link_faces:
				for v3 in v2f.verts:
					if v3.index == bm_v or v3.index in referVerts:
						if v3.index not in commv:
							commv.append(v3.index)
			if len(commv) < 2:
				verts2skip.append(v2.index)
				continue
			#print("- commv", bm_v.index, commv)
	targetClosestV2 = None
	targetClosestLen = 999
	for e in bm_v.link_edges:
		v2 = e.other_vert(bm_v)
		if (v2.index in verts2skip):
			continue
		diff = (v2.co-bm_v.co).length
		if diff < targetClosestLen:
			targetClosestV2 = v2
			targetClosestLen = diff
		# v2_c_dot = (v2.co-bm_v.co).normalized().dot( Vector((0.0, 0.0, 1.0)) )
		# if v2_c_dot > targetClosestDotZ:
		# 	targetClosestDotZ = v2_c_dot
		# 	targetClosestV2 = v2
		# 	#v2.select = True
	if targetClosestV2 is not None:
		return targetClosestV2
	return None

def bm_geodesicDistmap_v05(bme, initial_vertCurves, maxloops, maxdist, walkFacesToo, walkHidden, limit2vertsAll = None, limit2vertsBorder = None):
	# also: https://github.com/alessandro-zomparelli/tissue/blob/master/weight_tools.py
	# - tissue_weight_distance fill_neighbors
	# counting propagations
	# WAS: should be 100% stable - Symmetry stuff based on this
	# NOW: Special unwrap for symm, no need for stable extras...
	##initial_vIdx = bm_sortVertsByConnection(bme, initial_vIdx, True, walkFacesToo)
	#initial_vertCurves = bm_splitVertsByConnection(bme, initial_vIdx, True, None, None)
	# print("IniCurves", initial_vertCurves)
	# recreating initials with initial vertexes list - for left/right
	initial_vIdx = []
	initial_start_vIdx = []
	initial_end_vIdx = []
	for curve in initial_vertCurves:
		start_vIdx = curve[0]
		end_vIdx = start_vIdx
		for vIdx in curve:
			initial_vIdx.append(vIdx)
			end_vIdx = vIdx
		initial_start_vIdx.append(start_vIdx)
		initial_end_vIdx.append(end_vIdx)
	vertDistMap = {}
	vertOriginMap = {}
	vertStepMap = {}
	if maxdist is None:
		maxdist = 999
	# print("- initial_vIdx", initial_vIdx)
	step_vIdx = []
	for vIdx in initial_vIdx:
		vertDistMap[vIdx] = 0.0
		vertOriginMap[vIdx] = vIdx
		step_vIdx.append(vIdx)
	lastStep = -1
	for curStep in range(maxloops):
		for vIdx in step_vIdx:
			if vIdx not in vertStepMap:
				vertStepMap[vIdx] = curStep+1
			if vIdx not in vertDistMap:
				vertDistMap[vIdx] = 0.0
		nextStepIdx = {}
		vertDistMapAvgs = {}
		for vIdx in step_vIdx:
			vThis = bme.verts[vIdx]
			vFrom = vThis
			nearVers = []
			if walkFacesToo:
				# across faces
				for f in vThis.link_faces:
					for fv in f.verts:
						if (fv not in nearVers) and (fv.index not in vertStepMap):
							nearVers.append(fv)
			else:
				# across edges
				for e in vThis.link_edges:
					fv = e.other_vert(vThis)
					if (fv not in nearVers) and (fv.index not in vertStepMap):
						nearVers.append(fv)
			# if vIdx == 524: # DBG
			# 	print("- nearVers 524", nearVers)
			for fv in nearVers:
				if walkHidden == False and fv.hide != 0:
					continue
				if (limit2vertsAll is not None) and (fv.index not in limit2vertsAll):
					continue
				#if fv.index not in vertStepMap: # checked already
				fv_diff = (fv.co - vFrom.co).length
				fv_fulldst = vertDistMap[vIdx] + fv_diff
				if fv.index not in vertDistMapAvgs:
					vertDistMapAvgs[fv.index] = (vertDistMap[vIdx], 1, fv_diff)
				else:
					vertDistMapAvgs[fv.index] = ( vertDistMapAvgs[fv.index][0], vertDistMapAvgs[fv.index][1]+1.0 , vertDistMapAvgs[fv.index][2]+fv_diff )
				if fv.index not in vertDistMap:
					nextStepIdx[fv.index] = vIdx
					vertDistMap[fv.index] = fv_fulldst
					vertOriginMap[fv.index] = vertOriginMap[vIdx]
				else:
					if (fv_fulldst < vertDistMap[fv.index]):
						nextStepIdx[fv.index] = vIdx
						vertDistMap[fv.index] = fv_fulldst
						vertOriginMap[fv.index] = vertOriginMap[vIdx]
		# averaging/max reached distances at current step, if any
		for vIdx in vertDistMapAvgs:
			#vertDistMap[vIdx] = vertDistMapAvgs[vIdx][0] + vertDistMapAvgs[vIdx][2]/vertDistMapAvgs[vIdx][1]
			vertDistMap[vIdx] = max(vertDistMapAvgs[vIdx][0], vertDistMap[vIdx]) # better
		# print("- step",curStep+1,len(step_vIdx),len(nextStepIdx))
		if curStep == 0:
			doErrorNotf = True
			for vIdx in nextStepIdx:
				# vert derived from original vert
				# inverting index for left-placed vers
				origin_vIdx = abs(vertOriginMap[vIdx])
				origin_v = bme.verts[origin_vIdx]
				origFindIdx = initial_vIdx.index(origin_vIdx)
				init_vIdxOrdered = [(origin_v, origFindIdx, origin_v.index)]
				for ove in origin_v.link_edges:
					origin_v2 = ove.other_vert(origin_v)
					if origin_v2.index in initial_vIdx:
						sideFindIdx = initial_vIdx.index(origin_v2.index)
						#print("- cirkular check:", origin_v.index, origin_v2.index)
						if origin_v.index in initial_start_vIdx:
							if abs(sideFindIdx-origFindIdx) > 1.0:
								# special case - cirkular stuff
								#print("- cirkular stuff: start fix", origin_v.index, origin_v2.index, origFindIdx, sideFindIdx)
								sideFindIdx = origFindIdx-1
						if origin_v.index in initial_end_vIdx:
							if abs(sideFindIdx-origFindIdx) > 1.0:
								# special case - cirkular stuff
								#print("- cirkular stuff: end fix", origin_v.index, origin_v2.index, origFindIdx, sideFindIdx)
								sideFindIdx = origFindIdx+1
						init_vIdxOrdered.append( (origin_v2, sideFindIdx, origin_v2.index) )
				if len(init_vIdxOrdered) >= 2:
					v = bme.verts[vIdx]
					init_vIdxOrdered = sorted(init_vIdxOrdered, key=lambda pr: pr[1], reverse=False)
					#print("- lefter:", init_vIdxOrdered)
					#flow_dir = (init_vIdxOrdered[-1][0].co - init_vIdxOrdered[-2][0].co).normalized()
					flow_dir = (init_vIdxOrdered[-1][0].co - init_vIdxOrdered[0][0].co).normalized()
					check_dir = (v.co - origin_v.co).normalized()
					if wla.math_vecIsLeft(check_dir, flow_dir, origin_v.normal) < 0:
						vertOriginMap[vIdx] = -1 * abs(vertOriginMap[vIdx])
						# print("- lefter", vIdx, "from", origin_vIdx, init_vIdxOrdered)
				# else:
				# 	if doErrorNotf:
				# 		print("- lefter/right preparation failed: not enough data, skipping")
				# 		doErrorNotf = False
		step_vIdx = []
		for vIdxNext in nextStepIdx:
			isOk = True
			if vertDistMap[vIdxNext] > maxdist:
				isOk = False
			if (limit2vertsBorder is not None) and (vIdxNext in limit2vertsBorder):
				isOk = False
			# if walkNonQuad == False:
			# 	# if any non-quad
			# 	vThis = bme.verts[vIdxNext]
			# 	for fvf in vThis.link_faces:
			# 		if len(fvf.verts) != 4:
			# 			isOk = False
			# 			break
			if isOk:
				# print("- adding next", vIdxNext, vertFromMap[vIdxNext], vertDistMap[vIdxNext], vertOriginMap[vIdxNext])
				step_vIdx.append(vIdxNext)
		lastStep = curStep
		if len(step_vIdx) == 0:
			#print("- walk stopped at", curStep)
			break
	# if lastStep<0:
	# 	print("- WARNING: not enough steps", maxloops)
	# adding step for last verts
	# vertStepMap: 1...max
	if lastStep > 0:
		for vIdx in step_vIdx:
			if vIdx not in vertStepMap:
				vertStepMap[vIdx] = lastStep+2
	vertLeftList = []
	for vIdx in vertDistMap:
		if vertOriginMap[vIdx] < 0:
			vertOriginMap[vIdx] = abs(vertOriginMap[vIdx])
			vertLeftList.append(vIdx)
	# vertLeftList - not including originals
	# vertDistMap - including originals (ditance 0.0)
	return vertDistMap, vertStepMap, vertLeftList, vertOriginMap

def bm_geodesicBisecter(bm, initial_vertCurves, maxloops, maxdist, withOrderedSort):
	curve0 = []
	# removing doubles (can be present in VGS+CUTLINE, last == first)
	for vIdx in initial_vertCurves[0]:
		if vIdx not in curve0:
			curve0.append(vIdx)
	joinVertsData = []
	# if (maxdist is not None) and (maxdist < 0.0001): # OK, but need consistent first (for VGS)
	# 	vertIn = curve0
	# 	for vIdx in vertIn:
	# 		vi = bm.verts[vIdx]
	# 		joinVertsData.append( [vi.co.copy(), vi.index, 0, None] )
	# 	return vertIn, joinVertsData, {}
	vertDistMap, _, vertLeftList, vertOriginMap = bm_geodesicDistmap_v05(bm, [curve0], maxloops, maxdist, True, False)
	vertIn = vertDistMap.keys()
	walkedVerts = set()
	for vIdx in vertIn:
		vi = bm.verts[vIdx]
		edges = [e for e in vi.link_edges]
		for e in edges:
			vo = e.other_vert(vi)
			if vo.index in vertDistMap:
				if abs(vertDistMap[vi.index]-maxdist)<0.00001:
					if vi.index not in walkedVerts:
						walkedVerts.add(vi.index)
						joinVertsData.append( [vi.co.copy(), vi.index, vertOriginMap[vi.index], None] )
				elif abs(vertDistMap[vo.index]-maxdist)<0.00001:
					if vo.index not in walkedVerts:
						walkedVerts.add(vo.index)
						joinVertsData.append( [vo.co.copy(), vo.index, vertOriginMap[vo.index], None] )
				elif vertDistMap[vi.index] > maxdist and vertDistMap[vo.index] < maxdist:
					prc = (maxdist-vertDistMap[vo.index])/(vertDistMap[vi.index]-vertDistMap[vo.index])
					newv_co = vo.co+prc*(vi.co-vo.co)
					# joinVertsData.append( [newv_co, vo.index, vertOriginMap[vo.index], e.index] ) # vo.index == initial vert in one-loop zone around curve -> PROBLEM
					joinVertsData.append( [newv_co, e.other_vert(vo).index, vertOriginMap[vo.index], e.index] )
	if withOrderedSort and len(curve0) >= 2:
		# need to sort in order, according to initial_vertCurves order AND circular stepping
		# like bm_sortVertsByConnection
		# first vert must be "definite start vert", imprtant for VGS stripes stability
		curve0_ori0 = bm.verts[curve0[0]]
		curve0_ori1 = bm.verts[curve0[1]]
		lclX = (curve0_ori1.co-curve0_ori0.co).normalized()
		mindst = 999
		exhpos = -1
		for jj in range(1, len(joinVertsData)):
			itm2 = joinVertsData[jj]
			testDir2 = (itm2[0]-curve0_ori0.co).normalized()
			dirDot2 = testDir2.dot(lclX)
			#if (itm2[0]-curve0_ori0_co).length < (itm1[0]-curve0_ori0_co).length:
			#if wla.arrIndexOf(curve0, itm2[2], -1) < wla.arrIndexOf(curve0, itm1[2], -1):
			ll = dirDot2 + wla.arrIndexOf(curve0, itm2[2], -1)*10
			if ll < mindst:
				mindst = ll
				exhpos = jj
		if exhpos >= 0:
			itm1 = joinVertsData[0]
			joinVertsData[0] = joinVertsData[exhpos]
			joinVertsData[exhpos] = itm1
		for ii in range(len(joinVertsData)-1):
			itm1 = joinVertsData[ii]
			exhpos = -1
			if exhpos < 0:
				# base vert in linked verts - same leftness
				mindst = 9999
				itm1_link_vIdx = set()
				itm1_link_vIdx.add(itm1[1])
				itm1_v = bm.verts[itm1[1]]
				#itm1_vO = bm.verts[itm1[2]]
				for vf in itm1_v.link_faces:
					for vfv in vf.verts:
						itm1_link_vIdx.add( vfv.index )
				for jj in range(ii+1, len(joinVertsData)):
					itm2 = joinVertsData[jj]
					if itm2[1] not in itm1_link_vIdx:
						continue
					lftDiff = abs(wla.arrIndexOf(vertLeftList, itm2[1], 0, 1) - wla.arrIndexOf(vertLeftList, itm1[1], 0, 1))
					idxDiff = abs(wla.arrIndexOf(curve0, itm2[2], 0) - wla.arrIndexOf(curve0, itm1[2], 0))
					# local leftness
					#lclX = (itm1_vO.co-itm1_v.co).normalized()
					#lftDiff2 = wla.math_vecIsLeft((itm2[0]-itm1[0]), lclX, curve0_ori0.normal)
					ll = (itm2[0]-itm1[0]).length + 10*idxDiff + 20*lftDiff
					if ll < mindst:
						mindst = ll
						exhpos = jj
			if exhpos < 0:
				# any other vert - with leftness - with order
				mindst = 9999
				for jj in range(ii+1, len(joinVertsData)):
					itm2 = joinVertsData[jj]
					oriDiff = 0
					if itm2[1] != itm1[1]:
						oriDiff = oriDiff+1
					idxDiff = abs(wla.arrIndexOf(curve0, itm2[2], 0) - wla.arrIndexOf(curve0, itm1[2], 0))
					lftDiff = abs(wla.arrIndexOf(vertLeftList, itm2[1], 0, 1) - wla.arrIndexOf(vertLeftList, itm1[1], 0, 1))
					ll = (itm2[0]-itm1[0]).length + 10*idxDiff + 20*lftDiff + 5*oriDiff
					if ll < mindst:
						mindst = ll
						exhpos = jj
			if exhpos >= 0:
				t = joinVertsData[ii+1]
				joinVertsData[ii+1] = joinVertsData[exhpos]
				joinVertsData[exhpos] = t
			else:
				print("- bm_geodesicBisecter: ordering failed")
				break
	return vertIn, joinVertsData, vertDistMap

def bm_geodesicDistmapAlong_v01(bm, zeros_vIdx, curves_vIdx, curves_vertOrigMap, zeros_vertDistMap):
	vertDistMap = {}
	vertLeftList = set()
	vertStepMap = {}
	eCache = {}
	for v in bm.verts:
		if v.index not in curves_vertOrigMap:
			# ignoring
			continue
		vOnCurveIdx = curves_vertOrigMap[v.index]
		for i, curve in enumerate(curves_vIdx):
			if vOnCurveIdx not in curve:
				continue
			# this curve!
			vOnCurveZeroIdx = None
			for vZerIdx in zeros_vIdx:
				if vZerIdx in curve:
					vOnCurveZeroIdx = vZerIdx
					break
			if vOnCurveZeroIdx is None:
				continue
			# this curve and this zero point!
			idxV = curve.index(vOnCurveIdx)
			idxZ = curve.index(vOnCurveZeroIdx)
			if idxV == idxZ:
				vertLeftList.add(v.index)
				vertDistMap[v.index] = 0
				vertStepMap[v.index] = 0
				continue
			vertStepMap[v.index] = abs(idxV-idxZ)
			curve_betweens = []
			if idxZ < idxV:
				vertLeftList.add(v.index)
			curve_betweens = curve[min(idxV,idxZ):max(idxV,idxZ)]
			curve_betweens.append(vOnCurveIdx)
			curve_betweens.append(vOnCurveZeroIdx)
			loopDst = abs(idxV-idxZ)+1
			vertDistMap[v.index] = loopDst # in loops
			if type(zeros_vertDistMap) == bool:
				if zeros_vertDistMap == True:
					# need to calc precise edge-distance
					v_v_key = str(i)+"_"+str(min(idxV,idxZ))+"_"+str(max(idxV,idxZ))
					if v_v_key not in eCache:
						edgesDst = 0
						edgesBetween = set()
						bm_vertExtendByEdges(bm.verts[vOnCurveZeroIdx], edgesBetween, 999, False, curve_betweens)
						for e in edgesBetween:
							edgesDst = edgesDst + e.calc_length()
						# print("- ", v.index, vOnCurveIdx, len(edgesBetween), edgesDst)
						eCache[v_v_key] = edgesDst
					vertDistMap[v.index] = eCache[v_v_key]
			elif zeros_vertDistMap is not None:
				# map with needed distances
				if vOnCurveIdx in zeros_vertDistMap:
					vertDistMap[v.index] = zeros_vertDistMap[vOnCurveIdx]
	# vertStepMap: 0...max-1
	return vertDistMap, vertStepMap, list(vertLeftList)

# def bm_pointcloudDistmap_v01(acitve_obj, bme, vpc_co):
# 	distmap_U = {}
# 	distmap_V = {}
# 	if len(vpc_co) == 0:
# 		return distmap_U, distmap_V
# 	#_, _, camera_gDir, camera_gDirUp = wla.active_camera()
# 	#camera_gDirLeft = camera_gDir.cross(camera_gDirUp)
# 	#camMatrix = wla.math_matrix4axis(None, camera_gDirUp, camera_gDirLeft, 0)
# 	dots_tree_all = KDTree(len(vpc_co))
# 	pc_co_cnt_g = Vector((0,0,0))
# 	for i, pc_co_g in enumerate(vpc_co):
# 		dots_tree_all.insert(pc_co_g, i)
# 		pc_co_cnt_g = pc_co_cnt_g+pc_co_g
# 	pc_co_cnt_g = pc_co_cnt_g/len(vpc_co)
# 	#pc_cam_look_g = pc_co_cnt_g - camera_gCo
# 	dots_tree_all.balance()
# 	dist_min = 999
# 	dist_max = 0
# 	for v in bme.verts:
# 		v_co_g = acitve_obj.matrix_world @ v.co
# 		nearptsEdges = dots_tree_all.find_n(v_co_g,5)
# 		if len(nearptsEdges) > 0:
# 			n_co_g = None
# 			nearptsEdges.sort(key=lambda itm: itm[2], reverse=False)
# 			if len(nearptsEdges) < 2:
# 				n_co_g = nearptsEdges[0][0]
# 			else:
# 				n1_co_g = nearptsEdges[0][0]
# 				n2_co_g = nearptsEdges[1][0]
# 				n_co_g, _ = mathutils.geometry.intersect_point_line(v_co_g, n1_co_g, n2_co_g)
# 			dst = (n_co_g-v_co_g).length
# 			if math.isnan(dst):
# 				dst = 0
# 			else:
# 				dist_min = min(dist_min, dst)
# 				dist_max = max(dist_max, dst)
# 			distmap_U[v.index] = dst
# 			cam_look_ll = n_co_g - pc_co_cnt_g
# 			cam_look_ll2 = Vector((cam_look_ll[0], cam_look_ll[1]))
# 			# 2D-projected vector - for signed angle
# 			ang = (cam_look_ll2.angle_signed(Vector((0.0, 1.0)), 0.0) + math.pi) / (2.0*math.pi)
# 			distmap_V[v.index] = ang
# 	# normalizing distance and reversing 1.0->0.0
# 	for vIdx in distmap_U:
# 		distmap_U[vIdx] = ((distmap_U[vIdx] - dist_min)/(dist_max - dist_min))
# 	#print("- distmap_U dist_min/dist_max", dist_min, dist_max, distmap_U)
# 	return distmap_U, distmap_V

def bm_regularDistmap_v01(bme, step_vIdx, limit2verts, vertsPerIslands, vertsCo):
	def get_co(v):
		if(vertsCo is None or (v.index not in vertsCo)):
			return v.co
		return vertsCo[v.index]
	dots_tree_all = KDTree(len(step_vIdx))
	dots_tree_cnt = 0.0
	dots_tree_sum = Vector((0,0,0))
	for vIdx in step_vIdx:
		v = bme.verts[vIdx]
		v_co = get_co(v)
		dots_tree_all.insert(v_co, vIdx)
		dots_tree_sum = dots_tree_sum+v_co
		dots_tree_cnt = dots_tree_cnt+1.0
	if dots_tree_cnt < 1.0:
		return None, None
	dots_tree_sum = dots_tree_sum/dots_tree_cnt
	dots_tree_all.balance()
	dots_tree_cache = {}
	dots_tree_cnts = {}
	vertProj2Map = {}
	vertProjLefters = []
	#vertDistMap = {}
	#vertProj5Map = {}
	#dots_stepDirs = {}
	# for i,vIdx in enumerate(step_vIdx):
	# 	v = bme.verts[vIdx]
	# 	v_sidepts = []
	# 	dots_stepDirs[vIdx] = v_sidepts
	# 	for e in v.link_edges:
	# 		if e.other_vert(v).index in step_vIdx:
	# 			v_sidepts.append(get_co(e.other_vert(v)))
	# 	if len(v_sidepts) == 0:
	# 		if i > 0:
	# 			v2 = bme.verts[step_vIdx[0]]
	# 			v_sidepts.append(get_co(v2))
	# 		else:
	# 			v2 = bme.verts[step_vIdx[-1]]
	# 			v_sidepts.append(get_co(v2))
	# 		v_sidepts.append(get_co(v))
	# 	elif len(v_sidepts) == 1:
	# 		# adding self
	# 		v_sidepts.append(get_co(v))
	vert2isl = {}
	if vertsPerIslands is not None:
		for v in bme.verts:
			if limit2verts is not None and v.index not in limit2verts:
				continue
			vertIslId = -1
			for idx, isl in enumerate(vertsPerIslands):
				if v.index in isl:
					vertIslId = idx
					vert2isl[v.index] = vertIslId
					break
			if (vertIslId >= 0) and (vertIslId not in dots_tree_cache):
				dots_tree_cache[vertIslId] = "???"
				dots_tree_tmp_cnt = 0.0
				dots_tree_tmp_sum = Vector((0,0,0))
				dots_tree_tmp = KDTree(len(step_vIdx))
				for vIdx in step_vIdx:
					if vIdx not in vertsPerIslands[vertIslId]:
						continue
					v2 = bme.verts[vIdx]
					v2_co = get_co(v2)
					dots_tree_tmp.insert(v2_co, vIdx)
					dots_tree_tmp_sum = dots_tree_tmp_sum+v2_co
					dots_tree_tmp_cnt = dots_tree_tmp_cnt+1.0
				dots_tree_tmp.balance()
				if dots_tree_tmp_cnt > 0:
					dots_tree_cnts[vertIslId] = dots_tree_tmp_sum/dots_tree_tmp_cnt
					dots_tree_cache[vertIslId] = dots_tree_tmp
	for v in bme.verts:
		if limit2verts is not None and v.index not in limit2verts:
			continue
		dots_tree_cur = dots_tree_all
		dots_tree_cur_center = dots_tree_sum
		if vertsPerIslands is not None:
			vertIslId = vert2isl[v.index]
			if vertIslId >= 0 and vertIslId in dots_tree_cache:
				if dots_tree_cache[vertIslId] != "???":
					dots_tree_cur = dots_tree_cache[vertIslId]
					dots_tree_cur_center = dots_tree_cnts[vertIslId]
			#else:
			#	print("- no islands for", v.index)
		v_co_g = get_co(v)
		# nearptsEdges = dots_tree_cur.find_n(v_co_g,5)
		# if len(nearptsEdges) > 0:
		# 	nearptsEdges.sort(key=lambda itm: itm[2], reverse=False)
		# 	distEdges_min = nearptsEdges[0][2]
		# 	distEdges_max = nearptsEdges[-1][2]
		# 	if abs(distEdges_max-distEdges_min) < 0.0001:
		# 		# This case IS frequent for 1 vert in source (unwrap along...)
		# 		#print("- abs(distEdges_max-distEdges_min) < 0.0001 for", v.index, len(nearptsEdges))
		# 		distEdges_max = 1.0
		# 		distEdges_min = 0.0
		# 	nearVerts_dst = []
		# 	nearVerts_wei = []
		# 	nearVertsPrj_dst = []
		# 	nearVertsPrj_wei = []
		# 	for near in nearptsEdges:
		# 		n_co_g = near[0]
		# 		n_idx = near[1]
		# 		#n_dist = near[2]
		# 		v_n_dst = (n_co_g-v_co_g).length
		# 		v_n_wei = pow((v_n_dst - distEdges_min)/(distEdges_max - distEdges_min),2)
		# 		nearVerts_dst.append(v_n_dst)
		# 		nearVerts_wei.append(v_n_wei+0.0001) # avoiding null-weights..
		# 		if n_idx in dots_stepDirs and len(dots_stepDirs[n_idx]) >= 2:
		# 			n1_co_g = dots_stepDirs[n_idx][0]
		# 			n2_co_g = dots_stepDirs[n_idx][1]
		# 			v_n_dst = ( (n1_co_g+n2_co_g)*0.5 - v_co_g).length
		# 			v_n_wei = pow((v_n_dst - distEdges_min)/(distEdges_max - distEdges_min),2)
		# 			n_co_g, _ = mathutils.geometry.intersect_point_line(v_co_g, n1_co_g, n2_co_g)
		# 			dst2 = (n_co_g-v_co_g).length
		# 			if not math.isnan(dst2):
		# 				v_n_dst = dst2
		# 			else:
		# 				print("- NaN distance!")
		# 			nearVertsPrj_dst.append(v_n_dst)
		# 			nearVertsPrj_wei.append(v_n_wei + EPS)
		# 	v_n_dst = np.average(nearVerts_dst,weights=nearVerts_wei)
		# 	vertDistMap[v.index] = v_n_dst
		# 	v_n_dstPrj = np.average(nearVertsPrj_dst,weights=nearVertsPrj_wei)
		# 	vertProj5Map[v.index] = v_n_dstPrj
		# else:
		# 	print("- no nearptsEdges for", v.index)

		# v1: - two closest
		nearptsSeams = dots_tree_cur.find_n(get_co(v), 2)
		if len(nearptsSeams) > 0:
			nearptsSeams.sort(key=lambda itm: itm[2], reverse=False)
			n1_co_g = nearptsSeams[0][0]
			n1_co_idx = nearptsSeams[0][1]
			dst = (n1_co_g-v_co_g).length
			if len(nearptsSeams) > 1:
				n2_co_g = nearptsSeams[-1][0]
				n2_co_idx = nearptsSeams[-1][1]
				n_co_g, _ = mathutils.geometry.intersect_point_line(v_co_g, n1_co_g, n2_co_g)
				dst2 = (n_co_g-v_co_g).length
				if not math.isnan(dst2):
					dst = dst2
					if step_vIdx.index(n1_co_idx) < step_vIdx.index(n2_co_idx):
						tmp = n1_co_g
						n1_co_g = n2_co_g
						n2_co_g = tmp
				plane_nrm = (n2_co_g-dots_tree_cur_center).normalized().cross((n1_co_g-dots_tree_cur_center).normalized())
				#if wla.math_vecIsLeft(v_co_g-n1_co_g, dots_tree_cur_center-n1_co_g, n2_co_g-n1_co_g):
				if mathutils.geometry.distance_point_to_plane(v_co_g, dots_tree_cur_center, plane_nrm) < 0:
					vertProjLefters.append(v.index)
			vertProj2Map[v.index] = dst # for 1 vert - pure distance
		else:
			print("- no nearptsSeams for", v.index)
	#return vertDistMap, vertProj5Map, vertProj2Map
	return vertProj2Map, vertProjLefters

# def bm_vertsDistribute(bm, vertsIdx):
# 	if len(vertsIdx) < 2:
# 		return
# 	bm.verts.ensure_lookup_table()
# 	bm.verts.index_update()
# 	bm.edges.ensure_lookup_table()
# 	bm.edges.index_update()
# 	len_trg = 0
# 	t_xp = []
# 	t_yp_px = []
# 	t_yp_py = []
# 	t_yp_pz = []
# 	curve_pt_last = None
# 	for j, vIdx in enumerate(vertsIdx):
# 		curve_pt = bm.verts[vIdx]
# 		t_yp_px.append(curve_pt.co[0])
# 		t_yp_py.append(curve_pt.co[1])
# 		t_yp_pz.append(curve_pt.co[2])
# 		if curve_pt_last is not None:
# 			len_trg = len_trg+(curve_pt_last.co-curve_pt.co).length
# 		t_xp.append(len_trg)
# 		curve_pt_last = curve_pt
# 	#print("- distributing", t_xp, len_trg)
# 	for j, vIdx in enumerate(vertsIdx):
# 		curve_pt = bm.verts[vIdx]
# 		t_pos = float(j)/float(len(vertsIdx)-1)*len_trg
# 		new_co = Vector((np.interp(t_pos, t_xp, t_yp_px),np.interp(t_pos, t_xp, t_yp_py),np.interp(t_pos, t_xp, t_yp_pz)))
# 		curve_pt.co = new_co
# 	return

def bm_vertFitEdge(bm, vert1Idx, vert2Idx, fitLen, centerFact):
	bm.verts.ensure_lookup_table()
	bm.verts.index_update()
	v1 = bm.verts[vert1Idx]
	v2 = bm.verts[vert2Idx]
	if centerFact < 0.4:
		v2.co = v1.co + ((v2.co-v1.co).normalized() * fitLen)
	elif centerFact > 0.4:
		v1.co = v2.co + ((v1.co-v2.co).normalized() * fitLen)
	else:
		vCnt = (v2.co+v1.co) * 0.5
		v1.co = vCnt + ((v1.co-vCnt.co).normalized() * fitLen * 0.5)
		v2.co = vCnt + ((v2.co-vCnt.co).normalized() * fitLen * 0.5)
	return

def bm_copyFaces(active_obj, storeKey, selvertsAll, targetTransformPrep, targetOrigin = None):
	if selvertsAll is None:
		del config.WPL_G.store[storeKey]
		return -1, None
	isTmp = False
	active_mesh = None
	if (active_obj is not None):
		if (config.kWPLTempMesh in active_obj):
			active_mesh = active_obj[config.kWPLTempMesh]
			isTmp = True
		elif (active_obj.type == 'MESH'):
			active_mesh = active_obj.data
	if active_mesh is None:
		return -1, None
	if len(selvertsAll) == 0 or storeKey is None:
		return -1, None
	if isTmp == False:
		try:
			wla_do.select_and_change_mode(active_obj,"OBJECT")
		except Exception as e:
			print("- failed to activate object", active_obj.name, e)
			return -1, None
	#print("- bm_copyFaces, verts:", len(selvertsAll))
	l2g_matrix = targetTransformPrep
	if targetTransformPrep is None:
		l2g_matrix = active_obj.matrix_world
	facesOk = 0
	faceDescrAll = []
	edgeDescrAll = []
	vertDescrAll = {}
	vertDescrAll['uvs'] = []
	vertDescrAll['uvs_co'] = {}
	facesCenter_g = Vector((0,0,0))
	facesCenter_gCnt = 0.0
	# if modeAppend and storeKey in config.WPL_G.store:
	# 	pinDat = copy.copy(config.WPL_G.store[storeKey])
	# 	faceDescrAll = pinDat["faces"]
	# 	edgeDescrAll = pinDat["edges"]
	# 	vertDescrAll = pinDat["verts"]
	# 	facesCenter_g = pinDat["location"]
	# 	facesCenter_gCnt = None
	# Better get DEFORMED verts positions (from EDIT mode or deformedCos)
	# Critical for bodies with shapekeys, for now shapekeys ignored
	vertCo_g = {}
	selfacesAll = []
	for f in active_mesh.polygons:
		isSelFace = True
		for vfIdx in f.vertices:
			if vfIdx not in selvertsAll:
				isSelFace = False
				break
		if isSelFace:
			selfacesAll.append(f.index)
	for vIdx in selvertsAll:
		v = active_mesh.vertices[vIdx]
		if v.index in vertCo_g:
			continue
		vertCo_g[v.index] = l2g_matrix @ v.co
	for edg in active_mesh.edges:
		vert1 = active_mesh.vertices[ edg.vertices[0] ]
		vert2 = active_mesh.vertices[ edg.vertices[1] ]
		if (vert1.index not in selvertsAll):
			continue
		if (vert2.index not in selvertsAll):
			continue
		specEdge = False
		if edg.use_freestyle_mark:
			specEdge = True
		if edg.use_seam:
			specEdge = True
		if specEdge:
			edgeDescr = {}
			edgeDescr["seam"] = edg.use_seam
			# wire edge... saving - need for rings - not used for now
			edgeDescr["wire"] = 0 #1 if (len(edg.link_faces) == 0) else 0
			# freestyle... saving - need for edging
			edgeDescr["freestyle"] = edg.use_freestyle_mark
			edgeDescr["verts"] = []
			for ev in (vert1, vert2):
				vert_co_g = vertCo_g[ev.index]
				edgeDescr['verts'].append( (vert_co_g[0],vert_co_g[1],vert_co_g[2]) )
			edgeDescrAll.append(edgeDescr)
		v_cnt_co_g = (vertCo_g[vert1.index] + vertCo_g[vert2.index])*0.5
		if facesCenter_gCnt is not None:
			facesCenter_g = facesCenter_g + v_cnt_co_g
			facesCenter_gCnt = facesCenter_gCnt + 1.0
	if targetOrigin is not None:
		facesCenter_g = targetOrigin
	elif (facesCenter_gCnt is not None) and (facesCenter_gCnt > 0):
		facesCenter_g = facesCenter_g/facesCenter_gCnt
	for ipoly in range(len(active_mesh.polygons)):
		if ipoly not in selfacesAll:
			continue
		facesOk = facesOk+1
		faceDescr = {}
		faceDescr['smooth'] = active_mesh.polygons[ipoly].use_smooth
		faceDescr['material_index'] = active_mesh.polygons[ipoly].material_index
		if len(active_obj.material_slots) >faceDescr['material_index']:
			faceDescr['material_name'] = active_obj.material_slots[faceDescr['material_index']].name
		else:
			faceDescr['material_name'] = ""
		faceDescr['colors'] = {}
		faceDescr['verts'] = []
		for idx, lIdx in enumerate(active_mesh.polygons[ipoly].loop_indices):
			ivdx = active_mesh.polygons[ipoly].vertices[idx]
			# vert = active_mesh.vertices[ivdx]
			vert_co_g = vertCo_g[ivdx]
			faceDescr['verts'].append( (vert_co_g[0],vert_co_g[1],vert_co_g[2]) )
			for uv in active_mesh.uv_layers:
				if uv.name not in vertDescrAll['uvs']:
					vertDescrAll['uvs'].append(uv.name)
				if uv.name not in vertDescrAll['uvs_co']:
					vertDescrAll['uvs_co'][uv.name] = {}
				uvval = uv.data[lIdx].uv
				vertDescrAll['uvs_co'][uv.name][wla.coToKey(vert_co_g)] = (uvval[0], uvval[1])
			for vc in active_mesh.vertex_colors:
				col = vc.data[lIdx].color
				pickedcol = Vector((col[0], col[1], col[2]))
				faceDescr['colors'][vc.name] = pickedcol
		faceDescrAll.append(faceDescr)
	# print("- edgeDescrAll", edgeDescrAll)
	config.WPL_G.store[storeKey] = { "faces": faceDescrAll, "edges": edgeDescrAll, "verts": vertDescrAll, "location": facesCenter_g, "src_name": active_obj.name, "src_matrix": active_obj.matrix_world.copy() }
	return facesOk, facesCenter_g

def bm_pasteFaces(active_obj, storeKey, targetTransformPrep = None, targetCenter_g = None, opt_postOffset = None, opt_postRotate = None, opt_postScale = None, opt_postAxis_g = None):
	if active_obj is None or active_obj.type != 'MESH' or storeKey is None:
		return []
	if storeKey not in config.WPL_G.store:
		print("Nothing copied")
		return []
	if targetTransformPrep is None:
		targetTransformPrep = Matrix.Identity(4)
	active_mesh = active_obj.data
	matrix_world = active_obj.matrix_world
	matrix_world_inv = active_obj.matrix_world.inverted()
	# matrix_world_nrml = matrix_world_inv.transposed().to_3x3()
	addedFaces = []
	wla_do.select_and_change_mode(active_obj,"EDIT")
	bm = bmesh.from_edit_mesh(active_mesh)
	bm.verts.ensure_lookup_table()
	bm.verts.index_update()
	bm.edges.ensure_lookup_table()
	bm.edges.index_update()
	bm.faces.ensure_lookup_table()
	bm.faces.index_update()
	pinDat = copy.copy(config.WPL_G.store[storeKey])
	faceDescrAll = pinDat["faces"]
	edgeDescrAll = pinDat["edges"]
	vertDescrAll = pinDat["verts"]
	pastedCenter_g = pinDat["location"]
	# same transform as with verts needed
	pastedCenter_l = (matrix_world_inv @ (targetTransformPrep @ Vector( (pastedCenter_g[0], pastedCenter_g[1], pastedCenter_g[2]) )))
	bm2vmap = {}
	vkey_g2l = {}
	bm2vidx = []
	v_cc = None
	f_cc = None
	for faceDescr in faceDescrAll:
		f_v_set = []
		f_v_set_ko = []
		f_vg = faceDescr['verts']
		for v_co_g in f_vg:
			vert_index_g = wla.coToKey(v_co_g)
			v_co_l = (matrix_world_inv @ (targetTransformPrep @ Vector(( v_co_g[0], v_co_g[1], v_co_g[2] )) ) )
			if vert_index_g not in bm2vmap:
				v_cc = bm.verts.new( Vector(( v_co_l[0], v_co_l[1], v_co_l[2] )) )
				v_cc.select = True
				bm2vmap[vert_index_g] = v_cc
				vert_index_l = wla.coToKey(v_co_l)
				vkey_g2l[vert_index_l] = vert_index_g
			else:
				v_cc = bm2vmap[vert_index_g]
			if v_cc not in f_v_set:
				f_v_set.append(v_cc)
				f_v_set_ko.append(vert_index_g)
		bm.verts.ensure_lookup_table()
		bm.verts.index_update()
		if len(f_v_set) >= 3:
			f_v_set_ko = sorted(f_v_set_ko)
			f_v_set_ko = ",".join(f_v_set_ko)
			if f_v_set_ko not in bm2vmap:
				bm2vmap[f_v_set_ko] = f_v_set
				f_cc = bm.faces.new(f_v_set)
				f_cc.smooth = faceDescr['smooth']
		faceDescr['faceIdx'] = 0
		if f_cc is not None:
			bm.faces.ensure_lookup_table()
			bm.faces.index_update()
			f_cc.select = True
			faceDescr['faceIdx'] = f_cc.index
	# extra edges if needed
	edgeDescrAllPerCo = {}
	for edgeDescr in edgeDescrAll:
		e_vg = edgeDescr['verts']
		e_v_set = []
		for v_co_g in e_vg:
			vert_index_g = wla.coToKey(v_co_g)
			v_co_l = (matrix_world_inv @ (targetTransformPrep @ Vector(( v_co_g[0], v_co_g[1], v_co_g[2] )) ) )
			if vert_index_g not in bm2vmap:
				v_cc = bm.verts.new( Vector(( v_co_l[0], v_co_l[1], v_co_l[2] )) )
				v_cc.select = True
				bm2vmap[vert_index_g] = v_cc
				vert_index_l = wla.coToKey(v_co_l)
				vkey_g2l[vert_index_l] = vert_index_g
			else:
				v_cc = bm2vmap[vert_index_g]
			bm.verts.ensure_lookup_table()
			bm.verts.index_update()
			if  v_cc.index not in bm2vidx:
				bm2vidx.append(v_cc.index)
			if v_cc not in e_v_set:
				e_v_set.append(v_cc)
		if len(e_v_set) == 2:
			if edgeDescr['wire'] == 1:
				bm.edges.new(e_v_set)
			ecoKey = ",".join(sorted( [wla.coToKey(e_v_set[0].co), wla.coToKey(e_v_set[1].co)] ))
			if ecoKey in edgeDescrAllPerCo:
				print("- warning: edgekey duplication", edgeDescrAllPerCo[ ecoKey ], edgeDescr)
			edgeDescrAllPerCo[ ecoKey ] = edgeDescr
	bm.normal_update()
	bmesh.update_edit_mesh(active_mesh)
	wla_do.select_and_change_mode(active_obj,"OBJECT")
	# updating edges - use_freestyle_mark not possible in bmesh...
	for iedge in active_mesh.edges:
		ie_v1 = active_mesh.vertices[iedge.vertices[0]]
		ie_v2 = active_mesh.vertices[iedge.vertices[1]]
		ecoKey = ",".join(sorted( [wla.coToKey(ie_v1.co), wla.coToKey(ie_v2.co)] ))
		if ecoKey in edgeDescrAllPerCo:
			edgeDescr = edgeDescrAllPerCo[ecoKey]
			iedge.use_seam = edgeDescr['seam']
			iedge.use_freestyle_mark = edgeDescr['freestyle']
	# updating materials, VCs, UVs
	faceuvs = vertDescrAll['uvs']
	for cl_name in faceuvs:
		wla_attr.uv_obj_ensure(active_obj, cl_name)
	for faceDescr in faceDescrAll:
		# checking materials, VCS, adding missing
		if len(faceDescr['material_name']) > 0:
			faceDescr['material_index'] = wla_attr.mat_obj_ensuremat(active_obj, faceDescr['material_name'], False)
		facescolors = faceDescr['colors']
		# defaulting to black: 1) new in paste-vs-Object, 2) new in Object-vs-paste
		for cl_name in facescolors:
			if active_mesh.vertex_colors.get(cl_name) is None:
				# wla_attr.vc_obj_ensure - but manually, no mode changes
				active_mesh.vertex_colors.new(name = cl_name)
				vc = active_mesh.vertex_colors.get(cl_name)
				for ipoly in range(len(active_mesh.polygons)):
					for idx, lIdx in enumerate(active_mesh.polygons[ipoly].loop_indices):
						vc.data[lIdx].color = (0,0,0,1.0)
		for ipoly in range(len(active_mesh.polygons)):
			if faceDescr['faceIdx'] == active_mesh.polygons[ipoly].index:
				addedFaces.append(faceDescr['faceIdx'])
				if ('material_index' in faceDescr) and (faceDescr['material_index'] >= 0):
					active_mesh.polygons[ipoly].material_index = faceDescr['material_index']
				for idx, lIdx in enumerate(active_mesh.polygons[ipoly].loop_indices):
					ivdx = active_mesh.polygons[ipoly].vertices[idx]
					vert = active_mesh.vertices[ivdx]
					if vert.index not in bm2vidx:
						bm2vidx.append(vert.index)
					for uv in active_mesh.uv_layers:
						if uv.name in faceuvs:
							g2lkey = wla.coToKey(vert.co)
							if g2lkey in vkey_g2l:
								v_co_key = vkey_g2l[g2lkey]
								if v_co_key in vertDescrAll['uvs_co'][uv.name]:
									uvval = vertDescrAll['uvs_co'][uv.name][v_co_key]
									uv.data[lIdx].uv = (uvval[0],uvval[1])
							else:
								print("- bm_pasteFaces: WARNING: v-lost")
					for vc in active_mesh.vertex_colors:
						if vc.name in facescolors:
							col = facescolors[vc.name]
							vc.data[lIdx].color = (col[0],col[1],col[2],1.0)
						else:
							vc.data[lIdx].color = (0.0, 0.0, 0.0, 1.0)
	# pasted as is in global space (with pre-transform), now post-positioning verts
	if (targetCenter_g is not None) or (opt_postOffset is not None) or (opt_postRotate is not None) or (opt_postScale is not None) or (opt_postAxis_g is not None):
		wla_do.select_and_change_mode(active_obj,"EDIT")
		bm = bmesh.from_edit_mesh(active_mesh)
		bm.verts.ensure_lookup_table()
		bm.verts.index_update()
		bm.faces.ensure_lookup_table()
		bm.faces.index_update()
		if targetCenter_g is None:
			targetCenter_g = matrix_world @ pastedCenter_l
		sclV = Vector(( 1.0, 1.0, 1.0 ))
		shfV = Vector(( 0.0, 0.0, 0.0))
		rotV = Matrix.Identity(4)
		if opt_postOffset is not None:
			shfV = Vector(( opt_postOffset[0], opt_postOffset[1], opt_postOffset[2]))
		if (opt_postRotate is not None)  and (abs(opt_postRotate[0]) + abs(opt_postRotate[1]) + abs(opt_postRotate[2])) > config.kWPLRaycastEpsilon:
			rotV = mathutils.Euler((math.radians(opt_postRotate[0]),math.radians(opt_postRotate[1]),math.radians(opt_postRotate[2])), 'XYZ')
			rotV = rotV.to_quaternion().to_matrix().to_4x4()
		if (opt_postScale is not None) and (abs(opt_postScale[0]-1.0) + abs(opt_postScale[1]-1.0) + abs(opt_postScale[1]-1.0)) > config.kWPLRaycastEpsilon:
			sclV = Vector(( opt_postScale[0], opt_postScale[1], opt_postScale[2]))
		vFaces = set()
		for vIdx in bm2vidx:
			v = bm.verts[vIdx]
			vFaces.update(v.link_faces)
			shift_l = (v.co - pastedCenter_l)
			shift_l = rotV @ shift_l
			shift_l = sclV * shift_l
			shift_l = shift_l + (shfV[0]*Vector((1,0,0)))
			shift_l = shift_l + (shfV[1]*Vector((0,1,0)))
			shift_l = shift_l + (shfV[2]*Vector((0,0,1)))
			if opt_postAxis_g is None:
				v.co = (matrix_world_inv @ targetCenter_g) + shift_l
			else:
				v_co_g = targetCenter_g
				v_co_g = v_co_g + shift_l[0] * ( opt_postAxis_g @ Vector((1,0,0)) )
				v_co_g = v_co_g + shift_l[1] * ( opt_postAxis_g @ Vector((0,1,0)) )
				v_co_g = v_co_g + shift_l[2] * ( opt_postAxis_g @ Vector((0,0,1)) )
				v.co = matrix_world_inv @ v_co_g
		bm.normal_update()
		bmesh.ops.recalc_face_normals(bm, faces=list(vFaces))
		bmesh.update_edit_mesh(active_mesh)
	wla_do.select_and_change_mode(active_obj,"OBJECT")
	return addedFaces

# def find_last_changed_faces(active_obj, isFinally):
# 	from . import wla_meshwrap
# 	if active_obj is None or active_obj.type != 'MESH':
# 		return None
# 	if isFinally == False:
# 		facemap = []
# 		config.WPL_G.store["obj_chngfaces"] = facemap
# 		for f in active_obj.data.polygons:
# 			fk = wla_meshwrap.object_meshfKey(active_obj.data, f)
# 			facemap.append(fk)
# 		return None
# 	if not ("obj_chngfaces" in config.WPL_G.store):
# 		return None
# 	wla_do.select_and_change_mode(active_obj, 'OBJECT')
# 	facemap = config.WPL_G.store["obj_chngfaces"]
# 	newfaces = []
# 	for f in active_obj.data.polygons:
# 		fk = wla_meshwrap.object_meshfKey(active_obj.data, f)
# 		if fk not in facemap:
# 			newfaces.append(f.index)
# 	return newfaces

def bm_verts_to_spline(bm, vseq, width1, width2, tension1, tension2, flipped, influence):
	# based on MESHMachine unfuck tool
	remote1 = vseq[0]
	end1 = vseq[1]
	remote2 = vseq[-1]
	end2 = vseq[-2]
	loop1_dir = remote1.co - end1.co
	loop2_dir = remote2.co - end2.co
	if loop1_dir.length < 0.000001 or loop2_dir.length < 0.000001:
		print("bm_verts_to_spline: ERROR, zero-length vectors")
		return
	if flipped:
		start1co = end1.co - (remote1.co - end1.co).normalized() * width2
		start2co = end2.co - (remote2.co - end2.co).normalized() * width1
	else:
		start1co = end1.co - (remote1.co - end1.co).normalized() * width1
		start2co = end2.co - (remote2.co - end2.co).normalized() * width2
	h = mathutils.geometry.intersect_line_line(end1.co, remote1.co, end2.co, remote2.co)
	loop_angle = math.degrees(loop1_dir.angle(loop2_dir))
	if h is None or 178 <= loop_angle <= 182:  # if the edge and both loop egdes are on the same line or are parallel: _._._ or  _./'¯¯
		h1_full = mathutils.geometry.intersect_point_line(end2.co, end1.co, remote1.co)[0]
		h2_full = mathutils.geometry.intersect_point_line(end1.co, end2.co, remote2.co)[0]
		h1 = end1.co + (h1_full - end1.co)
		h2 = end2.co + (h2_full - end2.co)
		h = (h1, h2)
	if flipped:
		handle1co = start1co + (h[0] - start1co) * tension2
		handle2co = start2co + (h[1] - start2co) * tension1
	else:
		handle1co = start1co + (h[0] - start1co) * tension1
		handle2co = start2co + (h[1] - start2co) * tension2
	bezierverts = mathutils.geometry.interpolate_bezier(start1co, handle1co, handle2co, start2co, len(vseq) - 2)
	for idx, vert in enumerate(vseq[1:-1]):
		vert.co = vert.co + (bezierverts[idx] - vert.co) * influence

# def bm_findFaceVertWindingIdx(f, v):
# 	for idx, lp in enumerate(f.loops):
# 		if lp.vert == v:
# 			return idx
# 	return -1

# def bm_verts_left_right_parallel(bm, vseq, vseq2ignore):
# 	nextVSeqL = []
# 	nextVSeqR = []
# 	# sideVerts = []
# 	# for v in vseq:
# 	# 	for e in v.link_edges:
# 	# 		ov = e.other_vert(v)
# 	# 		if (ov not in vseq) and (ov not in vseq2ignore) and (ov not in sideVerts):
# 	# 			sideVerts.append(ov)
# 	for i in range(0, len(vseq)):
# 		v = vseq[i]
# 		vn = v
# 		if i < len(vseq)-1:
# 			vn = vseq[i+1]
# 		elif i > 0:
# 			vn = v
# 			v = vseq[i-1]
# 		for f in v.link_faces:
# 			f_co = f.calc_center_median()
# 			f_seq = nextVSeqR
# 			if wla.math_vecIsLeft(f_co-v.co, vn.co-v.co, v.normal) > 0.0:
# 				f_seq = nextVSeqL
# 			if (v not in f.verts):
# 				continue
# 			# first&last faces always with 1 vert in common, but this is NOT what is needed here...
# 			if (i == 0 or i == len(vseq)-1) and (vn not in f.verts): # and ((len(f_seq)>0) and (f_seq[-1] not in f.verts)):
# 				continue
# 			v_vn_dir = 1 # 1,2,3
# 			if bm_findFaceVertWindingIdx(f,v) > bm_findFaceVertWindingIdx(f,vn):
# 				v_vn_dir = -1 # 3,2,1
# 			edgVerts2add = []
# 			for fe in f.edges:
# 				if (fe.verts[0] in vseq) or (fe.verts[1] in vseq):
# 					continue
# 				if fe.verts[0] not in edgVerts2add:
# 					edgVerts2add.append(fe.verts[0])
# 				if fe.verts[1] not in edgVerts2add:
# 					edgVerts2add.append(fe.verts[1])
# 			# need new sequence in same direction as original. Using face winding to decide...
# 			if v_vn_dir > 0:
# 				edgVerts2add.sort(key=lambda fv: bm_findFaceVertWindingIdx(f, fv), reverse=False)
# 			else:
# 				edgVerts2add.sort(key=lambda fv: bm_findFaceVertWindingIdx(f, fv), reverse=True)
# 			#f.select = True
# 			for vp in edgVerts2add:
# 				if (vp not in vseq2ignore):
# 					f_seq.append(vp)
# 					vseq2ignore.append(vp)
# 			# for e in f.edges:
# 			# 	if v in e.verts:
# 			# 		vp = e.other_vert(v)
# 			# 		if vp in vseq2ignore:
# 			# 			continue
# 			# 		if vp not in f_seq:
# 			# 			f_seq.append(vp)
# 			# 			vseq2ignore.append(vp)
# 			# if len(f.edges) > 3:
# 			# 	for e in f.edges:
# 			# 		if vn in e.verts:
# 			# 			vp = e.other_vert(vn)
# 			# 			if vp in vseq2ignore:
# 			# 				continue
# 			# 			if vp not in f_seq:
# 			# 				f_seq.append(vp)
# 			# 				vseq2ignore.append(vp)
# 	return nextVSeqL, nextVSeqR

def bm_copy_face2face(bm, frmFace, trgFace, transferCache):
	# VC transfer, Vertex Vector transfer
	# UV tranfer: Not needed (Grid-vgBIND-etc)
	if bm is not None and trgFace is not None:
		bm.verts.ensure_lookup_table()
		bm.verts.index_update()
		bm.faces.ensure_lookup_table()
		bm.faces.index_update()
		if frmFace is not None:
			trgFace.smooth = frmFace.smooth
			trgFace.material_index = frmFace.material_index
		#print("bm_copy_face2face: ", frmFace.index, trgFace.index)
		allvcs = bm.loops.layers.color.keys()
		for llayer_key in allvcs:
			llayer = bm.loops.layers.color[llayer_key]
			if frmFace is not None:
				cck = llayer_key+str(frmFace.index)
			else:
				# important to set (0,0,0) for all VC... especially Wri
				cck = llayer_key+"???"
			if "vc_"+cck in transferCache:
				fcl = transferCache["vc_"+cck]
			else:
				fcl = Vector((0,0,0))
				if frmFace is not None:
					fcl_c = 0
					for loop in frmFace.loops:
						fcl = fcl+Vector((loop[llayer][0],loop[llayer][1],loop[llayer][2]))
						fcl_c = fcl_c+1
					if fcl_c>0:
						fcl = fcl/fcl_c
				# print("- copying vc", llayer_key, fcl)
				transferCache["vc_"+cck] = fcl
			for loop in trgFace.loops:
				loop[llayer] = (fcl[0],fcl[1],fcl[2],1)
	return

def bm_copy_faces2faces(active_obj, bm, frmFacesIdx, trgFacesIdx, transferCache):
	if bm is not None:
		bm.verts.index_update()
		bm.faces.index_update()
		bm.verts.ensure_lookup_table()
		bm.faces.ensure_lookup_table()
		for trgIdx in trgFacesIdx:
			trgFace = bm.faces[trgIdx]
			trgFace_cm = trgFace.calc_center_median()
			minDist = 999
			frmFaceClosest = None
			for frmIdx in frmFacesIdx:
				frmFace = bm.faces[frmIdx]
				frmFace_cm = frmFace.calc_center_median()
				dist = (frmFace_cm-trgFace_cm).length
				if dist<minDist:
					minDist = dist
					frmFaceClosest = frmFace
			bm_copy_face2face(bm, frmFaceClosest, trgFace, transferCache)
		# saving vert indexes for later weight updates
		if "bmcf2f_vf" not in transferCache:
			transferCache["bmcf2f_vf"] = {}
		bmcf2f_vf = transferCache["bmcf2f_vf"]
		for trgIdx in trgFacesIdx:
			trgFace = bm.faces[trgIdx]
			for trgFace_v in trgFace.verts:
				if trgFace_v.index not in bmcf2f_vf:
					dst_min = 999
					dst_v = -1
					for frmIdx in frmFacesIdx:
						frmFace = bm.faces[frmIdx]
						for frmFace_v in frmFace.verts:
							vdst = (frmFace_v.co-trgFace_v.co).length
							if vdst < dst_min:
								dst_min = vdst
								dst_v = frmFace_v.index
					bmcf2f_vf[trgFace_v.index] = dst_v
	if bm is None:
		# finally: transfering per-vertex stuff
		if (active_obj is not None) and (transferCache is not None) and ("bmcf2f_vf" in transferCache):
			# post-process: update verts weights
			bmcf2f_vf = transferCache["bmcf2f_vf"]
			# print("- bmcf2f_vf", bmcf2f_vf)
			datLayersCopiedVG = 0
			oldmode = wla_do.select_and_change_mode(active_obj, 'OBJECT')
			for group in active_obj.vertex_groups:
				datLayersCopiedVG = datLayersCopiedVG+1
				vg_weights = wla_attr.vg_get_weightMap(active_obj, group.name)
				for trgFace_vIdx in bmcf2f_vf.keys():
					frmFace_vIdx = bmcf2f_vf[trgFace_vIdx]
					if frmFace_vIdx not in vg_weights:
						vg_weights[frmFace_vIdx] = 0
					wla_attr.vg_add_verts2vg(active_obj, group.name, [trgFace_vIdx], vg_weights[frmFace_vIdx])
			# post-process: update verts vector attrib
			datLayersCopiedFVA = 0
			attrk_k = active_obj.data.attributes.keys()
			for ak in attrk_k:
				attr_fl = active_obj.data.attributes.get(ak)
				if not isinstance(attr_fl, bpy.types.FloatVectorAttribute):
					continue
				#print("- copying attr", attr_fl)
				datLayersCopiedFVA = datLayersCopiedFVA+1
				for trgFace_vIdx in bmcf2f_vf.keys():
					frmFace_vIdx = bmcf2f_vf[trgFace_vIdx]
					attr_fl.data[trgFace_vIdx].vector = attr_fl.data[frmFace_vIdx].vector
			wla_do.select_and_change_mode(active_obj, oldmode)
			print("- bm_copy_face2face: vertex data layers copied", datLayersCopiedVG, datLayersCopiedFVA)
		else:
			print("- bm_copy_face2face: no vertex data to use")
	return

def bm_getDeformedCos(obj):
	wla_do.select_and_change_mode(obj, 'OBJECT')
	vert2co = {}
	vert2nrm = {}
	active_mesh = obj.data
	if active_mesh is None or obj.type != 'MESH':
		print("- bm_getDeformedCos: no data for", obj.name)
		return None, None
	# v3: index2index
	# just taking vers with same indexes - modifers do not delete if not needed (subdiv -> no deletions, indexes stay)
	# BUT: hidegeom breaks verts index ordering!!!
	for v in active_mesh.vertices:
		vert2co[v.index] = Vector( v.co )
		vert2nrm[v.index] = Vector( v.normal )
	if len(obj.modifiers) == 0:
		# nothing to do
		return vert2co, vert2nrm
	#return vert2co
	####
	# v2: UV mapping
	# UV problem: depsgraph UV are "duplicated" to non-correlated vertices!!! not usable
	# tmpUVName = "tmp_pin"
	# if active_mesh.uv_layers.get(tmpUVName) is None:
	# 	active_mesh.uv_layers.new(name = tmpUVName)
	# tmpUV = active_mesh.uv_layers.get(tmpUVName)
	# for poly in active_mesh.polygons:
	# 	ipoly = poly.index
	# 	for idx, lIdx in enumerate(active_mesh.polygons[ipoly].loop_indices):
	# 		ivdx = active_mesh.polygons[ipoly].vertices[idx]
	# 		if ivdx not in vert2co:
	# 			vert2co[ivdx] = Vector( active_mesh.vertices[ivdx].co )
	# 		tmpUV.data[lIdx].uv = ( ivdx*100, ivdx)
	#wla_do.sys_update_mesh(obj)
	modf_cache = {}
	wla_do.modf_toggle(obj, wla_do.kWPLModifsIndexBreakers, False, modf_cache)
	depsgraph = bpy.context.evaluated_depsgraph_get()
	obj_eval = obj.evaluated_get(depsgraph)
	mesh_eval = obj_eval.data
	# DBG1
	# mesh_eval2 = bpy.data.meshes.new_from_object(obj_eval)
	# obj_eval2 = bpy.data.objects.new(name="TMP", object_data=mesh_eval2)
	# wla_do.link_object_to_scene(obj_eval2)
	# v1: bmesh way
	# bm = bmesh.new()
	# bm.from_object(obj, depsgraph, cage=False, face_normals=True)
	# bm.verts.ensure_lookup_table()
	# bm.verts.index_update()
	# tmpUV = bm.loops.layers.uv.get(tmpUVName)
	# for face in bm.faces:
	# 	for vert, loop in zip(face.verts, face.loops):
	# 		luv = loop[tmpUV].uv
	# 		vertKey = int(luv[0])
	# 		if abs(luv[0] - vertKey) > 0.01:
	# 			# new verts... not needed!
	# 			vertsSkipped = vertsSkipped+1
	# 			continue
	# 		vidx = vertKey2Idx[vertKey]
	# 		vert2co[vidx] = Vector(vert.co)
	# 	bm.free()

	# v2: UV mapping
	# tmpUV = mesh_eval.uv_layers.get(tmpUVName)
	# for poly in mesh_eval.polygons:
	# 	ipoly = poly.index
	# 	for idx, lIdx in enumerate(mesh_eval.polygons[ipoly].loop_indices):
	# 		ivdx = mesh_eval.polygons[ipoly].vertices[idx]
	# 		luv = tmpUV.data[lIdx].uv
	# 		if abs(int(luv[1])-luv[1]) > 0.0001:
	# 			# new verts... not needed!
	# 			continue
	# 		vidx_pre = int(luv[1]) # vertKey2Idx[vertKey]
	# 		if vidx_pre != int(luv[1]):
	# 			print("- reup idx diff", vidx_pre, luv)
	# 		if vidx_pre in vert2co:
	# 			diff = (vert2co[vidx_pre]-Vector(mesh_eval.vertices[ivdx].co)).length
	# 			if diff > 0:
	# 				print("- reup dst diff", diff, ivdx, luv)
	# 		vert2co[vidx_pre] = Vector(mesh_eval.vertices[ivdx].co)

	# v3: index2index. MUST MATCH
	#bm.normal_update()
	for v in mesh_eval.vertices:
		if v.index in vert2co:
			vert2co[v.index] = Vector( v.co )
			vert2nrm[v.index] = Vector( v.normal )
	#print("- get deformed coords", len(obj.data.vertices), len(vert2co), len(obj_eval.data.vertices) )
	obj_eval.to_mesh_clear()
	wla_do.modf_toggle(obj, wla_do.kWPLModifsIndexBreakers, None, modf_cache)
	return vert2co, vert2nrm

def bm_vertsCollectGuides(bm, vertsIdx, guidesEdgIdx, maxLoopSteps):
	# print("- guidesEdgIdx", guidesEdgIdx)
	if guidesEdgIdx is None:
		return None
	vertsGuides = []
	usedVerts = set()
	for vIdx in vertsIdx:
		usedVerts.add(vIdx)
	for vIdx in vertsIdx:
		vGuide = []
		nextv = bm.verts[vIdx]
		maxls = maxLoopSteps
		while nextv is not None and maxls > 0:
			maxls = maxls-1
			guideEdg = None
			for e in nextv.link_edges:
				if e.other_vert(nextv).index in usedVerts:
					continue
				if isinstance(guidesEdgIdx, str) and guidesEdgIdx == 'WIRE':
					if len(e.link_faces) == 0:
						guideEdg = e
						break
				elif isinstance(guidesEdgIdx, str) and guidesEdgIdx == 'SEAM':
					if e.seam:
						guideEdg = e
						break
				elif e.index in guidesEdgIdx:
					guideEdg = e
					break
			if guideEdg is not None:
				# adding verts to guide
				usedVerts.add(guideEdg.verts[0].index)
				usedVerts.add(guideEdg.verts[1].index)
				if nextv.index not in vGuide:
					vGuide.append(nextv.index)
				if guideEdg.other_vert(nextv).index not in vGuide:
					vGuide.append(guideEdg.other_vert(nextv).index)
				#print("- vert next", nextv.index, guideEdg.other_vert(nextv).index)
				nextv = guideEdg.other_vert(nextv)
			else:
				nextv = None
		if len(vGuide) > 0:
			vertsGuides.append(vGuide)
	return vertsGuides

def bm_closestVertIdx(src_bm, v_co_l, transferCache):
	if "bm_closestVert" not in transferCache:
		dots_tree_all = KDTree(len(src_bm.verts))
		for v in src_bm.verts:
			dots_tree_all.insert(v.co, v.index)
		dots_tree_all.balance()
		transferCache["bm_closestVert"] = dots_tree_all
	kdt = transferCache["bm_closestVert"]
	res = kdt.find(v_co_l)
	if res is None:
		return None
	return res[1]