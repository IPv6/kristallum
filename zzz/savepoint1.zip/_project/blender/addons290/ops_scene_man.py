import os, sys, time, datetime
import math, copy, string, random
import functools
import subprocess
import numpy as np
import bpy, bmesh, mathutils

import bpy.types
from mathutils import Vector, Matrix, Euler, Quaternion
from mathutils.bvhtree import BVHTree
from mathutils.kdtree import KDTree
from bpy_extras import view3d_utils
from bpy.props import *
from bpy.app.handlers import persistent

from . import config
from .tools import wla
from .tools import wla_do
from .tools import wla_arma
from .tools import wla_attr
from .tools import wla_edger
from .tools import wla_curve

kWPLLastBakePathKey = "#osl_last_bake_path"
kWPLLastBakeFileName = "_scene_bake"
# ==========================================
# Drivers and BPY-handlers/callbacks

kWPLGDriverInfoPrefix = "//"
kWPLGKey_DRV_ActiveViewLayer = "kWPLGKey_DRV_ActiveViewLayer"
kWPLGKey_DRV_NOTSET = "NONE"
kWPLGKey_DRV_SyncStatus = "kWPLGKey_DRV_SyncStatus"

kWPLGKey_HT_Objects = {}
kWPLGKey_HT_ObjUpdate = "drv:obj:"
kWPLGKey_HT_PropUpdate = "drv:prop2prop:"

def wpl_isSysLayer(depsgraph: bpy.types.Depsgraph, layerNameTok):
	# Driver, ScriptedExpression,
	# usage: wpl_isSysLayer(depsgraph, 'sysLayersP')
	# uses: scene_packAOV_v17
	if depsgraph is None:
		depsgraph =  bpy.context.evaluated_depsgraph_get()
	nowName = depsgraph.view_layer.name
	# checking active render layer
	if config.WPL_G.store[kWPLGKey_DRV_ActiveViewLayer] != nowName:
		config.WPL_G.store[kWPLGKey_DRV_ActiveViewLayer] = nowName
		if ("drv_verbose" in config.WPL_G.store) and config.WPL_G.store["drv_verbose"] == 1:
			ts = time.time()
			st = datetime.datetime.fromtimestamp(ts).strftime('%Y-%m-%d %H:%M:%S')
			print(kWPLGDriverInfoPrefix, config.WPL_G.store[kWPLGKey_DRV_SyncStatus]+":","Render Layer:", st, nowName, depsgraph.view_layer.samples)
	if ("!" in layerNameTok) and (layerNameTok.replace("!","").lower() not in nowName.lower()):
		return 1
	if (nowName == layerNameTok) or (layerNameTok.lower() in nowName.lower()):
		#print("wpl_isSysLayer == 1:", layerNameTok, nowName)
		return 1
	#print("wpl_isSysLayer == 0:", layerNameTok, nowName)
	return 0

def wpl_drvtest(*args, **kwargs):
	# usage: wpl_drvtest(self, locals()). Use_self must be enabled
	# https://blender.stackexchange.com/questions/199289/how-to-use-different-types-of-data-blocks-for-driver-variables
	for arg in args:
		print(arg)
	return -1 # a simple val to indicate working

def wpl_isAny(depsgraph: bpy.types.Depsgraph, objName):
	for ob in bpy.data.objects:
		if wla.isTokenInStr(objName, ob.name):
			#print("- Edges found",objName, ob.name)
			if ob.hide_render == False:
				return 1
	#print("- Edges NOT found",objName)
	return 0

def wpl_getProp(depsgraph: bpy.types.Depsgraph, objName, propName, propDefault, dself = None):
	# Driver, ScriptedExpression,
	# usage: wpl_getProp(depsgraph, '', '#isdebug', 0.0)
	# usage: wpl_getProp(depsgraph, 'zzz_mainCamera', 'location[0]', 0.0)
	# usage: wpl_getProp(depsgraph, 'zzz_mainCamera', 'is_ortho', 0.0)
	# usage: wpl_getProp(depsgraph, 'zzz_MainSun', 'location[0]', 0.0)
	# usage: wpl_getProp(depsgraph, 'zzz_MainSun', 'axis_z[0]', 1.0)
	# rint(kWPLGDriverInfoPrefix, "- ??? wpl_getProp:", objName, propName)
	# if dself is not None:
	# 	if dself.bl_idname == 'NodeSocketFloat' and dself.node.bl_idname == 'ShaderNodeValue':
	# 		# Getting tag from node.bl_label/node.name
	# 		print("- dself node", dself.node)
	if depsgraph is None:
		depsgraph =  bpy.context.evaluated_depsgraph_get()
	res = None
	if res is None and (propName == config.kWPLVirtualPropTagFrameNum):
		res = depsgraph.scene.frame_current
	if res is None:
		if objName is None or len(objName) == 0:
			objName = config.kWPLSystemMainCam
		obj = None
		if "," in objName:
			objToks = wla.strToTokens(objName,False)
			for tok in objToks:
				obj = wla.object_by_name(tok)
				if obj is not None:
					break
		else:
			obj = wla.object_by_name(objName)
		if (obj is None) and (objName == config.kWPLSystemMainSun):
			# fallback for DBG/Test scenes, camera as MainSun
			obj = wla.object_by_name(config.kWPLSystemMainCam)
		if obj is not None:
			if propName in obj:
				res = float(obj[propName])
			elif propName in config.kWPLVirtualPropTagObjDatas:
				if propName == 'is_ortho':
					res = 0.0
					if obj.type == 'CAMERA' and obj.data.type == 'ORTHO':
						res = 1.0
					if obj.type == 'LIGHT' and obj.data.type == 'SUN':
						res = 1.0
				elif propName == 'is_visible':
					res = 1.0
					if obj.hide_viewport:
						res = 0.0
				else:
					# same as in OSL bake
					# g_dims = obj.dimensions
					g_scale = obj.scale
					g_loc = obj.matrix_world.to_translation() # * obj.location
					mx_norm = obj.matrix_world.inverted().transposed().to_3x3()
					g_locx = (mx_norm @ Vector((1,0,0))).normalized()
					g_locy = (mx_norm @ Vector((0,1,0))).normalized()
					g_locz = (mx_norm @ Vector((0,0,1))).normalized()
					datasVals = (g_loc[0], g_loc[1], g_loc[2], g_locx[0], g_locx[1], g_locx[2], g_locy[0], g_locy[1], g_locy[2], g_locz[0], g_locz[1], g_locz[2], g_scale[0], g_scale[1], g_scale[2])
					res = datasVals[ config.kWPLVirtualPropTagObjDatas.index(propName) ]
		elif ("_drvdef_"+propName) in config.WPL_G.store:
			res = config.WPL_G.store["_drvdef_"+propName]
	if res is None:
		res = propDefault
	#print(kWPLGDriverInfoPrefix, "- wpl_getProp:", objName, propName, res)
	return res

# ========================================
# Short oneliners for PY parameters, 4EVAL
# params: facI = position (0.0,1.0)
def _mix3l(v0, v1, v2, pos_now):
	pos_middle = 0.5
	return wla.remap_F_M_T_linear(pos_now, pos_middle, (v0, v1, v2))
def _mix3s(v0, v1, v2, pos_middle, pos_now):
	return wla.remap_F_M_T_smooth(pos_now, pos_middle, 1.0, (v0, v1, v2))
def _mix2(v0, v1, pos_now):
	return v0+(v1-v0)*pos_now
def _mixArc(pos_now):
	pos_middle = 0.5
	return wla.remap_F_M_T_linear(pos_now, pos_middle, (0.0, 1.0, 0.0))
def _cuh(curvehash, pos_now):
	return wla.remap_curve_hash(curvehash, pos_now)
def _rndf(ffmin, ffmax):
	return random.uniform(ffmin, ffmax)
# def wpl_objprop(prop_name, defl = 1.0):
# 	if kWPLGKey_StickmanRefObj not in config.WPL_G.store:
# 		return defl
# 	obj = wla.object_by_name(config.WPL_G.store[kWPLGKey_StickmanRefObj])
# 	if obj is None:
# 		return defl
# 	if prop_name not in obj:
# 		return defl
# 	return obj[prop_name]
# ========================================

@persistent
def wpl_loadPost(scene):
	# https://docs.blender.org/api/current/bpy.app.handlers.html
	config.WPL_G.store[kWPLGKey_DRV_SyncStatus] = kWPLGKey_DRV_NOTSET
	config.WPL_G.store[kWPLGKey_DRV_ActiveViewLayer] = ""
	bpy.app.driver_namespace['wpl_isSysLayer'] = wpl_isSysLayer 
	bpy.app.driver_namespace['wpl_drvtest'] = wpl_drvtest
	bpy.app.driver_namespace['wpl_getProp'] = wpl_getProp
	bpy.app.driver_namespace['wpl_isAny'] = wpl_isAny
	# erasing or will be used for non-current frame
	store_keys2del = ["osl_frame"+str(0), "osl_frame"+str(1), "osl_frame"+str(2), "osl_frame"+str(3), "osl_frame"+str(4), "osl_frame"+str(5)]
	for kk in store_keys2del:
		if kk in config.WPL_G.store:
			del config.WPL_G.store[kk]
	if scene is None:
		# fixing bake path, if present
		camera_obj = wla.object_by_name(config.kWPLSystemMainCam)
		if camera_obj is not None and kWPLLastBakePathKey in camera_obj:
			last_bake_path = camera_obj[kWPLLastBakePathKey]
			osl_file_path = last_bake_path+kWPLLastBakeFileName+".osl"
			oso_file_path = last_bake_path+kWPLLastBakeFileName+".oso"
			osl_file_path = osl_file_path.replace("__","_")
			oso_file_path = osl_file_path.replace("__","_")
			if os.path.exists(osl_file_path) and oso_file_path:
				print("- wpl_loadPost: restoring last OSL Bake", osl_file_path)
				all_nodes = wla.mat_getAllNodes(True, False, False)
				for node in all_nodes:
					if node.bl_idname == 'ShaderNodeScript' and config.kWPLSystemOslScript in node.label:
						# installing bake script
						node.mode = 'EXTERNAL'
						node.filepath = osl_file_path

@persistent
def wpl_renderStart(scene):
	config.WPL_G.store[kWPLGKey_DRV_ActiveViewLayer] = ""
	ts = time.time()
	st = datetime.datetime.fromtimestamp(ts).strftime('%Y-%m-%d %H:%M:%S')
	#print("...")
	print(kWPLGDriverInfoPrefix, config.WPL_G.store[kWPLGKey_DRV_SyncStatus]+":","*** Starting:", st)

@persistent
def wpl_renderStop(scene):
	config.WPL_G.store[kWPLGKey_DRV_ActiveViewLayer] = ""
	ts = time.time()
	st = datetime.datetime.fromtimestamp(ts).strftime('%Y-%m-%d %H:%M:%S')
	print(kWPLGDriverInfoPrefix, config.WPL_G.store[kWPLGKey_DRV_SyncStatus]+":","*** Stopping:", st)

@persistent
def wpl_frameChange(scene_ui):
	scene_eval = scene_ui #depsgraph.scene
	if "last:wpl_frameChange" not in config.WPL_G.store:
		config.WPL_G.store["last:wpl_frameChange"] = -1
	frm_prev = config.WPL_G.store["last:wpl_frameChange"]
	frm = scene_eval.frame_current
	if frm_prev != frm:
		config.WPL_G.store["last:wpl_frameChange"] = frm
		#ts = time.time()
		#st = datetime.datetime.fromtimestamp(ts).strftime('%Y-%m-%d %H:%M:%S')
		print(kWPLGDriverInfoPrefix, config.WPL_G.store[kWPLGKey_DRV_SyncStatus]+":","Frame change:", frm)
		# checking kWPLFrameBindPostfix in collection names
		all_colls = []
		getSceneCollections(scene_eval.collection, all_colls)
		for coll in all_colls:
			if (config.kWPLFrameBindPostfix in coll.name) or (config.kWPLFrameBindPostfixNo in coll.name):
				if (config.kWPLFrameBindPostfixNo in coll.name):
						frmKey = config.kWPLFrameBindPostfixNo+str(frm)
						frmHide = False
						if frmKey in coll.name:
							frmHide = True
				else:
					frmKey = config.kWPLFrameBindPostfix+str(frm)
					frmHide = True
					if frmKey in coll.name:
						frmHide = False
				#if frm == 0:
				#	frmHide = False
				coll.hide_viewport = frmHide
				coll.hide_render = frmHide
	return

@persistent
def wpl_depsChange(scene):
	# custom driver-like updating, once 300ms
	# used for PFF
	def doCheck(testrun):
		changes = 0
		ht_keys = list(kWPLGKey_HT_Objects.keys())
		for ht_i in ht_keys:
			hotobj_name = kWPLGKey_HT_Objects[ht_i]["object"]
			obj = wla.object_by_name(hotobj_name)
			if obj is None:
				print(kWPLGDriverInfoPrefix, config.WPL_G.store[kWPLGKey_DRV_SyncStatus]+":","Deps change: object not found, removing", ht_i)
				del kWPLGKey_HT_Objects[ht_i]
				continue
			if kWPLGKey_HT_Objects[ht_i]["update"] is not None:
				update_list = kWPLGKey_HT_Objects[ht_i]["update"]
				if kWPLGKey_HT_ObjUpdate in ht_i:
					op_hash = sum([inner for outer in obj.matrix_world for inner in outer])+(obj.hide_render*0.7)+(obj.hide_viewport*0.31)
					if ("op_hash" not in kWPLGKey_HT_Objects[ht_i]) or (kWPLGKey_HT_Objects[ht_i]["op_hash"] != op_hash):
						changes = changes+1
						if testrun == False:
							# actual changes
							kWPLGKey_HT_Objects[ht_i]["op_hash"] = op_hash
							for up_i in update_list:
								callab = update_list[up_i]
								callab(obj, kWPLGKey_HT_Objects[ht_i])
				if kWPLGKey_HT_PropUpdate in ht_i:
					propset_from = kWPLGKey_HT_Objects[ht_i]["pgroup"]
					prop_from = kWPLGKey_HT_Objects[ht_i]["pgroup_prop"]
					prop_val = getattr(propset_from, prop_from)
					op_hash = sum([elem for elem in prop_val])
					if ("op_hash" not in kWPLGKey_HT_Objects[ht_i]) or (kWPLGKey_HT_Objects[ht_i]["op_hash"] != op_hash):
						changes = changes+1
						if testrun == False:
							# actual changes
							kWPLGKey_HT_Objects[ht_i]["prop_val"] = prop_val
							kWPLGKey_HT_Objects[ht_i]["op_hash"] = op_hash
							#print("- col change", kWPLGKey_HT_Objects[ht_i], ht_i)
							for up_i in update_list:
								callab = update_list[up_i]
								callab(obj, kWPLGKey_HT_Objects[ht_i])
		return changes
	def doOnTimer(valid_depsc_cct):
		if "depsc_cct" not in config.WPL_G.store:
			return
		if config.WPL_G.store["depsc_cct"] != valid_depsc_cct:
			# more fresh timer exists
			return
		doCheck(False)
		return None
	if doCheck(True) > 0:
		if "depsc_cct" not in config.WPL_G.store:
			config.WPL_G.store["depsc_cct"] = 0
		valid_depsc_cct = config.WPL_G.store["depsc_cct"]+1
		config.WPL_G.store["depsc_cct"] = valid_depsc_cct
		bpy.app.timers.register(functools.partial(doOnTimer, valid_depsc_cct), first_interval = 0.3)
	return

def ensureMaterialDrivers():
	# https://blender.stackexchange.com/questions/118350/how-to-update-the-dependencies-of-a-driver-via-python-script
	stats = {"updatedDrivers": 0}
	def testNode(nd):
		if nd.bl_idname == 'ShaderNodeValue':
			if config.kWPLSystemNodeTagInject in nd.label and "<dbg_link>" in nd.label:
				prevValue = nd.outputs[0].default_value
				nd.outputs[0].default_value = prevValue+1.0
				stats["updatedDrivers"] = stats["updatedDrivers"]+1
		# if nd.bl_idname == 'ShaderNodeGroup': toks = "zzz_"
		# 	handledDrivers = stats["handledDrivers"]
		# 	if nd.node_tree.animation_data is not None:
		# 		for d in nd.node_tree.animation_data.drivers:
		# 			drv = d.driver
		# 			if drv not in handledDrivers:
		# 				handledDrivers.append(drv)
		# 				expr = drv.expression
		# 				# adding visibility link to MainCam for easier debugging/reloads
		# 				if ("dbg_link" in expr) or (len(drv.variables) > 0 and drv.variables[0].name == 'dbg_link' and drv.variables[0].targets[0].id is None):
		# 					print("- materials: injecting local dbg_link...")
		# 					if(wla.object_by_name(config.kWPLSystemDbgNum)):
		# 						print("- Lib source detected, skipping inject")
		# 						continue
		# 					while len(drv.variables) > 0:
		# 						drv.variables.remove(drv.variables[0])
		# 					drv.variables.new()
		# 					drv.variables[0].name = 'dbg_link'
		# 					drv.variables[0].type= 'SINGLE_PROP'
		# 					drv.variables[0].targets[0].id = wla.object_by_name(config.kWPLSystemMainCam)
		# 					drv.variables[0].targets[0].data_path = "hide_render"
		# 				if toks is not None:
		# 					if wla.isTokenInStr(toks, expr) == False:
		# 						continue
		# 				#print("- updating driver expression", expr)
		# 				drv.expression = expr + ""
		# 				stats["updatedDrivers"] = stats["updatedDrivers"]+1
	node_groups = bpy.data.node_groups
	for group in node_groups:
		for node in group.nodes:
			testNode(node)
	# mats_all = wla.mat_getAll()
	# for mat in mats_all:
	# 	if mat.use_nodes:
	# 		for node in mat.node_tree.nodes:
	# 			testNode(node)
	return stats["updatedDrivers"]

# ==========================================

def ensureWorkspDefauts():
	bpy.context.space_data.shading.type = 'SOLID'
	#wla_do.switch_orientation('LOCAL', 'MEDIAN_POINT') -> wplverts_getori
	bpy.ops.mesh.wplverts_getori(opt_mode='UNGRAB')
	bpy.context.scene.tool_settings.transform_pivot_point = 'MEDIAN_POINT'
	bpy.context.scene.tool_settings.use_mesh_automerge = False
	bpy.context.scene.tool_settings.sculpt.use_symmetry_x = False
	bpy.context.scene.tool_settings.sculpt.use_symmetry_y = False
	bpy.context.scene.tool_settings.sculpt.use_symmetry_z = False
	bpy.context.scene.tool_settings.use_snap = False
	bpy.context.space_data.shading.light = 'STUDIO'
	bpy.context.space_data.shading.color_type = 'MATERIAL'
	bpy.context.space_data.shading.show_shadows = False
	bpy.context.space_data.overlay.show_overlays = True
	bpy.context.space_data.show_gizmo = True
	bpy.context.space_data.show_gizmo_object_translate = True
	if wla.is_object_mode():
		bpy.context.scene.tool_settings.use_proportional_edit_objects = False
	if wla.is_edit_mode():
		bpy.context.scene.tool_settings.use_proportional_edit = False
		bpy.context.scene.tool_settings.use_proportional_connected = True
		bpy.context.space_data.overlay.show_extra_edge_length = False
		bpy.context.space_data.overlay.show_extra_indices = False
		bpy.context.space_data.overlay.show_face_normals = False
		bpy.context.space_data.overlay.show_vertex_normals = False
		bpy.context.space_data.overlay.show_split_normals = False
		if (bpy.context.object is not None) and (bpy.context.object.type in ['MESH']):
			bpy.context.object.use_mesh_mirror_x = False
			bpy.context.object.use_mesh_mirror_y = False
			bpy.context.object.use_mesh_mirror_z = False

def ensureSceneDefauts(forCamera):
	ensureWorkspDefauts()
	bpy.app.debug_wm = False # True for ALL actions to be dumped into Info panels
	c_scene = bpy.context.scene
	# Resettings tools to defauls
	bpy.data.brushes["Grab"].falloff_shape = 'PROJECTED'
	bpy.data.brushes["Smooth"].falloff_shape = 'PROJECTED'
	bpy.data.brushes["Inflate/Deflate"].falloff_shape = 'PROJECTED'
	bpy.data.brushes["Pencil"].size = 10 # GP brush
	bpy.data.brushes["Smooth Stroke"].strength = 0.2 # GP brush
	c_scene.tool_settings.gpencil_paint.brush.gpencil_settings.pen_strength = 1.0 # GP brush
	#bpy.data.brushes["Inflate/Deflate"].direction = 'ADD'
	if c_scene.render.engine != 'CYCLES' or c_scene.cycles.shading_system != True:
		print("- ensureSceneDefauts: enabling CYCLES OSL")
		c_scene.render.engine = 'CYCLES'
		c_scene.cycles.device = 'CPU'
		c_scene.cycles.shading_system = True # OSL!!!
		c_scene.cycles.feature_set = 'EXPERIMENTAL'
	blend_file = os.path.basename(bpy.data.filepath)
	blend_w = wla.safeFloat(blend_file, 0.0, "_ww")
	if blend_w > 0:
		c_scene.render.resolution_x = int(blend_w)
	blend_h = wla.safeFloat(blend_file, 0.0, "_hh")
	if blend_h > 0:
		c_scene.render.resolution_y = int(blend_h)
	c_scene.render.image_settings.file_format ='OPEN_EXR_MULTILAYER'
	c_scene.render.image_settings.color_mode = 'RGBA'
	c_scene.render.image_settings.color_depth = '16'
	c_scene.render.use_compositing = True
	c_scene.render.use_sequencer = False
	c_scene.render.film_transparent = True
	c_scene.cycles.film_transparent_glass = True
	c_scene.cycles.film_transparent_roughness = 0.1
	c_scene.cycles.preview_samples = 1
	c_scene.cycles.max_bounces = 1
	c_scene.cycles.samples = 100
	c_scene.cycles.use_layer_samples = 'USE'
	c_scene.cycles.transparent_max_bounces = 100
	c_scene.cycles.diffuse_bounces = 3
	c_scene.cycles.glossy_bounces = 3
	c_scene.cycles.transmission_bounces = 3
	c_scene.cycles.volume_bounces = 3
	c_scene.view_settings.view_transform = 'Standard'
	c_scene.sequencer_colorspace_settings.name = 'Raw'
	#if c_scene.cycles.use_denoising != True:
	#OpenImageDenoiser - enabled, лучше для низкого количества сэмплов
	c_scene.cycles.denoiser = "OPENIMAGEDENOISE"
	c_scene.cycles.use_denoising = True
	c_scene.cycles.use_preview_denoising = False
	for area in bpy.context.screen.areas:
		if area.type == 'VIEW_3D':
			c_space = area.spaces[0]
			c_space.clip_start = 0.03
			c_space.clip_end = 10000
			#c_space = bpy.data.screens["Default"]
	if config.kWPLSystemNodeTagPFF in config.WPL_G.store[kWPLGKey_DRV_SyncStatus]:
		config.WPL_G.store[kWPLGKey_DRV_SyncStatus] = "INVALID"
	if forCamera is not None:
		c_scene.camera = forCamera
	return

def getSceneCollections(collection, out_list, case = False):
	if collection.children is None:
		return
	children = sorted (
		collection.children, 
		key = lambda c: c.name if case else c.name.lower()
	)
	for child in children:
		out_list.append(child)
		getSceneCollections(child, out_list, case)

def sortSceneCollections(collection, case = False):
	if collection.children is None:
		return
	children = sorted (
		collection.children, 
		key = lambda c: c.name if case else c.name.lower()
	)
	for child in children:
		collection.children.unlink(child)
		collection.children.link(child)
		sortSceneCollections(child, case)

def sortViewLayers():
	print("- sorting view_layers...")
	vl_list = []
	vl2del = []
	for vl in bpy.context.scene.view_layers:
		vl_list.append(vl.name)
		vl2del.append(vl)
	tmpvl = bpy.context.scene.view_layers.new(name="TMP")
	for vl in vl2del:
		if vl.name == tmpvl.name:
			continue
		bpy.context.scene.view_layers.remove(vl)
	vl_list = sorted(vl_list)
	for vl_name in vl_list:
		bpy.context.scene.view_layers.new(name=vl_name)
	bpy.context.scene.view_layers.remove(tmpvl)
	return

def getSceneCollection(subname):
	sysColl = bpy.data.collections.get(subname)
	return sysColl

def getViewLayer(subname):
	result = None
	for vl in bpy.context.scene.view_layers:
		if subname.lower() in vl.name.lower():
			if result is None or len(vl.name) < len(result.name):
				# getting most short name (important for Mains/name tags)
				result = vl
	return result

def ensureViewLayerPartial(subname):
	isNew = False
	result = getViewLayer(subname)
	if result is None:
		result = bpy.context.scene.view_layers.new(name=subname)
		isNew = True
	return result, isNew

# def getMatNodesBackmapped(allMats, allObjs):
# 	all_nodes_backmap = {}
# 	if allMats is None:
# 		allMats = wla.mat_getAll()
# 	if allObjs is None:
# 		allObjs = bpy.data.objects
# 	def matNodeCach(nd):
# 		if nd not in all_nodes_backmap:
# 			all_nodes_backmap[nd] = {
# 				"<mat>": [],
# 				"<obj>": [],
# 				"<root>": [],
# 				"<tag>": [],
# 			}
# 		return all_nodes_backmap[nd]
# 	# for mat in allMats:
# 	# 	if mat.use_nodes:
# 	# 		for node in mat.node_tree.nodes:
# 	# 			cach = matNodeCach(node)
# 	# 			if mat.name not in cach["<mat>"]:
# 	# 				cach["<mat>"].append(mat.name)
# 	for obj in allObjs:
# 		objtag = None
# 		isObjMappable = False
# 		for slt in obj.material_slots:
# 			mat = slt.material
# 			if (mat is not None) and mat.use_nodes:
# 				mat_name = mat.name
# 				if config.kWPLSuppVGScriptToken in mat_name:
# 					mat_name = mat_name.replace(config.kWPLSuppVGScriptToken, "")
# 					isObjMappable = True
# 					if config.kWPLNodePrefix in mat_name:
# 						tagidx = mat_name.find(config.kWPLNodePrefix)
# 						objtag = mat_name[(tagidx+len(config.kWPLNodePrefix)):].strip()
# 						objtag = wla.strBareName(objtag, False, True, True, False, False, False)
# 					break
# 		if isObjMappable == False:
# 			continue
# 		for slt in obj.material_slots:
# 			mat = slt.material
# 			if (mat is not None) and mat.use_nodes:
# 				if config.kWPLSystemReestrToken in mat.name:
# 					continue
# 				if config.kWPLMatTokenLocal in mat.name:
# 					continue
# 				for node in mat.node_tree.nodes:
# 					cach = matNodeCach(node)
# 					if mat.name not in cach["<mat>"]:
# 						cach["<mat>"].append(mat.name)
# 					if obj.name not in cach["<obj>"]:
# 						cach["<obj>"].append(obj.name)
# 					#root = wla.object_get_root(obj)
# 					_, rootp = wla.object_root_data(obj)
# 					if rootp is not None and rootp.name not in cach["<root>"]:
# 						cach["<root>"].append(rootp.name)
# 					if objtag is not None and objtag not in cach["<tag>"]:
# 						cach["<tag>"].append(objtag)
# 					if (config.kWPLSystemNodeTagInject in node.label) and ("<tag>" in node.label):
# 						# print("- node tags", node.label, cach, obj.name, mat.name)
# 						if len(cach["<tag>"]) > 1:
# 							print("- ERROR: too many tags per node:", "obj:"+obj.name, "mat:"+mat.name, "tag:"+objtag, cach)
# 							return None
# 						# print("- tag detected", objtag, obj.name, mat.name)
# 	return all_nodes_backmap

def getIsDumpable(obj):
	if obj is None:
		return False
	if obj.name == config.kWPLSystemMainSun or obj.name == config.kWPLSystemMainCam:
		return True
	if obj.hide_viewport and obj.hide_select and obj.hide_render:
		return False
	# 2D curves: shapes only. SVG objects are 2D curves but can be useful for rendering
	#if obj.type == 'CURVE' and obj.data.dimensions == '2D':
	if wla.isTokenInStr(config.kWPLSystemOslAssets, obj.name): # kWPLObjShapeToken kWPLObjShaperToken already
		return False
	# if wla.isTokenInStr(config.kWPLSuppBackupToken, obj.name):
	# 	return False
	obj_full_name = wla.object_full_name(obj)
	if config.kWPLSystemReestrToken in obj_full_name:
		return False
	return True

def sortkey4obj(obj_name):
	if obj_name not in bpy.data.objects:
		return "zzzzzzzz"
	camera_obj = wla.object_by_name(config.kWPLSystemMainCam)
	#cam_g_loc = camera_obj.matrix_world.to_translation()
	obj = bpy.data.objects.get(obj_name)
	#obj_full_name = wla.object_full_name(obj)
	objtype = "z"
	objsubtype = "z"
	if obj.name == config.kWPLSystemMainSun:
		objtype = "a"
	elif obj.name == config.kWPLSystemMainCam:
		objtype = "b"
	elif obj.type == 'CURVE' or obj.type == 'FONT' or obj.type == 'ARMATURE':
		objtype = "d"
	elif (obj.animation_data is not None):
		objtype = "e"
	elif wla.isTokenInStr(config.kWPLSystemOslIncluded, obj.name):
		objtype = "f"
	rootp = obj
	while (rootp.parent is not None):
		rootp = rootp.parent
		if rootp.type == 'CURVE' or rootp.type == 'FONT' or rootp.type == 'ARMATURE':
			objsubtype = "d"
		elif (rootp.animation_data is not None):
			objsubtype = "e"
		elif wla.isTokenInStr(config.kWPLSystemOslIncluded, rootp.name):
			objsubtype = "f"
	sortname = objtype+objsubtype+rootp.name[:50].zfill(50)+obj.name[:50].zfill(50)
	#print ("-", obj.name, sortname)
	return sortname

def oslbake_getscene( context ):
	bake_warns = 0
	c_scene = bpy.context.scene
	frameF = c_scene.frame_start
	frameT = c_scene.frame_end
	frameC = c_scene.frame_current
	# frame data and object indexes.
	# important: obj/mat indexes should NOT change between frames
	bounds_cache = {}
	objs2dump_names = []
	for i,obj in enumerate(bpy.data.objects):
		obj.pass_index = i + config.kWPLOslQueryMaxObjs
		isOk = 1
		if not getIsDumpable(obj):
			isOk = -1
		if wla.isTokenInStr(config.kWPLSystemOslIgnored, obj.name):
			isOk = -2
		# overload
		if wla.isTokenInStr(config.kWPLSystemOslIncluded, obj.name):
			isOk = 1
		if isOk > 0:
			objs2dump_names.append(obj.name)
		#else:
		#	print("OSL-Bake: object skipped:", obj.name, isOk)
	objs2dump_names = sorted(objs2dump_names, key=lambda k: sortkey4obj(k))
	if len(objs2dump_names) > config.kWPLOslQueryMaxObjs:
		# too many objects
		print("OSL-Bake: Too many objects ("+str(len(objs2dump_names))+"). Trimming to first "+str(config.kWPLOslQueryMaxObjs))
		objs2dump_names = objs2dump_names[:config.kWPLOslQueryMaxObjs]
	else:
		print("OSL-Bake: objects =", str(len(objs2dump_names)))
	objs2dump = []
	objsI2oMap = {}
	objsLastIndex = 0
	objsMap_frame = {}
	for i,obj_name in enumerate(objs2dump_names):
		# in advance for proper parenting
		if obj_name in bpy.data.objects:
			obj = bpy.data.objects.get(obj_name)
			objs2dump.append(obj)
			objsLastIndex = i+1
			obj.pass_index = objsLastIndex
			objsI2oMap[obj.pass_index] = obj
	matLastIndex = 0
	for m in bpy.data.materials:
		matLastIndex = matLastIndex+1
		m.pass_index = matLastIndex
	wla_do.sys_update_mesh(None) # update tagged
	for i, obj in enumerate(objs2dump):
		item = {}
		g_loc = Vector((0,0,0))
		# g_locx = Vector((1,0,0))
		# g_locy = Vector((0,1,0))
		# g_locz = Vector((0,0,1))
		g_dims = Vector((0,0,0))
		bbc, _ = wla.object_bounds_recursive(obj, bounds_cache)
		if len(bbc) > 0:
			g_dims = obj.dimensions
			g_loc = obj.matrix_world.to_translation() # * obj.location
			mx_norm = obj.matrix_world.inverted().transposed().to_3x3()
			# g_locx = (mx_norm @ Vector((1,0,0))).normalized()
			# g_locy = (mx_norm @ Vector((0,1,0))).normalized()
			# g_locz = (mx_norm @ Vector((0,0,1))).normalized()
		else:
			#print("- Faking skipping zero-scaled", obj.name)
			bbc = [ (0,0,0) ]
		bbc_min_pt = [ min(item[0] for item in bbc), min(item[1] for item in bbc), min(item[2] for item in bbc)]
		bbc_max_pt = [ max(item[0] for item in bbc), max(item[1] for item in bbc), max(item[2] for item in bbc)]
		obj_name = obj.name.replace("\"","'")
		if len(obj_name) > config.kWPLOslQueryMaxName:
			obj_name = obj_name[:config.kWPLOslQueryMaxName]
		item["name"] = "\""+obj_name+"\""
		# object Root/Parent
		item["rootI"] = repr(obj.pass_index) #self! for easier chaining
		item["parentI"] = repr(obj.pass_index) #self! for easier chaining
		#rootp_lastok = None
		if (obj.parent is not None) and (obj.parent in objs2dump):
			rootp = obj.parent
			rootI = rootp.pass_index
			item["parentI"] = repr(rootI)
			while (rootp is not None) and (rootp in objs2dump):
				if wla.isTokenInStr(config.kWPLObjFrameWrapper, rootp.name):
					# root search stops here
					break
				rootI = rootp.pass_index
				item["rootI"] = repr(rootI)
				#rootp_lastok = rootp
				rootp = rootp.parent
		#if rootp_lastok is not None:
		#	print("- oslbake_getscene:", obj.name, rootp_lastok.name, rootp_lastok.pass_index, rootI)
		# object ref point
		# refPnt, refDir = getObjRefdata(obj)
		# item["refPnt"] ="point("+repr(refPnt[0])+","+repr(refPnt[1])+","+repr(refPnt[2])+")"
		# item["refDir"] = "point("+repr(refDir[0])+","+repr(refDir[1])+","+repr(refDir[2])+")"
		# object parameters
		item["location"] = "point("+repr(g_loc[0])+","+repr(g_loc[1])+","+repr(g_loc[2])+")"
		# item["normx"] = "point("+repr(g_locx[0])+","+repr(g_locx[1])+","+repr(g_locx[2])+")"
		# item["normy"] = "point("+repr(g_locy[0])+","+repr(g_locy[1])+","+repr(g_locy[2])+")"
		# item["normz"] = "point("+repr(g_locz[0])+","+repr(g_locz[1])+","+repr(g_locz[2])+")"
		item["scale"] = "point("+repr(obj.scale[0])+","+repr(obj.scale[1])+","+repr(obj.scale[2])+")"
		maxX = abs(bbc_max_pt[0]-bbc_min_pt[0])
		maxY = abs(bbc_max_pt[1]-bbc_min_pt[1])
		maxZ = abs(bbc_max_pt[2]-bbc_min_pt[2])
		if obj.type == 'MESH' or obj.type == 'CURVE' or obj.type == 'FONT':
			item["dims"] = "point("+repr(g_dims[0])+","+repr(g_dims[1])+","+repr(g_dims[2])+")"
		else:
			# dimensions are not usefull for EMPTY
			item["dims"] = "point("+repr(maxX)+","+repr(maxY)+","+repr(maxZ)+")"
		if wla.isTokenInStr(config.kWPLSystemOslIncluded, wla.object_full_name(obj)): # and bbc_ok
			# check not working when frames are dropped to (0,0,0)
			# check not working when object is not visible -> reenabling for bake...
			#  and (obj.hide_viewport == False or obj.type == 'EMPTY')
			if (maxX+maxY+maxZ) > 7:
				if (wla.isTokenInStr(config.kWPLObjFrameWrapperF0, wla.object_full_name(obj)) == False) and (wla.isTokenInStr(config.kWPLSystemOslBgObj, wla.object_full_name(obj)) == False) and obj.type == 'MESH':
					# CURVES has a problem: https://developer.blender.org/T92500
					obj.update_tag()
					print("// OSL: suspicious object size", item["dims"], obj.name)
					print("// OSL: - tagged at ", wla.object_full_name(obj))
					bake_warns = bake_warns+1
			# if "f6_fg" in wla.object_full_name(obj): # DBG
			# 	print("// DBG: Object BBs", obj.name, bbc_min_pt, bbc_max_pt)
		item["bbmin"] = "point("+repr(bbc_min_pt[0])+","+repr(bbc_min_pt[1])+","+repr(bbc_min_pt[2])+")"
		item["bbmax"] = "point("+repr(bbc_max_pt[0])+","+repr(bbc_max_pt[1])+","+repr(bbc_max_pt[2])+")"
		# item["iscurve"] = repr(0.0)
		# if obj.type == 'CURVE' or obj.type == 'FONT':
		# 	item["iscurve"] = repr(1.0)
		# if obj.type == 'CAMERA':
		# 	if obj.data.type == 'ORTHO':
		# 		item["iscurve"] = repr(1.0)
		# 		print("- OLS bake: ortho camera")
		# item["color"] = "color("+repr(obj.color[0])+","+repr(obj.color[1])+","+repr(obj.color[2])+")"
		# for custprp in custprpNameParts:
		# 	if obj.get(custprp) is not None:
		# 		val = obj[custprp]
		# 		if isinstance(val,int) or isinstance(val,float):
		# 			custcol = Vector((val,val,val))
		# 		else:
		# 			custcol = val
		# 		print("- Found object prop:","["+obj.name+"]:",custprp) #,val,custcol
		# 	else:
		# 		custcol = Vector((0,0,0))
		# 	#print("Custom object parameters", obj.name, custprp, custcol)
		# 	item[custprp] = "color("+repr(custcol[0])+","+repr(custcol[1])+","+repr(custcol[2])+")"
		objsMap_frame[obj.name] = item
		# BAKE DEBUG
		# if obj.pass_index == 215 or obj.pass_index == 207:
		# 	print("- DBG:"+str(obj.pass_index)+":", item )
	config.WPL_G.store["osl_frame"+str(frameC)] = objsMap_frame
	frames_key = []
	frames_idx = []
	for frm in range(int(frameF), int(frameT)+1):
		if "osl_frame"+str(frm) in config.WPL_G.store:
			frames_key.append("osl_frame"+str(frm))
			frames_idx.append(frm)
	if frameC not in frames_idx:
		frames_key.append("osl_frame"+str(frameC))
		frames_idx.append(frameC)
	print("OSL-Bake: frames in cache:", frames_key, "current frame:", frameC)
	osl_content = []
	osl_content.append("/*")
	osl_content.append(" WARNING: text below is autogenerated, DO NOT EDIT.")
	osl_content.append(" TIMESTAMP: "+str(datetime.datetime.now()))
	osl_content.append(" FILE: "+bpy.data.filepath)
	osl_content.append(" FRAMES: "+",".join(frames_key))
	#for k in objs2dump_names_full:
	#	osl_content.append(k+": "+sortkey4obj(k))
	osl_content.append("*/")
	osl_content.append("")
	osl_content.append("#define DUMPLEN "+str(objsLastIndex))
	osl_content.append("#define STRSTR_INIT string splitTemp[3]")
	osl_content.append("#define STRSTR(orig,substr) (split((orig), splitTemp, (substr), 2) > 1)")
	# token check from osl_detNameStuff_v10.osl
	osl_content.append("int isNameTokenPresent(string objName, string obj_nameTokens){")
	osl_content.append("STRSTR_INIT;")
	osl_content.append("int nameTokenId = 0;if(strlen(obj_nameTokens)>0){")
	osl_content.append("if(startswith(obj_nameTokens,\",\")){ string toks[10];int toksCnt = split(obj_nameTokens,toks,\",\",10);")
	osl_content.append("for(int i=1;i<toksCnt;i++){ if(strlen(toks[i])>0 && STRSTR(objName, toks[i])){nameTokenId = 1; break;};};")
	osl_content.append("}else{ if(STRSTR(objName, obj_nameTokens)){nameTokenId = 1;};};")
	osl_content.append("};return nameTokenId;}")
	osl_content.append("")
	osl_content.append("shader sceneQuery (")
	osl_content.append(" int in_frame = 0,")
	osl_content.append(" int by_index = 0,")
	#osl_content.append(" string name_objColor = \"\",")
	osl_content.append(" string name_objTok = \"\",")

	osl_content.append(" output int index = 0,")
	#osl_content.append(" output int parent_index = 0,")
	osl_content.append(" output int root_index = 0,")
	osl_content.append(" output point g_Location = point(0,0,0),")
	#osl_content.append(" output point g_normalX = point(0,0,0),")
	#osl_content.append(" output point g_normalY = point(0,0,0),")
	#osl_content.append(" output point g_normalZ = point(0,0,0),")
	osl_content.append(" output point g_boundsMax = point(0,0,0),")
	osl_content.append(" output point g_boundsMin = point(0,0,0),")
	osl_content.append(" output point scale = point(1,1,1),")
	osl_content.append(" output point dimensions = point(0,0,0),")
	osl_content.append(" output float objIsNameTok = 0.0,")
	#osl_content.append(" output color objColor = color(0,0,0),")
	#osl_content.append(" output float objIsCurve = 0.0,")
	#osl_content.append(" output point objRefPnt = point(0,0,0),")
	#osl_content.append(" output point objRefDir = point(0,0,0),")
	osl_content.append("){")
	osl_content.append("STRSTR_INIT;")
	for fi, frame_key in enumerate(frames_key):
		objsMap = config.WPL_G.store[frame_key]
		objsData = []
		objsData_frameC = []
		for obj in objs2dump:
			if (obj.name not in objsMap_frame):
				print("// OSL: invalid frame cache, obj not found:", obj.name)
				bake_warns = bake_warns+1
				continue
			if (obj.name not in objsMap):
				objsData.append(objsMap_frame[obj.name])
			else:
				objsData.append(objsMap[obj.name])
			objsData_frameC.append(objsMap_frame[obj.name])
		if fi > 0:
			osl_content.append("else") # ot avoid OSL optimizations...
		if fi < len(frames_key)-1:
			osl_content.append(" if (in_frame == "+str(frames_idx[fi])+"){ // baked frame "+str(frames_idx[fi]))
		else:
			#osl_content.append(" { // baked frame "+str(frames_idx[fi]))
			osl_content.append(" if (in_frame >= 0){ // baked frame "+str(frames_idx[fi]))
		#osl_content.append("  int pIndex[DUMPLEN] = {"+",".join([ item['parentI'] for item in objsData_frameC ])+"};")
		osl_content.append("  int rIndex[DUMPLEN] = {"+",".join([ item['rootI'] for item in objsData_frameC ])+"};")
		# osl_content.append("  point refPnt[DUMPLEN] = {"+",".join([ item['refPnt'] for item in objsData_frameC ])+"};")
		# osl_content.append("  point refDir[DUMPLEN] = {"+",".join([ item['refDir'] for item in objsData_frameC ])+"};")
		osl_content.append("  string sNames[DUMPLEN] = {"+",".join([ item['name'] for item in objsData ])+"};")
		osl_content.append("  point sLocas[DUMPLEN] = {"+",".join([ item['location'] for item in objsData ])+"};")
		osl_content.append("  point sScales[DUMPLEN] = {"+",".join([ item['scale'] for item in objsData ])+"};")
		# osl_content.append("  point sNormalX[DUMPLEN] = {"+",".join([ item['normx'] for item in objsData ])+"};")
		# osl_content.append("  point sNormalY[DUMPLEN] = {"+",".join([ item['normy'] for item in objsData ])+"};")
		# osl_content.append("  point sNormalZ[DUMPLEN] = {"+",".join([ item['normz'] for item in objsData ])+"};")
		osl_content.append("  point sDimens[DUMPLEN] = {"+",".join([ item['dims'] for item in objsData ])+"};")
		osl_content.append("  point sBbmax[DUMPLEN] = {"+",".join([ item['bbmax'] for item in objsData ])+"};")
		osl_content.append("  point sBbmin[DUMPLEN] = {"+",".join([ item['bbmin'] for item in objsData ])+"};")
		#osl_content.append("  point sColor[DUMPLEN] = {"+",".join([ item['color'] for item in objsData ])+"};")
		#osl_content.append("  float isCurve[DUMPLEN] = {"+",".join([ item['iscurve'] for item in objsData ])+"};")
		# for custprp in custprpNameParts:
		# 	custprp_safe = custprpNamePartsMap[custprp]
		# 	osl_content.append("  point cp"+custprp_safe+"[DUMPLEN] = {"+",".join([ item[custprp] for item in objsData ])+"};")
		osl_content.append("  int iFoundIndex = -1;")
		osl_content.append("  if(by_index > 0){") # if_indx1
		osl_content.append("   iFoundIndex = by_index-1;")
		osl_content.append("  }") # if_indx1
		osl_content.append("  if(iFoundIndex >= 0 && iFoundIndex < DUMPLEN){") # if_indx2
		osl_content.append("   index = iFoundIndex+1;") #osl_content.append("  index = sIndex[iFoundIndex];")
		#osl_content.append("   parent_index = pIndex[iFoundIndex];")
		osl_content.append("   root_index = rIndex[iFoundIndex];")
		osl_content.append("   g_Location = sLocas[iFoundIndex];")
		#osl_content.append("   g_normalX = sNormalX[iFoundIndex];")
		#osl_content.append("   g_normalY = sNormalY[iFoundIndex];")
		#osl_content.append("   g_normalZ = sNormalZ[iFoundIndex];")
		osl_content.append("   g_boundsMax = sBbmax[iFoundIndex];")
		osl_content.append("   g_boundsMin = sBbmin[iFoundIndex];")
		osl_content.append("   scale = sScales[iFoundIndex];")
		osl_content.append("   dimensions = sDimens[iFoundIndex];")
		osl_content.append("   objIsNameTok=isNameTokenPresent(sNames[iFoundIndex], name_objTok);")
		#osl_content.append("   objIsCurve = isCurve[iFoundIndex];")
		#osl_content.append("   if(strlen(name_objColor)==0){objColor = sColor[iFoundIndex];}else{") # if_color
		# for custprp in custprpNameParts:
		# 	custprp_safe = custprpNamePartsMap[custprp]
		# 	osl_content.append("    if(name_objColor==\""+custprp+"\"){objColor = cp"+custprp_safe+"[iFoundIndex];};")
		#osl_content.append(" printf(\"(%i. %i. %f %f %f)\", in_frame, iFoundIndex, g_Location[0], g_Location[1], g_Location[2]);") # DBG
		#osl_content.append("   }") # if_color
		osl_content.append("  }") # if_indx2
		osl_content.append("  return;")
		osl_content.append(" }")
	osl_content.append("}")
	osl_content_final = "\n".join(osl_content)
	#textblock = bpy.data.texts.get(getWPLOslQueryName())
	#if not textblock:
	#	textblock = bpy.data.texts.new(getWPLOslQueryName())
	#else:
	#	textblock.clear()
	#textblock.write("\n".join(osl_content))
	#self.report({'INFO'}, "Scene query baked, objects="+str(objsLastIndex))
	return osl_content_final, bake_warns

# ==========================================
# ==========================================
# ==========================================
# ==========================================

class wplscene_updnodeval(bpy.types.Operator):
	bl_idname = "object.wplscene_updnodeval"
	bl_label = "Set value into nodes"
	bl_options = {'REGISTER', 'UNDO'}
	opt_nodeNameTag : EnumProperty( # main values, used in material nodes
		name= "Node Tag Name",
		default="<choose NodeTagId>",
		items = (
			("<choose NodeTagId>", "<choose NodeTagId>", "", 1), 
			(config.kWPLCustomPropTagDebug, config.kWPLCustomPropTagDebug, "", 2), 
			#(config.kWPLCustomPropTagAlpha, config.kWPLCustomPropTagAlpha, "", 3),
			(config.kWPLCustomPropTagCyUnitScale, config.kWPLCustomPropTagCyUnitScale, "", 4),
			(config.kWPLCustomPropTagSunIsPoint, config.kWPLCustomPropTagSunIsPoint, "", 5)
		)
	)
	opt_nodeNameValue : StringProperty(
		name		= "Node Tag Value",
		default	 = "0",
	)
	opt_viewportSwitch : EnumProperty(
		name= "Viewport switch",
		default="NONE",
		items = (
			("NONE", "None", "", 1), 
			("NORMAL", "Normal", "", 2), 
			("CYCLES", "Cycles", "", 3), 
			("FLATVC_ISL", "Flat VC-ISL", "", 4),
			("FLATVC_DEC", "Flat VC-DECORC", "", 5),
			("FLATMAT", "Flat Mat", "", 6), 
			("NORMALBF", "Backfacing", "", 7)
		)
	)
	opt_updateDeps : BoolProperty(
		name		= "Update deps",
		default	 = False
	)
	def execute( self, context ):
		# def checkNode(node, keyvalsMap):
		# 	changes = 0
		# 	if config.kWPLSystemNodeTagObjId in node.label:
		# 		return 0 # only automatic, ignoring
		# 	if len(node.outputs)>0:
		# 		#print("- Node: '%s' -> '%s'" % (node.bl_label, node.outputs[0]))
		# 		for nntag in keyvalsMap:
		# 			if nntag in node.label:
		# 				prevValue = node.outputs[0].default_value
		# 				node.outputs[0].default_value = float(keyvalsMap[nntag])
		# 				changes = changes+1
		# 				print("- Switching: '%s' -> '%s' (was: %s)" % (node.label, node.outputs[0].default_value, str(prevValue)))
		# 	return changes
		if config.kWPLNodePrefix not in self.opt_nodeNameTag:
			self.report({'INFO'}, "Choose NodeTagId")
			return {'FINISHED'}
		c_scene = bpy.context.scene
		sun_obj = wla.object_by_name(config.kWPLSystemMainSun)
		camera_obj = wla.object_by_name(config.kWPLSystemMainCam)
		if sun_obj is None or camera_obj is None:
			#self.report({'ERROR'}, "Main sun/cam not found")
			#return {'FINISHED'}
			print("- WARNING: no sun/cam found")
		prev = -1
		mac_obj_mtx = None
		if camera_obj is not None:
			prev = 0
			mac_obj_mtx = (camera_obj.matrix_world.copy(), camera_obj.data.shift_x, camera_obj.data.shift_y)
			if self.opt_nodeNameTag in camera_obj:
				prev = camera_obj[self.opt_nodeNameTag]
			camera_obj[self.opt_nodeNameTag] = self.opt_nodeNameValue
		# fallback for debug scenes without cam/sun
		# Updates needed to propagate custom Props to Materials
		if prev != self.opt_nodeNameValue or self.opt_updateDeps:
			ensureMaterialDrivers()
		config.WPL_G.store["_drvdef_"+self.opt_nodeNameTag] = int(self.opt_nodeNameValue)
		if camera_obj is not None:
			if mac_obj_mtx is not None:
				# important for testing in rotated positions
				camera_obj.matrix_world = mac_obj_mtx[0]
				camera_obj.data.shift_x = mac_obj_mtx[1]
				camera_obj.data.shift_y = mac_obj_mtx[2]
			if (c_scene.camera is None) or (c_scene.camera != camera_obj):
				# from PFF/any camera to mainCam
				ensureSceneDefauts(camera_obj)
			else:
				ensureWorkspDefauts()
		if self.opt_viewportSwitch != 'NONE':
			if self.opt_viewportSwitch == 'CYCLES':
				bpy.context.space_data.shading.type = 'RENDERED'
				bpy.context.space_data.overlay.show_overlays = True
				bpy.context.space_data.overlay.show_face_orientation = False
			if self.opt_viewportSwitch == 'NORMAL' or self.opt_viewportSwitch == 'NORMALBF':
				if self.opt_viewportSwitch == 'NORMALBF':
					bpy.context.space_data.overlay.show_face_orientation = True
				else:
					bpy.context.space_data.overlay.show_face_orientation = False
			if self.opt_viewportSwitch == 'FLATVC_ISL' or self.opt_viewportSwitch == 'FLATVC_DEC':
				bpy.context.space_data.shading.type = 'SOLID'
				bpy.context.space_data.shading.light = 'FLAT'
				bpy.context.space_data.shading.color_type = 'VERTEX'
				bpy.context.space_data.overlay.show_overlays = False
				bpy.context.space_data.overlay.show_face_orientation = False
				# Forcing Islands/DecorC as VC
				cm_name = config.kWPLIslandsVC
				if self.opt_viewportSwitch == 'FLATVC_DEC':
					cm_name = config.kWPLMeshColVC
				sel_all = wla.selected_objects()
				sel_all = wla_arma.all_mesh_hiers(sel_all)
				for sel_obj in sel_all:
					color_map = wla_attr.vc_obj_ensure(sel_obj, cm_name)
					sel_obj.data.vertex_colors.active = color_map
					print("- Activating color_map", color_map, self.opt_viewportSwitch, color_map)
					# Blender 3.2: also checking attributes && color_attributes
					for ai, attr in enumerate(sel_obj.data.attributes):
						if attr.name == cm_name:
							sel_obj.data.attributes.active_index = ai
							break
					for ai, attr in enumerate(sel_obj.data.color_attributes):
						if attr.name == cm_name:
							sel_obj.data.color_attributes.active_color_index = ai
							break
			if self.opt_viewportSwitch == 'FLATMAT':
				bpy.context.space_data.shading.type = 'SOLID'
				bpy.context.space_data.shading.light = 'FLAT'
				bpy.context.space_data.shading.color_type = 'MATERIAL'
				bpy.context.space_data.overlay.show_overlays = False
				bpy.context.space_data.overlay.show_face_orientation = False
		self.report({'INFO'}, "Updated: "+self.opt_nodeNameTag+"="+str(self.opt_nodeNameValue))
		return {'FINISHED'}

class wplscene_trafaref(bpy.types.Operator):
	bl_idname = "object.wplscene_trafaref"
	bl_label = "Setup bg image"
	bl_options = {'REGISTER', 'UNDO'}

	opt_imge : StringProperty(
		name		= "Image",
		default	 = "",
	)
	opt_opacity : IntProperty(
		name		= "Opacity",
		default	 = 100,
	)
	opt_tapeframe : IntVectorProperty(
		name		= "Tape index",
		size 		= 2,
		default	 	= (0,0),
	)

	def execute( self, context ):
		camera_obj = wla.object_by_name(config.kWPLSystemMainCam)
		if camera_obj is None:
			self.report({'INFO'}, "Camera not found")
			return {'FINISHED'}
		print("- CamRef:", self.opt_imge, self.opt_opacity, self.opt_tapeframe[0], self.opt_tapeframe[1])
		if self.opt_opacity > 0:
			camera_obj.data.show_background_images = True
		else:
			camera_obj.data.show_background_images = False
		if len(camera_obj.data.background_images) == 0:
			camera_obj.data.background_images.new()
		if len(camera_obj.data.background_images) > 0:
			bm = camera_obj.data.background_images[0]
			bm.rotation = 0.0
			bm.show_background_image = True
			bm.show_on_foreground = True
			img = None
			if self.opt_opacity > 0:
				bm.alpha = float(self.opt_opacity)/float(100.0)
			if len(self.opt_imge) > 0:
				img = bpy.data.images[self.opt_imge]
				bm.image = img
			bm.display_depth = 'FRONT'
			bm.frame_method = 'FIT'
			if self.opt_tapeframe[1] == 0 or img is None:
				# no offset -> easy to forget //
				bm.offset = [0.0, 0.0]
				bm.scale = 1.0
			else:
				slot_scale = 1.0
				if self.opt_tapeframe[1] > 1:
					slot_scale = max(img.size[0], img.size[1]) / min(bpy.context.scene.render.resolution_x, bpy.context.scene.render.resolution_y)
				bm.scale = slot_scale
				frame_posx = 0
				frame_posy = 0
				shift_scale = 1.0
				frac_pos = (float(self.opt_tapeframe[0])+0.5)/float(self.opt_tapeframe[1])
				if img.size[0] < img.size[1]:
					# vertical
					shift_scale = img.size[0]*0.5/bpy.context.scene.render.resolution_x
					frame_posy = wla.math_remapRanged(frac_pos, 0.0, 1.0, -1.0*shift_scale, 1.0*shift_scale)
				else:
					shift_scale = img.size[0]*0.5/bpy.context.scene.render.resolution_x
					frame_posx = -1 * wla.math_remapRanged(frac_pos, 0.0, 1.0, -1.0*shift_scale, 1.0*shift_scale)
				#print("- scale", slot_scale, shift_scale)
				#print("- framing", self.opt_tapeframe[0], frac_pos, "->", frame_posx, frame_posy, "orig:",img.size[0], img.size[1])
				bm.offset = [frame_posx, frame_posy]
		return {'FINISHED'}

class wplscene_framesync(bpy.types.Operator):
	bl_idname = "object.wplscene_framesync"
	bl_label = "Sync anim/scene"
	bl_options = {'REGISTER', 'UNDO'}
	
	opt_updateAnim : BoolProperty(
		name		= "Update animations binding",
		default	 = False
	)
	opt_updateScene : BoolProperty(
		name		= "Update scene defaults",
		default	 = False
	)
	opt_updateDrivers : BoolProperty(
		name		= "Sync Drivers expression",
		default	 = False
	)
	def execute( self, context ):
		camera_obj = wla.object_by_name(config.kWPLSystemMainCam)
		if camera_obj is None:
			# print("- missing: ", config.kWPLSystemMainCam)
			# self.report({'ERROR'}, "Main cam not found: "+config.kWPLSystemMainCam)
			# config.WPL_G.store[kWPLGKey_DRV_SyncStatus] = "INVALID"
			# return {'FINISHED'}
			print("- creating camera: ", config.kWPLSystemMainCam)
			cam_data = bpy.data.cameras.new(config.kWPLSystemMainCam)
			camera_obj = bpy.data.objects.new(config.kWPLSystemMainCam, cam_data)
			bpy.context.collection.objects.link(camera_obj)
			camera_obj.data.clip_start = 0.03
			camera_obj.data.clip_end = 10000
			camera_obj.rotation_mode = 'XYZ'
			camera_obj.rotation_euler = (math.radians(90),0,0)
			# camera_obj.rotation_mode = 'QUATERNION'
			# camera_obj.rotation_quaternion = Euler((math.radians(90),0,0), 'XYZ').to_quaternion()
			camera_obj.location = Vector((0,0,0))
			camera_obj.hide_render = False
			c_scene.camera = camera_obj
			wla_do.sys_update_view(True, False)
		if self.opt_updateDrivers:
			print("- syncing driver expressions...")
			# Updates needed to propagate custom Props to Materials
			# 	# updating all animations at once... heavy
			# 	print("- updating frame")
			# 	depth = bpy.context.evaluated_depsgraph_get()
			# 	depth.update()
			# 	wla_do.sys_update_view(True, False)
			# 	bpy.context.scene.frame_set(bpy.context.scene.frame_current)
			updated = ensureMaterialDrivers()
			print("// done",updated)
		if self.opt_updateScene:
			print("- syncing scene defaults")
			ensureSceneDefauts(None)
			print("- syncing collections...")
			wla.sys_collection(config.kWPLSystemMainColl)
			wla.sys_collection(config.kWPLSystemSuppColl)
			if wla.find_child_by_name(None, config.kWPLObjCharFaceToken):
				wla.sys_collection(config.kWPLSystemFaceColl)
			if wla.find_child_by_name(None, config.kWPLObjzRefToken):
				wla.sys_collection(config.kWPLSystemRefsColl)
			for scene in bpy.data.scenes:
				sortSceneCollections(scene.collection, True)
			print("- syncing view_layers...")
			isAnyViewLayerNew = False
			for vl_name in config.kWPLLayerRenderPrecreate:
				_, isNew = ensureViewLayerPartial(vl_name)
				isAnyViewLayerNew = isAnyViewLayerNew or isNew
			if isAnyViewLayerNew:
				sortViewLayers()
				print("- WARNING: some view_layers was added, check Compositor nodes")
			print("// done")
		if self.opt_updateAnim:
			print("- syncing animation bindings...")
			objs2check = [obj for obj in bpy.context.scene.objects]
			c_scene = bpy.context.scene
			bindedObj = 0
			bindedModf = 0
			bindedShk = 0
			bindedCon = 0
			frameF = c_scene.frame_start
			frameT = c_scene.frame_end
			frames = []
			frames.append(0)
			for frm in range(int(frameF), int(frameT)+1):
				frames.append(frm)
			print("- frames: [",frameF,",",frameT,"]")
			for obj in objs2check:
				if wla.isTokenInStr([config.kWPLFrameBindPostfix, config.kWPLFrameBindPostfixNo], obj.name) == False:
					continue
				bindedObj = bindedObj+1
				if obj.type == 'EMPTY':
					if (config.kWPLFrameBindPostfixNo in obj.name):
						print("- WARNING: Unsupported tag", obj.name)
						continue
					# special case - autohide via Location constraint
					# this method allows to hide whole hierarchy
					# constraint visibility INVERTED - hidden on target frame, active on others
					for frm in frames:
						frmKey = config.kWPLFrameBindPostfix+str(frm)
						if (frmKey in obj.name):
							csFrameVis = "Frame_vis" + config.kWPLFrameBindPostfixNo+str(frm)
							if obj.constraints.get(csFrameVis) is None:
								print("- EMPTY visibility: adding constraint instead", obj.name, csFrameVis)
								# baking both Z (low-distance) and Y offset
								# without Y - top view not usable
								# big Z - "dot" zooms camera too far
								cc = obj.constraints.new('LIMIT_LOCATION')
								cc.name = csFrameVis
								cc.use_min_z = True
								cc.min_z = config.kWPLUdiTrashMeshOffset2
								cc.use_max_z = True
								cc.max_z = config.kWPLUdiTrashMeshOffset2
								cc.use_min_y = True
								cc.min_y = config.kWPLUdiTrashMeshOffset2
								cc.use_max_y = True
								cc.max_y = config.kWPLUdiTrashMeshOffset2
					continue
				ini_hide = obj.hide_viewport
				ini_hide_render = obj.hide_render
				for frm in frames:
					if (config.kWPLFrameBindPostfixNo in obj.name):
						frmKey = config.kWPLFrameBindPostfixNo+str(frm)
						frmHide = False
						if frmKey in obj.name:
							frmHide = True
					else:
						frmKey = config.kWPLFrameBindPostfix+str(frm)
						frmHide = True
						if frmKey in obj.name:
							frmHide = False
					#if frm == 0:
					#	frmHide = False
					frmHide_r = frmHide
					if obj.type == 'GPENCIL':
						# never render, always hide
						frmHide_r = True
					obj.hide_viewport = frmHide
					obj.hide_render = frmHide_r
					obj.keyframe_insert("hide_viewport", frame = frm)
					obj.keyframe_insert("hide_render", frame = frm)
					print("-", frm, "obj:",obj.name, "hide=", frmHide)
				obj.hide_viewport = ini_hide
				obj.hide_render = ini_hide_render
			# again, since old checks may add modifiers/constraings/etc
			for obj in objs2check:
				# modifier visilibity
				for md in obj.modifiers:
					if wla.isTokenInStr([config.kWPLFrameBindPostfix, config.kWPLFrameBindPostfixNo], md.name) == False:
						continue
					bindedModf = bindedModf+1
					ini_show_render = md.show_render
					ini_show_viewport = md.show_viewport
					for frm in frames:
						if (config.kWPLFrameBindPostfixNo in md.name):
							frmKey = config.kWPLFrameBindPostfixNo+str(frm)
							frmShow = True
							if frmKey in md.name:
								frmShow = False
							#if frm == 0:
							#	frmShow = False
						else:
							frmKey = config.kWPLFrameBindPostfix+str(frm)
							frmShow = False
							if frmKey in md.name:
								frmShow = True
							#if frm == 0:
							#	frmShow = True
						md.show_render = frmShow
						md.show_viewport = frmShow
						md.keyframe_insert("show_render", frame = frm)
						md.keyframe_insert("show_viewport", frame = frm)
						print("-", frm, "modf:",md.name, "show=", frmShow)
					md.show_render = ini_show_render
					md.show_viewport = ini_show_viewport
				# shapekey visibility
				if (obj.type == 'MESH' or obj.type == 'CURVE') and (obj.data is not None) and (obj.data.shape_keys is not None) and len(obj.data.shape_keys.key_blocks) > 0:
					for shk in obj.data.shape_keys.key_blocks:
						#shk = obj.data.shape_keys[shk_key]
						if config.kWPLFrameBindPostfix in shk.name:
							bindedShk = bindedShk+1
							ini_mute = shk.mute
							for frm in frames:
								frmKey = config.kWPLFrameBindPostfix+str(frm)
								frmHide = True
								if frmKey in shk.name:
									frmHide = False
								#if frm == 0:
								#	frmHide = True
								shk.mute = frmHide
								shk.keyframe_insert("mute", frame = frm)
								print("-", frm, "shapekey:",shk.name, "mute=", frmHide)
							shk.mute = ini_mute
			# again, since old checks may add modifiers/constraings/etc
			for obj in objs2check:
				# constrains
				if obj.constraints is None:
					continue
				for constr in obj.constraints:
					if wla.isTokenInStr([config.kWPLFrameBindPostfix, config.kWPLFrameBindPostfixNo], constr.name) == False:
						continue
					bindedCon = bindedCon+1
					ini_mute = constr.mute
					for frm in frames:
						if (config.kWPLFrameBindPostfixNo in constr.name):
							frmKey = config.kWPLFrameBindPostfixNo+str(frm)
							frmHide = False
							if frmKey in constr.name:
								frmHide = True
							#if frm == 0:
							#	frmHide = True
						else:
							frmKey = config.kWPLFrameBindPostfix+str(frm)
							frmHide = True
							if frmKey in constr.name:
								frmHide = False
							#if frm == 0:
							#	frmHide = False
						constr.mute = frmHide
						constr.keyframe_insert("mute", frame = frm)
						print("-", frm, "constr:",constr.name, "mute=", frmHide)
					constr.mute = ini_mute
			result = "Binded "+str(bindedObj)+" objects, "+str(bindedModf)+" modf, "+str(bindedShk)+" shapekeys, "+str(bindedCon)+" constr"
			print("// results:", result)
		# wla_do.sys_update_view(True, False)
		self.report({'INFO'}, "Sync done")
		return {'FINISHED'}

class wplscene_viewlbind(bpy.types.Operator):
	bl_idname = "object.wplscene_viewlbind"
	bl_label = "Setup View layers"
	bl_options = {'REGISTER', 'UNDO'}
	
	opt_layerToks : StringProperty(
		name	= "View Layers (token:samp)",
		default	 = "<auto>",
	)

	# Running as separate dialog
	def invoke(self, context, event):
		return context.window_manager.invoke_props_dialog(self, width = 200)

	def execute( self, context ):
		camera_obj = wla.object_by_name(config.kWPLSystemMainCam)
		if camera_obj is None:
			self.report({'ERROR'}, "Main cam not found: "+config.kWPLSystemMainCam)
			return {'CANCELLED'}
		layersTk = self.opt_layerToks
		if len(layersTk) == 0 or "<auto>" in layersTk:
			# if config.kWPLCustomPropTagAlpha in camera_obj and camera_obj[config.kWPLCustomPropTagAlpha] >0:
			# 	print("- Default vl-set: ALPHA")
			# 	layersTk = layersTk + ", " +config.kWPLLayerRender_ALPHA
			# else:
			print("- Default vl-set: TEST, Step1")
			layersTk = layersTk + ", " +config.kWPLLayerRender_TEST_Step1
		print("- View layers setup:", layersTk)
		vls = {}
		vls_samp = {}
		for vl in bpy.context.scene.view_layers:
			vls[vl.name] = False
		toks = wla.strToTokens(layersTk)
		#print("- toks", toks)
		for tok_raw in toks:
			tok = tok_raw
			samp = -1
			if ":" in tok_raw:
				split_pair = tok_raw.split(":")
				tok = split_pair[0]
				samp = int(split_pair[1])
			for vl_name in vls.keys():
				if tok == '*':
					vls[vl_name] = True
					if samp > 0:
						vls_samp[vl_name] = samp
				if tok == '!*':
					vls[vl_name] = False
				if tok.lower() in vl_name.lower():
					vls[vl_name] = True
					if samp > 0:
						vls_samp[vl_name] = samp
				if tok.startswith("!") and (tok[1:].lower() in vl_name.lower()):
					vls[vl_name] = False
		enables = 0
		for vl in bpy.context.scene.view_layers:
			if vls[vl.name] == True:
				if vl.name in vls_samp:
					vl.samples = vls_samp[vl.name]
				print("- enabling", vl.name, "samples="+str(vl.samples))
				enables = enables+1
				vl.use = True
			else:
				vl.use = False
		#print("View layers state:", vls)
		self.report({'INFO'}, "Done, enabled: "+str(enables))
		return {'FINISHED'}

def getSceneRenderPath(c_scene):
	final_render_name = os.path.basename(c_scene.render.filepath)
	if len(final_render_name) == 0:
		final_render_name = os.path.basename(bpy.data.filepath)
		final_render_name = os.path.splitext(final_render_name)[0]
	final_render_path = os.path.dirname(c_scene.render.filepath)
	if len(final_render_path) == 0:
		# folder with file itself
		print("- initializing render path...")
		final_render_path = os.path.dirname(bpy.data.filepath)
		c_scene.render.filepath = final_render_path+os.path.sep+final_render_name
	return final_render_name, final_render_path

class wplscene_prep2render(bpy.types.Operator):
	bl_idname = "object.wplscene_prep2render"
	bl_label = "Prepare to render"
	bl_options = {'REGISTER'}

	opt_mode : EnumProperty(
		items = [
			('TEST', "TEST Render", "", 1),
			#('ALPHA', "ALPHA Render", "", 2),
			('FINAL_BG', "BG: FINAL Render", "", 2),
			('FINAL_CG', "CG: FINAL Render", "", 3),
		],
		name="Render mode",
		default='TEST',
	)

	def execute( self, context ):
		# common data & sanity checks
		print('---- ---- ---- ---- ----')
		print("- preparing to render, MODE="+str(self.opt_mode))
		c_scene = bpy.context.scene
		if c_scene.render.engine != 'CYCLES' or c_scene.cycles.shading_system != True:
			self.report({'ERROR'}, "Invalid render engine")
			config.WPL_G.store[kWPLGKey_DRV_SyncStatus] = "INVALID"
			return {'FINISHED'}
		camera_obj = wla.object_by_name(config.kWPLSystemMainCam)
		if camera_obj is None:
			print("- missing, need sync: ", config.kWPLSystemMainCam)
			self.report({'ERROR'}, "Main cam not found: "+config.kWPLSystemMainCam)
			config.WPL_G.store[kWPLGKey_DRV_SyncStatus] = "INVALID"
			return {'FINISHED'}
		if (config.kWPLSystemNodeTagPFF in config.WPL_G.store[kWPLGKey_DRV_SyncStatus]) or (c_scene.camera != camera_obj):
			print("- Render Sequence: need sync after PFF")
			#self.report({'ERROR'}, "Need re-sync after PFF")
			#return {'FINISHED'}
			ensureSceneDefauts(camera_obj)
		camera_obj.hide_render = False
		final_render_name, final_render_path = getSceneRenderPath(c_scene)
		#final_render_aovpath = final_render_path+os.path.sep+final_render_name+"_aovs"+os.path.sep
		final_render_aovpath = final_render_path+os.path.sep # same as main, easier to extract all...
		if len(final_render_name) == 0 or "/" in final_render_name or "." in final_render_name:
			print("- invalid output name", final_render_name)
			self.report({'ERROR'}, "Invalid name of output file: "+final_render_name)
			config.WPL_G.store[kWPLGKey_DRV_SyncStatus] = "INVALID"
			return {'FINISHED'}
		if not os.path.isdir(final_render_path):
			print("- invalid output folder", final_render_path)
			self.report({'ERROR'}, "Output folder not found: "+final_render_path)
			config.WPL_G.store[kWPLGKey_DRV_SyncStatus] = "INVALID"
			return {'FINISHED'}
		if not os.path.exists(final_render_aovpath):
			os.makedirs(final_render_aovpath)
		if self.opt_mode in ['FINAL_BG', 'FINAL_CG']:
			exr_files_before = wla.sys_filesWithSubd(final_render_path, ["exr"]) # as os.listdir, but recursive
			if len(exr_files_before) > 0:
				print("- output folder already contain exr files", final_render_path, exr_files_before)
				self.report({'ERROR'}, "Output folder not empty: "+final_render_path)
				config.WPL_G.store[kWPLGKey_DRV_SyncStatus] = "INVALID"
				return {'FINISHED'}
		# sysObjects/viewLayers presence
		mac_obj_mtx = (camera_obj.matrix_world.copy(), camera_obj.data.shift_x, camera_obj.data.shift_y)
		frameF = c_scene.frame_start
		frameT = c_scene.frame_end
		frameC = c_scene.frame_current
		print("- frames: [",frameF,",",frameT,"], current:",frameC)
		if self.opt_mode in ['FINAL_BG', 'FINAL_CG']:
			# final checks
			if wla.object_by_name(config.kWPLSystemMainReestrObj) is None:
				print("- missing: ", config.kWPLSystemMainReestrObj)
				self.report({'ERROR'}, "Sys obj not found: "+config.kWPLSystemMainReestrObj)
				config.WPL_G.store[kWPLGKey_DRV_SyncStatus] = "INVALID"
				return {'FINISHED'}
			if wla.object_by_name(config.kWPLSystemMainSun) is None:
				print("- missing: ", config.kWPLSystemMainSun)
				self.report({'ERROR'}, "Main sun not found: "+config.kWPLSystemMainSun)
				config.WPL_G.store[kWPLGKey_DRV_SyncStatus] = "INVALID"
				return {'FINISHED'}
			if config.kWPLSystemMainWorld not in bpy.data.worlds:
				self.report({'ERROR'}, "Default World not found: "+config.kWPLSystemMainWorld)
				config.WPL_G.store[kWPLGKey_DRV_SyncStatus] = "INVALID"
				return {'FINISHED'}
			if getSceneCollection(config.kWPLSystemMainColl) is None or getSceneCollection(config.kWPLSystemSuppColl) is None:
				self.report({'ERROR'}, "Collections not synced, missing sys collection")
				config.WPL_G.store[kWPLGKey_DRV_SyncStatus] = "INVALID"
				return {'FINISHED'}
			if getViewLayer(config.kWPLLayerRenderMain) is None:
				self.report({'ERROR'}, "View layers not synced, missing layer:"+config.kWPLLayerRenderMain)
				config.WPL_G.store[kWPLGKey_DRV_SyncStatus] = "INVALID"
				return {'FINISHED'}
			for vl_name in config.kWPLLayerRenderPrecreate:
				if getViewLayer(vl_name) is None:
					self.report({'ERROR'}, "View layers not synced, missing layer: "+vl_name)
					config.WPL_G.store[kWPLGKey_DRV_SyncStatus] = "INVALID"
					return {'FINISHED'}
			if frameF != frameT:
				for frm in range(int(frameF), int(frameT)+1):
					if "osl_frame"+str(frm) not in config.WPL_G.store:
						self.report({'ERROR'}, "Animation detected, but frame not baked: "+str(frm))
						config.WPL_G.store[kWPLGKey_DRV_SyncStatus] = "INVALID"
						return {'FINISHED'}
			if frameC < frameF or frameC > frameT:
				self.report({'ERROR'}, "Invalid current frame, range="+str(frameF)+":"+str(frameT))
				config.WPL_G.store[kWPLGKey_DRV_SyncStatus] = "INVALID"
				return {'FINISHED'}
		# --------------------------------
		# updating scene to starting point
		# moving our of edit modes, enabling main viewLayers, etc
		if wla.is_local_view():
			# getting out
			bpy.ops.view3d.localview()
		all_mat = wla.mat_getAll()
		all_nodes = wla.mat_getAllNodes(True, True, True)
		camera_obj[config.kWPLCustomPropTagFrameQueue] = 0
		# if self.opt_mode == 'TEST':
		# 	camera_obj[config.kWPLCustomPropTagAlpha] = 0
		# if self.opt_mode == 'ALPHA':
		# 	camera_obj[config.kWPLCustomPropTagDebug] = 0
		# 	camera_obj[config.kWPLCustomPropTagAlpha] = 1
		if self.opt_mode in ['FINAL_BG', 'FINAL_CG']:
			camera_obj[config.kWPLCustomPropTagDebug] = 0
			#camera_obj[config.kWPLCustomPropTagAlpha] = 0
			if frameF != frameC:
				# switching to FIRST frame - or drivers may be not updated properly
				print("- FINAL: switching to first frame of sequence", frameF)
				frameC = frameF
		# enabling ALL collections, renderability setup works for ENABLED only
		config.WPL_G.store["last:wpl_frameChange"] = -1 # resetting, frame change will update proper setup
		for cl in bpy.data.collections:
			cl.hide_viewport = False
			cl.hide_render = False
		# updating active viewlayer: kWPLLayerRenderMain
		vl_main = getViewLayer(config.kWPLLayerRenderMain)
		if vl_main is not None:# may be none for test scenes
			print("- Updating current frame...")
			context.window.view_layer = vl_main
			# Enabling all collections
			# For active/main view layer only (This is vl_main)
			lc_all = wla_do.view_layer_asllchildren(vl_main.layer_collection.children, True)
			for lc in lc_all:
				lc.exclude = False
			c_scene.frame_set(frameC) # frameC may change
			vl_main.update()
		# Activating camera AFTER enabling all collections and view layers
		# PFF may disable all - camera not usable in disabled
		wla_do.ensure_visible(camera_obj, 1)
		wla_do.select_and_change_mode(camera_obj, 'OBJECT')
		# --------------------------------
		errs_msgList = []
		#print("- DBG: premature exit2")
		#return {'FINISHED'} # DBG TEST
		# object->layers mapping, basic forcing hierarchy (shapes, etc)
		objs2dump = []
		for lobj in bpy.data.objects:
			if lobj.type == 'EMPTY':
				if wla.isTokenInStr((config.kWPLSystemObjShapes, config.kWPLSystemObjMainHelpers, config.kWPLSystemObjSysEHelpers),lobj.name):
					continue
			# main cam - in all important collections
			# not checking name, since some sysobjects may contain...
			if lobj.type == 'CAMERA': #(config.kWPLSystemMainCam in lobj.name):
				wla_do.link_object_to_scene(lobj, config.kWPLSystemMainColl)
				wla_do.link_object_to_scene(lobj, config.kWPLSystemEdgeColl)
			# 2D/Mesh shapes. 2D curves skipping - SVG curves ok for scene
			if (wla.isTokenInStr(config.kWPLObjShaperToken, lobj.name)):
				# must be non-renderable - can be temp/ref objects, etc
				lobj.hide_render = True
				continue
			elif (wla.isTokenInStr(config.kWPLObjShapeToken, lobj.name)):
				# must be non-renderable - can be temp/ref objects, etc
				lobj.hide_render = True
				sysShapesRoot = wla.sys_empty(config.kWPLSystemObjShapes)
				if lobj.type == 'MESH' and len(lobj.data.polygons) > 0:
					sysShapesRoot = wla.sys_empty(config.kWPLSystemObjMainHelpers)
				if (lobj.parent != sysShapesRoot) or (len(lobj.users_collection) == 0) or (lobj.users_collection[0] != sysShapesRoot.users_collection[0]):
					wla_do.link_object_to_scene(lobj, sysShapesRoot, 2)
				continue
			elif (wla.isTokenInStr(config.kWPLSuppZZZZPrefix, lobj.name)):
				# must be non-renderable and hidden
				lobj.hide_render = True
				lobj.hide_viewport = True
				continue
			elif (wla.isTokenInStr([config.kWPLObjCharRefLoomis, config.kWPLObjCharRefStickman, config.kWPLObjEdgeLinArtToken], lobj.name)):
				# must be non-renderable
				lobj.hide_render = True
				continue
			# Reestrs
			if (config.kWPLSystemReestrToken in lobj.name):
				# Reestrs - linked objects can not be reparented... parent reset after reload
				# 	if lobj.parent != sysReestrsRoot:
				# 		wla_do.unlink_object_from_coll(lobj, None)
				#	wla_do.link_object_to_scene(lobj, sysReestrsRoot)
				wla_do.link_object_to_scene(lobj, config.kWPLSystemSuppColl, 1)
				continue
			# if self.opt_mode in ['FINAL_BG', 'FINAL_CG']:
			# face objects - no multi-user, problems with applying displace to cam - must be per instance! Important for eyes/mouth
			# - NOT ANYMORE!!! WAS: Displace per material, NOW: Displace per OBJECT -> Multi-user OK
			# 	if lobj.type != 'EMPTY' and wla.isTokenInStr(config.kWPLObjCharFaceToken, wla.object_full_name(lobj)) and wla.object_useCount(lobj.data) > 1:
			# 		print("- ERROR: Face object with multi-user data found", wla.object_full_name(lobj), lobj.data.name, wla.object_useCount(lobj.data))
			# 		self.report({'ERROR'}, "Face object with multi-user data found")
			# 		config.WPL_G.store[kWPLGKey_DRV_SyncStatus] = "INVALID"
			# 		return {'FINISHED'}
			# ring objects - no multi-user, problems with frame-sharing via scale == 0
			# if wla.isTokenInStr(config.kWPLObjRingToken, lobj.name) and wla.object_useCount(lobj.data) > 1:
			# 	print("- ERROR: Ring/Volu object with multi-user data found", wla.object_full_name(lobj), lobj.data.name, wla.object_useCount(lobj.data))
			# 	self.report({'ERROR'}, "Ring object with multi-user data found")
			#	config.WPL_G.store[kWPLGKey_DRV_SyncStatus] = "INVALID"
			# 	return {'FINISHED'}
			# if self.opt_mode == 'ALPHA' and wla.isTokenInStr(config.kWPLObjFrameWrapperF0 not in wla.object_full_name(lobj)):
			# 	if wla.isTokenInStr(config.kWPLObjCharFaceToken, lobj.name) and wla.isTokenInStr(config.kWPLObjProtoToken, lobj.name) == False:
			# 		print("- ERROR: ALPHA: Non-proto Face object found", wla.object_full_name(lobj))
			# 		self.report({'ERROR'}, "ALPHA: Non-proto Face object")
			# 		config.WPL_G.store[kWPLGKey_DRV_SyncStatus] = "INVALID"
			# 		return {'FINISHED'}
			# 	if wla.isTokenInStr(config.kWPLUdiSysfToken, lobj.name) and wla.isTokenInStr(config.kWPLObjProtoToken, lobj.name) == True:
			# 		print("- ERROR: ALPHA: Proto sysf-col object found", wla.object_full_name(lobj))
			# 		self.report({'ERROR'}, "ALPHA: Proto sysf-col object")
			# 		config.WPL_G.store[kWPLGKey_DRV_SyncStatus] = "INVALID"
			# 		return {'FINISHED'}
			# common checks
			if not getIsDumpable(lobj):
				#print("- dump: ignoring", lobj.name)
				continue
			objs2dump.append(lobj)
		# removing empty sys-helper empties (after copy-paste characters, for example)
		objs2del = []
		for lobj in bpy.data.objects:
			if lobj.type == 'EMPTY' and wla.isTokenInStr((config.kWPLSystemObjShapes, config.kWPLSystemObjMainHelpers, config.kWPLSystemObjSysEHelpers),lobj.name):
				if len(lobj.children) == 0:
					objs2del.append(lobj)
		for lobj in objs2del:
			print("- removing empty sys-helper:", lobj.name)
			bpy.data.objects.remove(lobj, do_unlink=True)
		objs2Reenable_invp = []
		for lobj in objs2dump:
			#obj_name_2top = wla.object_full_name(lobj)
			isFrame0obj = wla.isTokenInStr(config.kWPLObjFrameWrapperF0, wla.object_full_name(lobj))
			isProtoObj = False
			if wla.isTokenInStr(config.kWPLObjProtoToken, wla.object_full_name(lobj)):
				isProtoObj = True
				if isFrame0obj == False and (lobj.type in ['MESH', 'CURVE', 'GPENCIL', 'EMPTY']):
					if self.opt_mode in ['FINAL_CG'] and (lobj.hide_render == False):
						errs_msgList.append("Renderable proto objects found: [" + wla.object_full_name(lobj)+"]")
			if isFrame0obj == False and (config.kWPLFrameBindPostfix in lobj.name):
				if lobj.animation_data is None:
					errs_msgList.append("No animdata on: [" + wla.object_full_name(lobj)+"]")
			# Collection-autolinking rules (kWPLLayerRenderCollLinkRules)
			target_colls = []
			if isProtoObj:
				# AMUST! чтобы при дублировании одежек/персонажей ничего не терялось
				#target_colls = [config.kWPLSystemMainColl]
				# 2022-05-16: не актуально, теперь все в подколлекциях
				# just not applying any rules anymore
				target_colls = None
			else:
				for tok in config.kWPLLayerRenderCollLinkRules.keys():
					clrules = None
					if (self.opt_mode+":") in tok:
						subtok = tok.replace( (self.opt_mode+":"), "" )
						if wla.isTokenInStr(subtok, wla.object_full_name(lobj)):
							clrules = config.kWPLLayerRenderCollLinkRules[tok]
					if wla.isTokenInStr(tok, wla.object_full_name(lobj)):
						clrules = config.kWPLLayerRenderCollLinkRules[tok]
					if clrules is not None:
						for vl_name in clrules:
							if vl_name not in target_colls:
								target_colls.append(vl_name)
			if (target_colls is not None) and (len(target_colls) > 0):
				if wla.object_isInCollections(lobj, target_colls) == False:
					print("- relinking", lobj.name, target_colls)
					isFirstExclu = 1
					for vl_name in target_colls:
						wla_do.link_object_to_scene(lobj, vl_name, isFirstExclu)
						isFirstExclu = 0
				# else:
				# 	# unlink from scene collection (should be in named)
				# 	# skip, if already in some collection
				# 	# print("- relink test", lobj.name)
				# 	if len(lobj.users_collection) == 0 or c_scene.collection.objects.get(lobj.name) is not None:
				# 		wla_do.link_object_to_scene(lobj, config.kWPLSystemMainColl)
				# 		if c_scene.collection.objects.get(lobj.name) is not None:
				# 			c_scene.collection.objects.unlink(lobj)
			# need ALL "Hide viewport objects" to be visible -> or objs MAY have wrong Dims
			if lobj.hide_viewport == True and lobj.hide_render == False:
				lobj.hide_viewport = False
				objs2Reenable_invp.append(lobj)
		# OSL preparations
		# need active non-linked object to compile OSL
		# need ALL COLLECTIONS ENABLED -> or objs MAY be NOT UPDATED
		# need ALL "Hide viewport objects" to be visible -> or objs MAY have wrong Dims
		# to update all coords, etc -> resetting current frame
		print("- OSL-bake: enabling all collection, updating frame...")
		osl_scene_bake, osl_warns = oslbake_getscene(context)
		for lobj in objs2Reenable_invp:
			lobj.hide_viewport = True
		if osl_scene_bake is None:
			self.report({'ERROR'}, "Can`t bake OSL")
			config.WPL_G.store[kWPLGKey_DRV_SyncStatus] = "INVALID"
			return {'CANCELLED'}
		if osl_warns > 0:
			errs_msgList.append("Warnings on OSL bake")
		osl_file_path = final_render_aovpath+final_render_name+kWPLLastBakeFileName+".osl"
		oso_file_path = final_render_aovpath+final_render_name+kWPLLastBakeFileName+".oso"
		if os.path.exists(osl_file_path):
			os.remove(osl_file_path)
		if os.path.exists(oso_file_path):
			os.remove(oso_file_path)
		with open(osl_file_path,"w") as osl_file:
			osl_file.write(osl_scene_bake)
		for node in all_nodes:
			if node.bl_idname == 'ShaderNodeScript' and config.kWPLSystemOslScript in node.label:
				# installing bake script
				node.mode = 'EXTERNAL'
				node.filepath = osl_file_path
				#print("- OSL: node with script", node.name)
		camera_obj[kWPLLastBakePathKey] = final_render_aovpath+final_render_name
		# all_node_groups = bpy.data.node_groups
		# all_nodes_backmap = getMatNodesBackmapped(all_mat, objs2dump)
		# if all_nodes_backmap is None:
		# 	# Test can be called to move imported char objects to place - shapse, etc. Crashing on conflict NOT ok...
		# 	errs_msgList.append("Failed to setup materials: tag conflicts found")
		for node in all_nodes:
			# check for compositing output to be connected - can be missed in case of broken libs import!!!
			#print(" -- node", node.label, node.name, node.type)
			if node.type == 'GROUP' and node.node_tree is None:
				# safety check
				errs_msgList.append("Broken NodeGroup found: [" + node.name+"]")
				continue
			if ((node.type == 'VIEWER') or (node.type == 'COMPOSITE')) and (node.bl_idname != 'GeometryNodeViewer'):
				# compositing check
				if node.inputs[0].is_linked == False:
					#wla_do.sys_dump_pythonobj(node)
					errs_msgList.append("Compositing BROKEN: Viewer/Composite not connected: [" + node.name + "/" + node.type + "]" )
			if node.type == 'GROUP' and node.node_tree is not None and config.kWPLComposMainNodeTag in node.node_tree.name:
				# compositing check
				for inp in node.inputs:
					if wla.isTokenInStr(config.kWPLComposMainNodeChecks, inp.name) and inp.is_linked == False:
						errs_msgList.append("Compositing BROKEN: Composite input not connected: ["+inp.name+"]")
			if config.kWPLSystemNodeTagAovs in node.label:
				# EXR save node
				postfix = "aov"
				if len(node.label) > len(config.kWPLSystemNodeTagAovs):
					postfix = node.label[len(config.kWPLSystemNodeTagAovs):]
				postfix = postfix + "_"+self.opt_mode.lower()
				node.format.file_format = 'OPEN_EXR_MULTILAYER'  # 'OPEN_EXR'
				node.format.color_mode = 'RGBA'
				node.format.color_depth = '16'
				node_path = final_render_aovpath+final_render_name+"_"+postfix+"_"
				node_path = node_path.replace("__","_")
				node.base_path = node_path
				print("Compositing: AOVs path:", node.base_path)
			# if all_nodes_backmap is not None and config.kWPLSystemNodeTagInject in node.label:
			# 	#print("- inject: node.type", node.type)
			# 	node_inpts = node.label.split(":")
			# 	if len(node_inpts) >= 2:
			# 		node_tag = str(node_inpts[1])
			# 		nodeCach = None
			# 		if node in all_nodes_backmap:
			# 			nodeCach = all_nodes_backmap[node]
			# 			if len(nodeCach["<mat>"]) > 0:
			# 				backmap_mat = nodeCach["<mat>"][0]
			# 				node_tag = node_tag.replace("<mat>", backmap_mat)
			# 			if len(nodeCach["<obj>"]) > 0:
			# 				backmap_obj = nodeCach["<obj>"][0]
			# 				node_tag = node_tag.replace("<obj>",backmap_obj)
			# 			if len(nodeCach["<root>"]) > 0:
			# 				backmap_root = nodeCach["<root>"][0]
			# 				node_tag = node_tag.replace("<root>",backmap_root)
			# 			if len(nodeCach["<tag>"]) > 0:
			# 				backmap_root = nodeCach["<tag>"][0]
			# 				node_tag = node_tag.replace("<tag>",backmap_root)
			# 			# if len(nodeCach["<mat>"]) > 0:
			# 			# 	errs_msgList.append("Inject duply: mats: "+ ",".join(nodeCach["<mat>"]))
			# 			# if len(nodeCach["<obj>"]) > 0:
			# 			# 	errs_msgList.append("Inject duply: obj: "+ ",".join(nodeCach["<obj>"]))
			# 		if config.kWPLMatTokenWPV in node_tag:
			# 			# checking is numeric, or names like "local_vera_eyes" will be corrupted
			# 			part = node_tag.rpartition(config.kWPLMatTokenWPV)
			# 			if part[2].isnumeric():
			# 				node_tag = part[0]
			# 		if node.type == 'TEX_IMAGE' or node.type == 'TEX_ENVIRONMENT':
			# 			# local packed Image Texture
			# 			img = None
			# 			if (img is None):
			# 				if nodeCach is not None and node_tag == "<auto>":
			# 					if (img is None) and len(nodeCach["<tag>"]) > 0:
			# 						img = wla.sys_findImg(nodeCach["<tag>"][0], True)
			# 					if (img is None) and len(nodeCach["<mat>"]) > 0:
			# 						img = wla.sys_findImg(nodeCach["<mat>"][0], True)
			# 					if (img is None) and len(nodeCach["<obj>"]) > 0:
			# 						img = wla.sys_findImg(nodeCach["<obj>"][0], True)
			# 				else:
			# 					img = wla.sys_findImg(node_tag, True)
			# 			if img is not None:
			# 				if node.image is None or node.image != img:
			# 					print("- Inject: Image: ", img.name)
			# 					node.image = img
			# 			#else:
			# 			#	print("- Inject: Image skipped: failed to find image", node_tag, nodeCach)
			# 			#	node.image = None
			# 		if node.type == 'GROUP':
			# 			nodegrp = all_node_groups.get(node_tag)
			# 			if nodegrp is not None:
			# 				# print("- Inject: NodeGroup: ", nodegrp.name, node.name, nodeCach)
			# 				if node.node_tree is None or wla.isTokenInStr(config.kWPLObjProtoToken, node.node_tree.name): # node.node_tree.name != nodegrp.name:
			# 					print("- Inject: NodeGroup: ", nodegrp.name, nodeCach)
			# 					node.node_tree = nodegrp
			# 			#else:
			# 			#	print("- Inject: NodeGroup skipped: ", node_tag, nodeCach)
			# if config.kWPLSystemNodeTagObjId in node.label:
			# 	node_inpts = node.label.split(":")
			# 	# print("obj_id node:", node.type, node_inpts, node_inpts[1])
			# 	# object index
			# 	finalIndex = None
			# 	if len(node_inpts) >= 2:
			# 		node_tag = str(node_inpts[1])
			# 		# if node_tag in objs2tag:
			# 		# 	tagged = objs2tag[ node_tag ]
			# 		# 	idx = int(node_inpts[2])
			# 		# 	finalIndex = config.kWPLOslQueryMaxObjs
			# 		# 	if idx >= 0 and idx < len(tagged):
			# 		# 		lobj = tagged[idx]
			# 		# 		finalIndex = lobj.pass_index
			# 		# else:
			# 		# object name
			# 		if node_tag in bpy.data.objects:
			# 			node_obj = bpy.data.objects.get(node_tag)
			# 			finalIndex = node_obj.pass_index
			# 	if finalIndex is not None:
			# 		if node.type == 'VALUE':
			# 			node.outputs[0].default_value = finalIndex
			# 		if node.type == 'ID_MASK':
			# 			node.index = finalIndex
		#warns_noIslandMeshes = 0
		if self.opt_mode in ['FINAL_BG', 'FINAL_CG']: # or True
			# Checking islands, edge unwrap and bone normals for all "_fg_" objects
			# if required map not already present
			for obj in objs2dump:
				if obj.hide_render == True:
					# ignored
					continue
				if wla.isTokenInStr(config.kWPLObjFrameWrapperF0, wla.object_full_name(obj)):
					# ignored
					continue
				# checking debug modifiers and constraints
				if obj.type == 'GPENCIL':
					if len(obj.grease_pencil_modifiers)>0:
						for md in obj.grease_pencil_modifiers:
							if wla.isTokenInStr(config.kWPLSystemDBGToken, md.name) and md.show_render == True:
								errs_msgList.append("Active DBG modifier: ["+ wla.object_full_name(obj)+"] ["+md.name+"]")
				else:
					if len(obj.modifiers)>0:
						for md in obj.modifiers:
							if wla.isTokenInStr(config.kWPLSystemDBGToken, md.name) and md.show_render == True:
								errs_msgList.append("Active DBG modifier: ["+ wla.object_full_name(obj)+"] ["+md.name+"]")
					if len(obj.constraints)>0:
						for cs in obj.constraints:
							if wla.isTokenInStr(config.kWPLSystemDBGToken, cs.name) and cs.mute != True:
								errs_msgList.append("Active DBG constraint: ["+ wla.object_full_name(obj)+"] ["+cs.name+"]")
				if obj.type == 'MESH':
					active_mesh = obj.data
					# zero scale - can be intentional
					# non-zero but small - problematic, big UVs -> 'inf' in tif
					# example: cg99, nks hall table, scales was 0.000034
					obj_scalemat = obj.matrix_world.to_scale()
					obj_scale = abs(obj_scalemat[0])+abs(obj_scalemat[1])+abs(obj_scalemat[2])
					if wla.isTokenInStr(config.kWPLSystemOslIncluded, wla.object_full_name(obj)):
						# FG checks
						if obj_scale > 0.0 and (obj_scale < 0.01 or obj_scale > 10):
							# FG element - bad scale - possible MAJOR problem
							errs_msgList.append("Invalid object scale: ["+ wla.object_full_name(obj)+"] scal="+str(obj_scale))
						if self.opt_mode in ['FINAL_CG'] and wla.isTokenInStr(config.kWPLObjFrameWrapperF0, wla.object_full_name(obj)) == False:
							if wla.isTokenInStr(config.kWPLObjCharFaceToken + [config.kWPLUdiSyseToken, config.kWPLUdiSysfToken], wla.object_full_name(obj)) == False:
								vc_layer_ob = active_mesh.vertex_colors.get(config.kWPLIslandsVC)
								if vc_layer_ob is None and wla.is_object_valid(obj, 0.01):
									# !!! Regeneration required Using CURRENT Camera position !!! 
									# !!! So must be made manually
									errs_msgList.append("Extra map missing: ["+ wla.object_full_name(obj)+"], map:" +config.kWPLIslandsVC)
								uv_layer_ob = active_mesh.attributes.get(config.kWPLEBoneFlowUV)
								if uv_layer_ob is None and wla_arma.is_has_arma_vgs(obj):
									# !!! Regeneration required Using CURRENT Camera position !!! 
									# !!! So must be made manually
									errs_msgList.append("Extra map missing: ["+ wla.object_full_name(obj)+"], map:" +config.kWPLEBoneFlowUV)
					# else:
					# 	vc_layer_ob = active_mesh.vertex_colors.get(config.kWPLIslandsVC)
					# 	if vc_layer_ob is None:
					# 		warns_noIslandMeshes = warns_noIslandMeshes+1
		# View layers setup, materials auto-override, etc
		c_opts = config.kWPLLayerRenderModeRules[self.opt_mode]
		if self.opt_mode in ['FINAL_BG', 'FINAL_CG']:
			# adding extra options for final renders
			for vl in c_scene.view_layers:
				for vl_tok in config.kWPLLayerRenderModeRules:
					if vl_tok in vl.name:
						c_opts.update(config.kWPLLayerRenderModeRules[vl_tok])
		cycles_max_bounces = 1
		cycles_adaptive = None
		if "max_bounces" in c_opts:
			cycles_max_bounces = max(cycles_max_bounces, int(c_opts["max_bounces"]))
		if "adapt" in c_opts:
			cycles_adaptive = c_opts["adapt"]
		print("- Rendering setup:", c_opts)
		for vl in c_scene.view_layers:
			#print("Layer",i,vl.name)
			if not (config.kWPLLayerRenderPrefix in vl.name):
				# not a system render layers... ignoring
				vl.use = False
				continue
			isVLUsed = False
			if self.opt_mode in ['FINAL_BG', 'FINAL_CG']:
				# enabling for FINAL render by default
				isVLUsed = True
			# elif self.opt_mode == 'ALPHA':
			# 	if wla.isTokenInStr(config.kWPLLayerRender_ALPHA, vl.name):
			# 		isVLUsed = True
			else:
				# no change in other modes
				isVLUsed = vl.use
			if config.kWPLLayerRenderMain in vl.name:
				vl.use_pass_material_index = True
				vl.use_pass_z = True
				#vl.use_pass_object_index = True
				#bpy.data.worlds[config.kWPLSystemMainWorld].mist_settings.falloff = 'LINEAR'
				#bpy.data.worlds[config.kWPLSystemMainWorld].mist_settings.start = minObjDepth
				#bpy.data.worlds[config.kWPLSystemMainWorld].mist_settings.depth = maxObjDepth
			else:
				vl.use_pass_material_index = False
				vl.cycles.use_denoising = False
				vl.use_pass_z = False
				#vl.use_pass_object_index = False
			vl.use_pass_combined = True
			vl.use_pass_diffuse_color = True
			vl.use_pass_emit = True
			vl.use_pass_glossy_color = True
			vl.use_pass_transmission_color = True
			vl.use_pass_subsurface_color = False
			vl.use_pass_ambient_occlusion = False
			vl.use_pass_normal = True
			vl.use_pass_shadow = False
			vl.use_pass_mist = False
			cycles_denoise = False
			samples_rq_a = None
			for vl_tok in config.kWPLLayerRenderSetupRules.keys():
				if vl_tok in vl.name:
					opts = config.kWPLLayerRenderSetupRules[vl_tok]
					if "denoise" in opts:
						cycles_denoise = opts["denoise"]
					if "samples:RQ-A" in opts:
						samples_rq_a = opts["samples:RQ-A"]
			if samples_rq_a is not None:
				vl.samples = max(1, int(c_opts["samples"]*c_opts["qual_mul"]*samples_rq_a))
			else:
				vl.samples = max(1, int(c_opts["samples"]*c_opts["qual_mul"]))
			if cycles_denoise == True:
				vl.cycles.use_denoising = True
				vl.cycles.denoising_openimagedenoise_input_passes = 'RGB_ALBEDO_NORMAL'
			vl.use = isVLUsed
			# enabling proper collections for view layer
			collSet = None
			collSetXt = None
			for vl_tok in config.kWPLLayerRenderSetupRules.keys():
				if vl_tok in vl.name:
					opts = config.kWPLLayerRenderSetupRules[vl_tok]
					# if self.opt_mode == 'ALPHA' and "alpha_collections" in opts:
					# 	collSet = opts["alpha_collections"]
					# 	break
					if "colls" in opts: # final_collections are also defaults
						collSetXt = opts["collsXt"]
						collSet = opts["colls"]+collSetXt
						break
			if collSet is None:
				print("- RenderLayer:",vl.name,"WARNING: config not found. Using defaults.")
				collSet = config.kWPLLayerRenderDefaultColls
			lc_all = wla_do.view_layer_asllchildren(vl.layer_collection.children, True)
			for lc in lc_all:
				lc.exclude = True
				if wla.isTokenInStr(collSet, lc.name):
					lc.exclude = False
					if wla.isTokenInStr(collSetXt, lc.name) and (config.kWPLFrameBindPostfix in lc.name):
						errs_msgList.append("Collection Xt: kWPLFrameBindPostfix found: ["+ lc.name+"]")
			# enabling material override, if needed
			mat_overrd = None
			if (vl.material_override is not None) and (config.kWPLMatTokenLocal in vl.material_override.name):
				# keeping current local material
				mat_overrd = vl.material_override
				print("// ",vl.name,"- keeping local override")
			if mat_overrd is None:
				for mat in all_mat:
					if vl.name.lower() in mat.name.lower():
						mat_overrd = mat
						break
			vl.material_override = mat_overrd
			if vl.material_override is None:
				print("- RenderLayer:",vl.name,("->" if vl.use else "xx"),"None", vl.samples)
			else:
				print("- RenderLayer:",vl.name,("->" if vl.use else "xx"), vl.material_override.name, vl.samples)
		# rendering preparations
		c_scene.render.resolution_percentage = c_opts["renderPercentage"]
		c_scene.cycles.max_bounces = cycles_max_bounces
		if cycles_adaptive is None:
			c_scene.cycles.use_adaptive_sampling = False
		else:
			c_scene.cycles.use_adaptive_sampling = True
			c_scene.cycles.adaptive_threshold = cycles_adaptive[0]
			c_scene.cycles.adaptive_min_samples = int(cycles_adaptive[1])
		if self.opt_mode != 'TEST':
			c_scene.render.use_border = False
		# all done
		if len(errs_msgList) > 0:
			print("\nERRORS:")
			for err in errs_msgList:
				print("-", err)
		# if warns_noIslandMeshes > 0:
		# 	print("- WARNING: Meshes without Islands VC:", warns_noIslandMeshes)
		if self.opt_mode in ['FINAL_BG', 'FINAL_CG']:
			#print("- Nodeflags:", config.WPL_G.store[kWPLGKey_DRV_RenderFlags])
			if len(errs_msgList) > 0:
				config.WPL_G.store[kWPLGKey_DRV_SyncStatus] = "INVALID"
				self.report({'ERROR'}, "FINAL: failed, errors found")
			else:
				config.WPL_G.store[kWPLGKey_DRV_SyncStatus] = "FINAL"
				finalRes = str(int(c_scene.render.resolution_x*c_scene.render.resolution_percentage/100.0))+":"+str(int(c_scene.render.resolution_y*c_scene.render.resolution_percentage/100.0))
				self.report({'INFO'}, "FINAL: "+finalRes+", WARNS:"+str(len(errs_msgList)))
				#if "frh" not in WPL_G.store:
				#	WPL_G.store["frh"] = 1
				#	handlers.render_pre.append(frh_start_timer)
				#	handlers.render_stats.append(frh_elapsed)
		# elif self.opt_mode == 'ALPHA':
		# 	config.WPL_G.store[kWPLGKey_DRV_SyncStatus] = "ALPHA"
		# 	if len(errs_msgList) > 0:
		# 		config.WPL_G.store[kWPLGKey_DRV_SyncStatus] = "INVALID"
		# 	self.report({'INFO'}, "ALPHA prepared, WARNS:"+str(len(errs_msgList)))
		else:
			config.WPL_G.store[kWPLGKey_DRV_SyncStatus] = "TEST"
			self.report({'INFO'}, "TEST prepared, WARNS:"+str(len(errs_msgList)))
		wla_do.select_and_change_mode(camera_obj, 'OBJECT') # again, active/selection may change
		if self.opt_mode == 'TEST' and mac_obj_mtx is not None:
			 # improtant for testing in rotated positions
			camera_obj.matrix_world = mac_obj_mtx[0]
			camera_obj.data.shift_x = mac_obj_mtx[1]
			camera_obj.data.shift_y = mac_obj_mtx[2]
		print("- All done")
		return {'FINISHED'}

class wplscene_runrender(bpy.types.Operator):
	bl_idname = "object.wplscene_runrender"
	bl_label = "Run prepared"
	bl_options = {'REGISTER'}

	opt_mode : EnumProperty(
		items = [
			('TEST', "TEST Render", "", 1),
			#('ALPHA', "ALPHA Render", "", 2),
			('FINAL_BG', "BG: FINAL Render", "", 3),
			('FINAL_FG', "FG: FINAL Render", "", 4),
			('ASIS_RQ0', "Render As-Is, RQ-A", "", 5),
			('ASIS_RQALL', "Render As-Is, RQ-A && RQ-B", "", 6)
		],
		name="Render mode",
		default='TEST',
	)
	opt_firstFrame : IntProperty(
		name="First Frame", 
		default=-1, 
		min=-99, max=99
	)
	opt_lastFrame : IntProperty(
		name="Last Frame", 
		default=-1, 
		min=-99, max=99
	)

	# Running as separate dialog
	def invoke(self, context, event):
		return context.window_manager.invoke_props_dialog(self, width = 200)

	def execute( self, context ):
		print("- Render Sequence: Starting preparations")
		if self.opt_mode not in ['ASIS_RQ0', 'ASIS_RQALL']:
			try:
				bpy.ops.object.wplscene_prep2render(opt_mode = self.opt_mode)
			except Exception as e:
				print("- Render Sequence: Skipped, errors found, exception:", e)
				self.report({'ERROR'}, "Render Sequence: Skipped, errors found")
				return {'FINISHED'}
		if "INVALID" in config.WPL_G.store[kWPLGKey_DRV_SyncStatus]:
			print("- Render Sequence: Skipped, errors found, status: INVALID")
			self.report({'ERROR'}, "Render Sequence: Skipped, errors found")
			return {'FINISHED'}
		c_scene = bpy.context.scene
		frameF = c_scene.frame_start
		frameT = c_scene.frame_end
		if self.opt_firstFrame >= 0:
			frameF = self.opt_firstFrame
		if self.opt_lastFrame >= 0:
			frameT = self.opt_lastFrame
		final_render_name, final_render_path = getSceneRenderPath(c_scene)
		print("- Rendering sequence:", frameF, "->", frameT, c_scene.render.resolution_x, c_scene.render.resolution_y, c_scene.render.resolution_percentage )
		print("// Path:", final_render_path)
		print("// Timestamp:", datetime.datetime.fromtimestamp(time.time()).strftime('%Y-%m-%d %H:%M:%S'))
		ht_keys = list(kWPLGKey_HT_Objects.keys())
		if len(ht_keys) > 0:
			# Disabling any hotobject watchers
			print("- DRV HotObjects: disabling", ht_keys)
			for ht_i in ht_keys:
				del kWPLGKey_HT_Objects[ht_i]
		camera_obj = wla.object_by_name(config.kWPLSystemMainCam)
		wla_do.ensure_visible(camera_obj, 1)
		wla_do.select_and_change_mode(camera_obj, 'OBJECT')
		# preparing initials
		initials_QUFA = [] # RQ-A
		initials_QUFB = [] # RQ-B
		initials_QUF_mv = []
		initials_VL = {}
		for vl in bpy.context.scene.view_layers:
			initials_VL[vl.name+"_samples"] = vl.samples
			initials_VL[vl.name+"_use"] = vl.use
		for ob in bpy.data.objects:
			if wla.isTokenInStr(config.kWPLRQueueBindPostfix, ob.name):
				if (config.kWPLRQueueBindPostfix[0] in ob.name) or ("_#quf_a" in ob.name):# "_#quf_a" -> old naming
					initials_QUFA.append(ob.name)
				if (config.kWPLRQueueBindPostfix[1] in ob.name) or ("_#quf_b" in ob.name):# "_#quf_b" -> old naming
					initials_QUFB.append(ob.name)
			obj_vers, _, _ = wla.sys_objdata_versions(ob)
			if len(obj_vers) > 1:
				initials_QUF_mv.append(ob.name)
		def alterObjectVisibilityToRenderQueue(queNum, objsEnable, objsDisable, vl_frame_tag):
			for ob_name_enable in objsEnable:
				obj = wla.object_by_name(ob_name_enable)
				if obj is not None:
					if (vl_frame_tag is not None) and (config.kWPLFrameBindPostfix in obj.name):
						if vl_frame_tag not in obj.name:
							# should NOT be altered for this frame
							continue
					print("// RQ: unhide", obj.name)
					obj_childs = [obj]
					if obj.type == 'EMPTY':
						# Looking for hierarchy
						wla.all_childs_recursive(obj, obj_childs)
					for xobj in obj_childs:
						xobj.hide_render = False
			for ob_name_disable in objsDisable:
				obj = wla.object_by_name(ob_name_disable)
				if obj is not None:
					if (vl_frame_tag is not None) and (config.kWPLFrameBindPostfix in obj.name):
						if vl_frame_tag not in obj.name:
							# should NOT be altered for this frame
							continue
					print("// RQ: hide", obj.name)
					obj_childs = [obj]
					if obj.type == 'EMPTY':
						# Looking for hierarchy
						wla.all_childs_recursive(obj, obj_childs)
					for xobj in obj_childs:
						xobj.hide_render = True
			for vl in bpy.context.scene.view_layers:
				# limiting VLs accoring to kWPLLayerRenderSetupRules
				samples = initials_VL[vl.name+"_samples"]
				for vl_tok in config.kWPLLayerRenderSetupRules.keys():
					if vl_tok in vl.name:
						opts = config.kWPLLayerRenderSetupRules[vl_tok]
						if queNum == 1 and "factor:RQ-B" in opts:
							samples = samples*opts["factor:RQ-B"]
				vl.samples = max(1, int(samples))
			return
		def alterObjectMeshVersion(objsVer, stopTag):
			objs = 0
			for ob_name in objsVer:
				obj = wla.object_by_name(ob_name)
				obj_vers, _, _ = wla.sys_objdata_versions(obj)
				ver_setQ = None
				ver_lastNonQ = None
				for ver_nm in obj_vers:
					if wla.isTokenInStr(config.kWPLRQueueBindPostfix, ver_nm):
						if stopTag in ver_nm:
							ver_setQ = ver_nm
							break
						else:
							ver_setQ = ver_lastNonQ
					else:
						ver_lastNonQ = ver_nm
				if ver_setQ is not None:
					# setting object mesh/etc version
					print("// RQ: upd.ver", obj.name, ver_setQ)
					newDat = wla.sys_objdata_by_name(obj, ver_setQ)
					if newDat is None:
						print("// RQ: upd.ver: failed - no data!", obj.name, ver_setQ)
						continue
					obj.data = newDat
					objs = objs+1
			return objs
		def frameDoRender(fr, queNum, frfl, frame_tag):
			render_quf_enabled = 0
			render_quf_name = "["+frfl+"]"
			bpy.context.scene.frame_set(fr)
			print("- Starting frame", fr, render_quf_name)
			# Restoring initial values and specific objects visibility
			# AFTER frame_set, may alter per-object frame-visibility values
			if queNum == 0:
				render_quf_enabled = 1
				alterObjectVisibilityToRenderQueue(queNum, initials_QUFA, initials_QUFB, frame_tag)
			if queNum == 1 and len(initials_QUFB) > 0:
				render_quf_enabled = 1
				alterObjectVisibilityToRenderQueue(queNum, initials_QUFB, initials_QUFA, frame_tag)
			if queNum < len(config.kWPLRQueueBindPostfix):
				objAffects = alterObjectMeshVersion(initials_QUF_mv, config.kWPLRQueueBindPostfix[queNum])
				if objAffects>0:
					render_quf_enabled = 1
			if render_quf_enabled == 0:
				print("// No special changes, skipping")
				return
			if camera_obj is not None:
				camera_obj[config.kWPLCustomPropTagFrameQueue] = queNum
				c_scene.camera = camera_obj
			exr_files_before = os.listdir(final_render_path)
			config.WPL_G.store["drv_verbose"] = 1
			bpy.ops.render.render(animation=False, write_still=True, use_viewport=False, scene=c_scene.name) # "INVOKE_DEFAULT", 
			config.WPL_G.store["drv_verbose"] = 0
			exr_files_after = os.listdir(final_render_path)
			# detecting new files
			for fl in exr_files_after:
				if ".exr" not in fl:
					continue
				if fl not in exr_files_before:
					fl_path_name = os.path.splitext(fl)[0]
					fl_to = fl_path_name+frfl+os.path.splitext(fl)[1]
					fl_to = fl_to.replace("0000", "")
					fl_to = fl_to.replace("0001", "")
					fl_to = fl_to.replace("0002", "")
					fl_to = fl_to.replace("0003", "")
					fl_to = fl_to.replace("0004", "")
					fl_to = fl_to.replace("0005", "")
					fl_to = fl_to.replace("0006", "")
					fl_to = fl_to.replace("0007", "")
					fl_to = fl_to.replace("0008", "")
					fl_to = fl_to.replace("0009", "")
					fl_to = fl_to.replace("__", "_")
					print("- EXR: renaming rendered", fl, fl_to)
					if os.path.exists(os.path.join(final_render_path,fl_to)):
						print("- EXR: deleting old",fl_to)
						os.remove(os.path.join(final_render_path,fl_to))
					os.rename(os.path.join(final_render_path,fl), os.path.join(final_render_path,fl_to))
		def frameSaveSVG(fr, vl_frame_tag):
			vl_main = getViewLayer(config.kWPLLayerRenderMain)
			if vl_main is None:
				return
			# saving SVG if any
			objs4svg_export = []
			for obj in bpy.data.objects:
				if obj.type == 'GPENCIL' and vl_frame_tag in obj.name:
					#wla_do.ensure_visible(obj, 2)
					# mdES = wla.modf_by_type(obj, ???, wla_edger.kWPL_EdgeModf_ExportSimplify)
					# if mdES is not None:
					# 	mdES.show_viewport = True
					# 	mdES.show_render = True
					# Disabling debug modifiers (ONLY)
					mdDB = wla.modf_by_type(obj, None, wla_edger.kWPL_EdgeModf_DBGBold)
					if mdDB is not None:
						mdDB.show_viewport = False
						mdDB.show_render = False
					splines = wla_curve.cu_getSplines(obj)
					for polyline in splines:
						polyline.start_cap_mode = 'FLAT'
						polyline.end_cap_mode = 'FLAT'
					objs4svg_export.append(obj)
			if len(objs4svg_export) > 0:
				# enabling Edging collection in Main view layers
				context.window.view_layer = vl_main
				bpy.context.scene.frame_set(fr)
				edgeColl = wla.sys_collection(config.kWPLSystemEdgeColl)
				edgeColl.hide_viewport = False
				lc_all = wla_do.view_layer_asllchildren(vl_main.layer_collection.children, True)
				for lc in lc_all:
					if lc.name == config.kWPLSystemEdgeColl:
						lc.hide_viewport = False
						lc.exclude = False
				wla_do.sys_update_view(True, True)
				# zzzEdge will be enabled - needed for export
				bpy.ops.object.select_all(action='DESELECT')
				wla_do.select_and_activate_multi(objs4svg_export, None)
				svg_path = final_render_name+"_gp"+frame_file_prefSVG+".svg"
				svg_path = svg_path.replace("__","_")
				svg_path = os.path.join(final_render_path, svg_path)
				print("// Saving svgs:", len(objs4svg_export), svg_path)
				bpy.ops.wm.gpencil_export_svg(filepath = svg_path,
					selected_object_type='SELECTED', # ACTIVE, VISIBLE
					check_existing=False,
					use_fill=True, 
					stroke_sample=0.0,
					use_normalized_thickness=False,
					use_clip_camera=False)
				lc_all = wla_do.view_layer_asllchildren(vl_main.layer_collection.children, True)
				for lc in lc_all:
					if lc.name == config.kWPLSystemEdgeColl:
						lc.hide_viewport = True
						lc.exclude = True
				wla_do.sys_update_view(True, True)
		config.WPL_G.store["last:wpl_frameChange"] = -1
		# ====================================================
		bpy.ops.object.select_all(action='DESELECT')
		#final_render_name = c_scene.render.filepath
		final_render_name, final_render_path = getSceneRenderPath(c_scene)
		# removing exr files
		exr_files_before = os.listdir(final_render_path)
		for fl in exr_files_before:
			if ".exr" not in fl:
				continue
			print("// EXR: cleaning", fl)
			os.remove(os.path.join(final_render_path, fl))
		bpy.types.RenderSettings.use_lock_interface = True
		config.WPL_G.store["last:wpl_frameChange"] = -1
		for fr in range(frameF, frameT+1):
			frame_tag = config.kWPLFrameBindPostfix + str(int(fr))
			frame_file_prefSVG = "_f"
			if self.opt_mode == 'ASIS_RQ0':
				frame_file_prefAsIs = "_asis"+str(fr).zfill(2)
				frameDoRender(fr, 0, frame_file_prefAsIs, frame_tag)
				frame_file_prefSVG = frame_file_prefAsIs
			else:
				# queue A: full samples
				frame_file_prefA = "_fa"+str(fr).zfill(2)
				frameDoRender(fr, 0, frame_file_prefA, frame_tag)
				# queue B: limited samples (in alterObjectVisibilityToRenderQueue)
				frame_file_prefB = "_fb"+str(fr).zfill(2)
				frameDoRender(fr, 1, frame_file_prefB, frame_tag)
				frame_file_prefSVG = frame_file_prefA
			frameSaveSVG(fr, frame_tag)
		bpy.ops.object.select_all(action='DESELECT')
		# Restoring initial values and specific objects visibility
		alterObjectVisibilityToRenderQueue(0, initials_QUFA, initials_QUFB, None)
		if camera_obj is not None: # resetting value
			camera_obj[config.kWPLCustomPropTagFrameQueue] = 0
		bpy.types.RenderSettings.use_lock_interface = False
		print("- Interface unlocked")
		if self.opt_mode in ['FINAL_BG', 'FINAL_CG']:
			extractor_path = None
			for stp in config.kWPLPostFINALRenderExtractor:
				if os.path.exists(stp):
					extractor_path = stp
					break
			if extractor_path is not None:
				print("- Executing extractor", extractor_path)
				extr_call = []
				extr_call.append("python3")
				extr_call.append(extractor_path)
				extr_call.append(os.path.join(final_render_path, ''))
				subprocess.check_call(" ".join(extr_call), shell=True, stdout=sys.stdout, stderr=subprocess.STDOUT)
		print("-", datetime.datetime.fromtimestamp(time.time()).strftime('%Y-%m-%d %H:%M:%S'),"Render sequence: done")
		self.report({'INFO'}, "Render sequence: Done")
		return {'FINISHED'}

# ==========================================
# ==========================================
# ==========================================
# ==========================================

def uilayout_trafarefBox(col, context):
	trafaref_imgs = 0
	for im in bpy.data.images:
		if wla.isTokenInStr(config.kWPLComposTrafarefLenToken, im.name):
			tokidx = im.name.lower().find(config.kWPLComposTrafarefLenToken.lower())
			if tokidx > 0:
				# tape of frames
				trafaref_imgs = trafaref_imgs+1
				col.label(text = "TRAFAREF: " + im.name)
				frames = int(im.name[tokidx+len(config.kWPLComposTrafarefLenToken)])
				row = col.row()
				for fr in range(0, frames):
					op = row.operator("object.wplscene_trafaref", text="["+str(fr+1)+"]")
					op.opt_imge = im.name
					op.opt_tapeframe = (fr, frames)
			# else:
			# 	# single image
			# 	op = box2.operator("object.wplscene_trafaref", text=im.name)
			# 	op.opt_imge = im.name
			# 	op.opt_tapeframe = (0,0)
	if trafaref_imgs>0:
		#col.label( text='Trafaref visibility')
		row = col.row()
		row.operator("object.wplscene_trafaref", text="Trafaref OFF").opt_opacity = 0
		row.operator("object.wplscene_trafaref", text="Trafaref ON").opt_opacity = 100
		row = col.row()
		row.operator("object.wplscene_trafaref", text="10%").opt_opacity = 10
		row.operator("object.wplscene_trafaref", text="40%").opt_opacity = 40
		row.operator("object.wplscene_trafaref", text="70%").opt_opacity = 70
	#else:
	# 	box2.label( text='// No Trafaref images found')

class WPL_PT_SceneManPanel(bpy.types.Panel):
	bl_idname = "WPL_PT_SceneManPanel"
	bl_label = "Scene manager"
	bl_space_type = 'VIEW_3D'
	bl_region_type = 'UI'
	bl_category = 'FINALS'

	def draw(self, context):
		layout = self.layout
		col = layout.column()
		c_scene = bpy.context.scene
		frameC = c_scene.frame_current
		frameF = c_scene.frame_start
		frameT = c_scene.frame_end
		# display the properties
		box1 = col.box()
		row0 = box1.row()
		op1 = row0.operator("object.wplscene_updnodeval", text="DBG=0", icon="SHADING_SOLID")
		op1.opt_nodeNameTag = config.kWPLCustomPropTagDebug
		op1.opt_nodeNameValue = "0"
		op1.opt_viewportSwitch = 'NORMAL'
		op1.opt_updateDeps = False
		op1 = row0.operator("object.wplscene_updnodeval", text="DBG=1 (COL/VL)", icon="SHADING_RENDERED")
		op1.opt_nodeNameTag = config.kWPLCustomPropTagDebug
		op1.opt_nodeNameValue = "1"
		op1.opt_viewportSwitch = 'CYCLES'
		op1.opt_updateDeps = True # for RefEmis recalcs, etc
		row0 = box1.row()
		spl = row0.split(align=True, factor=0.5)
		
		spl_col = spl.row()
		op1 = spl_col.operator("object.wplscene_updnodeval", text="FLAT COL")
		op1.opt_nodeNameTag = config.kWPLCustomPropTagDebug
		op1.opt_nodeNameValue = "0"
		op1.opt_viewportSwitch = 'FLATVC_DEC'
		op1.opt_updateDeps = False
		op1 = spl_col.operator("object.wplscene_updnodeval", text="DBG MAT")
		op1.opt_nodeNameTag = config.kWPLCustomPropTagDebug
		op1.opt_nodeNameValue = "0"
		op1.opt_viewportSwitch = 'FLATMAT'
		op1.opt_updateDeps = False

		spl_col = spl.row()
		if bpy.context.space_data.shading.type != 'RENDERED':
			op1 = spl_col.operator("object.wplscene_updnodeval", text="FLAT ISL")
			op1.opt_nodeNameTag = config.kWPLCustomPropTagDebug
			op1.opt_nodeNameValue = "0"
			op1.opt_viewportSwitch = 'FLATVC_ISL'
			op1.opt_updateDeps = False
			op1 = spl_col.operator("object.wplscene_updnodeval", text="DBG NRM")
			op1.opt_nodeNameTag = config.kWPLCustomPropTagDebug
			op1.opt_nodeNameValue = "0"
			op1.opt_viewportSwitch = 'NORMALBF'
			op1.opt_updateDeps = False
		else:
			op1 = spl_col.operator("object.wplscene_framesync", text="DBG: UPDATE DRIVERS")
			op1.opt_updateDrivers = True
			op1.opt_updateAnim = False
			op1.opt_updateScene = False
		box1.separator()
		if "osl_frame"+str(frameC) not in config.WPL_G.store:
			opRP_t = box1.operator("object.wplscene_prep2render", text="Frame "+str(frameC)+": Bind MAT/OSL (!)", icon="EXPERIMENTAL")
			opRP_t.opt_mode = 'TEST'
		else:
			opRP_t = box1.operator("object.wplscene_prep2render", text="Frame "+str(frameC)+": Rebind MAT/OSL", icon="EXPERIMENTAL")
			opRP_t.opt_mode = 'TEST'
		row0 = box1.row()
		op0 = row0.operator("object.wplscene_framesync", text = "Bind Anims")
		op0.opt_updateDrivers = False
		op0.opt_updateAnim = True
		op0.opt_updateScene = False
		op0 = row0.operator("object.wplscene_framesync", text = "Sync Scene")
		op0.opt_updateDrivers = False
		op0.opt_updateAnim = False
		op0.opt_updateScene = True
		box1.operator("object.wplscene_viewlbind")
		op0 = box1.operator("object.wplscene_runrender", text="RENDER SCENES ("+str(frameF)+"-"+str(frameT)+")", icon="RENDER_ANIMATION")

# ==========================================
# ==========================================

classes = (
	WPL_PT_SceneManPanel,

	wplscene_updnodeval,
	wplscene_framesync,
	wplscene_viewlbind,
	wplscene_trafaref,

	wplscene_prep2render,
	wplscene_runrender
)

def register():
	bpy.app.handlers.render_pre.append(wpl_renderStart)
	bpy.app.handlers.render_post.append(wpl_renderStop)
	bpy.app.handlers.frame_change_pre.append(wpl_frameChange)
	bpy.app.handlers.load_post.append(wpl_loadPost)
	bpy.app.handlers.depsgraph_update_post.append(wpl_depsChange)
	wpl_loadPost("reg")
	for cls in classes:
		bpy.utils.register_class(cls)

def unregister():
	bpy.app.handlers.render_pre.remove(wpl_renderStart)
	bpy.app.handlers.render_post.remove(wpl_renderStop)
	bpy.app.handlers.frame_change_pre.remove(wpl_frameChange)
	bpy.app.handlers.load_post.remove(wpl_loadPost)
	bpy.app.handlers.depsgraph_update_post.remove(wpl_depsChange)
	for cls in reversed(classes):
		bpy.utils.unregister_class(cls)

if __name__ == "__main__":
	register()