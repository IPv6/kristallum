import os, sys, time, datetime
import math, copy, string, random
import numpy as np
import json
import bpy, bmesh, mathutils

import bpy.types
from mathutils import Vector, Matrix, Euler, Quaternion
from mathutils.bvhtree import BVHTree
from mathutils.kdtree import KDTree
from bpy_extras import view3d_utils
from bpy.props import *

import gpu, bgl
from gpu_extras.presets import draw_circle_2d
from gpu_extras.batch import batch_for_shader

from . import config
from .tools import wla
from .tools import wla_do
from .tools import wla_bm
from .tools import wla_attr
from .ops_scene_man import _mix3l, _mix3s, _mix2, _mixArc, _cuh, _rndf

kWPL_STP_PRESET_PEN  = '{"stamp":"<stripe>", "ovr_grd":"999", "flow_cuh":"159"}'
kWPL_STP_PRESET_OVR  = '{"stamp":"<stripe>", "ovr_grd":"111", "flow_cuh":"159"}'
kWPL_STP_PRESET_MAT  = '{"stamp_flags":1}'
kWPL_STP_PRESET_CUTINSD  = '{"stamp":"<view-cut>"}'
kWPL_STP_PRESET_EXTRACT  = '{"stamp":"<view-sep>"}'

kWPL_ATTR_OPT1 = "pff_shapeOpt1" # "pff_shapeAlpha"
kWPL_ATTR_OPT2 = "pff_shapeOpt2"
kWPL_ATTR_DIRO = "pff_shapeDirO"
kWPL_ATTR_DIRS = "pff_shapeDirS"
kWPL_ATTR_DIRE = "pff_shapeDirE"

kWPL_STP_SNAPDOT_COLOR = (0.2, 0.2, 0.8, 1.0)
kWPL_STP_SNAPDOT_SIZEPX = 1
kWPL_STP_LINE_LSIZEPX = 5
kWPL_STP_LINE_COLOR = (0.2, 0.8, 0.2, 1.0)
kWPL_STP_CIRCLE_VERTS = 10

kWPL_STP_ORIENTS_ROTLOC = ['LOCAL_XY','LOCAL_XZ','LOCAL_YZ']
kWPL_STP_ORIENTS_ROTCUR = ['CUR3D_XY','CUR3D_XZ','CUR3D_YZ']
kWPL_STP_ZPUSH_STEP = 0.0001
kWPL_STP_MATLIST_MAXITEMS = 10

kWPLAutoSetupPffRnd_offsetRel = "#pff:rnd_offset_rel"
kWPLAutoSetupPffRnd_offsetAbs = "#pff:rnd_offset_abs"
kWPLAutoSetupPffRnd_offsetDefl = "[ 0.0, 0.0, 0.0 ]"
kWPLAutoSetupPffRnd_spin = "#pff:rnd_spin"
kWPLAutoSetupPffRnd_spinDefl = "[ 0.0, 0.0, spinI ]"
kWPLAutoSetupPffRnd_scale = "#pff:rnd_scale"
kWPLAutoSetupPffRnd_scaleDefl = "[ 1.0, 1.0, 1.0, 1.0 ]"
kWPLAutoSetupPffRnd_flow = "#pff:rnd_flow"
kWPLAutoSetupPffRnd_flowDefl = "[ 1.0, _rndf(-1.0,1.0) ]"
kWPLAutoSetupPffRnd_flags = "#pff:stamp_flags"
kWPLAutoSetupPffRnd_flagsDefl = ""

class STAMP_C:
	isActive = 0
	target_obj_name = ''
	grid_center = Vector((0,0,0))
	grid_plane_cache = None
	grid_plane_zpush = 0.0
	grid_plane_zcnt = 0
	grid_plane_zinv = 1.0
	undo_steps = []

def get_draw_plane(context, scene_pt):
	axis_c = None
	axis_x = None
	axis_y = None
	axis_z = None
	if STAMP_C.grid_plane_cache is not None:
		return STAMP_C.grid_plane_cache
	wpl_stamppOpts = context.scene.wpl_stamppOpts
	axis_c = STAMP_C.grid_center
	if wpl_stamppOpts.opt_gridorient in kWPL_STP_ORIENTS_ROTLOC:
		# LOCAL_XY, default, Z is UP. Normalization is AMUST
		mw = Matrix.Identity(4)
		active_obj = wla.object_by_name(STAMP_C.target_obj_name)
		if active_obj is not None:
			mw = active_obj.matrix_world
		mw_nrm_g = mw.inverted().transposed().to_3x3()
		axis_x = (mw_nrm_g @ Vector( (1,0,0) )).normalized()
		axis_y = (mw_nrm_g @ Vector( (0,1,0) )).normalized()
		axis_z = (mw_nrm_g @ Vector( (0,0,1) )).normalized()
		if wpl_stamppOpts.opt_gridorient == 'LOCAL_XZ':
			# y is up
			tmp = axis_y
			axis_y = axis_z
			axis_z = tmp
		elif wpl_stamppOpts.opt_gridorient == 'LOCAL_YZ':
			# x is up
			tmp = axis_x
			axis_x = axis_z
			axis_z = tmp
	if wpl_stamppOpts.opt_gridorient in kWPL_STP_ORIENTS_ROTCUR:
		mw = bpy.context.scene.cursor.matrix
		mw_nrm_g = mw.inverted().transposed().to_3x3()
		axis_x = (mw_nrm_g @ Vector( (1,0,0) )).normalized()
		axis_y = (mw_nrm_g @ Vector( (0,1,0) )).normalized()
		axis_z = (mw_nrm_g @ Vector( (0,0,1) )).normalized()
		if wpl_stamppOpts.opt_gridorient == 'CUR3D_XZ':
			# y is up
			tmp = axis_y
			axis_y = axis_z
			axis_z = tmp
		elif wpl_stamppOpts.opt_gridorient == 'CUR3D_YZ':
			# x is up
			tmp = axis_x
			axis_x = axis_z
			axis_z = tmp
	# orienting plane to camera
	region, _ = wla.active_view_region()
	regionZ_g = (region.view_rotation @ Vector((0.0, 0.0, 1.0)))
	#print("- viewZ", regionZ_g, "planeZ", axis_z, regionZ_g.dot(axis_z))
	if regionZ_g.dot(axis_z) < 0:
		axis_z = -1* axis_z
	STAMP_C.grid_plane_cache = (axis_c, axis_x, axis_y, axis_z)
	return STAMP_C.grid_plane_cache

def plane_pt_to_scene_pt(context, plane_pt):
	plane_co, plane_x, plane_y, plane_z = get_draw_plane(context, None)
	pt = plane_co + plane_x*plane_pt[0] + plane_y*plane_pt[1] + plane_z*plane_pt[2]
	return pt

def scene_pt_to_plane_pt(context, scene_pt_g):
	plane_co, plane_x, plane_y, plane_z = get_draw_plane(context, None)
	plane_mw = wla.math_matrix4axis(plane_co, plane_x, plane_y, plane_z, 0)
	plane_pt = plane_mw.inverted() @ (scene_pt_g)
	scene_pt_g_snapped = plane_pt_to_scene_pt(context, (plane_pt[0], plane_pt[1], 0.0) )
	return (scene_pt_g_snapped, plane_pt)

def region_2d_to_scene_pt(context, co_2d):
	# https://blender.stackexchange.com/questions/150645/projection-of-point-on-plane
	# mira tools get_mouse_on_plane
	view_vec = view3d_utils.region_2d_to_vector_3d(context.region, context.space_data.region_3d, co_2d)
	#view_point = view3d_utils.region_2d_to_origin_3d(context.region, context.space_data.region_3d, co_2d)
	view_point = view3d_utils.region_2d_to_location_3d(context.region, context.space_data.region_3d, co_2d, view_vec)
	plane_co, _, _, plane_no = get_draw_plane(context, None)
	hit_co = mathutils.geometry.intersect_line_plane(view_point, view_point+view_vec*10000, plane_co, plane_no, False)
	if hit_co is not None:
		return hit_co
	return None

def region_2d_view_pixel(context, co_2d_region, co_2d_window):
	# ??? bpy.ops.ui.eyedropper_color
	#https://blender.stackexchange.com/questions/190140/copy-framebuffer-of-3d-view-into-custom-frame-buffer
	# https://docs.blender.org/api/current/gpu.html
	framebuffer = gpu.state.active_framebuffer_get()
	#viewport_info = gpu.state.viewport_get()
	#width = viewport_info[2]
	#height = viewport_info[3]
	# obtain pixels from the framebuffer
	pixelBuffer = framebuffer.read_color(co_2d_window[0], co_2d_window[1], 1, 1, 4, 0, 'FLOAT')
	#print("- read_color", viewport_info, pixelBuffer)
	if pixelBuffer is None:
		return None
	pixelBuffer.dimensions = 1 * 1 * 4
	color = [v for v in pixelBuffer]
	return color

def stamp_get_cuh4curve(curvmod_cuh, fac, defl, curve_cache, isLeft):
	facOvrl = 0.0
	if defl is None:
		# need a FACTOR, not a value
		facOvrl = fac
	if len(curvmod_cuh) > 0:
		ovr_cuh = curvmod_cuh
		if "|" in ovr_cuh:
			ovr_cuh_pair = ovr_cuh.split('|')
			if isLeft:
				ovr_cuh = ovr_cuh_pair[0]
			else:
				ovr_cuh = ovr_cuh_pair[1]

		absMode = 0.0
		if '>' in ovr_cuh:
			absMode = absMode+ovr_cuh.count(">")
			ovr_cuh = ovr_cuh.replace(">","")
		if '<' in ovr_cuh:
			absMode = absMode-ovr_cuh.count("<")
			ovr_cuh = ovr_cuh.replace("<","")
		facOvrl = wla.remap_curve_hash(ovr_cuh, fac)
		if abs(absMode) > 0 and defl is None:
			# need a factor, SHIFTED from current value
			shift_len = facOvrl*3.0*curve_cache["tool_bsize"]*absMode
			shift_fac = shift_len/curve_cache["curve_len"]
			facOvrl = fac + shift_fac
		facOvrl = min(facOvrl,1.0)
		facOvrl = max(facOvrl,0.0)
		# gradMidL = 0.5
		# gradMidR = 0.5
		# if wpl_stamppOpts.opt_curv_ovr_cuh < 0:
		# 	gradMidL = wla.math_lerp1D(abs(wpl_stamppOpts.opt_curv_ovr_cuh),0.5,0.99)
		# 	gradMidR = wla.math_lerp1D(abs(wpl_stamppOpts.opt_curv_ovr_cuh),0.5,0.01)
		# else:
		# 	gradMidL = wla.math_lerp1D(abs(wpl_stamppOpts.opt_curv_ovr_cuh),0.5,0.01)
		# 	gradMidR = wla.math_lerp1D(abs(wpl_stamppOpts.opt_curv_ovr_cuh),0.5,0.99)
		# gradMid = gradMidR
		# if isLeft:
		# 	gradMid = gradMidL
		# facOvrl = wla.remap_F_M_T_linear(fac, gradMid, (0.0,0.5,1.0) )
	return facOvrl

def stampp_draw_callback2_px(self, context):
	if context.area != self.current_area:
		return
	if STAMP_C.last_mouse_pt_g is None:
		return
	wpl_stamppOpts = context.scene.wpl_stamppOpts
	pt_3d_snapped, pt_2d_local = scene_pt_to_plane_pt(context, STAMP_C.last_mouse_pt_g)
	dots2d3d_tmp = None
	pt_co = pt_3d_snapped
	tool_dst = wpl_stamppOpts.opt_tool_bsize
	plane_co, plane_x, plane_y, plane_z = get_draw_plane(context, None)

	bgl.glEnable(bgl.GL_BLEND) # alpha support
	if len(STAMP_C.last_added_dots) >= 1:
		bgl.glLineWidth(kWPL_STP_LINE_LSIZEPX)
		dots2d3d_tmp = copy.copy(STAMP_C.last_added_dots)
		dots2d3d_tmp.append( (pt_2d_local, pt_3d_snapped) )
		rect_pts = []
		for i in range(0, len(dots2d3d_tmp)-1):
			pt1 = dots2d3d_tmp[i][1]
			pt2 = dots2d3d_tmp[i+1][1]
			rect_pts = rect_pts + [ (pt1[0],pt1[1],pt1[2]), (pt2[0],pt2[1],pt2[2]) ]

		# sideline
		if len(dots2d3d_tmp) >= 2:
			pt1 = dots2d3d_tmp[-2][1]
			pt2 = dots2d3d_tmp[-1][1]
			pt_dir = (pt2-pt1).normalized()
			pt_cross = plane_z.cross(pt_dir)*STAMP_C.grid_plane_zinv
			pt1 = pt_co
			pt2 = pt_co + pt_cross*tool_dst*0.85
			rect_pts = rect_pts + [ (pt1[0],pt1[1],pt1[2]), (pt2[0],pt2[1],pt2[2]) ]

		batch = batch_for_shader(self.shader_3du, 'LINES', {"pos": rect_pts})
		self.shader_3du.bind()
		self.shader_3du.uniform_float("color", kWPL_STP_LINE_COLOR)
		batch.draw(self.shader_3du)

	# point under cursor - circle with brush radius
	bgl.glLineWidth(kWPL_STP_SNAPDOT_SIZEPX)
	tool_pts = []
	for i in range(0, kWPL_STP_CIRCLE_VERTS):
		ang1 = math.pi*2.0*float(i-1)/kWPL_STP_CIRCLE_VERTS
		ang2 = math.pi*2.0*float(i)/kWPL_STP_CIRCLE_VERTS
		pt1 = pt_co + plane_x*math.cos(ang1)*tool_dst + plane_y*math.sin(ang1)*tool_dst
		pt2 = pt_co + plane_x*math.cos(ang2)*tool_dst + plane_y*math.sin(ang2)*tool_dst
		tool_pts = tool_pts + [ (pt1[0],pt1[1],pt1[2]), (pt2[0],pt2[1],pt2[2]) ]
	batch = batch_for_shader(self.shader_3du, 'LINES', {"pos": tool_pts})
	self.shader_3du.bind()
	self.shader_3du.uniform_float("color", kWPL_STP_SNAPDOT_COLOR)
	batch.draw(self.shader_3du)

	bgl.glDisable(bgl.GL_BLEND)

# ================================

class wplstampp_modalflow(bpy.types.Operator):
	bl_idname = "mesh.wplstampp_modalflow"
	bl_label = "Paint stamps on grid"
	bl_options = {'REGISTER', 'UNDO'}

	opt_action : EnumProperty(
		items = [
			('NONE', "None", ""),
			('START', "Start", ""),
			('STOP', "Stop", "")
		],
		name="Action",
		default='NONE',
	)
	opt_preset :  StringProperty(
		name = "Preset",
		default = ""
	)

	def setupPredefines(self, context, preset_json):
		# tool_predefines - also from Custom Props of StampP stamps, names are FROZEN
		wpl_stamppOpts = context.scene.wpl_stamppOpts
		tool_predefines = {}
		if len(preset_json) > 0:
			pd = json.loads(preset_json)
			tool_predefines.update(pd)
		if ('stamp' in tool_predefines):
			for lst_itm in WPL_STAMPPOPTS_stamplist_items(None, None):
				if tool_predefines['stamp'] in lst_itm[0]:
					wpl_stamppOpts.opt_toolstamp2 = lst_itm[0]
					break
		if ('stamp_flags' in tool_predefines) and (tool_predefines['stamp_flags'] == 1):
			stamp_drive_obj = wla.object_by_name(wpl_stamppOpts.opt_toolstamp)
			print("- stamp_drive_obj", stamp_drive_obj)
			if (stamp_drive_obj is not None) and (kWPLAutoSetupPffRnd_flags in stamp_drive_obj):
				rnd_flags = stamp_drive_obj[kWPLAutoSetupPffRnd_flags]
				stamp_opts = wla.strTokensMap(rnd_flags,1.0,True)
				tool_predefines.update(stamp_opts)
		if ('ovr_grd' in tool_predefines):
			wpl_stamppOpts.opt_curv_ovr_grd = str(tool_predefines['ovr_grd'])
		if ('flow_cuh' in tool_predefines):
			wpl_stamppOpts.opt_curv_flow_cuh = str(tool_predefines['flow_cuh'])
		if ('fg_cuh' in tool_predefines):
			wpl_stamppOpts.opt_curv_fg_cuh = str(tool_predefines['fg_cuh'])
		print("- preset/predefines:", tool_predefines, wpl_stamppOpts.opt_toolstamp)

	def invoke(self, context, event):
		wpl_stamppOpts = context.scene.wpl_stamppOpts
		active_obj = wla.active_object(['MESH'])
		if active_obj is None:
			self.report({'ERROR'}, "Select mesh object first")
			return {'FINISHED'}
		active_mesh = active_obj.data
		if self.opt_action != 'START':
			STAMP_C.isActive = 0
			return {'FINISHED'}
		# updating values from UI (may change after reloads, etc)
		wpl_stamppOpts.opt_toolmat = wpl_stamppOpts.opt_toolmat2
		wpl_stamppOpts.opt_toolstamp = wpl_stamppOpts.opt_toolstamp2
		# Calcualting oredefines
		self.setupPredefines(context, self.opt_preset)
		# Initializing tool
		STAMP_C.target_obj_name = active_obj.name
		STAMP_C.grid_center = active_obj.matrix_world @ Vector((0,0,0))
		if wpl_stamppOpts.opt_gridorigin == 'CURSOR_POS':
			STAMP_C.grid_center = wla.active_context_cursor()
		STAMP_C.last_mouse_pt_g = None
		STAMP_C.last_mouse_pt_time = None
		STAMP_C.last_added_dots = []
		STAMP_C.grid_plane_cache = None
		STAMP_C.undo_steps = []
		STAMP_C.isActive = 1
		STAMP_C.grid_plane_zpush = 0.0
		STAMP_C.grid_plane_zcnt = 0
		STAMP_C.target_obj_isEdit = wla.is_edit_mode()
		if (active_mesh.vertex_colors.get(config.kWPLMeshColVC) is None):
			wla_do.select_and_change_mode(active_obj, 'OBJECT')
			wla_attr.vc_obj_ensure(active_obj, config.kWPLMeshColVC)
		if (active_mesh.attributes.get(kWPL_ATTR_OPT1) is None):
			wla_do.select_and_change_mode(active_obj, 'OBJECT')
			wla_attr.attr3fc_obj_ensure(active_obj, kWPL_ATTR_OPT1)
			wla_attr.attr3fc_obj_ensure(active_obj, kWPL_ATTR_OPT2)
			wla_attr.attr3v_obj_ensure(active_obj, kWPL_ATTR_DIRO) #wla_attr.attr3fc_obj_ensure(active_obj, kWPL_ATTR_DIRO)
			wla_attr.attr3fc_obj_ensure(active_obj, kWPL_ATTR_DIRS)
			wla_attr.attr3fc_obj_ensure(active_obj, kWPL_ATTR_DIRE)
		if wla.is_edit_mode() == False:
			wla_do.select_and_change_mode(active_obj,'EDIT')
		context.tool_settings.mesh_select_mode = (False, False, True) # 'FACE'
		self.shader_3du = gpu.shader.from_builtin('3D_UNIFORM_COLOR')
		self.shader_3du_flat = gpu.shader.from_builtin('3D_FLAT_COLOR')
		self.ob = context.object
		self.gp = self.ob.data
		self.refresh_trigger = {'MOUSEMOVE'}
		args = (self, context)
		self.current_area = context.area
		self._handle = bpy.types.SpaceView3D.draw_handler_add(stampp_draw_callback2_px, args, 'WINDOW', 'POST_VIEW')
		context.window_manager.modal_handler_add(self)
		return {'RUNNING_MODAL'}

	def exit(self, context):
		print("- StampP: finished")
		active_obj = wla.object_by_name(STAMP_C.target_obj_name)
		if active_obj is not None:
			if STAMP_C.target_obj_isEdit != True:
				wla_do.select_and_change_mode(active_obj, 'OBJECT')
		STAMP_C.isActive = 0
		if self._handle is not None:
			bpy.context.window.cursor_set("DEFAULT")
			bpy.types.SpaceView3D.draw_handler_remove(self._handle, 'WINDOW')
			self._handle = None
			context.area.header_text_set(None)
			context.area.tag_redraw()

	def modal(self, context, event):
		#print("- modal event", event.type, event.ctrl, event.alt, event.shift, event.oskey)
		wpl_stamppOpts = context.scene.wpl_stamppOpts
		if STAMP_C.isActive == 0 or wla.is_edit_mode() == False:
			self.exit(context)
			return {'FINISHED'}
		# if event.type in {'ONE', 'TWO', 'THREE'}:
		# 	if event.type == 'ONE':
		# 		context.tool_settings.mesh_select_mode = (True, False, False) # 'VERT'
		# 	if event.type == 'TWO':
		# 		context.tool_settings.mesh_select_mode = (False, True, False) # 'EDGE'
		# 	if event.type == 'THREE':
		# 		context.tool_settings.mesh_select_mode = (False, False, True) # 'FACE'
		# 	# EDIT-mode selection switching, quiting... unfortunately string editing (cuh) also triggers
		# 	self.exit(context)
		# 	return {'FINISHED'}
		if event.type in {'C', 'B'}:
			# EDIT-mode lasso selection, quiting...
			STAMP_C.target_obj_isEdit = True # Explicitly, even for OBJECT-mode case (at the start)
			self.exit(context)
			return {'PASS_THROUGH'}
		if event.type in {'SPACE', 'RET', 'ESC'}:
			context.area.tag_redraw()
			if event.value == 'PRESS':
				if len(STAMP_C.last_added_dots) > 0:
					if event.type in ('SPACE', 'RET'):
						self.onToolPointAdded(context, True)
					# resetting current line/etc anyway (for all cases)
					STAMP_C.last_added_dots = []
					return {'RUNNING_MODAL'}
				self.exit(context)
				return {'FINISHED'}
			return {'RUNNING_MODAL'}
		default_result = {'PASS_THROUGH'}
		if event.type == 'Z' and (event.ctrl or event.oskey):
			if event.value == 'PRESS':
				print("- StampP: Undo last step")
				if len(STAMP_C.undo_steps) > 0:
					facesIdx = STAMP_C.undo_steps.pop()
					self.delMeshFaces(facesIdx)
			return {'RUNNING_MODAL'}
		if bpy.context.area is None:
			return {"PASS_THROUGH"}
		if wla.sys_ismouse_in_view3d_window(event):
			bpy.context.window.cursor_set("PAINT_BRUSH")
		else:
			bpy.context.window.cursor_set("DEFAULT")
			return {"PASS_THROUGH"}
		if event.type == 'RIGHT_BRACKET':
			default_result = {'RUNNING_MODAL'}
			if event.value == 'PRESS':
				wpl_stamppOpts.opt_tool_bsize = wpl_stamppOpts.opt_tool_bsize+wpl_stamppOpts.opt_tool_bstep
				context.area.tag_redraw()
		if event.type == 'LEFT_BRACKET':
			default_result = {'RUNNING_MODAL'}
			if event.value == 'PRESS':
				wpl_stamppOpts.opt_tool_bsize = wpl_stamppOpts.opt_tool_bsize-wpl_stamppOpts.opt_tool_bstep
				wpl_stamppOpts.opt_tool_bsize = max(wpl_stamppOpts.opt_tool_bsize, wpl_stamppOpts.opt_tool_bstep)
				context.area.tag_redraw()
		if event.type == 'RIGHTMOUSE':
			if event.value == 'RELEASE':
				if len(STAMP_C.last_added_dots) == 0:
					# color picker
					pickColor = region_2d_view_pixel(context, (event.mouse_region_x, event.mouse_region_y), (event.mouse_prev_x, event.mouse_prev_y) )
					if pickColor is not None:
						print("- color picker", pickColor, (event.mouse_region_x, event.mouse_region_y), (event.mouse_prev_x, event.mouse_prev_y))
						wpl_vcOpts = context.scene.wpl_vcOpts
						wpl_vcOpts.bake_vc_col = (pickColor[0], pickColor[1], pickColor[2])
						context.area.tag_redraw()
				if len(STAMP_C.last_added_dots) > 0:
					# finishing active line
					self.onToolPointAdded(context, True)
			return {'RUNNING_MODAL'}
		if event.type == 'I':
			if event.value == 'PRESS':
				STAMP_C.grid_plane_zinv = -1 * STAMP_C.grid_plane_zinv
				context.area.tag_redraw()
			return {'RUNNING_MODAL'}
		context.area.tag_redraw()
		context.area.header_text_set('StampPainter | Tool Size: ['+f'{wpl_stamppOpts.opt_tool_bsize:.2f}'+'] | Material: ['+wpl_stamppOpts.opt_toolmat+'] | Hotkeys: [ ] I')
		if event.type in self.refresh_trigger:
			mouse = Vector((event.mouse_region_x, event.mouse_region_y))
			hit_3d = region_2d_to_scene_pt(context, mouse)
			STAMP_C.last_mouse_pt_g = hit_3d
		if event.type == 'LEFTMOUSE':
			if event.value == 'PRESS' and STAMP_C.last_mouse_pt_g is not None: # NOT 'RELEASE'... Line starts where clicked
				_, pt_2d_local = scene_pt_to_plane_pt(context, STAMP_C.last_mouse_pt_g)
				# fast doubleclick - end line
				# Can`t reply on coords - free, non-snapped positions
				timediff = -1.0
				isDoubleClick = False
				if STAMP_C.last_mouse_pt_time is not None:
					timediff = time.time()-STAMP_C.last_mouse_pt_time
					if timediff < 0.25:
						isDoubleClick = True
				if isDoubleClick == False:
					STAMP_C.last_mouse_pt_time = time.time()
					self.addToolPoint(context, pt_2d_local )
					print("- adding point", pt_2d_local, len(STAMP_C.last_added_dots), "timediff", timediff)
					self.onToolPointAdded(context, False)
				else:
					print("- skipping point, same.", "timediff", timediff)
					self.onToolPointAdded(context, True)
			return {'RUNNING_MODAL'}
		return default_result

	def addToolPoint(self, context, pt2d):
		pt3d = plane_pt_to_scene_pt(context, pt2d)
		STAMP_C.last_added_dots.append( (pt2d, pt3d) )
		return pt3d

	def delMeshFaces(self, facesIdx):
		active_obj = wla.object_by_name(STAMP_C.target_obj_name)
		if active_obj is None:
			return
		bm = bmesh.from_edit_mesh(active_obj.data)
		bm.verts.ensure_lookup_table()
		bm.faces.ensure_lookup_table()
		if len(facesIdx)>0:
			faces2del = []
			for fIdx in facesIdx:
				f = bm.faces[fIdx]
				faces2del.append(f)
			bmesh.ops.delete(bm, geom=faces2del, context='FACES')
			bm.normal_update()
			bmesh.update_edit_mesh(active_obj.data)
			bm.faces.index_update()
			bm.faces.ensure_lookup_table()
			print("- removed faces",len(faces2del))

	def addMeshFace(self, context, bm, fac, verts_co, isLeft, curve_cache):
		wpl_stamppOpts = context.scene.wpl_stamppOpts
		mw = curve_cache["mw"]
		mw_inv = curve_cache["mw_inv"]
		plane_z = curve_cache["plane_z"]
		opacityFac = curve_cache["opacityFac"]
		facFlowOvl = stamp_get_cuh4curve(wpl_stamppOpts.opt_curv_flow_cuh, fac, None, curve_cache, isLeft)
		facFlowGrd = facFlowOvl # same! no cases for different curves at the SAME time
		facFgMix = stamp_get_cuh4curve(wpl_stamppOpts.opt_curv_fg_cuh, fac, 0.0, curve_cache, isLeft)
		facOvrGrdMix = stamp_get_cuh4curve(wpl_stamppOpts.opt_curv_ovr_grd, fac, 0.0, curve_cache, isLeft)
		ptZ_g = wla.math_lerpCurveGet(facFlowOvl, 0, curve_cache) # properly lerped ptZ_g
		ptS_g = curve_cache["ptS_g"]
		ptE_g = curve_cache["ptE_g"]
		#print("- add face", verts_co)
		opt1_map = None
		opt2_map = None
		dirO_map = None
		dirS_map = None
		dirE_map = None
		if kWPL_ATTR_OPT1 in curve_cache:
			opt1_map = curve_cache[kWPL_ATTR_OPT1]
			opt2_map = curve_cache[kWPL_ATTR_OPT2]
			dirO_map = curve_cache[kWPL_ATTR_DIRO]
			dirS_map = curve_cache[kWPL_ATTR_DIRS]
			dirE_map = curve_cache[kWPL_ATTR_DIRE]
		verts = []
		for pt_g_co in verts_co:
			pt_k = wla.coToKey(pt_g_co)+str(isLeft)
			pt_v = None
			if pt_k in curve_cache:
				pt_v = curve_cache[pt_k]
			else:
				pt_g_co2 = pt_g_co + plane_z * STAMP_C.grid_plane_zpush
				pt_l = mw_inv @ pt_g_co2
				pt_v = bm.verts.new(pt_l)
				curve_cache[pt_k] = pt_v
			if pt_v not in verts:
				verts.append(pt_v)
		if len(verts)<3:
			print("- can`t create face: verts too close", verts)
			return None
		new_f = bm.faces.new(verts)
		faceMatIdx = curve_cache["faceMatIdx"]
		if faceMatIdx >= 0:
			new_f.material_index = faceMatIdx
		# bm.verts.ensure_lookup_table()
		# bm.verts.index_update()
		# bm.faces.ensure_lookup_table()
		# bm.faces.index_update()
		if "decorc_map" in curve_cache:
			decorc_col = curve_cache["decorc_col"]
			decorc_map = curve_cache["decorc_map"]
			for loop in new_f.loops:
				vert = loop.vert
				loop[decorc_map] = decorc_col
				if (opt1_map is not None) and (opt2_map is not None) and (dirS_map is not None) and (dirE_map is not None):
					v_co_g = mw @ vert.co
					vOpacity = opacityFac
					if ("valpha" in curve_cache) and len(curve_cache["valpha"])>0:
						idx = verts.index(vert)
						vOpacity = vOpacity * curve_cache["valpha"][idx]
					#print("- vert alpha", idx, vOpacity, curve_cache["valpha"])
					loop[opt1_map] = Vector(( vOpacity, facFgMix, facOvrGrdMix ))
					loop[opt2_map] = Vector(( facFlowGrd, fac, fac ))
					loop[dirS_map] = ptS_g-v_co_g
					loop[dirE_map] = ptE_g-v_co_g
					# if ("poked-center" in curve_cache) and (curve_cache["poked-center"] == True):
					# 	loop[dirO_map] = (999.0,999.0,999.0) # kWPL_ATTR_DIRO per loop
					# else:
					# 	loop[dirO_map] = ptZ_g-v_co_g # kWPL_ATTR_DIRO per loop
			if dirO_map is not None:
				for vert in new_f.verts:
					v_co_g = mw @ vert.co
					if ("poked-center" in curve_cache) and (curve_cache["poked-center"] == True):
						vert[dirO_map] = (999.0,999.0,999.0) # kWPL_ATTR_DIRO per vert
					else:
						if "pervert_dirO_map" not in curve_cache:
							curve_cache["pervert_dirO_map"] = {}
						if vert not in curve_cache["pervert_dirO_map"]:
							curve_cache["pervert_dirO_map"][vert] = [0.0, Vector((0.0,0.0,0.0))]
						o_val = ptZ_g-v_co_g
						o_val_other = curve_cache["pervert_dirO_map"][vert]
						o_val_other[0] = o_val_other[0]+1.0
						o_val_other[1] = o_val_other[1]+o_val
						#curve_cache["pervert_dirO_map"][vert] = o_val_other
						o_val = o_val_other[1]/o_val_other[0]
						vert[dirO_map] = o_val # kWPL_ATTR_DIRO per vert
		return new_f

	def onToolPointAdded(self, context, isFinal):
		if len(STAMP_C.last_added_dots) == 0:
			return
		active_obj = wla.object_by_name(STAMP_C.target_obj_name)
		if active_obj is None or active_obj.type != 'MESH':
			print("- invalid target object", STAMP_C.target_obj_name)
			return
		if isFinal == False:
			return
		wpl_stamppOpts = context.scene.wpl_stamppOpts
		if ("<view-cut>" in wpl_stamppOpts.opt_toolstamp):
			print("- view: deleting insides...")
			self.finalizeWithViewCut(context, "<view-cut>")
			return
		if ("<view-sep>" in wpl_stamppOpts.opt_toolstamp):
			print("- view: extracting insides...")
			self.finalizeWithViewCut(context, "<view-sep>")
			return
		if ("<stripe>" in wpl_stamppOpts.opt_toolstamp) or len(wpl_stamppOpts.opt_toolstamp) == 0:
			print("- building stripe...")
			self.finalizeWithStamp(context, None)
			return
		stamp_drive_obj = wla.object_by_name(wpl_stamppOpts.opt_toolstamp)
		if stamp_drive_obj is None:
			print("- invalid stamp object", wpl_stamppOpts.opt_toolstamp, stamp_drive_obj)
			return
		print("- building stamps...", stamp_drive_obj.name)
		self.finalizeWithStamp(context, stamp_drive_obj)
		return

	def finalizeWithViewCut(self, context, mode):
		pts = []
		for i in range(0, len(STAMP_C.last_added_dots)):
			pt_g = STAMP_C.last_added_dots[i][1]
			pts.append([pt_g[0], pt_g[1], pt_g[2]])
		if len(pts) < 3:
			print("- skipped, no points", len(pts))
			return
		pts_json = json.dumps([pts])
		active_obj = wla.object_by_name(STAMP_C.target_obj_name)
		#wla_do.select_and_change_mode(active_obj, 'OBJECT')
		self.exit(context)
		if mode == "<view-cut>":
			bpy.ops.mesh.wplcamcut_flow_annot(opt_action = 'FINISHDELINS', opt_pointsJson = pts_json)
		if mode == "<view-sep>":
			bpy.ops.mesh.wplcamcut_flow_annot(opt_action = 'FINISHEXTR_NRM', opt_pointsJson = pts_json)

	def finalizeWithStamp(self, context, stamp_drive_obj):
		active_obj = wla.object_by_name(STAMP_C.target_obj_name)
		wpl_stamppOpts = context.scene.wpl_stamppOpts
		opt_curv_size = wpl_stamppOpts.opt_curv_size
		opt_curv_opacity = wpl_stamppOpts.opt_curv_opacity
		stripe_leftFaces = True
		stripe_rightFaces = True
		if ('R' in opt_curv_size) or ('0|' in opt_curv_size):
			# right only
			stripe_leftFaces = False
			opt_curv_size = opt_curv_size.replace('R','')
			opt_curv_size = opt_curv_size.replace('0|','')
		if ('L' in opt_curv_size) or ('|0' in opt_curv_size):
			# left only
			stripe_rightFaces = False
			opt_curv_size = opt_curv_size.replace('L','')
			opt_curv_size = opt_curv_size.replace('|0','')
		stripe_leftNoOpacity = False
		stripe_rightNoOpacity = False
		if ('R' in opt_curv_opacity) or ('0|' in opt_curv_opacity):
			stripe_rightNoOpacity = True
			opt_curv_opacity = opt_curv_opacity.replace('R','')
			opt_curv_opacity = opt_curv_opacity.replace('0|','')
		if ('L' in opt_curv_opacity) or ('|0' in opt_curv_opacity):
			stripe_leftNoOpacity = True
			opt_curv_opacity = opt_curv_opacity.replace('L','')
			opt_curv_opacity = opt_curv_opacity.replace('|0','')
		list_of_stamp_obj = []
		if stamp_drive_obj is not None:
			if stamp_drive_obj.type == 'EMPTY':
				for child in stamp_drive_obj.children:
					if child.type == 'MESH':
						list_of_stamp_obj.append(child)
			if stamp_drive_obj.type == 'MESH':
				# drive is the stamp itself
				list_of_stamp_obj.append(stamp_drive_obj)
		STAMP_C.grid_plane_zpush = STAMP_C.grid_plane_zpush + kWPL_STP_ZPUSH_STEP
		faceMatIdx = -1
		mt_name = wla_attr.mat_find_any(wpl_stamppOpts.opt_toolmat)
		if (mt_name is not None):
			for idx, mt in enumerate(active_obj.material_slots):
				if mt.name == mt_name:
					faceMatIdx = idx
					break
		mw = active_obj.matrix_world
		mw_inv = mw.inverted()
		bm = bmesh.from_edit_mesh(active_obj.data)
		bm.verts.ensure_lookup_table()
		bm.faces.ensure_lookup_table()
		rnd_offsetRel_py = None
		rnd_offsetAbs_py = None
		rnd_spin_py = None
		rnd_scale_py = None
		rnd_flow_py  = None
		rnd_flags = ""
		if stamp_drive_obj is not None:
			try:
				if kWPLAutoSetupPffRnd_flags in stamp_drive_obj:
					rnd_flags = stamp_drive_obj[kWPLAutoSetupPffRnd_flags]
				rnd_offsetRel = kWPLAutoSetupPffRnd_offsetDefl
				if kWPLAutoSetupPffRnd_offsetRel in stamp_drive_obj:
					rnd_offsetRel = stamp_drive_obj[kWPLAutoSetupPffRnd_offsetRel]
				rnd_offsetAbs = kWPLAutoSetupPffRnd_offsetDefl
				if kWPLAutoSetupPffRnd_offsetAbs in stamp_drive_obj:
					rnd_offsetAbs = stamp_drive_obj[kWPLAutoSetupPffRnd_offsetAbs]
				rnd_spin = kWPLAutoSetupPffRnd_spinDefl
				if kWPLAutoSetupPffRnd_spin in stamp_drive_obj:
					rnd_spin = stamp_drive_obj[kWPLAutoSetupPffRnd_spin]
				rnd_scale = kWPLAutoSetupPffRnd_scaleDefl
				if kWPLAutoSetupPffRnd_scale in stamp_drive_obj:
					rnd_scale = stamp_drive_obj[kWPLAutoSetupPffRnd_scale]
				rnd_flow  = kWPLAutoSetupPffRnd_flowDefl
				if kWPLAutoSetupPffRnd_flow in stamp_drive_obj:
					rnd_flow = stamp_drive_obj[kWPLAutoSetupPffRnd_flow]
				rnd_offsetRel_py = compile(rnd_offsetRel, "<string>", "eval")
				rnd_offsetAbs_py = compile(rnd_offsetAbs, "<string>", "eval")
				rnd_spin_py = compile(rnd_spin, "<string>", "eval")
				rnd_scale_py = compile(rnd_scale, "<string>", "eval")
				rnd_flow_py = compile(rnd_flow, "<string>", "eval")
			except Exception as e:
				print("- stamp: failed to evaluate custom prop", e)
		# adding point to curvecache for resampling
		curve_cache = {}
		curve_cache["mw"] = mw
		curve_cache["mw_inv"] = mw_inv
		curve_cache["faceMatIdx"] = faceMatIdx
		decorc_col = None
		if bm.loops.layers.color.get(config.kWPLMeshColVC) is not None:
			wpl_vcOpts = context.scene.wpl_vcOpts
			decorc_col = (wpl_vcOpts.bake_vc_col[0], wpl_vcOpts.bake_vc_col[1], wpl_vcOpts.bake_vc_col[2], 1)
			curve_cache["decorc_map"] = bm.loops.layers.color.get(config.kWPLMeshColVC)
			curve_cache["decorc_col"] = decorc_col
			if Vector( (decorc_col[0],decorc_col[1],decorc_col[2]) ).length < 0.001:
				# full black
				decorc_col = None
		if bm.loops.layers.float_vector.get(kWPL_ATTR_OPT1) is not None: #  bm.verts.layers.float_vector.get(kWPL_ATTR_OPT1)
			curve_cache[kWPL_ATTR_OPT1] = bm.loops.layers.float_vector.get(kWPL_ATTR_OPT1)
			curve_cache[kWPL_ATTR_OPT2] = bm.loops.layers.float_vector.get(kWPL_ATTR_OPT2)
			curve_cache[kWPL_ATTR_DIRO] = bm.verts.layers.float_vector.get(kWPL_ATTR_DIRO)# bm.loops.layers.float_vector.get(kWPL_ATTR_DIRO)
			curve_cache[kWPL_ATTR_DIRS] = bm.loops.layers.float_vector.get(kWPL_ATTR_DIRS)
			curve_cache[kWPL_ATTR_DIRE] = bm.loops.layers.float_vector.get(kWPL_ATTR_DIRE)
		curve_len = 0.0
		curve_origpts = []
		for i in range(0, len(STAMP_C.last_added_dots)):
			pt_g = STAMP_C.last_added_dots[i][1]
			curve_len = wla.math_lerpCurveAdd(pt_g, [pt_g], curve_cache)
			curve_origpts.append(curve_len)
		curve_cache["curve_len"] = curve_len
		curve_cache["tool_bsize"] = wpl_stamppOpts.opt_tool_bsize
		pts_mixfac = 0.5
		pts_facLine = []
		if ("poked-center" in rnd_flags):
			curve_cache["poked-center"] = True
		if ("no-resample" in rnd_flags):
			pts_mixfac = 1.0
			pts_facLine = []
			pts_facLine.append(0) # duplicating first element
			if curve_len > 0.0:
				for i in range(0, len(curve_origpts)):
					fac = curve_origpts[i]/curve_len
					pts_facLine.append(fac)
			else:
				pts_facLine.append(0)
		elif curve_len > 0.0:
			pts_mixfac = 0.5
			dens_resamp = wpl_stamppOpts.opt_tool_bsize
			if dens_resamp > 0.0001:
				# defaulting to brush size
				dens_resamp = wpl_stamppOpts.opt_tool_bsize*wpl_stamppOpts.opt_tooldens_resamp
			else:
				dens_resamp = max(abs(dens_resamp), wpl_stamppOpts.opt_tool_bstep*0.1)
			if wpl_stamppOpts.opt_tooldens_scale > 0.0001:
				dens_resamp = dens_resamp/wpl_stamppOpts.opt_tooldens_scale
			pts = int(curve_len/dens_resamp)
			if pts < 3:
				# need at least 3
				# or curveHash with zeros on both ends will give NO FACES
				dens_resamp = curve_len/3.0
				pts = int(curve_len/dens_resamp)
			pts_facLine = []
			if curve_len >= dens_resamp:
				for i in range(0, pts):
					fac = float(i)/float(pts-1)
					pts_facLine.append(fac)
		if len(pts_facLine) == 0:
			print("- invalid line: no points")
			STAMP_C.last_added_dots = []
			return
		# building mesh for current line
		added_faces = []
		_, plane_x, _, plane_z = get_draw_plane(context, None)
		curve_cache["plane_z"] = plane_z
		dir_z = plane_z
		ptS_g = STAMP_C.last_added_dots[0][1]
		ptE_g = STAMP_C.last_added_dots[-1][1]
		pt0_last = None
		for i in range(1, len(pts_facLine)):
			fac0 = pts_facLine[i-1]
			fac1 = pts_facLine[i]
			pt0_g = wla.math_lerpCurveGet(fac0, 0, curve_cache)
			pt1_g = wla.math_lerpCurveGet(fac1, 0, curve_cache)
			fac2 = None
			pt2_g = None
			if i < len(pts_facLine)-1:
				fac2 = pts_facLine[i+1]
				pt2_g = wla.math_lerpCurveGet(fac2, 0, curve_cache)
			fac = wla.math_lerp1D(pts_mixfac, fac0, fac1)
			ptZ_g = pt0_g.lerp(pt1_g, pts_mixfac)
			ptZ_l = mw_inv @ ptZ_g
			dir_x = (pt1_g-pt0_g)
			if dir_x.length > 0.0:
				dir_x = dir_x.normalized()
			else:
				dir_x = plane_x
			dir_y = dir_z.cross(dir_x).normalized()*STAMP_C.grid_plane_zinv
			facLen0 = wla.remap_curve_hash(opt_curv_size, fac0)
			facLen1 = wla.remap_curve_hash(opt_curv_size, fac1)
			opacityFac = wla.remap_curve_hash(opt_curv_opacity, fac)
			curve_cache["opacityFac"] = opacityFac
			sizeLen0 = facLen0*wpl_stamppOpts.opt_tool_bsize
			sizeLen1 = facLen1*wpl_stamppOpts.opt_tool_bsize
			curve_cache["ptS_g"] = ptS_g
			curve_cache["ptE_g"] = ptE_g
			if (stamp_drive_obj is None) or len(list_of_stamp_obj) == 0:
				pt1uL_g = wla.math_vecOffsetClipped(pt1_g, dir_y*sizeLen1, pt0_g, pt2_g)
				pt1uR_g = wla.math_vecOffsetClipped(pt1_g, -1 * dir_y*sizeLen1, pt0_g, pt2_g)
				if pt0_last is None:
					pt0uL_g = pt0_g + dir_y*sizeLen0
					pt0uR_g = pt0_g - dir_y*sizeLen0
				else:
					pt0uL_g = pt0_last[0]
					pt0uR_g = pt0_last[1]
				pt0_last = (pt1uL_g, pt1uR_g)
				if stripe_leftFaces:
					curve_cache["valpha"] = []
					if stripe_leftNoOpacity:
						curve_cache["valpha"] = [1.0,1.0,0.0,0.0]
					f = self.addMeshFace(context, bm, fac, (pt0_g, pt1_g, pt1uL_g, pt0uL_g), True, curve_cache)
					added_faces.append(f)
				if stripe_rightFaces:
					curve_cache["valpha"] = []
					if stripe_rightNoOpacity:
						curve_cache["valpha"] = [0.0,0.0,1.0,1.0]
					f = self.addMeshFace(context, bm, fac, (pt0uR_g, pt1uR_g, pt1_g, pt0_g), False, curve_cache) # reverse order
					added_faces.append(f)
				continue
			stamp_obj = random.choice(list_of_stamp_obj)
			stamp_vc_decorc = stamp_obj.data.vertex_colors.get(config.kWPLMeshColVC)
			stamp_vc_wri = stamp_obj.data.vertex_colors.get(config.kWPLMeshWriVC)
			stamp_max_dim = 0.0
			for vert in stamp_obj.data.vertices:
				stamp_max_dim = max(stamp_max_dim, vert.co.length)
			# copy faces from stamp object and randomization
			facI = fac # 4EVAL
			sizeFac = (facLen0+facLen1)*0.5 # 4EVAL
			alphaFac = opacityFac # 4EVAL
			sizeI = (sizeLen0+sizeLen1)*0.5 # 4EVAL
			spinI = math.degrees(math.atan2(dir_x[1],dir_x[0])) # 4EVAL
			brushSize = wpl_stamppOpts.opt_tool_bsize # 4EVAL
			brushStep = wpl_stamppOpts.opt_tool_bstep # 4EVAL
			brushCnt = STAMP_C.grid_plane_zcnt # 4EVAL
			tmpRndA = random.uniform(0.0, 1.0) # 4EVAL
			tmpRndB = random.uniform(0.0, 1.0) # 4EVAL
			tmpRndC = random.uniform(0.0, 1.0) # 4EVAL
			tmpRndD = random.uniform(0.0, 1.0) # 4EVAL
			STAMP_C.grid_plane_zcnt = STAMP_C.grid_plane_zcnt+1
			rnd_offsetRel_val = (0.0, 0.0, 0.0)
			rnd_offsetAbs_val = (0.0, 0.0, 0.0)
			rnd_spin_val = (0.0, 0.0, spinI)
			rnd_scale_val = (1.0, 1.0, 1.0, 1.0)
			rnd_flow_val = (1.0, 0.0)
			if rnd_offsetRel_py is not None:
				rnd_offsetRel_val = eval(rnd_offsetRel_py)
				#print("- rnd_offsetRel_val", rnd_offsetRel_val)
			if rnd_offsetAbs_py is not None:
				rnd_offsetAbs_val = eval(rnd_offsetAbs_py)
				#print("- rnd_offsetAbs_val", rnd_offsetAbs_val)
			if rnd_spin_py is not None:
				rnd_spin_val = eval(rnd_spin_py)
				#print("- rnd_spin_val", rnd_spin_val)
			if rnd_scale_py is not None:
				rnd_scale_val = eval(rnd_scale_py)
				#print("- rnd_scale_val", rnd_scale_val)
			if rnd_flow_py is not None:
				rnd_flow_val = eval(rnd_flow_py)
				#print("- rnd_flow_val", rnd_flow_val)
			if random.uniform(0.01,0.99) > rnd_flow_val[0]:
				# stamp skipped
				continue
			rescale2brush = 1.0
			if stamp_max_dim > 0.0:
				rescale2brush = sizeI/stamp_max_dim
			isLeft = False
			if rnd_flow_val[1] > 0.0:
				isLeft = True
			if stripe_leftFaces == False and isLeft == True:
				# partial skip
				continue
			if stripe_rightFaces == False and isLeft == False:
				# partial skip
				continue
			for poly in stamp_obj.data.polygons:
				fverts = []
				curve_cache["valpha"] = []
				for vIdx in poly.vertices:
					sv = stamp_obj.data.vertices[vIdx]
					sv_co = sv.co
					sv_co = Vector( ( sv_co[0]*rnd_scale_val[0], sv_co[1]*rnd_scale_val[1]*STAMP_C.grid_plane_zinv, sv_co[2]*rnd_scale_val[2] ) )
					sv_co = sv_co * rescale2brush * rnd_scale_val[3]
					sv_co = Matrix.Rotation( math.radians(rnd_spin_val[2]), 4, dir_z ) @ sv_co
					sv_co = sv_co + Vector(rnd_offsetAbs_val)
					sv_co_g = mw @ (ptZ_l + sv_co)
					# dir_x/dir_y/dir_z are in GLOBAL space
					sv_co_g = sv_co_g + rnd_offsetRel_val[0]*dir_x + rnd_offsetRel_val[1]*dir_y + rnd_offsetRel_val[2]*dir_z
					fverts.append(sv_co_g)
					if stamp_vc_wri is not None:
						# Wri -> Alpha for vertex (per face/loop)
						valpha = 1.0
						for idx, lIdx in enumerate(poly.loop_indices):
							vIdx_loop = poly.vertices[idx]
							if vIdx_loop == vIdx:
								wri_col = stamp_vc_wri.data[lIdx].color
								valpha = 1.0-max(max(wri_col[0], wri_col[1]), wri_col[2])
						curve_cache["valpha"].append(valpha)
				if (decorc_col is None) and stamp_vc_decorc is not None:
					# getting decorC from stamp
					ipoly = poly.index
					for idx, lIdx in enumerate(poly.loop_indices):
						curve_cache["decorc_col"] = stamp_vc_decorc.data[lIdx].color
						break
				try:
					f = self.addMeshFace(context, bm, fac, fverts, isLeft, curve_cache)
					added_faces.append(f)
				except Exception as e:
					print("- stamp: failed to add face", e)
		bm.normal_update()
		bmesh.update_edit_mesh(active_obj.data)
		STAMP_C.last_added_dots = []
		bm.faces.index_update()
		bm.faces.ensure_lookup_table()
		undo_faces = []
		for f in added_faces:
			if f is None:
				continue
			undo_faces.append(f.index)
		STAMP_C.undo_steps.append(undo_faces)
		return

def doAutoSetupCustomProp(stamp_obj):
	if kWPLAutoSetupPffRnd_offsetRel not in stamp_obj:
		stamp_obj[kWPLAutoSetupPffRnd_offsetRel] = kWPLAutoSetupPffRnd_offsetDefl
	if kWPLAutoSetupPffRnd_offsetAbs not in stamp_obj:
		stamp_obj[kWPLAutoSetupPffRnd_offsetAbs] = kWPLAutoSetupPffRnd_offsetDefl
	if kWPLAutoSetupPffRnd_spin not in stamp_obj:
		stamp_obj[kWPLAutoSetupPffRnd_spin] = kWPLAutoSetupPffRnd_spinDefl
	if kWPLAutoSetupPffRnd_scale not in stamp_obj:
		stamp_obj[kWPLAutoSetupPffRnd_scale] = kWPLAutoSetupPffRnd_scaleDefl
	if kWPLAutoSetupPffRnd_flow not in stamp_obj:
		stamp_obj[kWPLAutoSetupPffRnd_flow] = kWPLAutoSetupPffRnd_flowDefl
	if kWPLAutoSetupPffRnd_flags not in stamp_obj:
		stamp_obj[kWPLAutoSetupPffRnd_flags] = kWPLAutoSetupPffRnd_flagsDefl
	return

# ==========================================
# ==========================================

def WPL_STAMPPOPTS_matlist_items(self, context):
	lst = []
	active_obj = wla.active_object()
	if active_obj is not None:
		for idx, mt in enumerate(active_obj.material_slots):
			if (mt is None) or (len(mt.name) == 0):
				continue
			lst.append((mt.name, mt.name, "tool material"))
			if idx >= kWPL_STP_MATLIST_MAXITEMS:
				break
	while len(lst)<kWPL_STP_MATLIST_MAXITEMS:
		lst.append(('...', '...', "tool material"))
	return lst
def WPL_STAMPPOPTS_matlist_update(self, context):
	wpl_stamppOpts = context.scene.wpl_stamppOpts
	wpl_stamppOpts.opt_toolmat = wpl_stamppOpts.opt_toolmat2
	print("- StampP: material updated", wpl_stamppOpts.opt_toolmat)

def WPL_STAMPPOPTS_stamplist_items(self, context):
	lst = []
	lst.append(("<stripe>", "<stripe>", "tool stamp"))
	stamps = wla.all_objects_by_name(config.kWPLObjStampToken)
	for obj in stamps:
		if (obj.parent is not None) and wla.isTokenInStr(config.kWPLObjStampToken, obj.parent.name):
			# only parent valid
			continue
		stamp_name = wla.strReplaceTokenInStr(config.kWPLObjStampToken, obj.name, "")
		lst.append((obj.name, stamp_name, "tool stamp"))
	lst.append(("<view-cut>", "<view-cut>", "tool stamp"))
	lst.append(("<view-sep>", "<view-sep>", "tool stamp"))
	return lst
def WPL_STAMPPOPTS_stamplist_update(self, context):
	wpl_stamppOpts = context.scene.wpl_stamppOpts
	wpl_stamppOpts.opt_toolstamp = wpl_stamppOpts.opt_toolstamp2
	print("- StampP: stamp object updated", wpl_stamppOpts.opt_toolstamp)

class WPL_STAMPPOPTS(bpy.types.PropertyGroup):
	opt_gridorient : EnumProperty(
		items = [
			('LOCAL_XY', "Local XY", ""),
			('LOCAL_XZ', "Local XZ", ""),
			('LOCAL_YZ', "Local YZ", ""),
			('CUR3D_XY', "Cursor XY", ""),
			('CUR3D_XZ', "Cursor XZ", ""),
			('CUR3D_YZ', "Cursor YZ", ""),
		],
		name="Grid Align",
		default='LOCAL_XY',
	)
	opt_gridorigin : EnumProperty(
		items = [
			('LOCAL_ZERO', "Local (0,0,0)", ""),
			('CURSOR_POS', "3D Cursor", ""),
		],
		name="Grid Origin",
		default='LOCAL_ZERO',
	)
	opt_tool_bsize : FloatProperty(
		name="Brush Size",
		default = 0.05 # PFF default
	)
	opt_tool_bstep : FloatProperty(
		name="Size Step",
		default = 0.01 # PFF default
	)
	opt_toolstamp: StringProperty(
		name="Stamp object",
		default = ""
	)
	opt_toolstamp2: EnumProperty(
		name="Stamp object",
		items = WPL_STAMPPOPTS_stamplist_items,
		update = WPL_STAMPPOPTS_stamplist_update
	)
	opt_toolmat: StringProperty(
		name="Tool material",
		default = ""
	)
	opt_toolmat2: EnumProperty(
		name="Tool material",
		items = WPL_STAMPPOPTS_matlist_items,
		update = WPL_STAMPPOPTS_matlist_update
	)
	opt_tooldens_resamp: FloatProperty(
		name="Density",
		min = -10.0, max = 10, default = 0.33 # Fraction of Brush Size, if<0 = abs distance
	)
	opt_tooldens_scale: FloatProperty(
		name="Density scale",
		min = 0.0, default = 1.0
	)

	opt_curv_size : StringProperty(
		name="Size",
		default = "16961",
		description = "CUH specials: [L] [R] 0|0"
	)
	opt_curv_opacity : StringProperty(
		name="Opacity",
		default = "999",
		description = "CUH specials: [L] [R] 0|0"
	)
	opt_curv_fg_cuh : StringProperty(
		name="FG mix",
		default = "111",
		description = "CUH specials: [|]"
	)
	opt_curv_ovr_grd: StringProperty(
		name="OVR-GRD",
		default = "111",
		description = "OVR=111, GRD=999, CUH specials: [|]"
	)
	opt_curv_flow_cuh: StringProperty(
		name="Flow Sampling",
		default = "159",
		description = "CUH specials: [|] [< << > >>]"
	)

def uilayout_stamppBox(col, context, forPFF):
	col.label(text = "StampP")
	wpl_stamppOpts = context.scene.wpl_stamppOpts
	wpl_vcOpts = context.scene.wpl_vcOpts
	row1 = col.row()
	row1.prop(wpl_stamppOpts, "opt_tool_bsize", text = "Brush size")
	row1.prop(wpl_stamppOpts, "opt_tool_bstep", text = "step")
	row1 = col.row()
	row1.prop(wpl_vcOpts, "bake_vc_col", text = "Color")
	row1 = col.row()
	row1.prop(wpl_stamppOpts, "opt_toolstamp2", text = "Stamp")
	row1.prop(wpl_stamppOpts, "opt_toolmat2", text = "Material")
	if STAMP_C.isActive > 0:
		col.prop(wpl_stamppOpts, "opt_curv_size")
		row1 = col.row()
		row1.prop(wpl_stamppOpts, "opt_curv_opacity")
		row1.prop(wpl_stamppOpts, "opt_curv_ovr_grd")
		row1 = col.row()
		row1.prop(wpl_stamppOpts, "opt_curv_flow_cuh")
		row1.prop(wpl_stamppOpts, "opt_curv_fg_cuh")
		row1 = col.row()
		row1.prop(wpl_stamppOpts, "opt_tooldens_resamp")
		row1.prop(wpl_stamppOpts, "opt_tooldens_scale")
		col.separator()
		op = col.operator("mesh.wplstampp_modalflow", text='StampP: Stop', icon = 'OUTLINER_OB_FORCE_FIELD')
		op.opt_action = 'STOP'
	else:
		col.prop(wpl_stamppOpts, "opt_gridorient", text = "Grid type")
		op = col.operator("mesh.wplstampp_modalflow", text='StampP: Start', icon = 'OUTLINER_OB_FORCE_FIELD')
		op.opt_action = 'START'
		op.opt_preset = ''
		if forPFF:
			row1 = col.row()
			op = row1.operator("mesh.wplstampp_modalflow", text='PEN/GRD')
			op.opt_action = 'START'
			op.opt_preset = kWPL_STP_PRESET_PEN
			op = row1.operator("mesh.wplstampp_modalflow", text='OVR')
			op.opt_action = 'START'
			op.opt_preset = kWPL_STP_PRESET_OVR
			op = row1.operator("mesh.wplstampp_modalflow", text='STAMP')
			op.opt_action = 'START'
			op.opt_preset = kWPL_STP_PRESET_MAT
		else:
			row1 = col.row()
			op = row1.operator("mesh.wplstampp_modalflow", text='View: Del Inside')
			op.opt_action = 'START'
			op.opt_preset = kWPL_STP_PRESET_CUTINSD
			op = row1.operator("mesh.wplstampp_modalflow", text='View: Extract')
			op.opt_action = 'START'
			op.opt_preset = kWPL_STP_PRESET_EXTRACT
			
		
# class WPL_PT_StamppPanel1(bpy.types.Panel):
# 	bl_idname = "WPL_PT_StamppPanel1"
# 	bl_label = "StampP"
# 	bl_space_type = 'VIEW_3D'
# 	bl_region_type = 'UI'
# 	bl_category = 'PFF'

# 	def draw(self, context):
# 		layout = self.layout
# 		col = layout.column()
# 		box1 = col.box()
# 		uilayout_stamppBox(box1, context)

# ==========================================
# ==========================================

classes = (
	WPL_STAMPPOPTS,
	#WPL_PT_StamppPanel1,

	wplstampp_modalflow,
)

def register():
	for cls in classes:
		bpy.utils.register_class(cls)
	bpy.types.Scene.wpl_stamppOpts = bpy.props.PointerProperty(type=WPL_STAMPPOPTS)

def unregister():
	for cls in reversed(classes):
		bpy.utils.unregister_class(cls)
	del bpy.types.Scene.wpl_stamppOpts

if __name__ == "__main__":
	register()