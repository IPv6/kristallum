import os, sys, time, datetime
import math, copy, string, random
import numpy as np
import bpy, bmesh, mathutils

import bpy.types
from mathutils import Vector, Matrix, Euler, Quaternion
from mathutils.bvhtree import BVHTree
from mathutils.kdtree import KDTree
from bpy_extras import view3d_utils
from bpy.props import *

from . import config
from .tools import wla
from .tools import wla_do
from .tools import wla_bm
from .tools import wla_meshfair
from .tools import wla_meshwrap
from .tools import wla_curve

# ==========================================

class wplsculpt_doosabin_smooth(bpy.types.Operator):
	bl_idname = "mesh.wplsculpt_doosabin_smooth"
	bl_label = "Doo-Sabin smooth"
	bl_options = {'REGISTER', 'UNDO'}

	opt_SmoothAmount : FloatProperty(
		name="Smooth Amount",
		min=-10, max=10,
		default=0.5
	)
	opt_IterationAmount : IntProperty(
		name="Iterations",
		min=0, max=1000,
		default=1, step=1
	)
	opt_PreserveVolS : FloatProperty(
		name="Keep Surface",
		default=0.0, min=-10, max=10
	)
	opt_PreserveVolN : FloatProperty(
		name="Keep Normal",
		default=0.0, min=-10, max=10
	)
	opt_FreezeBoundary : BoolProperty(
		name="Freeze boundary", default=True
	)
	opt_FreezeSeams : BoolProperty(
		name="Freeze seams", default=True
	)
	opt_postRemesh : IntProperty(
		name="Post-Relax edgenet (30)", default=0
	)
	def resetOpts(self):
		print("- operator parameters reset")
		self.opt_SmoothAmount = 0.5
		self.opt_IterationAmount = 1
		self.opt_PreserveVolN = 0
		self.opt_PreserveVolS = 0
		self.opt_FreezeBoundary = True
		self.opt_FreezeSeams = True
		self.opt_postRemesh = 0
		return

	def ds_smooth_mesh(self, bm, selverts, factor, preserveVol, vertsFreeze):
		def calc_median(*args):
			return sum(args, Vector()) / len(args)
		selected_vertices = [v for v in bm.verts if v.index in selverts]
		face_points = [None] * len(bm.faces)
		for vertex in selected_vertices:
			for face in vertex.link_faces:
				face_points[face.index] = face.calc_center_median()
		#Compute the "edge midpoints" of all edges connected to the selected vertices, indexed by their BMesh indexes.
		edge_midpoints = [None] * len(bm.edges)
		for vertex in selected_vertices:
			for edge in vertex.link_edges:
				if edge_midpoints[edge.index] == None:
					edge_midpoints[edge.index] = calc_median(edge.verts[0].co, edge.verts[1].co)
		#Go through each vertex and compute their smoothed position.
		total_sum = Vector()
		for vertex in selected_vertices:
			if vertex.index in vertsFreeze:
				continue
			total_sum.zero()
			for face in vertex.link_faces:
				total_sum += face_points[face.index]
			for edge in vertex.link_edges:
				total_sum += edge_midpoints[edge.index]
			ent_cnt = (len(vertex.link_faces) + len(vertex.link_edges))
			if ent_cnt == 0:
				continue
			new_co = total_sum / ent_cnt
			old_co = vertex.co.copy()
			vertex.co = vertex.co + factor*(new_co - vertex.co)
			if abs(preserveVol) > 0.001:
				diff = (vertex.co - old_co) # NOT .normalized()
				projectedDiff_on_normal = vertex.normal * vertex.normal.dot(diff)  # u(u dot v)  - projection of v on u
				vertex.co -= projectedDiff_on_normal * preserveVol
		return

	def execute( self, context ):
		active_obj = wla.active_object(['MESH'])
		if active_obj is None:
			self.report({'ERROR'}, "Select mesh object first")
			return {'CANCELLED'}
		active_mesh = active_obj.data
		wla_do.select_and_change_mode(active_obj,'EDIT')
		oldselectmode = list(context.tool_settings.mesh_select_mode)
		selvertsAll = wla.selected_vertsIdx(active_mesh)
		selfacesAll = wla.selected_facesIdx(active_mesh)
		if len(selvertsAll)<3:
			self.resetOpts()
			wla_do.select_and_change_mode(active_obj,'EDIT')
			self.report({'ERROR'}, "No verts (opts reset)")
			return {'FINISHED'}
		wla_do.select_and_change_mode(active_obj,'EDIT')
		bm = bmesh.from_edit_mesh(active_mesh)
		bm.faces.ensure_lookup_table()
		bm.faces.index_update()
		bm.verts.ensure_lookup_table()
		bm.verts.index_update()
		vertsFreeze = []
		bound_verts, seam_verts, _, _ = wla_bm.bm_vertsInitSeamBnd(bm, selvertsAll)
		for vIdx in selvertsAll:
			needFrees = False
			if self.opt_FreezeBoundary and (vIdx in bound_verts):
				needFrees = True
			if self.opt_FreezeSeams and (vIdx in seam_verts):
				needFrees = True
			if needFrees:
				vertsFreeze.append(vIdx)
		bvh_orig = None
		if abs(self.opt_PreserveVolS) > 0.001 or self.opt_postRemesh > 0:
			# creating BVH only from selected faces
			bvh_orig = wla_bm.bm_BVHFromFacesIdx(active_obj, bm, selfacesAll, False)
		okCnt = len(selvertsAll)
		if self.opt_IterationAmount > 0:
			for i in range(self.opt_IterationAmount):
				self.ds_smooth_mesh(bm, selvertsAll, self.opt_SmoothAmount, self.opt_PreserveVolN, vertsFreeze)
				#bpy.ops.mesh.vertices_smooth()
				if abs(self.opt_PreserveVolS) > 0.001 and (bvh_orig is not None):
					for vIdx in selvertsAll:
						v = bm.verts[vIdx]
						n_loc = None
						# first project
						#n_loc, n_normal, n_index, n_distance = bvh_orig.ray_cast(v.co, v.normal)
						#if n_loc is None:
						#	n_loc, n_normal, n_index, n_distance = bvh_orig.ray_cast(v.co, -1 * v.normal)
						if n_loc is None:
							# if nothing then shrinkwrap
							n_loc, n_normal, n_index, n_distance = bvh_orig.find_nearest(v.co)
						if n_loc is not None:
							v.co = v.co.lerp(n_loc, self.opt_PreserveVolS)
			bm.normal_update()
		wla_bm.bm_selectVertEdgesFaces(bm, selvertsAll, None)
		if self.opt_postRemesh > 0 and (bvh_orig is not None):
			# even for zero influence - with proper bound/seam freezers
			print("- relaxing edgenet")
			remesher = wla_meshfair.BoundaryAlignedRemesher(bm, selvertsAll, vertsFreeze, bvh_orig)
			remesher.remesh(self.opt_postRemesh, True)
			# if self.opt_influence > 0.0:
			# 	for vIdx in selvertsAll:
			# 		v = bm.verts[vIdx]
			# 		if vIdx in originalPos:
			# 			v.co = originalPos[vIdx].lerp(v.co, self.opt_influence)
			bm.normal_update()
		bmesh.update_edit_mesh(active_mesh)
		context.tool_settings.mesh_select_mode = oldselectmode
		self.report({'INFO'}, "Done, "+str(okCnt)+" verts moved")
		return {'FINISHED'}

class wplsculpt_pin_toconvex(bpy.types.Operator):
	bl_idname = "mesh.wplsculpt_pin_toconvex"
	bl_label = "Pin convex"
	bl_options = {'REGISTER', 'UNDO'}

	opt_convexMode : EnumProperty(
		name="Convex mode", default="ADD",
		items=(("ADD", "Add verts", ""), ("REPLACE", "Replace verts", ""))
	)
	opt_extendXMirr : BoolProperty(
		name="Extend: X-Mirror", default=False
	)
	opt_extendLocalX : BoolProperty(
		name="Extend: X-Dir", default=False
	)
	opt_extendLocalY : BoolProperty(
		name="Extend: Y-Dir", default=False
	)
	opt_extendLocalZ : BoolProperty(
		name="Extend: Z-Dir", default=False
	)
	def resetOpts(self):
		print("- operator parameters reset")
		if wla_bm.kWPL_PINCONVEXKey in config.WPL_G.store:
			print("- pinned verts cleared")
			del config.WPL_G.store[wla_bm.kWPL_PINCONVEXKey]
		self.opt_extendXMirr = False
		self.opt_extendLocalX = False
		self.opt_extendLocalY = False
		self.opt_extendLocalZ = False
		return

	def execute( self, context ):
		active_obj = wla.active_object(wla_meshwrap.kWPLMESHWRAP_TYPES)
		if active_obj is None:
			self.resetOpts()
			self.report({'ERROR'}, "Select mesh (opts reset)")
			return {'CANCELLED'}
		oldmode = wla_do.select_and_change_mode(active_obj,'OBJECT')
		# special case - objects with GN use FINAL mesh - generated verts also needed
		active_mesh = None
		active_mesh_needClear = False
		selvertsAll = []
		if wla.modf_by_type(active_obj, 'NODES') is not None:
			depsgraph = bpy.context.evaluated_depsgraph_get()
			obj_eval = active_obj.evaluated_get(depsgraph)
			# active_mesh = obj_eval.data # will be CURVE, not mesh
			active_mesh = bpy.data.meshes.new_from_object(obj_eval)
			active_mesh_needClear = True
			selvertsAll = [v.index for v in active_mesh.vertices]
			print("- GN detected, using final MESH for pinning", len(selvertsAll))
		else:
			active_mesh = wla_meshwrap.object_wrappedmesh(active_obj)
			selvertsAll = active_mesh.selected_vertsIdx()
			if len(selvertsAll) == 0:
				self.resetOpts()
				wla_do.select_and_change_mode(active_obj,oldmode)
				self.report({'ERROR'}, "No verts (opts reset)")
				return {'FINISHED'}
		last_used_co = []
		if self.opt_convexMode == 'ADD':
			if wla_bm.kWPL_PINCONVEXKey in config.WPL_G.store:
				last_used_co = config.WPL_G.store[wla_bm.kWPL_PINCONVEXKey]
		for vIdx in selvertsAll:
			v_co = active_mesh.vertices[vIdx].co
			v_co_g = active_obj.matrix_world @ v_co
			last_used_co.append(v_co_g)
			if self.opt_extendXMirr:
				v_co_xm = active_obj.matrix_world @ Vector((-1*v_co[0], v_co[1], v_co[2]))
				last_used_co.append(v_co_xm)
			if self.opt_extendLocalX:
				v_co_xm = active_obj.matrix_world @ Vector((v_co[0]+100, v_co[1], v_co[2]))
				last_used_co.append(v_co_xm)
				v_co_xm = active_obj.matrix_world @ Vector((v_co[0]-100, v_co[1], v_co[2]))
				last_used_co.append(v_co_xm)
			if self.opt_extendLocalY:
				v_co_xm = active_obj.matrix_world @ Vector((v_co[0], v_co[1]+100, v_co[2]))
				last_used_co.append(v_co_xm)
				v_co_xm = active_obj.matrix_world @ Vector((v_co[0], v_co[1]-100, v_co[2]))
				last_used_co.append(v_co_xm)
			if self.opt_extendLocalZ:
				v_co_xm = active_obj.matrix_world @ Vector((v_co[0], v_co[1], v_co[2]+100))
				last_used_co.append(v_co_xm)
				v_co_xm = active_obj.matrix_world @ Vector((v_co[0], v_co[1], v_co[2]-100))
				last_used_co.append(v_co_xm)
		if active_mesh_needClear:
			# tmp_obj.to_mesh_clear()
			active_mesh.name = "zzz_deleteme_"+active_mesh.name
		config.WPL_G.store[wla_bm.kWPL_PINCONVEXKey] = last_used_co
		wla_do.select_and_change_mode(active_obj, oldmode)
		self.report({'INFO'}, "Pinned "+str(len(last_used_co))+" verts")
		return {'FINISHED'}

class wplsculpt_flt_toconvex_view2d(bpy.types.Operator):
	bl_idname = "mesh.wplsculpt_flt_toconvex_view2d"
	bl_label = "Curves: Wrap to convex"
	bl_options = {'REGISTER', 'UNDO'}

	opt_influence : FloatProperty(
		name		= "Influence",
		default	 = 1.0,
		min = -10.0,
		max = 10.0
	)
	opt_convex2dMode : EnumProperty(
		name="2D extend", default="VIEW",
		items=(("NONE", "None", ""), ("VIEW", "View", ""))
	)
	opt_normCastMode : EnumProperty(
		name="Direction mode", default="NONE",
		items=(("NONE", "None", ""), ("VIEWR", "View-Right", ""), ("VIEWL", "View-Left", ""), ("VIEWT", "View-Top", ""), ("VIEWB", "View-Bottom", ""))
	)
	opt_convexMode : EnumProperty(
		name="Convex mode", default="ALL",
		items=(("ALL", "All verts", ""), ("USEPINNED", "Pinned", ""))
	)
	opt_reapplyDistribute : BoolProperty(
		name="Curve/GP: Distribute",
		default=True
	)
	
	def execute( self, context ):
		active_obj = wla.active_object(wla_meshwrap.kWPLMESHWRAP_TYPES)
		if active_obj is None:
			self.report({'ERROR'}, "Select mesh object first")
			return {'CANCELLED'}
		oldmode = wla_do.select_and_change_mode(active_obj,'OBJECT')
		active_mesh = wla_meshwrap.object_wrappedmesh(active_obj)
		selvertsAll = active_mesh.selected_vertsIdx()
		if len(selvertsAll) == 0:
			wla_do.select_and_change_mode(active_obj, oldmode)
			self.report({'ERROR'}, "No verts, opts reset.")
			return {'FINISHED'}
		bm2 = bmesh.new()
		hullv = []
		hullc_c = Vector((0,0,0))
		if self.opt_convexMode == 'USEPINNED':
			if wla_bm.kWPL_PINCONVEXKey in config.WPL_G.store:
				lastVerts = config.WPL_G.store[wla_bm.kWPL_PINCONVEXKey]
				for v_co_g in lastVerts:
					v_co = active_obj.matrix_world.inverted() @ v_co_g
					bm2v = bm2.verts.new(v_co)
					hullc_c = hullc_c+v_co
					hullv.append(bm2v)
				if len(hullv)>0:
					hullc_c = hullc_c/len(hullv)
				# if self.opt_convexMode == 'USEPINNED101':
				# 	for v in hullv:
				# 		v.co = hullc_c+(v.co-hullc_c)*1.01
				print("- saved convex",len(hullv))
		else:
			for vIdx in selvertsAll:
				v_co = active_mesh.vertices[vIdx].co
				bm2v = bm2.verts.new(v_co)
				hullc_c = hullc_c+v_co
				hullv.append(bm2v)
			if len(hullv)>0:
				hullc_c = hullc_c/len(hullv)
		if len(hullv) < 3:
			self.report({'ERROR'}, "No verts, opts reset.")
			return {'FINISHED'}
		print("- convex verts", len(hullv))
		if self.opt_reapplyDistribute and active_obj.type in ['CURVE', 'GPENCIL']:
			bpy.ops.curve.wplcurve_evenly_pts(opt_onlySelection=True, opt_linearizeCo = 0.0)
			active_mesh = wla_meshwrap.object_wrappedmesh(active_obj)
			selvertsAll = active_mesh.selected_vertsIdx()
		region, _ = wla.active_view_region()
		axisZ_g = (region.view_rotation @ Vector((0.0, 0.0, 1.0)))
		axisZ_l = active_obj.matrix_world.transposed().to_3x3() @ axisZ_g
		axisX_g = (region.view_rotation @ Vector((1.0, 0.0, 0.0)))
		axisX_l = active_obj.matrix_world.transposed().to_3x3() @ axisX_g
		axisY_g = (region.view_rotation @ Vector((0.0, 1.0, 0.0)))
		axisY_l = active_obj.matrix_world.transposed().to_3x3() @ axisY_g
		if self.opt_convex2dMode != 'NONE':
			print("- extending convex according to view")
			# if self.opt_convex2dMode == 'VIEW_ANNOT' or self.opt_convex2dMode == 'VIEW_ANNOT_CLEAN':
			# 	# BEFORE extending to view
			# 	annot_strokes = wla_curve.gp_get_annots()
			# 	for stroke in annot_strokes:
			# 		for pt_co_g in stroke:
			# 			v_co_l = active_obj.matrix_world.inverted() @ pt_co_g
			# 			bm2v2 = bm2.verts.new(v_co_l)
			# 			hullv.append(bm2v2)
			# 	if self.opt_convex2dMode == 'VIEW_ANNOT_CLEAN' and len(annot_strokes) > 0:
			# 		bpy.ops.gpencil.data_unlink()
			region_gOrtho = not region.is_perspective
			_, axisLoc_g = wla.active_view_region()
			axisLoc_l = active_obj.matrix_world.inverted() @ axisLoc_g
			hullv_ori = copy.copy(hullv)
			for v in hullv_ori:
				if region_gOrtho:
					bm2v1 = bm2.verts.new(v.co + axisZ_l*10)
					hullv.append(bm2v1)
					bm2v2 = bm2.verts.new(v.co - axisZ_l*10)
					hullv.append(bm2v2)
				else:
					v_co1 = v.co.lerp(axisLoc_l,0.5)
					bm2v1 = bm2.verts.new(v_co1)
					hullv.append(bm2v1)
					v_co2 = v.co.lerp(axisLoc_l,1.5)
					bm2v2 = bm2.verts.new(v_co2)
					hullv.append(bm2v2)
		okCnt = 0
		bvh_hull = None
		bm2.verts.ensure_lookup_table()
		bm2.verts.index_update()
		bmesh.ops.convex_hull(bm2, input=hullv)
		bm2.faces.ensure_lookup_table()
		bm2.faces.index_update()
		bvh_hull = BVHTree.FromBMesh(bm2, epsilon = 0)
		bm2.free()
		for vIdx in selvertsAll:
			v = active_mesh.vertices[vIdx]
			v_co = v.co
			if self.opt_normCastMode == 'VIEWR':
				# invert cast - less propblems
				n_loc2, _, _, _ = bvh_hull.ray_cast(v_co + axisX_l*10, -1*axisX_l)
				if n_loc2 is not None:
					v_co = n_loc2
			if self.opt_normCastMode == 'VIEWL':
				# invert cast - less propblems
				n_loc2, _, _, _ = bvh_hull.ray_cast(v_co - axisX_l*10, 1*axisX_l)
				if n_loc2 is not None:
					v_co = n_loc2
			if self.opt_normCastMode == 'VIEWT':
				# invert cast - less propblems
				n_loc2, _, _, _ = bvh_hull.ray_cast(v_co + axisY_l*10, -1*axisY_l)
				if n_loc2 is not None:
					v_co = n_loc2
			if self.opt_normCastMode == 'VIEWB':
				# invert cast - less propblems
				n_loc2, _, _, _ = bvh_hull.ray_cast(v_co - axisY_l*10, 1*axisY_l)
				if n_loc2 is not None:
					v_co = n_loc2
			n_loc4, _, _, _ = bvh_hull.find_nearest(v_co)
			if n_loc4 is None:
				continue
			v.co = v_co.lerp(n_loc4, self.opt_influence)
			okCnt = okCnt+1
		active_mesh.to_mesh()
		wla_do.select_and_change_mode(active_obj, oldmode)
		self.report({'INFO'}, "Moved "+str(okCnt)+" verts")
		return {'FINISHED'}


class wplsculpt_flt_toconvex_mesh(bpy.types.Operator):
	bl_idname = "mesh.wplsculpt_flt_toconvex_mesh"
	bl_label = "Mesh: Wrap to convex"
	bl_options = {'REGISTER', 'UNDO'}

	opt_influence : FloatProperty(
		name		= "Influence",
		default	 = 1.0,
		min = -10.0,
		max = 10.0
	)
	opt_postSmooth : IntProperty(
		name		= "Post-smooth",
		default	 = 3,
		min		 = 0,
		max		 = 500
	)
	opt_halfConvex : BoolProperty(
		name="Use convex half", default=True
	)
	opt_FreezeBoundary : BoolProperty(
		name="Freeze boundary", default=True
	)
	opt_FreezeSeams : BoolProperty(
		name="Freeze Seams", default=True
	)
	opt_postRemesh : IntProperty(
		name="Post-Relax edgenet (30)", default=0
	)
	opt_convexMode : EnumProperty(
		name="Convex mode", default="ALL",
		items=(("ALL", "All verts", ""), ("BOUNDS", "Bound verts", ""), ("USEPINNED", "Pinned", ""))
	)
	opt_normCast : FloatProperty(
		name		= "Direction Recast",
		default		= 0.0
	)
	opt_normCastMode : EnumProperty(
		name="Direction mode", default="NORMAL_SMOOTH",
		items=(("NORMAL", "Normal", ""), 
			("NORMAL_SMOOTH", "Smoothed Normal", ""), 
			("CURSOR_ORIENT", "Cursor Orientation", ""),
			("CCNORMAL", "Convex Center", ""))
	)
	def resetOpts(self):
		print("- operator parameters reset")
		self.opt_influence = 1
		self.opt_postSmooth = 3
		self.opt_normCast= 0.0
		self.opt_normCastMode="NORMAL_SMOOTH"
		#self.opt_cursCast = 0.0
		self.opt_FreezeBoundary = True
		self.opt_FreezeSeams = True
		self.opt_postRemesh = 0
		return

	def execute( self, context ):
		active_obj = wla.active_object(['MESH'])
		if active_obj is None:
			self.resetOpts()
			self.report({'ERROR'}, "Select mesh (opts reset)")
			return {'CANCELLED'}
		active_mesh = active_obj.data
		wla_do.select_and_change_mode(active_obj,'EDIT')
		oldselectmode = list(context.tool_settings.mesh_select_mode)
		selvertsAll = wla.selected_vertsIdx(active_mesh)
		if len(selvertsAll) == 0:
			self.resetOpts()
			wla_do.select_and_change_mode(active_obj,'EDIT')
			self.report({'ERROR'}, "No verts (opts reset)")
			return {'FINISHED'}
		wla_do.select_and_change_mode(active_obj,'EDIT')
		matrix_world = active_obj.matrix_world
		matrix_world_nrml = active_obj.matrix_world.inverted().transposed().to_3x3()
		bm = bmesh.from_edit_mesh(active_mesh)
		bm.verts.ensure_lookup_table()
		bm.verts.index_update()
		#bvh_orig = BVHTree.FromBMesh(bm, epsilon = 0)
		okCnt = 0
		bound_verts, seam_verts, originalPos, originalNrm = wla_bm.bm_vertsInitSeamBnd(bm, selvertsAll)
		# calcing averages to remove backfaces
		originalNrmSm = {}
		originalNrmAvg = Vector((0,0,0))
		originalNrmAvgC = 0.0
		originalNrmAvgA = Vector((0,0,0))
		originalNrmAvgAC = 0.0
		for vIdx in selvertsAll:
			v = bm.verts[vIdx]
			if self.opt_normCastMode == 'NORMAL_SMOOTH' and (self.opt_influence > 0.0):
				extset = set()
				v_nrm_v = Vector((0,0,0))
				v_nrm_c = 0
				wla_bm.bm_vertExtendByFaces(v, extset, 2, False)
				if len(extset)>0:
					for vv in extset:
						v_nrm_v = v_nrm_v+vv.normal
						v_nrm_c = v_nrm_c+1
					originalNrmSm[vIdx] = (v_nrm_v/v_nrm_c).normalized()
			originalNrmAvgA = originalNrmAvgA+v.normal
			originalNrmAvgAC = originalNrmAvgAC+1.0
			if vIdx in bound_verts:
				originalNrmAvg = originalNrmAvg+v.normal
				originalNrmAvgC = originalNrmAvgC+1.0
		if originalNrmAvgC>0:
			originalNrmAvg = originalNrmAvg/originalNrmAvgC
		else: # convexes, etc, no bounds
			originalNrmAvg = originalNrmAvgA/originalNrmAvgAC
		originalNrmAvg = originalNrmAvg.normalized()
		if self.opt_normCastMode == 'CURSOR_ORIENT':
			if wla.active_context_orient() is not None:
				orientation = wla.active_context_orient().matrix
				originalNrmAvg =  matrix_world_nrml.inverted() @ (orientation @ Vector(( 0, 0, 1)))
		bm2 = bmesh.new()
		hullv = []
		hullc_c = Vector((0,0,0))
		if self.opt_convexMode == 'USEPINNED':
			if wla_bm.kWPL_PINCONVEXKey in config.WPL_G.store:
				lastVerts = config.WPL_G.store[wla_bm.kWPL_PINCONVEXKey]
				for v_co_g in lastVerts:
					v_co = matrix_world.inverted() @ v_co_g
					bm2v = bm2.verts.new(v_co)
					hullc_c = hullc_c+v_co
					hullv.append(bm2v)
				if len(hullv)>0:
					hullc_c = hullc_c/len(hullv)
				# if self.opt_convexMode == 'USEPINNED101':
				# 	for v in hullv:
				# 		v.co = hullc_c+(v.co-hullc_c)*1.01
				print("- saved convex",len(hullv))
		else:
			for vIdx in selvertsAll:
				bm2.verts.ensure_lookup_table()
				v = bm.verts[vIdx]
				if self.opt_convexMode == 'BOUNDS':
					isSelects = False
					isNonselects = False
					for e in v.link_edges:
						if e.other_vert(v).index in selvertsAll:
							isSelects = True
						else:
							isNonselects = True
					if self.opt_FreezeBoundary and (v.is_boundary or v.is_wire):
						isNonselects = True
					if self.opt_FreezeSeams and vIdx in seam_verts:
						isNonselects = True
					if isSelects == True and isNonselects == False:
						# nonbound
						continue
				bm2v = bm2.verts.new(v.co)
				hullc_c = hullc_c+v.co
				hullv.append(bm2v)
			if len(hullv)>0:
				hullc_c = hullc_c/len(hullv)
		if len(hullv) < 3:
			self.resetOpts()
			self.report({'ERROR'}, "No verts (opts reset)")
			return {'FINISHED'}
		newPos = {}
		bvh_hull = None
		if self.opt_influence > 0.0:
			print("- convex verts", len(hullv))
			bm2.verts.ensure_lookup_table()
			bm2.verts.index_update()
			bmesh.ops.convex_hull(bm2, input=hullv)
			bm2.faces.ensure_lookup_table()
			bm2.faces.index_update()
			if self.opt_halfConvex:
				faces2del = []
				for hull_face in bm2.faces:
					# v2: checking is face normal opposite to average verts normal (good after fairing)
					if hull_face.normal.dot(originalNrmAvg)<= 0.0:
						faces2del.append(hull_face)
				if len(faces2del)>0:
					bmesh.ops.delete(bm2, geom=faces2del, context='FACES')
			bvh_hull = BVHTree.FromBMesh(bm2, epsilon = 0) # config.kWPLRaycastEpsilon
			bm2.free()
			for i in range(self.opt_postSmooth+1):
				if i>0:
					bpy.ops.mesh.vertices_smooth()
				for vIdx in selvertsAll:
					v = bm.verts[vIdx]
					n_loc1 = v.co
					n_loc2 = None
					n_loc4 = None
					if abs(self.opt_normCast) > 0.00001: # +abs(self.opt_cursCast)
						n_loc1_nrm = originalNrm[vIdx]
						# if self.opt_normCastMode == 'LOCALY':
						# 	n_loc1_nrm = Vector((0,-1,0))
						if self.opt_normCastMode == 'CURSOR_ORIENT':
							n_loc1_nrm = originalNrmAvg
						if self.opt_normCastMode == 'NORMAL_SMOOTH' and (vIdx in originalNrmSm):
							n_loc1_nrm = originalNrmSm[vIdx]
						if self.opt_normCastMode == 'CCNORMAL':
							n_loc1_nrm = (v.co-hullc_c).normalized()
						castDir = 1.0
						if abs(self.opt_normCast) > 0.0001:
							castDir = math.copysign(1.0, self.opt_normCast)
						#print("- recast dir", n_loc1_nrm)
						n_loc2, _, _, _ = bvh_hull.ray_cast(v.co, n_loc1_nrm * castDir)
						if n_loc2 is not None:
							n_loc1 = n_loc1.lerp(n_loc2, abs(self.opt_normCast)) # +abs(self.opt_cursCast)
					n_loc4, _, _, _ = bvh_hull.find_nearest(n_loc1)
					if n_loc4 is None:
						continue
					newPos[vIdx] = n_loc4
				for vIdx in selvertsAll:
					v = bm.verts[vIdx]
					if vIdx in newPos:
						v.co = newPos[vIdx]
		else:
			# important for edgenet relaxer - works even on zero influence
			bvh_hull = BVHTree.FromBMesh(bm, epsilon = 0) # config.kWPLRaycastEpsilon
			for vIdx in selvertsAll:
				v = bm.verts[vIdx]
				newPos[vIdx] = v.co
		bm.normal_update()
		vertsFreeze = []
		verts2del = []
		verts2sel = []
		for vIdx in selvertsAll:
			v = bm.verts[vIdx]
			if len(v.link_faces) == 0:
				# wire edge for making up volume.. deleting
				verts2del.append(v)
				continue
			needFrees = False
			if self.opt_FreezeBoundary and vIdx in bound_verts:
				needFrees = True
			if self.opt_FreezeSeams and vIdx in seam_verts:
				needFrees = True
			if needFrees:
				verts2sel.append(vIdx)
				vertsFreeze.append(vIdx)
				v.co = originalPos[vIdx]
			elif vIdx in newPos:
				verts2sel.append(vIdx)
				v.co = originalPos[vIdx].lerp(newPos[vIdx], self.opt_influence)
				okCnt = okCnt+1
		if len(verts2del) > 0:
			print("- deleting wire verts", len(verts2del))
			bmesh.ops.delete(bm, geom=verts2del, context='VERTS')
		wla_bm.bm_selectVertEdgesFaces(bm, verts2sel, None)
		if self.opt_postRemesh > 0:
			# even for zero influence - with proper bound/seam freezers
			print("- relaxing edgenet")
			remesher = wla_meshfair.BoundaryAlignedRemesher(bm, verts2sel, vertsFreeze, bvh_hull)
			remesher.remesh(self.opt_postRemesh, True)
			if self.opt_influence > 0.0:
				for vIdx in verts2sel:
					v = bm.verts[vIdx]
					if vIdx in originalPos:
						v.co = originalPos[vIdx].lerp(v.co, self.opt_influence)
		bmesh.update_edit_mesh(active_mesh)
		context.tool_settings.mesh_select_mode = oldselectmode
		self.report({'INFO'}, "Done, "+str(okCnt)+" verts moved")
		return {'FINISHED'}


class wplsculpt_edge_verts(bpy.types.Operator):
	bl_idname = "mesh.wplsculpt_edge_verts"
	bl_label = "Distribute verts"
	bl_options = {'REGISTER', 'UNDO'}

	opt_influence : FloatProperty(
		name		= "Influence",
		default	 = 1.0,
		min		 = 0,
		max		 = 1
	)
	opt_lerpLinear : FloatProperty(
		name		= "Straighten",
		default	 = 0.0,
		min		 = 0,
		max		 = 1
	)
	opt_lerpEqualize : FloatProperty(
		name		= "Distribute",
		default	 = 0.0,
		min		 = 0,
		max		 = 1
	)

	opt_smoothLoops : IntProperty(
		name="Smoothing loops",
		min=0, max=100,
		default=0,
	)

	opt_FreezeSeams : BoolProperty(
		name="Freeze Seams (smart)", default=True
	)

	def resetOpts(self):
		print("- operator parameters reset")
		self.opt_influence = 1
		self.opt_lerpLinear = 0
		self.opt_lerpEqualize = 0
		self.opt_smoothLoops = 0
		return
		
	def execute( self, context ):
		active_obj = wla.active_object(['MESH'])
		if active_obj is None:
			self.resetOpts()
			self.report({'ERROR'}, "Select mesh (opts reset)")
			return {'FINISHED'}
		active_mesh = active_obj.data
		bm, strands_vidx = wla_meshwrap.objectm_selection_to_bmStrands(active_obj)
		if strands_vidx is None:
			self.resetOpts()
			wla_do.select_and_change_mode(active_obj,'EDIT')
			self.report({'ERROR'}, "No edges found (opts reset)")
			return {'FINISHED'} # or all changes get lost!!!
		protectedVerts = []
		if self.opt_FreezeSeams == True:
			nonseams = 0
			isseams = 0
			isseamsVerts = []
			for e in bm.edges:
				if e.select:
					if e.seam == False:
						nonseams = nonseams+1
					else:
						isseams = isseams+1
						if e.verts[0] not in isseamsVerts:
							isseamsVerts.append(e.verts[0])
							protectedVerts.append([e.verts[0].index, e.verts[0].co.copy()])
						if e.verts[1] not in isseamsVerts:
							isseamsVerts.append(e.verts[1])
							protectedVerts.append([e.verts[1].index, e.verts[1].co.copy()])
			# for v in bm.verts:
			# 	for e in v.link_edges:
			# 		if e.seam:
			# 			protectedVerts.append([v.index, v.co.copy()])
			if nonseams == 0:
				print("- only seam verts selected, ignoring seam freeze")
				protectedVerts = []
			print("- seams loops found", isseams,"| non seams", nonseams)
		else:
			print("- loops found", len(strands_vidx))
		for i in range(len(strands_vidx)):
			vidx_es = strands_vidx[i]
			len_trg = 0
			t_xp = []
			t_yp_px = []
			t_yp_py = []
			t_yp_pz = []
			t_pos_len = {}
			curve_pt_last = None
			for j, vIdx in enumerate(vidx_es):
				bm.verts.ensure_lookup_table()
				bm.verts.index_update()
				bm.edges.ensure_lookup_table()
				bm.edges.index_update()
				curve_pt = bm.verts[vIdx]
				t_yp_px.append(curve_pt.co[0])
				t_yp_py.append(curve_pt.co[1])
				t_yp_pz.append(curve_pt.co[2])
				if curve_pt_last is not None:
					len_trg = len_trg+(curve_pt_last.co-curve_pt.co).length
				t_xp.append(len_trg)
				t_pos_len[vIdx] = len_trg
				curve_pt_last = curve_pt
			if self.opt_lerpLinear > 0.0:
				#t_xp_orig = copy.copy(t_xp)
				dots = len(t_yp_px)
				if dots > 1:
					for j in range(dots):
						if j == 0 or j == dots-1:
							continue
						#frac = (float(j)/float(dots))
						frac = t_xp[j]/len_trg
						px = t_yp_px[0]+(t_yp_px[-1] - t_yp_px[0])*frac
						t_yp_px[j] = t_yp_px[j]+(px - t_yp_px[j])*self.opt_lerpLinear
						py = t_yp_py[0]+(t_yp_py[-1] - t_yp_py[0])*frac
						t_yp_py[j] = t_yp_py[j]+(py - t_yp_py[j])*self.opt_lerpLinear
						pz = t_yp_pz[0]+(t_yp_pz[-1] - t_yp_pz[0])*frac
						t_yp_pz[j] = t_yp_pz[j]+(pz - t_yp_pz[j])*self.opt_lerpLinear
						# xp = t_xp[0]+(t_xp[-1] - t_xp[0])*frac
						# t_xp[j] = t_xp[j]+(xp - t_xp[j])*self.opt_lerpLinear
			if len_trg > 0.00001:
				# if enforceVertCount > 0 and len(vidx) != enforceVertCount:
				# 	t_pos_len = {} # not compatible yet
				# 	maxAttempts = 100
				# 	while maxAttempts > 0 and len(vidx) < enforceVertCount:
				# 		maxAttempts = maxAttempts-1
				# 		bm.verts.ensure_lookup_table()
				# 		bm.verts.index_update()
				# 		bm.edges.ensure_lookup_table()
				# 		bm.edges.index_update()
				# 		j_rand = random.randint(0,len(vidx)-1)
				# 		rnd_vIds = vidx[j_rand]
				# 		curve_pt1 = bm.verts[rnd_vIds[0]]
				# 		# random edge with vert in same line
				# 		rnd_edge = None
				# 		rnd_edge_dir = 0
				# 		for e in curve_pt1.link_edges:
				# 			for j, vIds in enumerate(vidx):
				# 				curve_pt2 = bm.verts[vIds[0]]
				# 				if e.other_vert(curve_pt1) == curve_pt2:
				# 					rnd_edge = e
				# 					rnd_edge_dir = -1
				# 					if j >= j_rand:
				# 						rnd_edge_dir = 1
				# 					break
				# 			if rnd_edge_dir != 0:
				# 				break
				# 		if rnd_edge is not None and rnd_edge_dir != 0:
				# 			result = bmesh.ops.subdivide_edges(bm, edges=[rnd_edge], cuts=1)
				# 			result_verts = [e for e in result["geom_split"] if isinstance(e, bmesh.types.BMVert)]
				# 			if len(result_verts) > 0:
				# 				new_vert = result_verts[0]
				# 				new_vert.select = True
				# 				new_vidx_item = [new_vert.index]
				# 				if rnd_edge_dir > 0:
				# 					vidx.insert(j_rand+1,new_vidx_item) # next to j_rand
				# 				else:
				# 					vidx.insert(j_rand,new_vidx_item) # before j_rand
				if self.opt_smoothLoops > 0:
					bpy.ops.mesh.wplverts_pinsnap(opt_pinId = "pin_straight") # pin mesh
				bm = bmesh.from_edit_mesh(active_mesh)
				for j, vIdx in enumerate(vidx_es):
					bm.verts.ensure_lookup_table()
					bm.verts.index_update()
					bm.edges.ensure_lookup_table()
					bm.edges.index_update()
					curve_pt = bm.verts[vIdx]
					t_pos = float(j)/float(len(vidx_es)-1)*len_trg
					if vIdx in t_pos_len:
						t_pos_ini = t_pos_len[vIdx]
						t_pos = t_pos_ini*(1.0-self.opt_lerpEqualize)+t_pos*self.opt_lerpEqualize
					new_co = Vector((np.interp(t_pos, t_xp, t_yp_px),np.interp(t_pos, t_xp, t_yp_py),np.interp(t_pos, t_xp, t_yp_pz)))
					curve_pt.co = curve_pt.co.lerp(new_co,self.opt_influence)
				if self.opt_smoothLoops > 0:
					bpy.ops.mesh.wplverts_pinpropagt(opt_mode='KEEPACTIV', opt_smoothLoops=self.opt_smoothLoops, opt_smoothPow=1.0, opt_pinId = "pin_straight") # pin mesh
				bm = bmesh.from_edit_mesh(active_mesh)
				if len(protectedVerts) > 0:
					for vv in protectedVerts:
						v = bm.verts[vv[0]]
						v.co = vv[1]
				bm.normal_update()
				bmesh.update_edit_mesh(active_mesh)
		return {'FINISHED'}

class wplsculpt_edge_outline(bpy.types.Operator):
	bl_idname = "mesh.wplsculpt_edge_outline"
	bl_label = "Geodesic outline"
	bl_options = {'REGISTER', 'UNDO'}

	opt_geoDistAbs : FloatProperty(
		name	= "Absolute Distance",
		default	= 0.0,
		min		= 0,
		max		= 999
	)
	opt_geoDistRel : FloatProperty(
		name	= "Relative Distance (avg edge len)",
		subtype	= 'PERCENTAGE',
		default	= 30,
		min		= 0,
		max		= 999
	)
	opt_postSelect : EnumProperty(
		name	= "Post Action", 
		default	= "BOUNDS",
		items	= (("BOUNDS", "Select Bounds", ""), ("ALL", "Select All", ""), ("EXTRACT", "Make copy", ""))
	)

	def execute( self, context ):
		active_obj = wla.active_object(['MESH'])
		if active_obj is None:
			self.report({'ERROR'}, "Select mesh object first")
			return {'CANCELLED'}
		
		active_mesh = active_obj.data
		vertsIdx = wla.selected_vertsIdx(active_mesh)
		if len(vertsIdx)<1:
			self.report({'ERROR'}, "No selected verts found, select some verts first")
			return {'FINISHED'} # or all changes get lost!!!
		bm = None
		if self.opt_postSelect == 'EXTRACT':
			active_mesh_copy = active_mesh.copy()
			bm = bmesh.new()
			bm.from_mesh(active_mesh_copy)
			active_mesh = active_mesh_copy
		else:
			wla_do.select_and_change_mode(active_obj, 'EDIT')
			context.tool_settings.mesh_select_mode = (True, False, False) # 'VERT'
			bm = bmesh.from_edit_mesh(active_mesh)
		bm.verts.ensure_lookup_table()
		bm.verts.index_update()
		bm.edges.ensure_lookup_table()
		bm.edges.index_update()
		bm.faces.ensure_lookup_table()
		bm.faces.index_update()
		avglenSum = 0.0
		avglenCnt = 0.0
		for vIdx in vertsIdx:
			v = bm.verts[vIdx]
			for e in v.link_edges:
				avglenSum = avglenSum+e.calc_length()
				avglenCnt = avglenCnt+1.0
		outlineDist = self.opt_geoDistAbs
		if avglenCnt>0 and self.opt_geoDistRel>0:
			outlineDist = outlineDist+self.opt_geoDistRel*0.01*avglenSum/avglenCnt
		vertsIdx_curves = wla_bm.bm_splitVertsByConnection(bm, vertsIdx, True, None, None)
		vertIn, joinVertsData, vertDistMap = wla_bm.bm_geodesicBisecter(bm, vertsIdx_curves, 100, outlineDist, False)
		# selecting needed verts
		for vIdx in vertIn:
			v = bm.verts[vIdx]
			v.select = False
			if self.opt_postSelect in ('ALL', 'EXTRACT'):
				if vertDistMap[v.index] < outlineDist:
					v.select = True
		# pre-getting edges (index not usable dure bisecting in iteration)
		joinvertsRaw = []
		joinedgesRaw = []
		for jvd in joinVertsData:
			if jvd[3] is not None:
				e = bm.edges[ jvd[3] ]
				joinedgesRaw.append( (e, jvd[0]) )
			elif jvd[1] not in joinvertsRaw:
				joinvertsRaw.append(jvd[1])
		for bsc in joinedgesRaw:
			e = bsc[0]
			newv_co = bsc[1]
			geom = bmesh.ops.bisect_edges(bm, edges = [e], cuts = 1)
			new_bmverts = [ele for ele in geom['geom_split'] if isinstance(ele, bmesh.types.BMVert)]
			if len(new_bmverts) == 1:
				newv = new_bmverts[0]
				newv.co = newv_co
				if newv.index not in joinvertsRaw:
					joinvertsRaw.append(newv.index)
		if len(joinvertsRaw) >= 2:
			# resorting by distance and same-faceness
			joinvertsRaw = wla_bm.bm_sortVertsByConnection(bm, joinvertsRaw, False, True)
			joinvertsSrt = []
			for vIdx in joinvertsRaw:
				v = bm.verts[vIdx]
				v.select = True
				joinvertsSrt.append(v)
			bmesh.ops.connect_verts(bm, verts = joinvertsSrt, faces_exclude = [], check_degenerate = True)
		bm.normal_update()
		if self.opt_postSelect == 'EXTRACT':
			# deleting all non-selected and merging back
			bm_copy = bm
			active_mesh_copy = active_mesh
			verts2del = []
			# verts2selIdx = []
			for v in bm_copy.verts:
				if v.select == False:
					verts2del.append(v)
				# else:
				# 	verts2selIdx.append(v.index)
			bmesh.ops.delete(bm_copy, geom=verts2del, context='VERTS')
			bm_copy.to_mesh(active_mesh_copy)
			bm_copy.free()
			active_mesh = active_obj.data
			wla_do.select_and_change_mode(active_obj, 'EDIT')
			context.tool_settings.mesh_select_mode = (True, False, False) # 'VERT'
			bm = bmesh.from_edit_mesh(active_mesh)
			bm.verts.ensure_lookup_table()
			bm.verts.index_update()
			bm.edges.ensure_lookup_table()
			bm.edges.index_update()
			bm.faces.ensure_lookup_table()
			bm.faces.index_update()
			for v in bm.verts:
				v.select = False
			bm.from_mesh(active_mesh_copy)
			bm.verts.ensure_lookup_table()
			bm.verts.index_update()
			bm.edges.ensure_lookup_table()
			bm.edges.index_update()
			bm.faces.ensure_lookup_table()
			bm.faces.index_update()
			verts2selIdx = [v.index for v in bm.verts if v.select]
			wla_bm.bm_selectVertEdgesFaces(bm, verts2selIdx)
		bmesh.update_edit_mesh(active_mesh)
		self.report({'INFO'}, "Done, "+str(len(joinvertsRaw))+" verts added")
		return {'FINISHED'}

class wplsculpt_edge_bisect(bpy.types.Operator):
	bl_idname = "mesh.wplsculpt_edge_bisect"
	bl_label = "Bisect with edge"
	bl_options = {'REGISTER', 'UNDO'}

	opt_ovlNormalDir : FloatVectorProperty(
		name	 = "Bisect normal override",
		size	 = 3,
		min=-1.0, max=1.0,
		default	 = (0.0,0.0,0.0)
	)

	def execute( self, context ):
		active_obj = wla.active_object(['MESH'])
		if active_obj is None:
			self.report({'ERROR'}, "Select mesh object first")
			return {'CANCELLED'}
		active_mesh = active_obj.data
		facesIdx = wla.selected_facesIdx(active_mesh)
		#edgesIdx = wla.selected_edgesIdx(active_mesh)
		wla_do.select_and_change_mode(active_obj, 'EDIT')
		bisectEdges = []
		bm = bmesh.from_edit_mesh(active_mesh)
		bm.edges.ensure_lookup_table()
		bm.edges.index_update()
		bm.faces.ensure_lookup_table()
		bm.faces.index_update()
		if context.tool_settings.mesh_select_mode[2] == True: # 'FACE' selection
			histFaceIdx = wla_bm.bm_historyFaceIdx(bm)
			if len(histFaceIdx) == 0:
				self.report({'ERROR'}, "No active face found, select face first")
				return {'CANCELLED'}
			faceBisecterIdx = histFaceIdx[0]
			if faceBisecterIdx in facesIdx:
				facesIdx.remove(faceBisecterIdx)
			f = bm.faces[faceBisecterIdx]
			oporV = f.verts[0]
			secdV = f.verts[1]
			bisectEdges.append((oporV,secdV,f.normal))
		if context.tool_settings.mesh_select_mode[1] == True: # 'EDGE' selection
			histEdgesIdx = wla_bm.bm_historyEdgesIdx(bm)
			if len(histEdgesIdx) == 0:
				self.report({'ERROR'}, "No active edge found, select edge first")
				return {'CANCELLED'}
			bisectEdgeMain = bm.edges[histEdgesIdx[0]]
			oporV = bisectEdgeMain.verts[0]
			secdV = bisectEdgeMain.verts[1]
			bisectEdges.append((oporV,secdV,None))
			if len(facesIdx) == 0:
				facesIdx = []
				context.tool_settings.mesh_select_mode = (False, False, True) # 'FACE'
				for f in oporV.link_faces:
					f.select = True
					if f.index not in facesIdx:
						facesIdx.append(f.index)
				for f in secdV.link_faces:
					f.select = True
					if f.index not in facesIdx:
						facesIdx.append(f.index)
		if len(facesIdx) == 0:
			self.report({'ERROR'}, "No faces found, select faces first")
			return {'CANCELLED'}
		if len(bisectEdges) == 0:
			self.report({'ERROR'}, "No bisect edge found")
			return {'CANCELLED'}
		bisectFaces = [bm.faces[idx] for idx in facesIdx]
		# # adding edges with verts without selected faces
		# if len(edgesIdx) > 0:
		# 	print("- adding connected faces to selected edges")
		# 	for eIdx in edgesIdx:
		# 		e = bm.edges[eIdx]
		# 		isPossibleBse = True
		# 		for bse in bisectEdges:
		# 			if bse[0] == e.verts[0] or bse[0] == e.verts[1] or bse[1] == e.verts[0] or bse[1] == e.verts[1]:
		# 				isPossibleBse = False
		# 				break
		# 		vfcsc = 0
		# 		for f in e.verts[0].link_faces:
		# 			if f.select:
		# 				vfcsc = vfcsc+1
		# 				break
		# 		for f in e.verts[1].link_faces:
		# 			if f.select:
		# 				vfcsc = vfcsc+1
		# 				break
		# 		if vfcsc > 1 or isPossibleBse == False:
		# 			continue
		# 		bisectEdges.append((e.verts[0],e.verts[1],None))
		context.tool_settings.mesh_select_mode = (False, False, True) # 'FACE'
		for bse in bisectEdges:
			oporV = bse[0]
			secdV = bse[1]
			bisectNrm = bse[2]
			if bisectNrm is None:
				reperNrm = oporV.normal
				bisectNrm = (oporV.co-secdV.co).normalized().cross(reperNrm)
			if abs(self.opt_ovlNormalDir[0])+abs(self.opt_ovlNormalDir[1])+abs(self.opt_ovlNormalDir[2])>0.00001:
				bisectNrm = Vector((self.opt_ovlNormalDir[0],self.opt_ovlNormalDir[1],self.opt_ovlNormalDir[2])).normalized()
			bisectNrm = bisectNrm.normalized()
			geom_in_v = []
			geom_in_e = []
			geom_in_f = []
			for f in bisectFaces:
				geom_in_v.extend(f.verts)
				geom_in_e.extend(f.edges)
				geom_in_f.append(f)
			print("Bisecting",len(geom_in_v),len(geom_in_e),len(geom_in_f), bisectNrm)
			#geom_in = bm.verts[:]+bm.edges[:]+bm.faces[:]
			geom_in = set(geom_in_v[:]+geom_in_e[:]+geom_in_f[:])
			res = bmesh.ops.bisect_plane(bm, geom=list(geom_in), dist=config.kWPLRaycastEpsilon, plane_co=oporV.co, plane_no=bisectNrm, use_snap_center=False, clear_outer=False, clear_inner=False)
			for elem in res["geom"]:
				if isinstance(elem, bmesh.types.BMFace):
					elem.select = True
					if elem not in bisectFaces:
						bisectFaces.append(elem)
		bm.normal_update()
		bm.faces.ensure_lookup_table()
		bm.faces.index_update()
		bm.verts.ensure_lookup_table()
		bm.verts.index_update()
		bm.edges.ensure_lookup_table()
		bm.edges.index_update()
		bmesh.update_edit_mesh(active_mesh)
		context.tool_settings.mesh_select_mode = (False, True, False) # 'EDGE'
		return {'FINISHED'}

class wplsculpt_stepsubd(bpy.types.Operator):
	bl_idname = "mesh.wplsculpt_stepsubd"
	bl_label = "Step and Subdivide"
	bl_options = {'REGISTER', 'UNDO'}

	opt_smoothLoops : IntProperty (
		name = "Extra loops",
		min = 0, max = 100,
		default = 1
	)
	opt_cuts : IntProperty (
		name = "Cuts",
		min = 0, max = 100,
		default = 1
	)

	def execute( self, context ):
		active_obj = wla.active_object(['MESH','CURVE','GPENCIL','LATTICE'])
		if active_obj is None:
			self.report({'ERROR'}, "Select object first")
			return {'CANCELLED'}
		if active_obj.type == 'LATTICE':
			# doubling dimensions (except 1)
			if active_obj.data.points_u > 1:
				active_obj.data.points_u = active_obj.data.points_u*2
			if active_obj.data.points_v > 1:
				active_obj.data.points_v = active_obj.data.points_v*2
			if active_obj.data.points_w > 1:
				active_obj.data.points_w = active_obj.data.points_w*2
		if active_obj.type == 'MESH':
			wla_do.select_and_change_mode(active_obj, 'EDIT')
			for i in range(0, self.opt_smoothLoops):
				bpy.ops.mesh.select_more(use_face_step = True)
			bpy.ops.mesh.subdivide(number_cuts = self.opt_cuts, smoothness = 0)
		if active_obj.type == 'GPENCIL':
			for i in range(0, self.opt_smoothLoops):
				bpy.ops.gpencil.select_more()
			bpy.ops.gpencil.stroke_subdivide(number_cuts = self.opt_cuts, only_selected=True, smooth_thickness = False, smooth_strength = True, smooth_position = False)
		if active_obj.type == 'CURVE':
			for i in range(0, self.opt_smoothLoops):
				bpy.ops.curve.select_more()
			bpy.ops.curve.subdivide(number_cuts = self.opt_cuts)
		return {'FINISHED'}

class wplsculpt_edge_regul(bpy.types.Operator):
	bl_idname = "mesh.wplsculpt_edge_regul"
	bl_label = "Squarify edgenet"
	bl_options = {'REGISTER', 'UNDO'}

	opt_maxSlide2ang : FloatProperty(
		name		= "Angle: Max slide",
		min		 = 0.0,
		max		 = 10.0,
		default	 = 0.2
	)
	opt_maxSlide2len : FloatProperty(
		name		= "Length: Shift influence",
		min		 = -1.0,
		max		 = 1.0,
		default	 = 0.0
	)
	opt_smoothLoops : IntProperty (
		name = "Smoothing loops",
		min = 0, max = 100,
		default = 1
	)

	opt_smoothPow : FloatProperty (
		name = "Smoothing pow",
		min = 0.0, max = 10.0,
		default = 1.0
	)

	opt_allowNegShift : BoolProperty(
		name="Allow negative shifts", 
		default=True
	)

	def execute( self, context ):
		active_obj = wla.active_object(['MESH'])
		if active_obj is None:
			self.report({'ERROR'}, "Select mesh object first")
			return {'CANCELLED'}
		active_mesh = active_obj.data
		oldmode = wla_do.select_and_change_mode(active_obj, 'OBJECT')
		selvertsIdx = wla.selected_vertsIdx(active_mesh)
		wla_do.select_and_change_mode(active_obj, 'EDIT')
		context.tool_settings.mesh_select_mode = (True, False, False) # 'VERT'
		bm = bmesh.from_edit_mesh(active_mesh)
		bm.verts.ensure_lookup_table()
		bm.verts.index_update()
		bm.edges.ensure_lookup_table()
		bm.edges.index_update()
		if len(selvertsIdx) == 1:
			# special case for ring-faces
			v = bm.verts[selvertsIdx[0]]
			if len(v.link_edges) > 0:
				lenMin = 999
				lenMax = 0
				lenSum = 0
				for e in v.link_edges:
					elen = e.calc_length()
					lenMin = min(lenMin, elen)
					lenMax = max(lenMax, elen)
					lenSum = lenSum+ elen
				lenNew = lenSum/len(v.link_edges)
				if self.opt_maxSlide2len < 0:
					lenNew = lenMin
				if self.opt_maxSlide2len > 0:
					lenNew = lenMax
				for e in v.link_edges:
					v2 = e.other_vert(v)
					v2.co = v.co + lenNew*((v2.co-v.co).normalized())
				bmesh.update_edit_mesh(active_mesh)
			wla_do.select_and_change_mode(active_obj, oldmode)
			self.report({'INFO'}, "Done")
			return {'FINISHED'}
		selvertsIdx_curves = wla_bm.bm_splitVertsByConnection(bm, selvertsIdx, True, None, None)
		_, vertStepMap, _, _ = wla_bm.bm_geodesicDistmap_v05(bm, selvertsIdx_curves, self.opt_smoothLoops, None, False, False)
		visitedVerts = []
		for step in range(1, self.opt_smoothLoops+1):
			stepVerts = []
			for vIdx in vertStepMap:
				if vertStepMap[vIdx] == step:
					stepVerts.append(vIdx)
					visitedVerts.append(vIdx)
			stepShifts = {}
			stepEdgMaxLen = 0.0
			stepEdgMinLen = 999.0
			stepEdgAvgLen = 0.0
			stepEdgAvgCnt = 0.0
			stepLenFixPairs = []
			for vIdx in stepVerts:
				v1 = bm.verts[vIdx]
				if v1.hide:
					continue
				refEdges = []
				nextVerts = []
				for eRef in v1.link_edges:
					v2 = eRef.other_vert(v1)
					if (v2.index in visitedVerts) and (v2.index not in stepVerts):
						continue
					if (v2.index in stepVerts):
						refEdges.append((v1,v2))
						continue
					if len(eRef.link_faces) == 0:
						# fold(wire) links...
						continue
					# checking verts in faces of v2
					v2_nearverst = []
					for f2 in v2.link_faces:
						for f2v in f2.verts:
							if (f2v.index in stepVerts) or (f2v.index in visitedVerts):
								if f2v.index not in v2_nearverst:
									v2_nearverst.append(f2v.index)
					if len(v2_nearverst) < 2:
						# forward/backward verts, not side
						continue
					nextVerts.append(v2)
					stepLenFixPairs.append( (v2,v1) )
					edgDist = (v2.co-v1.co).length
					stepEdgAvgCnt = stepEdgAvgCnt+1.0
					stepEdgAvgLen = stepEdgAvgLen+edgDist
					stepEdgMaxLen = max(stepEdgMaxLen,edgDist)
					stepEdgMinLen = min(stepEdgMinLen,edgDist)
				#print("- step", step, vIdx, len(nextVerts), len(refEdges))
				for v2 in nextVerts:
					shiftCandidated = []
					for e in v2.link_edges:
						v3 = e.other_vert(v2)
						if v3.index in visitedVerts:
							continue
						# edge should be connected to visited/stepVerts via at least one face
						# so only topologically parallel edges are used (assuming quads)
						# ... faces with 2 common verts at least -> skipping corner verts to avoid bad problems
						isStepVertConnected = 0
						for f in e.link_faces:
							for vf in f.verts:
								if vf.index in stepVerts:
									isStepVertConnected = isStepVertConnected+1
						if isStepVertConnected < 2:
							continue
						# checking aligments with RefEdges
						for refEdg in refEdges:
							p1 = refEdg[0].co
							cross1 = ( (v3.co-refEdg[0].co).normalized() ).cross( (refEdg[1].co-refEdg[0].co).normalized() ).normalized()
							p2 = p1 + cross1
							cross2 = ( (refEdg[1].co-refEdg[0].co).normalized() ).cross(cross1).normalized()
							p3 = p1 + cross2
							posprj = mathutils.geometry.intersect_ray_tri(p1, p2, p3, v3.co-v2.co, v2.co, False)
							if posprj is None and self.opt_allowNegShift:
								posprj = mathutils.geometry.intersect_ray_tri(p1, p2, p3, v2.co-v3.co, v2.co, False)
							if posprj is not None:
								shiftCandidated.append(( (posprj-v2.co).length, posprj, v3 ))
							else:
								print("- no intersection", p1, p2, p3, v3.co-v2.co, v2.co)
					for candid in shiftCandidated:
						newpos = candid[1]
						v3 = candid[2]
						maxedgelen = self.opt_maxSlide2ang * (v3.co-v2.co).length
						if (newpos-v2.co).length > maxedgelen:
							newpos = v2.co+(maxedgelen*((newpos-v2.co).normalized()))
						newlen = (newpos-v1.co).length
						newpos = v1.co + newlen * (newpos-v1.co).normalized()
						if v2 not in stepShifts:
							stepShifts[v2] = []
						stepShifts[v2].append( newpos )
			stepInfl = 1.0
			if self.opt_smoothLoops > 1:
				if self.opt_smoothPow > 0.0:
					stepInfl = pow(1.0-float(step-1)/float(self.opt_smoothLoops), self.opt_smoothPow) # * self.opt_influence
				else:
					stepInfl = 1.0
			print("- stepShifts", len(stepShifts))
			for vv in stepShifts:
				sumV = Vector((0,0,0))
				for newpos in stepShifts[vv]:
					sumV = sumV+newpos
				sumV = sumV/len(stepShifts[vv])
				vv.co = vv.co.lerp(sumV, stepInfl)
			if abs(self.opt_maxSlide2len) > 0.0001:
				targetLen = stepEdgMaxLen #stepEdgAvgLen/stepEdgAvgCnt
				if self.opt_maxSlide2len < 0:
					targetLen = stepEdgMinLen
				for lenpair in stepLenFixPairs:
					v2 = lenpair[0]
					v1 = lenpair[1]
					newlen = (v2.co-v1.co).length
					newlen = wla.math_lerp1D(abs(self.opt_maxSlide2len)*stepInfl, newlen, targetLen)
					v2.co = v1.co + newlen * (v2.co-v1.co).normalized()
		bmesh.update_edit_mesh(active_mesh)
		wla_do.select_and_change_mode(active_obj, oldmode)
		self.report({'INFO'}, "Done, "+str(len(visitedVerts))+" verts moved")
		return {'FINISHED'}

# class wplsculpt_edge_unfuck(bpy.types.Operator):
# 	bl_idname = "mesh.wplsculpt_edge_unfuck"
# 	bl_label = "Unfuck parallel edges"
# 	bl_options = {'REGISTER', 'UNDO'}

# 	opt_width1: FloatProperty(name="Width L", default=0)
# 	opt_width2: FloatProperty(name="Width R", default=0)
# 	opt_widthlinked: BoolProperty(name="Width Linked", default=True)

# 	opt_tension1: FloatProperty(name="Tension", default=0.7, min=0.01, max=10)
# 	opt_tension2: FloatProperty(name="Tension 2", default=0.7, min=0.01, max=10)
# 	opt_tensionlinked: BoolProperty(name="Tension Linked", default=True)

# 	def execute( self, context ):
# 		active_obj = wla.active_object(['MESH'])
# 		if active_obj is None:
# 			self.report({'ERROR'}, "Select mesh object first")
# 			return {'CANCELLED'}
# 		active_mesh = active_obj.data
# 		oldmode = wla_do.select_and_change_mode(active_obj, 'OBJECT')
# 		vertsIdx = wla.selected_vertsIdx(active_mesh)
# 		edgesIdx = wla.selected_edgesIdx(active_mesh)
# 		if len(edgesIdx)<1:
# 			self.report({'ERROR'}, "No selected edges found, select some edges first")
# 			return {'FINISHED'} # or all changes get lost!!!

# 		if self.opt_widthlinked:
# 			self.opt_width2 = self.opt_width1
# 		if self.opt_tensionlinked:
# 			self.opt_tension2 = self.opt_tension1
# 		wla_do.select_and_change_mode(active_obj, 'EDIT')
# 		bm = bmesh.from_edit_mesh(active_mesh)
# 		bm.verts.ensure_lookup_table()
# 		bm.faces.ensure_lookup_table()
# 		bm.verts.index_update()
# 		strands_points,strands_vidx = wla_bm.bm_edgesAsStrands_v04(active_obj, bm, vertsIdx, edgesIdx, None, None)
# 		if strands_points is None:
# 			self.report({'ERROR'}, "No edges found")
# 			return {'FINISHED'} # or all changes get lost!!!
# 		vertsMoved = 0
# 		vertUsed = []
# 		vseqsPrepared = []
# 		for i,strand_vids in enumerate(strands_vidx):
# 			vseq = []
# 			for vIdx in strand_vids:
# 				v = bm.verts[vIdx]
# 				vseq.append(v)
# 				vertUsed.append(v)
# 			if len(vseq) > 3:
# 				vertsMoved = vertsMoved+len(vseq)
# 				vseqsPrepared.append((vseq, 1.0))
# 		for vseqpair in vseqsPrepared:
# 			if vseqpair[1] <= 0.0:
# 				continue
# 			wla_bm.bm_verts_to_spline(bm, vseqpair[0], self.opt_width1, self.opt_width2, self.opt_tension1, self.opt_tension2, False, vseqpair[1])
# 		bmesh.update_edit_mesh(active_mesh)
# 		wla_do.select_and_change_mode(active_obj, oldmode)
# 		self.report({'INFO'}, "Done, "+str(vertsMoved)+" verts moved")
# 		return {'FINISHED'}

class wplsculpt_fair(bpy.types.Operator):
	bl_idname = "mesh.wplsculpt_fair"
	bl_label = "Mesh fairing"
	bl_options = {'REGISTER', 'UNDO'}

	opt_continutyOrder : IntProperty(
			name="Order",
			min=1, max=3,
			default=1
		)

	opt_FreezeBoundary : BoolProperty(
		name="Freeze boundary", default=True
	)
	opt_FreezeSeams : BoolProperty(
		name="Freeze Seams", default=True
	)

	@classmethod
	def poll(cls, context):
		return context.active_object is not None

	def execute(self, context):
		active_obj = wla.active_object(['MESH'])
		if active_obj is None:
			self.report({'ERROR'}, "Select mesh object first")
			return {'CANCELLED'}
		active_mesh = active_obj.data
		selvertsAll = wla.selected_vertsIdx(active_mesh)
		wla_do.select_and_change_mode(active_obj,'EDIT')
		# Initialize BMesh.
		bm = bmesh.from_edit_mesh(active_obj.data)
		bm.faces.ensure_lookup_table()
		bm.faces.index_update()
		bm.edges.ensure_lookup_table()
		bm.edges.index_update()
		bm.verts.ensure_lookup_table()
		bm.verts.index_update()
		selected_vertices = [v for v in bm.verts if v.index in selvertsAll]
		vertsFreeze = []
		bound_verts, seam_verts, _, _ = wla_bm.bm_vertsInitSeamBnd(bm, selvertsAll)
		for vIdx in selvertsAll:
			needFrees = False
			if self.opt_FreezeBoundary and (vIdx in bound_verts):
				needFrees = True
			if self.opt_FreezeSeams and (vIdx in seam_verts):
				needFrees = True
			if needFrees:
				vertsFreeze.append(vIdx)
		wla_meshfair.do_fair(bm, self.opt_continutyOrder, selected_vertices, vertsFreeze)
		bm.normal_update()
		bmesh.update_edit_mesh(active_obj.data)
		self.report({'INFO'}, "Done")
		return {'FINISHED'}

# ==========================================
# ==========================================
# ==========================================
# ==========================================

class WPL_PT_SculptPanel(bpy.types.Panel):
	bl_idname = "WPL_PT_SculptPanel"
	bl_label = "Aligners"
	bl_space_type = 'VIEW_3D'
	bl_region_type = 'UI'
	bl_category = 'Sculpt'

	def draw(self, context):
		layout = self.layout
		active_obj = wla.active_object()
		col = layout.column()
		if active_obj is not None and (active_obj.type == 'CURVE' or active_obj.type == 'GPENCIL'):
			col.operator("curve.wplcurve_smooth_pos", text = 'Smooth curves', icon='MOD_SMOOTH')
			row = col.row()
			row.operator("curve.wplcurve_evenly_pts", text="Straighten", icon = 'IPO_LINEAR').opt_linearizeCo = 1.0
			row.operator("curve.wplcurve_evenly_pts", text = "Distribute", icon="PARTICLE_POINT").opt_linearizeCo = 0.0
			row2 = col.row()
			row2.operator("mesh.wplsculpt_flt_toconvex_view2d", text = 'Convex 2D', icon = 'SHADING_WIRE')
			row2.operator("mesh.wplsculpt_stepsubd", text="Subd +1", icon="MOD_PARTICLE_INSTANCE")
			# row2.operator("curve.wplcurve_cnormalize", text = "Normalize")
			col.operator("curve.wplcurve_forcexmirr", text='Curve XMirror', icon='MOD_MIRROR')
		else:
			col.operator("mesh.wplsculpt_doosabin_smooth", text = 'DB Smooth', icon='MOD_SMOOTH')
			col.operator("mesh.wplsculpt_flt_toconvex_mesh", text = 'Convex', icon = 'SHADING_WIRE').opt_convexMode = 'ALL'
			row2 = col.row()
			row2.operator("mesh.wplsculpt_flt_toconvex_mesh", text="Flattening", icon = "MESH_GRID").opt_convexMode = 'BOUNDS'
			row2.operator("mesh.wplsculpt_fair", text='Fairing (P)').opt_continutyOrder=1

			row1 = col.row()
			op5 = row1.operator("mesh.wplsculpt_edge_verts", text="Straighten", icon = 'MOD_INSTANCE')
			op5.opt_lerpLinear = 1.0
			op5.opt_lerpEqualize = 0.0
			op5.opt_smoothLoops = 3
			op7 = row1.operator("mesh.wplsculpt_edge_verts", text="Linearize", icon = "IPO_LINEAR")
			op7.opt_lerpLinear = 1.0
			op7.opt_lerpEqualize = 0.0
			op7.opt_smoothLoops = 0

			row2 = col.row()
			row2.operator("mesh.wplsculpt_stepsubd", text="Subd +1", icon="MOD_PARTICLE_INSTANCE")
			op7 = row2.operator("mesh.wplsculpt_edge_verts", text="Distribute", icon="PARTICLE_POINT")
			op7.opt_lerpLinear = 0.0
			op7.opt_lerpEqualize = 1.0
			op7.opt_smoothLoops = 0

			if active_obj is not None and active_obj.type == 'MESH':
				col.separator()
				from . import ops_mesh_edit2
				ops_mesh_edit2.uilayout_geomtBox(col, context)
			

# ==========================================
# ==========================================
# ==========================================
# ==========================================
# ==========================================
# ==========================================

classes = (
	WPL_PT_SculptPanel,
	wplsculpt_doosabin_smooth,
	wplsculpt_flt_toconvex_mesh,
	wplsculpt_flt_toconvex_view2d,
	wplsculpt_pin_toconvex,
	wplsculpt_edge_verts,
	wplsculpt_edge_outline,
	wplsculpt_edge_bisect,
	wplsculpt_edge_regul,
	wplsculpt_stepsubd,
	#wplsculpt_edge_unfuck,
	wplsculpt_fair
)

def register():
	for cls in classes:
		bpy.utils.register_class(cls)

def unregister():
	for cls in reversed(classes):
		bpy.utils.unregister_class(cls)

if __name__ == "__main__":
	register()