import os, sys, time, datetime
import math, copy, string, random
import numpy as np
import bpy, bmesh, mathutils

import bpy.types
from mathutils import Vector, Matrix, Euler, Quaternion
from mathutils.bvhtree import BVHTree
from mathutils.kdtree import KDTree
from bpy_extras import view3d_utils
from bpy.props import *

from . import config
from .tools import wla
from .tools import wla_do
from .tools import wla_attr
from .tools import wla_bm
from .tools import wla_arma
from .tools import wla_meshwrap
from .tools import wla_vgbind
from .tools import wla_edger
from .tools import wla_vgs

kWPLArmBoneNormalsExcept_MLOW = 'breast,shoulder'
#kWPLArmBoneUvsExcept_MLOW = 'breast,hand,shoulder'
#kWPLLastUpdatedVG = 'lastUpdatedVG'

# ==========================================

class wpluvvg_vgedt(bpy.types.Operator):
	bl_idname = "mesh.wpluvvg_vgedt"
	bl_label = "Weight: inc/dec selected"
	bl_options = {'REGISTER', 'UNDO'}

	opt_stepadd : FloatProperty(
		name		= "Add val",
		default	 	= 0.0
		)
	# opt_stepmul : FloatProperty(
	# 	name		= "Mul val",
	# 	default	 	= 1.0
	# 	)
	opt_oldmul : FloatProperty(
		name		= "Mix fac",
		default	 	= 1.0
		)
	opt_otherval : FloatProperty(
		name		= "Value for other vg",
		default	 	= -1.0
		)
	opt_extendOnNear : BoolProperty(
		name = "With nears (even hidden)",
		default = False
	)

	def execute( self, context ):
		wpl_weigToolOpts = context.scene.wpl_uvvgOpts
		active_obj = wla.active_object(wla_meshwrap.kWPLMESHWRAP_TYPES)
		sel_all = wla.selected_objects(wla_meshwrap.kWPLMESHWRAP_TYPES)
		if len(sel_all) > 1 or (active_obj is not None and active_obj.type not in ['MESH', 'GPENCIL'] ):
			# multi-create VG
			vgname = wpl_weigToolOpts.wei_gropnm
			vg_upds = 0
			if len(vgname) > 0:
				for obj in sel_all:
					if obj.type != 'MESH':
						vg_upds = vg_upds+1
						obj[vgname] = {"-1": 0.0}
					else:
						vg = obj.vertex_groups.get(vgname)
						if vg is None:
							vg = wla_attr.vg_get_or_new(obj, vgname)
							vg_upds = vg_upds+1
			self.report({'INFO'}, "Multi-add: VG added: "+str(vg_upds)+" objs")
			return {'FINISHED'}
		if active_obj is None:
			self.report({'ERROR'}, "Select mesh object first")
			return {'CANCELLED'}
		oldmode = wla_do.select_and_change_mode(active_obj, 'OBJECT')
		active_mesh = active_obj.data
		vg = active_obj.vertex_groups.get(wpl_weigToolOpts.wei_gropnm)
		if vg is None:
			# creating VG even if no selected vertex -> for binding
			if len(wpl_weigToolOpts.wei_gropnm) == 0:
				self.report({'ERROR'}, "No active vertex group found")
				return {'FINISHED'}
			# comparing to last with bareName search
			# to avoid creating duplicates for changed #vgs groups
			# if (kWPLLastUpdatedVG in config.WPL_G.store) and wpl_weigToolOpts.wei_gropnm == config.WPL_G.store[kWPLLastUpdatedVG]:
			# 	for vg2 in active_obj.vertex_groups:
			# 		if wla.strBareName(config.WPL_G.store[kWPLLastUpdatedVG], True, True, True, True, True, True) == wla.strBareName(vg2.name, True, True, True, True, True, True):
			# 			print("- bareName conflict:", config.WPL_G.store[kWPLLastUpdatedVG], vg2.name)
			# 			self.report({'ERROR'}, "Can not create VG: bareName conflict with existing. Try again.")
			# 			wpl_weigToolOpts.wei_gropnm = ""
			# 			del config.WPL_G.store[kWPLLastUpdatedVG]
			# 			return {'FINISHED'}
			self.report({'INFO'}, "Vertex group not found, creating new")
			vg = wla_attr.vg_get_or_new(active_obj, wpl_weigToolOpts.wei_gropnm)
			wpl_weigToolOpts.wei_gropnm = vg.name
		#config.WPL_G.store[kWPLLastUpdatedVG] = vg.name
		active_obj.vertex_groups.active_index = vg.index
		if active_obj.type != 'MESH':
			# gpencil require custom stuff...
			return {'FINISHED'}
		# applying selections
		selvertsAll = wla.selected_vertsIdx(active_mesh)
		if len(selvertsAll) == 0:
			self.report({'ERROR'}, "No selected vertices found")
			return {'FINISHED'}
		if active_obj.type =='MESH' and self.opt_extendOnNear == True:
			additnlIdx = []
			for e in active_mesh.edges:
				if e.vertices[0] in selvertsAll and e.vertices[1] not in selvertsAll:
					if e.vertices[1] not in additnlIdx:
						additnlIdx.append(e.vertices[1])
				if e.vertices[1] in selvertsAll and e.vertices[0] not in selvertsAll:
					if e.vertices[0] not in additnlIdx:
						additnlIdx.append(e.vertices[0])
			selvertsAll = selvertsAll+additnlIdx
		#stepval = wpl_weigToolOpts.wei_value
		for idx in selvertsAll:
			wmod = 'REPLACE'
			try:
				oldval = vg.weight(idx)
			except Exception as e:
				wmod = 'ADD'
				oldval = 0
			newval = oldval*self.opt_oldmul + self.opt_stepadd
			#newval = newval + self.opt_stepmul*stepval
			vg.add([idx], newval, wmod)
		if self.opt_otherval >= 0.0:
			for vg in active_obj.vertex_groups:
				if vg.name == wpl_weigToolOpts.wei_gropnm:
					continue
				for idx in selvertsAll:
					wmod = 'REPLACE'
					try:
						oldval = vg.weight(idx)
					except Exception as e:
						oldval = 0
						wmod = 'ADD'
					vg.add([idx], self.opt_otherval, wmod)
		if oldmode != 'EDIT':
			wla_do.select_and_change_mode(active_obj, 'EDIT')
		wla_do.select_and_change_mode(active_obj, oldmode)
		self.report({'INFO'}, 'Verts updated: '+str(len(selvertsAll)))
		return {'FINISHED'}

# class wpluvvg_smoothall(bpy.types.Operator):
# 	bl_idname = "mesh.wpluvvg_smoothall"
# 	bl_label = "Weight: smooth all"
# 	bl_options = {'REGISTER', 'UNDO'}
	
# 	opt_onActiveOnly : BoolProperty(
# 		name="Use active only",
# 		default=False
# 	)
# 	opt_normalizeAll : BoolProperty(
# 		name="Normalize weights (ALL)",
# 		default=False
# 	)
# 	opt_iters : IntProperty(
# 		name		= "Iters",
# 		default	 	= 5
# 	)

# 	def execute( self, context ):
# 		active_obj = wla.active_object(['MESH'])
# 		if active_obj is None:
# 			self.report({'ERROR'}, "Select mesh object first")
# 			return {'CANCELLED'}
# 		oldmode = wla_do.select_and_change_mode(active_obj, 'OBJECT')
# 		active_mesh = active_obj.data
# 		selvertsAll = wla.selected_vertsIdx(active_mesh)
# 		if len(selvertsAll) == 0:
# 			self.report({'ERROR'}, "No selected vertices found")
# 			return {'CANCELLED'}
# 		act_vg = None
# 		if self.opt_onActiveOnly:
# 			wpl_weigToolOpts = context.scene.wpl_uvvgOpts
# 			act_vg = active_obj.vertex_groups.get(wpl_weigToolOpts.wei_gropnm)
# 			if act_vg is None:
# 				self.report({'ERROR'}, "No active group")
# 				return {'CANCELLED'}
# 		wla_do.select_and_change_mode(active_obj,"EDIT")
# 		if act_vg is None:
# 			print("- smoothing vg: ALL")
# 			bpy.ops.object.vertex_group_smooth(group_select_mode = 'ALL', repeat = self.opt_iters)
# 		else:
# 			print("- smoothing vg:", act_vg.name)
# 			active_obj.vertex_groups.active_index = act_vg.index
# 			bpy.ops.object.vertex_group_smooth(group_select_mode = 'ACTIVE', repeat = self.opt_iters)
# 		if self.opt_normalizeAll:
# 			print("- normalizing weights")
# 			bpy.ops.mesh.select_all( action = 'SELECT' )
# 			wla_do.select_and_change_mode(active_obj,"OBJECT")
# 			for vg in active_obj.vertex_groups:
# 				bpy.ops.object.vertex_group_set_active(group = vg.name)
# 				bpy.ops.object.vertex_group_normalize()
# 			wla_do.select_and_change_mode(active_obj,"EDIT")
# 			bpy.ops.mesh.select_all( action = 'DESELECT' )
# 			wla_do.select_and_change_mode(active_obj,"OBJECT")
# 			for v in active_mesh.vertices:
# 				if v.index in selvertsAll:
# 					v.select = True
# 		wla_do.select_and_change_mode(active_obj, oldmode)
# 		return {'FINISHED'}

class wpluvvg_vgpropg(bpy.types.Operator):
	bl_idname = "mesh.wpluvvg_vgpropg"
	bl_label = "VG: Propagate on selected"
	bl_options = {'REGISTER', 'UNDO'}

	opt_influence : FloatProperty(
		name		= "Influence",
		min = 0.0, max = 1.0,
		default	 	= 1.0
	)

	opt_falloff : FloatProperty(
		name		= "Falloff",
		min = 0.0, max = 10.0,
		default	 	= 0.0
	)

	opt_action : EnumProperty(
		name="Action type", default="PROPG",
		items=(("PROPG", "Propagate", ""), 
			("SELALL", "Select verts W>0.1", ""),
			("SELHALFUP", "Select verts W>0.5", ""),
		)
	)

	def execute( self, context ):
		active_obj = wla.active_object('MESH')
		if active_obj is None:
			self.report({'ERROR'}, "No active object found")
			return {'FINISHED'}
		active_mesh = active_obj.data
		if self.opt_action in ['SELALL', 'SELHALFUP']:
			wpl_weigToolOpts = context.scene.wpl_uvvgOpts
			wla_do.select_and_change_mode(active_obj,"OBJECT")
			limit = 0.11
			if self.opt_action == 'SELHALFUP':
				limit = 0.51
			_, vg_vertsIdx, _ = wla_attr.vg_get_verts(active_obj, wpl_weigToolOpts.wei_gropnm, limit, None)
			# act_vg = active_obj.vertex_groups.get(wpl_weigToolOpts.wei_gropnm)
			# if act_vg is None:
			# 	self.report({'ERROR'}, "No active group:"+wpl_weigToolOpts.wei_gropnm)
			# 	return {'CANCELLED'}
			wla_do.select_and_change_mode(active_obj,"EDIT")
			bm = bmesh.from_edit_mesh(active_mesh)
			wla_bm.bm_selectVertEdgesFaces(bm, vg_vertsIdx, None)
			bmesh.update_edit_mesh(active_mesh)
			return {'FINISHED'}
		selvertsAll = wla.selected_vertsIdx(active_mesh)
		if len(selvertsAll) == 0:
			self.report({'ERROR'}, "No selected vertices found")
			return {'FINISHED'}
		wla_do.select_and_change_mode(active_obj,"EDIT")
		bm = bmesh.from_edit_mesh(active_mesh)
		bm.verts.ensure_lookup_table()
		bm.verts.index_update()
		histVertsIdx = wla_bm.bm_historyVertsIdx(bm)
		if len(histVertsIdx) == 0:
			self.report({'ERROR'}, "No active vertice found")
			return {'FINISHED'}
		refVertIdx = histVertsIdx[0]
		print("Ref vert:",refVertIdx,bm.verts[refVertIdx].co,"selverts",len(selvertsAll))
		vertsCo = {}
		vertsCo[refVertIdx] = bm.verts[refVertIdx].co
		distanceMax = 0.0
		for idx in selvertsAll:
			vertsCo[idx] = bm.verts[idx].co
			dst2ref = (vertsCo[idx]-vertsCo[refVertIdx]).length
			distanceMax = max(dst2ref,distanceMax)
		wla_do.select_and_change_mode(active_obj,"OBJECT")
		ok = 0
		for vg in active_obj.vertex_groups:
			try:
				valRef = vg.weight(refVertIdx)
			except Exception as e:
				valRef = 0
			for idx in selvertsAll:
				if idx == refVertIdx:
					continue
				wmod = 'REPLACE'
				try:
					oldval = vg.weight(idx)
				except Exception as e:
					oldval = 0
					wmod = 'ADD'
				dst2ref = (vertsCo[idx]-vertsCo[refVertIdx]).length
				infl = 1.0
				if self.opt_falloff > 0.0:
					infl = 1.0-dst2ref/distanceMax
					infl = min(1.0,infl)
					infl = max(0.0,infl)
					infl = pow(infl,self.opt_falloff)
				newval = oldval+(valRef-oldval)*self.opt_influence*infl
				vg.add([idx], newval, wmod)
				ok=ok+1
		wla_do.select_and_change_mode(active_obj,"EDIT")
		self.report({'INFO'}, "Propagated on "+str(ok)+" verts")
		return {'FINISHED'}

class wpluvvg_gen_isl(bpy.types.Operator):
	bl_idname = "object.wpluvvg_gen_isl"
	bl_label = "Generate Islands"
	bl_options = {'REGISTER', 'UNDO'}

	opt_generType : EnumProperty(
		name="Generation type", default="ISL",
		items=(("ISL", "Mesh island", ""), 
			("MTL", "Material Index", ""),
			("MTL_ISL", "Material+Island", ""),
			("MTL_ISL_DBG", "Material+Island BW", ""),
			)
	)

	def execute(self, context):
		active_obj0 = wla.active_object()
		if active_obj0 is None:
			self.report({'ERROR'}, "Select object first")
			return {'CANCELLED'}
		sel_all_all = wla.selected_objects(['MESH','EMPTY','ARMATURE'])
		if len(sel_all_all) == 0:
			self.report({'ERROR'}, "Select mesh object first")
			return {'CANCELLED'}
		camera_gCo, _, _, _ = wla.active_camera()
		if camera_gCo is None:
			self.report({'ERROR'}, "Camera not found: "+config.kWPLSystemMainCam)
			return {'CANCELLED'}
		sel_all_all = wla.objects_sort_by_dist(sel_all_all, camera_gCo)
		# names for VC/UV
		out_VCName = config.kWPLIslandsVC
		out_UVNameZM = config.kWPLIslandsVC + "_ZM" # Islands_ZM
		sel_of_sels = []
		non_hiers = []
		handledMeshData = set()
		for sel_obj in sel_all_all:
			if sel_obj.type not in ['EMPTY', 'ARMATURE']:
				if (sel_obj in handledMeshData) or (wla.isTokenInStr(config.kWPLObjCharFaceToken, wla.object_full_name(sel_obj))):
					continue
				handledMeshData.add(sel_obj)
				non_hiers.append(sel_obj)
				continue
			sel_hier = []
			sel_obj_subs = wla_arma.all_mesh_hiers([sel_obj])
			for sel_obj_sub in sel_obj_subs:
				if (sel_obj_sub in handledMeshData):
					continue
				handledMeshData.add(sel_obj_sub)
				sel_hier.append(sel_obj_sub)
			if len(sel_hier) > 0:
				sel_of_sels.append(sel_hier)
		if len(non_hiers) >0:
			sel_of_sels.append(non_hiers)
		for sel_all in sel_of_sels:
			islandTotal = 0.0
			objectsTotal = 0
			handledMeshData = {}
			print("- IslandsGen: Objects in group:", len(sel_all))
			for active_obj in sel_all:
				if active_obj.type not in ['MESH']:
					continue
				active_mesh = active_obj.data
				objectsTotal = objectsTotal+1
				# preventing redoing work on multi-user objects
				if active_mesh.name in handledMeshData:
					print("- skipping obj: meshdata already handled.", active_obj.name)
					continue
				if not wla.is_object_valid(active_obj, 0.01):
					print("- skipping object (scale0)", active_obj.name)
					continue
				obj_full_name = wla.object_full_name(active_obj)
				#selverts = [e.index for e in active_mesh.vertices] # all, important for curve meshing
				# Islands should use final coords - after shapekey if any
				deform_verts, _ = wla_bm.bm_getDeformedCos(active_obj)
				if deform_verts is None:
					print("- skipped, cant get deformed verts:", active_obj.name)
					continue
				# active_mesh_verts = wla_meshwrap.objectm_shpverts(active_obj, None)
				wla_do.select_and_change_mode(active_obj,'EDIT')
				bm = bmesh.from_edit_mesh(active_mesh)
				bm.faces.ensure_lookup_table()
				bm.verts.ensure_lookup_table()
				bm.verts.index_update()
				###############
				# ZDepth calcs: we need depth in GLOBAL coords, not local
				# Per-vertex may be bad on BIG faces!!! https://vk.com/topic-134845799_46945287?post=2787
				# But any averaging 100% bad for vertex-to-vertex connections on cloth, etc
				# rounding based on distance to camera good for edging, rims, outlines
				distMinPerVert = {}
				for v in bm.verts:
					v_co_g = active_obj.matrix_world @ v.co
					zdepth = (camera_gCo-v_co_g).length
					zdepth = wla.math_clipFraction(zdepth, 0.2)
					distMinPerVert[v.index] = zdepth
				# Islands calcs:
				segmentMap = None
				if self.opt_generType == 'MTL':
					segmentMap = "<mat_id>"
				if self.opt_generType == 'MTL_ISL' or self.opt_generType == 'MTL_ISL_DBG':
					segmentMap = "<island>_<mat_id>"
				# islandId is numerated from last IslandsId used - so numbering continous for all selected objects
				islandsData, islandPerFace, _ = wla_edger.segmentMesh(active_obj, None, segmentMap, islandTotal)
				islandId = islandsData[0]
				if len(islandPerFace) == 0:
					print("- skipped, no islands found:", active_obj.name)
					continue
				# calculating min-max vdepth per island
				distMinPerIsland = {}
				distMaxPerIsland = {}
				distVertsPerIsland = {}
				distAvgCoPerIsland = {}
				for poly in active_mesh.polygons:
					ipoly = poly.index
					for idx, lIdx in enumerate(active_mesh.polygons[ipoly].loop_indices):
						isls = []
						ivdx = active_mesh.polygons[ipoly].vertices[idx]
						if ipoly in islandPerFace:
							isls.append(islandPerFace[ipoly])
						for isl in isls:
							if isl not in distMinPerIsland:
								distMinPerIsland[isl] = -1
								distMaxPerIsland[isl] = -1
								distVertsPerIsland[isl] = 0
								distAvgCoPerIsland[isl] = Vector((0,0,0))
							# we need depth in GLOBAL coords, not local
							# v = active_mesh_verts[ivdx]
							# v_co_g = active_obj.matrix_world @ v.co
							v_co_g = active_obj.matrix_world @ deform_verts[ivdx]
							zdepth = (camera_gCo-v_co_g).length
							if zdepth < distMinPerIsland[isl] or distMinPerIsland[isl] < 0.0:
								distMinPerIsland[isl] = zdepth
							if zdepth > distMaxPerIsland[isl] or distMaxPerIsland[isl] < 0.0:
								distMaxPerIsland[isl] = zdepth
							distAvgCoPerIsland[isl] = distAvgCoPerIsland[isl] + v_co_g
							distVertsPerIsland[isl] = distVertsPerIsland[isl] + 1.0
				print("- obj phase1", active_obj.name, islandId, len(islandPerFace))
				handledMeshData[active_mesh.name] = (islandId, islandPerFace, distMinPerIsland, distMaxPerIsland, distAvgCoPerIsland, distVertsPerIsland)
				islandTotal = islandId
			# Continous BW plane order for BW-DBG mapping
			colorsRGB = wla_attr.vc_glob_rand_colors(islandTotal)
			islandsBw_list = []
			for active_obj in sel_all:
				if active_obj.type not in ['MESH']:
					continue
				active_mesh = active_obj.data
				if active_mesh.name not in handledMeshData:
					continue
				(islandId, islandPerFace, distMinPerIsland, distMaxPerIsland, distAvgCoPerIsland, distVertsPerIsland) = handledMeshData[active_mesh.name]
				for isl in distMinPerIsland:
					islandsBw_list.append( (isl, distMinPerIsland[isl]) )
			islandsBw_list = sorted(islandsBw_list, key=lambda pr: pr[1], reverse=True)
			if len(islandsBw_list) == 1:
				isl0 = islandsBw_list[0][0]
				islandsBw_frac = {}
				islandsBw_frac[isl0] = 1.0
			else:
				islandsBw_frac = {vv[0]:(i/(len(islandsBw_list)-1)) for i,vv in enumerate(islandsBw_list)}
				if len(islandsBw_frac)>10:
					print("- BW: shuffling for more contrast")
					bw_keys = sorted(list(islandsBw_frac.keys()))
					for i in range(len(bw_keys)):
						rnd_i2 = random.randint(i-2,i+2)
						if rnd_i2<0 or rnd_i2 >= len(islandsBw_frac):
							continue
						k1 = bw_keys[i]
						k2 = bw_keys[rnd_i2]
						tmp = islandsBw_frac[k1]
						islandsBw_frac[k1] = islandsBw_frac[k2]
						islandsBw_frac[k2] = tmp
			for active_obj in sel_all:
				if active_obj.type not in ['MESH']:
					continue
				wla_do.select_and_change_mode(active_obj,'OBJECT')
				active_mesh = active_obj.data
				if active_mesh.name not in handledMeshData:
					continue
				(islandId, islandPerFace, distMinPerIsland, distMaxPerIsland, distAvgCoPerIsland, distVertsPerIsland) = handledMeshData[active_mesh.name]
				# print("- islMin", distMinPerIsland)
				# print("- islMax", distMaxPerIsland)
				# should be created already!!!
				wla_attr.vc_obj_ensure(active_obj, out_VCName)
				wla_attr.uv_obj_ensure(active_obj, out_UVNameZM)
				palette_mapvc = active_mesh.vertex_colors.get(out_VCName)
				minmax_zm_mapuv = active_mesh.uv_layers.get(out_UVNameZM)
				if (palette_mapvc.name != out_VCName) or (minmax_zm_mapuv.name != out_UVNameZM):
					print("- ERROR: Failed to keep VC/UV maps", active_obj.name, palette_mapvc.name, out_VCName, minmax_zm_mapuv.name, out_UVNameZM)
					continue
				if minmax_zm_mapuv is None or palette_mapvc is None:
					print("- ERROR: Failed to create VC/UV maps", active_obj.name)
					continue
				# random colors should differ even between differen objects with 1 island
				# so need global color queue with strong randomness...
				for poly in active_mesh.polygons:
					ipoly = poly.index
					for idx, lIdx in enumerate(active_mesh.polygons[ipoly].loop_indices):
						ivdx = active_mesh.polygons[ipoly].vertices[idx]
						islfrac = None
						if ipoly in islandPerFace:
							islfrac = islandPerFace[ipoly]
						zdepthmin = 0.0
						zdepthmax = 0.0
						if islfrac is not None and (islfrac in distAvgCoPerIsland):
							#avgco = distAvgCoPerIsland[islfrac]/distVertsPerIsland[islfrac]
							zdepthmin = distMinPerIsland[islfrac]
							zdepthmax = distMaxPerIsland[islfrac]
							if ivdx in distMinPerVert:
								zdepthmin = distMinPerVert[ivdx]
							if wla.isTokenInStr(config.kWPLSystemOslNoBbox, obj_full_name):
								#print("- Islands_ZM: faking data for Far objects")
								zdepthmin = 0.0
							#minmax_xy_mapuv.data[lIdx].uv = Vector(( avgco[0], avgco[1]))
							minmax_zm_mapuv.data[lIdx].uv = Vector(( zdepthmax, zdepthmin))
						else:
							print("- Islands_ZM: unmapped poly", islfrac, ipoly, active_obj.name)
						bw_frac = islandsBw_frac[islfrac]
						bw_col = wla.math_lerp1D(bw_frac, 0.2, 1.0)
						newcolor = colorsRGB[int(islfrac)]
						if self.opt_generType == 'MTL_ISL_DBG':
							newcolor = (bw_col,bw_col,bw_col)
						else:
							newcolor = (bw_col,newcolor[1],newcolor[2]) # only R channel
						palette_mapvc.data[lIdx].color = (newcolor[0],newcolor[1],newcolor[2],1.0)
						#print("- Islands: lIdx", islfrac, lIdx, newcolor)
				print("- obj phase2", active_obj.name, islandId, len(islandPerFace))
		if active_obj0 is not None:
			wla_do.select_and_change_mode(active_obj0,"OBJECT")
			wla_do.select_and_activate_multi(sel_all, active_obj0)
		self.report({'INFO'}, 'Done. Groups:'+str(len(sel_of_sels))+", Objects:"+str(len(sel_all)))
		return {'FINISHED'}

class wpluvvg_unwrap_edges_norm(bpy.types.Operator):
	bl_idname = "object.wpluvvg_unwrap_edges_norm"
	bl_label = "UV: Unwrap from normals"
	bl_options = {'REGISTER', 'UNDO'}

	opt_uvPrefx : StringProperty(
		name = "UV Name",
		default = config.kWPLGridUV
	)
	opt_rotZ : FloatProperty(
		name		= "Z-Rotation",
		default	 	= 0.0
	)
	opt_scaleTotal : FloatProperty(
		name		= "Scale",
		default	 	= 1.0
	)
	opt_offsetChannls : FloatVectorProperty(
		name="Offset channels",
		size=2,
		default=(0.0, 0.0)
	)
	def execute(self, context):
		active_obj = wla.active_object(['MESH'])
		if active_obj is None:
			self.report({'ERROR'}, "Select mesh object first")
			return {'CANCELLED'}
		wla_do.select_and_change_mode(active_obj, "OBJECT")
		active_mesh = active_obj.data
		bakemap_pref = self.opt_uvPrefx
		wla_attr.uv_obj_ensure(active_obj, bakemap_pref)
		wla_do.select_and_change_mode(active_obj, "EDIT")
		bm = bmesh.from_edit_mesh( active_mesh )
		bm.verts.ensure_lookup_table()
		bm.faces.ensure_lookup_table()
		bm.verts.index_update()
		affeFaces = []
		fNorms = Vector((0,0,0))
		fCentr = Vector((0,0,0))
		fTang = Vector((0,0,0))
		for face in bm.faces:
			if face.select:
				affeFaces.append(face)
				fNorms = fNorms + face.normal
				fCentr = fCentr + face.calc_center_median()
				fTang = fTang + face.calc_tangent_edge_pair()
		if len(affeFaces) == 0:
			self.report({'ERROR'}, "Select some faces first")
			return {'CANCELLED'}
		scaleFixed = self.opt_scaleTotal
		if abs(scaleFixed) < 0.00001:
			scaleFixed = 1.0
		fNorms = fNorms / len(affeFaces)
		fCentr = fCentr / len(affeFaces)
		fTang = fTang / len(affeFaces)
		fMatInv = wla.math_matrix4axis(fCentr, fTang, None, fNorms).inverted()
		rotMat = Matrix.Rotation( math.radians(self.opt_rotZ), 4, 'Z')
		uv_layer_ob = bm.loops.layers.uv.get(bakemap_pref)
		vertMapU = {}
		vertMapV = {}
		for face in affeFaces:
			for v in face.verts:
				if v.index in vertMapU:
					continue
				v_co_ll = fMatInv @ v.co
				v_co_ll.rotate(rotMat)
				vertMapU[v.index] = v_co_ll[0] / scaleFixed + self.opt_offsetChannls[0]
				vertMapV[v.index] = v_co_ll[1] / scaleFixed + self.opt_offsetChannls[1]
		for face in affeFaces:
			for loop in face.loops:
				vert = loop.vert
				if vert.index in vertMapU:
					loop[uv_layer_ob].uv = (vertMapU[vert.index], vertMapV[vert.index])
		bmesh.update_edit_mesh(active_mesh)
		wla_do.select_and_change_mode(active_obj, "EDIT")
		self.report({'INFO'}, "Faces baked (nrm): "+str(len(affeFaces)))
		return {'FINISHED'}

# class wpluvvg_unwrap_edges_view(bpy.types.Operator):
# 	bl_idname = "object.wpluvvg_unwrap_edges_view"
# 	bl_label = "UV: Unwrap from cam"
# 	bl_options = {'REGISTER', 'UNDO'}

# 	opt_uvPrefx : StringProperty(
# 		name = "UV Name",
# 		default = config.kWPLGridUV
# 	)
# 	opt_vgSeedU : StringProperty(
# 		name = "U/Y coord",
# 		default = "_sel2"
# 	)
# 	opt_vgSeedV : StringProperty(
# 		name = "V/X coord",
# 		default = "_sel1"
# 	)
# 	opt_viewRot : FloatProperty(
# 		name		= "Angle",
# 		default	 	= 0.0
# 	)
# 	opt_scaleTotal : FloatProperty(
# 		name		= "Scale",
# 		default	 	= 1.0
# 	)
# 	opt_Eval3D: StringProperty(
# 		name="3D coords transform",
# 		default="( pX * 1.0, pY * 1.0, pZ * 1.0)"
# 	)
# 	opt_Eval2D: StringProperty(
# 		name="2D coords transform",
# 		default="( pX * 1.0 + 0.0, pY * 1.0 + 0.0)"
# 	)
# 	# opt_scaleChannls : FloatVectorProperty(
# 	# 	name="Scale channels",
# 	# 	size=3,
# 	# 	default=(1.0, 1.0, 1.0)
# 	# )
# 	# opt_shiftChannls : FloatVectorProperty(
# 	# 	name="Shift channels",
# 	# 	size=2,
# 	# 	default=(0.0, 0.0)
# 	# )
# 	def execute(self, context):
# 		active_obj = wla.active_object(['MESH'])
# 		if active_obj is None:
# 			self.report({'ERROR'}, "Select mesh object first")
# 			return {'CANCELLED'}
# 		# camera_obj = wla.object_by_name(config.kWPLSystemMainCam)
# 		# if camera_obj is None:
# 		# 	self.report({'ERROR'}, "Camera not found: "+config.kWPLSystemMainCam)
# 		# 	return {'CANCELLED'}
# 		wla_do.select_and_change_mode(active_obj, "OBJECT")
# 		vmapU_vg = wla_attr.vg_get_by_name(active_obj, self.opt_vgSeedU)
# 		vmapV_vg = wla_attr.vg_get_by_name(active_obj, self.opt_vgSeedV)
# 		if vmapU_vg is None or vmapV_vg is None:
# 			self.report({'ERROR'}, "Can`t find seed groups")
# 			return {'CANCELLED'}
# 		Eval2D_py = None
# 		Eval3D_py = None
# 		try:
# 			Eval2D_py = compile(self.opt_Eval2D, "<string>", "eval")
# 			Eval3D_py = compile(self.opt_Eval3D, "<string>", "eval")
# 		except Exception as e:
# 			self.report({'ERROR'}, "Eval compilation: syntax error")
# 			return {'CANCELLED'}
# 		vmapU = wla_attr.vg_get_weightMap(active_obj, vmapU_vg.name)
# 		print("- using",vmapU_vg.name,len(vmapU))
# 		vmapV = wla_attr.vg_get_weightMap(active_obj, vmapV_vg.name)
# 		print("- using",vmapV_vg.name,len(vmapV))
# 		# getting center vertex... Islands IGNORED???
# 		vIdxCenter = None
# 		for vIdx in vmapU:
# 			if vIdx in vmapV:
# 				vIdxCenter = vIdx
# 				break
# 		if vIdxCenter is None:
# 			self.report({'ERROR'}, "Seed groups not intersecting")
# 			return {'CANCELLED'}
# 		scaleFixed = 0.004 * self.opt_scaleTotal
# 		active_mesh = active_obj.data
# 		bakemap_pref = self.opt_uvPrefx
# 		wla_attr.uv_obj_ensure(active_obj, bakemap_pref)
# 		modf_cache = {}
# 		wla_do.modf_toggle(active_obj, wla_do.kWPLModifsHeavies+['ARMATURE'], False, modf_cache)
# 		wla_do.select_and_change_mode(active_obj, "EDIT")
# 		bm = bmesh.from_edit_mesh( active_mesh )
# 		bm.verts.ensure_lookup_table()
# 		bm.faces.ensure_lookup_table()
# 		bm.verts.index_update()
# 		uv_layer_ob = bm.loops.layers.uv.get(bakemap_pref)
# 		vertMapU = {}
# 		vertMapV = {}
# 		vCenter = bm.verts[vIdxCenter]
# 		vCenter2dCo = wla.view_point3dToPoint2d(active_obj.matrix_world @ vCenter.co) -> active_view_region(pt)
# 		if vCenter2dCo is None:
# 			self.report({'ERROR'}, "Intersection not projectable")
# 			return {'CANCELLED'}
# 		for v in bm.verts:
# 			v_co = v.co - vCenter.co
# 			#v_co_ll = Vector((v_co[0]*self.opt_scaleChannls[0], v_co[1]*self.opt_scaleChannls[1], v_co[2]*self.opt_scaleChannls[2]))
# 			pX = v_co[0] # 4EVAL
# 			pY = v_co[1] # 4EVAL
# 			pZ = v_co[2] # 4EVAL
# 			v_co_ll = Vector( eval(Eval3D_py) )
# 			v_co_view = wla.view_point3dToPoint2d(active_obj.matrix_world @ (vCenter.co + v_co_ll)) -> active_view_region(pt)
# 			if v_co_view is None:
# 				continue
# 			v_co_view = (v_co_view - vCenter2dCo)
# 			pX = v_co_view[0] # 4EVAL
# 			pY = v_co_view[1] # 4EVAL
# 			v_co_view_ll = Vector( eval(Eval2D_py) ).to_3d() * scaleFixed
# 			rot_mat = Matrix.Rotation( math.radians(self.opt_viewRot), 4, 'Z')
# 			v_co_view_ll.rotate(rot_mat)
# 			vertMapU[v.index] = v_co_view_ll[0] # + self.opt_shiftChannls[0]
# 			vertMapV[v.index] = v_co_view_ll[1] # + self.opt_shiftChannls[1]
# 		for face in bm.faces:
# 			for loop in face.loops:
# 				vert = loop.vert
# 				if vert.index in vertMapU:
# 					loop[uv_layer_ob].uv = (vertMapU[vert.index], vertMapV[vert.index])
# 		bmesh.update_edit_mesh(active_mesh)
# 		wla_do.select_and_change_mode(active_obj, "OBJECT")
# 		wla_do.modf_toggle(active_obj, wla_do.kWPLModifsHeavies+['ARMATURE'], None, modf_cache)
# 		self.report({'INFO'}, "Vertices baked (view): "+str(len(vertMapU)))
# 		return {'FINISHED'}

# class wpluvvg_unwrap_edges_df(bpy.types.Operator):
# 	bl_idname = "object.wpluvvg_unwrap_edges_df"
# 	bl_label = "UV: Unwrap with distance field/polar coords"
# 	bl_options = {'REGISTER', 'UNDO'}

# 	opt_uvPrefx : StringProperty(
# 		name = "UV Name",
# 		default = config.kWPLGridUV
# 	)

# 	def execute(self, context):
# 		sel_all = wla.selected_objects(wla_meshwrap.kWPLMESHWRAP_TYPES)
# 		if len(sel_all) == 0:
# 			self.report({'ERROR'}, "Select objects first")
# 			return {'CANCELLED'}
# 		active_obj = None
# 		points_co_g = []
# 		for obj in sel_all:
# 			if config.kWPLObjUvRefToken in obj.name:
# 				active_obj = obj
# 				continue
# 			mw = wla_meshwrap.object_wrappedmesh(obj)
# 			for vIdx in mw.all_vertsIdx():
# 				v = mw.vertices[vIdx]
# 				v_co_g = obj.matrix_world @ v.co
# 				points_co_g.append(v_co_g)
# 		if active_obj is None:
# 			self.report({'ERROR'}, "Wriw_UV object not found")
# 			return {'CANCELLED'}
# 		wla_do.select_and_change_mode(active_obj, "OBJECT")
# 		active_mesh = active_obj.data
# 		bakemap_pref = self.opt_uvPrefx
# 		wla_attr.uv_obj_ensure(active_obj, bakemap_pref)
# 		modf_cache = {}
# 		wla_do.modf_toggle(active_obj, wla_do.kWPLModifsHeavies+['ARMATURE'], False, modf_cache)
# 		wla_do.select_and_change_mode(active_obj, "EDIT")
# 		bm = bmesh.from_edit_mesh( active_mesh )
# 		bm.verts.ensure_lookup_table()
# 		bm.faces.ensure_lookup_table()
# 		bm.verts.index_update()
# 		uv_layer_ob = bm.loops.layers.uv.get(bakemap_pref)
# 		vertMapU, vertMapV = wla_bm.bm_pointcloudDistmap_v01(active_obj, bm, points_co_g)
# 		for face in bm.faces:
# 			for loop in face.loops:
# 				vert = loop.vert
# 				if vert.index in vertMapU:
# 					loop[uv_layer_ob].uv = (vertMapU[vert.index], vertMapV[vert.index])
# 		bmesh.update_edit_mesh(active_mesh)
# 		wla_do.select_and_change_mode(active_obj, "OBJECT")
# 		wla_do.modf_toggle(active_obj, wla_do.kWPLModifsHeavies+['ARMATURE'], None, modf_cache)
# 		self.report({'INFO'}, "Vertices baked (df): "+str(len(vertMapU))+" pc: "+str(len(points_co_g)))
# 		return {'FINISHED'}

class wpluvvg_unwrap_vgbind(bpy.types.Operator):
	bl_idname = "object.wpluvvg_unwrap_vgbind"
	bl_label = "UV: Unwrap for BIND"
	bl_options = {'REGISTER', 'UNDO'}
	
	opt_uvPrefx : StringProperty(
		name = "UV Name",
		default = config.kWPLGridUV
	)

	def execute(self, context):
		active_obj = wla.active_object(['MESH'])
		if active_obj is None:
			self.report({'ERROR'}, "Select mesh object first")
			return {'CANCELLED'}
		active_mesh = active_obj.data
		bakemap_pref = self.opt_uvPrefx
		uv_layer_ob = wla_attr.uv_obj_ensure(active_obj, bakemap_pref)
		# disabling modifyers - can change verts positions inside EDIT mode -> non-stable unwrap -> symmetry problems
		modf_cache = {}
		wla_do.modf_toggle(active_obj, wla_do.kWPLModifsHeavies+['ARMATURE'], False, modf_cache)
		wla_do.select_and_change_mode(active_obj, "EDIT")
		bm = bmesh.from_edit_mesh( active_mesh )
		bm.verts.ensure_lookup_table()
		bm.faces.ensure_lookup_table()
		bm.verts.index_update()
		uv_layer_ob = bm.loops.layers.uv.get(bakemap_pref)
		uv_dup_verts = []
		for face in bm.faces:
			for loop in face.loops:
				vert = loop.vert
				vU = vert.co[0]*100+abs(vert.co[2])*math.copysign(3, vert.co[0])
				vV = vert.co[1]*100+abs(vert.co[2])*math.copysign(5, vert.co[1])
				vU = wla.math_clipFraction(vU, config.kWPLUVPrecision)
				vV = wla.math_clipFraction(vV, config.kWPLUVPrecision)
				#print("- UV", vert.index, vU, vV)
				loop[uv_layer_ob].uv = (vU, vV)
		# checking final duplications
		bmesh.update_edit_mesh(active_mesh)
		wla_do.select_and_change_mode(active_obj, "OBJECT")
		_, _, vertDupes = wla_vgbind.bm_getUvMappingAtMeshData(active_obj.data, bakemap_pref)
		if (vertDupes is not None) and len(vertDupes) > 0:
			print("- Post-check: UV dupes found", vertDupes)
			for vIdx in vertDupes:
				if vIdx not in uv_dup_verts:
					uv_dup_verts.append(vIdx)
		wla_do.select_and_change_mode(active_obj, "EDIT")
		bm = bmesh.from_edit_mesh( active_mesh )
		bm.verts.ensure_lookup_table()
		bm.faces.ensure_lookup_table()
		bm.verts.index_update()
		uv_layer_ob = bm.loops.layers.uv.get(bakemap_pref)
		if len(uv_dup_verts)>0:
			# hard rewrap from coordinates...
			print("- rewrapping duplications", len(uv_dup_verts))
			for face in bm.faces:
				for loop in face.loops:
					vert = loop.vert
					if vert.index in uv_dup_verts:
						vUV_fallback = wla.math_vecSwizzlePick( (math.copysign(10, vert.co[0])+vert.co[0]*100, math.copysign(10, vert.co[1])+vert.co[1]*100, math.copysign(10, vert.co[2])+vert.co[2]*100), 'XZ' )
						# adding Y sign into account... or symmetrical parts may get dupes
						vUV_fallback[1] = vUV_fallback[1] + wla.math_clipFraction(vert.co[1]*100,100)
						vU = wla.math_clipFraction(vUV_fallback[0]*3, config.kWPLUVPrecision)*10
						vV = wla.math_clipFraction(vUV_fallback[1]*3, config.kWPLUVPrecision)*10
						#print("- UV dedupe", vert.index, vU, vV)
						loop[uv_layer_ob].uv = (vU, vV)
		bmesh.update_edit_mesh(active_mesh)
		wla_do.select_and_change_mode(active_obj, "OBJECT")
		wla_do.modf_toggle(active_obj, wla_do.kWPLModifsHeavies+['ARMATURE'], None, modf_cache)
		self.report({'INFO'}, "Vertices baked (bind):" + str(len(active_mesh.vertices)))
		# double-checking
		if wla_vgbind.obj_checkUnwrap(active_obj, True) == False:
			self.report({'ERROR'}, "Failed to force antidup (cleanup needed)")
		return {'FINISHED'}


class wpluvvg_unwrap_edges_grid(bpy.types.Operator):
	bl_idname = "object.wpluvvg_unwrap_edges_grid"
	bl_label = "UV: Unwrap from edges"
	bl_options = {'REGISTER', 'UNDO'}

	opt_tranfType : EnumProperty(
		name="Unwrap type", default="DST_GRD",
		items=(("DST_GRD", "Grid", ""), ("DST_PRJ", "DistancePRJ", ""))
	)
	opt_selectedOnly : BoolProperty(
		name = "Selected only",
		default = False
	)
	opt_uvPrefx : StringProperty(
		name = "UV Name",
		default = config.kWPLGridUV
	)
	opt_vgSeedV : StringProperty(
		name = "V/X verts",
		default = "_sel1"
	)
	opt_vgSeedU : StringProperty(
		name = "U/Y verts",
		default = ""
	)
	opt_vgSeedVsec : StringProperty(
		name = "V-secondaries",
		default = "" # _sel2
	)
	opt_uvSigned : EnumProperty(
		name="Sign type", default="AUTO",
		items=(("AUTO", "Auto", ""), ("NONE", "None", ""))
	)
	opt_scaleTotal : FloatProperty(
		name		= "Scale",
		default	 	= 1.0
	)
	opt_scaleChannls : FloatVectorProperty(
		name="Scale channels",
		size=2,
		default=(1.0, 1.0)
	)

	# Running as separate dialog
	def invoke(self, context, event):
		return context.window_manager.invoke_props_dialog(self, width = 200)

	def execute(self, context):
		active_obj = wla.active_object(['MESH'])
		if active_obj is None:
			self.report({'ERROR'}, "Select mesh object first")
			return {'CANCELLED'}
		if config.kWPLObjCharHairsPostfix in active_obj.name:
			self.report({'ERROR'}, "Hairs not allowed") # @as113 FUCKUP
			return {'CANCELLED'}
		oldmode = wla_do.select_and_change_mode(active_obj, 'OBJECT')
		active_mesh = active_obj.data
		bakemap_pref = self.opt_uvPrefx
		selverts = wla.selected_vertsIdx(active_mesh)
		selfaces = wla.selected_facesIdx(active_mesh)
		vmapV = None
		vmapV_vg = wla_attr.vg_get_by_name(active_obj, bakemap_pref+self.opt_vgSeedV)
		if vmapV_vg is None:
			vmapV_vg = wla_attr.vg_get_by_name(active_obj, self.opt_vgSeedV)
		if vmapV_vg is not None:
			vmapV = wla_attr.vg_get_weightMap(active_obj, vmapV_vg.name)
			print("- using",vmapV_vg.name,len(vmapV))

		vmapVsec = None
		vmapVsec_vg = wla_attr.vg_get_by_name(active_obj, bakemap_pref+self.opt_vgSeedVsec)
		if vmapVsec_vg is None:
			vmapVsec_vg = wla_attr.vg_get_by_name(active_obj, self.opt_vgSeedVsec)
		if vmapVsec_vg is not None:
			vmapVsec = wla_attr.vg_get_weightMap(active_obj, vmapVsec_vg.name)
			print("- using",vmapVsec_vg.name,len(vmapVsec))

		vmapU = None
		vmapU_vg = wla_attr.vg_get_by_name(active_obj, bakemap_pref+self.opt_vgSeedU)
		if vmapU_vg is None:
			vmapU_vg = wla_attr.vg_get_by_name(active_obj, self.opt_vgSeedU)
		if vmapU_vg is not None:
			vmapU = wla_attr.vg_get_weightMap(active_obj, vmapU_vg.name)
			print("- using",vmapU_vg.name,len(vmapU))

		vmapV = wla.coalesce(vmapV, [])
		vmapU = wla.coalesce(vmapU, [])
		# vmapVsec = wla.coalesce(vmapVsec, [])
		if len(vmapV) == 0 and len(vmapU) == 0:
			if 'EDIT' in oldmode and len(selfaces) == 0 and len(selverts) >= 3:
				# Precreating seed vg and using it
				print("- precreating seed verts from selection", self.opt_vgSeedV, len(selverts))
				wla_attr.vg_add_verts2vg(active_obj, self.opt_vgSeedV, selverts, 1.0)
				vmapV = wla_attr.vg_get_weightMap(active_obj, self.opt_vgSeedV)
		if len(vmapV) == 0: # len(vmapU) MAY be []
			self.report({'ERROR'}, "No seed verts found")
			return {'FINISHED'}
		# preparing data layers
		uv_layer_ob = wla_attr.uv_obj_ensure(active_obj, bakemap_pref)
		uv_layer_ob = active_mesh.uv_layers.get(bakemap_pref)
		deform_verts, _ = wla_bm.bm_getDeformedCos(active_obj)
		cutlineVerts = None
		cutlineMap, _ = wla_attr.vg_get_weightMapByTok(active_obj, config.kWPLSuppVGScriptCutlin)
		if cutlineMap is not None:
			cutlineVerts = list(cutlineMap.keys())
		# disabling modifyers - can change verts positions inside EDIT mode -> non-stable unwrap -> symmetry problems
		modf_cache = {}
		wla_do.modf_toggle(active_obj, wla_do.kWPLModifsHeavies+['ARMATURE'], False, modf_cache)
		wla_do.select_and_change_mode(active_obj, "EDIT")
		bm = bmesh.from_edit_mesh( active_mesh )
		bm.verts.ensure_lookup_table()
		bm.faces.ensure_lookup_table()
		bm.verts.index_update()
		stepU_vIdx = []
		stepV_vIdx = []
		stepVsecI_vIdx = []
		stepVsecO_vIdx = []
		for v in bm.verts:
			if (vmapU is not None) and (v.index in vmapU):
				if vmapU[v.index] > 0.95:
					stepU_vIdx.append(v.index)
				# elif vmapU[v.index] > 0.45:
				# 	stepU_vIdxLeft = v.index
			if (vmapV is not None) and (v.index in vmapV):
				if vmapV[v.index] > 0.95:
					stepV_vIdx.append(v.index)
				# elif vmapV[v.index] > 0.45:
				# 	stepV_vIdxLeft = v.index
			if (vmapVsec is not None) and (v.index in vmapVsec):
				if vmapVsec[v.index] > 0.95:
					stepVsecO_vIdx.append(v.index)
				elif vmapVsec[v.index] > 0.45:
					stepVsecI_vIdx.append(v.index)
		if len(stepU_vIdx) == 0 and len(stepV_vIdx) > 0:
			vert_curves = wla_bm.bm_splitVertsByConnection(bm, stepV_vIdx, True, None, None)
			for curv_vIdx in vert_curves:
				if len(curv_vIdx) >= 3:
					vIdx_cnt = curv_vIdx[int(len(curv_vIdx)/2)]
					stepU_vIdx.append(vIdx_cnt)
		# elif len(stepV_vIdx) == 0 and len(stepU_vIdx) > 0:
		# 	# using middle-verts as start points for bm_geodesicDistmapAlong_v01 calcualtions
		# 	vert_curves = wla_bm.bm_splitVertsByConnection(bm, stepU_vIdx, True, None, None)
		# 	for curv_vIdx in vert_curves:
		# 		if len(curv_vIdx) >= 3:
		# 			vIdx_cnt = curv_vIdx[int(len(curv_vIdx)/2)]
		# 			stepV_vIdx.append(vIdx_cnt)
		print("- seedU:",len(stepU_vIdx),"seedV",len(stepV_vIdx))
		if len(stepU_vIdx) == 0 or len(stepV_vIdx) == 0:
			self.report({'ERROR'}, "No seed verts found")
			return {'FINISHED'}
		vertLeftListU = None
		vertLeftListV = None
		vertDistMapU = None
		vertDistMapV = None
		walkMaxDist = None
		walkMaxSteps = 100
		vertsPerIslands = wla_bm.bm_expandVertsToIslands_v02(bm, None, cutlineVerts)
		stepU_vIdx = wla_bm.bm_sortVertsByConnection(bm, stepU_vIdx, True, False)
		stepV_vIdx = wla_bm.bm_sortVertsByConnection(bm, stepV_vIdx, True, False)
		vertDstMapV_r, vertDstMapV_leftr = wla_bm.bm_regularDistmap_v01(bm, stepV_vIdx, walkMaxDist, vertsPerIslands, deform_verts)
		if len(stepU_vIdx) > 1:
			vertDstMapU_r, vertDstMapU_leftr = wla_bm.bm_regularDistmap_v01(bm, stepU_vIdx, walkMaxDist, vertsPerIslands, deform_verts)
		else:
			vertDstMapU_r = vertDstMapV_r
			vertDstMapU_leftr = vertDstMapV_leftr
		if self.opt_tranfType == 'DST_PRJ':
			vertDistMapU = vertDstMapU_r
			vertDistMapV = vertDstMapV_r
			vertLeftListV = vertDstMapV_leftr
			vertLeftListU = vertDstMapU_leftr
		if self.opt_tranfType == 'DST_GRD':
			vertDistMapU = None
			vertLeftListU = None
			vertOrigMapU = None
			vertDistMapV = None
			vertLeftListV = None
			vertOrigMapV = None
			isRegreedrU = False
			if set(stepU_vIdx).issubset(set(stepV_vIdx)) and len(stepV_vIdx)>len(stepU_vIdx):
				isRegreedrU = True
			isRegreedrV = False
			if set(stepV_vIdx).issubset(set(stepU_vIdx)) and len(stepU_vIdx)>len(stepV_vIdx):
				isRegreedrV = True
			if isRegreedrU == False:
				print("- GRID: generating U", len(stepU_vIdx))
				initial_vertCurves = wla_bm.bm_splitVertsByConnection(bm, stepU_vIdx, True, None, None)
				vertDistMapU, _, vertLeftListU, vertOrigMapU = wla_bm.bm_geodesicDistmap_v05(bm, initial_vertCurves, walkMaxSteps, walkMaxDist, False, True)
			if isRegreedrV == False:
				print("- GRID: generating V", len(stepV_vIdx))
				initial_vertCurves = wla_bm.bm_splitVertsByConnection(bm, stepV_vIdx, True, None, None)
				vertDistMapV, _, vertLeftListV, vertOrigMapV = wla_bm.bm_geodesicDistmap_v05(bm, initial_vertCurves, walkMaxSteps, walkMaxDist, False, True)
			if isRegreedrU == True and vertOrigMapV is not None:
				print("- GRID: generating U along V", len(stepV_vIdx))
				curvesV_vIdx = wla_bm.bm_splitVertsByConnection(bm, stepV_vIdx, True, None, None)
				vertDistMapU, _, vertLeftListU = wla_bm.bm_geodesicDistmapAlong_v01(bm, stepU_vIdx, curvesV_vIdx, vertOrigMapV, True)
				print("- GRID: U along V: secondary front", len(stepVsecO_vIdx), len(stepVsecI_vIdx))
				if len(stepVsecO_vIdx) > 0 and len(stepVsecI_vIdx) > 0:
					initial_vertCurvesI = wla_bm.bm_splitVertsByConnection(bm, stepVsecI_vIdx, True, None, None)
					vertDistMapVsecI, _, _, vertOrigMapVsecI = wla_bm.bm_geodesicDistmap_v05(bm, initial_vertCurvesI, walkMaxSteps, walkMaxDist, False, True)
					initial_vertCurvesO = wla_bm.bm_splitVertsByConnection(bm, stepVsecO_vIdx, True, None, None)
					stepVsecOcnt_vIdx = []
					for curv_vIdx in initial_vertCurvesO:
						if len(curv_vIdx) >= 3:
							vIdx_cnt = curv_vIdx[int(len(curv_vIdx)/2)]
							stepVsecOcnt_vIdx.append(vIdx_cnt)
					vertDistMapVsecO, _, _, vertOrigMapVsecO = wla_bm.bm_geodesicDistmap_v05(bm, initial_vertCurvesO, walkMaxSteps, walkMaxDist, False, True, None, stepVsecI_vIdx)
					vertDistMapUsecO, _, _ = wla_bm.bm_geodesicDistmapAlong_v01(bm, stepVsecOcnt_vIdx, initial_vertCurvesO, vertOrigMapVsecO, True)
					for vIdx in vertDistMapV:
						if (vIdx in vertDistMapVsecO):
							secIorig = vertOrigMapVsecI[vIdx]
							secOorig = vertOrigMapVsecO[vIdx]
							vertDistMapV[vIdx] = vertDistMapVsecO[vIdx] #+ vertDistMapV[secIorig]
							vertDistMapU[vIdx] = vertDistMapUsecO[vIdx] #+ (vertDistMapU[secIorig] - vertDistMapU[secOorig])
							# bm.verts[vIdx].select = True
			# if isRegreedrV == True and vertOrigMapU is not None:
			# 	print("- GRID: generating V along U", len(stepU_vIdx))
			# 	curvesU_vIdx = wla_bm.bm_splitVertsByConnection(bm, stepU_vIdx, True, None, None)
			# 	vertDistMapV, _, vertLeftListV = wla_bm.bm_geodesicDistmapAlong_v01(bm, stepV_vIdx, curvesU_vIdx, vertOrigMapU, True) # vertDistMapV
		negzoneUScale = 1.0
		negzoneVScale = 1.0
		negzoneU = None
		negzoneV = None
		if self.opt_uvSigned != 'NONE':
			negzoneU = vertLeftListU
			negzoneV = vertLeftListV
		uv_layer_ob = bm.loops.layers.uv.get(bakemap_pref)
		uv_ignor_verts = set()
		uv_vert2uv = {}
		for vert in bm.verts:
			isMapped = 0
			vU = 0.0
			vV = 0.0
			if (vert.index in vertDistMapU):
				isMapped = isMapped+1
				vU = float(vertDistMapU[vert.index])
			if (vert.index in vertDistMapV):
				isMapped = isMapped+1
				vV = float(vertDistMapV[vert.index])
			if isMapped != 2:
				#print("- Unmapped vert, skipping:", vert.index, isMapped)
				# uv_unmap_checkmap[vert.index] = len(uv_unmap_checkmap)
				uv_ignor_verts.add(vert.index)
				continue
			if negzoneU is not None:
				if vert.index in negzoneU:
					vU = -1.0*negzoneUScale*abs(vU)
				else:
					vU = negzoneUScale*abs(vU)
			if negzoneV is not None:
				if vert.index in negzoneV:
					vV = -1.0*negzoneVScale*abs(vV)
				else:
					vV = negzoneVScale*abs(vV)
			vU = wla.math_clipFraction(vU, config.kWPLUVPrecision) * self.opt_scaleChannls[0] * self.opt_scaleTotal
			vV = wla.math_clipFraction(vV, config.kWPLUVPrecision) * self.opt_scaleChannls[1] * self.opt_scaleTotal
			uv_vert2uv[vert.index] = (vU, vV)
		uv_vert2dirU = {}
		for vert1 in bm.verts:
			if vert1.index in uv_vert2uv:
				dir_U = Vector((0,0,0))
				dir_maxdiff = 0.0
				for e in vert1.link_edges:
					vert2 = e.other_vert(vert1)
					if (vert2.index in uv_vert2uv):
						dir_diff = uv_vert2uv[vert2.index][0] - uv_vert2uv[vert2.index][1]
						if dir_diff > dir_maxdiff:
							dir_maxdiff = dir_diff
							dir_U = ((active_obj.matrix_world @ vert2.co) - (active_obj.matrix_world @ vert1.co)).normalized()
				uv_vert2dirU[vert1.index] = dir_U
		for face in bm.faces:
			if self.opt_selectedOnly and face.index not in selfaces:
				continue
			for loop in face.loops:
				vert = loop.vert
				if vert.index in uv_vert2uv:
					loop[uv_layer_ob].uv = uv_vert2uv[vert.index]
		bmesh.update_edit_mesh(active_mesh)
		wla_do.select_and_change_mode(active_obj, "OBJECT")
		uv_layer_diru_ob = wla_attr.attr3v_obj_ensure(active_obj, bakemap_pref+"_DirU") # Grid_DirU
		if uv_layer_diru_ob is not None:
			# placing # Dir_U in verts
			for vert in active_mesh.vertices:
				vIdx = vert.index
				if vert.index in uv_vert2dirU:
					uv_layer_diru_ob.data[vIdx].vector = uv_vert2dirU[vert.index]
		else:
			print("- GRID_DirU: falied to add attribute")
		wla_do.modf_toggle(active_obj, wla_do.kWPLModifsHeavies+['ARMATURE'], None, modf_cache)
		self.report({'INFO'}, "Vertices baked (grid):" + str(len(vertDistMapU)) + "/" + str(len(vertDistMapV)) + ", ignor:"+str(len(uv_ignor_verts)))
		return {'FINISHED'}

class wpluvvg_copyuv(bpy.types.Operator): # topocopy
	# **: XMirror expected, selection NOT used
	bl_idname = "mesh.wpluvvg_copyuv"
	bl_label = "Topological Copy/Paste UV"
	bl_options = {'REGISTER', 'UNDO'}

	opt_op : EnumProperty(
		name="Operation", default="COPY",
		items=(('COPY', "COPY", ""), ('PASTE', "PASTE", ""))
	)
	opt_uvName : StringProperty(
		name = "UV Name",
		default = config.kWPLGridUV
	)
	opt_stackDepth : IntProperty(
		name="Depth", default=18, min=1, max=99
	)
	opt_useXMirror : BoolProperty(
		name = "Use XMirror",
		default = True
	)
	# opt_useSeam : BoolProperty(
	# 	name = "Use Seam marks",
	# 	default = False
	# )
	def execute( self, context ):
		active_obj = wla.active_object(['MESH'])
		if active_obj is None:
			self.report({'ERROR'}, "Select mesh object first")
			return {'CANCELLED'}
		active_mesh = active_obj.data
		# selverts = wla.selected_vertsIdx(active_mesh) # selection NOT USED
		print("- mesh vertices:", len(active_mesh.vertices),"polygons:", len(active_mesh.polygons))
		def generateVertTopoKeys(bm):
			mapVertTopoKeys = {}
			print("- starting. depth:",self.opt_stackDepth)
			mapVertTopoKeys = {}
			mapVertTopoKeysInv = {}
			for v1 in bm.verts:
				kk = "p"
				if self.opt_useXMirror and v1.co[0] < 0.001:
					kk = "n"
				kk = kk+str(len(v1.link_faces))+":"+str(len(v1.link_edges))+"="
				curv = [v1]
				vIdx = v1.index
				curv_steps = self.opt_stackDepth
				curv_used = set( [vIdx] )
				while len(curv) > 0 and curv_steps > 0:
					curv_steps = curv_steps-1
					nextv = []
					step_ecn = 0
					#step_seam = 0
					step_clse = 0
					for v2 in curv:
						#nextv_len = len(nextv)
						for e2 in v2.link_edges:
							v3 = e2.other_vert(v2)
							if v3.index in curv_used:
								continue
							nextv.append(v3)
							curv_used.add(v3.index)
							# if self.opt_useSeam and e2.seam:
							# 	step_seam = step_seam+1
							#step_ecn = step_ecn+1
					# for v2 in nextv:
					# 	if len(v2.link_edges) == 5:
					# 		step_clse = step_clse+1
					# 	nonVisits = 0
					# 	for e2 in v2.link_edges:
					# 		v3 = e2.other_vert(v2)
					# 		if v3.index not in curv_used:
					# 			nonVisits = nonVisits+1
					# 	if nonVisits == 2:
					# 		# tubes. specially for legs/palms
					# 		step_clse = step_clse+10
					# for v2 in nextv:
					# 	for e2 in v2.link_edges:
					# 		v3 = e2.other_vert(v2)
					# 		if v3.index not in curv_used:
					# 			step_clse = step_clse+len(v3.link_edges)
					# 		else:
					# 			step_clse = step_clse-len(v3.link_edges)
					# 		# if v3 in curv:
					# 		# 	step_clse = step_clse+1
					step_ecn = step_ecn+len(nextv)
					kk = kk+str(step_ecn)+":"+str(step_clse)+"/" # +":"+str(step_seam)
					curv = nextv
				# again, but walking faces
				curv = [v1]
				vIdx = v1.index
				curv_steps = self.opt_stackDepth
				curv_used = set( [vIdx] )
				while len(curv) > 0 and curv_steps > 0:
					curv_steps = curv_steps-1
					nextv = []
					step_ecn = 0
					#step_ecn2 = 0
					for v2 in curv:
						for f2 in v2.link_faces:
							for v3 in f2.verts:
								if v3.index in curv_used:
									continue
								nextv.append(v3)
								curv_used.add(v3.index)
								#step_ecn = step_ecn+1
								#step_ecn2 = step_ecn2+1
					step_ecn = step_ecn+len(nextv)
					kk = kk+str(step_ecn)+"*"
					curv = nextv
				mapVertTopoKeys[vIdx] = kk
				if kk not in mapVertTopoKeysInv:
					mapVertTopoKeysInv[kk] = []
				mapVertTopoKeysInv[kk].append(vIdx)
				if len(mapVertTopoKeys) % 100 == 0:
					print("- handled", len(mapVertTopoKeys) or len(bm.verts))
			print("- finished, checking dupes")
			dupesKeys2 = 0
			for kk in mapVertTopoKeysInv:
				if len(mapVertTopoKeysInv[kk]) >= 2:
					dupesKeys2 = dupesKeys2+1
					for vIdx in mapVertTopoKeysInv[kk]:
						v = bm.verts[vIdx]
						v.select = True
					print("- topology dupesKeys", kk, mapVertTopoKeysInv[kk])
			if dupesKeys2 > 0:
				bmesh.update_edit_mesh(active_mesh)
				print("- ERROR: topology dupes:", dupesKeys2)
				return mapVertTopoKeys, dupesKeys2, mapVertTopoKeysInv
			return mapVertTopoKeys, None, mapVertTopoKeysInv
		wla_do.select_and_change_mode(active_obj, 'EDIT')
		bm = bmesh.from_edit_mesh(active_mesh)
		bm.verts.ensure_lookup_table()
		bm.verts.index_update()
		bm.faces.ensure_lookup_table()
		bm.faces.index_update()
		uv_layer_holdr = bm.loops.layers.uv.get(self.opt_uvName)
		if self.opt_op == 'COPY':
			okCnt = 0
			uvmapDict = {}
			mapVertTopoKeys, mapVertDupes, _ = generateVertTopoKeys(bm)
			if uv_layer_holdr is not None:
				for face in bm.faces:
					for vert, loop in zip(face.verts, face.loops):
						if vert.index in mapVertTopoKeys:
							kk = mapVertTopoKeys[vert.index]
							if kk not in uvmapDict:
								uvmapDict[kk] = copy.copy(loop[uv_layer_holdr].uv)
								okCnt = okCnt+1
			wpluvvg_copyuv = { "dict": uvmapDict, "cnt_v": len(active_mesh.vertices), "cnt_p": len(active_mesh.polygons), "cnt_e": len(active_mesh.edges) }
			config.WPL_G.store['wpluvvg_copyuv'] = wpluvvg_copyuv
			wla_do.select_and_change_mode(active_obj, 'OBJECT')
			self.report({'INFO'}, "Copied "+str(okCnt)+" verts, dupes="+str(mapVertDupes))
		if self.opt_op == 'PASTE':
			if 'wpluvvg_copyuv' not in config.WPL_G.store:
				self.report({'ERROR'}, "No UV map copy found")
				return {'FINISHED'}
			wpluvvg_copyuv = config.WPL_G.store['wpluvvg_copyuv']
			if (wpluvvg_copyuv["cnt_v"] != len(active_mesh.vertices)) or (wpluvvg_copyuv["cnt_p"] != len(active_mesh.polygons)) or (wpluvvg_copyuv["cnt_e"] != len(active_mesh.edges)):
				print("- meshes do not match", wpluvvg_copyuv["cnt_v"], len(active_mesh.vertices), wpluvvg_copyuv["cnt_p"], len(active_mesh.polygons), wpluvvg_copyuv["cnt_e"], len(active_mesh.edges))
				self.report({'ERROR'}, "Poligon/Verts/Edges count do not match")
				return {'FINISHED'}
			uvmapDict = wpluvvg_copyuv["dict"]
			if uv_layer_holdr is None:
				self.report({'ERROR'}, "Target UV map not found")
				return {'FINISHED'}
			okCnt = {}
			mapVertTopoKeys, mapVertDupes, mapVertTopoKeysInv = generateVertTopoKeys(bm)
			if (mapVertDupes is not None) and mapVertDupes > 0:
				self.report({'ERROR'}, "Vert dupes, stopping")
				return {'FINISHED'}
			for face in bm.faces:
				for vert, loop in zip(face.verts, face.loops):
					if vert.index in mapVertTopoKeys:
						kk = mapVertTopoKeys[vert.index]
						if kk in uvmapDict:
							uvmap = uvmapDict[kk]
							loop[uv_layer_holdr].uv = (uvmap[0], uvmap[1])
							okCnt[vert.index] = 1
			unmapCnt = 0
			if len(okCnt)<len(mapVertTopoKeys):
				for kk in uvmapDict.keys():
					if kk not in mapVertTopoKeysInv:
						print("- unmapped key:", kk)
				for v in bm.verts:
					if v.index not in okCnt:
						v.select = True
						unmapCnt = unmapCnt+1
						kk = mapVertTopoKeys[v.index]
						print("- unmapped ver:", kk, v.index)
				print("- Unmapped verts found:", unmapCnt)
			bmesh.update_edit_mesh(active_mesh)
			wla_do.select_and_change_mode(active_obj, 'OBJECT')
			self.report({'INFO'}, "Pasted. Mapped " + str(len(okCnt)) + " verts, unmapped="+str(unmapCnt))
		return {'FINISHED'}

class wpluvvg_gen_nrms(bpy.types.Operator):
	bl_idname = "object.wpluvvg_gen_nrms"
	bl_label = "Generate flat/bone normals && vgs"
	bl_options = {'REGISTER', 'UNDO'}

	opt_regenIsls : BoolProperty(
		name = "Regenerate Islands",
		default = True
	)
	opt_regenFlatn : BoolProperty(
		name = "Regenerate FlatNormals",
		default = True
	)
	opt_ensureNoProblems : BoolProperty(
		name = "Check possible problems",
		default = True
	)
	opt_ensureCleanup : BoolProperty(
		name = "Cleanup helpers",
		default = True
	)
	# Running as separate dialog
	def invoke(self, context, event):
		return context.window_manager.invoke_props_dialog(self, width = 200)

	def execute(self, context):
		if wla.is_local_view():
			self.report({'ERROR'}, "Can`t work in Local view")
			return {'CANCELLED'}
		active_obj0 = wla.active_object()
		if active_obj0 is None:
			self.report({'ERROR'}, "Select object first")
			return {'CANCELLED'}
		sel_all_all = wla.selected_objects()
		sel_all_all = wla.all_objects_hier(sel_all_all)
		sel_all_valid = []
		sel_all_del = []
		for obj in sel_all_all:
			if wla.isTokenInStr(config.kWPLObjCharFaceToken, wla.object_full_name(obj)):
				continue
			if self.opt_ensureCleanup:
				if wla.isTokenInStr(config.kWPLObjCharRefLoomis, obj.name):
					sel_all_del.append(obj)
					continue
				if wla.isTokenInStr(config.kWPLObjCharRefStickman, obj.name):
					sel_all_del.append(obj)
					continue
			if self.opt_ensureNoProblems:
				if obj.type == 'GPENCIL' and wla.modf_by_type(obj, None, wla_edger.kWPL_EdgeModf_DBGLineArt) is not None:
					print("- problem: lineart object found (crashy)", wla.object_full_name(obj))
					self.report({'ERROR'}, "Object not ready: lineart object: " + obj.name)
					return {'CANCELLED'}
				if wla.isTokenInStr(config.kWPLObjProtoToken, wla.object_full_name(obj)) and (obj.hide_render == False):
					print("- problem: renderable proto found", wla.object_full_name(obj))
					self.report({'ERROR'}, "Object not ready: renderable proto: " + obj.name)
					return {'CANCELLED'}
				if obj.type == 'MESH':
					obj_vers, _, _ = wla.sys_objdata_versions(obj)
					if len(obj_vers) > 1:
						lastver = None
						for vname in obj_vers:
							if config.kWPLRQueueBindPostfix[-1] in vname:
								continue
							lastver = vname # valid
						# print("- checking mesh version", obj_vers, lastver, obj.data.name)
						if lastver is not None:
							if lastver != obj.data.name:
								print("- problem: non-base mesh version, switch, CHECK edging", obj.name, lastver, obj.data.name)
								self.report({'ERROR'}, "Object not ready: non-base version: " + obj.name)
								return {'CANCELLED'}
							# lastokdat = wla.sys_objdata_by_name(obj, lastver)
							# if (lastokdat is not None) and lastokdat.name != obj.data.name:
							# 	# print("- Switching object data", obj.data.name, lastokdat.name)
							# 	# bpy.ops.object.wplheal_meshversion(opt_switchTo = lastokdat.name)# obj.data = lastokdat
			if obj.type == 'MESH':
				possible_probs = None
				if wla.isTokenInStr(config.kWPLObjCharHeadPostfix, wla.object_full_name(obj)):
					possible_probs = ['obj_scale_not_applied']
				sel_obj_nonoperable = wla.is_object_nonoperable(obj, possible_probs)
				if sel_obj_nonoperable is not None:
					print("- problem:", sel_obj_nonoperable)
					self.report({'ERROR'}, "Object not ready:" + sel_obj_nonoperable)
					return {'CANCELLED'}
			sel_all_valid.append(obj)
		for obj in sel_all_del:
			print("- removing helper:", obj.name)
			bpy.data.objects.remove(obj, do_unlink=True)
		sel_all = wla_arma.all_mesh_hiers(sel_all_valid)
		if len(sel_all) == 0:
			# just nothing
			return {'FINISHED'}
		camera_gCo, camera_gOrtho, camera_gDir, _ = wla.active_camera()
		if camera_gCo is None:
			self.report({'ERROR'}, "Camera not found: "+config.kWPLSystemMainCam)
			return {'CANCELLED'}
		if self.opt_regenIsls:
			print("- generating islands && per-island meta...")
			bpy.ops.object.wpluvvg_gen_isl(opt_generType = 'MTL_ISL')
		objsOk = 0
		objsSkip = 0
		objsNoBone = 0
		if self.opt_regenFlatn:
			# transferring normals from any kWPLObjCharBodyPostfix (if present) to skin/unhandled objects
			print("- generating flat-normals...")
			obj_primaryCharbs = []
			for obj in sel_all:
				if wla.isTokenInStr(config.kWPLObjCharBodyPostfix, obj.name):
					obj_primaryCharbs.append(obj)
			if len(obj_primaryCharbs) != 1:
				print("- Primary charb: not found, skipping normal generation")
				return {'FINISHED'}
			if len(obj_primaryCharbs) > 1:
				print("- Primary charb: ambigous", obj_primaryCharbs)
				self.report({'ERROR'}, "Primary charb: ambigous")
				return {'CANCELLED'}
			obj_primaryCharb = obj_primaryCharbs[0]
			if obj_primaryCharb.type != 'MESH':
				self.report({'ERROR'}, "Primary charb should be MESH")
				return {'CANCELLED'}
			if obj_primaryCharb is not None:
				print("- found primary charb", obj_primaryCharb.name)
				selVGs = wla_attr.vg_names_by_nameToken(obj_primaryCharb, config.kWPLSaveSelVGroup)
				for selVG in selVGs:
					print("- selection VGs found", selVG)
					#self.report({'ERROR'}, "Selection VGs on " + obj_primaryCharb.name)
					#return {'CANCELLED'}
					wla_attr.vg_remove(obj_primaryCharb, selVG)
				for active_obj in sel_all:
					if active_obj.type != 'MESH' or not wla.is_object_valid(active_obj):
						continue
					# skipping head childs (no need for vg-bonenormals -> copyconstr/etc chain used)
					if wla.isTokenInStr(config.kWPLObjCharHeadPostfix, wla.object_full_name(active_obj)) or active_obj == obj_primaryCharb:
						continue
					if wla.isTokenInStr(config.kWPLObjVgsSkinPostfix, active_obj.name) or wla_arma.is_has_arma_vgs(active_obj) == False:
						print("- transfering vertex groups to",active_obj.name)
						canTransfer = True
						if (wla_attr.vg_get_by_name(obj_primaryCharb, config.kWPLSuppVGHideMaskM) is not None) and (wla_attr.vg_get_by_name(active_obj, config.kWPLSuppVGHideMaskM) is not None):
							print("// VG transfer skipped: can`t overwrite", config.kWPLSuppVGHideMaskM)
							canTransfer = False
						if canTransfer:
							wla_do.transfer_data(obj_primaryCharb, active_obj, True, False)
			bone_parlens_cache = {}
			def get_bone_parlen(armatr, bn_name):
				if bn_name in bone_parlens_cache:
					return bone_parlens_cache[bn_name]
				pblen = 0
				pb = armatr.pose.bones[bn_name]
				if pb.parent is not None:
					arm_mw = armatr.matrix_world
					pb1 = armatr.pose.bones[pb.parent.name]
					pb1_head_g = arm_mw @ pb1.head
					pb1_tail_g = arm_mw @ pb1.tail
					pblen = pblen+(pb1_head_g-pb1_tail_g).length
					if pb.parent.parent is not None:
						pblen = pblen + get_bone_parlen(armatr, pb.parent.parent.name)
				bone_parlens_cache[bn_name] = pblen
				return pblen
			armatr0 = wla_arma.related_arma(active_obj0)
			if armatr0 is None:
				print("- Warning: no armature found for", active_obj0.name)
			# opt_skipBones = wla_arma.select_by_arma(active_obj0, config.kWPLArmBakeIgnoreBns_MB, config.kWPLArmBakeIgnoreBns_MLOW, "") 
			for active_obj in sel_all:
				if not wla.is_object_valid(active_obj):
					print("- Skipping object, scale0", active_obj.name)
					objsSkip = objsSkip+1
					continue
				# okCnt = wla_vgs.execVgScriptOnObject(active_obj, False)
				# if okCnt is not None and okCnt > 0:
				# 	print("- executed vgs: reentrable steps done", okCnt)
				ao_mw = active_obj.matrix_world
				ao_mw_nrm_g = active_obj.matrix_world.inverted().transposed().to_3x3()
				armatrX = wla_arma.related_arma(active_obj)
				if armatrX is None and armatr0 is not None:
					# using first!!! charh not linked to arma anymore
					armatrX = armatr0
				# if armatr0 is not None and armatrX is not None and armatrX.name != armatr0.name:
				# 	objsNoBone = objsNoBone+1
				# 	print("- skipping obj, inconsistent armature", active_obj.name, armatr0.name, armatrX.name)
				# 	objsSkip = objsSkip+1
				# 	continue
				if active_obj.type != 'MESH':
					continue
				vertsOk = 0
				vertsNotOk = 0
				verts_new_datal = {}
				active_mesh = active_obj.data
				if armatrX is not None:
					print("- updating flat/bone normals for", active_obj.name, "from", armatrX.name)
					armatrX_skipbn = ""
					# cats/etc - not MLOW, but ok for bone normals
					if wla_arma.is_mlow_arma(armatrX):
						armatrX_skipbn = kWPLArmBoneNormalsExcept_MLOW
					wla_do.select_and_change_mode(armatrX,"POSE")
					boneNames = armatrX.pose.bones.keys()
					bpy.ops.pose.visual_transform_apply()
					arm_mw = armatrX.matrix_world
					#matrix_world_inv = active_obj.matrix_world.inverted()
					actbonesOk = []
					virtVGs = [] # bone parenting / constrains
					obj_parents = wla.object_parent_chain(active_obj)
					obj_parents = [active_obj] + obj_parents
					for nexrPare in obj_parents:
						if nexrPare.constraints is not None:
							for constr in nexrPare.constraints:
								if constr.type == 'COPY_TRANSFORMS' or constr.type == 'COPY_LOCATION':
									if len(constr.subtarget) > 0:
										virtVGs.append(constr.subtarget)
						if len(nexrPare.parent_bone) > 0:
							virtVGs.append(nexrPare.parent_bone)
					#print(" - virtVGs", virtVGs)
					for bn_name in boneNames:
						if (bn_name in active_obj.vertex_groups) or (bn_name in virtVGs):
							pb = armatrX.pose.bones[bn_name]
							head_g = arm_mw @ pb.head
							tail_g = arm_mw @ pb.tail
							camDir = camera_gDir
							if camera_gOrtho == False:
								pb_center = tail_g #(head_g-tail_g)*0.5
								if (head_g-camera_gCo).length < (tail_g-camera_gCo).length:
									pb_center = head_g
								camDir = (pb_center-camera_gCo).normalized()
							perp1 = (head_g-tail_g).cross(camDir)
							perp2 = (head_g-tail_g).cross(perp1)
							perp2 = perp2.normalized()
							if perp2.dot(camDir) < 0:
								perp2 = -1*perp2
							pb_rot = perp2.rotation_difference(camDir)
							pb_rot_mat = pb_rot.to_matrix().to_4x4()
							bone_verts = []
							bone_verts_gen = []
							if (bn_name in virtVGs):
								for v in active_obj.data.vertices:
									bone_verts_gen.append( (v, 1.0) )
							else:
								_, allVgVertsIdx, allVgVertsW = wla_attr.vg_get_verts(active_obj, active_obj.vertex_groups[bn_name], 0.001, None)
								for i, vIdx in enumerate(allVgVertsIdx):
									bone_verts_gen.append( (active_obj.data.vertices[vIdx], allVgVertsW[vIdx]) )
							avg_bn_dst = 0.0
							avg_bn_dst_cnt = 0.0
							for item in bone_verts_gen:
								bone_verts.append(item)
								v = item[0]
								v_co_g = ao_mw @ v.co
								v2bn_projpair = mathutils.geometry.intersect_point_line(v_co_g, head_g, tail_g)
								avg_bn_dst = avg_bn_dst + v2bn_projpair[1]
								avg_bn_dst_cnt = avg_bn_dst_cnt+1.0
							if avg_bn_dst_cnt < 1.0:
								continue
							bone_scale_nrm = 1.0
							bone_skip_scale = wla.getTokenForStr(armatrX_skipbn, bn_name, "0.0000001")
							if bone_skip_scale is not None:
								bone_scale_nrm = float(bone_skip_scale)
							else:
								actbonesOk.append(bn_name)
							avg_bn_dst = avg_bn_dst/avg_bn_dst_cnt
							#print(" - used:", pb.name, len(bone_verts), avg_bn_dst)
							for item in bone_verts:
								v = item[0]
								# new normal
								v_wei = item[1] * bone_scale_nrm
								v_nrm_g = (ao_mw_nrm_g @ v.normal).normalized()
								v_nrm_g2 = (pb_rot_mat @ v_nrm_g).normalized()
								v_co_g = ao_mw @ v.co
								v2bn_projpair = mathutils.geometry.intersect_point_line(v_co_g, head_g, tail_g)
								vertPairs = []
								vertPairs.append( (v_wei, v_nrm_g2) )
								if v.index not in verts_new_datal:
									verts_new_datal[v.index] = []
								verts_new_datal[v.index].append( vertPairs )
					print("- bones used", len(actbonesOk), actbonesOk)
					wla_do.select_and_change_mode(armatrX,"OBJECT")
				else:
					objsNoBone = objsNoBone+1
				verts_nrm_g = {}
				if len(verts_new_datal) > 0:
					for vIdx, vert_list in verts_new_datal.items():
						nx = np.average([itm[0][1][0] for itm in vert_list],weights=[itm[0][0] for itm in vert_list])
						ny = np.average([itm[0][1][1] for itm in vert_list],weights=[itm[0][0] for itm in vert_list])
						nz = np.average([itm[0][1][2] for itm in vert_list],weights=[itm[0][0] for itm in vert_list])
						avg_g_co = Vector((nx,ny,nz)).normalized()
						verts_nrm_g[vIdx] = avg_g_co
				else:
					# default normal
					for v in active_mesh.vertices:
						v_nrm_g = ao_mw_nrm_g @ v.normal
						verts_nrm_g[v.index] = v_nrm_g
				wla_do.select_and_change_mode(active_obj,"OBJECT")
				uv_flatnrm_ob = wla_attr.attr3v_obj_ensure(active_obj, config.kWPLEBoneFlowUV)
				wla_do.select_and_change_mode(active_obj,"EDIT")
				bm = bmesh.from_edit_mesh(active_mesh)
				bm.verts.ensure_lookup_table()
				bm.faces.ensure_lookup_table()
				bm.verts.index_update()
				uv_flatnrm_ob = bm.verts.layers.float_vector.get(config.kWPLEBoneFlowUV) #bm.loops.layers.uv.get(config.kWPLEBoneFlowUV)
				if uv_flatnrm_ob is None:
					wla_do.select_and_change_mode(active_obj, "OBJECT")
					print("- Error: can`t create attrib")
					self.report({'ERROR'}, "Can`t create attrib map on "+active_obj.name)
					return {'CANCELLED'}
				for vert in bm.verts:
					vert.select = False
					if (vert.index not in verts_nrm_g):
						# MISSED! trying to get average from nears as fallback
						# print("- bonevert NOT FOUND", vert.index)
						#vert.select = True
						avg_sum = Vector((0,0,0))
						avg_cnt = 0
						for e in vert.link_edges:
							vert2 = e.other_vert(vert)
							if vert2.index in verts_nrm_g:
								avg_sum = avg_sum+verts_nrm_g[vert2.index]
								avg_cnt = avg_cnt+1
						if avg_cnt>0:
							verts_nrm_g[vert.index] = avg_sum/avg_cnt
						else:
							vertsNotOk = vertsNotOk+1
							v_nrm_g = ao_mw_nrm_g @ vert.normal
							verts_nrm_g[vert.index] = v_nrm_g
					if (vert.index in verts_nrm_g):
						new_n = verts_nrm_g[vert.index]
						new_n = new_n.normalized()
						vert[uv_flatnrm_ob] = new_n #wla.math_vecPack2(new_n, True)
						vertsOk = vertsOk+1
					else:
						vert[uv_flatnrm_ob] = (0.0,0.0,0.0) #wla.math_vecPack2(None, True)
				bmesh.update_edit_mesh(active_mesh)
				wla_do.select_and_change_mode(active_obj, "OBJECT")
				print("- object baked", active_obj.name, "verts:", vertsOk, "problemVerts:", vertsNotOk)
				if vertsOk > 0:
					objsOk = objsOk+1
			if armatr0 is not None:
				armatr0.hide_viewport = True
				print("- Flat/Bone normals: arma "+ armatr0.name+", objs:"+str(objsOk)+", skipped:"+str(objsSkip))
		if active_obj0 is not None:
			wla_do.select_and_change_mode(active_obj0, "OBJECT")
			wla_do.select_and_activate_multi(sel_all, active_obj0)
		self.report({'INFO'}, "Done. Objects:"+str(objsOk)+" (no-bone:"+str(objsNoBone)+", skipped:"+str(objsSkip)+")")
		return {'FINISHED'}

class wpluvvg_transferdat(bpy.types.Operator):
	bl_idname = "object.wpluvvg_transferdat"
	bl_label = "Transfer data/arma from object to object"
	bl_options = {'REGISTER', 'UNDO'}
	
	opt_transfVG : BoolProperty(
		name = "Transfer VG",
		default = True
	)
	opt_transfVC : BoolProperty(
		name = "Transfer VC",
		default = False
	)
	opt_transfArma : BoolProperty(
		name = "Transfer Armature Modf",
		default = False
	)

	# Running as separate dialog
	def invoke(self, context, event):
		return context.window_manager.invoke_props_dialog(self, width = 200)

	def execute( self, context ):
		fromObj, selObjs = wla_arma.find_refarm_object(None)
		if fromObj is None:
			self.report({'ERROR'}, "Source object not detected")
			return {'CANCELLED'}
		modf_cache = {}
		okCnt = 0
		wla_do.modf_toggle(fromObj, wla_do.kWPLModifsHeavies+['MASK', 'EDGE_SPLIT'], False, modf_cache)
		for obj in selObjs:
			if wla.isTokenInStr(config.kWPLObjCharFaceToken, wla.object_full_name(obj)):
				# wrap objects does not visible in bone normals
				# but both bodies and wraps has _sel1/_sel2 for unwrapping
				# possible solutions: custom UV-axis groups for charb (or delete, no need after unwrap) or wrap
				print("- skipping WRAP object",obj.name)
				continue
			if (wla_attr.vg_get_by_name(fromObj, config.kWPLSuppVGHideMaskM) is not None) and (wla_attr.vg_get_by_name(obj, config.kWPLSuppVGHideMaskM) is not None):
				print("- skipping object with Hidegeom: can not overwrite",obj.name)
				continue
			wla_do.transfer_data(fromObj, obj, self.opt_transfVG, self.opt_transfVC)
			if self.opt_transfArma:
				mdFrom = wla.modf_by_type(fromObj, 'ARMATURE')
				if mdFrom is not None:
					md = obj.modifiers.new('ArmatureMod', 'ARMATURE')
					wla_do.modf_copy_opts(md, mdFrom)
					md.show_in_editmode = True
					md.show_on_cage = True
			okCnt = okCnt+1
		wla_do.select_and_change_mode(fromObj, 'OBJECT')
		wla_do.modf_toggle(fromObj, wla_do.kWPLModifsHeavies+['MASK', 'EDGE_SPLIT'], None, modf_cache)
		self.report({'INFO'}, "Transfered from "+fromObj.name+" to "+str(okCnt)+" objects")
		return {'FINISHED'}
	
# ==========================================
# ==========================================

def WPL_UVVGOPTS_wei_gropnm_real_update(self, context):
	wpl_weigToolOpts = context.scene.wpl_uvvgOpts
	if len(wpl_weigToolOpts.wei_gropnm_real)>0:
		wpl_weigToolOpts.wei_gropnm = wpl_weigToolOpts.wei_gropnm_real
		wpl_weigToolOpts.wei_gropnm_real = ""

class WPL_UVVGOPTS(bpy.types.PropertyGroup):
	# wei_value : FloatProperty(
	# 	name = "Val",
	# 	default = 0.1
	# )
	wei_gropnm : StringProperty(
		name = "VG",
		default = ""
	)
	wei_gropnm_real : StringProperty(
		name = "",
		default = "",
		update = WPL_UVVGOPTS_wei_gropnm_real_update
	)

class WPL_PT_VGPanel(bpy.types.Panel):
	bl_idname = "WPL_PT_VGPanel"
	bl_label = "VG tools"
	bl_space_type = 'VIEW_3D'
	bl_region_type = 'UI'
	bl_category = "MATS"

	def draw(self, context):
		layout = self.layout
		col = layout.column()
		wpl_uvvgOpts = context.scene.wpl_uvvgOpts
		active_obj = wla.active_object(wla_meshwrap.kWPLMESHWRAP_TYPES)
		box2 = col.box()
		row0 = box2.row()
		row0.prop(wpl_uvvgOpts, "wei_gropnm")
		if active_obj is not None:
			row0.prop_search(wpl_uvvgOpts, "wei_gropnm_real", active_obj, "vertex_groups", icon='GROUP_VERTEX', text="")
		row0 = box2.row()
		row0.operator("mesh.wpluvvg_vgpropg", text="Select W>0.1").opt_action = 'SELALL'
		row0.operator("mesh.wpluvvg_vgpropg", text="Select W>0.5").opt_action = 'SELHALFUP'
		box2.separator()
		# row1 = box2.row()
		# row1.prop(wpl_uvvgOpts, "wei_value")
		# op1 = row1.operator("mesh.wpluvvg_vgedt", text="+")
		# op1.opt_stepmul = 1.0
		# op1.opt_oldmul = 1.0
		# op1.opt_stepadd = 0.0
		# op1.opt_otherval = -1.0
		# op2 = row1.operator("mesh.wpluvvg_vgedt", text="-")
		# op2.opt_stepmul = -1.0
		# op2.opt_oldmul = 1.0
		# op2.opt_stepadd = 0.0
		# op2.opt_otherval = -1.0
		row2 = box2.row()
		op5 = row2.operator("mesh.wpluvvg_vgedt", text="*0.5")
		#op5.opt_stepmul = 0.0
		op5.opt_oldmul = 0.5
		op5.opt_stepadd = 0.0
		op5.opt_otherval = -1.0
		op5 = row2.operator("mesh.wpluvvg_vgedt", text="*1.5")
		#op5.opt_stepmul = 0.0
		op5.opt_oldmul = 1.5
		op5.opt_stepadd = 0.0
		op5.opt_otherval = -1.0
		op6 = row2.operator("mesh.wpluvvg_vgedt", text="*2.0")
		#op6.opt_stepmul = 0.0
		op6.opt_oldmul = 2.0
		op6.opt_stepadd = 0.0
		op6.opt_otherval = -1.0
		row3 = box2.row()
		op7 = row3.operator("mesh.wpluvvg_vgedt", text="=0.0")
		#op7.opt_stepmul = 0.0
		op7.opt_oldmul = 0.0
		op7.opt_stepadd = 0.0
		op7.opt_otherval = -1.0
		op7.opt_extendOnNear = False
		op8 = row3.operator("mesh.wpluvvg_vgedt", text="=0.0(+)")
		#op8.opt_stepmul = 0.0
		op8.opt_oldmul = 0.0
		op8.opt_stepadd = 0.0
		op8.opt_otherval = -1.0
		op8.opt_extendOnNear = True
		op9 = row3.operator("mesh.wpluvvg_vgedt", text="=0.4")
		#op9.opt_stepmul = 0.0
		op9.opt_oldmul = 0.0
		op9.opt_stepadd = 0.4
		op9.opt_otherval = -1.0
		row3 = box2.row()
		op8 = row3.operator("mesh.wpluvvg_vgedt", text="=0.5")
		#op8.opt_stepmul = 0.0
		op8.opt_oldmul = 0.0
		op8.opt_stepadd = 0.5
		op8.opt_otherval = -1.0
		op8 = row3.operator("mesh.wpluvvg_vgedt", text="=0.7")
		#op8.opt_stepmul = 0.0
		op8.opt_oldmul = 0.0
		op8.opt_stepadd = 0.7
		op8.opt_otherval = -1.0
		op9 = row3.operator("mesh.wpluvvg_vgedt", text="=1.0")
		#op9.opt_stepmul = 0.0
		op9.opt_oldmul = 0.0
		op9.opt_stepadd = 1.0
		op9.opt_otherval = -1.0
		# op10 = box2.operator("mesh.wpluvvg_vgedt", text="Set 1.0 Exclusively")
		# op10.opt_stepmul = 0.0
		# op10.opt_oldmul = 0.0
		# op10.opt_stepadd = 1.0
		# op10.opt_otherval = 0.0
		# row1 = box2.row()
		# row1.operator("mesh.wpluvvg_vgpropg", text="Propagate from Active").opt_action = 'PROPG'
		# row1.operator("mesh.wpluvvg_smoothall", text="Smooth on vSel").opt_onActiveOnly = True

class WPL_PT_MTPanel(bpy.types.Panel):
	bl_idname = "WPL_PT_MTPanel"
	bl_label = "MT tools"
	bl_space_type = 'VIEW_3D'
	bl_region_type = 'UI'
	bl_category = "MATS"

	def draw(self, context):
		layout = self.layout
		col = layout.column()
		op = col.operator("object.wpluvvg_unwrap_edges_grid", text = "E-UV: GRID Unwrap", icon='UV_DATA')
		op.opt_uvPrefx = config.kWPLGridUV
		op.opt_vgSeedV = "_sel1"
		op.opt_tranfType='DST_GRD'
		op.opt_selectedOnly = False
		col.operator("object.wpluvvg_unwrap_edges_norm", text = "E-UV: FACE Unwrap")
		col.operator("object.wpluvvg_unwrap_vgbind", text = "E-UV: vgBIND Mapping", icon='UV_DATA')
		#op = row1.operator("object.wpluvvg_unwrap_edges_view", text = "E-UV: VIEW")
		#op = row1.operator("object.wpluvvg_unwrap_edges_df", text = "E-UV: DistF")
		col.separator()
		col.operator("object.wplheal_selbymats", text="Scene: Select by mats")
		col.operator("object.wplheal_replacemats", text="Selected: Replace && Recolor to mat")
		col.separator()
		col.operator("object.wpluvvg_transferdat", text="Selected: Transfer VC/VG/Arma")
		col.operator("mesh.wplvc_cppaste", text="Selected: VC Mass-PASTE", icon='PASTEDOWN').opt_op = 'PASTE'
		col.operator("mesh.wplvc_masspalupd", text="Selected: VC Mass-RECOLOR", icon='COLOR') # ** -> material color except <Lib04>
		row1 = col.row()
		row1.operator("mesh.wpluvvg_copyuv", text="XSymTopo-Copy").opt_op = 'COPY'
		row1.operator("mesh.wpluvvg_copyuv", text="XSymTopo-Paste").opt_op = 'PASTE'

# ==========================================
# ==========================================

classes = (
	WPL_PT_VGPanel,
	WPL_PT_MTPanel,
	WPL_UVVGOPTS,

	wpluvvg_vgedt,
	wpluvvg_vgpropg,
	# wpluvvg_smoothall,

	wpluvvg_gen_isl,
	wpluvvg_gen_nrms,
	wpluvvg_copyuv,
	wpluvvg_unwrap_edges_grid,
	wpluvvg_unwrap_edges_norm,
	#wpluvvg_unwrap_edges_df,
	#wpluvvg_unwrap_edges_view,
	wpluvvg_unwrap_vgbind,
	wpluvvg_transferdat
)

def register():
	for cls in classes:
		bpy.utils.register_class(cls)
	bpy.types.Scene.wpl_uvvgOpts = bpy.props.PointerProperty(type=WPL_UVVGOPTS)

def unregister():
	for cls in reversed(classes):
		bpy.utils.unregister_class(cls)
	del bpy.types.Scene.wpl_uvvgOpts

if __name__ == "__main__":
	register()