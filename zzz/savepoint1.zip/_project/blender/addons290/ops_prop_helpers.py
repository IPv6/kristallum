import os, sys, time, datetime
import math, copy, string, random
import numpy as np
import bpy, bmesh, mathutils

import bpy.types
from mathutils import Vector, Matrix, Euler, Quaternion
from mathutils.bvhtree import BVHTree
from mathutils.kdtree import KDTree
from bpy_extras import view3d_utils
from bpy_extras import object_utils
from bpy.props import *
import re

from . import config
from .tools import wla
from .tools import wla_do
from .tools import wla_arma
from .tools import wla_meshwrap
from .tools import wla_vgbind
from .tools import wla_attr

kWPLGMatrixPushKey = "_matrix"
kWPLRotModeItems = ['QUATERNION', 'XYZ', 'XZY', 'YXZ', 'YZX', 'ZXY', 'ZYX', 'AXIS_ANGLE']
kWPLBisectEpsilon = 0.000001
kWPLAutoSetupRetopoFix = "Retopo_"

# ==========================================
def doAutoSetupGeometryNodes(obj):
	for md in obj.modifiers:
		if md.type == 'NODES' and md.node_group is not None:
			# bpy.types.GeometryNodeTree
			for gn_input in md.node_group.inputs:
				#wla_do.sys_dump_pythonobj(gn_input)
				if (config.kWPLAutoSetupCustomProp in gn_input.name) and (gn_input.bl_socket_idname == 'NodeSocketObject'):
					gnObj = md[gn_input.identifier]
					if gnObj is None:
						objname = gn_input.name.replace(config.kWPLAutoSetupCustomProp,'')
						gnObj = wla.object_by_name(objname)
						if gnObj is not None:
							md[gn_input.identifier] = gnObj
				if (config.kWPLAutoSetupCustomProp in gn_input.name) and (gn_input.bl_socket_idname == 'NodeSocketFloatFactor'):
					if ("is_ortho" in gn_input.name):
						objname = gn_input.name.replace(config.kWPLAutoSetupCustomProp,'')
						objname = objname.replace("is_ortho","")
						objname = objname.replace(":","")
						gnObj = wla.object_by_name(objname)
						gnRes = 0.0
						if gnObj is not None and gnObj.type == 'CAMERA' and gnObj.data.type == 'ORTHO':
							gnRes = 1.0
						if gnObj is not None and gnObj.type == 'LIGHT' and gnObj.data.type == 'SUN':
							gnRes = 1.0
						md[gn_input.identifier] = gnRes
				if (config.kWPLAutoSetupCustomProp in gn_input.name) and (gn_input.bl_socket_idname == 'NodeSocketMaterial'):
					gnMat = md[gn_input.identifier]
					if gnMat is None:
						if obj.material_slots is not None and len(list(obj.material_slots)) > 0:
							gnMat = obj.material_slots[0]
							if gnMat is not None:# MaterialSlot, not Material!!!
								md[gn_input.identifier] = gnMat.material
								#md[gn_input.identifier].material = gnMat
								# gnMat = wla_attr.mat_find_any(gnMat.name)
								# md[gn_input.identifier].default_value = gnMat
								#print("- GN: mat input, default material", gnMat)
				if (config.kWPLSuppVGScriptToken in gn_input.name) and (gn_input.bl_socket_idname == 'NodeSocketObject'):
					if ("pin_world" in gn_input.name):
						gnObj = md[gn_input.identifier]
						if gnObj is not None:
							# checking is renderable
							if gnObj.hide_render or wla.isTokenInStr(config.kWPLObjShaperToken, gnObj.name):
								print("- ERROR: MT-pattern object is non-renderable", wla.object_full_name(gnObj))
								return False
							# setting up GLOBAL orientation
							cpAmustConstr = config.kWPLSuppVGScriptToken+": ensure_global_"
							cc = None
							if gnObj.constraints.get(cpAmustConstr+"s") is None:
								print("- GN: pin_world: object input, pinning to world scale(1,1,1)", gnObj)
								cc = gnObj.constraints.new('LIMIT_SCALE')
								cc.name = cpAmustConstr+"s"
								cc.use_min_x = True
								cc.use_max_x = True
								cc.min_x = 1.0
								cc.max_x = 1.0
								cc.use_min_y = True
								cc.use_max_y = True
								cc.min_y = 1.0
								cc.max_y = 1.0
								cc.use_min_z = True
								cc.use_max_z = True
								cc.min_z = 1.0
								cc.max_z = 1.0
								#cc.target = wla.object_by_name(config.kWPLSystemMainReestrObj)
							else:
								print("- GN: pin_world: object input, already pinned world scale(1,1,1)", gnObj)
							if gnObj.constraints.get(cpAmustConstr+"r") is None:
								print("- GN: pin_world: object input, pinning to world rot(0,0,0)", gnObj)
								cc = gnObj.constraints.new('LIMIT_ROTATION')
								cc.name = cpAmustConstr+"r"
								cc.use_limit_x = True
								cc.min_x = 0
								cc.max_x = 0
								cc.use_limit_y = True
								cc.min_y = 0
								cc.max_y = 0
								cc.use_limit_z = True
								cc.min_z = 0
								cc.max_z = 0
								#cc.target = wla.object_by_name(config.kWPLSystemMainReestrObj)
							else:
								print("- GN: pin_world: object input, already pinned to world rot(0,0,0)", gnObj)
	return True

def doAutoSetupCustomProp(obj):
	if obj.type == 'CURVE' and config.kWPLObjCharHairsPostfix in obj.name:
		from . import ops_scene_nodes
		# autosetup параметров из NodeGroup-COPY значений
		nodecopy = ops_scene_nodes.WPL_G_NODES.nodecopy
		if '#faceCharHairColL' in nodecopy:
			col = nodecopy['#faceCharHairColL'][1]
			wla_attr.vc_obj_setPropCol(obj, "DecorC", col, 'PROP_NON_GAMMA')
		if '#faceCharHairColD' in nodecopy:
			col = nodecopy['#faceCharHairColD'][1]
			wla_attr.vc_obj_setPropCol(obj, "DecorD", col, 'PROP_NON_GAMMA')
		if '#faceCharHairColP' in nodecopy:
			col = nodecopy['#faceCharHairColP'][1]
			wla_attr.vc_obj_setPropCol(obj, "DecorP", col, 'PROP_NON_GAMMA')
	if obj.type == 'CURVE' and '_charh_eye' in obj.name:
		from . import ops_scene_nodes
		nodecopy = ops_scene_nodes.WPL_G_NODES.nodecopy
		if '#faceCharBackgroundCol' in nodecopy:
			col = nodecopy['#faceCharBackgroundCol'][1]
			wla_attr.vc_obj_setPropCol(obj, "DecorP", col, 'PROP_NON_GAMMA')
		if '#faceCharEyesIrisH1' in nodecopy:
			col = nodecopy['#faceCharEyesIrisH1'][1]
			if '#faceCharEyesIrisH1_R' in nodecopy:
				col = nodecopy['#faceCharEyesIrisH1_R'][1]
			wla_attr.vc_obj_setPropCol(obj, "#opt:col_eyesIrisH1", col, 'PROP_NON_GAMMA')
		if '#faceCharEyesIrisH2' in nodecopy:
			col = nodecopy['#faceCharEyesIrisH2'][1]
			if '#faceCharEyesIrisH2_R' in nodecopy:
				col = nodecopy['#faceCharEyesIrisH2_R'][1]
			wla_attr.vc_obj_setPropCol(obj, "#opt:col_eyesIrisH2", col, 'PROP_NON_GAMMA')
		if '#faceCharEyesIrisD' in nodecopy:
			col = nodecopy['#faceCharEyesIrisD'][1]
			if '#faceCharEyesIrisD_R' in nodecopy:
				col = nodecopy['#faceCharEyesIrisD_R'][1]
			wla_attr.vc_obj_setPropCol(obj, "#opt:col_eyesIrisD", col, 'PROP_NON_GAMMA')
		if '#faceCharEyesIrisL' in nodecopy:
			col = nodecopy['#faceCharEyesIrisL'][1]
			if '#faceCharEyesIrisL_R' in nodecopy:
				col = nodecopy['#faceCharEyesIrisL_R'][1]
			wla_attr.vc_obj_setPropCol(obj, "#opt:col_eyesIrisL", col, 'PROP_NON_GAMMA')
		if '#faceCharEyesIrisD' in nodecopy:
			col = nodecopy['#faceCharEyesIrisD'][1]
			wla_attr.vc_obj_setPropCol(obj, "#opt:col_eyesIrisD", col, 'PROP_NON_GAMMA')
		if '#faceCharEyesBorderI' in nodecopy:
			col = nodecopy['#faceCharEyesBorderI'][1]
			wla_attr.vc_obj_setPropCol(obj, "#opt:col_eyesBorderI", col, 'PROP_NON_GAMMA')
		if '#faceCharEyesBorderO' in nodecopy:
			col = nodecopy['#faceCharEyesBorderO'][1]
			wla_attr.vc_obj_setPropCol(obj, "#opt:col_eyesBorderO", col, 'PROP_NON_GAMMA')
	if obj.type in ['MESH', 'CURVE']:
		if obj.material_slots is not None:
			for mt in obj.material_slots:
				if mt.material is not None:
					base_mat = mt.material
					if base_mat.use_nodes:
						for node in base_mat.node_tree.nodes:
							#print("- node", node.type, node.bl_idname, node.name, node.label, node.attribute_name, wla_do.sys_dump_pythonobj(node))
							if (node.type == 'ATTRIBUTE') and (config.kWPLAutoSetupCustomProp in node.attribute_name): # node.bl_idname == 'ShaderNodeAttribute':
								if (node.attribute_name not in obj):
									desc = node.label
									if len(desc) == 0:
										desc = node.name
									if wla.isTokenInStr([config.kWPLAutoSetupCustomPropCol], node.attribute_name):
										wla_attr.vc_obj_setPropCol(obj, node.attribute_name, (0.0, 0.0, 0.0), 'PROP_NON_GAMMA')
										print("- adding custom prop: color", base_mat.name, node.attribute_name)
									elif wla.isTokenInStr([config.kWPLAutoSetupCustomPropVec], node.attribute_name):
										# color/vector, Float3
										obj[node.attribute_name] = (0.0, 0.0, 0.0)
										print("- adding custom prop: vector", base_mat.name, node.attribute_name)
									else:
										# value, Float1
										val_def = wla.safeFloat(desc,0.0,"def")
										val_min = wla.safeFloat(desc,-100.0,"min")
										val_max = wla.safeFloat(desc,100.0,"max")
										print("- adding custom prop: float", base_mat.name, node.attribute_name, val_def, val_min, val_max)
										obj[node.attribute_name] = val_def
										ui_data = obj.id_properties_ui(node.attribute_name)
										ui_data.update( min = val_min, max = val_max )
	if wla.isTokenInStr(config.kWPLObjStampToken, obj.name):
		from . import ops_tool_stampp
		ops_tool_stampp.doAutoSetupCustomProp(obj)
	if wla.isTokenInStr(config.kWPLObjCharFaceToken, wla.object_full_name(obj)):
		from . import ops_prop_pose
		ops_prop_pose.doAutoSetupCustomProp(obj)
	return True

def doAutoSetupObjWatch(active_obj):
	from . import ops_scene_man
	from . import ops_prop_edging
	if wla.isTokenInStr(config.kWPLObjzRefToken, active_obj.name) or active_obj.name == config.kWPLSystemMainSun:
		print("- autosetup: ref-objects: hot-updates")
		hotobj = ops_scene_man.kWPLGKey_HT_Objects
		empty_ht_key = ops_scene_man.kWPLGKey_HT_ObjUpdate + active_obj.name
		if empty_ht_key not in hotobj:
			hotobj[empty_ht_key] = {}
			hotobj[empty_ht_key]["object"] = active_obj.name
			hotobj[empty_ht_key]["update"] = {}
			hotobj[empty_ht_key]["update"]["gizmo_zzz_ref"] = gizmo_zzz_ref_update
			print("- autosetup: ref-objects: hot-updates activated")
	if kWPLAutoSetupRetopoFix in active_obj.name:
		wla_do.select_and_change_mode(active_obj,"OBJECT")
		bpy.ops.object.wplheal_dedupmats(opt_upgrMats=True, opt_upgrToLinked=True, opt_upgrRenamesMats=True)
		orig_name = (active_obj.name).replace(kWPLAutoSetupRetopoFix, '')
		orig_obj = wla.object_by_name(orig_name)
		if orig_obj is not None:
			wla_do.ensure_visible(orig_obj, 1)
			wla_do.transfer_data(orig_obj, active_obj, True, True)
			active_obj.data.name = orig_obj.data.name
			orig_obj.data = active_obj.data
			wla_do.select_and_change_mode(orig_obj,"OBJECT")
			bpy.data.objects.remove(active_obj, do_unlink=True)
	# if wla.isTokenInStr(config.kWPLObjEdgeFillsToken, active_obj.name):
	# 	trackCon = active_obj.constraints.get(ops_prop_edging.kWPLEdgeSecondariesTrackConName)
	# 	if trackCon is not None:
	# 		print("- autosetup: fill-objects: hot-updates")
	# 		trackTarg = trackCon.target
	# 		hotobj = ops_scene_man.kWPLGKey_HT_Objects
	# 		empty_ht_key = ops_scene_man.kWPLGKey_HT_ObjUpdate + active_obj.name
	# 		if empty_ht_key not in hotobj:
	# 			hotobj[empty_ht_key] = {}
	# 			hotobj[empty_ht_key]["object"] = trackTarg.name
	# 			hotobj[empty_ht_key]["relfill"] = active_obj.name
	# 			hotobj[empty_ht_key]["update"] = {}
	# 			hotobj[empty_ht_key]["update"]["gizmo_visib"] = gizmo_trackvis_update
	# 			print("- autosetup: fill-objects: hot-updates activated")
	return True

class wplheal_pushmatrix(bpy.types.Operator):
	bl_idname = "object.wplheal_pushmatrix"
	bl_label = "Obj: Copy matrix"
	bl_options = {'REGISTER', 'UNDO'}

	# opt_resetToXZ : BoolProperty(
	# 	name	 = "Reset to LocalXZ",
	# 	default	 = False
	# )

	def resetOpts(self):
		# self.opt_resetToXZ = False
		return

	def execute(self, context):
		active_obj = wla.active_object()
		if active_obj is None:
			self.resetOpts()
			self.report({'ERROR'}, "Select object first")
			return {'CANCELLED'}
		prevmode = wla_do.select_and_change_mode(active_obj,"OBJECT")
		copymat = active_obj.matrix_world
		copymatUseScale = True
		if 'POSE' in prevmode and active_obj.type == 'ARMATURE':
			sel_bns = wla_arma.arm_bonenames_tok(active_obj, "<pose_sel>")
			if len(sel_bns) == 1:
				print("- object matrix: using selected bone", sel_bns[0])
				copymatUseScale = False
				wla_do.select_and_change_mode(active_obj,"POSE")
				pbone = active_obj.pose.bones[sel_bns[0]]
				copymat = active_obj.convert_space(pose_bone=pbone, matrix=pbone.matrix, from_space='POSE', to_space='WORLD')
		# cansaveMatrix = True
		# if (kWPLGMatrixPushKey+"_isreset" in active_obj) and active_obj[kWPLGMatrixPushKey+"_isreset"] == 1:
		# 	cansaveMatrix = False
		# if cansaveMatrix:
		aLoc, aRot, aSca = copymat.decompose()
		if copymatUseScale == False:
			aSca = (1,1,1)
		aRotEuler = aRot.to_euler('XYZ')
		matrlist = [aLoc[0],aLoc[1],aLoc[2],aRotEuler.x,aRotEuler.y,aRotEuler.z,aSca[0],aSca[1],aSca[2],kWPLRotModeItems.index(active_obj.rotation_mode)]
		config.WPL_G.store[kWPLGMatrixPushKey] = matrlist
		active_obj[kWPLGMatrixPushKey] = matrlist
		print("- COPY executed")
		# else:
		# 	print("- COPY skipped, reset mode")
		# if self.opt_resetToXZ:
		# 	active_obj[kWPLGMatrixPushKey+"_isreset"] = 1
		# 	active_obj.rotation_mode = 'XYZ'
		# 	active_obj.scale=(1,1,1)
		# 	active_obj.rotation_euler=(0,0,0)
		# 	if active_obj.parent is not None:
		# 		local_pos = active_obj.location.copy() #active_obj.matrix_world
		# 		active_obj.matrix_world = Matrix.Identity(4)
		# 		active_obj.location = local_pos
		# 	if cansaveMatrix:
		# 		self.report({'INFO'}, "Copy+Reset: ok")
		# 	else:
		# 		self.report({'INFO'}, "Reset: ok")
		# else:
		#if cansaveMatrix:
		self.report({'INFO'}, "Copy: ok")
		# else:
		# 	self.report({'INFO'}, "Copy: skipped, reset mode")
		return {'FINISHED'}

class wplheal_popmatrix(bpy.types.Operator):
	bl_idname = "object.wplheal_popmatrix"
	bl_label = "Obj: Restore matrix"
	bl_options = {'REGISTER', 'UNDO'}

	opt_restoreOrigin : BoolProperty(
		name	 = "Restore origin",
		default	 = True
	)
	opt_restoreRotation : BoolProperty(
		name	 = "Restore rotation",
		default	 = True
	)
	opt_restoreScale : BoolProperty(
		name	 = "Restore scale",
		default	 = True
	)

	# opt_perObjectMatrix : BoolProperty(
	# 	name	 = "Use per-Object matrix",
	# 	default	 = True
	# )
	def execute(self, context):
		active_obj = wla.active_object()
		if active_obj is None:
			self.report({'ERROR'}, "Select object first")
			return {'FINISHED'}
		matrlist = None
		#isFromObj = False
		# if self.opt_perObjectMatrix == True and kWPLGMatrixPushKey in active_obj:
		# 	isFromObj = True
		# 	matrlist = active_obj[kWPLGMatrixPushKey]
		# elif 
		if kWPLGMatrixPushKey in config.WPL_G.store:
			matrlist = config.WPL_G.store[kWPLGMatrixPushKey]
		# if kWPLGMatrixPushKey+"_isreset" in active_obj:
		# 	del active_obj[kWPLGMatrixPushKey+"_isreset"]
		if matrlist is None:
			self.report({'ERROR'}, "No pushed matrix found")
			return {'FINISHED'}
		aLoc, aRot, aSca = active_obj.matrix_world.decompose()
		aRot = aRot.to_euler('XYZ')

		#print("matrlist", matrlist[0], matrlist[1], matrlist[2], matrlist[3], matrlist[4], matrlist[5], matrlist[6], matrlist[7], matrlist[8])
		if self.opt_restoreOrigin:
			aLoc = Vector((float(matrlist[0]),float(matrlist[1]),float(matrlist[2])))
		if self.opt_restoreRotation:
			aRot = Euler((float(matrlist[3]),float(matrlist[4]),float(matrlist[5])), 'XYZ').to_quaternion()
		if self.opt_restoreScale:
			aSca = Vector((float(matrlist[6]),float(matrlist[7]),float(matrlist[8])))
		aLocM = mathutils.Matrix.Translation(aLoc)
		aRotM = aRot.to_matrix().to_4x4()
		aScaM = Matrix().Scale(aSca[0], 4, Vector((1,0,0)))
		aScaM = aScaM @ Matrix().Scale(aSca[1], 4, Vector((0,1,0)))
		aScaM = aScaM @ Matrix().Scale(aSca[2], 4, Vector((0,0,1)))
		active_obj.matrix_world = aLocM @ aRotM @ aScaM
		active_obj.rotation_mode = kWPLRotModeItems[int(matrlist[9])]
		# del config.WPL_G.store[kWPLGMatrixPushKey]
		# if active_obj is not None:
		# 	del active_obj[kWPLGMatrixPushKey]
		# if isFromObj:
		# 	self.report({'INFO'}, "Pasted (from Object)")
		# else:
		self.report({'INFO'}, "Pasted (from Buffer)")
		return {'FINISHED'}

class wplheal_meshversion(bpy.types.Operator):
	bl_idname = "object.wplheal_meshversion"
	bl_label = "Switch to mesh version"
	bl_options = {'REGISTER', 'UNDO'}

	opt_switchTo : StringProperty(
		name = "Mesh Name",
		default = ""
	)

	def execute( self, context ):
		active_obj = wla.active_object(wla_meshwrap.kWPLMESHWRAP_TYPES+['ARMATURE'])
		if active_obj is None:
			self.report({'ERROR'}, "Select object first")
			return {'FINISHED'}
		if (config.kWPLMatTokenWPV in active_obj.name):
			self.report({'ERROR'}, "Object has token ["+config.kWPLMatTokenWPV+"]: "+ active_obj.name)
			return {'CANCELLED'}
		wla_do.select_and_change_mode(active_obj, 'OBJECT')
		switchToName = self.opt_switchTo
		if len(switchToName) > 0:
			# if "VEIL:" in switchToName:
			# 	# marking for veiled
			# 	switchToName = switchToName.replace("VEIL:", "")
			# 	active_obj[config.kWPLUdiSyscMeshOffset[0]] = switchToName
			# 	self.report({'INFO'}, "Mesh version marked for sysLayersT_Wri: "+switchToName)
			# 	return {'FINISHED'}
			if "FIN:" in switchToName:
				# deleting all meshes except this, renaming this to normal (non-versioned)
				switchToName = switchToName.replace("FIN:", "")
				nms, _, _ = wla.sys_objdata_versions(active_obj)
				oldVerRemoved = 0
				for nm in nms:
					if nm == active_obj.data.name:
						thisDat = active_obj.data
						thisDat.use_fake_user = False # not needed without other versions
						thisDat.name = active_obj.name
					else:
						oldDat = wla.sys_objdata_by_name(active_obj, nm)
						if oldDat is not None:
							switchToName = config.kWPLSuppZZZPrefix + active_obj.name
							oldDat.use_fake_user = False
							oldDat.name = switchToName
							oldVerRemoved = oldVerRemoved+1
				self.report({'INFO'}, "Cleanup done, removed "+str(oldVerRemoved)+" old versions")
				return {'FINISHED'}
			if "DEL:" in switchToName:
				# deleting old mesh
				switchToName = switchToName.replace("DEL:", "")
				newDat = wla.sys_objdata_by_name(active_obj, switchToName)
				if newDat is not None:
					switchToName = config.kWPLSuppZZZPrefix + active_obj.name
					newDat.use_fake_user = False
					newDat.name = switchToName
					self.report({'INFO'}, "Version removed to ["+switchToName+"]")
				return {'FINISHED'}
			if wla.sys_objdata_by_name(active_obj, switchToName) is None:
				self.report({'ERROR'}, "No mesh data found: ["+switchToName+"]")
				return {'CANCELLED'}
		# creating new version
		if wla_vgbind.obj_checkUnwrap(active_obj) == False:
			self.report({'ERROR'}, "Skipped, UV unwrap not ok")
			return {'CANCELLED'}
		if wla.isTokenInStr(config.kWPLRQueueBindPostfix, active_obj.name):
			self.report({'ERROR'}, "Object already RQ-tagged: "+ active_obj.name)
			return {'CANCELLED'}
		# renaming current mesh data if not versioned
		curDat = active_obj.data
		if config.kWPLMatTokenWPV not in curDat.name:
			_, nms_next, _ = wla.sys_objdata_versions(active_obj)
			if nms_next is None:
				self.report({'ERROR'}, "No next name found: ["+active_obj.name+"]")
				return {'CANCELLED'}
			curDat.name = nms_next
		if len(switchToName) == 0:
			nms, nms_next, _ = wla.sys_objdata_versions(active_obj)
			if nms_next is None:
				self.report({'ERROR'}, "No next name found: ["+active_obj.name+"]")
				return {'CANCELLED'}
			switchToName = nms_next
			if len(switchToName) > 0:
				# making version
				curDat.use_fake_user = True
				newDat = curDat.copy()
				newDat.use_fake_user = True
				newDat.name = switchToName
		newDat = wla.sys_objdata_by_name(active_obj, switchToName)
		if newDat is not None:
			active_obj.data = newDat
			nms, _, _ = wla.sys_objdata_versions(active_obj)
			all_nms = ",".join(nms)
			if config.kWPLRQueueBindPostfix[-1] in all_nms:
				# adding WireFrame to Folding version, make a visual difference
				# print("- Object with folding version:", all_nms)
				if config.kWPLRQueueBindPostfix[-1] in newDat.name:
					active_obj.show_wire = True
				else:
					active_obj.show_wire = False
			self.report({'INFO'}, "Version switched to ["+switchToName+"]")
		return {'FINISHED'}

class wplheal_wrapempty(bpy.types.Operator):
	bl_idname = "object.wplheal_wrapempty"
	bl_label = "Wrap in Empty"
	bl_options = {'REGISTER', 'UNDO'}

	opt_use3Dcursor : BoolProperty(
		name = "Use current 3D cursor position",
		default = False
		)
	opt_putOnSameLevel : BoolProperty(
		name		= "Use same parent",
		default	 = True
		)

	def execute( self, context ):
		wrName = config.kWPLObjWrapper
		active_obj = wla.active_object()
		if active_obj is None:
			self.report({'ERROR'}, "Select object first")
			return {'CANCELLED'}
		if wla.is_pose_mode() and active_obj.type == 'ARMATURE':
			# special case for empty linked to bone
			sel_bns = wla_arma.arm_bonenames_tok(active_obj, "<pose_sel>")
			empty = bpy.data.objects.new(name = wrName, object_data=None)
			wla_do.link_object_sideBySide(empty, active_obj)
			if len(sel_bns) == 1:
				print("- wrapper: using selected bone", sel_bns[0])
				empty.name = wrName+"_"+sel_bns[0]
				pcontr = empty.constraints.new('COPY_TRANSFORMS')
				pcontr.target = active_obj
				pcontr.subtarget = sel_bns[0]
				pcontr.mix_mode = 'REPLACE' # 'BEFORE' not ok, REPLACE works...
			wla_do.select_and_change_mode(empty, 'OBJECT')
			return {'FINISHED'}
		objs2check = wla.selected_objects()
		if len(objs2check) < 1:
			#self.report({'ERROR'}, "No objects selected")
			#return {'CANCELLED'}
			print("- no object selected, adding empty")
			empty = bpy.data.objects.new(name = wrName, object_data=None)
			wla_do.link_object_to_scene(empty, config.kWPLSystemMainColl)
			if self.opt_use3Dcursor == False:
				empty.location = Vector( (0,0,0) )
			wla_do.select_and_change_mode(empty, 'OBJECT')
			return {'FINISHED'}
		firsto = None
		firstp = None
		# looking for object with most shortes parent chain
		maxchainlen = 999
		for obj in objs2check:
			pch = wla.object_parent_chain(obj)
			if len(pch) < maxchainlen:
				maxchainlen = len(pch)
				firsto = obj
				firstp = obj.parent
		if (firsto is not None) and config.kWPLObjFrameWrapper in firsto.name:
			wrName = config.kWPLObjFrameWrapper+config.kWPLObjWrapper
			empty = bpy.data.objects.new(name = wrName, object_data=None)
			empty.empty_display_size = 4.0
			empty.empty_display_type = 'SINGLE_ARROW'
			wla_do.link_object_sideBySide(empty, firsto)
			wla_do.select_and_change_mode(empty, 'OBJECT')
			return {'FINISHED'}
		count = 0
		empty = bpy.data.objects.new(name = wrName, object_data=None)
		empty.empty_display_size = 0.45
		empty.empty_display_type = 'PLAIN_AXES'
		if self.opt_use3Dcursor:
			empty.location = wla.active_context_cursor()
		else:
			#empty.location = Vector((0,0,0))
			loc = Vector((0,0,0))
			for obj in objs2check:
				loc = loc + obj.location
			empty.location = loc/len(objs2check)
		print("- objs:",len(objs2check),"wrapper parent:", firstp, "wrapper location:", empty.location)
		wla_do.link_object_to_scene(empty, firstp)
		if self.opt_putOnSameLevel and firstp is not None:
			locIni = empty.location
			#empty.location = firstp.matrix_world.inverted()*empty.location
			empty.parent = firstp
			empty.location = locIni
		for obj in objs2check:
			obj.select_set(False)
			if (firstp is not None) and (obj.name == firstp.name):
				continue
			wla_do.set_active_object(obj)
			bpy.ops.object.parent_clear(type='CLEAR_KEEP_TRANSFORM')
		for obj in objs2check:
			if (firstp is not None) and (obj.name == firstp.name):
				continue
			obj.select_set(True)
		wla_do.set_active_object(empty)
		bpy.ops.object.parent_set(type='OBJECT', xmirror=False, keep_transform=True)
		if firsto is not None:
			wla_do.unlink_object_from_coll(empty, None)
			for coll in firsto.users_collection:
				if coll.objects.get(empty.name) is None:
					print("- Adding to collection:", empty.name, "->", coll.name)
					coll.objects.link(empty)
					wla_do.sys_update_view(True, False)
		for obj in objs2check:
			count = count+1
			#if obj.type == 'ARMATURE':
			#	obj.parent = empty
		wla_do.select_and_change_mode(empty,'OBJECT')
		self.report({'INFO'}, "Wrapped "+str(count)+" objects")
		return {'FINISHED'}

class wplheal_parn2cursr(bpy.types.Operator):
	bl_idname = "object.wplheal_parn2cursr"
	bl_label = "Snap parent to active"
	bl_options = {'REGISTER', 'UNDO'}

	opt_use3Dcursor : BoolProperty(
		name		= "Use current 3D cursor position",
		default	 = False
		)

	def execute(self, context):
		active_obj = wla.active_object()
		if active_obj is None:
			self.report({'ERROR'}, "Select object first")
			return {'CANCELLED'}
		# if parent not in the current set of views - nothing will happen! Snapping will be ignored
		wla_do.ensure_visible(active_obj, 2)
		wla_do.ensure_visible(active_obj.parent, 2)
		if self.opt_use3Dcursor == False:
			bpy.ops.view3d.snap_cursor_to_active()
		wla_do.select_and_change_mode(active_obj, 'OBJECT') # to exit from possible edit
		wla_do.deselect_all_objects()
		if active_obj.parent is not None: #len(active_obj.children) == 0 and 
			parent = active_obj.parent
		else:
			self.report({'ERROR'}, "No parent found")
			return {'FINISHED'}
		print("Parent:", parent.name)
		child_objs = []
		for child in parent.children:
			child.select_set(True)
			child_objs.append(child)
			bpy.ops.object.parent_clear(type='CLEAR_KEEP_TRANSFORM')
			child.select_set(False)
		wla_do.select_and_change_mode(parent, 'OBJECT')
		bpy.ops.view3d.snap_selected_to_cursor(use_offset=False)
		parent.select_set(False)
		for child in child_objs:
			child.select_set(True)
		parent.select_set(True)
		wla_do.set_active_object(parent)
		bpy.ops.object.parent_set(type='OBJECT', keep_transform=True)
		for child in child_objs:
			child.select_set(False)
		parent.select_set(False)
		active_obj.select_set(True)
		wla_do.set_active_object(active_obj)
		self.report({'INFO'}, "Parent snapped, childs: "+str(child_objs))
		return {'FINISHED'}

class wplheal_orig2cursr(bpy.types.Operator):
	bl_idname = "object.wplheal_orig2cursr"
	bl_label = "Snap origins to active"
	bl_options = {'REGISTER', 'UNDO'}

	opt_use3Dcursor : BoolProperty(
		name		= "Use current 3D cursor position",
		default	 = False
		)

	def execute(self, context):
		sel_all = wla.selected_objects()
		active_obj = wla.active_object()
		if active_obj is None:
			self.report({'ERROR'}, "Select object first")
			return {'CANCELLED'}
		active_obj_loc1 = active_obj.location.copy()
		if self.opt_use3Dcursor == False:
			if bpy.context.mode == 'OBJECT':
				# snapping to geomcenter of object
				local_bbox_center = 0.125 * sum((Vector(b) for b in active_obj.bound_box), Vector())
				bpy.context.scene.cursor.location = active_obj.matrix_world @ local_bbox_center
			else:
				bpy.ops.view3d.snap_cursor_to_active()
		wla_do.select_and_change_mode(active_obj, 'OBJECT') # to exit from possible edit
		for sel_obj in sel_all:
			wla_do.select_and_change_mode(sel_obj, 'OBJECT')
			bpy.ops.object.origin_set(type='ORIGIN_CURSOR')
		wla_do.set_active_object(active_obj)
		active_obj_loc2 = active_obj.location.copy()
		print("- Origin adjusted", active_obj_loc1, active_obj_loc2, active_obj_loc2-active_obj_loc1)
		self.report({'INFO'}, "Done, objects affected: "+str(len(sel_all)))
		return {'FINISHED'}

class wplheal_objo2camv(bpy.types.Operator):
	bl_idname = "object.wplheal_objo2camv"
	bl_label = "Snap to camera view (screen space)"
	bl_options = {'REGISTER', 'UNDO'}

	opt_camViewXY : FloatVectorProperty(
		name = "Render XY",
		description="X0==left, X1==right,Y0==bottom, Y1==top",
		size = 2,
		default	 = (0.0,0.0),
	)
	opt_testDirX : FloatVectorProperty(
		name = "Test dir for X (Global)",
		size = 3,
		default	 = (1.0,0.0,0.0),
	)
	opt_testDirY : FloatVectorProperty(
		name = "Test dir for Y (Global)",
		size = 3,
		default	 = (0.0,0.0,1.0),
	)
	opt_iters : IntProperty(
		name = "Iterations",
		default	 = 500
	)
	opt_reverseUp : BoolProperty(
		name = "Reverse screen-space up",
		default = True
	)

	# Running as separate dialog
	def invoke(self, context, event):
		return context.window_manager.invoke_props_dialog(self, width = 200)

	def execute(self, context):
		active_obj = wla.active_object()
		if active_obj is None:
			self.report({'ERROR'}, "Select object first")
			return {'CANCELLED'}
		c_scene = bpy.context.scene
		camera_obj = wla.object_by_name(config.kWPLSystemMainCam)
		if camera_obj is None:
			self.report({'ERROR'}, "No main camera")
			return {'CANCELLED'}
		total_bisects = 0
		x_dir = Vector( self.opt_testDirX ).normalized()
		y_dir = Vector( self.opt_testDirY ).normalized()
		active_obj_pos = active_obj.matrix_world.to_translation()

		targetXY = self.opt_camViewXY
		if self.opt_reverseUp:
			targetXY = (self.opt_camViewXY[0], 1.0-self.opt_camViewXY[1])
		# X-test
		max_bisects = self.opt_iters
		x_min_max = [-100,100]
		x_cur = x_min_max[0]
		while max_bisects > 0:
			max_bisects = max_bisects-1
			total_bisects = total_bisects+1
			x_cur = (x_min_max[0]+x_min_max[1]) * 0.5
			# returns in (0,0)-(1,1)
			pos_test = object_utils.world_to_camera_view(c_scene, camera_obj, active_obj_pos + x_dir*x_cur)
			if abs(pos_test[0] - targetXY[0]) <= kWPLBisectEpsilon:
				break
			if pos_test[0] < targetXY[0]:
				x_min_max[0] = x_cur
			else:
				x_min_max[1] = x_cur
		x_cur_fin = x_cur
		# Y-test
		max_bisects = self.opt_iters
		y_min_max = [-100,100]
		y_cur = y_min_max[0]
		while max_bisects > 0:
			max_bisects = max_bisects-1
			total_bisects = total_bisects+1
			y_cur = (y_min_max[0]+y_min_max[1]) * 0.5
			# returns in (0,0)-(1,1)
			pos_test = object_utils.world_to_camera_view(c_scene, camera_obj, active_obj_pos + y_dir*y_cur)
			if abs(pos_test[1] - targetXY[1]) <= kWPLBisectEpsilon:
				break
			if pos_test[1] < targetXY[1]:
				y_min_max[0] = y_cur
			else:
				y_min_max[1] = y_cur
		y_cur_fin = y_cur
		offset_fin = x_dir*x_cur_fin + y_dir*y_cur_fin
		new_pos = active_obj_pos + offset_fin
		print("- final offset", offset_fin.length, offset_fin)
		active_obj.matrix_world = wla.math_matrixReplace(active_obj.matrix_world, new_pos, None, None)
		self.report({'INFO'}, "Done, bisects executed: "+str(total_bisects))
		return {'FINISHED'}


class wplheal_objo2cursr(bpy.types.Operator):
	bl_idname = "object.wplheal_objo2cursr"
	bl_label = "Snap object orientation to active"
	bl_options = {'REGISTER', 'UNDO'}

	opt_resetOrigin : BoolProperty(
		name		= "Reset origin also",
		default	 = False
	)

	def execute(self, context):
		active_obj = wla.active_object()
		if active_obj is None:
			self.report({'ERROR'}, "Select object first")
			return {'CANCELLED'}
		bpy.ops.view3d.snap_cursor_to_active()
		orientation = None
		reset2GlobalAxis = False
		if active_obj.type == 'MESH' and wla.is_edit_mode():
			# if nothing selected in edit mode - reorient to global axis
			selvertsAll = wla.selected_vertsIdx(active_obj.data)
			if len(selvertsAll) == 0:
				print("- nothing selected in EDIT mode: defaulting orientation to global axises")
				reset2GlobalAxis = True
				aScaM = Matrix().Scale(1, 4, Vector((1,0,0)))
				aScaM = aScaM @ Matrix().Scale(1, 4, Vector((0,1,0)))
				aScaM = aScaM @ Matrix().Scale(1, 4, Vector((0,0,1)))
				orientation = aScaM
			wla_do.select_and_change_mode(active_obj,'EDIT') # selected_vertsIdx drops to OBJECT
		if orientation is None:
			# if active_obj.type == 'MESH' and wla.is_edit_mode():
			# 	print("- creating TEMP orientation from NORMAL")
			# 	wla_do.switch_orientation('NORMAL', 'MEDIAN_POINT')
			# else:
			# 	print("- creating TEMP orientation")
			wla_do.create_temp_orientation()
			if wla.active_context_orient(config.kWPLTempOrien) is not None:
				orientation = wla.active_context_orient(config.kWPLTempOrien).matrix
		if orientation is None:
			self.report({'ERROR'}, "No proper context/Invalid orientation")
			return {'FINISHED'}
		sel_all = wla.selected_objects(['MESH'])
		for selected in sel_all:
			#wla_do.set_active_object(selected)
			wla_do.select_and_change_mode(active_obj,'OBJECT')
			matrix_world_old = selected.matrix_world
			aLoc, aRot, aSca = selected.matrix_world.decompose()
			#aRotEuler = aRot.to_euler('XYZ')
			aLocM = mathutils.Matrix.Translation(aLoc)
			aRotM = orientation.to_quaternion().to_matrix().to_4x4()
			aScaM = Matrix().Scale(aSca[0], 4, Vector((1,0,0)))
			aScaM = aScaM @ Matrix().Scale(aSca[1], 4, Vector((0,1,0)))
			aScaM = aScaM @ Matrix().Scale(aSca[2], 4, Vector((0,0,1)))
			matrix_world_new = aLocM @ aRotM @ aScaM
			wla_do.select_and_change_mode(active_obj,'EDIT')
			bm = bmesh.from_edit_mesh(active_obj.data)
			bmesh.ops.transform(bm, matrix= matrix_world_new.inverted() @ matrix_world_old, verts=bm.verts) #, space=matrix_world_old )
			bm.normal_update()
			bmesh.update_edit_mesh(active_obj.data)
			wla_do.select_and_change_mode(active_obj,'OBJECT')
			active_obj.matrix_world = matrix_world_new
			if self.opt_resetOrigin:
				if reset2GlobalAxis:
					bpy.ops.object.origin_set(type='ORIGIN_GEOMETRY', center='MEDIAN')
				else:
					bpy.ops.object.origin_set(type='ORIGIN_CURSOR', center='MEDIAN')
		wla_do.switch_orientation('LOCAL', 'MEDIAN_POINT')
		wla_do.set_active_object(active_obj)
		if reset2GlobalAxis:
			self.report({'INFO'}, "Reset to GLOBAL: Done")
		else:
			self.report({'INFO'}, "Done")
		return {'FINISHED'}

class wplheal_replacemats(bpy.types.Operator):
	bl_idname = "object.wplheal_replacemats"
	bl_label = "Replace mats"
	bl_options = {'REGISTER', 'UNDO'}

	# zzz_* -> skipped, local_* -> skipped
	# <lib> -> skipped if "library mats" to "non-library mats"
	# <libAny> -> skipped if "library mats" to anything
	# альтернативно можно называть материалы [#mat:<tok>] и делать [Dedup materials] - будет автозамена (но без перекрасов итп)

	opt_objmatReplRules : StringProperty(
		name = "Replacement rules", # ??:..., *:...
		default = config.kWPLSystemMatReplaceDef
	)
	opt_protectMat : StringProperty(
		name = "Protected mats",
		default = "local_, <lib>"
	)
	opt_col2DecorC : EnumProperty(
		name="Recolor according to mat", default="NOPE",
		items=(("NOPE", "Do not", ""), ("ASIS", "Recolor As Is", ""), 
		("WITH_GAMMA", "Recolor As Svg", ""))
	)
	
	# Running as separate dialog
	def invoke(self, context, event):
		return context.window_manager.invoke_props_dialog(self, width = 200)

	def execute( self, context ):
		if len(self.opt_objmatReplRules) == 0:
			self.report({'INFO'}, "Dry run: Target Materials")
			return {'FINISHED'}
		objs2check = wla.selected_objects()
		if len(objs2check) < 1:
			self.report({'ERROR'}, "Dry run: No objects to check/replace")
			return {'FINISHED'}
		if self.opt_col2DecorC != 'NOPE':
			print("- Adding face colors according to material color")
			colmod = "***"
			if "<lib>" in self.opt_protectMat:
				colmod = "**"
			useGammaFix = False
			if self.opt_col2DecorC == 'WITH_GAMMA':
				useGammaFix = True
			bpy.ops.mesh.wplvc_masspalupd(opt_objmatOnly = colmod, opt_objTargetVC=config.kWPLMeshColVC, opt_correctGamma = useGammaFix)
		replMap = {}
		protcRulesTokens = wla.strToTokens(self.opt_protectMat)
		replRulesTokens = wla.strToTokens(self.opt_objmatReplRules)
		for tk in replRulesTokens:
			replPair = tk.split(":")
			if len(replPair) == 2:
				replCount = 0
				replMat = None
				replMatName = replPair[1].strip().lower()
				for mat in bpy.data.materials:
					if replMatName == mat.name.lower():
						replMat = mat
						replMatName = mat.name
						replCount = 1
						print("- found exact replacement", replPair, replMatName)
						break
					if replMatName in mat.name.lower():
						replMat = mat
						replMatName = mat.name
						replCount = replCount+1
						print("- found fuzzy replacement", replPair, replMatName)
				if replCount != 1 or replMat is None:
					self.report({'ERROR'}, "Ambigous/Unknown replacement: ["+tk+","+str(replCount)+"]")
					return {'FINISHED'}
				replMap[replPair[0]] = replMat
		print("- Objects selected:", len(objs2check), replMap)
		count = 0
		active_obj = None
		lastSel_obj = None
		for active_obj in objs2check:
			if active_obj.type == 'MESH' and active_obj.library is None:
				#print("Checking "+active_obj.name)
				mat_slots = {}
				matsUpdated = 0
				for slt in active_obj.material_slots:
					updMat = None
					slt_name = slt.name.lower()
					for opn in replMap.keys():
						if len(opn) > 1 and opn in slt_name:
							updMat = replMap[opn]
							break
					if updMat is None and "*" in replMap:
						updMat = replMap["*"]
					isProtected = False
					if len(protcRulesTokens) > 0 and slt.material is not None:
						if ("<lib>" in protcRulesTokens) or ("<libAny>" in protcRulesTokens):
							if (slt.material.library is not None):
								if ("<libAny>" in protcRulesTokens):
									isProtected = True
								if (updMat is None) or (updMat.library is None):
									isProtected = True
						for protTk in protcRulesTokens:
							if (protTk in slt.material.name.lower()):
								#print("// protkey", protTk)
								isProtected = True
								break
					if isProtected:
						# skipping protected
						print("- Skipping "+slt.name+ ", protected mat")
						continue
					if updMat is not None:
						matsUpdated = matsUpdated+1
						lastSel_obj = active_obj
						# replacing
						print("- Changing "+slt.name+ " to "+updMat.name+", obj: "+active_obj.name)
						slt.material = updMat
						count = count+1
					else:
						print("- Skipping "+slt.name+ ", unknown replace")
		self.report({'INFO'}, "Updated "+str(count)+" mat slots")
		if lastSel_obj is not None:
			wla_do.set_active_object(lastSel_obj)
		return {'FINISHED'}

class wplheal_remunusdats(bpy.types.Operator):
	bl_idname = "object.wplheal_remunusdats"
	bl_label = "Remove unused datas"
	bl_options = {'REGISTER', 'UNDO'}

	opt_remMatsExcept : StringProperty(
			name = "Mats to skip (* for all unused)",
			default = "*"
	)
	opt_remShapeksExcept : StringProperty(
			name = "Shapekeys to skip (* for all shapekeys)",
			default = "*"
	)
	opt_delEmptEmpties : BoolProperty(
			name = "Delete empties with no childrens",
			default = True
	)
	opt_delEmptyMeshes : BoolProperty(
			name = "Delete meshes with no verts",
			default = True
	)
	opt_delUnusedShapes : BoolProperty(
			name = "Delete unused shapes",
			default = True
	)
	opt_delUnusedVG : BoolProperty(
			name = "Delete unused vertex groups",
			default = True
	)
	def execute( self, context ):
		active_obj = wla.active_object()
		objs2check = wla.selected_objects()
		if len(objs2check) < 1:
			self.report({'ERROR'}, "No objects selected")
			return {'CANCELLED'}
		matcount = 0
		shpcount = 0
		empcount = 0
		# if len(self.opt_skipIfParts)>0:
			# skipNameParts = [x.strip().lower() for x in self.opt_skipIfParts.split(",")]
		# else:
			# skipNameParts = []
		ok_objs = []
		for sel_obj in objs2check:
			if sel_obj is None or sel_obj.library is not None:
				continue
			if sel_obj.name.find(config.kWPLSystemReestrToken) >= 0:
				continue
			if self.opt_delUnusedShapes and wla.isTokenInStr(config.kWPLObjShapeToken + config.kWPLObjShaperToken, sel_obj.name):
				isRealShape = False
				if (sel_obj.type == 'MESH' and len(sel_obj.data.polygons) == 0):
					isRealShape = True
				# curves has 1 1 even when used by other curves... wTF //
				# if (active_obj.type == 'CURVE' and active_obj.data.dimensions == '2D'):
				# 	isRealShape = True
				if isRealShape and (sel_obj.users < 2):
					print ("// removing: shape, seems to be unused: users", sel_obj.name, sel_obj.users, sel_obj.data.users)
					bpy.data.objects.remove(sel_obj, do_unlink=True)
					empcount = empcount+1
					continue
			if self.opt_delEmptEmpties and sel_obj.type == 'EMPTY' and len(sel_obj.children) == 0:
				if (config.kWPLObjFrameWrapper not in sel_obj.name) and (config.kWPLObjzRefToken not in sel_obj.name):
					print("- removing: empty empty: "+sel_obj.name)
					bpy.data.objects.remove(sel_obj, do_unlink=True)
					empcount = empcount+1
					continue
			if self.opt_delEmptyMeshes and sel_obj.type == 'MESH':
				if len(sel_obj.data.vertices) == 0:
					print("- removing: mesh with no verts: "+sel_obj.name)
					bpy.data.objects.remove(sel_obj, do_unlink=True)
					empcount = empcount+1
					continue
				if len(sel_obj.data.polygons) == 0 and len(sel_obj.modifiers) == 0 and (wla.isTokenInStr(config.kWPLObjShapeToken + config.kWPLObjShaperToken, sel_obj.name) == False):
					print("- removing: mesh with no face: "+sel_obj.name)
					bpy.data.objects.remove(sel_obj, do_unlink=True)
					empcount = empcount+1
					continue
			if sel_obj.type == 'MESH':
				print("- checking",sel_obj.name,len(sel_obj.data.vertices),len(sel_obj.data.polygons))
				wla_do.select_and_change_mode(sel_obj,"OBJECT")
				isObjMappable = False
				for slt in sel_obj.material_slots:
					mat = slt.material
					if (mat is not None) and mat.use_nodes:
						mat_name = mat.name
						#if (config.kWPLSuppVGScriptToken in mat_name):
						if (config.kWPLSuppVGScriptToken in mat_name) and wla.isTokenInStr(config.kWPLObjCharFaceToken, wla.object_full_name(sel_obj)):
							isObjMappable = True
				shpcount_perobj = 0
				matcount_perobj = 0
				if isObjMappable == False:
					mat_slots = {}
					for p in sel_obj.data.polygons:
						if len(sel_obj.material_slots) > 0 and p.material_index > 0 and p.material_index >= len(sel_obj.material_slots):
							print("// face with matindex > matslots, fixing", p.material_index, len(sel_obj.material_slots))
							p.material_index = 0
						mat_slots[p.material_index] = 1
					mat_slots = mat_slots.keys()
					for i in reversed(range(len(sel_obj.material_slots))):
						if i not in mat_slots:
							#if matcount_perobj == 0:
							#	print("- unused material: "+sel_obj.name)
							matcount_perobj = matcount_perobj+1
							mat_name = sel_obj.material_slots[i].name
							if len(self.opt_remMatsExcept)>0 and self.opt_remMatsExcept.find(mat_name) >= 0:
								print("// skipping material",mat_name)
								continue
							if mat_name.find(config.kWPLSystemReestrToken) >= 0:
								print("// skipping material",mat_name)
								continue
							print("// removing: unused material",mat_name)
							sel_obj.active_material_index = i
							bpy.ops.object.material_slot_remove()
							matcount = matcount+1
				else:
					print("// skipping matcheck: #vgs-material on face object found")
				if sel_obj.data is not None and sel_obj.data.shape_keys is not None and len(sel_obj.data.shape_keys.key_blocks):
					wla_do.select_and_change_mode(sel_obj,"OBJECT")
					keys = sel_obj.data.shape_keys.key_blocks.keys()
					active_idx = 0
					for kk in reversed(keys):
						#if shpcount_perobj == 0:
						#	print("Cleaning shapekeys from "+sel_obj.name)
						shpcount_perobj = shpcount_perobj+1
						if (config.kWPLFrameBindPostfix in kk) or (config.kWPLSystemFinPrefix in kk):
							print("// skipping sk:", kk, ", stopping shapekey checks")
							break
						if len(self.opt_remShapeksExcept)>0 and self.opt_remShapeksExcept.find(kk) >= 0:
							print("// skipping sk:", kk, ", stopping shapekey checks")
							break
						active_idx = keys.index(kk)
						print("// removing: sk",kk,"at",active_idx)
						shape_key = sel_obj.data.shape_keys.key_blocks[kk]
						sel_obj.active_shape_key_index = active_idx
						shape_key.value = 0
						bpy.ops.object.shape_key_remove(all = False)
						sel_obj.data.update()
						shpcount = shpcount+1
				if self.opt_delUnusedVG:
					res = wla_attr.vg_cleanup_groups(sel_obj)
					if res>0:
						print("// removed empty vg", res)
						shpcount = shpcount+res
				ok_objs.append(sel_obj)
		if active_obj not in ok_objs:
			active_obj = None
		wla_do.select_and_activate_multi(ok_objs, active_obj)
		self.report({'INFO'}, "Removed "+str(matcount)+" mats, "+str(shpcount)+" sk/vg, "+str(empcount)+" emptobjs")
		return {'FINISHED'}

class wplheal_massrename(bpy.types.Operator):
	bl_idname = "object.wplheal_massrename"
	bl_label = "Rename object deps"
	bl_options = {'REGISTER', 'UNDO'}

	opt_objReplc : StringProperty(
			description = "DSL: [???:???], [+]???, [-]???",
			# 1) ???:??? -> rename ??? to ???
			# <n> - replaced with original name
			# <1> - replaced with left part
			# <2> - replaced with right part
			# 2) ??? -> remove ???
			# 3) [+]??? -> prefix with ???
			# 4) [-]??? -> unprefix from ???
			# 6) @full_hier - автоматом со всеми чайлдами
			name = "Rename Action",
			default = ""
	)
	opt_skipIf : StringProperty(
			name = "Skip renames for",
			default = ", ".join( [config.kWPLSystemReestrToken] )
	)
	# Running as separate dialog
	def invoke(self, context, event):
		return context.window_manager.invoke_props_dialog(self, width = 300)

	def execute( self, context ):
		sel_all = wla.selected_objects()
		if len(sel_all) < 1:
			self.report({'ERROR'}, "No objects selected")
			return {'FINISHED'}
		replace_list = self.opt_objReplc
		if '@full_hier' in replace_list:
			replace_list = replace_list.replace('@full_hier','')
			sel_all = wla.all_objects_hier(sel_all)
		replaceToks = wla.strToTokens(replace_list, False)
		count = 0
		for obj in sel_all:
			if obj.library is not None:
				continue
			config.performOneTimeUpgrades(obj)
			baseName = obj.name
			print("- Renames: Checking object", baseName)
			objUpdated = False
			# if len(replace_list) > 0 and wla.isTokenInStr(self.opt_skipIf, baseName) == False:
			# 	for tok in replaceToks:
			# 		if tok[0:6] == "[#vgs]":
			# 			prefix = tok[6:]
			# 			replPair = prefix.split(":")
			# 			if len(replPair) == 2:
			# 				# all vgs
			# 				for vg in obj.vertex_groups:
			# 					if replPair[0] in vg.name:
			# 						new_name = vg.name.replace(replPair[0], replPair[1])
			# 						print("- vgs: renaming object vg:", vg.name, "->", new_name)
			# 						vg.name = new_name
			# 						objUpdated = True
			# 				for ocp_key in obj.keys():
			# 					if ('_RNA_UI' not in ocp_key) and (replPair[0] in ocp_key):
			# 						new_ocp_key = ocp_key.replace(replPair[0], replPair[1])
			# 						print("- vgs: renaming object custom prop:", ocp_key, "->", new_ocp_key)
			# 						ocp_val = obj[ocp_key]
			# 						obj[new_ocp_key] = ocp_val
			# 						del obj[ocp_key]
			# 						objUpdated = True
			if obj.type == 'MESH' and config.kWPLMatTokenWPV in obj.data.name:
				print("- skipping object:", baseName, "version token found:", obj.data.name)
				continue
			# objectTag = wla.object_tagFromName(baseName)
			# if objectTag is not None:
			# 	baseName = baseName.replace(config.kWPLNodePrefix+objectTag, "").strip()
			needUpdateObjName = False
			# in case of chinese chars - replacing
			# in case on german, etc - too! Or osl write will fail, not unicode (not needed)
			baseName_noZapchars = ""
			for i in range(len(baseName)):
				#if baseName[i] > u'\u4e000' and baseName[i] < u'\u9fff':
				if ord(baseName[i]) > 128:
					baseName_noZapchars = baseName_noZapchars+"_"
					needUpdateObjName = True
				else:
					baseName_noZapchars = baseName_noZapchars+baseName[i]
			baseName = baseName_noZapchars
			if needUpdateObjName == False:
				if len(replace_list) > 0 and wla.isTokenInStr(self.opt_skipIf, baseName) == False:
					for tok2 in replaceToks:
						if tok2[0:1] == "[":
							if tok2[0:3] == "[+]":
								#print("- prefixing")
								prefix = tok2[3:]
								if baseName[0:len(prefix)] != prefix:
									baseName = prefix+baseName
								needUpdateObjName = True
							elif tok2[0:3] == "[-]":
								#print("- unprefixing")
								prefix = tok2[3:]
								if baseName[0:len(prefix)] == prefix:
									baseName = baseName[len(prefix):]
								needUpdateObjName = True
						elif ":" in tok2:
							#print("- replacing")
							replPair = tok2.split(":")
							if len(replPair) == 2:
								reFrom = replPair[0].strip()
								reTo = replPair[1].strip()
								reFrom = reFrom.replace("&nbsp", " ")
								reFrom = reFrom.replace("<n>", baseName)
								reTo = reTo.replace("&nbsp", " ")
								reTo = reTo.replace("<n>", baseName)
								reTo = reTo.replace("<1>", reFrom)
								reFrom = reFrom.replace("<2>", reTo)
								if reFrom in baseName:
									baseName = baseName.replace(reFrom,reTo)
									#print("- Replace test:", baseName_noZapchars, "["+reFrom+"]", "["+reTo+"]", baseName)
									needUpdateObjName = True
						else:
							reFrom = tok2.strip()
							reFrom = reFrom.replace("&nbsp", " ")
							if reFrom in baseName:
								baseName = baseName.replace(reFrom, "")
								needUpdateObjName = True
			if "__" in baseName:
				baseName = baseName.replace("__","_")
				baseName = baseName.replace("__","_")
				needUpdateObjName = True
			if " _" in baseName:
				baseName = baseName.replace(" _","_")
				baseName = baseName.replace(" _","_")
				needUpdateObjName = True
			if "-_" in baseName:
				baseName = baseName.replace("-_","_")
				needUpdateObjName = True
			if "_-" in baseName:
				baseName = baseName.replace("_-","_")
				needUpdateObjName = True
			if needUpdateObjName == False:
				parts = baseName.rpartition(config.kWPLMatTokenDedup)
				if parts[2].isnumeric() and wla.object_by_name(parts[0]) is None:
					# There is no "initial" object for copy -> removing trailing ".001", etc
					baseName = parts[0]
					needUpdateObjName = True
			if needUpdateObjName and baseName != obj.name:
				# if objectTag is not None:
				# 	baseName = baseName + " " + (config.kWPLNodePrefix+objectTag)
				print("- renaming object:", obj.name, "->", baseName)
				obj.name = baseName
				objUpdated = True
			# object data naming
			namePostfix = ""
			if obj.type == 'ARMATURE':
				namePostfix = "_arm"
			baseDataName = baseName+namePostfix
			baseDataName = wla.strBareName(baseDataName, False, False, False, False, True, True)
			if obj.data is not None and obj.data.name != baseDataName:
				print("- renaming data:", obj.data.name, "->", baseDataName)
				obj.data.name = baseDataName
				objUpdated = True

			if obj.type == 'CURVE':
				if obj.data.bevel_object is not None:
					curveBevelName = baseName+config.kWPLObjShapeToken[0]
					if curveBevelName != obj.data.bevel_object.name:
						print("- renaming curve bevel:", obj.data.bevel_object.name, "->", curveBevelName)
						obj.data.bevel_object.name = curveBevelName
						obj.data.bevel_object.data.name = curveBevelName
						objUpdated = True
			if objUpdated:
				count = count+1
		self.report({'INFO'}, "Updated "+str(count)+" objects")
		return {'FINISHED'}

def gizmo_zzz_ref_update(gizmo_zzz_ref, metadata):
	from . import ops_scene_man
	ops_scene_man.ensureMaterialDrivers()	
	return
# def gizmo_trackvis_update(gizmo_zzz_ref, metadata):
# 	relfill_name = metadata["relfill"]
# 	relfill = wla.object_by_name(relfill_name)
# 	if relfill is not None:
# 		relfill.hide_viewport = gizmo_zzz_ref.hide_viewport
# 		relfill.hide_render = gizmo_zzz_ref.hide_render
# 	return
class wplheal_geomnorml(bpy.types.Operator):
	bl_idname = "object.wplheal_geomnorml"
	bl_label = "Normalize object/geometry"
	bl_options = {'REGISTER', 'UNDO'}

	opt_makeSingleUser : BoolProperty(
		name		= "Make single user",
		default	 = True
	)
	opt_tris2quad : BoolProperty(
		name		= "Tris2Quad",
		default	 = True
	)
	opt_removeDoubles : FloatProperty(
		name		= "Remove doubles+cleanup",
		min = 0.0, max = 100,
		default	 = 0.0001
	)
	opt_applyObjTran : EnumProperty(
		name="Apply Orig/Rot/Scale", default="NONE",
		items=(("NONE", "Nothing", ""), 
			("ORIG", "Reset Origin", ""),
			("ORIGSCAL", "Reset Origin+Scale", ""),
			("ORIGSCALROT", "Reset Origin+Scale+Rotation", "")
		)
	)

	# Running as separate dialog
	def invoke(self, context, event):
		return context.window_manager.invoke_props_dialog(self, width = 200)

	def execute( self, context ):
		sel_all = wla.selected_objects()
		if len(sel_all) == 0:
			self.report({'ERROR'}, "No objects selected")
			return {'FINISHED'}
		skipCount = 0
		meshDataHandled = {}
		print("- Normalize: Checking objects", len(sel_all))
		for i, active_obj in enumerate(sel_all):
			print("Handling object", active_obj.name, i, len(sel_all))
			wla_do.select_and_change_mode(active_obj,"OBJECT")
			if self.opt_makeSingleUser and (active_obj.type != 'EMPTY'):
				if active_obj.data.users > 1:
					print("- Making single-user: [",active_obj.name,"/",active_obj.data.name,"]; current count=",active_obj.data.users)
					bpy.ops.object.make_single_user(object=False, obdata=True)
			if active_obj.library is not None:
				print("- skipping library object")
				continue
			if active_obj.type != 'ARMATURE' and active_obj.type != 'EMPTY' and active_obj.type != 'GPENCIL':
				try:
					if self.opt_applyObjTran != 'NONE':
						if active_obj.data.users < 2:
							resetOrigin = True
							if wla.modf_by_type(active_obj,'MIRROR'):
								resetOrigin = False
							if resetOrigin:
								bpy.ops.object.origin_set(type='ORIGIN_GEOMETRY', center='MEDIAN')
							if self.opt_applyObjTran == 'ORIGSCAL' or self.opt_applyObjTran == 'ORIGSCALROT':
								resetScale = False
								if self.opt_applyObjTran == 'ORIGSCAL' or self.opt_applyObjTran == 'ORIGSCALROT':
									resetScale = True
								resetRota = False
								if self.opt_applyObjTran == 'ORIGSCALROT':
									resetRota = True
								bpy.ops.object.transform_apply(location=False, rotation=resetRota, scale=resetScale)
						else:
							skipCount = skipCount+1
							print("- skipping object (multi-user): [",active_obj.name,"/",active_obj.data.name,"]; current count=",active_obj.data.users)
					if active_obj.type == 'MESH' and (active_obj.data.name not in meshDataHandled):
						meshDataHandled[active_obj.data.name] = 1
						# smooth shading with auto-splits. SPLITSMOOTH
						wla_do.select_and_change_mode(active_obj,"EDIT")
						bpy.ops.mesh.select_all(action='SELECT')
						bpy.ops.mesh.faces_shade_smooth()
						bpy.ops.mesh.select_all(action='SELECT')
						bpy.ops.mesh.delete_loose()
						if self.opt_removeDoubles > 0:
							print("- removing doubles")
							bpy.ops.mesh.select_all(action = 'SELECT')
							bpy.ops.mesh.remove_doubles(threshold = self.opt_removeDoubles)
							bpy.ops.mesh.select_all(action = 'SELECT')
							bpy.ops.mesh.delete_loose()
							bpy.ops.mesh.select_all(action = 'SELECT')
							bpy.ops.mesh.set_normals_from_faces()
							bpy.ops.mesh.select_all(action = 'SELECT')
							bpy.ops.mesh.normals_make_consistent()
						if self.opt_tris2quad:
							print("- tris 2 quads")
							bpy.ops.mesh.select_all(action = 'SELECT')
							bpy.ops.mesh.tris_convert_to_quads()
						bpy.ops.mesh.select_all(action='DESELECT')
						wla_do.select_and_change_mode(active_obj,"OBJECT")
						# for skp files custom normals are not usable at all..
						#bpy.ops.mesh.select_all(action='SELECT')
						bpy.ops.mesh.customdata_custom_splitnormals_clear()
						active_obj.data.use_auto_smooth = True
						active_obj.data.auto_smooth_angle = math.radians(30)
				except:
					pass
		self.report({'INFO'}, "Objects updated: "+str(len(sel_all))+", skips: "+str(skipCount))
		return {'FINISHED'}

# class wplheal_orialign(bpy.types.Operator):
# 	bl_idname = "mesh.wplheal_orialign"
# 	bl_label = "Align to orientation"
# 	bl_options = {'REGISTER', 'UNDO'}

# 	opt_moveOffset : FloatVectorProperty(
# 		name		= "Move Offset",
# 		size = 3,
# 		default	 = (0.0,0.0,0.0),
# 	)
# 	opt_influence : FloatProperty(
# 		name		= "Influence",
# 		default	 = 1.0,
# 		min		 = 0,
# 		max		 = 100
# 	)

# 	def execute(self, context):
# 		active_obj = wla.active_object()
# 		if active_obj is None:
# 			self.report({'ERROR'}, "Select object first")
# 			return {'CANCELLED'}
# 		matrix_world = active_obj.matrix_world
# 		matrix_world_inv = active_obj.matrix_world.inverted()
# 		orient_co = wla.active_context_cursor()
# 		if orient_co is None:
# 			self.report({'ERROR'}, "No proper context/Invalid orientation")
# 			return {'FINISHED'}
# 		orientation = None
# 		if wla.active_context_orient() is not None:
# 			orientation = wla.active_context_orient().matrix
# 		if bpy.context.mode == 'OBJECT' or active_obj.type != 'MESH':
# 			new_co_g = orient_co
# 			if orientation is not None:
# 				new_co_g = new_co_g + self.opt_moveOffset[0]*(orientation @ Vector((1,0,0)))
# 				new_co_g = new_co_g + self.opt_moveOffset[1]*(orientation @ Vector((0,1,0)))
# 				new_co_g = new_co_g + self.opt_moveOffset[2]*(orientation @ Vector((0,0,1)))
# 			aLoc, aRot, aSca = matrix_world.decompose()
# 			aLocM = mathutils.Matrix.Translation(aLoc.lerp(new_co_g,self.opt_influence))
# 			aRotM = mathutils.Matrix.Identity(4)
# 			if orientation is not None:
# 				aRotM = orientation.to_quaternion().to_matrix().to_4x4()
# 			aScaM = Matrix().Scale(aSca[0], 4, Vector((1,0,0)))
# 			aScaM = aScaM @ Matrix().Scale(aSca[1], 4, Vector((0,1,0)))
# 			aScaM = aScaM @ Matrix().Scale(aSca[2], 4, Vector((0,0,1)))
# 			matrix_world = aLocM @ aRotM @ aScaM
# 			active_obj.matrix_world = matrix_world
# 			return {'FINISHED'}
# 		active_mesh = active_obj.data
# 		selvertsAll = wla.selected_vertsIdx(active_mesh)
# 		if len(selvertsAll) == 0:
# 			self.report({'ERROR'}, "No selected verts found")
# 			return {'FINISHED'}
# 		# getting reference position
# 		wla_do.select_and_change_mode(active_obj,'EDIT')
# 		bm = bmesh.from_edit_mesh(active_mesh)
# 		fltCenter = None
# 		fltNormal = None
# 		fltrefs = wla_bm.bm_historyRefCo(bm)
# 		if fltrefs is not None:
# 			fltCenter = fltrefs[0]
# 			fltNormal = fltrefs[1]
# 		else:
# 			fltCenter = Vector((0,0,0))
# 			for vIdx in selvertsAll:
# 				v = bm.verts[vIdx]
# 				fltCenter = fltCenter + v.co
# 			fltCenter = fltCenter/float(len(selvertsAll))
# 		diff_p = (matrix_world_inv @ orient_co)-fltCenter
# 		for vIdx in selvertsAll:
# 			v = bm.verts[vIdx]
# 			new_co = v.co
# 			new_co = new_co+diff_p
# 			if orientation is not None:
# 				new_co = new_co + self.opt_moveOffset[0]*(orientation @ Vector((1,0,0)))
# 				new_co = new_co + self.opt_moveOffset[1]*(orientation @ Vector((0,1,0)))
# 				new_co = new_co + self.opt_moveOffset[2]*(orientation @ Vector((0,0,1)))
# 			v.co = v.co.lerp(new_co,self.opt_influence)
# 		bm.normal_update()
# 		bmesh.update_edit_mesh(active_mesh)
# 		self.report({'INFO'}, "Done, "+str(len(selvertsAll))+" verts moved")
# 		return {'FINISHED'}

class wplheal_clonehier(bpy.types.Operator):
	bl_idname = "object.wplheal_clonehier"
	bl_label = "Clone hierarchy"
	bl_options = {'REGISTER', 'UNDO'}

	def execute( self, context ):
		sel_all = wla.selected_objects() # ALL objects! no type checks
		if len(sel_all) == 0:
			self.report({'ERROR'}, "No objects selected")
			return {'CANCELLED'}
		wla_do.select_and_change_mode(sel_all[0], 'OBJECT')
		sel_all_hier = wla.all_objects_hier(sel_all)
		for obj in sel_all_hier:
			wla_do.ensure_visible(obj, 2)
		wla_do.select_and_activate_multi(sel_all_hier, None)
		#bpy.ops.object.duplicate_move(OBJECT_OT_duplicate={"linked":False, "mode":'TRANSLATION'}, TRANSFORM_OT_translate={"value":(0, 0, 0), "orient_axis_ortho":'X', "orient_type":'GLOBAL', "orient_matrix":((1, 0, 0), (0, 1, 0), (0, 0, 1)), "orient_matrix_type":'GLOBAL', "constraint_axis":(False, False, False), "mirror":False, "use_proportional_edit":False, "proportional_edit_falloff":'SMOOTH', "proportional_size":0.025704, "use_proportional_connected":False, "use_proportional_projected":False, "snap":False, "snap_target":'CLOSEST', "snap_point":(0, 0, 0), "snap_align":False, "snap_normal":(0, 0, 0), "gpencil_strokes":False, "cursor_transform":False, "texture_space":False, "remove_on_cancel":False, "view2d_edge_pan":False, "release_confirm":False, "use_accurate":False, "use_automerge_and_split":False})
		bpy.ops.object.duplicate( linked=False )
		return {'FINISHED'}

class wplheal_tweakobj(bpy.types.Operator):
	bl_idname = "object.wplheal_tweakobj"
	bl_label = "Set object flags"
	bl_options = {'REGISTER', 'UNDO'}

	opt_actionType : EnumProperty(
		name="Action", default="ADDCOL",
		items=(("ADDCOL", "Set collider", ""), ("ADDCOL_EXCL", "Collider excls", ""), ("REMCOL", "Clear collider", ""), 
		("ADDWRFOVL", "Add wireframe", ""), ("REMWRF", "Remove collider", ""), ("ADDWRFFULL", "Wireframe only", ""),
		("ADDXRAY", "Add X-Ray", ""), ("REMXRAY", "Remove x-ray", ""),
		("ADDCYCLSHAD", "Add Cycles:shadow", ""), ("REMCYCLSHAD", "Remove Cycles:shadow", ""),
		("SPLITSMOOTH", "Split-Smooth", ""), ("AUTOSETUPOBJ", "Auto-setup object", ""),
		))


	def execute( self, context ):
		sel_all = wla.selected_objects() # ALL objects! no type checks
		if self.opt_actionType == 'ADDCOL_EXCL':
				# removing colliders from ALL objects
				ok = 0
				for sel_obj in bpy.data.objects:
					prevCld = wla.modf_by_type(sel_obj, 'COLLISION')
					if prevCld is not None:
						sel_obj.modifiers.remove(prevCld)
						ok = ok+1
				print("- mark colliders: removed from", ok, "objects")
				if len(sel_all) == 0:
					# nothing to do
					self.report({'INFO'}, "Removed coll-mark: "+str(ok)+" objects")
					return {'FINISHED'}
		if len(sel_all) == 0:
			self.report({'ERROR'}, "No objects selected")
			return {'CANCELLED'}
		ok = 0
		for i, sel_obj in enumerate(sel_all):
			if self.opt_actionType == 'AUTOSETUPOBJ':
				#print("- autosetup", wla.object_full_name(active_obj), active_obj.name)
				if doAutoSetupCustomProp(sel_obj) == False:
					self.report({'ERROR'}, "Failed to setup custom props")
					return {'FINISHED'}
				if doAutoSetupGeometryNodes(sel_obj) == False:
					self.report({'ERROR'}, "Failed to setup GN object props")
					return {'FINISHED'}
				if doAutoSetupObjWatch(sel_obj) == False:
					self.report({'ERROR'}, "Failed to setup object watch")
					return {'FINISHED'}
				ok = ok+1
			if (self.opt_actionType == 'SPLITSMOOTH') and sel_obj.type in ('MESH'):
				ok = ok+1
				wla_do.select_and_change_mode(sel_obj,'EDIT')
				bpy.ops.mesh.select_all(action='SELECT')
				bpy.ops.mesh.faces_shade_smooth()
				bpy.ops.mesh.select_all(action='DESELECT')
				wla_do.select_and_change_mode(sel_obj,'OBJECT')
				bpy.ops.mesh.customdata_custom_splitnormals_clear()
				sel_obj.data.use_auto_smooth = True
				sel_obj.data.auto_smooth_angle = math.radians(30)
			if ((self.opt_actionType == 'ADDCOL' or self.opt_actionType == 'ADDCOL_EXCL') or self.opt_actionType == 'REMCOL') and sel_obj.type in ('MESH', 'CURVE', 'GPENCIL'):
				prevCld = wla.modf_by_type(sel_obj, 'COLLISION')
				if prevCld is None:
					if (self.opt_actionType == 'ADDCOL' or self.opt_actionType == 'ADDCOL_EXCL'):
						sel_obj.modifiers.new(name = 'wpl_collider', type = 'COLLISION')
						ok = ok+1
				else:
					if self.opt_actionType == 'REMCOL':
						sel_obj.modifiers.remove(prevCld)
						ok = ok+1
			if self.opt_actionType == 'ADDWRFOVL' or self.opt_actionType == 'ADDWRFFULL' or self.opt_actionType == 'REMWRF':
				if self.opt_actionType == 'ADDWRFOVL' or self.opt_actionType == 'ADDWRFFULL':
					sel_obj.show_wire = True
					sel_obj.show_all_edges = True
				else:
					sel_obj.show_wire = False
				if self.opt_actionType == 'ADDWRFFULL':
					sel_obj.display_type = 'WIRE'
				else:
					sel_obj.display_type = 'SOLID'
				ok = ok+1
			if self.opt_actionType == 'ADDXRAY' or self.opt_actionType == 'REMXRAY':
				ok = ok+1
				if self.opt_actionType == 'REMXRAY':
					sel_obj.show_in_front = False
				else:
					sel_obj.show_in_front = True
			if self.opt_actionType == 'ADDCYCLSHAD' or self.opt_actionType == 'REMCYCLSHAD':
				ok = ok+1
				if self.opt_actionType == 'REMCYCLSHAD':
					sel_obj.visible_shadow = False
				else:
					sel_obj.visible_shadow = True
		print("-", self.opt_actionType,"handled", ok, "objects")
		self.report({'INFO'}, "Handled "+str(ok)+" objects")
		return {'FINISHED'}

class wplheal_datarndm(bpy.types.Operator):
	bl_idname = "object.wplheal_datarndm"
	bl_label = "Randomize from stamps data"
	bl_options = {'REGISTER', 'UNDO'}

	# <obj> -> object name (without numbers and stuff) in mesh block name
	# <_rnd> _rnd... in mesh name -> probability of this mesh block
	# opt_dataSelTeplate : StringProperty(
	# 	name="DataSel Template",
	# 	default = "<obj>"
	# )
	# opt_ignoreSelected4blocks : BoolProperty(
	# 	name		= "Skip selection for block search",
	# 	default	 = True
	# )

	def execute( self, context ):
		active_obj = wla.active_object()
		sel_all = wla.selected_objects(['MESH', 'EMPTY'])
		if active_obj is None or len(sel_all) == 0:
			self.report({'ERROR'}, "No objects selected")
			return {'FINISHED'}
		wla_do.select_and_change_mode(active_obj, 'OBJECT')
		ok = 0
		datasForRnd = []
		datasForRndW = []
		# searchTempl = wla.strBareName(wla.strTemplateObj(self.opt_dataSelTeplate, obj), True, True, True, True, True, False)
		# if wla.isTokenInStr(['(',')'], searchTempl):
		# 	# extracting brackets content - tagging for auto-replacement datablocks search
		# 	searchTempl = wla.strExtractOuterBrackets(searchTempl)
		# print("- collecting mesh blocks: originals, with proper name/(name part)")
		sel_all2 = []
		for obj in sel_all:
			if not wla.isTokenInStr(config.kWPLObjStampToken, obj.name):
				continue
			if obj.type == 'MESH':
				sel_all2.append(obj)
			if obj.type == 'EMPTY':
				# gathering childs
				for child in obj.children:
					if child.type == 'MESH':
						sel_all2.append(child)
		for obj in sel_all2:
			if obj.type != 'MESH':
				continue
			block_n = obj.data.name
			if (block_n in datasForRnd):
				continue
			#if searchTempl in wla.strBareName(block_n, True, True, True, False, True, True):
			datasForRnd.append(block_n)
			blockW = 1.0
			blockWfromNameAll = re.findall(r"(?<=_rnd)([0-9]*)",block_n)
			if len(blockWfromNameAll) > 0:
				blockW = float(blockWfromNameAll[0])/100.0
			datasForRndW.append(blockW)
		print("- found valid datablocks", datasForRnd, datasForRndW)
		if len(datasForRnd) == 0:
			self.report({'ERROR'}, "No valid datablocks found")
			return {'FINISHED'}
		datasForRndW_normalized = datasForRndW / np.sum(datasForRndW)
		for obj in sel_all:
			if wla.isTokenInStr(config.kWPLObjStampToken, obj.name) or (obj.type not in ['MESH']):
				continue
			rndDataName = np.random.choice(datasForRnd,None,p=datasForRndW_normalized)
			obj.data = bpy.data.meshes[rndDataName]
			obj.select_set(True)
			ok = ok+1
		self.report({'INFO'}, "Handled "+str(ok)+" objects")
		return {'FINISHED'}


class wplheal_selbymats(bpy.types.Operator):
	bl_idname = "object.wplheal_selbymats"
	bl_label = "Select by mats"
	bl_options = {'REGISTER', 'UNDO'}

	opt_objmatOldParts : StringProperty(
			name = "Materials (* for all)",
			default = ""
	)

	# Running as separate dialog
	def invoke(self, context, event):
		return context.window_manager.invoke_props_dialog(self, width = 200)

	def execute( self, context ):
		additional_mats = []
		if len(self.opt_objmatOldParts) > 0:
			# autosubst
			if self.opt_objmatOldParts not in bpy.data.materials:
				for mat in bpy.data.materials:
					if self.opt_objmatOldParts.lower() in mat.name.lower():
						additional_mats.append(mat.name.lower())
						#self.opt_objmatOldParts = mat.name
						#break
		if len(self.opt_objmatOldParts) == 0:
			self.report({'INFO'}, "Dry run: Target Materials")
			return {'FINISHED'}
		objs2check = [obj for obj in bpy.context.scene.objects]
		bpy.ops.object.select_all(action = 'DESELECT')
		if len(objs2check) < 1:
			self.report({'ERROR'}, "Dry run: No objects to check/replace")
			return {'FINISHED'}
		objmatOldParts = wla.strToTokens(self.opt_objmatOldParts)
		print("- Looking for", objmatOldParts, "in",len(objs2check),"objects")
		count = 0
		objCount = 0
		objCountFail = 0
		active_obj = None
		lastSel_obj = None
		for active_obj in objs2check:
			if (active_obj.type == 'MESH' or active_obj.type == 'CURVE' or active_obj.type == 'FONT') and active_obj.library is None:
				#print("Checking "+active_obj.name)
				mat_slots = {}
				matsUpdated = 0
				for slt in active_obj.material_slots:
					isNeedUpdMat = False
					slt_name = slt.name.lower()
					for opn in additional_mats:
						if opn == slt_name:
							isNeedUpdMat = True
							break
					for opn in objmatOldParts:
						if opn == '*' or opn in slt_name:
							isNeedUpdMat = True
							break
					if isNeedUpdMat:
						matsUpdated = matsUpdated+1
						lastSel_obj = active_obj
						print("- Selecting", wla.object_full_name(active_obj) )
						try:
							lastSel_obj.select_set(True)
						except Exception as e:
							print("// Failed to select:"+str(e))
							objCountFail = objCountFail+1
						objCount = objCount+1
						break
		self.report({'INFO'}, "Selected "+str(objCount)+" objects, errs="+str(objCountFail))
		if lastSel_obj is not None:
			wla_do.set_active_object(lastSel_obj)
		return {'FINISHED'}

# ==========================================
# ==========================================
# ==========================================
# ==========================================

class WPL_PT_HealPanel1(bpy.types.Panel):
	bl_idname = "WPL_PT_HealPanel1"
	bl_label = "Object controls"
	bl_space_type = 'VIEW_3D'
	bl_region_type = 'UI'
	bl_category = "OBJ"

	def draw(self, context):
		layout = self.layout
		active_obj = wla.active_object()
		col = layout.column()
		if active_obj is not None:
			if bpy.context.mode == 'OBJECT':
				col.label(text="* OBJECT: "+active_obj.name+", SEL: "+str(len(wla.selected_objects())))
				# if "_WPL_PT_HealPanel_tmp1" in config.WPL_G.store:
				# 	del config.WPL_G.store["_WPL_PT_HealPanel_tmp1"]
			else:
				col.label(text="* EDIT: "+active_obj.name+", MODE: "+('VERT' if context.tool_settings.mesh_select_mode[0] else '')+('EDGE' if context.tool_settings.mesh_select_mode[1] else '')+('FACE' if context.tool_settings.mesh_select_mode[2] else ''))
				# if active_obj.type=='MESH':
				# 	active_mesh = active_obj.data
				# 	selectedVertsIdx = None
				# 	selectedFacesIdx = None
				# 	if "_WPL_PT_HealPanel_tmp1" in config.WPL_G.store:
				# 		(selectedVertsIdx, selectedFacesIdx, aon) = config.WPL_G.store["_WPL_PT_HealPanel_tmp1"]
				# 		if aon != active_obj.name:
				# 			selectedVertsIdx = None
				# 			selectedFacesIdx = None
				# 			del config.WPL_G.store["_WPL_PT_HealPanel_tmp1"]
				# 	if selectedVertsIdx is None:
				# 		selectedVertsIdx = [e.index for e in active_mesh.vertices if e.select]
				# 		selectedFacesIdx = [f.index for f in active_mesh.polygons if f.select]
				# 		config.WPL_G.store["_WPL_PT_HealPanel_tmp1"] = (selectedVertsIdx, selectedFacesIdx, active_obj.name)
				# 	col.label(text="* verts: "+str(len(active_mesh.vertices))+" ("+str(len(selectedVertsIdx))+"), faces: "+str(len(active_mesh.polygons))+" ("+str(len(selectedFacesIdx))+")")
			box3 = col.box()
			box3.operator("object.wplheal_wrapempty", text="Wrap in empty", icon = 'EMPTY_DATA')
			if bpy.context.mode == 'OBJECT':
				box1x = box3.column(align=True)
				box1r = box1x.row(align=True)
				box1r.operator("mesh.wplverts_vcopy", text="COPY Objects", icon='COPYDOWN').opt_mode = 'COPY_OBJS'
				box1r.operator("mesh.wplverts_vpaste", text="MOVE Aside", icon='PASTEDOWN').opt_postAlign = 'MOVE_OBJSASIDE'
				box1r = box1x.row(align=True)
				box1r.operator("mesh.wplverts_vpaste", text="MOVE Inside", icon='PASTEDOWN').opt_postAlign = 'MOVE_OBJSINSIDE'
				box1r.operator("mesh.wplverts_vpaste", text="... with cursor", icon='ORIENTATION_CURSOR').opt_postAlign = 'MOVE_OBJS2CURS'
			box3.separator()
			box1r = box3.row(align=True)
			box1r.operator("object.wplheal_pushmatrix", text="COPY matrix", icon='COPYDOWN')
			box1r.operator("object.wplheal_popmatrix", text="PASTE matrix", icon='PASTEDOWN')
			box3.label(text = "Obj: Snapping")
			box4c = box3.column(align=True)
			box4r = box4c.row(align=True)
			spl = box4r.split(align=True, factor=0.6)
			spl.operator("object.wplheal_parn2cursr", text="Parent to active", icon='FILE_PARENT').opt_use3Dcursor = False
			spl.operator("object.wplheal_parn2cursr", text="... to cursor").opt_use3Dcursor = True
			box4c = box3.column(align=True)
			box4r = box4c.row(align=True)
			spl = box4r.split(align=True, factor=0.6)
			spl.operator("object.wplheal_orig2cursr", text="Origin to active", icon='OBJECT_ORIGIN').opt_use3Dcursor = False
			spl.operator("object.wplheal_orig2cursr", text="... to cursor").opt_use3Dcursor = True
			box4r = box3.row(align=True)
			spl = box4r.split(align=True, factor=0.6)
			spl.operator("object.wplheal_objo2cursr", text="Re-orient to active", icon='ORIENTATION_GIMBAL').opt_resetOrigin = False # orientation of active will be set as object orientation inplace
			spl.operator("object.wplheal_objo2cursr", text="... with origin").opt_resetOrigin = True

			obj_pos = active_obj.matrix_world @ Vector((0,0,0))
			obj_bbc, _ = wla.object_bounds_recursive(active_obj, None)
			bbc_min_pt = [ min(item[0] for item in obj_bbc), min(item[1] for item in obj_bbc), min(item[2] for item in obj_bbc)]
			bbc_max_pt = [ max(item[0] for item in obj_bbc), max(item[1] for item in obj_bbc), max(item[2] for item in obj_bbc)]
			box3.label(text="Obj: pos({:.2f}:{:.2f}:{:.2f}) bnd({:.1f}:{:.1f}:{:.1f})".format(obj_pos[0], obj_pos[1], obj_pos[2], abs(bbc_max_pt[0]-bbc_min_pt[0]), abs(bbc_max_pt[1]-bbc_min_pt[1]), abs(bbc_max_pt[2]-bbc_min_pt[2])))
			# ao_mw_nrm_g = active_obj.matrix_world.inverted().transposed().to_3x3()
			# obj_xDir = ao_mw_nrm_g @ Vector((1,0,0))
			# box3.label(text="* x-axis: "+"{:.3f}:{:.3f}:{:.3f}".format(obj_xDir[0], obj_xDir[1], obj_xDir[2]))
			# obj_zDir = ao_mw_nrm_g @ Vector((0,0,1))
			# box3.label(text="* z-axis: "+"{:.3f}:{:.3f}:{:.3f}".format(obj_zDir[0], obj_zDir[1], obj_zDir[2]))
			# active_cursorPos = wla.active_context_cursor()
			# box3.label(text="* 3D-cur: "+"{:.3f}:{:.3f}:{:.3f}".format(active_cursorPos[0], active_cursorPos[1], active_cursorPos[2]))
		else:
			col.label(text="* OBJECT: None")

class WPL_PT_HealPanel2(bpy.types.Panel):
	bl_idname = "WPL_PT_HealPanel2"
	bl_label = "Misc tools"
	bl_space_type = 'VIEW_3D'
	bl_region_type = 'UI'
	bl_category = "OBJ"

	def draw(self, context):
		layout = self.layout
		active_obj = wla.active_object()
		col = layout.column()
		# col.operator("object.wplheal_tweakobj", text='Obj: Add Smooth-Split shading').opt_actionType = 'SPLITSMOOTH'
		#col.operator("object.wplheal_tweakobj", icon="FILE_REFRESH", text="Obj: AutoSetup active").opt_actionType = 'AUTOSETUPOBJ'
		op = col.operator("object.wplheal_geomnorml", text="Objects: Normalize imported geom")
		op.opt_applyObjTran = 'ORIGSCAL'
		op.opt_removeDoubles = 0.0001
		col.operator("object.wplheal_datarndm", text="Objects: Randomize with Stamps", icon='PARTICLEMODE')
		col.separator()
		row1 = col.row(align=True)
		row1.operator("object.wplheal_tweakobj", text='Wire ON', icon = 'MOD_WIREFRAME').opt_actionType = 'ADDWRFOVL'
		row1.operator("object.wplheal_tweakobj", text='Wire OFF').opt_actionType = 'REMWRF'
		row1.operator("object.wplheal_tweakobj", text='Wire FULL').opt_actionType = 'ADDWRFFULL'
		row1 = col.row(align=True)
		row1.operator("object.wplheal_tweakobj", text='XRay ON', icon = 'MOD_WIREFRAME').opt_actionType = 'ADDXRAY'
		row1.operator("object.wplheal_tweakobj", text='XRay OFF').opt_actionType = 'REMXRAY'
		row1 = col.row(align=True)
		row1.operator("object.wplheal_tweakobj", text='Collider ON', icon = 'PHYSICS').opt_actionType = 'ADDCOL'
		row1.operator("object.wplheal_tweakobj", text='Collider OFF').opt_actionType = 'REMCOL'
		row1 = col.row(align=True)
		row1.operator("object.wplheal_tweakobj", text='Shadow ON').opt_actionType = 'ADDCYCLSHAD'
		row1.operator("object.wplheal_tweakobj", text='Shadow OFF').opt_actionType = 'REMCYCLSHAD'
		col.separator()
		col.operator("object.wplheal_objo2camv", text="Object: Snap to screen-space point")
		col.operator("object.wplheal_massrename", text="Objects: Mass-Rename deps").opt_objReplc = ""

# ==========================================
# ==========================================

classes = (
	WPL_PT_HealPanel1,
	WPL_PT_HealPanel2,

	wplheal_pushmatrix,
	wplheal_popmatrix,
	#wplheal_orialign,
	wplheal_meshversion,

	wplheal_wrapempty,
	wplheal_tweakobj,
	wplheal_clonehier,

	wplheal_parn2cursr,
	wplheal_orig2cursr,
	wplheal_objo2cursr,
	wplheal_objo2camv,
	wplheal_datarndm,
	wplheal_replacemats,
	wplheal_remunusdats,
	wplheal_massrename,
	wplheal_selbymats,
	wplheal_geomnorml
)

def register():
	for cls in classes:
		bpy.utils.register_class(cls)

def unregister():
	for cls in reversed(classes):
		bpy.utils.unregister_class(cls)

if __name__ == "__main__":
	register()