import os, sys, time, datetime
import math, copy, string, random
import numpy as np
import bpy, bmesh, mathutils

import bpy.types
from mathutils import Vector, Matrix, Euler, Quaternion
from mathutils.bvhtree import BVHTree
from mathutils.kdtree import KDTree
from bpy_extras import view3d_utils
from bpy.props import *

from . import config
from .tools import wla
from .tools import wla_do
from .tools import wla_bm
from .tools import wla_attr
from .tools import wla_arma
from .tools import wla_meshwrap
from .tools import wla_vgbind

kWPLGKey_FaceCP = "faceCopyPaste"
kWPLGKey_LeftRightPin = "wplself_leftrightini"
kWPLGKey_ObjSelCP = "objsCopyPaste"
kWPLArmAlignBns_MB = 'neck, clavicle, pelvis, spine, upperarm_R+upperarm_twist_R, upperarm_L+upperarm_twist_L, lowerarm_R+lowerarm_twist_R, lowerarm_L+lowerarm_twist_L, thigh_R+thigh_twist_R, thigh_L+thigh_twist_L, calf_R+calf_twist_R, calf_L+calf_twist_L, foot, thumb01, thumb02, thumb03, pinky00, ring00, middle00, index00, pinky01, ring01, middle01, index01, pinky02, ring02, middle02, index02, pinky03, ring03, middle03, index03'
kWPLArmAlignBns_MLOW = 'bn_shoulder, bn_upperarm, bn_forearm, bn_spine, bn_breast, bn_thigh, bn_shin, bn_foot, bn_toe, bn_hand, thumb01, thumb02, thumb03, pinky00, ring00, middle00, index00, pinky01, ring01, middle01, index01, pinky02, ring02, middle02, index02, pinky03, ring03, middle03, index03; bn_breast.L<, bn_breast.R<'

# kWPLArmMeshPartHide_Body_MB = 'clavicle,spine,pelvis,breast,!upperarm_L:0.12,!upperarm_R:0.12,!thigh_twist_L:0.5,!thigh_twist_R:0.5,!head:0.5'
# kWPLArmMeshPartHide_ArmL_MB = 'lowerarm_L,upperarm_L,!clavicle:0.12'
# kWPLArmMeshPartHide_ArmR_MB = 'lowerarm_R,upperarm_R,!clavicle:0.12'
# kWPLArmMeshPartHide_LegL_MB = 'thigh_L,calf_L,calf_twist_L'
# kWPLArmMeshPartHide_LegR_MB = 'thigh_R,calf_R,calf_twist_R'
# kWPLArmMeshPartHide_Hands_MB = 'hand,pinky,ring,middle,index,thumb,!lowerarm_L:0.005,!lowerarm_R:0.005'
# kWPLArmMeshPartHide_Body_MLOW = 'bn_shoulder,bn_spine,bn_pelvis,bn_breast,!bn_thigh:0.5,!bn_upperarm:0.5'
# kWPLArmMeshPartHide_ArmL_MLOW = 'bn_upperarm01.L:0.6,bn_upperarm02.L:0.6,bn_forearm01.L:0.6,bn_forearm02.L:0.6,!bn_shoulder.L:0.1,!bn_spine:0.1'
# kWPLArmMeshPartHide_ArmR_MLOW = 'bn_upperarm01.R:0.6,bn_upperarm02.R:0.6,bn_forearm01.R:0.6,bn_forearm02.R:0.6,!bn_shoulder.R:0.1,!bn_spine:0.1'
# kWPLArmMeshPartHide_LegL_MLOW = 'bn_thigh01.L,bn_thigh02.L,bn_shin01.L,bn_shin02.L,!bn_spine:0.2,!bn_pelvis:0.3'
# kWPLArmMeshPartHide_LegR_MLOW = 'bn_thigh01.R,bn_thigh02.R,bn_shin01.R,bn_shin02.R,!bn_spine:0.2,!bn_pelvis:0.3'
# kWPLArmMeshPartHide_Hands_MLOW = 'hand,pinky,ring,middle,index,thumb,!bn_forearm:0.5'


# ==========================================

class wplverts_sele_fill(bpy.types.Operator):
	bl_idname = "mesh.wplverts_sele_fill"
	bl_label = "Fill-Select"
	bl_options = {'REGISTER', 'UNDO'}

	opt_iterations : IntProperty(
		name	 = "Fill iterations",
		default	 = 10
	)
	opt_boundMode : EnumProperty(
		name="Bounds mode", default="MATERIAL",
		items=(("SELECTED", "Selected verts", ""), 
			("SEAMS", "Seam verts", ""), 
			("CREASE", "Creased verts", ""),
			("MATERIAL", "Same material", ""))
	)
	opt_fillAcrossFaces : BoolProperty(
		name="Go across faces",
		default=True,
	)
	opt_fillAcrossHidden : BoolProperty(
		name="Go across hidden",
		default=False,
	)
	opt_aggressiveStop : BoolProperty(
		name="Aggressive barriers",
		default=False, # sometime easier to deselect extra, that to select inners
	)
	opt_selectWithBorders : BoolProperty(
		name="Select borders",
		default=True,
	)
	def execute( self, context ):
		active_obj = wla.active_object(['MESH'])
		if active_obj is None:
			self.report({'ERROR'}, "Select mesh object first")
			return {'CANCELLED'}
		wla_do.select_and_change_mode(active_obj,"OBJECT")
		active_mesh = active_obj.data
		selvertsAll = []
		if self.opt_boundMode == 'SELECTED':
			selvertsAll = wla.selected_vertsIdx(active_mesh)
		if self.opt_boundMode == 'MATERIAL':
			wla_do.select_and_change_mode(active_obj,"EDIT")
			bm = bmesh.from_edit_mesh( active_mesh )
			bm.verts.ensure_lookup_table()
			bm.verts.index_update()
			bm.edges.ensure_lookup_table()
			bm.edges.index_update()
			for v in bm.verts:
				if len(v.link_faces) > 0:
					matIdx = v.link_faces[0].material_index
					for vf in v.link_faces:
						if matIdx != vf.material_index:
							matIdx = -999
							break
					if matIdx == -999:
						selvertsAll.append(v.index)
		else:
			wla_do.select_and_change_mode(active_obj,"OBJECT")
			seam_vertsIdx, crease_vertsIdx = wla_meshwrap.objectm_extractVertsByType(active_obj)
			if self.opt_boundMode == 'SEAMS':
				selvertsAll = seam_vertsIdx
			if self.opt_boundMode == 'CREASE':
				selvertsAll = crease_vertsIdx
		if len(selvertsAll) < 2:
			wla_do.select_and_change_mode(active_obj,"EDIT")
			self.report({'ERROR'}, "No bound verts found")
			return {'FINISHED'}
		fillAcrossFaces = self.opt_fillAcrossFaces
		selectWithBorders = self.opt_selectWithBorders
		wla_do.select_and_change_mode(active_obj,"EDIT")
		context.tool_settings.mesh_select_mode = (True, False, False) # 'VERT'
		bm = bmesh.from_edit_mesh( active_mesh )
		bm.verts.ensure_lookup_table()
		bm.verts.index_update()
		bm.edges.ensure_lookup_table()
		bm.edges.index_update()
		histVertsIdx = wla_bm.bm_historyVertsIdx(bm)
		if len(histVertsIdx) == 0:
			self.report({'ERROR'}, "No active vert found")
			return {'CANCELLED'}
		vSeed = bm.verts[histVertsIdx[0]]
		blockVerts = []
		if self.opt_boundMode != 'SELECTED' and (vSeed.index in selvertsAll):
			# selecting INSIDE block-vert
			fillAcrossFaces = True
			selectWithBorders = False
			for v in bm.verts:
				if v.index == vSeed.index:
					continue
				if v.index in selvertsAll:
					continue
				blockVerts.append(v.index)
		else:
			blockVerts = [vIdx for vIdx in selvertsAll if vIdx != vSeed.index]
		seedVerts = [vSeed.index]
		visitedVerts = []
		finalVerts = []
		okCnt = 0
		for iter in range(0, self.opt_iterations):
			seedVertsCpy = copy.copy(seedVerts)
			for vIdx in seedVertsCpy:
				if (vIdx in blockVerts) or (vIdx in visitedVerts):
					continue
				v = bm.verts[vIdx]
				visitedVerts.append(vIdx)
				sideVerts = []
				if self.opt_fillAcrossHidden == False:
					sideVertsEdges = [e.other_vert(v) for e in v.link_edges]
				else:
					sideVertsEdges = [e.other_vert(v) for e in v.link_edges if e.other_vert(v).hide == False]
				if fillAcrossFaces:
					for f in v.link_faces:
						for v2 in f.verts:
							if self.opt_fillAcrossHidden == False and v2.hide:
								continue
							if v2.index != v.index and v2.index not in sideVerts:
								sideVerts.append(v2)
				else:
					sideVerts = sideVertsEdges
				for v2 in sideVerts:
					if v2.index in visitedVerts:
						continue
					if v2.index in blockVerts:
						finalVerts.append(v2.index)
						if self.opt_aggressiveStop and v2 in sideVertsEdges: # blocking all neared to this one. only for "real edges" verts!
							for e2 in v2.link_edges:
								v2a = e2.other_vert(v2)
								if v2a.index not in visitedVerts:
									if v2a.index not in blockVerts:
										blockVerts.append(v2a.index)
						continue
					okCnt = okCnt+1
					if v2.index not in seedVerts:
						seedVerts.append(v2.index)
		verts2sel = []+visitedVerts
		# for vIdx in visitedVerts:
		# 	v = bm.verts[vIdx]
		# 	v.select = True
		if selectWithBorders:
			verts2sel = verts2sel+finalVerts
			# for vIdx in finalVerts:
			# 	v = bm.verts[vIdx]
			# 	v.select = True
		wla_bm.bm_selectVertEdgesFaces(bm, verts2sel, None)
		okCnt = okCnt+1
		bmesh.update_edit_mesh(active_mesh)
		self.report({'INFO'}, "Verts selected: "+str(okCnt))
		return {'FINISHED'}

# class wplverts_chaindesel(bpy.types.Operator):
# 	bl_idname = "mesh.wplverts_chaindesel"
# 	bl_label = "Deselect short chains"
# 	bl_options = {'REGISTER', 'UNDO'}
	
# 	opt_chainlen : IntProperty(
# 		name	 = "Chain len threshold",
# 		default	 = 3
# 	)
# 	opt_angleprc : FloatProperty(
# 		name	 = "Max step angle",
# 		default	 = 360.0
# 	)
# 	opt_crossdir : BoolProperty(
# 		name="Deselect bigger",
# 		default=False,
# 	)

# 	def execute( self, context ):
# 		active_obj = wla.active_object(['MESH'])
# 		if active_obj is None:
# 			self.report({'ERROR'}, "Select mesh object first")
# 			return {'CANCELLED'}
# 		active_mesh = active_obj.data
# 		seledgAll = wla.selected_edgesIdx(active_mesh)
# 		wla_do.select_and_change_mode(active_obj,"EDIT")
# 		if len(seledgAll) == 0:
# 			self.report({'ERROR'}, "No selected edges found")
# 			return {'FINISHED'}
# 		bm = bmesh.from_edit_mesh( active_mesh )
# 		bm.edges.ensure_lookup_table()
# 		bm.edges.index_update()
# 		edgeChains = wla_bm.bm_edgeSegmented(bm, seledgAll, math.radians(self.opt_angleprc))
# 		deselEdges = []
# 		for eIdx in seledgAll:
# 			e_chain = None
# 			for chn in edgeChains:
# 				if eIdx in chn:
# 					e_chain = chn
# 					break
# 			if (e_chain is not None) and self.opt_crossdir == False and len(e_chain) <= self.opt_chainlen:
# 				deselEdges.append(eIdx)
# 			if (e_chain is not None) and self.opt_crossdir == True and len(e_chain) >= self.opt_chainlen:
# 				deselEdges.append(eIdx)
# 		bpy.ops.mesh.select_all(action = 'DESELECT')
# 		context.tool_settings.mesh_select_mode = (False, True, False) # 'EDGE'
# 		for eIdx in seledgAll:
# 			if eIdx not in deselEdges:
# 				e = bm.edges[eIdx]
# 				e.select = True
# 		# DBG
# 		# bpy.ops.mesh.select_all(action = 'DESELECT')
# 		# if self.opt_chainlen < len(edgeChains):
# 		# 	for eIdx in edgeChains[self.opt_chainlen]:
# 		# 		e = bm.edges[eIdx]
# 		# 		e.select = True
# 		bmesh.update_edit_mesh(active_mesh)
# 		self.report({'INFO'}, "Deselected: "+str(len(deselEdges))+" edges")
# 		return {'FINISHED'}

class wplverts_sele_leftright(bpy.types.Operator):
	bl_idname = "mesh.wplverts_sele_leftright"
	bl_label = "Select parallel edges"
	bl_options = {'REGISTER', 'UNDO'}
	
	opt_left : BoolProperty(
		name="Left edges",
		default=True,
	)
	opt_right : BoolProperty(
		name="Right edges",
		default=True,
	)
	opt_pattern: StringProperty(
		name		= "Pattern [01]",
		default	 	= "1",
	)

	def resetOpts(self):
		if kWPLGKey_LeftRightPin in config.WPL_G.store:
			del config.WPL_G.store[kWPLGKey_LeftRightPin]
		self.opt_pattern = "1"
		return

	def execute( self, context ):
		active_obj = wla.active_object(['MESH'])
		if active_obj is None:
			self.resetOpts()
			self.report({'ERROR'}, "Select mesh object first")
			return {'CANCELLED'}
		selsCount = 0
		maxSelects = 400
		repeatCount = min(len(self.opt_pattern), maxSelects)
		active_mesh = active_obj.data
		oldmode = wla_do.select_and_change_mode(active_obj, 'OBJECT')
		vertsIdx = wla.selected_vertsIdx(active_mesh)
		edgesIdx = wla.selected_edgesIdx(active_mesh)
		if len(edgesIdx)<1:
			self.resetOpts()
			self.report({'ERROR'}, "No selected edges found, select some edges first")
			wla_do.select_and_change_mode(active_obj, oldmode)
			return {'FINISHED'} # or all changes get lost!!!
		wla_do.select_and_change_mode(active_obj, 'EDIT')
		context.tool_settings.mesh_select_mode = (False, True, False) # 'EDGE'
		bm = bmesh.from_edit_mesh(active_mesh)
		bm.verts.ensure_lookup_table()
		bm.faces.ensure_lookup_table()
		bm.edges.ensure_lookup_table()
		bm.verts.index_update()
		vertStepInits = None
		vertStepMap = None
		vertLeft2vMap = None
		if kWPLGKey_LeftRightPin in config.WPL_G.store:
			needReset = False
			dat = config.WPL_G.store[kWPLGKey_LeftRightPin]
			vertStepInits = dat[0]
			vertStepMap = dat[1]
			vertLeft2vMap = dat[2]
			if dat[3] != active_obj.name:
				needReset = True
			for vIdx in vertStepInits:
				if vIdx not in vertsIdx:
					# some of initials was deselected
					needReset = True
					break
			if needReset == True:
				vertStepInits = None
				vertStepMap = None
				vertLeft2vMap = None
		if vertLeft2vMap is None:
			print("- calculating Left-Right mappings")
			vertLeft2vMap = {}
			vertStepInits = vertsIdx
			vertStepInits_curves = wla_bm.bm_splitVertsByConnection(bm, vertStepInits, True, None, None)
			_, vertStepMap, vertLeftList, _ = wla_bm.bm_geodesicDistmap_v05(bm, vertStepInits_curves, maxSelects, None, False, False)
			for vIdx in vertStepMap.keys():
				if vIdx in vertLeftList:
					vertLeft2vMap[vIdx] = True
				else:
					vertLeft2vMap[vIdx] = False
			config.WPL_G.store[kWPLGKey_LeftRightPin] = (vertStepInits, vertStepMap, vertLeft2vMap, active_obj.name)
		edges2sel_set = set()
		edges2desel_set = set()
		vertsIdx_set = set(vertsIdx)
		vertStepMap_set = set(vertStepMap)
		# faces2skip_set = set()
		for repeatIdx in range(0, repeatCount):
			repeatVal = True
			if self.opt_pattern[repeatIdx] in "-0?":
				print("- step", repeatIdx+1,"- deselect")
				repeatVal = False
			else:
				print("- step", repeatIdx+1,"- select")
			usedVerts_set = set()
			for f in bm.faces:
				# if f.index in faces2skip_set:
				# 	continue
				cursels = 0
				curmaxstep = -1
				for fv in f.verts:
					vIdx = fv.index
					if (vIdx in vertsIdx_set) and (vIdx in vertStepMap_set):
						cursels = cursels+1
						curmaxstep = max(curmaxstep, vertStepMap[vIdx])
				if cursels > 1 and curmaxstep > 0:
					# some of edges of this face may be next left/right!!!
					for fe in f.edges:
						isEdge2sel = False
						vIdx1 = fe.verts[0].index
						vIdx2 = fe.verts[1].index
						if (vIdx1 in vertStepMap_set) and (vIdx2 in vertStepMap_set):
							if (vertStepMap[vIdx1] == curmaxstep+1) and (vertStepMap[vIdx2] == curmaxstep+1):
								isEdge2sel = True
						if isEdge2sel and self.opt_left == False:
							if (vertLeft2vMap[vIdx1] == True) or (vertLeft2vMap[vIdx2] == True):
								isEdge2sel = False
						if isEdge2sel and self.opt_right == False:
							if (vertLeft2vMap[vIdx1] == False) or (vertLeft2vMap[vIdx2] == False):
								isEdge2sel = False
						if isEdge2sel:
							if repeatVal == True:
								edges2sel_set.add(fe)
							if repeatVal == False:
								edges2desel_set.add(fe)
							#fe.select = repeatVal # ??? reselect+iterate == slow
							# adding to initial "selections" for any selection case
							usedVerts_set.add(vIdx1)
							usedVerts_set.add(vIdx2)
							# if f.index not in faces2skip_set:
							# 	faces2skip_set.add(f.index)
							# edgesIdx - not used
			vertsIdx_set = vertsIdx_set.union(usedVerts_set)
			vertsIdx = list(vertsIdx_set)
		for fe in edges2sel_set:
			selsCount = selsCount+1
			fe.select = True
		for fe in edges2desel_set:
			fe.select = False
		bmesh.update_edit_mesh(active_mesh)
		wla_do.select_and_change_mode(active_obj, oldmode)
		print("- selection:", selsCount)
		self.report({'INFO'}, "Done")
		return {'FINISHED'}

class wplverts_sele_forwbacw(bpy.types.Operator):
	bl_idname = "mesh.wplverts_sele_forwbacw"
	bl_label = "Select forward edge"
	bl_options = {'REGISTER', 'UNDO'}

	opt_forward : BoolProperty(
		name="Forward edge",
		default=True,
	)
	opt_backward : BoolProperty(
		name="Backward edge",
		default=True,
	)
	opt_flowNorml : EnumProperty(
		items = [
			('AUTO', "Auto", "", 1),
			('LOCALZ', "Local Z", "", 2),
			('LOCALX', "Local X", "", 3),
			('LOCALY', "Local Y", "", 4),
		],
		name="Forward direction",
		default='AUTO',
	)
	opt_pattern: StringProperty(
		name		= "Pattern [01]",
		default	 	= "1",
	)

	def resetOpts(self):
		self.opt_pattern = "1"
		return

	def execute( self, context ):
		active_obj = wla.active_object(['MESH'])
		if active_obj is None:
			self.resetOpts()
			self.report({'ERROR'}, "Select mesh object first")
			return {'CANCELLED'}
		forward_dir_l = Vector((1,0,0))
		if self.opt_flowNorml == 'LOCALY':
			forward_dir_l = Vector((0,1,0))
		if self.opt_flowNorml == 'LOCALZ':
			forward_dir_l = Vector((0,0,1))
		if wla.active_context_orient() is not None:
			orientation = wla.active_context_orient().matrix
			forward_dir_l = active_obj.matrix_world.inverted() @ (orientation @ (active_obj.matrix_world @ forward_dir_l) )
		forward_dir_l = forward_dir_l.normalized()
		active_mesh = active_obj.data
		oldmode = wla_do.select_and_change_mode(active_obj, 'OBJECT')
		vertsIdx = wla.selected_vertsIdx(active_mesh)
		edgesIdx = wla.selected_edgesIdx(active_mesh)
		if len(edgesIdx)<1:
			self.resetOpts()
			self.report({'ERROR'}, "No selected edges found, select some edges first")
			return {'FINISHED'} # or all changes get lost!!!
		wla_do.select_and_change_mode(active_obj, 'EDIT')
		context.tool_settings.mesh_select_mode = (False, True, False) # 'EDGE'
		bm = bmesh.from_edit_mesh(active_mesh)
		bm.verts.ensure_lookup_table()
		bm.faces.ensure_lookup_table()
		bm.edges.ensure_lookup_table()
		bm.verts.index_update()

		_,strands_vidx = wla_bm.bm_edgesAsStrands_v04(active_obj, bm, vertsIdx, edgesIdx, None, None)
		if strands_vidx is None:
			self.report({'ERROR'}, "No edges found")
			return {'FINISHED'} # or all changes get lost!!!
		
		repeatCount = len(self.opt_pattern)
		for repeatIdx in range(0, repeatCount):
			repeatVal = True
			if self.opt_pattern[repeatIdx] in "-0?":
				print("- step", repeatIdx+1,"- deselect")
				repeatVal = False
			else:
				print("- step", repeatIdx+1,"- select")
			edgesNext = []
			for i,strand_vids in enumerate(strands_vidx):
				#print("- strand_vids", strand_vids)
				edgesByAng = []
				vert2check = ( (strand_vids[0], strand_vids[1], strand_vids[0]), (strand_vids[-1], strand_vids[-1], strand_vids[-2]))
				for j, vIdxSeqSS in enumerate(vert2check):
					vIdx = vIdxSeqSS[0]
					v = bm.verts[vIdx]
					if self.opt_flowNorml == 'AUTO':
						vIdx1 = vIdxSeqSS[1]
						v1 = bm.verts[vIdx1]
						vIdx2 = vIdxSeqSS[2]
						v2 = bm.verts[vIdx2]
						forward_dir_l = (v2.co-v1.co).normalized()
					for e in v.link_edges:
						if e.other_vert(v).index in vertsIdx:
							continue
						edirdot = (e.other_vert(v).co-v.co).normalized().dot(forward_dir_l)
						edgesByAng.append( (e, edirdot, j) )
						# e.select = True
				edgesByAng.sort(key=lambda ia: ia[1], reverse=True)
				if self.opt_forward:
					en = edgesByAng[0][0]
					#en_con = edgesByAng[0][2]
					edgesNext.append(en)
					# extending proper side of strand for next iterations
					if (en.verts[0].index == strand_vids[0]):
						strand_vids.insert(0, en.verts[1].index)
					elif (en.verts[1].index == strand_vids[0]):
						strand_vids.insert(0, en.verts[0].index)
					elif (en.verts[0].index == strand_vids[-1]):
						strand_vids.append(en.verts[1].index)
					elif (en.verts[1].index == strand_vids[-1]):
						strand_vids.append(en.verts[0].index)
					#print(" -> ", en_con, en.verts[0].index, en.verts[1].index, strand_vids)
				if self.opt_backward:
					en = edgesByAng[-1][0]
					#en_con = edgesByAng[0][2]
					edgesNext.append(en)
					# extending proper side of strand for next iterations
					if (en.verts[0].index == strand_vids[0]):
						strand_vids.insert(0, en.verts[1].index)
					elif (en.verts[1].index == strand_vids[0]):
						strand_vids.insert(0, en.verts[0].index)
					elif (en.verts[0].index == strand_vids[-1]):
						strand_vids.append(en.verts[1].index)
					elif (en.verts[1].index == strand_vids[-1]):
						strand_vids.append(en.verts[0].index)
					#print(" -> ", en_con, en.verts[0].index, en.verts[1].index, strand_vids)
			for e in edgesNext:
				e.select = repeatVal
				if e.verts[0].index not in vertsIdx:
					vertsIdx.append(e.verts[0].index)
				if e.verts[1].index not in vertsIdx:
					vertsIdx.append(e.verts[1].index)
		bmesh.update_edit_mesh(active_mesh)
		wla_do.select_and_change_mode(active_obj, oldmode)
		self.report({'INFO'}, "Done")
		return {'FINISHED'}

class wplverts_sele_dir(bpy.types.Operator):
	bl_idname = "mesh.wplverts_sele_dir"
	bl_label = "Deselect by direction"
	bl_options = {'REGISTER', 'UNDO'}
	
	opt_direction : FloatVectorProperty(
		name	 = "Direction",
		size	 = 3,
		default	 = (0.0,0.0,1.0)
	)
	opt_maxdiff : FloatProperty(
		name	 = "Max angle",
		min = 0, max = 180,
		default	 = 45
	)
	opt_crossdir : BoolProperty(
		name="Check cross-direction",
		default=False,
	)

	def execute( self, context ):
		active_obj = wla.active_object(['MESH'])
		if active_obj is None:
			self.report({'ERROR'}, "Select mesh object first")
			return {'CANCELLED'}
		active_mesh = active_obj.data
		seledgAll = wla.selected_edgesIdx(active_mesh)
		selfaceAll = wla.selected_facesIdx(active_mesh)
		if len(seledgAll)+len(selfaceAll) == 0:
			self.report({'ERROR'}, "No selected edges/faces found")
			return {'FINISHED'}
		#matrix_world = active_obj.matrix_world
		#matrix_world_inv = active_obj.matrix_world.inverted()
		#matrix_world_norm = matrix_world_inv.transposed().to_3x3()
		wla_do.select_and_change_mode(active_obj,"EDIT")
		bm = bmesh.from_edit_mesh( active_mesh )
		bm.edges.ensure_lookup_table()
		bm.edges.index_update()
		bm.faces.ensure_lookup_table()
		bm.faces.index_update()
		maindd_l = Vector((self.opt_direction[0],self.opt_direction[1],self.opt_direction[2])).normalized()
		#maindd_l = matrix_world_norm @ maindd_g
		if len(selfaceAll) > 0 and context.tool_settings.mesh_select_mode[2] == True: # 'FACE' selection
			deselFaces = []
			for fIdx in selfaceAll:
				f = bm.faces[fIdx]
				dir_l = f.normal.normalized()
				difang = math.acos(max(-1.0,min(1.0,abs(dir_l.dot(maindd_l)))))
				if self.opt_crossdir == False and difang < math.radians(self.opt_maxdiff):
					deselFaces.append(fIdx)
				if self.opt_crossdir == True and abs(math.radians(90)-difang) < math.radians(self.opt_maxdiff):
					deselFaces.append(fIdx)
			bpy.ops.mesh.select_all(action = 'DESELECT')
			context.tool_settings.mesh_select_mode = (False, False, True) # 'FACE'
			for fIdx in selfaceAll:
				if fIdx not in deselFaces:
					f = bm.faces[fIdx]
					f.select = True
			self.report({'INFO'}, "Deselected: "+str(len(deselFaces))+" faces")
		else:
			deselEdges = []
			for eIdx in seledgAll:
				e = bm.edges[eIdx]
				dir_l = (e.verts[0].co-e.verts[1].co).normalized()
				difang = math.acos(max(-1.0,min(1.0,abs(dir_l.dot(maindd_l)))))
				if self.opt_crossdir == False and difang < math.radians(self.opt_maxdiff):
					deselEdges.append(eIdx)
				if self.opt_crossdir == True and abs(math.radians(90)-difang) < math.radians(self.opt_maxdiff):
					deselEdges.append(eIdx)
			bpy.ops.mesh.select_all(action = 'DESELECT')
			context.tool_settings.mesh_select_mode = (False, True, False) # 'EDGE'
			for eIdx in seledgAll:
				if eIdx not in deselEdges:
					e = bm.edges[eIdx]
					e.select = True
			self.report({'INFO'}, "Deselected: "+str(len(deselEdges))+" edges")
		bmesh.update_edit_mesh(active_mesh)
		return {'FINISHED'}

# class wplverts_sele_mirr(bpy.types.Operator):
# 	bl_idname = "mesh.wplverts_sele_mirr"
# 	bl_label = "XMirror selection"
# 	bl_options = {'REGISTER', 'UNDO'}

# 	opt_mode : EnumProperty(
# 		items = [
# 			('SELOTHER', "Reselect to symmetrical", "", 1),
# 			('SELBOTH', "Select symmetrical", "", 2),
# 			('SNAPOTHER_U', "Snap symmetrical positions", "", 3)
# 		],
# 		name="Action",
# 		default='SELOTHER',
# 	)
# 	opt_uvPrefx : StringProperty(
# 		name = "UV Name",
# 		default = config.kWPLGridUV
# 	)
# 	opt_checkUSymm : BoolProperty(
# 		name = "Check U-symmetry",
# 		default = True
# 	)
# 	opt_checkVSymm : BoolProperty(
# 		name = "Check V-symmetry",
# 		default = False
# 	)
# 	def execute( self, context ):
# 		active_obj = wla.active_object(['MESH'])
# 		if active_obj is None:
# 			self.report({'ERROR'}, "Select mesh object first")
# 			return {'CANCELLED'}
# 		active_mesh = active_obj.data
# 		selvertsAll = wla.selected_vertsIdx(active_mesh)
# 		wla_do.select_and_change_mode(active_obj, "EDIT")
# 		context.tool_settings.mesh_select_mode = (True, False, False) # 'VERT'
# 		bm = bmesh.from_edit_mesh( active_mesh )
# 		uv_layer_holdr = bm.loops.layers.uv.get(self.opt_uvPrefx)
# 		if uv_layer_holdr is None:
# 			self.report({'ERROR'}, "No baked symmetry found")
# 			return {'CANCELLED'}
# 		bm.verts.ensure_lookup_table()
# 		bm.verts.index_update()
# 		vertKeys = {}
# 		uvKeysSyms = 0
# 		uvKeysNoSyms = 0
# 		uvKeysDupMap = 0
# 		verts2sel = []
# 		for face in bm.faces:
# 			for vert, loop in zip(face.verts, face.loops):
# 				luv = loop[uv_layer_holdr].uv
# 				vU = wla.math_clipFraction(luv[0], config.kWPLUVPrecision)
# 				vV = wla.math_clipFraction(luv[1], config.kWPLUVPrecision)
# 				luv_kk = wla.uvToKey( (vU, vV) )
# 				vertKeys[vert.index] = (vU, vV)
# 				if (luv_kk in vertKeys) and vertKeys[luv_kk] != vert.index:
# 					if len(selvertsAll) == 0:
# 						vert.select = True
# 						print("- XMirror: dupe UV", vert.index, luv_kk, vert.co)
# 					uvKeysDupMap = uvKeysDupMap+1
# 				vertKeys[luv_kk] = vert.index
# 		if uvKeysDupMap > 0:
# 			print("- Warning: map duplications found", uvKeysDupMap)
# 		if len(selvertsAll) == 0:
# 			if uvKeysDupMap>0:
# 				bmesh.update_edit_mesh(active_mesh)
# 				self.report({'ERROR'}, "No selected vertices found (mapdupes: "+str(uvKeysDupMap)+")")
# 			else:
# 				self.report({'ERROR'}, "No selected vertices found (mapdupes: 0)")
# 			return {'FINISHED'}
# 		if self.opt_mode == 'SELOTHER':
# 			bpy.ops.mesh.select_all( action = 'DESELECT' )
# 		# print("vertKeys",vertKeys)
# 		for vIdx in selvertsAll:
# 			if vIdx not in vertKeys:
# 				uvKeysNoSyms = uvKeysNoSyms+1
# 				continue
# 			v = bm.verts[vIdx]
# 			luv = vertKeys[vIdx]
# 			luv_orig = wla.uvToKey(luv)
# 			symverts = []
# 			luv_kk1 = wla.uvToKey( (-1*luv[0], luv[1]) )
# 			luv_kk2 = wla.uvToKey( (luv[0], -1*luv[1]) )
# 			#luv_kk3 = wla.uvToKey( (-1*luv[0], -1*luv[1]) )
# 			if self.opt_checkUSymm and (luv_kk1 in vertKeys): # and (luv_kk1 != luv_orig or self.opt_checkUSymm):
# 				symverts.append((vertKeys[luv_kk1],luv_kk1))
# 			if self.opt_checkVSymm and (luv_kk2 in vertKeys): # and (luv_kk2 != luv_orig or self.opt_checkVSymm):
# 				symverts.append((vertKeys[luv_kk2],luv_kk2))
# 			#if luv_kk3 in vertKeys:
# 			#	symverts.append((vertKeys[luv_kk3],luv_kk3))
# 			uvSymmFound = False
# 			for symvp in symverts:
# 				syvIdx = symvp[0]
# 				if syvIdx != vIdx:
# 					uvKeysSyms = uvKeysSyms+1
# 				symv = bm.verts[syvIdx]
# 				if self.opt_mode == 'SELOTHER' or self.opt_mode == 'SELBOTH':
# 					#symv.select = True
# 					verts2sel.append(symv.index)
# 				else:
# 					symv.co = Vector(( -1*v.co[0], v.co[1], v.co[2]))
# 				uvSymmFound = True
# 				print("- adding symm", symvp[1], "of", luv_orig, syvIdx, vIdx)
# 			if uvSymmFound == False:
# 				# symmetry not found: vert not mapped
# 				uvKeysNoSyms = uvKeysNoSyms+1
# 				if luv_orig in vertKeys:
# 					print("- unmapped: orig ok:",luv_orig,", missing syms:", luv_kk1, luv_kk2, v.co)
# 					print(">>> co:{:.15f}:{:.15f}:{:.15f} uv:{:.15f}:{:.15f}".format(v.co[0], v.co[1], v.co[2], luv[0],luv[1]))
# 					print(">>> symverts", symverts)
# 				else:
# 					print("- unmapped: missing orig:",luv_orig,", syms: ",luv_kk1,luv_kk2, v.co)
# 		bm.normal_update()
# 		if len(verts2sel)>0:
# 			print("- selecting verts:", selvertsAll, verts2sel)
# 			wla_bm.bm_selectVertEdgesFaces(bm, verts2sel, None)
# 		bmesh.update_edit_mesh(active_mesh)
# 		self.report({'INFO'}, "Symverts "+str(uvKeysSyms)+" verts (skipped: "+str(uvKeysNoSyms)+"/all: "+str(len(selvertsAll))+")")
# 		return {'FINISHED'}

class wplverts_loadsel(bpy.types.Operator):
	bl_idname = "mesh.wplverts_loadsel"
	bl_label = "Load selection"
	bl_options = {'REGISTER', 'UNDO'}

	opt_vgname : StringProperty(
		name		= "Group name",
		default	 	= ""
	)
	opt_deselVg : BoolProperty(
		name="Deselect, not select",
		default=False,
	)
	opt_deselCurrent : BoolProperty(
		name="Deselect current",
		default=True,
	)

	def execute( self, context ):
		active_obj = wla.active_object(['MESH'])
		if active_obj is None:
			self.report({'ERROR'}, "Select mesh object first")
			return {'CANCELLED'}
		active_mesh = active_obj.data
		if "DEL:" in self.opt_vgname:
			wla_attr.vg_remove(active_obj, self.opt_vgname.replace("DEL:",""))
			return {'FINISHED'}
		wla_do.select_and_change_mode(active_obj,"EDIT")
		mask_group = wla_attr.vg_get_by_name(active_obj, self.opt_vgname)
		if mask_group is not None:
			#active_obj.vertex_groups.active = mask_group.index
			bpy.ops.object.vertex_group_set_active(group = mask_group.name)
			if self.opt_deselCurrent:
				bpy.ops.mesh.select_all( action = 'DESELECT' )
			if self.opt_deselVg:
				bpy.ops.object.vertex_group_deselect()
			else:
				bpy.ops.object.vertex_group_select()
			self.report({'INFO'}, "Loaded "+self.opt_vgname)
		return {'FINISHED'}

class wplverts_savesel(bpy.types.Operator):
	bl_idname = "mesh.wplverts_savesel"
	bl_label = "Save selection"
	bl_options = {'REGISTER', 'UNDO'}

	def execute( self, context ):
		active_obj = wla.active_object(['MESH'])
		if active_obj is None:
			self.report({'ERROR'}, "Select mesh object first")
			return {'CANCELLED'}
		active_mesh = active_obj.data
		wla_do.select_and_change_mode(active_obj,"OBJECT")
		selvertsAll = wla.selected_vertsIdx(active_mesh)
		if len(selvertsAll) == 0:
			self.report({'ERROR'}, "No selected vertices found")
			return {'FINISHED'}
		nextNumber = 1
		while wla_attr.vg_get_by_name(active_obj, config.kWPLSaveSelVGroup+str(nextNumber)) is not None:
			nextNumber = nextNumber+1
		selVGName = config.kWPLSaveSelVGroup + str(nextNumber)
		mask_group = wla_attr.vg_get_or_new(active_obj, selVGName)
		#config.WPL_G.store[config.kWPLG_LastSelSaveKey] = selVGName
		ok = 0
		for idx in selvertsAll:
			wmod = 'REPLACE'
			try:
				oldval = mask_group.weight(idx)
			except Exception as e:
				oldval = 0
				wmod = 'ADD'
			mask_group.add([idx], 1.0, wmod)
			ok = ok+1
		wla_do.select_and_change_mode(active_obj, 'EDIT')
		active_mesh.update()
		self.report({'INFO'}, selVGName+": "+str(ok)+" verts")
		return {'FINISHED'}

class wplverts_vcopy(bpy.types.Operator):
	bl_idname = "mesh.wplverts_vcopy"
	bl_label = "Copy faces/objs"
	bl_options = {'REGISTER', 'UNDO'}

	opt_mode : EnumProperty(
		items = [
			('COPY', "Copy faces", "", 1),
			('COPY_OBJS', "Copy objects", "", 2),
			('RESET', "RESET Clipboard", "", 3)
		],
		name="Mode",
		default='COPY',
	)

	def execute( self, context):
		if self.opt_mode == 'RESET':
			wla_bm.bm_copyFaces(None, kWPLGKey_FaceCP, None, None, None)
			self.report({'INFO'}, "Clipboard cleared")
			return {'FINISHED'}
		if self.opt_mode == 'COPY_OBJS':
			selobjnames_all = wla.selected_objects(None, True)
			config.WPL_G.store[kWPLGKey_ObjSelCP] = selobjnames_all
			print("- Selection:", selobjnames_all)
			self.report({'INFO'}, "Selection saved: "+str(len(selobjnames_all))+" objs")
			return {'FINISHED'}
		active_obj = wla.active_object(['MESH'])
		if active_obj is None:
			self.report({'ERROR'}, "Select mesh object first")
			return {'CANCELLED'}
		active_mesh = active_obj.data
		oldmode = wla_do.select_and_change_mode(active_obj,"OBJECT")
		selvertsAll = wla.selected_vertsIdx(active_mesh)
		if len(selvertsAll) == 0:
			self.report({'ERROR'}, "No selected verts/faces found")
			return {'FINISHED'}
		# appendMode = False
		# if self.opt_mode == 'ADD':
		# 	appendMode = True
		facesOk, _ = wla_bm.bm_copyFaces(active_obj, kWPLGKey_FaceCP, selvertsAll, None, None)
		wla_do.select_and_change_mode(active_obj, oldmode)
		active_mesh.update()
		self.report({'INFO'}, "Done, "+str(facesOk)+" faces")
		return {'FINISHED'}

class wplverts_vpaste(bpy.types.Operator):
	bl_idname = "mesh.wplverts_vpaste"
	bl_label = "Paste faces"
	bl_options = {'REGISTER', 'UNDO'}

	opt_postAlign : EnumProperty(
		items = [
			('NONE', "Paste as is", "", 1),
			('CURSOR', "Paste to cursor", "", 2),
			('SELMASS', "vgsCP-Paste", "", 3),
			#('EDGELINE', "Edgeline", "", 4),
			('SELSW', "vgsSW-Paste", "", 4), # #vgs: sw()
			('MOVE_OBJSINSIDE', "Relink objects inside target", "", 5),
			('MOVE_OBJSASIDE', "Relink objects aside target", "", 6),
			('MOVE_OBJS2CURS', "Relink objects inside && to cursor", "", 7),
		],
		name="Post align",
		default='NONE',
	)
	opt_postOffset : FloatVectorProperty(
		name		= "Post Offset",
		size = 3,
		default	 = (0.0,0.0,0.0),
	)
	opt_postRotate : FloatVectorProperty(
		name		= "Post Rotate",
		size = 3,
		step = 10,
		default	 = (0.0,0.0,0.0),
	)
	opt_postScale : FloatVectorProperty(
		name		= "Scale (X/Y/Z/All)",
		size = 4,
		step = 0.2,
		default	 = (1.0,1.0,1.0,1.0),
	)

	def execute( self, context ):
		if self.opt_postAlign in ['MOVE_OBJSINSIDE', 'MOVE_OBJSASIDE', 'MOVE_OBJS2CURS']:
			if kWPLGKey_ObjSelCP not in config.WPL_G.store:
				self.report({'ERROR'}, "Nothing copied")
				return {'CANCELLED'}
			selobjnames_all = config.WPL_G.store[kWPLGKey_ObjSelCP]
			active_obj = wla.active_object(['MESH', 'CURVE', 'EMPTY', 'ARMATURE'])
			if active_obj is None:
				self.report({'ERROR'}, "Select root to move object inside")
				return {'CANCELLED'}
			objs2move_dat = []
			objs2move_all = []
			objs2move_root = []
			for obj_name in selobjnames_all:
				obj = wla.object_by_name(obj_name)
				if obj is None or obj.name == active_obj.name:
					print("- skipping", obj_name,"- object not found")
					continue
				if obj in objs2move_all:
					continue
				objs2move_all.append(obj)
				objs2move_dat.append( [obj, len(wla.object_parent_chain(obj)), copy.copy(obj.matrix_world)] )
				# adding ALL CHILDS, even hidden/non selectable
				# IMPORTANT for chars: may have disabled faces, rigs, etc
				childs = wla.all_childs_recursive(obj)
				for ch_obj in childs:
					if ch_obj in objs2move_all:
						continue
					objs2move_dat.append( [ch_obj, len(wla.object_parent_chain(ch_obj)), copy.copy(obj.matrix_world)] )
					objs2move_all.append(ch_obj)
			# print("- objs2move_all", objs2move_all)
			for obj in objs2move_all:
				if (obj.parent is None) or (obj.parent not in objs2move_all):
					if obj.name not in objs2move_root:
						objs2move_root.append(obj.name)
			isInside = True #if active_obj.type != 'EMPTY':
			if self.opt_postAlign == 'MOVE_OBJSASIDE':
				isInside = False
			print("- roots to relink", objs2move_root, "all objects:", len(objs2move_all), "Inside:", isInside)
			objs2move_dat.sort(key=lambda ia: ia[1], reverse=False)
			for obj_dat in objs2move_dat:
				obj = obj_dat[0]
				obj_wm = obj_dat[2]
				if (obj.parent is not None) and (obj.parent in objs2move_all):
					# should relink to already relinked
					wla_do.link_object_to_samecolls(obj, active_obj)
					continue
				print("- reparenting", obj.name, "to", active_obj.name)
				wla_do.link_object_to_scene(obj, active_obj, 2)
				if isInside == False:
					# placing side-by-side and using same location/scale/rotation
					obj.parent = active_obj.parent
					# position, etc
					obj.matrix_world = active_obj.matrix_world
				else:
					# placing inside (link_object_to_scene parenting inside) and keeping original matrix
					obj.matrix_world = obj_wm
				# if obj.type == 'MESH' and abs(obj.scale[0]-1.0) + abs(obj.scale[1]-1.0) + abs(obj.scale[1]-1.0) > 0.001:
				# 	if obj.data.users < 2:
				# 		# applying scale
				# 		print("- resetting scale", obj.scale)
				# 		wla_do.select_and_change_mode(obj,"OBJECT")
				# 		bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
			if self.opt_postAlign == 'MOVE_OBJS2CURS':
				curpos = wla.active_context_cursor()
				print("- moving to cursor", curpos, objs2move_root)
				for obj_name in objs2move_root:
					obj = wla.object_by_name(obj_name)
					if len(obj.constraints) > 0:
						print("// WARNING: constraints on object:", obj.name,"snapping may be overwritten")
					wla_do.select_and_change_mode(obj,"OBJECT")
					obj.matrix_world = wla.math_matrixReplace(obj.matrix_world, curpos, None, None)
					#bpy.ops.view3d.snap_selected_to_cursor(use_offset=False)
			wla_do.select_and_activate_multi(objs2move_all, None)
			self.report({'INFO'}, "Selection relinked: "+str(len(objs2move_all))+" objs -> "+active_obj.name)
			return {'FINISHED'}
		if kWPLGKey_FaceCP not in config.WPL_G.store:
			self.report({'ERROR'}, "Nothing copied")
			return {'CANCELLED'}
		# if (self.opt_postAlign == 'EDGELINE') and (config.kWPLGKey_EdgePinStrands not in config.WPL_G.store):
		# 	self.report({'ERROR'}, "No edgelines stored")
		# 	return {'CANCELLED'}
		need_to_reset_origin = False
		active_obj = wla.active_object(['MESH'])
		if active_obj is None:
			pinDat = config.WPL_G.store[kWPLGKey_FaceCP]
			# creating empty mesh side-by-side with original
			# if selected an empty - then in empty
			hullObj = None
			active_empty = wla.active_object(['EMPTY'])
			if active_empty is not None:
				if "src_name" in pinDat:
					new_name = pinDat["src_name"] + "_tmp" + config.kWPLObjProtoToken[0]
				else:
					new_name = active_empty.name + "_tmp" + config.kWPLObjProtoToken[0]
				hullm = bpy.data.meshes.new(name = new_name + "mesh")
				hullObj = bpy.data.objects.new(name = new_name, object_data=hullm)
				if len(active_empty.children)>0:
					wla_do.link_object_sideBySide(hullObj, active_empty.children[0])
				else:
					wla_do.link_object_sideBySide(hullObj, active_empty)
			# else:
			# 	src_obj = None
			# 	if "src_name" in pinDat and wla.object_by_name(pinDat["src_name"]) is not None:
			# 		src_obj = wla.object_by_name(pinDat["src_name"])
			# 	new_name = None
			# 	if src_obj is None:
			# 		src_obj = wla.object_by_name(config.kWPLSystemMainCam)
			# 		new_name = "tmp" + config.kWPLObjProtoToken[0]
			# 	else:
			# 		new_name = src_obj.name + config.kWPLObjProtoToken[0]
			# 	hullm = bpy.data.meshes.new(name = new_name + "mesh")
			# 	hullObj = bpy.data.objects.new(name = new_name, object_data=hullm)
			# 	wla_do.link_object_sideBySide(hullObj, src_obj)
			if hullObj is not None:
				need_to_reset_origin = True
				print("- created empty object", new_name)
				active_obj = hullObj
		if active_obj is None:
			self.report({'ERROR'}, "Select Target: MESH or EMPTY")
			return {'CANCELLED'}
		active_mesh = active_obj.data
		matrix_world = active_obj.matrix_world
		matrix_world_inv = active_obj.matrix_world.inverted()
		matrix_world_norm = matrix_world_inv.transposed().to_3x3()
		oldmode = wla_do.select_and_change_mode(active_obj,"OBJECT")
		selvertsIdx = wla.selected_vertsIdx(active_mesh)
		wla_do.select_and_change_mode(active_obj,"EDIT")
		# bm = bmesh.from_edit_mesh(active_mesh)
		# bm.verts.ensure_lookup_table()
		# bm.verts.index_update()
		# histVertsIdx = wla_bm.bm_historyVertsIdx(bm)
		bpy.ops.mesh.select_all(action = 'DESELECT')
		context.tool_settings.mesh_select_mode = (True, False, False) # 'VERT'
		targetScale = [self.opt_postScale[0]*self.opt_postScale[3], self.opt_postScale[1]*self.opt_postScale[3], self.opt_postScale[2]*self.opt_postScale[3]]
		targetCenter_g = None
		targetOrient_g = None
		addedFaces = []
		# if self.opt_postAlign == 'EDGELINE':
		# 	pinDat = config.WPL_G.store[kWPLGKey_FaceCP]
		# 	(_, strands_dfrm) = config.WPL_G.store[config.kWPLGKey_EdgePinStrands]
		# 	orig_matrix = Matrix(pinDat["src_matrix"])
		# 	# we need paste in LOCAL space... copy always in global here
		# 	addedFaces = wla_bm.bm_pasteFaces(active_obj, kWPLGKey_FaceCP, orig_matrix.inverted(), None, None, None, None, None)
		# 	bm = bmesh.from_edit_mesh(active_mesh)
		# 	bm.verts.ensure_lookup_table()
		# 	bm.verts.index_update()
		# 	# getting bounding box of source mesh
		# 	addedXMin = 999
		# 	addedXMax = -999
		# 	addedYMin = 999
		# 	addedZMin = 999
		# 	addedVerts = []
		# 	addedSeamVerts = []
		# 	for f in bm.faces:
		# 		if f.index not in addedFaces:
		# 			continue
		# 		for fv in f.verts:
		# 			if fv not in addedVerts:
		# 				addedVerts.append(fv)
		# 				# converting into local space of active_obj
		# 				fv.co = matrix_world @ fv.co
		# 		for fe in f.edges:
		# 			if fe.seam:
		# 				for fev in fe.verts:
		# 					if fev not in addedSeamVerts:
		# 						addedSeamVerts.append(fev)
		# 						addedXMin = min(addedXMin,fev.co[0])
		# 						addedYMin = min(addedYMin,fev.co[1])
		# 						addedZMin = min(addedZMin,fev.co[2])
		# 						addedXMax = max(addedXMax,fev.co[0])
		# 	if len(addedSeamVerts) == 0:
		# 		# calcing from all verts
		# 		for fev in addedVerts:
		# 			addedXMin = min(addedXMin,fev.co[0])
		# 			addedYMin = min(addedYMin,fev.co[1])
		# 			addedZMin = min(addedZMin,fev.co[2])
		# 			addedXMax = max(addedXMax,fev.co[0])
		# 	# bbox calculated
		# 	strand = strands_dfrm[-1]
		# 	curve_cache = {}
		# 	curve_len = 0.0
		# 	print("- pasted. verts", len(addedVerts), "faces", len(addedFaces))
		# 	#print("- BBox", addedXMin, addedYMin, addedZMin, addedXMax)
		# 	# DBG bmesh.update_edit_mesh(active_mesh)
		# 	# DBG return {'FINISHED'}
		# 	# pushing strand for interpolation
		# 	for i, curve_pp in enumerate(strand):
		# 		#print("- curvePt", i, curve_pp)
		# 		vl_co = matrix_world_inv @ curve_pp[0]
		# 		vRDir = ((matrix_world_inv @ curve_pp[1]) - (matrix_world_inv @ curve_pp[0])).normalized()
		# 		vLDir = ((matrix_world_inv @ curve_pp[2]) - (matrix_world_inv @ curve_pp[0])).normalized()
		# 		vUpDir = ((matrix_world_inv @ curve_pp[3]) - (matrix_world_inv @ curve_pp[0])).normalized()
		# 		#vRDir = vLDir.cross(vUpDir)
		# 		curve_len = wla.math_lerpCurveAdd(vl_co, [vl_co, vLDir, vRDir, vUpDir], curve_cache)
		# 	if curve_len > 0.0:
		# 		for v in addedVerts:
		# 			v_relpos = (v.co[0]-addedXMin)/(addedXMax-addedXMin)
		# 			if targetScale[0] < 0:
		# 				v_relpos = 1.0 - v_relpos
		# 			trg_co = wla.math_lerpCurveGet(v_relpos, 0, curve_cache)
		# 			targetNormalX_g = wla.math_lerpCurveGet(v_relpos, 1, curve_cache).normalized()
		# 			targetNormalY_g = wla.math_lerpCurveGet(v_relpos, 2, curve_cache).normalized()
		# 			targetNormalZ_g = wla.math_lerpCurveGet(v_relpos, 3, curve_cache).normalized()
		# 			targetOrient_g = wla.math_matrix4axis(None, targetNormalX_g, targetNormalY_g, targetNormalZ_g)
		# 			if targetOrient_g is None:
		# 				print("- failed to get target orientation", v_relpos, targetNormalX_g, targetNormalY_g, targetNormalZ_g)
		# 				continue
		# 			v_ll = Vector( ( 0, (v.co[1]-addedYMin), (v.co[2]-addedZMin) ) )
		# 			rot_eu = mathutils.Euler((math.radians(self.opt_postRotate[0]),math.radians(self.opt_postRotate[1]),math.radians(self.opt_postRotate[2])), 'XYZ')
		# 			rot_mat = rot_eu.to_quaternion().to_matrix().to_4x4()
		# 			v_ll = rot_mat @ v_ll
		# 			v_ll = Vector( ( self.opt_postOffset[0] + v_ll[0], self.opt_postOffset[1] + v_ll[1] * targetScale[1], self.opt_postOffset[2] + v_ll[2] * targetScale[2] ) )
		# 			v.co = trg_co + (targetOrient_g @ v_ll)
		# 		bm.normal_update()
		# 	bmesh.update_edit_mesh(active_mesh)
		if self.opt_postAlign == 'CURSOR' and wla.active_context_cursor() is not None:
			targetCenter_g =  wla.active_context_cursor()
			if wla.active_context_orient() is not None:
				orientation = wla.active_context_orient().matrix
				targetOrient_g = orientation.to_quaternion().to_matrix().to_4x4()
			addedFaces = wla_bm.bm_pasteFaces(active_obj, kWPLGKey_FaceCP, None, targetCenter_g, self.opt_postOffset, self.opt_postRotate, targetScale, targetOrient_g)
		if self.opt_postAlign == 'NONE':
			addedFaces = wla_bm.bm_pasteFaces(active_obj, kWPLGKey_FaceCP, None, targetCenter_g, self.opt_postOffset, self.opt_postRotate, targetScale, targetOrient_g)
		if self.opt_postAlign == 'SELMASS':
			if len(selvertsIdx) == 0:
				self.report({'ERROR'}, "No targets")
				return {'CANCELLED'}
			bm = bmesh.from_edit_mesh(active_mesh)
			bm.verts.ensure_lookup_table()
			bm.verts.index_update()
			pasteOpts = []
			for vIdx in selvertsIdx:
				vertL = bm.verts[vIdx]
				vertR = wla_bm.bm_vertSecondAxisVert(vertL, None, True)
				targetTangent_l = Vector((0,0,1))
				targetNormal_l = vertL.normal
				if wla_bm.bm_vertIsNecklace(vertL):
					# necklace-face: ring or "base-axis"
					neck_f = vertL.link_faces[0]
					targetNormal_l = neck_f.normal
				else:
					targetNormal_l = Vector((0,0,0))
					vfCnt = 0.0
					for vf in vertL.link_faces:
						targetNormal_l = targetNormal_l + vf.normal
						vfCnt = vfCnt+1.0
					if vfCnt > 0:
						targetNormal_l = (targetNormal_l/vfCnt).normalized()
					else:
						targetNormal_l = Vector((0,1,0))
				if vertR is not None:
					targetTangent_l = (vertR.co - vertL.co).normalized()
					# if targetTangent_l.dot(targetNormal_l) > 0.9:
					# 	# possible on very sharp edges...
					# 	targetNormal_l = vertR.normal
					# 	#print("- tangLine", targetTangent_l.dot(targetNormal_l))
				# targetNormal1_g = (matrix_world_norm @ targetNormal_l).normalized()
				# targetNormal2_g = (matrix_world_norm @ targetTangent_l).normalized()
				# targetNormal3_g = targetNormal2_g.cross(targetNormal1_g).normalized()
				# targetNormal2_g = targetNormal1_g.cross(targetNormal3_g).normalized()
				targetBiTangent_l = targetNormal_l.cross(targetTangent_l)
				targetNormal_l = -1.0*targetNormal_l # facing to default camera
				targetNormalZ_g = (matrix_world_norm @ targetNormal_l).normalized()
				targetNormalY_g = (matrix_world_norm @ targetTangent_l).normalized()
				targetNormalX_g = (matrix_world_norm @ targetBiTangent_l).normalized()
				# need localxz, localxy -> localxz, y swap z
				tmp = targetNormalY_g
				targetNormalY_g = targetNormalZ_g
				targetNormalZ_g = tmp
				# getting vertex-local orientation
				targetOrient_g = wla.math_matrix4axis(None, targetNormalX_g, targetNormalY_g, targetNormalZ_g)
				targetCenter_g = matrix_world @ vertL.co
				#targetTransformPrep = Matrix.Identity(4)
				#targetTransformPrep = Matrix.Rotation( math.radians(-90), 4, 'X') @ targetTransformPrep
				pasteOpts.append( (targetCenter_g, targetOrient_g, None) )
			for i, pasteItem in enumerate(pasteOpts):
				print("- pasting", i+1, "of", len(pasteOpts), "...")
				addedFacesIter = wla_bm.bm_pasteFaces(active_obj, kWPLGKey_FaceCP, pasteItem[2], pasteItem[0], self.opt_postOffset, self.opt_postRotate, targetScale, pasteItem[1])
				if addedFacesIter is None:
					addedFaces = None
					break
				addedFaces.extend(addedFacesIter)
		if self.opt_postAlign == 'SELSW':
			if len(selvertsIdx) == 0:
				self.report({'ERROR'}, "No selected vertline")
				return {'CANCELLED'}
			# if len(histVertsIdx) == 0:
			# 	self.report({'ERROR'}, "No active vert found")
			# 	return {'CANCELLED'}
			#zero_vIdx = histVertsIdx[0]
			bm = bmesh.from_edit_mesh(active_mesh)
			bm.verts.ensure_lookup_table()
			bm.verts.index_update()
			tempUV, _, zero_vIdx = wla_vgbind.gm_generateUVGrid(bm, selvertsIdx, {"steps": 5})
			if (tempUV is None) or (zero_vIdx is None):
				self.report({'ERROR'}, "Grid error")
				return {'CANCELLED'}
			zero_v = bm.verts[zero_vIdx]
			zero_vCo = Vector(zero_v.co)
			zero_vNo = Vector(zero_v.normal)
			zero_vTang = None
			zero_v2 = wla_bm.bm_vertSecondAxisVert(zero_v, selvertsIdx, False )
			if zero_v2 is not None:
				zero_vTang = (zero_v2.co - zero_vCo).normalized()
			addedFaces = wla_bm.bm_pasteFaces(active_obj, kWPLGKey_FaceCP, None, active_obj.matrix_world @ Vector((0,0,0))) # pasting into local (0,0,0)
			addedVerts = wla_meshwrap.objectm_vertsOfPolygons(active_obj, addedFaces)
			wla_do.select_and_change_mode(active_obj,"EDIT")
			bm = bmesh.from_edit_mesh(active_mesh) # again, paste switches to OBJECT....
			bm.verts.ensure_lookup_table()
			bm.verts.index_update()
			bm.faces.ensure_lookup_table()
			bm.faces.index_update()
			cage_base_co_g = {}
			cage_base_nrm_g = {}
			cage_now_co_g = {}
			cage_now_nrm_g = {}
			bind_base_co_g = {}
			for tvIdx in tempUV:
				vIdx_co = tempUV[tvIdx][0]
				vIdx_nrm = tempUV[tvIdx][1]
				vIdx_uv = tempUV[tvIdx][2]
				# (dstU, dstV) -> Z==Along the line
				# (dstV, dstU) -> X==Along the line
				vIdx_uv = (vIdx_uv[0]/targetScale[0] - self.opt_postOffset[0], vIdx_uv[1]/targetScale[1] - self.opt_postOffset[1])
				# vB = bm.verts[vIdx]
				# vIdx_uv = tempUV[vIdx]
				# vIdx_co = vB.co
				# vIdx_nrm = vB.normal
				cage_base_co_g[tvIdx] = Vector( (vIdx_uv[0], 0.0, vIdx_uv[1]) )
				cage_base_nrm_g[tvIdx] = Vector(( 0.0, -1.0, 0.0 ))
				cage_now_co_g[tvIdx] = copy.copy(vIdx_co)
				cage_now_nrm_g[tvIdx] = copy.copy(vIdx_nrm)
				#vB.co = Vector( (vIdx_uv[0], 0.0, vIdx_uv[1]) ) #DBG
			for amv in addedVerts:
				vIdx = amv.index
				vP = bm.verts[vIdx]
				vIdx_co = vP.co 
				vIdx_co = Vector( (vIdx_co[0], (vIdx_co[1] - self.opt_postOffset[2])*targetScale[2], vIdx_co[2]) )
				bind_base_co_g[vIdx] = vIdx_co
			bind_now_co_g_final, _ = wla_vgbind.math_remapSurface(cage_base_co_g, cage_base_nrm_g, cage_now_co_g, cage_now_nrm_g, bind_base_co_g, None)
			for amv in addedVerts:
				vIdx = amv.index
				vP = bm.verts[vIdx]
				if vIdx in bind_now_co_g_final:
					vco_new = bind_now_co_g_final[vIdx]
					if zero_vTang is not None and abs(self.opt_postRotate[0])+abs(self.opt_postRotate[1])+abs(self.opt_postRotate[2])>0.01:
						vco_diff = vco_new - zero_vCo
						vco_diff.rotate( mathutils.Quaternion( zero_vTang, math.radians(self.opt_postRotate[0])))
						vco_diff.rotate( mathutils.Quaternion( zero_vNo.cross(zero_vTang), math.radians(self.opt_postRotate[1])))
						vco_diff.rotate( mathutils.Quaternion( zero_vNo, math.radians(self.opt_postRotate[2])))
						vco_new = zero_vCo + vco_diff
					vP.co = vco_new
		if need_to_reset_origin:
			# wla_do.sys_update_mesh(hullObj)
			wla_do.select_and_change_mode(hullObj, 'OBJECT' )
			bpy.ops.object.origin_set(type='ORIGIN_GEOMETRY', center='MEDIAN')
		wla_do.select_and_change_mode(active_obj, oldmode)
		active_mesh.update()
		if addedFaces is None:
			self.report({'ERROR'}, "Failed to paste FACES")
			return {'CANCELLED'}
		if len(addedFaces) == 0:
			self.report({'ERROR'}, "Failed to paste faces")
		else:
			self.report({'INFO'}, "Done, "+str(len(addedFaces))+" faces to "+active_obj.name)
		return {'FINISHED'}


class wplverts_getori_bone(bpy.types.Operator):
	bl_idname = "mesh.wplverts_getori_bone"
	bl_label = "Grab orientation from bone"
	bl_options = {'REGISTER', 'UNDO'}

	opt_bones2useIni : StringProperty(
		name="Bones",
		default = ""
	)
	opt_pivot2cursor : BoolProperty(
		name="Change pivot to cursor",
		default=True,
	)

	def execute(self, context):
		# special case - EDIT armature -> orientation of bone in POSE mode
		if bpy.context.mode == 'EDIT_ARMATURE':
			active_obj = wla.active_object(["ARMATURE"])
			wla_do.select_and_change_mode(active_obj,'POSE')
			wla_do.create_temp_orientation()
			orientation = wla.active_context_orient(config.kWPLTempOrien)
			bpy.context.space_data.show_gizmo_object_translate = True
			bpy.context.scene.tool_settings.transform_pivot_point = 'ACTIVE_ELEMENT'
			config.WPL_G.store["wplverts_getori"] = "BONE"
			wla_do.select_and_change_mode(active_obj,'EDIT')
			return {'FINISHED'}
		active_obj = wla.active_object(["MESH"])
		armatr = wla_arma.related_arma(active_obj)
		if armatr is None:
			self.report({'ERROR'}, "Need related Armature")
			return {'CANCELLED'}
		opt_bones2use = self.opt_bones2useIni
		if len(opt_bones2use) == 0:
			opt_bones2use = wla_arma.select_by_arma(active_obj, kWPLArmAlignBns_MB, kWPLArmAlignBns_MLOW, "")
		active_mesh = active_obj.data
		matrix_world_inv = active_obj.matrix_world.inverted()
		matrix_world_nrml = matrix_world_inv.transposed().to_3x3()
		selvertsAll = wla.selected_vertsIdx(active_mesh)
		wla_do.select_and_change_mode(active_obj,"EDIT")
		context.tool_settings.mesh_select_mode = (True, False, False)
		bm = bmesh.from_edit_mesh( active_mesh )
		bm.verts.ensure_lookup_table()
		bm.verts.index_update()
		bm.edges.ensure_lookup_table()
		bm.edges.index_update()
		active_v = None
		histVertsIdx = wla_bm.bm_historyVertsIdx(bm)
		if active_v is None and len(histVertsIdx) > 0:
			active_v = bm.verts[histVertsIdx[0]]
		if active_v is None and len(selvertsAll) > 0:
			active_v = bm.verts[selvertsAll[0]]
		if active_v is None:
			self.report({'ERROR'}, "No active vert found")
			return {'CANCELLED'}
		#bpy.ops.view3d.snap_cursor_to_active()
		if "wplverts_getori" not in config.WPL_G.store:
			config.WPL_G.store["wplverts_getori"] = ""
		cur_co = None
		cur_no = None
		cur_tan = None
		# looking for bone with highest weight from allowed
		bn_wcaches = {}
		bnpref = wla.strToTokens(opt_bones2use)
		refbone_maxw = 0.0
		refbone_maxn = None
		refbone_remap = {}
		for pref_item in bnpref:
			pref = pref_item
			pref2 = "*"
			if "+" in pref:
				pref_item_sl = pref_item.split("+")
				pref = pref_item_sl[0]
				pref2 = pref_item_sl[1]
				refbone_remap[pref2] = pref
			for vg in active_obj.vertex_groups:
				if (pref in vg.name.lower()) or (pref2 in vg.name.lower()):
					_, _, allVgVertsW = wla_attr.vg_get_verts(active_obj, vg, 0.01, bn_wcaches)
					if active_v.index in allVgVertsW:
						v_w = allVgVertsW[active_v.index]
						if v_w > refbone_maxw:
							print("- relbone", vg.name, v_w)
							refbone_maxw = v_w
							refbone_maxn = vg.name
		if refbone_maxn is not None:
			# getting bone line, projecting vertex
			if refbone_maxn in refbone_remap:
				refbone_maxn = refbone_remap[refbone_maxn]
			print("- final:", refbone_maxn)
			# special case @as116: SYMMETRY different between armature and object
			# left bones - to RIGHT armature bones and ViseVersa
			needReverBnName = False
			if (armatr.scale[0]*active_obj.scale[0] < 0):
				needReverBnName = True
			elif (active_obj.parent is not None) and (armatr.scale[0]*active_obj.parent.scale[0] < 0):
				needReverBnName = True
			if needReverBnName:
				if ".L" in refbone_maxn:
					refbone_maxn = refbone_maxn.replace(".L", ".R")
					print("// reversing due scaleIncompats:", refbone_maxn)
				elif ".R" in refbone_maxn:
					refbone_maxn = refbone_maxn.replace(".R", ".L")
					print("// reversing due scaleIncompats:", refbone_maxn)
			pbone = armatr.pose.bones[refbone_maxn]
			pblocs = wla_arma.posebone_localpos(pbone, armatr)
			phead = matrix_world_inv @ (armatr.matrix_world @ pblocs[0])
			ptail = matrix_world_inv @ (armatr.matrix_world @ pblocs[1])
			intrRes = mathutils.geometry.intersect_point_line(active_v.co, phead, ptail)
			proj_co = intrRes[0]
			if (refbone_maxn+">") in opt_bones2use:
				# bone tail
				print(" -> bone tail")
				proj_co = ptail
			if (refbone_maxn+"<") in opt_bones2use:
				# bone tail
				print(" -> bone head")
				proj_co = phead
			cur_co = active_obj.matrix_world @ proj_co
			cur_no = (matrix_world_nrml @ (active_v.co-proj_co)).normalized()
			cur_tan = (matrix_world_nrml @ (ptail-phead)).normalized()
			# print(" -> ", active_v.co, (active_v.co-proj_co), (ptail-phead), cur_no.dot(cur_tan))
			if cur_no.dot(cur_tan) > 0.99:
				cur_no = (matrix_world_nrml @ active_v.normal).normalized()
			if cur_no.dot(cur_tan) > 0.99:
				print(" - WARNING: default tangent")
				cur_tan = cur_no.cross(Vector((0,1,0)))
		if cur_no is not None and cur_co is not None:
			wla_do.select_and_change_mode(active_obj,"EDIT")
			bpy.context.scene.cursor.location = cur_co
			wla_do.create_temp_orientation()
			orientation = wla.active_context_orient(config.kWPLTempOrien)
			# rotation matrix from 2 vectors
			aRot = Matrix.Identity(3)
			aRot[0] = cur_tan.normalized() # x
			aRot[1] = cur_no.normalized().cross(cur_tan).normalized() # y
			aRot[2] = cur_no.normalized() # z
			aRot = aRot.transposed()
			aRotM = aRot.to_4x4()
			# z = Quaternion()
			# aRot = z.rotation_difference(cur_no.to_track_quat())
			# aRotM = aRot.to_matrix().to_4x4()
			aLocM = mathutils.Matrix.Translation(cur_co)
			combined = aLocM @ aRotM
			orientation.matrix = combined.to_3x3()
		bpy.context.space_data.show_gizmo_object_translate = True
		if self.opt_pivot2cursor:
			bpy.context.scene.tool_settings.transform_pivot_point = 'CURSOR'
		else:
			bpy.context.scene.tool_settings.transform_pivot_point = 'MEDIAN_POINT'
		config.WPL_G.store["wplverts_getori"] = "BONE"
		wla_do.select_and_change_mode(active_obj,"EDIT")
		return {'FINISHED'}


class wplverts_getori(bpy.types.Operator):
	bl_idname = "mesh.wplverts_getori"
	bl_label = "Grab orientation"
	bl_options = {'REGISTER', 'UNDO'}

	opt_mode : EnumProperty(
		items = [
			('ACTIVE', "Active elem", "", 1),
			('ACTIVE_ROT', "Active elem - rotation", "", 2),
			('SELCNT', "Selection center", "", 3),
			('CAMERA',  "Camera", "", 4),
			('UNGRAB', "Ungrab", "", 5)
		],
		name="Orientation mode",
		default='ACTIVE',
	)
	opt_pivot2cursor : BoolProperty(
			name="Change pivot to cursor",
			default=True,
	)

	def execute(self, context):
		if self.opt_mode == 'UNGRAB':
			config.WPL_G.store["wplverts_getori"] = ""
			wla_do.switch_orientation('LOCAL', 'MEDIAN_POINT')
			return {'FINISHED'}
		if self.opt_mode == 'SELCNT':
			bpy.ops.view3d.snap_cursor_to_selected()
		else:
			bpy.ops.view3d.snap_cursor_to_active()
		camera_obj = wla.object_by_name(config.kWPLSystemMainCam)
		#wla_do.ensure_visible(camera_obj, 1)
		if "wplverts_getori" not in config.WPL_G.store:
			config.WPL_G.store["wplverts_getori"] = ""
		cur_co = wla.active_context_cursor()
		cur_co_key = self.opt_mode #coToKey(cur_co)
		if self.opt_mode == 'ACTIVE' or self.opt_mode == 'SELCNT' or self.opt_mode == 'ACTIVE_ROT':
			wla_do.create_temp_orientation()
		if self.opt_mode == 'CAMERA':
			if camera_obj is None:
				self.report({'ERROR'}, "Camera not found: "+config.kWPLSystemMainCam)
				return {'CANCELLED'}
			wla_do.create_temp_orientation()
			orientation = wla.active_context_orient(config.kWPLTempOrien)
			combined = wla.math_matrixReplace(camera_obj.matrix_world, cur_co, None, None)
			orientation.matrix = combined.to_3x3()
		bpy.context.space_data.show_gizmo_object_translate = True
		if self.opt_pivot2cursor:
			bpy.context.scene.tool_settings.transform_pivot_point = 'CURSOR'
		else:
			bpy.context.scene.tool_settings.transform_pivot_point = 'MEDIAN_POINT'
		# setting cursor orientation too - cool for some tools
		orientation = wla.active_context_orient(config.kWPLTempOrien)
		if self.opt_mode == 'ACTIVE_ROT' and wla.is_edit_mode():
			# orientation of active element - but for MESH specifically last in selection
			active_obj = wla.active_object(["MESH"])
			if active_obj is not None:
				matrix_world = active_obj.matrix_world
				matrix_world_inv = matrix_world.inverted()
				matrix_world_norm = matrix_world_inv.transposed().to_3x3()
				wla_do.select_and_change_mode(active_obj,"EDIT")
				context.tool_settings.mesh_select_mode = (True, False, False)
				bm = bmesh.from_edit_mesh( active_obj.data )
				bm.verts.ensure_lookup_table()
				bm.verts.index_update()
				histVerts = wla_bm.bm_historyVertsIdx(bm)
				if len(histVerts) > 0 and camera_obj is not None:
					camPos = camera_obj.matrix_world.to_translation()
					lastV = bm.verts[histVerts[0]]
					camClosestV = lastV.link_edges[0].other_vert(lastV)
					for e in lastV.link_edges:
						v2 = e.other_vert(lastV)
						if ((matrix_world@v2.co) - camPos).length < ((matrix_world@camClosestV.co) - camPos).length:
							camClosestV = v2
					nrm_g = matrix_world_norm @ lastV.normal
					#camera_gDir = camera_obj.matrix_world.to_3x3() @ Vector((0.0, 0.0, 1.0))
					#tan_g = nrm_g.cross(camera_gDir).normalized()
					tan_g = ((matrix_world@lastV.co) - (matrix_world@camClosestV.co)).normalized()
					tan2_g = nrm_g.cross(tan_g).normalized()
					tan_g = nrm_g.cross(tan2_g).normalized()
					nrm_orient = wla.math_matrix4axis(None, tan_g, tan2_g, nrm_g)
					combined = wla.math_matrixReplace(orientation.matrix.to_4x4(), None, nrm_orient.to_4x4(), None)
					orientation.matrix = combined.to_3x3()
		if orientation is not None:
			bpy.context.scene.cursor.rotation_mode = 'XYZ' # 'QUATERNION'
			bpy.context.scene.cursor.rotation_euler = orientation.matrix.to_euler('XYZ')
		config.WPL_G.store["wplverts_getori"] = cur_co_key
		return {'FINISHED'}

# class wplverts_getori_coll(bpy.types.Operator):
# 	bl_idname = "mesh.wplverts_getori_coll"
# 	bl_label = "Grab orientation from colliders"
# 	bl_options = {'REGISTER', 'UNDO'}
# 	opt_pivot2cursor : BoolProperty(
# 		name="Change pivot to cursor",
# 		default=True,
# 	)
# 	opt_pinId: ??? Also to pinned mesh??? <colliders> as option
# 	def execute(self, context):
# 		active_obj = wla.active_object()
# 		oldmode = None
# 		if active_obj is not None:
# 			oldmode = wla_do.select_and_change_mode(active_obj, 'OBJECT')
# 		if "wplverts_getori" not in config.WPL_G.store:
# 			config.WPL_G.store["wplverts_getori"] = ""
# 		bvh2collides = wla_bm.bm_sceneColldersBVH(None, False)
# 		if len(bvh2collides) == 0:
# 			self.report({'ERROR'}, "Colliders not found: Need objects with collision modifier")
# 			return {'CANCELLED'}
# 		#bpy.ops.view3d.snap_cursor_to_active()
# 		cur_co = wla.active_context_cursor()
# 		cur_no = None
# 		start_co = wla_meshwrap.objectm_vertsAvgCo(active_obj, cur_co, True, False)
# 		dist = 999
# 		for bvh_collide in bvh2collides:
# 			location, normal, index, distance = bvh_collide.find_nearest(start_co, 999)
# 			if location is not None and distance < dist:
# 				# moving 3D cursor to position
# 				print("Collider pos", location, normal)
# 				dist = distance
# 				cur_no = normal
# 				cur_co = location
# 		if cur_no is not None:
# 			bpy.context.scene.cursor.location = cur_co
# 			wla_do.create_temp_orientation()
# 			orientation = wla.active_context_orient(config.kWPLTempOrien)
# 			nrm_rot = cur_no.rotation_difference(mathutils.Vector((0,0,1)))
# 			co_pos = Matrix.Translation(cur_co).to_3x3()
# 			co_pos.rotate(nrm_rot.to_matrix())
# 			orientation.matrix = co_pos
# 		bpy.context.space_data.show_gizmo_object_translate = True
# 		if self.opt_pivot2cursor:
# 			bpy.context.scene.tool_settings.transform_pivot_point = 'CURSOR'
# 		else:
# 			bpy.context.scene.tool_settings.transform_pivot_point = 'MEDIAN_POINT'
# 		config.WPL_G.store["wplverts_getori"] = "COLLD"
# 		if active_obj is not None and oldmode is not None:
# 			wla_do.select_and_change_mode(active_obj, oldmode)
# 		return {'FINISHED'}

class wplverts_resetvco(bpy.types.Operator):
	bl_idname = "mesh.wplverts_resetvco"
	bl_label = "Reset co channel"
	bl_options = {'REGISTER', 'UNDO'}

	opt_channelMode : EnumProperty(
		name="Channel mode", default="X",
		items=(("X", "X channel", ""), ("Y", "Y channel", ""), ("Z", "Z channel", ""), 
			("XG", "X global", ""), ("YG", "Y global", ""), ("ZG", "Z global", ""),
			("HETA_XY", "Head-Tail XY", ""), ("HETA_Z", "Head-Tail Z", ""))
	)
	opt_refCo : EnumProperty(
		name="Reference point", default="ACTIVE",
		items=(("ACTIVE", "Active vert", ""), 
			("CENTER", "Center", ""), 
			("CURSOR3D", "3D Cursor", ""), 
			("LOCALZERO", "Zero", ""))
	)
	opt_keepOnEdge : BoolProperty(
		name="Keep on edge",
		default=False,
	)
	opt_influence : FloatProperty(
		name="Influence",
		min=0.0001, max=1.0,
		default=1
	)

	def execute( self, context ):
		active_obj = wla.active_object()
		if active_obj is None:
			self.report({'ERROR'}, "Select objects first")
			return {'FINISHED'}
		# defaults for both EDIT/Object modes
		ao_mw_nrm_g = active_obj.matrix_world.inverted().transposed().to_3x3()
		refCo_g_nrm = Vector((0,0,1))
		if self.opt_channelMode == 'X' or self.opt_channelMode == 'HETA_XY':
			refCo_g_nrm = ao_mw_nrm_g @ Vector((1,0,0))
		if self.opt_channelMode == 'Y':
			refCo_g_nrm = ao_mw_nrm_g @ Vector((0,1,0))
		if self.opt_channelMode == 'Z' or self.opt_channelMode == 'HETA_Z':
			refCo_g_nrm = ao_mw_nrm_g @ Vector((0,0,1))
		if self.opt_channelMode == 'XG':
			refCo_g_nrm = Vector((1,0,0))
		if self.opt_channelMode == 'YG':
			refCo_g_nrm = Vector((0,1,0))
		if self.opt_channelMode == 'ZG':
			refCo_g_nrm = Vector((0,0,1))
		refCo = Vector((0,0,0))
		if wla.is_object_mode():
			# aligning object origins
			print("- aligning objects")
			sel_objs = wla.selected_objects()
			if self.opt_refCo == "ACTIVE":
				refCo = active_obj.matrix_world.to_translation()
			if self.opt_refCo == "CURSOR3D":
				refCo = wla.active_context_cursor()
			if self.opt_refCo == "CENTER":
				for obj in sel_objs:
					refCo = refCo + obj.matrix_world.to_translation()
				refCo = refCo/len(sel_objs)
			refCo_g = refCo # already global
			print("- snap plane", refCo_g, refCo_g_nrm)
			for obj in sel_objs:
				vco_g = obj.matrix_world.to_translation()
				co_g_new, _ = wla.math_vecFaceProj(vco_g, refCo_g, refCo_g_nrm)
				vco_g = vco_g.lerp(co_g_new, self.opt_influence)
				#obj.location = obj.matrix_world.inverted() @ vco_g
				obj.matrix_world = wla.math_matrixReplace(obj.matrix_world, vco_g, None, None)
			return {'FINISHED'}
		if active_obj.type in ['CURVE']:
			active_mesh = wla_meshwrap.object_wrappedmesh(active_obj)
			selvertsAll = active_mesh.selected_vertsIdx()
			if len(selvertsAll) == 0:
				self.report({'ERROR'}, "No selected verts found")
				return {'FINISHED'}
			if self.opt_refCo == "CURSOR3D":
				refCo = active_obj.matrix_world.inverted() @ wla.active_context_cursor()
			else:
				refCo = Vector((0,0,0))
				for vIdx in selvertsAll:
					v_co = active_mesh.vertices[vIdx].co
					refCo = refCo+v_co
				refCo = refCo/len(selvertsAll)
			refCo_g = active_obj.matrix_world @ refCo
			print("- snap plane", refCo_g, refCo_g_nrm)
			for vIdx in selvertsAll:
				v_co = active_mesh.vertices[vIdx].co
				vco_g = active_obj.matrix_world @ v_co
				co_g_new, _ = wla.math_vecFaceProj(vco_g, refCo_g, refCo_g_nrm)
				vco_g = vco_g.lerp(co_g_new, self.opt_influence)
				active_mesh.vertices[vIdx].co = active_obj.matrix_world.inverted() @ vco_g
			active_mesh.to_mesh()
			wla_do.select_and_change_mode(active_obj,"EDIT")
			return {'FINISHED'}
		if active_obj.type != 'MESH':
			self.report({'ERROR'}, "Select mesh object first")
			return {'FINISHED'}
		# changing vertex positions in EDIT mode
		active_mesh = active_obj.data
		selvertsAll = wla.selected_vertsIdx(active_mesh)
		if len(selvertsAll) == 0:
			self.report({'ERROR'}, "No selected verts found")
			return {'FINISHED'}
		wla_do.select_and_change_mode(active_obj,"EDIT")
		oldselmod = list(context.tool_settings.mesh_select_mode)
		context.tool_settings.mesh_select_mode = (True, False, False) # 'VERT'
		bm = bmesh.from_edit_mesh( active_mesh )
		bm.verts.ensure_lookup_table()
		bm.verts.index_update()
		bm.edges.ensure_lookup_table()
		bm.edges.index_update()
		if self.opt_refCo == "ACTIVE":
			histVertsIdx = wla_bm.bm_historyVertsIdx(bm)
			if len(histVertsIdx) > 0:
				vActive = bm.verts[histVertsIdx[0]]
				refCo = vActive.co.copy()
			else:
				self.opt_refCo = "CENTER"
		if self.opt_refCo == "CURSOR3D":
			refCo = active_obj.matrix_world.inverted() @ wla.active_context_cursor()
		if self.opt_refCo == "CENTER":
			refCo = Vector((0,0,0))
			for vIdx in selvertsAll:
				v = bm.verts[vIdx]
				refCo = refCo+v.co
			refCo = refCo/len(selvertsAll)
		refCo_g = active_obj.matrix_world @ refCo
		if (self.opt_channelMode == 'HETA_XY' or self.opt_channelMode == 'HETA_Z') and len(selvertsAll) > 0:
			avgHeadTailNrm = Vector((0,0,0))
			heta_verts = []
			for vIdx in selvertsAll:
				v = bm.verts[vIdx]
				selOthers = 0
				for e in v.link_edges:
					if e.other_vert(v).index in selvertsAll:
						selOthers = selOthers+1
				if selOthers <= 1:
					# head or tail
					avgHeadTailNrm = avgHeadTailNrm+v.normal
					heta_verts.append(v.co)
			if len(heta_verts)>0:
				if len(heta_verts) != 2:
					print("- no clear head-tails, using avg normal")
					avgHeadTailNrm = (avgHeadTailNrm/len(heta_verts)).normalized()
					refCo_g_nrm = ao_mw_nrm_g @ avgHeadTailNrm
				else:
					heta_dir = (heta_verts[0]-heta_verts[1]).normalized()
					if self.opt_channelMode == 'HETA_XY':
						avgHeadTailNrm = (heta_dir.cross(avgHeadTailNrm)).cross(heta_dir)
						refCo_g_nrm = ao_mw_nrm_g @ avgHeadTailNrm
					if self.opt_channelMode == 'HETA_Z':
						avgHeadTailNrm = heta_dir.cross(avgHeadTailNrm)
						refCo_g_nrm = ao_mw_nrm_g @ avgHeadTailNrm
		#print("- snap plane", refCo_g, refCo_g_nrm)
		for vIdx in selvertsAll:
			v = bm.verts[vIdx]
			vco_g = active_obj.matrix_world @ v.co
			vco_g_new, _ = wla.math_vecFaceProj(vco_g, refCo_g, refCo_g_nrm)
			v_co_new = active_obj.matrix_world.inverted() @ vco_g_new
			if self.opt_keepOnEdge:
				# looking for edge in move direction
				eOk = None
				eOkMaxDot = None
				eOkMinDot = None
				for e in v.link_edges:
					e_dir_g = ao_mw_nrm_g @ (e.other_vert(v).co-v.co).normalized()
					e_dir_dot = e_dir_g.dot(refCo_g_nrm)
					#if e_dir_dot > 0.1:
					if eOkMaxDot is None or e_dir_dot > eOkMaxDot:
						eOkMaxDot = e_dir_dot
						eOk = e
				if eOkMaxDot is None:
					# no forward edges - looking backward
					for e in v.link_edges:
						e_dir_g = ao_mw_nrm_g @ (e.other_vert(v).co-v.co).normalized()
						e_dir_dot = e_dir_g.dot(refCo_g_nrm)
						if e_dir_dot < 0.1:
							if eOkMinDot is None or e_dir_dot < eOkMinDot:
								eOkMinDot = e_dir_dot
								eOk = e
				if eOk is not None:
					#v_co_new = v.co+moveDst*e_dir
					e_dir = (eOk.verts[0].co-eOk.verts[1].co).normalized()
					#print("- snapping along edge", eOk, ao_mw_nrm_g @ e_dir)
					pt1_g = active_obj.matrix_world @ (eOk.verts[0].co - e_dir*100)
					pt2_g = active_obj.matrix_world @ (eOk.verts[0].co + e_dir*100)
					ptProj_g = mathutils.geometry.intersect_line_plane(pt1_g, pt2_g, refCo_g, refCo_g_nrm)
					if ptProj_g is not None:
						v_co_new = active_obj.matrix_world.inverted() @ ptProj_g
			v.co = v.co.lerp(v_co_new, self.opt_influence)
		bmesh.update_edit_mesh(active_mesh)
		context.tool_settings.mesh_select_mode = oldselmod
		return {'FINISHED'}
		
class wplverts_weldinto(bpy.types.Operator):
	bl_idname = "mesh.wplverts_weldinto"
	bl_label = "Weld verts into selection"
	bl_options = {'REGISTER', 'UNDO'}

	opt_distanceAbs : FloatProperty(
		name	= "Absolute distance",
		default	= 0.005,
		min		= 0.00001,
		max		= 100
	)
	opt_distanceRel : FloatProperty(
		name	= "Edge-relative distance",
		subtype	= 'PERCENTAGE',
		default	= 0,
		min		= 0.0,
		max		= 100.0
	)
	opt_rmdDistanceRel : FloatProperty(
		name	= "Pre-remove doubles",
		subtype	= 'PERCENTAGE',
		default	= 1,
		min		= 0.0,
		max		= 100.0
	)
	opt_rmdMiddles : BoolProperty(
		name	= "Post-remove middle verts",
		default	= True
	)

	def execute( self, context ):
		active_obj = wla.active_object(['MESH'])
		if active_obj is None:
			self.report({'ERROR'}, "Select mesh object first")
			return {'CANCELLED'}
		active_mesh = active_obj.data
		if abs(self.opt_rmdDistanceRel) > 0.00001:
			selvertsAll = wla.selected_vertsIdx(active_mesh)
			if len(selvertsAll) == 0:
				self.report({'ERROR'}, "No selected verts found")
				return {'CANCELLED'}
			wla_do.select_and_change_mode(active_obj, 'EDIT')
			bm = bmesh.from_edit_mesh( active_mesh )
			bm.verts.ensure_lookup_table()
			bm.verts.index_update()
			edgelenAvg = wla_bm.bm_averageEdgeLen(bm, selvertsAll, 0.0)
			dst = edgelenAvg*(self.opt_rmdDistanceRel/100.0)
			bpy.ops.mesh.remove_doubles(threshold = dst)
		selvertsAll = wla.selected_vertsIdx(active_mesh)
		if len(selvertsAll) == 0:
			self.report({'ERROR'}, "No selected verts found")
			return {'CANCELLED'}
		wla_do.select_and_change_mode(active_obj, 'EDIT')
		bm = bmesh.from_edit_mesh( active_mesh )
		bm.verts.ensure_lookup_table()
		bm.verts.index_update()
		edgelenAvg = wla_bm.bm_averageEdgeLen(bm, selvertsAll, 0.0)
		checkDst = max(self.opt_distanceAbs, edgelenAvg*(self.opt_distanceRel/100.0))
		bmtree = wla_bm.bm_vertsToKdtree(None, bm, selvertsAll)
		weldmap = {}
		welddist = {}
		#dissolv = []
		weldedOk = 0
		for vIdx in selvertsAll:
			v = bm.verts[vIdx]
			nearest_verts = bmtree.find_range(v.co, checkDst)
			for nearest_body_vert_data in nearest_verts:
				near_vert_idx = nearest_body_vert_data[1]
				near_vert_dist = nearest_body_vert_data[2]
				if near_vert_idx not in welddist or near_vert_dist < welddist[near_vert_idx]:
					near_v = bm.verts[near_vert_idx]
					if near_v.hide > 0:
						continue
					weldedOk = weldedOk+1
					welddist[near_vert_idx] = near_vert_dist
					weldmap[near_v] = v
		if len(weldmap)>0:
			bmesh.ops.weld_verts(bm, targetmap = weldmap)
		bmesh.update_edit_mesh(active_mesh)
		if self.opt_rmdMiddles:
			# same as "select same edges"
			selvertsAll = wla.selected_vertsIdx(active_mesh)
			wla_do.select_and_change_mode(active_obj, 'EDIT')
			bm = bmesh.from_edit_mesh( active_mesh )
			bm.verts.ensure_lookup_table()
			bm.verts.index_update()
			verts2dslv = []
			for vIdx in selvertsAll:
				v = bm.verts[vIdx]
				if len(v.link_edges) < 3:
					verts2dslv.append(v)
					weldedOk = weldedOk+1
			bmesh.ops.dissolve_verts(bm, verts = verts2dslv)
			bmesh.update_edit_mesh(active_mesh)
		self.report({'INFO'}, "Verts merged: "+str(weldedOk))
		return {'FINISHED'}

class wplverts_sele_toggleact(bpy.types.Operator):
	bl_idname = "mesh.wplverts_sele_toggleact"
	bl_label = "Toggle edge active point"
	bl_options = {'REGISTER', 'UNDO'}

	opt_mode : EnumProperty(
		name="Action", default="TOGGLE",
		items=(("TOGGLE", "To other side", ""),("TOGGLE_GRAB", "To other && grab", ""))
	)

	def execute( self, context ):
		active_obj = wla.active_object(['MESH'])
		if active_obj is None:
			self.report({'ERROR'}, "Select mesh object first")
			return {'CANCELLED'}
		active_mesh = active_obj.data
		vertsIdx = wla.selected_vertsIdx(active_mesh)
		edgesIdx = wla.selected_edgesIdx(active_mesh)
		opt_flowDir = (0,0,1)
		wla_do.select_and_change_mode(active_obj, 'EDIT')
		bm = bmesh.from_edit_mesh(active_mesh)
		bm.verts.ensure_lookup_table()
		bm.faces.ensure_lookup_table()
		bm.verts.index_update()
		strands_points, strands_vidx = wla_bm.bm_edgesAsStrands_v04(active_obj, bm, vertsIdx, edgesIdx, opt_flowDir, None)
		if strands_points is None:
			self.report({'ERROR'}, "No edges found")
			return {'FINISHED'} # or all changes get lost!!!
		histVertsIdx = wla_bm.bm_historyVertsIdx(bm)
		refVertIdx = -999
		if len(histVertsIdx)>0:
			refVertIdx = histVertsIdx[-1]
		print("- refVertIdx", refVertIdx, strands_vidx[0][0], strands_vidx[0][-1])
		if refVertIdx == strands_vidx[0][0]:
			bm.select_history.clear()
			v2 = bm.verts[strands_vidx[0][-1]]
			bm.select_history.add(v2)
		else:
			bm.select_history.clear()
			v2 = bm.verts[strands_vidx[0][0]]
			bm.select_history.add(v2)
		bmesh.update_edit_mesh(active_mesh)
		if self.opt_mode == 'TOGGLE_GRAB':
			bpy.ops.mesh.wplverts_getori(opt_mode='ACTIVE', opt_pivot2cursor=True)
		return {'FINISHED'}

# ==========================================
# ==========================================
# ==========================================
# ==========================================

class WPL_PT_SculptSPanel1(bpy.types.Panel):
	bl_idname = "WPL_PT_SculptSPanel1"
	bl_label = "Selection tools"
	bl_space_type = 'VIEW_3D'
	bl_region_type = 'UI'
	bl_category = "vSel"

	def draw(self, context):
		layout = self.layout
		active_obj = wla.active_object()
		sel_objs = wla.selected_objects()
		col = layout.column()
		if active_obj is not None:
			box1 = col.box()
			orient_slot = bpy.context.scene.transform_orientation_slots[0]
			if ("wplverts_getori" in config.WPL_G.store and len(config.WPL_G.store["wplverts_getori"]) > 0) or (orient_slot is not None and orient_slot.type != 'LOCAL'):
				box1.operator("mesh.wplverts_getori", text = "UNGRAB orientation").opt_mode='UNGRAB'
			pro4 = box1.row()
			op2 = pro4.operator("mesh.wplverts_getori", text = "GRAB rotation")
			op2.opt_mode = 'ACTIVE_ROT'
			op2.opt_pivot2cursor = False
			pro4 = box1.row()
			op1 = pro4.operator("mesh.wplverts_getori", text = "GRAB 2active", icon = 'PIVOT_ACTIVE')
			op1.opt_mode = 'ACTIVE'
			op1.opt_pivot2cursor = True
			op4 = pro4.operator("mesh.wplverts_getori", text="GRAB 2camera")
			op4.opt_mode = 'CAMERA'
			op4.opt_pivot2cursor = False
			if (active_obj is not None) and active_obj.type in ['MESH']:
				pro4 = box1.row()
				pro4.operator("mesh.wplverts_getori_bone", text="GRAB 2bone", icon = 'BONE_DATA')
				pro4.operator("mesh.wplverts_sele_toggleact", text="GRAB EDGE/tip").opt_mode='TOGGLE_GRAB'
			# box1.operator("mesh.wplverts_getori_coll", text="2collider", icon = 'PIVOT_MEDIAN')
		col.separator()
		box3 = col.box()
		if (active_obj is not None) and active_obj.type in ['MESH', 'CURVE'] and wla.is_edit_mode():
			opr1 = box3.row()
			opr1.label(text="Snap Verts")
			opr1.operator("mesh.wplverts_resetvco", text="X").opt_channelMode = 'X'
			opr1.operator("mesh.wplverts_resetvco", text="Y").opt_channelMode = 'Y'
			opr1.operator("mesh.wplverts_resetvco", text="Z").opt_channelMode = 'Z'
		if (active_obj is not None) and active_obj.type in ['MESH'] and wla.is_edit_mode():
			opr1 = box3.row()
			opr1.operator("mesh.wplverts_weldinto", text='vSel: Weld', icon="AUTOMERGE_ON")
			op = opr1.operator("mesh.wplbind_maskout", text='vSel: Hidegeom', icon = 'MOD_MASK')
			op.opt_extraAction = 'HIDE'
			box3.separator()
			# opr1 = box3.row()
			# opr1.operator("mesh.wplverts_sele_mirr", text = "XMirror: Select", icon = 'MOD_MIRROR').opt_mode = 'SELBOTH'
			# opr1.operator("mesh.wplverts_sele_mirr", text = "XMirror snap", icon = 'MOD_MIRROR').opt_mode = 'SNAPOTHER_U'
			#opr1 = box3.row()
			#opr1.operator("mesh.wplverts_chaindesel", text="Desel short").opt_crossdir = False
			#opr1.operator("mesh.wplverts_chaindesel", text="Desel long").opt_crossdir = True
			opr1 = box3.row()
			op1 = opr1.operator("mesh.wplverts_sele_leftright", text="+Left", icon = 'SELECT_EXTEND')
			op1.opt_left = True
			op1.opt_right = False
			op1 = opr1.operator("mesh.wplverts_sele_leftright", text="+Right")
			op1.opt_left = False
			op1.opt_right = True
			opr1 = box3.row()
			op1 = opr1.operator("mesh.wplverts_sele_forwbacw", text="+Forward", icon = 'SELECT_EXTEND')
			op1.opt_forward = True
			op1.opt_backward = False
			op1 = opr1.operator("mesh.wplverts_sele_forwbacw", text="+Backward")
			op1.opt_forward = False
			op1.opt_backward = True
			
			row1 = box3.row()
			op1 = row1.operator("mesh.wplverts_sele_dir", text="Desel vertical")
			op1.opt_direction = (0,0,1)
			op1.opt_crossdir = False
			op2 = row1.operator("mesh.wplverts_sele_dir", text="Desel horizontal")
			op2.opt_direction = (0,0,1)
			op2.opt_crossdir = True
			box3.operator("mesh.wplverts_sele_fill", icon = 'SELECT_EXTEND')
		else: # if wla.is_object_mode()
			opr1 = box3.row()
			opr1.label(text="Snap Objects")
			opr1.operator("mesh.wplverts_resetvco", text="X").opt_channelMode = 'X'
			opr1.operator("mesh.wplverts_resetvco", text="Y").opt_channelMode = 'Y'
			opr1.operator("mesh.wplverts_resetvco", text="Z").opt_channelMode = 'Z'
		if (active_obj is not None) and active_obj.type in ['MESH', 'GPENCIL']:
			# save/load selection - even in OBJ mode, to see created selections
			col.separator()
			box3 = col.box()
			if active_obj.type == 'MESH':
				selGrps = []
				vgsGrps = []
				for vg in active_obj.vertex_groups:
					if config.kWPLSaveSelVGroup in vg.name:
						selGrps.append(vg.name)
					if wla.isTokenInStr([config.kWPLSuppVGScriptToken, config.kWPLSuppVGScriptCutlin, config.kWPLSuppVGNoMirror], vg.name):
						if ("bind(" in vg.name):# except this one
							continue
						vgsGrps.append(vg.name)
				box3.operator("mesh.wplverts_savesel", icon='GROUP_VERTEX', text="Save selection")
				allGrps = sorted(selGrps) + sorted(vgsGrps)
				for vg_name in allGrps:
					row = box3.row()
					spl1 = row.split(factor = 0.7)
					op1 = spl1.operator("mesh.wplverts_loadsel", text=vg_name)
					op1.opt_deselCurrent = True
					op1.opt_deselVg = False
					op1.opt_vgname = vg_name
					op2 = spl1.operator("mesh.wplverts_loadsel", text="!Sel")
					op2.opt_deselCurrent = False
					op2.opt_deselVg = True
					op2.opt_vgname = vg_name
					op3 = spl1.operator("mesh.wplverts_loadsel", text="Rem")
					op3.opt_vgname = "DEL:"+vg_name
			if active_obj.type in ['GPENCIL']:
				row = box3.row()
				op = row.operator("mesh.wplbind_maskout", text='GP: ZHide', icon = 'MOD_MASK')
				op.opt_extraAction = 'HIDE'
				op = row.operator("mesh.wplbind_maskout", text='GP: ZUnhide')
				op.opt_extraAction = 'UNHIDE'
		# if (active_obj is not None):
		# 	col.separator()
		# 	box1 = col.box()
		# 	if (config.kWPLGKey_EdgePinStrands in config.WPL_G.store):
		# 		box1.operator("mesh.wplsculpt_fastpin_edges_snap", icon="PARTICLE_TIP").opt_mode = 'VSHRINKWR'
		# 		box1.separator()
		# 	ss3 = box1.operator("mesh.wplverts_pinsurfshrw", text="Colliders: Deselect visible (View)", icon="PHYSICS")
		# 	ss3.opt_shrinkwMethod = 'VIEWPROJ_DESELV'
		# 	ss3.opt_castFeats = (0, -0.01, 0) # some step TO camera
		# 	ss3.opt_pinId = "<collider>"
		# 	opr6 = box1.row()
		# 	ss3 = opr6.operator("mesh.wplverts_pinsurfshrw", text="Colliders: Land on", icon="PHYSICS")
		# 	ss3.opt_shrinkwMethod = 'VIEWPROJTO_AVG'
		# 	ss3.opt_castFeats = (-0.1, 0, 0)
		# 	ss3.opt_vertsType = 'ALL'
		# 	ss3.opt_pinId = "<collider>"
		# 	ss3 = opr6.operator("mesh.wplverts_pinsurfshrw", text="Land on PinConv")
		# 	ss3.opt_shrinkwMethod = 'VIEWPROJTO_AVG'
		# 	ss3.opt_castFeats = (-0.1, 0, 0)
		# 	ss3.opt_vertsType = 'ALL'
		# 	ss3.opt_pinId = "<pinconv>"
		# if active_obj is not None and active_obj.type == 'MESH':
		# 	if wla.is_edit_mode() and len(wla_attr.vg_names_by_nameToken(active_obj, "bn_")) > 1:
		# 		col.separator()
		# 		col.label( text='Arma-Selection')
		# 		box2 = col.box()
		# 		row1 = box2.row()
		# 		op = row1.operator("object.wplpose_verts_toggle", text="Arm L")
		# 		op.opt_nameTokens = 'bn_upperarm01.L:0.5, bn_upperarm02.L, bn_forearm01.L, bn_forearm02.L, bn_hand.L, bn_thumb01.L, bn_thumb02.L, bn_thumb03.L, bn_pinky01.L, bn_ring01.L, bn_middle01.L, bn_index01.L, bn_pinky02.L, bn_ring02.L, bn_middle02.L, bn_index02.L, bn_pinky03.L, bn_ring03.L, bn_middle03.L, bn_index03.L'
		# 		op = row1.operator("object.wplpose_verts_toggle", text="Arm R")
		# 		op.opt_nameTokens = 'bn_upperarm01.R:0.5, bn_upperarm02.R, bn_forearm01.R, bn_forearm02.R, bn_hand.R, bn_thumb01.R, bn_thumb02.R, bn_thumb03.R, bn_pinky01.R, bn_ring01.R, bn_middle01.R, bn_index01.R, bn_pinky02.R, bn_ring02.R, bn_middle02.R, bn_index02.R, bn_pinky03.R, bn_ring03.R, bn_middle03.R, bn_index03.R'

		# 		row_ff = box2.row()
		# 		p0 = row_ff.operator("object.wplpose_verts_toggle", text="T")
		# 		p0.opt_nameTokens = 'bn_thumb01.L:0.21, bn_thumb02.L, bn_thumb03.L'
		# 		p1 = row_ff.operator("object.wplpose_verts_toggle", text="1")
		# 		p1.opt_nameTokens = 'bn_index01.L:0.21, bn_index02.L, bn_index03.L'
		# 		p2 = row_ff.operator("object.wplpose_verts_toggle", text="2")
		# 		p2.opt_nameTokens = 'bn_middle01.L:0.21, bn_middle02.L, bn_middle03.L'
		# 		p3 = row_ff.operator("object.wplpose_verts_toggle", text="3")
		# 		p3.opt_nameTokens = 'bn_ring01.L:0.21, bn_ring02.L, bn_ring03.L'
		# 		p4 = row_ff.operator("object.wplpose_verts_toggle", text="4")
		# 		p4.opt_nameTokens = 'bn_pinky01.L:0.21, bn_pinky02.L, bn_pinky03.L'

		# 		p0 = row_ff.operator("object.wplpose_verts_toggle", text="T")
		# 		p0.opt_nameTokens = 'bn_thumb01.R:0.21, bn_thumb02.R, bn_thumb03.R'
		# 		p1 = row_ff.operator("object.wplpose_verts_toggle", text="1")
		# 		p1.opt_nameTokens = 'bn_index01.R:0.21, bn_index02.R, bn_index03.R'
		# 		p2 = row_ff.operator("object.wplpose_verts_toggle", text="2")
		# 		p2.opt_nameTokens = 'bn_middle01.R:0.21, bn_middle02.R, bn_middle03.R'
		# 		p3 = row_ff.operator("object.wplpose_verts_toggle", text="3")
		# 		p3.opt_nameTokens = 'bn_ring01.R:0.21, bn_ring02.R, bn_ring03.R'
		# 		p4 = row_ff.operator("object.wplpose_verts_toggle", text="4")
		# 		p4.opt_nameTokens = 'bn_pinky01.R:0.21, bn_pinky02.R, bn_pinky03.R'

		# 		row1 = box2.row()
		# 		op = row1.operator("object.wplpose_verts_toggle", text="Breast L")
		# 		op.opt_nameTokens = "bn_breast.L"
		# 		op = row1.operator("object.wplpose_verts_toggle", text="Breast R")
		# 		op.opt_nameTokens = "bn_breast.R"
		# 		row1 = box2.row()
		# 		op = row1.operator("object.wplpose_verts_toggle", text="Leg L")
		# 		op.opt_nameTokens = "bn_thigh01.L:0.26, bn_thigh02.L, bn_shin01.L, bn_shin02.L, bn_foot.L, bn_toe.L"
		# 		op = row1.operator("object.wplpose_verts_toggle", text="Leg R")
		# 		op.opt_nameTokens = "bn_thigh01.R:0.26, bn_thigh02.R, bn_shin01.R, bn_shin02.R, bn_foot.R, bn_toe.R"


class WPL_PT_SculptSPanel2(bpy.types.Panel):
	bl_idname = "WPL_PT_SculptSPanel2"
	bl_label = "Mesh Copy-Paste"
	bl_space_type = 'VIEW_3D'
	bl_region_type = 'UI'
	bl_category = "vSel"

	def draw(self, context):
		layout = self.layout
		active_obj = wla.active_object()
		col = layout.column()
		layout = self.layout
		col = layout.column()
		box1 = None
		if active_obj is not None and active_obj.type == 'MESH' and wla.is_edit_mode():
			if box1 is None:
				box1 = col.box()
			box1.operator("mesh.wplverts_vcopy", text="COPY faces", icon='COPYDOWN').opt_mode = 'COPY'
		# paste can be used without active object
		if box1 is None:
			box1 = col.box()
		box1r = box1.row()
		box1r.operator("mesh.wplverts_vpaste", text="PASTE faces", icon='PASTEDOWN').opt_postAlign = 'NONE'
		box1r.operator("mesh.wplverts_vpaste", text="PASTE at Cursor").opt_postAlign = 'CURSOR'
		box1r = box1.row()
		box1r.operator("mesh.wplverts_vpaste", text="CP-Paste", icon = 'ONIONSKIN_ON').opt_postAlign = 'SELMASS'
		box1r.operator("mesh.wplverts_vpaste", text="SW-Paste", icon = 'ONIONSKIN_ON').opt_postAlign = 'SELSW'
		# if (config.kWPLGKey_EdgePinStrands in config.WPL_G.store):
		# 	box1.operator("mesh.wplverts_vpaste", text="Paste to stored edgeline").opt_postAlign = 'EDGELINE'
		# col.separator()
		# spl1 = col.split(factor = 0.65)
		# spl1.column().operator("mesh.wplsculpt_fastpin_edges", text = "Store Edge Line", icon="SNAP_NORMAL").opt_srcMode = 'EDG'
		# spl1.column().operator("mesh.wplsculpt_fastpin_edges", text = "vSel").opt_srcMode = 'VERTLINE'
		# spl1.column().operator("mesh.wplsculpt_fastpin_edges", text = "vHist").opt_srcMode = 'VERTHIST'

# ==========================================
# ==========================================
# ==========================================
# ==========================================

classes = (
	WPL_PT_SculptSPanel1,
	WPL_PT_SculptSPanel2,

	wplverts_sele_fill,
	wplverts_sele_leftright,
	wplverts_sele_forwbacw,
	wplverts_sele_dir,
	wplverts_sele_toggleact,
	#wplverts_chaindesel,
	#wplverts_sele_mirr,

	wplverts_vcopy,
	wplverts_vpaste,
	wplverts_savesel,
	wplverts_loadsel,

	wplverts_getori,
	wplverts_getori_bone,
	#wplverts_getori_coll,

	wplverts_weldinto,
	wplverts_resetvco,
)

def register():
	for cls in classes:
		bpy.utils.register_class(cls)

def unregister():
	for cls in reversed(classes):
		bpy.utils.unregister_class(cls)

if __name__ == "__main__":
	register()