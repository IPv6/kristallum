import os, sys, time, datetime
import math, copy, string, random
import numpy as np
import bpy, bmesh, mathutils
from functools import reduce
import json

import bpy.types
from mathutils import Vector, Matrix, Euler, Quaternion
from mathutils.bvhtree import BVHTree
from mathutils.kdtree import KDTree
from bpy_extras import view3d_utils
from bpy.props import *

from . import config
from .tools import wla
from .tools import wla_do
from .tools import wla_bm
from .tools import wla_attr
from .tools import wla_curve
from .tools import wla_meshfair
from .tools import wla_meshwrap

kWPL_CutP_Distance = 0.5

# ============================================
def camcut_finish_flow():
	camera_obj = wla.object_by_name(config.kWPLSystemMainCam)
	cutp_name = config.kWPLSystemMainCam + config.kWPLObjCutpPostfix
	cutp_obj = wla.find_child_by_name(camera_obj, cutp_name, False)
	if "camcut_objects" in config.WPL_G.store:
		if "camcut_objects_modf" in config.WPL_G.store:
			# enabling MODFS if any - or cut will be misplaced
			wla_do.modf_toggle_multi(config.WPL_G.store["camcut_objects"], wla_do.kWPLModifsHeavies, None, config.WPL_G.store["camcut_objects_modf"])
			del config.WPL_G.store["camcut_objects_modf"]
		del config.WPL_G.store["camcut_objects"]
	if cutp_obj is not None:
		cutp_obj.hide_viewport = True
	return

# class wplcamcut_flow_gp(bpy.types.Operator):
# 	bl_idname = "mesh.wplcamcut_flow_gp"
# 	bl_label = "Apply CutPlane to GP"
# 	bl_options = {'REGISTER', 'UNDO'}

# 	opt_action : EnumProperty(
# 		name="Action", default="FINISHDELINS",
# 		items=(
# 			("FINISHDELINS", "Finish: Del inside", ""),
# 			("FINISHADDLINES", "Finish: Add curves", "")
# 		))

# 	def getCo2D(self, camera_obj, cutp_obj, co3D_g, cache):
# 		kk = None
# 		if cache is not None:
# 			kk = wla.coToKey(co3D_g)
# 			if kk in cache:
# 				return cache[kk]
# 		p1_co2a_l = wla.math_vecCamProj(cutp_obj, co3D_g, False, None)
# 		p1_co2b = camera_obj.matrix_world.inverted() @ (cutp_obj.matrix_world @ p1_co2a_l)
# 		p1_co2c = (p1_co2b[0], p1_co2b[1])
# 		if cache is not None:
# 			cache[kk] = p1_co2c
# 		return p1_co2c

# 	def execute(self, context):
# 		# https://shapely.readthedocs.io/en/stable/manual.html#merging-linear-features
# 		wla_do.pip_ensure_install("shapely")
# 		import shapely
# 		from shapely.ops import split
# 		v_co_cache = {}
# 		camera_obj = wla.object_by_name(config.kWPLSystemMainCam)
# 		cutp_obj = wla.find_child_by_name(camera_obj, cutp_name, False)
# 		wla_do.select_and_change_mode(cutp_obj, 'OBJECT')
# 		if "camcut_objects" in config.WPL_G.store:
# 			print("- preparing cut", self.opt_action, cutp_obj.name, len(cutp_obj.data.vertices), len(cutp_obj.data.polygons))
# 			shapel_polygs = []
# 			shapel_exactsplits = True
# 			sel_objs = config.WPL_G.store["camcut_objects"]
# 			# if no faces - making one
# 			if len(cutp_obj.data.polygons) == 0 and len(cutp_obj.data.vertices) > 2:
# 				print("- cutplane: making faces")
# 				wla_do.select_and_change_mode(cutp_obj, 'EDIT')
# 				bpy.ops.mesh.select_all( action = 'SELECT' )
# 				bpy.ops.mesh.edge_face_add()
# 				wla_do.select_and_change_mode(cutp_obj, 'OBJECT')
# 			if len(cutp_obj.data.polygons) > 0:
# 				for f in cutp_obj.data.polygons:
# 					polyg2d = []
# 					for vIdx in f.vertices:
# 						v = cutp_obj.data.vertices[vIdx]
# 						v_co2 = self.getCo2D(camera_obj, cutp_obj, cutp_obj.matrix_world @ v.co, v_co_cache)
# 						polyg2d.append(v_co2)
# 					line = shapely.geometry.LinearRing(polyg2d)
# 					polygon = shapely.geometry.Polygon(line)
# 					shapel_polygs.append(polygon)
# 					print("- polygon added", len(polyg2d)) # polygon.bounds, polygon.exterior.coords, polygon.interiors)
# 			if len(shapel_polygs)>0:
# 				for obj_name in sel_objs:
# 					objSrc = wla.object_by_name(obj_name)
# 					if objSrc.type != 'GPENCIL':
# 						continue
# 					# step 1 - subdividing intersections
# 					wla_do.select_and_change_mode(objSrc, 'OBJECT')
# 					wla_do.select_and_change_mode(objSrc, 'EDIT')
# 					ops_curves_edit.cu_desel_all(objSrc)
# 					splines = wla_curve.cu_getSplines(objSrc)
# 					pts2subd = 0
# 					for polyline in splines:
# 						points = wla_curve.cu_getPoints(polyline)
# 						for ip in range(0, len(points)):
# 							p1 = points[ip]
# 							p1_co2 = shapely.geometry.Point(self.getCo2D(camera_obj, cutp_obj, objSrc.matrix_world @ p1.co, v_co_cache))
# 							p1prev = None
# 							if ip-1 >= 0:
# 								p1prev = points[ip-1]
# 							p1next = None
# 							if ip+1 < len(points):
# 								p1next = points[ip+1]
# 							for poly in shapel_polygs:
# 								if poly.covers(p1_co2):
# 									#print("- COVERS", p1_co2, p1, p1prev, p1next)
# 									p1.select = True
# 									pts2subd = pts2subd+1
# 									if p1prev is not None:
# 										p1prev.select = True
# 										pts2subd = pts2subd+1
# 									if p1next is not None:
# 										p1next.select = True
# 										pts2subd = pts2subd+1
# 								elif p1next is not None:
# 									p1next_co2 = shapely.geometry.Point(self.getCo2D(camera_obj, cutp_obj, objSrc.matrix_world @ p1next.co, v_co_cache))
# 									if poly.crosses(shapely.geometry.LineString([p1_co2, p1next_co2])):
# 										p1.select = True
# 										p1next.select = True
# 										pts2subd = pts2subd+2
# 					print("- pre-subdivs", pts2subd)
# 					if pts2subd > 1:
# 						ops_curves_edit.cu_subd_sel(objSrc, 3)
# 					# step 2 - deleting inners
# 					wla_do.select_and_change_mode(objSrc, 'OBJECT')
# 					wla_do.select_and_change_mode(objSrc, 'EDIT')
# 					ops_curves_edit.cu_desel_all(objSrc)
# 					splines = wla_curve.cu_getSplines(objSrc)
# 					pts2del = 0
# 					for polyline in splines:
# 						points = wla_curve.cu_getPoints(polyline)
# 						for ip in range(0, len(points)):
# 							p1 = points[ip]
# 							p1_co2 = shapely.geometry.Point(self.getCo2D(camera_obj, cutp_obj, objSrc.matrix_world @ p1.co, v_co_cache))
# 							p1prev = None
# 							p1prev_co2 = None
# 							if ip-1 >= 0:
# 								p1prev = points[ip-1]
# 								p1prev_co2 = shapely.geometry.Point(self.getCo2D(camera_obj, cutp_obj, objSrc.matrix_world @ p1prev.co, v_co_cache))
# 							p1next = None
# 							p1next_co2 = None
# 							if ip+1 < len(points):
# 								p1next = points[ip+1]
# 								p1next_co2 = shapely.geometry.Point(self.getCo2D(camera_obj, cutp_obj, objSrc.matrix_world @ p1next.co, v_co_cache))
# 							for poly in shapel_polygs:
# 								need2del = False
# 								if poly.covers(p1_co2):
# 									need2del = True
# 									if shapel_exactsplits:
# 										# Do NOT deleting segments intersecting poly edges
# 										if (p1prev_co2 is not None) and poly.covers(p1prev_co2) == False:
# 											need2del = False
# 										if (p1next_co2 is not None) and poly.covers(p1next_co2) == False:
# 											need2del = False
# 								if need2del:
# 									pts2del = pts2del+1
# 									p1.select = True
# 					if pts2del>0:
# 						print("- pre-deleting", pts2del)
# 						ops_curves_edit.cu_delv_sel(objSrc)
# 					if shapel_exactsplits:
# 						# step 3: intersections: moving inner point to intersection point
# 						wla_do.select_and_change_mode(objSrc, 'OBJECT')
# 						wla_do.select_and_change_mode(objSrc, 'EDIT')
# 						ops_curves_edit.cu_desel_all(objSrc)
# 						splines = wla_curve.cu_getSplines(objSrc)
# 						pts2mov = 0
# 						for polyline in splines:
# 							points = wla_curve.cu_getPoints(polyline)
# 							if len(points) > 1:
# 								for pp in [ (points[0], points[1]), (points[-2], points[-1])]:
# 									p1 = pp[0]
# 									p2 = pp[1]
# 									p1_co2 = shapely.geometry.Point(self.getCo2D(camera_obj, cutp_obj, objSrc.matrix_world @ p1.co, v_co_cache))
# 									p2_co2 = shapely.geometry.Point(self.getCo2D(camera_obj, cutp_obj, objSrc.matrix_world @ p2.co, v_co_cache))
# 									for poly in shapel_polygs:
# 										itrVec = None
# 										if poly.covers(p1_co2) == True and poly.covers(p2_co2) == False:
# 											itrVec = [p1_co2, p2_co2, p1, p2]
# 										elif poly.covers(p2_co2) == True and poly.covers(p1_co2) == False:
# 											itrVec = [p2_co2, p1_co2, p2, p1]
# 										if itrVec is not None:
# 											# moving first to intersection point
# 											line = shapely.geometry.LineString([itrVec[0], itrVec[1]])
# 											spl = split(line, poly)
# 											if spl is not None and len(spl.geoms) == 2:
# 												inner_spl = spl.geoms[0]
# 												if poly.covers(spl.geoms[1]):
# 													inner_spl = spl.geoms[1]
# 												spl_dist = inner_spl.length / line.length
# 												print("- split found", inner_spl.length, line.length, spl_dist)
# 												p_in = itrVec[2]
# 												p_out = itrVec[3]
# 												p_in.co = p_in.co.lerp(p_out.co, spl_dist)
# 												pts2mov = pts2mov+1
# 						if pts2mov>0:
# 							print("- moved pts", pts2mov)
# 			else:
# 				print("- no faces found")
# 			camcut_finish_flow()
# 			wla_do.select_and_change_mode(camera_obj, 'OBJECT')
# 		self.report({'INFO'}, "Done")
# 		return {'FINISHED'}

class wplcamcut_flow_annot(bpy.types.Operator):
	bl_idname = "mesh.wplcamcut_flow_annot"
	bl_label = "Cut Action from annotations"
	bl_options = {'REGISTER', 'UNDO'}

	opt_action : EnumProperty(
		name="Action", default="FINISHDELINS",
		items=(
			("FINISHDELINS", "Finish: Del inside", ""),
			("FINISHSEL", "Finish: Select", ""),
			("FINISHDUPLI", "Finish: Duplicate", ""),
			("FINISHEXTR_NRM", "Finish: Extract NRM", ""),
		)
	)

	opt_pointsJson : StringProperty(
		name = "Points Source",
		default = "<annot>"
	)

	def execute(self, context):
		sel_all = wla.selected_objects(['MESH','GPENCIL'], True)
		if len(sel_all) == 0:
			self.report({'ERROR'}, "No objects selected")
			return {'FINISHED'}
		active_obj = wla.active_object(['MESH','GPENCIL'])
		if active_obj is None:
			self.report({'ERROR'}, "Select some objects")
			return {'CANCELLED'}
		active_obj_name = active_obj.name
		oldmode = wla_do.select_and_change_mode(active_obj, 'OBJECT')
		annot_strokes = []
		pointsJson = self.opt_pointsJson
		if pointsJson == '<annot>':
			annot_strokes = wla_curve.gp_get_annots()
			if len(annot_strokes) == 0:
				print("- GP: annot points not found")
				self.report({'ERROR'}, "No strokes found")
				return {'FINISHED'}
			print("- GP: annot points found", len(annot_strokes), len(annot_strokes[0]))
			bpy.ops.gpencil.data_unlink()
			# switching from annotator
			bpy.ops.wm.tool_set_by_id(name="builtin.select")
		elif len(pointsJson) > 0:
			# unpacking from JSON
			annot_strokes = json.loads(pointsJson)
			print("- GP: points found", len(annot_strokes[0]))
		camera_obj = wla.object_by_name(config.kWPLSystemMainCam)
		if camera_obj is None:
			self.report({'ERROR'}, "Camera not found: "+config.kWPLSystemMainCam)
			return {'CANCELLED'}
		wla_do.ensure_visible(camera_obj, 1)
		cutp_name = config.kWPLSystemMainCam + config.kWPLObjCutpPostfix
		cutp_obj = wla.find_child_by_name(camera_obj, cutp_name, False)
		if cutp_obj is not None:
			# deleting, need fresh
			bpy.data.objects.remove(cutp_obj, do_unlink=True)
		# adding cut object
		bpy.ops.mesh.primitive_plane_add(size=0.1, align='WORLD', enter_editmode=False, location=Vector((0,0,0)))
		cutp_obj = wla.active_object()
		cutp_obj.name = cutp_name
		cutp_obj.data.name = config.kWPLSystemMainCam+"_cutmesh"
		cutp_obj.parent = camera_obj
		wla_do.link_object_to_scene(cutp_obj, config.kWPLSystemMainColl, 1)
		wla_do.set_object_noShadow(cutp_obj, True, True)
		cutp_obj.show_all_edges = True
		cutp_obj.matrix_world = camera_obj.matrix_world
		wla_do.select_and_change_mode(active_obj, 'OBJECT')
		okFaces = 0
		if len(annot_strokes)>0:
			# making cutp polygon
			wla_do.select_and_change_mode(cutp_obj, 'EDIT')
			context.tool_settings.mesh_select_mode = (True, False, False) # 'VERT'
			bm = bmesh.from_edit_mesh(cutp_obj.data)
			bm.verts.ensure_lookup_table()
			bm.verts.index_update()
			if len(bm.verts) > 0:
				print("- removing old verts", len(bm.verts))
				bmesh.ops.delete(bm, geom=bm.verts, context='VERTS')
			for stroke in annot_strokes:
				meshf = []
				for pt_co_g in stroke:
					#vv_co_l = wla.math_vecCamProj(cutp_obj, pt_co_g, False, None) # no need to project from CAMERA!!! region-view is needed
					vv_co_l = cutp_obj.matrix_world.inverted() @ Vector( pt_co_g )
					newv = bm.verts.new(vv_co_l)
					meshf.append(newv)
				bm.verts.ensure_lookup_table()
				bm.verts.index_update()
				if len(meshf) >= 3:
					okFaces = okFaces+1
					bm.faces.new(meshf)
			print("- removing doubles")
			bm.verts.ensure_lookup_table()
			bm.verts.index_update()
			bm.faces.ensure_lookup_table()
			bm.faces.index_update()
			# merging faces if same positions
			bmesh.ops.remove_doubles(bm, verts=bm.verts, dist=0.002)
			bmesh.update_edit_mesh(cutp_obj.data)
			if len(bm.verts)>50:
				print("- simplifying project contours")
				bpy.ops.mesh.select_all(action='SELECT')
				bpy.ops.mesh.dissolve_limited()
		if okFaces == 0:
			wla_do.select_and_change_mode(active_obj, oldmode)
			camcut_finish_flow()
			self.report({'ERROR'}, "No valid strokes found")
			return {'FINISHED'}
		# replacing to avoid ambiguity
		config.WPL_G.store["camcut_objects"] = sel_all
		if "camcut_objects_modf" in config.WPL_G.store:
			del config.WPL_G.store["camcut_objects_modf"]
		wla_do.select_and_change_mode(cutp_obj, 'OBJECT')
		wla_do.select_and_change_mode(cutp_obj, 'EDIT')
		# DBG
		# self.report({'INFO'}, "Done: DBG")
		# return {'FINISHED'}
		# executing real knife project
		print("- projecting...", len(cutp_obj.data.vertices))
		bpy.ops.mesh.wplcamcut_flow(opt_action = self.opt_action)
		if self.opt_action in ('FINISHDELINS', 'FINISHDUPLI', 'FINISHSEL'):
			active_obj = wla.object_by_name(active_obj_name)
			wla_do.select_and_change_mode(active_obj, oldmode)
		# else: Cut-copy in EDIT mode already
		self.report({'INFO'}, "Done")
		return {'FINISHED'}

class wplcamcut_flow(bpy.types.Operator):
	bl_idname = "mesh.wplcamcut_flow"
	bl_label = "Cut Action from Plane"
	bl_options = {'REGISTER', 'UNDO'}

	opt_action : EnumProperty(
		name="Action", default="STARTCUT",
		items=(
			("STARTCUT", "Start", ""), 
			("FINISHDELINS", "Finish: Del inside", ""),
			("FINISHDELOUT", "Finish: Del outside", ""),
			("FINISHDUPLI", "Finish: Duplicate", ""),
			("FINISHSEL", "Finish: Select", ""),
			("FINISHEXTR_NRM", "Finish: Extract NRM", ""),
			("FINISHCANCEL", "Cancel cut", "")
		)
	)

	def execute(self, context):
		active_pos_g = None
		bpy.context.space_data.show_gizmo_object_translate = True
		active_obj = wla.active_object(['MESH','GPENCIL'])
		if active_obj is not None and self.opt_action == "STARTCUT":
			active_pos_g = wla_meshwrap.objectm_vertsAvgCo(active_obj, active_pos_g, True, True)
		# adding cutplane2camera
		camera_obj = wla.object_by_name(config.kWPLSystemMainCam)
		if camera_obj is None:
			self.report({'ERROR'}, "Camera not found: "+config.kWPLSystemMainCam)
			return {'CANCELLED'}
		wla_do.ensure_visible(camera_obj, 1)
		cutp_name = config.kWPLSystemMainCam + config.kWPLObjCutpPostfix
		cutp_obj = wla.find_child_by_name(camera_obj, cutp_name, False)
		if self.opt_action == "FINISHCANCEL":
			camcut_finish_flow()
			wla_do.select_and_change_mode(camera_obj, 'OBJECT')
			self.report({'INFO'}, "Cancelled")
			return {'FINISHED'}
		sel_all = wla.selected_objects(['MESH','GPENCIL'], True)
		if len(sel_all) == 0:
			self.report({'ERROR'}, "No objects selected")
			return {'FINISHED'}
		needBack2LV = False
		if cutp_obj is None:
			if wla.is_local_view():
				bpy.ops.view3d.localview()
				needBack2LV = True
			wla_do.select_and_change_mode(camera_obj, 'OBJECT')
			bpy.ops.mesh.primitive_plane_add(size=0.1, align='WORLD', enter_editmode=False, location=Vector((0,0,-kWPL_CutP_Distance)))
			cutp_obj = wla.active_object()
			cutp_obj.name = cutp_name
			cutp_obj.data.name = config.kWPLSystemMainCam+"_cutmesh"
			cutp_obj.parent = camera_obj
			wla_do.link_object_to_scene(cutp_obj, config.kWPLSystemMainColl, 1)
			wla_do.set_object_noShadow(cutp_obj, True, True)
			cutp_obj.show_all_edges = True
		if cutp_obj is None:
			self.report({'ERROR'}, "Cant create cutplane")
			return {'FINISHED'}
		if self.opt_action == "STARTCUT":
			config.WPL_G.store["camcut_objects"] = sel_all
			config.WPL_G.store["camcut_objects_modf"] = {}
			# enabling MODFS if any - or cut will be misplaced
			mac_obj_mtx = camera_obj.matrix_world # improtant for testing in rotated positions
			wla_do.modf_toggle_multi(config.WPL_G.store["camcut_objects"], wla_do.kWPLModifsHeavies, False, config.WPL_G.store["camcut_objects_modf"])
			wla_do.select_and_change_mode(cutp_obj, 'OBJECT')
			if wla.is_local_view():
				bpy.ops.view3d.localview()
				needBack2LV = True
			if needBack2LV == True:
				cutp_obj.select_set(True)
				camera_obj.select_set(True) # for trafarefs to work
				needBack2LV = False
				for obj_name in sel_all:
					objSrc = wla.object_by_name(obj_name)
					objSrc.select_set(True)
				bpy.ops.view3d.localview()
			bpy.ops.view3d.view_axis(type='TOP')
			bpy.ops.view3d.view_camera()
			camera_obj.matrix_world = mac_obj_mtx # improtant for testing in rotated positions
			cutp_obj.hide_viewport = False
			wla_do.select_and_change_mode(cutp_obj, 'EDIT')
			context.tool_settings.mesh_select_mode = (True, False, False) # 'VERT'
			bm = bmesh.from_edit_mesh(cutp_obj.data)
			bm.verts.ensure_lookup_table()
			bm.verts.index_update()
			if len(bm.verts) > 0:
				print("- cut object: removing previous content")
				bmesh.ops.delete(bm, geom=bm.verts, context='VERTS')
			bm.verts.ensure_lookup_table()
			bm.verts.index_update()
			center_v_co = Vector((0,0,0))
			if active_pos_g is not None:
				# reprojecting to camera
				print("- reprojecting to camera plane") # active_pos_g, cutp_obj.matrix_world.to_translation()
				# so start vector is aligned with selection
				center_v_co2_l = wla.math_vecCamProj(cutp_obj, active_pos_g, False, None)
				if center_v_co2_l is not None:
					center_v_co = center_v_co2_l
			print("- start vertex pos", center_v_co)
			newv = bm.verts.new(center_v_co)
			newv.select = True
			bm.verts.ensure_lookup_table()
			bm.verts.index_update()
			bmesh.update_edit_mesh(cutp_obj.data)
			wla_do.select_and_change_mode(cutp_obj, 'OBJECT')
			wla_do.select_and_change_mode(cutp_obj, 'EDIT')
			self.report({'INFO'}, "Cutplane initialized")
		elif "camcut_objects" in config.WPL_G.store:
			# deletes
			wla_do.ensure_visible(cutp_obj, 2)
			wla_do.select_and_change_mode(cutp_obj, 'OBJECT')
			print("- preparing cut", self.opt_action, cutp_obj.name, len(cutp_obj.data.vertices), len(cutp_obj.data.polygons))
			# if no faces - making one
			if len(cutp_obj.data.polygons) == 0 and len(cutp_obj.data.vertices) > 2:
				print("- cutplane: making faces")
				wla_do.select_and_change_mode(cutp_obj, 'EDIT')
				bpy.ops.mesh.select_all( action = 'SELECT' )
				bpy.ops.mesh.edge_face_add()
				wla_do.select_and_change_mode(cutp_obj, 'OBJECT')
			if len(cutp_obj.data.polygons) == 0 and not self.opt_action == 'FINISHEXTR_NRM':
				self.report({'ERROR'}, "Cant use cutplane: no faces")
				return {'FINISHED'}
			sel_objs = config.WPL_G.store["camcut_objects"]
			for obj_name in sel_objs:
				wla_do.select_and_change_mode(cutp_obj, 'OBJECT')
				if cutp_obj.type != 'MESH':
					continue
				objSrc = wla.object_by_name(obj_name)
				objClone = None
				if config.kWPLSystemMainCam in obj_name or objSrc.type != 'MESH':
					continue
				if self.opt_action == "FINISHEXTR_NRM":
					objClone = wla_do.clone_evaluated_obj(objSrc, objSrc.name+"_cut"+config.kWPLObjProtoToken[0], False, True, None)
					objSrc = objClone
					wla_do.select_and_change_mode(objSrc, 'OBJECT')
				if len(cutp_obj.data.polygons) > 0:
					print("- making cut", objSrc.name, len(cutp_obj.data.vertices), len(cutp_obj.data.polygons))
					wla_do.select_and_change_mode(objSrc, 'EDIT')
					context.tool_settings.mesh_select_mode = (False, True, False) # 'EDGE'
					# 300 Problem: Multiedit-mode instead of proper selected-active!!!
					#wla_do.select_and_change_mode(cutp_obj, 'OBJECT')
					# bpy.ops.object.select_all(action='DESELECT')
					# cutp_obj.select_set(True)
					# objSrc.select_set(True)
					# wla_do.set_active_object(obj)
					# bpy.ops.object.mode_set(mode='EDIT') # !!! NOT wla_do.select_and_change_mode(obj, 'EDIT')
					# bpy.ops.mesh.select_all(action='DESELECT')
					# knife_project: Taken from "Quad Swords" by Kushiro
					wla_do.sys_update_view(False, True)
					override1 = context.copy()
					override1['selected_objects'] = []
					override1['selected_objects'].append(cutp_obj)
					override1['selected_objects'].append(objSrc)
					bpy.ops.mesh.knife_project(override1, cut_through  = True)
					#bpy.ops.object.mode_set(mode='EDIT')
				else:
					print("- making copy",objSrc.name,"no faces in cut object")
				wla_do.select_and_change_mode(objSrc, 'EDIT') # must be only selected in EDIT mode 
				if self.opt_action == "FINISHSEL":
					pass
				if self.opt_action == "FINISHDUPLI":
					bpy.ops.mesh.duplicate()
					bpy.ops.mesh.region_to_loop()
					bpy.ops.transform.edge_crease(value=1)
				if self.opt_action == "FINISHDELINS":
					bpy.ops.mesh.split()
					bpy.ops.mesh.delete(type='VERT')
				if self.opt_action == "FINISHDELOUT" or self.opt_action == "FINISHEXTR_NRM":
					bpy.ops.mesh.split()
					bpy.ops.mesh.select_more()
					bpy.ops.mesh.select_all(action='INVERT')
					bpy.ops.mesh.delete(type='VERT')
				bpy.ops.mesh.select_mode(type='VERT')
				if objClone is not None:
					mdsEnabled = wla_do.modf_toggle(objClone, wla_do.kWPLModifsHeavies, True, None)
					if len(mdsEnabled) > 0:
						# hardening edges
						bpy.ops.mesh.select_all(action='SELECT')
						bpy.ops.mesh.region_to_loop()
						bpy.ops.transform.edge_crease(value=1)
					if self.opt_action == "FINISHEXTR_NRM":
						objSrc0 = wla.object_by_name(obj_name)
						wla_do.link_with_vgsbind(objSrc0, objClone)
			camcut_finish_flow()
			self.report({'INFO'}, "Done")
		return {'FINISHED'}


# ==========================================
# ==========================================

class WPL_PT_CamCutPanel(bpy.types.Panel):
	bl_idname = "WPL_PT_CamCutPanel"
	bl_label = "CamCut"
	bl_space_type = 'VIEW_3D'
	bl_region_type = 'UI'
	bl_category = 'Sculpt'

	def draw(self, context):
		layout = self.layout
		active_obj = wla.active_object()
		col = layout.column()

		layout = self.layout
		col = layout.column()

		if active_obj is None or active_obj.type not in ['MESH', 'GPENCIL']:
			col.label(text = "CamCut: inactive, need edit mesh")
		else:
			if "camcut_objects" not in config.WPL_G.store:
				col.operator("mesh.wplcamcut_flow", text='Start Camera Cut', icon = 'ORIENTATION_VIEW').opt_action = 'STARTCUT'
				col.separator()
				op = col.operator("mesh.wplcamcut_flow_annot", text='Annot-Cut: Cut+Select')
				op.opt_action = 'FINISHSEL'
				op.opt_pointsJson = "<annot>"
				op = col.operator("mesh.wplcamcut_flow_annot", text='Annot-Cut: Cut+Duplicate')
				op.opt_action = 'FINISHDUPLI'
				op.opt_pointsJson = "<annot>"
				op = col.operator("mesh.wplcamcut_flow_annot", text='Annot-Cut: Del inside', icon='GP_SELECT_BETWEEN_STROKES')
				op.opt_action = 'FINISHDELINS'
				op.opt_pointsJson = "<annot>"
				op = col.operator("mesh.wplcamcut_flow_annot", text='Annot-Cut: Extract Cut', icon='MOD_EXPLODE')
				op.opt_action = 'FINISHEXTR_NRM'
				op.opt_pointsJson = "<annot>"
			else:
				sel_objs = config.WPL_G.store["camcut_objects"]
				objSrc = wla.object_by_name(sel_objs[0])
				if objSrc.type == 'MESH':
					col.operator("mesh.wplcamcut_flow", text='Finish cut: del inside', icon='GP_SELECT_BETWEEN_STROKES').opt_action = 'FINISHDELINS'
					col.operator("mesh.wplcamcut_flow", text='Finish cut: del outside').opt_action = 'FINISHDELOUT'
					col.operator("mesh.wplcamcut_flow", text='Finish cut: duplicate').opt_action = 'FINISHDUPLI'
					col.operator("mesh.wplcamcut_flow", text='Finish cut: select').opt_action = 'FINISHSEL'
					col.operator("mesh.wplcamcut_flow", text='Extract cut', icon='MOD_EXPLODE').opt_action = 'FINISHEXTR_NRM'
				# if objSrc.type == 'GPENCIL':
				# 	col.operator("mesh.wplcamcut_flow_gp", text='Finish cut: del inside').opt_action = 'FINISHDELINS'
				col.operator("mesh.wplcamcut_flow", text='Cancel cut', icon='CANCEL').opt_action = 'FINISHCANCEL'
		annot_strokes = wla_curve.gp_get_annots()
		if len(annot_strokes)>0:
			col.operator("gpencil.data_unlink", text='Cancel annotation', icon='CANCEL')

# ==========================================
# ==========================================

classes = (

	WPL_PT_CamCutPanel,
	wplcamcut_flow,
	#wplcamcut_flow_gp,
	wplcamcut_flow_annot,

)

def register():
	for cls in classes:
		bpy.utils.register_class(cls)

def unregister():
	for cls in reversed(classes):
		bpy.utils.unregister_class(cls)

if __name__ == "__main__":
	register()