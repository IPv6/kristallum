import os, sys, time, datetime
import math, copy, string, random
import numpy as np
import bpy, bmesh, mathutils

import bpy.types
from mathutils import Vector, Matrix, Euler, Quaternion
from mathutils.bvhtree import BVHTree
from mathutils.kdtree import KDTree
from bpy_extras import view3d_utils
from bpy.props import *

from . import config
from .tools import wla
from .tools import wla_do
from .tools import wla_attr
from .tools import wla_arma
from .tools import wla_meshwrap
from .tools import wla_bm
from . import ops_prop_edging

kWPLArmStickmanMat = "fg_bodySkin"
kWPLArmStickmanCol = "#FFD4C2" # kWPLMeshColVC

kWPLArmStickmanBnsSpheres_MLOW = [
	# голова
	{"anchor": "bn_head", "sphere_rad": "bn_len['bn_head']*0.3", "sphere_co": "bn_head['bn_head']*0.5+bn_tail['bn_head']*0.5", "sphere_scale": "(1.3,1.0,1.3)"},
	
	# плечи - около-анатомические центр поворота
	#{"anchor": "bn_shoulder.R", "sphere_rad": "bn_min['bn_upperarm01.R']*0.3", "sphere_co": "bn_head['bn_upperarm01.R']+bn_avg['bn_upperarm01.R']*0.6*(bn_dirz['bn_upperarm01.R']+bn_diry['bn_upperarm01.R']*1.3)"},
	#{"anchor": "bn_shoulder.L", "sphere_rad": "bn_min['bn_upperarm01.L']*0.3", "sphere_co": "bn_head['bn_upperarm01.L']+bn_avg['bn_upperarm01.L']*0.6*(bn_dirz['bn_upperarm01.L']+bn_diry['bn_upperarm01.L']*1.3)"},
	# {"anchor": "bn_shoulder.R", "sphere_rad": "bn_min['bn_upperarm01.R']*0.4", "sphere_co": "bn_tail['bn_shoulder.R']+bn_diry['bn_shoulder.R']*bn_len['bn_shoulder.R']*0.3-bn_dirz['bn_shoulder.R']*bn_len['bn_shoulder.R']*0.04"},
	# {"anchor": "bn_shoulder.L", "sphere_rad": "bn_min['bn_upperarm01.L']*0.4", "sphere_co": "bn_tail['bn_shoulder.L']+bn_diry['bn_shoulder.L']*bn_len['bn_shoulder.L']*0.3-bn_dirz['bn_shoulder.L']*bn_len['bn_shoulder.L']*0.04"},
	# {"anchor_f": "bn_upperarm01.R", "sphere_rad": "bn_min['bn_upperarm01.R']*0.9", "sphere_co": "bn_head['bn_upperarm01.R']+bn_diry['bn_shoulder.R']*0.06"},
	# {"anchor_f": "bn_upperarm01.L", "sphere_rad": "bn_min['bn_upperarm01.L']*0.9", "sphere_co": "bn_head['bn_upperarm01.L']+bn_diry['bn_shoulder.L']*0.06"},
	# плечи
	{"anchor": "bn_upperarm01.R", "sphere_rad": "bn_min['bn_upperarm01.R']", "sphere_co": "bn_head['bn_upperarm01.R']+bn_diry['bn_upperarm01.R']*0.06"},
	{"anchor": "bn_upperarm01.L", "sphere_rad": "bn_min['bn_upperarm01.L']", "sphere_co": "bn_head['bn_upperarm01.L']+bn_diry['bn_upperarm01.L']*0.06"},

	# ключицы (clavicle)
	{"anchor": "bn_shoulder.R", "s_verts":"(v_idx in seam_vertsIdx) and bn_weightIn(v_idx,'bn_shoulder.R', 0.25, 1.0)", "convexadd_co": "v_co"},
	{"anchor": "bn_shoulder.L", "s_verts":"(v_idx in seam_vertsIdx) and bn_weightIn(v_idx,'bn_shoulder.L', 0.25, 1.0)", "convexadd_co": "v_co"},
	# мечевидный отросток (грудь)
	{"anchor": "bn_spine04", "s_verts":"(v_idx in seam_vertsIdx) and bn_weightIn(v_idx,'bn_spine04', 0.74,1.0) and bn_weightIn(v_idx,'bn_spine03',0.05,1.0)", "convexadd_co": "v_co"},
	
	# локти
	{"anchor": "bn_upperarm02.R", "sphere_rad": "bn_min['bn_forearm01.R']*0.6", "sphere_co": "bn_tail['bn_upperarm02.R']+bn_diry['bn_upperarm02.R']*0.15", "sphere_scale": "(1.0,1.0,0.5)"},
	{"anchor": "bn_upperarm02.R", "sphere_rad": "bn_min['bn_forearm01.R']*0.6", "sphere_co": "bn_tail['bn_upperarm02.R']+bn_diry['bn_upperarm02.R']*0.15", "sphere_scale": "(1.0,0.5,1.0)"},
	{"anchor": "bn_upperarm02.L", "sphere_rad": "bn_min['bn_forearm01.L']*0.6", "sphere_co": "bn_tail['bn_upperarm02.L']+bn_diry['bn_upperarm02.L']*0.15", "sphere_scale": "(1.0,1.0,0.5)"},
	{"anchor": "bn_upperarm02.L", "sphere_rad": "bn_min['bn_forearm01.L']*0.6", "sphere_co": "bn_tail['bn_upperarm02.L']+bn_diry['bn_upperarm02.L']*0.15", "sphere_scale": "(1.0,0.5,1.0)"},
	#{"anchor": "bn_forearm01.R", "s_verts":"(v_idx in seam_vertsIdx) and bn_weightIn(v_idx,'bn_upperarm02.R', 0.49, 0.51)", "seamlim_rad": "bn_min['bn_upperarm02.R']*0.1", "convexadd_co": "v_co"},
	#{"anchor": "bn_forearm01.L", "s_verts":"(v_idx in seam_vertsIdx) and bn_weightIn(v_idx,'bn_upperarm02.L', 0.49, 0.51)", "seamlim_rad": "bn_min['bn_upperarm02.L']*0.1", "convexadd_co": "v_co"},

	# ладонь - основание
	{"anchor": "bn_forearm02.R", "sphere_rad": "bn_min['bn_forearm02.R']", "sphere_co": "bn_head['bn_hand.R']", "sphere_scale": "(0.5,0.95,0.5)"},
	{"anchor": "bn_forearm02.R", "sphere_rad": "bn_min['bn_forearm02.R']", "sphere_co": "bn_head['bn_hand.R']", "sphere_scale": "(0.95,0.5,0.5)"},
	{"anchor": "bn_forearm02.L", "sphere_rad": "bn_min['bn_forearm02.L']", "sphere_co": "bn_head['bn_hand.L']", "sphere_scale": "(0.5,0.95,0.5)"},
	{"anchor": "bn_forearm02.L", "sphere_rad": "bn_min['bn_forearm02.L']", "sphere_co": "bn_head['bn_hand.L']", "sphere_scale": "(0.95,0.5,0.5)"},

	# кости таза
	{"anchor": "bn_pelvis.R", "s_verts":"(v_idx in seam_vertsIdx) and bn_weightIn(v_idx,'bn_pelvis.R', 0.25, 0.7)", "convexadd_co": "v_co*0.95+bn_tail['bn_pelvis.R']*0.05"},
	{"anchor": "bn_pelvis.L", "s_verts":"(v_idx in seam_vertsIdx) and bn_weightIn(v_idx,'bn_pelvis.L', 0.25, 0.7)", "convexadd_co": "v_co*0.95+bn_tail['bn_pelvis.L']*0.05"},
	
	# копчик - convex
	{"anchor": "bn_spine02", "s_verts":"(v_idx in seam_vertsIdx) and bn_weightIn(v_idx,'bn_spine02', 0.149, 0.501)", "convexadd_co": "v_co"},

	# лобок - convex
	{"anchor": "bn_spine01", "s_verts":"(v_idx in seam_vertsIdx) and bn_weightIn(v_idx,'bn_spine01', 0.69, 0.71)", "convexadd_co": "v_co"},

	# бедра
	{"anchor": "bn_thigh01.R", "sphere_rad": "bn_min['bn_thigh01.R']*0.9", "sphere_co": "bn_head['bn_thigh01.R']"},
	{"anchor": "bn_thigh01.L", "sphere_rad": "bn_min['bn_thigh01.L']*0.9", "sphere_co": "bn_head['bn_thigh01.L']"},

	# колени - конвекс на кости адекватнее
	# {"anchor": "bn_thigh02.R", "sphere_rad": "bn_min['bn_thigh02.R']*1.1", "sphere_co": "bn_tail['bn_thigh02.R']+bn_min['bn_thigh02.R']*0.6*bn_dirz['bn_thigh02.R']", "sphere_scale": "(0.4,1.0,0.85)"},
	# {"anchor": "bn_thigh02.R", "sphere_rad": "bn_min['bn_thigh02.R']*1.1", "sphere_co": "bn_tail['bn_thigh02.R']+bn_min['bn_thigh02.R']*0.6*bn_dirz['bn_thigh02.R']", "sphere_scale": "(0.9,1.0,0.4)"},
	# {"anchor": "bn_thigh02.L", "sphere_rad": "bn_min['bn_thigh02.L']*1.1", "sphere_co": "bn_tail['bn_thigh02.L']+bn_min['bn_thigh02.L']*0.6*bn_dirz['bn_thigh02.R']", "sphere_scale": "(0.4,1.0,0.85)"},
	# {"anchor": "bn_thigh02.L", "sphere_rad": "bn_min['bn_thigh02.L']*1.1", "sphere_co": "bn_tail['bn_thigh02.L']+bn_min['bn_thigh02.L']*0.6*bn_dirz['bn_thigh02.R']", "sphere_scale": "(0.9,1.0,0.4)"},
	# {"anchor": "bn_thigh02.R", "s_verts":"(v_idx in seam_vertsIdx) and bn_weightIn(v_idx,'bn_thigh02.R', 0.59, 0.61)", "convexadd_co": "v_co"},
	# {"anchor": "bn_thigh02.L", "s_verts":"(v_idx in seam_vertsIdx) and bn_weightIn(v_idx,'bn_thigh02.L', 0.59, 0.61)", "convexadd_co": "v_co"},

	# большберцовая кость (колени-2)
	#{"anchor": "bn_shin01.R", "s_verts":"(v_idx in seam_vertsIdx) and bn_weightIn(v_idx,'bn_shin01.R', 0.89, 0.91)", "convexadd_co": "v_co"},
	#{"anchor": "bn_shin01.L", "s_verts":"(v_idx in seam_vertsIdx) and bn_weightIn(v_idx,'bn_shin01.L', 0.89, 0.91)", "convexadd_co": "v_co"},

	# основания пальцев
	{"anchor": "bn_hand.L", "sphere_rad": "bn_min['bn_index01.L']*1.0", "sphere_co": "bn_head['bn_index01.L']-bn_diry['bn_index01.L']*0.04"},
	{"anchor": "bn_hand.R", "sphere_rad": "bn_min['bn_index01.R']*1.0", "sphere_co": "bn_head['bn_index01.R']-bn_diry['bn_index01.R']*0.04"},
	{"anchor": "bn_hand.L", "sphere_rad": "bn_min['bn_middle01.L']*1.0", "sphere_co": "bn_head['bn_middle01.L']-bn_diry['bn_middle01.L']*0.04"},
	{"anchor": "bn_hand.R", "sphere_rad": "bn_min['bn_middle01.R']*1.0", "sphere_co": "bn_head['bn_middle01.R']-bn_diry['bn_middle01.R']*0.04"},
	{"anchor": "bn_hand.L", "sphere_rad": "bn_min['bn_ring01.L']*1.0", "sphere_co": "bn_head['bn_ring01.L']-bn_diry['bn_ring01.L']*0.04"},
	{"anchor": "bn_hand.R", "sphere_rad": "bn_min['bn_ring01.R']*1.0", "sphere_co": "bn_head['bn_ring01.R']-bn_diry['bn_ring01.R']*0.04"},
	{"anchor": "bn_hand.L", "sphere_rad": "bn_min['bn_pinky01.L']*1.0", "sphere_co": "bn_head['bn_pinky01.L']-bn_diry['bn_pinky01.L']*0.04"},
	{"anchor": "bn_hand.R", "sphere_rad": "bn_min['bn_pinky01.R']*1.0", "sphere_co": "bn_head['bn_pinky01.R']-bn_diry['bn_pinky01.R']*0.04"},
	
	# пальцы
	# {"anchor": "bn_pinky01.L", "sphere_rad": "bn_min['bn_pinky01.L']*1.0", "sphere_co": "bn_tail['bn_pinky01.L']"},
	# {"anchor": "bn_pinky02.L", "sphere_rad": "bn_min['bn_pinky02.L']*1.0", "sphere_co": "bn_tail['bn_pinky02.L']"},
	# {"anchor": "bn_ring01.L", "sphere_rad": "bn_min['bn_ring01.L']*1.0", "sphere_co": "bn_tail['bn_ring01.L']"},
	# {"anchor": "bn_ring02.L", "sphere_rad": "bn_min['bn_ring02.L']*1.0", "sphere_co": "bn_tail['bn_ring02.L']"},
	# {"anchor": "bn_middle01.L", "sphere_rad": "bn_min['bn_middle01.L']*1.0", "sphere_co": "bn_tail['bn_middle01.L']"},
	# {"anchor": "bn_middle02.L", "sphere_rad": "bn_min['bn_middle02.L']*1.0", "sphere_co": "bn_tail['bn_middle02.L']"},
	# {"anchor": "bn_index01.L", "sphere_rad": "bn_min['bn_index01.L']*1.0", "sphere_co": "bn_tail['bn_index01.L']"},
	# {"anchor": "bn_index02.L", "sphere_rad": "bn_min['bn_index02.L']*1.0", "sphere_co": "bn_tail['bn_index02.L']"},
	# {"anchor": "bn_pinky01.R", "sphere_rad": "bn_min['bn_pinky01.R']*1.0", "sphere_co": "bn_tail['bn_pinky01.R']"},
	# {"anchor": "bn_pinky02.R", "sphere_rad": "bn_min['bn_pinky02.R']*1.0", "sphere_co": "bn_tail['bn_pinky02.R']"},
	# {"anchor": "bn_ring01.R", "sphere_rad": "bn_min['bn_ring01.R']*1.0", "sphere_co": "bn_tail['bn_ring01.R']"},
	# {"anchor": "bn_ring02.R", "sphere_rad": "bn_min['bn_ring02.R']*1.0", "sphere_co": "bn_tail['bn_ring02.R']"},
	# {"anchor": "bn_middle01.R", "sphere_rad": "bn_min['bn_middle01.R']*1.0", "sphere_co": "bn_tail['bn_middle01.R']"},
	# {"anchor": "bn_middle02.R", "sphere_rad": "bn_min['bn_middle02.R']*1.0", "sphere_co": "bn_tail['bn_middle02.R']"},
	# {"anchor": "bn_index01.R", "sphere_rad": "bn_min['bn_index01.R']*1.0", "sphere_co": "bn_tail['bn_index01.R']"},
	# {"anchor": "bn_index02.R", "sphere_rad": "bn_min['bn_index02.R']*1.0", "sphere_co": "bn_tail['bn_index02.R']"},
]

kWPLArmStickmanBnsConvexes_MLOW_LITE = [
	{"anchor": "bn_spine05", "s_verts": 0.35, "v_inset": 0.5, "anchor2": "bn_spine06"}, # neck
	{"anchor": "bn_spine03", "s_verts": 0.35, "v_inset": 0.8},
	{"anchor": "bn_spine04", "s_verts": 0.35, "v_inset": 0.5},
	{"anchor": "bn_spine01", "s_verts": 0.35, "v_inset": 0.4},
	{"anchor": "bn_spine02", "s_verts": 0.35, "v_inset": 0.4},
	{"anchor": "bn_breast.L", "s_verts": 0.35, "v_inset": 0.7},{"anchor": "bn_breast.R", "s_verts": 0.35, "v_inset": 0.7},

	{"anchor": "bn_shoulder.L", "s_verts": 0.55, "v_inset": 0.98},{"anchor": "bn_shoulder.R", "s_verts": 0.55, "v_inset": 0.98},
	{"anchor": "bn_shoulder.L", "s_verts": "bn_weightIn(v_idx,'bn_upperarm01.L', 0.4, 1.0) and bn_weightIn(v_idx,'bn_shoulder.L', 0.075, 0.25)"},
	{"anchor": "bn_shoulder.R", "s_verts": "bn_weightIn(v_idx,'bn_upperarm01.R', 0.4, 1.0) and bn_weightIn(v_idx,'bn_shoulder.R', 0.075, 0.25)"},

	{"anchor": "bn_upperarm02.R", "s_verts": 0.35, "v_inset": 0.5, "anchor2": "bn_upperarm01.R"},{"anchor": "bn_upperarm02.L", "s_verts": 0.35, "v_inset": 0.5, "anchor2": "bn_upperarm01.L"},
	{"anchor": "bn_forearm02.R", "s_verts": 0.35, "v_inset": 0.4, "anchor2": "bn_forearm01.R"},{"anchor": "bn_forearm02.L", "s_verts": 0.35, "v_inset": 0.4, "anchor2": "bn_forearm01.L"},
	{"anchor": "bn_pelvis.L", "s_verts": 0.35, "v_inset": 0.3},{"anchor": "bn_pelvis.R", "s_verts": 0.35, "v_inset": 0.3},

	{"anchor": "bn_thigh01.L", "s_verts": "bn_weightIn(v_idx,'bn_thigh02.L', 0.2, 1.0) and bn_weightIn(v_idx,'bn_shin01.L', 0.15, 1.0)"},
	{"anchor": "bn_thigh01.R", "s_verts": "bn_weightIn(v_idx,'bn_thigh02.R', 0.2, 1.0) and bn_weightIn(v_idx,'bn_shin01.R', 0.15, 1.0)"},
	{"anchor": "bn_thigh01.R", "s_verts": 0.35, "v_inset": 0.5},{"anchor": "bn_thigh01.L", "s_verts": 0.35, "v_inset": 0.5},
	{"anchor": "bn_thigh02.R", "s_verts": 0.35, "v_inset": 0.3},{"anchor": "bn_thigh02.L", "s_verts": 0.35, "v_inset": 0.3},
	{"anchor": "bn_shin01.R", "s_verts": 0.35, "v_inset": 0.3},{"anchor": "bn_shin01.L", "s_verts": 0.35, "v_inset": 0.3},
	{"anchor": "bn_shin02.R", "s_verts": 0.35, "v_inset": 0.5},{"anchor": "bn_shin02.L", "s_verts": 0.35, "v_inset": 0.5},
	
	{"anchor": "bn_foot.R", "s_verts": 0.35, "v_inset": 0.85},{"anchor": "bn_foot.L", "s_verts": 0.35, "v_inset": 0.85},
	{"anchor": "bn_toe.R", "s_verts": 0.35, "v_inset": 0.85},{"anchor": "bn_toe.L", "s_verts": 0.35, "v_inset": 0.85},
	{"anchor": "bn_hand.R", "s_verts": 0.85, "v_inset": 0.75},{"anchor": "bn_hand.L", "s_verts": 0.85, "v_inset": 0.75},
]

kWPLArmStickmanBnsConvexes_MLOW_FULL = [
	{"anchor": "bn_spine05", "s_verts": 0.25, "v_inset": 0.8, "anchor2": "bn_spine06"}, # neck

	{"anchor": "bn_spine03", "s_verts": 0.5, "v_inset": 0.8},
	{"anchor": "bn_spine04", "s_verts": 0.5, "v_inset": 0.8},
	{"anchor": "bn_spine04", "s_verts": "bn_weightIn(v_idx,'bn_spine04', 0.3, 0.5) and bn_weightIn(v_idx,'bn_spine03', 0.10, 0.7) and bn_weightIn(v_idx,'bn_breast.L', 0.0, 0.1) and bn_weightIn(v_idx,'bn_breast.R', 0.0, 0.1)", "v_inset":"v_co*0.95+bn_head['bn_spine04']*0.05"},

	{"anchor": "bn_spine01", "s_verts": 0.25, "v_inset": 0.8},
	{"anchor": "bn_spine02", "s_verts": 0.25, "v_inset": 0.8},
	{"anchor": "bn_breast.L", "s_verts": 0.35, "v_inset": 0.95},{"anchor": "bn_breast.R", "s_verts": 0.35, "v_inset": 0.95},

	{"anchor": "bn_shoulder.L", "s_verts": 0.3, "v_inset": 0.5},
	{"anchor": "bn_shoulder.L", "s_verts": "bn_weightIn(v_idx,'bn_upperarm01.L', 0.4, 1.0) and bn_weightIn(v_idx,'bn_shoulder.L', 0.075, 0.25)"},
	{"anchor": "bn_shoulder.R", "s_verts": 0.3, "v_inset": 0.5},
	{"anchor": "bn_shoulder.R", "s_verts": "bn_weightIn(v_idx,'bn_upperarm01.R', 0.4, 1.0) and bn_weightIn(v_idx,'bn_shoulder.R', 0.075, 0.25)"},

	{"anchor": "bn_upperarm02.R", "s_verts": 0.5, "v_inset": 0.8, "anchor2": "bn_upperarm01.R"},{"anchor": "bn_upperarm02.L", "s_verts": 0.5, "v_inset": 0.8, "anchor2": "bn_upperarm01.L"},
	{"anchor": "bn_forearm02.R", "s_verts": 0.35, "v_inset": 0.8, "anchor2": "bn_forearm01.R"},{"anchor": "bn_forearm02.L", "s_verts": 0.35, "v_inset": 0.8, "anchor2": "bn_forearm01.L"},

	{"anchor": "bn_pelvis.L", "s_verts": 0.35, "v_inset": 0.3},{"anchor": "bn_pelvis.R", "s_verts": 0.35, "v_inset": 0.3},

	{"anchor": "bn_thigh01.L", "s_verts": "bn_weightIn(v_idx,'bn_thigh02.L', 0.2, 1.0) and bn_weightIn(v_idx,'bn_shin01.L', 0.15, 1.0)"},
	{"anchor": "bn_thigh01.R", "s_verts": "bn_weightIn(v_idx,'bn_thigh02.R', 0.2, 1.0) and bn_weightIn(v_idx,'bn_shin01.R', 0.15, 1.0)"},
	{"anchor": "bn_thigh01.R", "s_verts": 0.35, "v_inset": 0.8, "anchor2": "bn_thigh02.R"},{"anchor": "bn_thigh01.L", "s_verts": 0.35, "v_inset": 0.8, "anchor2": "bn_thigh02.L"},
	{"anchor": "bn_shin01.R", "s_verts": 0.75, "v_inset": 0.8, "anchor2": "bn_shin02.R"},{"anchor": "bn_shin01.L", "s_verts": 0.75, "v_inset": 0.8, "anchor2": "bn_shin02.L"},

	{"anchor": "bn_foot.R", "s_verts": 0.35, "v_inset": 0.85},{"anchor": "bn_foot.L", "s_verts": 0.35, "v_inset": 0.85},
	{"anchor": "bn_toe.R", "s_verts": 0.35, "v_inset": 0.85},{"anchor": "bn_toe.L", "s_verts": 0.35, "v_inset": 0.85},
	{"anchor": "bn_hand.R", "s_verts": 0.35, "v_inset": 0.75},{"anchor": "bn_hand.L", "s_verts": 0.35, "v_inset": 0.75},
	
	{"anchor": "bn_thumb01.L", "s_verts": 0.35, "v_inset": 0.75},{"anchor": "bn_thumb02.L", "s_verts": 0.35, "v_inset": 0.75},{"anchor": "bn_thumb03.L", "s_verts": 0.35, "v_inset": 0.75},
	{"anchor": "bn_thumb01.R", "s_verts": 0.35, "v_inset": 0.75},{"anchor": "bn_thumb02.R", "s_verts": 0.35, "v_inset": 0.75},{"anchor": "bn_thumb03.R", "s_verts": 0.35, "v_inset": 0.75},
	{"anchor": "bn_index01.L", "s_verts": 0.35, "v_inset": 0.75},{"anchor": "bn_index02.L", "s_verts": 0.35, "v_inset": 0.75},{"anchor": "bn_index03.L", "s_verts": 0.35, "v_inset": 0.75},
	{"anchor": "bn_index01.R", "s_verts": 0.35, "v_inset": 0.75},{"anchor": "bn_index02.R", "s_verts": 0.35, "v_inset": 0.75},{"anchor": "bn_index03.R", "s_verts": 0.35, "v_inset": 0.75},
	{"anchor": "bn_middle01.L", "s_verts": 0.35, "v_inset": 0.75},{"anchor": "bn_middle02.L", "s_verts": 0.35, "v_inset": 0.75},{"anchor": "bn_middle03.L", "s_verts": 0.35, "v_inset": 0.75},
	{"anchor": "bn_middle01.R", "s_verts": 0.35, "v_inset": 0.75},{"anchor": "bn_middle02.R", "s_verts": 0.35, "v_inset": 0.75},{"anchor": "bn_middle03.R", "s_verts": 0.35, "v_inset": 0.75},
	{"anchor": "bn_ring01.L", "s_verts": 0.35, "v_inset": 0.75},{"anchor": "bn_ring02.L", "s_verts": 0.35, "v_inset": 0.75},{"anchor": "bn_ring03.L", "s_verts": 0.35, "v_inset": 0.75},
	{"anchor": "bn_ring01.R", "s_verts": 0.35, "v_inset": 0.75},{"anchor": "bn_ring02.R", "s_verts": 0.35, "v_inset": 0.75},{"anchor": "bn_ring03.R", "s_verts": 0.35, "v_inset": 0.75},
	{"anchor": "bn_pinky01.L", "s_verts": 0.35, "v_inset": 0.75},{"anchor": "bn_pinky02.L", "s_verts": 0.35, "v_inset": 0.75},{"anchor": "bn_pinky03.L", "s_verts": 0.35, "v_inset": 0.75},
	{"anchor": "bn_pinky01.R", "s_verts": 0.35, "v_inset": 0.75},{"anchor": "bn_pinky02.R", "s_verts": 0.35, "v_inset": 0.75},{"anchor": "bn_pinky03.R", "s_verts": 0.35, "v_inset": 0.75},
]

# autosegmentation
kWPLArmSegmenterBns_MLOW = 'bn_breast.L, bn_breast.R, bn_spine05+bn_spine06:e1, bn_shoulder.L, bn_shoulder.R'
kWPLArmSegmenterBns_MLOW = kWPLArmSegmenterBns_MLOW+', bn_forearm01.L+bn_forearm02.L+bn_hand.L'
kWPLArmSegmenterBns_MLOW = kWPLArmSegmenterBns_MLOW+', bn_forearm01.R+bn_forearm02.R+bn_hand.R'
kWPLArmSegmenterBns_MLOW = kWPLArmSegmenterBns_MLOW+', bn_upperarm01.L+bn_upperarm02.L:e2'
kWPLArmSegmenterBns_MLOW = kWPLArmSegmenterBns_MLOW+', bn_upperarm01.R+bn_upperarm02.R:e2'
kWPLArmSegmenterBns_MLOW = kWPLArmSegmenterBns_MLOW+', bn_pelvis.L+bn_thigh01.L+bn_thigh02.L'
kWPLArmSegmenterBns_MLOW = kWPLArmSegmenterBns_MLOW+', bn_pelvis.R+bn_thigh01.R+bn_thigh02.R'
kWPLArmSegmenterBns_MLOW = kWPLArmSegmenterBns_MLOW+', bn_shin01.L+bn_shin02.L:e1, bn_foot.L+bn_toe.L'
kWPLArmSegmenterBns_MLOW = kWPLArmSegmenterBns_MLOW+', bn_shin01.R+bn_shin02.R:e1, bn_foot.R+bn_toe.R'
kWPLArmSegmenterBns_MLOW = kWPLArmSegmenterBns_MLOW+', bn_spine01+bn_spine02+bn_spine03+bn_spine04:e2'
kWPLArmSegmenterBns_MLOW = kWPLArmSegmenterBns_MLOW+', bn_thumb01.L+bn_thumb02.L+bn_thumb03.L:e2+any, bn_middle01.L+bn_middle02.L+bn_middle03.L:e1+any, bn_index01.L+bn_index02.L+bn_index03.L:e1+any, bn_pinky01.L+bn_pinky02.L+bn_pinky03.L:e1+any, bn_ring01.L+bn_ring02.L+bn_ring03.L:e1+any'
kWPLArmSegmenterBns_MLOW = kWPLArmSegmenterBns_MLOW+', bn_thumb01.R+bn_thumb02.R+bn_thumb03.R:e2+any, bn_middle01.R+bn_middle02.R+bn_middle03.R:e1+any, bn_index01.R+bn_index02.R+bn_index03.R:e1+any, bn_pinky01.R+bn_pinky02.R+bn_pinky03.R:e1+any, bn_ring01.R+bn_ring02.R+bn_ring03.R:e1+any'

# armature rescale
kWPLArmaRescaleTemp = "zzz_tempRig"
kWPLArmRescaleMapHint_MLOW = {
	#'ctrl-root': 'bn_spine01<', 'rig-properties': 'bn_head>',
	'ctrl-root': '-', 'rig-properties': '-',
	'ctrl-breast<': 'bn_breast??<', 'ctrl-breast>': 'bn_breast??>', # or tails will be matched wrong - there is a shift...
	'ctrl-elbow': 'bn_upperarm02??>', 'IK_elbow_parent': 'bn_upperarm02??>',
	'thigh_parent_socket': 'bn_thigh01??<',
	'ctrl-knee': 'bn_thigh02??>', 'MCH-knee_parent': 'bn_thigh02??>', 
	'MCH-heel01': 'bn_foot??<', 'ORG-heel01': 'bn_foot??<'
}
kWPLArmRescaleNoStretchFox_MLOW = "VIS-"
kWPLArmRescaleDebugging = False
kWPLArmRescaleEpsilon = 0.001

kWPLGKey_StickmanRefObj = "StickmanRefObj"

# kWPLAutoSetupCustomProp
# kWPLAutoSetupMouthCSC = "#faceMouthCurveScale"
# kWPLAutoSetupMouthLSC = "#faceMouthLipsScale"
# kWPLAutoSetupMouthDNC = "#faceMouthDnCurve"
# kWPLAutoSetupMouthUPC = "#faceMouthUpCurve"
# kWPLAutoSetupEyesRings = "#faceEyesPieIrisRings"

# kWPLArmSelHandsBns_MB = 'hand,pinky,ring,middle,index,thumb'
# kWPLArmSelHandsBns_MLOW = 'hand,pinky,ring,middle,index,thumb'
# kWPLArmShowIKBns_MB = 'IK_,root'
# kWPLArmShowDFBns_MB = 'breast, neck, clavicle, pelvis, spine, upperarm, lowerarm, thigh, calf, foot, thumb, pinky, ring, middle, index'
# kWPLArmShowIKBns_MLOW = 'ctrl-,properties'
# kWPLArmShowDFBns_MLOW = 'bn_'

def bone_fuzzyKey(bn_name):
	boneNameDgs = ""
	if "_master" in bn_name:
		boneNameDgs = "_master"
	else:
		boneNameDgs = ''.join(filter(lambda x: x.isdigit(), bn_name))
	boneNamePrim = ""
	if len(boneNameDgs) > 0 and boneNameDgs in bn_name:
		boneNamePrim = bn_name[:bn_name.index(boneNameDgs)]
	return boneNameDgs, boneNamePrim

# ==========================================
class wplpose_ar_toggle(bpy.types.Operator):
	bl_idname = "object.wplpose_ar_toggle"
	bl_label = "Toggle bone stuff"
	bl_options = {'REGISTER', 'UNDO'}

	opt_postAction : EnumProperty(
		name="Action", default="XRAY",
		items=(
			("POSE_ON_REST", "Rest On", ""), ("POSE_ON", "Rest Off", "")
			, ("XRAY", "X-Ray", "")
			, ("SCLINH_ON", "SCLINH_ON", ""), ("SCLINH_OFF", "SCLINH_OFF", "")
			, ("MOVLOC_OFF", "MOVLOC_OFF", ""), ("MOVLOC_ON", "MOVLOC_ON", "")
			, ("ROTINH_OFF", "ROTINH_OFF", ""), ("ROTINH_ON", "ROTINH_ON", "")
			, ("CONSTRS_OFF", "CONSTRS_OFF", ""), ("CONSTRS_ON", "CONSTRS_ON", "")
			, ("POSE_OFF", "POSE_OFF", ""))
	)

	opt_nameTok : StringProperty(
		name="Names",
		default = "<sel>"
	)

	def execute( self, context ):
		active_obj = wla.active_object()
		armatr = wla_arma.related_arma(active_obj)
		if armatr is None:
			self.report({'ERROR'}, "Works on Armature only")
			return {'CANCELLED'}
		wla_do.ensure_visible(armatr, 2)
		okCnt = 0
		if self.opt_postAction == "POSE_OFF":
			okCnt = okCnt+1
			bpy.context.scene.tool_settings.transform_pivot_point = 'MEDIAN_POINT'
			if armatr.parent is not None:
				wla_do.select_and_change_mode(armatr.parent, "OBJECT")
			else:
				wla_do.select_and_change_mode(armatr, "OBJECT")
		if self.opt_postAction == "POSE_ON_REST" or self.opt_postAction == "POSE_ON":
			okCnt = okCnt+1
			bpy.context.scene.tool_settings.transform_pivot_point = 'INDIVIDUAL_ORIGINS'
			if self.opt_postAction == "POSE_ON":
				armatr.data.pose_position = 'POSE'
				self.report({'INFO'}, "Armature in POSE mode")
				wla_do.select_and_change_mode(armatr,'POSE')
			else:
				armatr.data.pose_position = 'REST'
				self.report({'INFO'}, "Armature in REST mode")
				wla_do.select_and_change_mode(armatr,'OBJECT')
		if self.opt_postAction == "XRAY":
			okCnt = okCnt+1
			armatr.show_in_front = not armatr.show_in_front
		if self.opt_postAction == "CONSTRS_ON" or self.opt_postAction == "CONSTRS_OFF":
			wla_do.select_and_change_mode(armatr,"POSE")
			bpy.ops.pose.visual_transform_apply()
			isGetStats = False
			nameTok = self.opt_nameTok
			if self.opt_nameTok == "?":
				nameTok = "*"
				isGetStats = True
			selbones = wla_arma.arm_bonenames_tok(armatr, nameTok)
			for boneName in selbones:
				pbone = armatr.pose.bones[boneName]
				if len(pbone.constraints) > 0:
					okCnt = okCnt+1
					constrs = []
					for constr in pbone.constraints:
						constrs.append(constr)
					for constr in constrs:
						isMuteDriven = False
						drpaths = wla_arma.is_bone_driven_paths(armatr, pbone.name)
						for drv in drpaths:
							if (constr.name in drv) and (".mute" in drv):
								isMuteDriven = True
						if isGetStats and constr.mute:
							print("- "+boneName, "|", constr.name, constr.mute, isMuteDriven)
							continue
						#if self.opt_postAction == "CLEAR":
						#	pbone.constraints.remove(constr)
						if self.opt_postAction == "CONSTRS_OFF":
							if constr.mute != True:
								print("-", boneName, "|", constr.name, "-> Mute now True")
								if isMuteDriven:
									print("// WARN: driven path", constr.name, drpaths)
							constr.mute = True
						if self.opt_postAction == "CONSTRS_ON":
							if constr.mute != False:
								print("-", boneName, "|", constr.name, "-> Mute now False")
								if isMuteDriven:
									print("// WARN: driven path", constr.name, drpaths)
							constr.mute = False
		if self.opt_postAction == "ROTINH_ON" or self.opt_postAction == "ROTINH_OFF":
			wla_do.select_and_change_mode(armatr,"POSE")
			bpy.ops.pose.visual_transform_apply()
			selbones = wla_arma.arm_bonenames_tok(armatr, self.opt_nameTok)
			for boneName in selbones:
				okCnt = okCnt+1
				pbone = armatr.pose.bones[boneName]
				if self.opt_postAction == "ROTINH_ON":
					pbone.use_inherit_rotation = True
				if self.opt_postAction == "ROTINH_OFF":
					pbone.use_inherit_rotation = False
		if self.opt_postAction == "SCLINH_ON" or self.opt_postAction == "SCLINH_OFF":
			wla_do.select_and_change_mode(armatr,"POSE")
			bpy.ops.pose.visual_transform_apply()
			selbones = wla_arma.arm_bonenames_tok(armatr, self.opt_nameTok)
			for boneName in selbones:
				okCnt = okCnt+1
				pbone = armatr.pose.bones[boneName]
				if self.opt_postAction == "SCLINH_ON":
					pbone.use_inherit_scale = True
				if self.opt_postAction == "SCLINH_OFF":
					pbone.use_inherit_scale = False
		if self.opt_postAction == "MOVLOC_ON" or self.opt_postAction == "MOVLOC_OFF":
			wla_do.select_and_change_mode(armatr,"POSE")
			bpy.ops.pose.visual_transform_apply()
			selbones = wla_arma.arm_bonenames_tok(armatr, self.opt_nameTok)
			for boneName in selbones:
				okCnt = okCnt+1
				pbone = armatr.pose.bones[boneName]
				if self.opt_postAction == "MOVLOC_ON":
					pbone.lock_location = (True, True, True)
				if self.opt_postAction == "MOVLOC_OFF":
					pbone.lock_location = (False, False, False)
		self.report({'INFO'}, "Handled "+str(okCnt)+" bones")
		return {'FINISHED'}

class wplpose_bn_copypaste(bpy.types.Operator):
	bl_idname = "object.wplpose_bn_copypaste"
	bl_label = "Copy-paste rotations"
	bl_options = {'REGISTER', 'UNDO'}

	opt_mode : EnumProperty(
		name="Mode",
		items=(("COPY", "Copy", ""), ("PASTE", "Paste indirect", ""), ("PASTEALL", "Paste ALL", ""), ("PASTESEL", "Paste SEL", "")),
		default="COPY"
	)
	opt_influence : FloatProperty(
		name="Influence",
		min=0.0, max=1.0,
		default=1.0,
	)
	opt_autoFuzzy : BoolProperty(
		name="Fuzzy matching",
		default=True
	)
	opt_autoMirror : BoolProperty(
		name="With mirroring",
		default=False
	)
	opt_ignoreHidden : BoolProperty(
		name="Ignore hidden bones",
		default=True
	)
	opt_doRotation : BoolProperty(
		name="Paste rotation",
		default=True
	)
	opt_doScale : BoolProperty(
		name="Paste scale",
		default=True
	)
	opt_doLocation : BoolProperty(
		name="Paste Location",
		default=True
	)
	def execute( self, context ):
		active_obj = wla.active_object()
		armatr = wla_arma.related_arma(active_obj)
		if armatr is None:
			self.report({'ERROR'}, "Works on Armature only")
			return {'CANCELLED'}
		wla_do.ensure_visible(armatr, 2)
		wla_do.select_and_change_mode(armatr, 'POSE')
		okBones = 0
		if self.opt_mode == 'COPY':
			copyedBonesAll = {}
			boneNames = armatr.pose.bones.keys()
			for boneName in boneNames:
				bone = armatr.data.bones[boneName]
				pbone = armatr.pose.bones[boneName]
				# pbone.rotation_mode = "XYZ" # DBG RESTORE
				if pbone.rotation_mode == "QUATERNION":
					eul_new = pbone.rotation_quaternion.to_euler('XYZ')
				else:
					eul_new = pbone.rotation_euler
				copyedBonesAll[boneName] = {"rot_xyz": (eul_new[0], eul_new[1], eul_new[2]), "loc": copy.copy(pbone.location), "scl": copy.copy(pbone.scale), "sel": bone.select}
				if bone.select:
					okBones = okBones+1
			config.WPL_G.store["wplpose_ccpy"] = copyedBonesAll
		infl = self.opt_influence
		if self.opt_mode == 'PASTEALL' or self.opt_mode == 'PASTESEL':
			if "wplpose_ccpy" not in config.WPL_G.store:
				self.report({'ERROR'}, "Nothing copied")
				return {'FINISHED'}
			copyedBonesAll = config.WPL_G.store["wplpose_ccpy"]
			boneNames = armatr.pose.bones.keys()
			for boneName in boneNames:
				abone = armatr.data.bones[boneName]
				pbone = armatr.pose.bones[boneName]
				if boneName not in copyedBonesAll:
					continue
				if self.opt_mode == 'PASTESEL' and abone.select == False:
					continue
				okBones = okBones+1
				eul_new = copyedBonesAll[boneName]["rot_xyz"]
				scl_new = copyedBonesAll[boneName]["scl"]
				loc_new = copyedBonesAll[boneName]["loc"]
				if self.opt_doRotation:
					if pbone.rotation_mode == "QUATERNION":
						eul_prev = pbone.rotation_quaternion.to_euler('XYZ')
					else:
						eul_prev = pbone.rotation_euler
					newX = eul_prev[0]*(1.0-infl)+eul_new[0]*infl
					newY = eul_prev[1]*(1.0-infl)+eul_new[1]*infl
					newZ = eul_prev[2]*(1.0-infl)+eul_new[2]*infl
					eul_new = mathutils.Euler((newX,newY,newZ), 'XYZ')
					pbone.rotation_quaternion = eul_new.to_quaternion()
					pbone.rotation_euler = eul_new
				if self.opt_doScale:
					scl_prev = pbone.scale
					scl_new = Vector(scl_prev).lerp(scl_new, infl)
					pbone.scale = (scl_new[0], scl_new[1], scl_new[2])
				if self.opt_doLocation:
					loc_prev = pbone.location
					loc_new = Vector(loc_prev).lerp(loc_new, infl)
					pbone.location = loc_new
		if self.opt_mode == 'PASTE':
			if "wplpose_ccpy" not in config.WPL_G.store:
				self.report({'ERROR'}, "Nothing copied")
				return {'FINISHED'}
			copyedBonesAll = config.WPL_G.store["wplpose_ccpy"]
			copyedNames = []
			for key in copyedBonesAll:
				if copyedBonesAll[key]["sel"]:
					copyedNames.append(key)
			copyedNames = sorted(copyedNames)
			#print("- copyedNames", copyedNames)
			boneNames = armatr.pose.bones.keys()
			for boneName in boneNames:
				bone = armatr.data.bones[boneName]
				if bone.select:
					pbone = armatr.pose.bones[boneName]
					if self.opt_ignoreHidden and wla_arma.is_posebone_hidden(armatr, pbone):
						# print("- posebone is hidden", pbone.name)
						continue
					new_rot_name = None
					if (new_rot_name is None) and (boneName in copyedNames):
						new_rot_name = boneName
					if self.opt_autoMirror:
						if (new_rot_name is None) and (".L" in boneName):
							mirr = boneName.replace(".L",".R")
							if mirr in copyedNames:
								new_rot_name = mirr
						if (new_rot_name is None) and (".R" in boneName):
							mirr = boneName.replace(".R",".L")
							if mirr in copyedNames:
								new_rot_name = mirr
					if new_rot_name is None and self.opt_autoFuzzy:
						# fuzzy search
						posiibles = []
						fuzzKey,fuzzPrim = bone_fuzzyKey(boneName)
						if len(fuzzKey) > 0:
							for cpn in copyedNames:
								cpn_fuzzKey,_ = bone_fuzzyKey(cpn)
								#print("//",cpn,cpn_fuzzKey,"vs",fuzzKey)
								if fuzzKey == cpn_fuzzKey:
									posiibles.append(cpn)
							if len(posiibles) > 1 and len(fuzzPrim) > 0:
								print("- too much, narrowing", posiibles)
								# selecting by same prim
								posiibles2 = posiibles
								posiibles = []
								for cpn in posiibles2:
									cpn_fuzzKey, cpn_fuzzPrim = bone_fuzzyKey(cpn)
									if cpn_fuzzPrim == fuzzPrim:
										posiibles.append(cpn)
										break
						if len(posiibles) > 0:
							new_rot_name = posiibles[0]
					if new_rot_name is not None:
						eul_new = copyedBonesAll[new_rot_name]["rot_xyz"]
						scl_new = copyedBonesAll[new_rot_name]["scl"]
						loc_new = copyedBonesAll[new_rot_name]["loc"]
						okBones = okBones+1
						print("- pasting",new_rot_name, '->', boneName, math.degrees(eul_new[0]), math.degrees(eul_new[1]), math.degrees(eul_new[2]))
						if self.opt_doRotation:
							if pbone.rotation_mode == "QUATERNION":
								eul_prev = pbone.rotation_quaternion.to_euler('XYZ')
							else:
								eul_prev = pbone.rotation_euler
							newX = eul_prev[0]*(1.0-infl)+eul_new[0]*infl
							newY = eul_prev[1]*(1.0-infl)+eul_new[1]*infl
							newZ = eul_prev[2]*(1.0-infl)+eul_new[2]*infl
							eul_new = mathutils.Euler((newX,newY,newZ), 'XYZ')
							pbone.rotation_quaternion = eul_new.to_quaternion()
							pbone.rotation_euler = eul_new
						if self.opt_doScale:
							scl_prev = pbone.scale
							scl_new = Vector(scl_prev).lerp(scl_new, infl)
							pbone.scale = (scl_new[0], scl_new[1], scl_new[2])
						if self.opt_doLocation:
							loc_prev = pbone.location
							loc_new = Vector(loc_prev).lerp(loc_new, infl)
							pbone.location = (loc_new[0], loc_new[1], loc_new[2])
					else:
						print("- no match for",pbone.name)
		self.report({'INFO'}, "Handled "+str(okBones)+" bones")
		return {'FINISHED'}

class wplpose_bn_slide(bpy.types.Operator):
	bl_idname = "object.wplpose_bn_slide"
	bl_label = "Slide bones"
	bl_options = {'REGISTER', 'UNDO'}

	opt_rotats : FloatVectorProperty(
		name = "Rotation X-Y-Z",
		size = 3,
		step = 10,
		default = (0.0, 0.0, 0.0),
		description = "Euler rotation in Degrees"
	)
	opt_scales : FloatVectorProperty(
		name = "Scale X-Y-Z",
		size = 3,
		step = 10,
		default = (1.0, 1.0, 1.0)
	)
	opt_cuhFalloff : StringProperty(
		name="Dist falloff CUH",
		default="999",
		description = "Curve Hash (1-9)"
	)

	# Running as separate dialog
	def invoke(self, context, event):
		return context.window_manager.invoke_props_dialog(self, width = 200)

	def execute( self, context ):
		active_obj = wla.active_object()
		armatr = wla_arma.related_arma(active_obj)
		if armatr is None:
			self.report({'ERROR'}, "Works on Armature only")
			return {'CANCELLED'}
		wla_do.ensure_visible(armatr, 2)
		region, _ = wla.active_view_region()
		eo_dir2cam_g = (region.view_rotation @ Vector((0.0, 0.0, 1.0)))
		eo_dir2cam_l = armatr.matrix_world.inverted().to_3x3() @ eo_dir2cam_g
		boneNames = armatr.pose.bones.keys()
		okBones = 0
		minChain = 999
		maxChain = 0
		minDist = 999
		maxDist = 0
		curBones = []
		for boneName in boneNames:
			bone = armatr.data.bones[boneName]
			if bone.select:
				pbone = armatr.pose.bones[boneName]
				#pbone.rotation_mode = "YXZ"
				pbone.rotation_mode = "QUATERNION"
				pbone_chain = wla_arma.posebone_parentchain(pbone)
				deep1 = len(pbone_chain)
				minChain = min(minChain,deep1)
				maxChain = max(maxChain,deep1)
				dir2cam = (pbone.matrix @ Vector((0,0,0))-eo_dir2cam_l).length
				minDist = min(minDist,dir2cam)
				maxDist = max(maxDist,dir2cam)
				curBones.append((pbone, deep1, dir2cam))
				okBones = okBones+1
		curBones = sorted(curBones, key=lambda p:p[1])
		print("bn_pair",curBones,minDist,maxDist)
		for bn_pair in curBones:
			bn = bn_pair[0]
			infl = 1.0
			# if maxChain > minChain and self.opt_cuhFalloff>0.0:
				# fac = (bn_pair[1]-minChain)/(maxChain-minChain)
				# facStep = 1.0/(maxChain-minChain+1)
				# bn_w1 = facStep+(1.0-facStep)*fac
				# infl = pow(bn_w1,self.opt_cuhFalloff)
			if maxDist > minDist and len(self.opt_cuhFalloff) > 0:
				fac = (bn_pair[2]-minDist)/(maxDist-minDist)
				infl = wla.remap_curve_hash(self.opt_cuhFalloff, fac)
				# if self.opt_cuhFalloff<0:
				# 	fac = 1.0-fac
				# infl = pow(fac, abs(self.opt_cuhFalloff))
			eul_prev = bn.rotation_quaternion.to_euler('XYZ')
			newX = eul_prev[0]+math.radians(self.opt_rotats[0])*infl
			newY = eul_prev[1]+math.radians(self.opt_rotats[1])*infl
			newZ = eul_prev[2]+math.radians(self.opt_rotats[2])*infl
			eul_new = mathutils.Euler((newX,newY,newZ), 'XYZ')
			bn.rotation_euler = eul_new
			bn.rotation_quaternion = eul_new.to_quaternion()
			scal_prev = bn.scale
			scal_new = [scal_prev[0]*(1.0*(1.0-infl) + self.opt_scales[0]*infl), scal_prev[1]*(1.0*(1.0-infl) + self.opt_scales[1]*infl), scal_prev[2]*(1.0*(1.0-infl) + self.opt_scales[2]*infl) ]
			bn.scale = scal_new
		self.report({'INFO'}, "Handled "+str(okBones)+" bones")
		return {'FINISHED'}

class wplpose_armsegm(bpy.types.Operator):
	bl_idname = "object.wplpose_armsegm"
	bl_label = "Auto-segmentation"
	bl_options = {'REGISTER', 'UNDO'}

	def execute(self, context):
		sel_all = wla.selected_objects()
		sel_all = wla_arma.all_mesh_hiers(sel_all)
		active_obj = wla.active_object(['MESH'])
		if active_obj is None and len(sel_all)>0:
			active_obj = sel_all[0]
		armas = wla_arma.related_armas(sel_all)
		if len(armas) != 1:
			print("- related armatures: ambiguity", armas)
			self.report({'ERROR'}, "Armature not found or more that one")
			return {'CANCELLED'}
		armatr = armas[0]
		wla_do.select_and_change_mode(armatr, 'EDIT')
		all_deformBns = [b.name for b in armatr.data.edit_bones if b.use_deform]
		all_okBones = ops_prop_edging.bones_expandDescription(all_deformBns, kWPLArmSegmenterBns_MLOW)
		# print("- all_deformBns", all_deformBns, all_okBones)
		wla_do.select_and_change_mode(active_obj, 'OBJECT')
		for sel_obj in sel_all:
			bn_wcaches = {}
			usedBones = set()
			usedFaces = set()
			okZones = 0
			for bonesToks, bonesExtra in all_okBones:
				if len(bonesToks) == 0:
					# can be for missed bones - no Breast on MALE chars, for example
					continue
				boneName = bonesToks[0]
				bonesExtraStepOut = wla.safeFloat(bonesExtra, 0.0, "e")
				bonesExtraIsAll = True
				if "any" in bonesExtra:
					bonesExtraIsAll = False
				segmVerts = set()
				for bn in all_deformBns:
					if bn in usedBones:
						continue
					if (".L" in boneName) and (".L" not in bn):
						continue
					if (".R" in boneName) and (".R" not in bn):
						continue
					if wla.isTokenInStr(bonesToks, bn) == False:
						continue
					usedBones.add(bn)
					wscale1 = 0.1
					_, vertsIdx, _ = wla_attr.vg_get_verts( sel_obj, sel_obj.vertex_groups.get(bn), wscale1, bn_wcaches)
					segmVerts = segmVerts.union(set(vertsIdx))
				selfaces = wla_meshwrap.objectm_polygonsOfVerts(sel_obj, segmVerts, bonesExtraIsAll)
				selfaces = set(selfaces).difference(usedFaces)
				if len(selfaces) == 0:
					# skipping
					continue
				print("- adding segm", sel_obj.name, bonesToks, len(segmVerts), len(selfaces))
				if bonesExtraStepOut > 0:
					selfaces = wla_meshwrap.objectm_polygonsStepOut(int(bonesExtraStepOut), sel_obj, list(selfaces))
					# while bonesExtraStepOut > 0.0:
					# 	bonesExtraStepOut = bonesExtraStepOut-1
					# 	selfaces = wla_meshwrap.objectm_polygonsStepOut(sel_obj, list(selfaces))
					# 	#selfaces = set(selfaces).difference(usedFaces)
					print("// extended",len(selfaces))
				usedFaces = usedFaces.union(set(selfaces))
				mats_names = set()
				for fIdx in selfaces:
					fpoly = sel_obj.data.polygons[fIdx]
					if (fpoly.material_index not in mats_names) and fpoly.material_index < len(sel_obj.material_slots):
						slot = sel_obj.material_slots[fpoly.material_index]
						mats_names.add(slot.name)
				if len(mats_names) > 1:
					print("// skipping multimat segment", bonesToks, len(selfaces), mats_names)
					continue
				pastedfaces = wla_attr.mat_segmentFaces(sel_obj, list(selfaces))
				if pastedfaces > 0:
					okZones = okZones+1
			print("- obj done", sel_obj.name, okZones)
		#wla_do.select_and_change_mode(active_obj, 'OBJECT')
		wla_do.select_and_activate_multi(sel_all, active_obj)
		bpy.ops.object.wplheal_remunusdats()
		self.report({'INFO'}, "Handled "+str(len(sel_all))+" objects")
		return {'FINISHED'}


class wplpose_armskel(bpy.types.Operator):
	bl_idname = "object.wplpose_armskel"
	bl_label = "Add armature stickman"
	bl_options = {'REGISTER', 'UNDO'}
	
	opt_mode : EnumProperty(
		name="Mode",
		items=(("LITE", "Lite", ""), ("FULL", "Full", "")),
		default="LITE"
	)

	# def boneGeometry(self, l1, l2, x, z, baseSize, l1Size, l2Size ):#Create the bone geometry (vertices and faces)
	# 	start = l1 + (l2-l1) * 0.01
	# 	end = l2 - (l2-l1) * 0.2
	# 	x1 = x * baseSize * l1Size * 0.1
	# 	z1 = z * baseSize * l1Size * 0.1
	# 	x2 = x * baseSize * l2Size * 0.1
	# 	z2 = z * baseSize * l2Size * 0.1

	# 	verts = [
	# 		start - x1 + z1,
	# 		start + x1 + z1,
	# 		start - x1 - z1,
	# 		start + x1 - z1,
	# 		end - x2 + z2,
	# 		end + x2 + z2,
	# 		end - x2 - z2,
	# 		end + x2 - z2
	# 	] 
	# 	return verts
	def scaleCoToBone(self, editBone, verts_co, scaleFac):
		# if scaleFac<0:
		# 	wla_do.sys_dump_pythonobj(editBone)
		bn_head = editBone.head
		bn_tail = editBone.tail
		verts_coScaled = []
		maxDist = -999
		minDist = 999
		#avgDist = 0
		for v_co in verts_co:
			intresct = mathutils.geometry.intersect_point_line(v_co, bn_head, bn_tail)
			reldist = intresct[1]
			# if reldist > 1.0 or reldist < 0.0:
			# 	continue
			reldist = wla.math_clamp(reldist,0.0,1.0)
			relpos = bn_head+(bn_tail-bn_head)*reldist
			v_dist = (v_co-relpos).length
			maxDist = max(maxDist, v_dist)
			minDist = min(minDist, v_dist)
			#avgDist = avgDist+v_dist
			v_coS = relpos+(v_co-relpos)*abs(scaleFac)
			verts_coScaled.append(v_coS)
		#avgDist = (avgDist/(len(verts_coScaled)+0.001))
		return verts_coScaled, minDist, maxDist

	def execute(self, context):
		active_obj = wla.active_object(['MESH'])
		if active_obj is None:
			self.report({'ERROR'}, "Select mesh with armature")
			return {'CANCELLED'}
		# if wla.is_local_view():
		# 	self.report({'INFO'}, 'Can`t work in Local view')
		# 	return {"CANCELLED"}
		if wla.modf_by_type(active_obj,'MIRROR'):
			self.report({'INFO'}, 'MIRROR not allowed')
			return {"CANCELLED"}
		armatr = wla_arma.related_arma(active_obj)
		if armatr is None:
			self.report({'ERROR'}, "Armature not found")
			return {'CANCELLED'}
		armatr.data.pose_position = 'REST'
		config.WPL_G.store[kWPLGKey_StickmanRefObj] = active_obj.name
		# seam_vertsIdx # 4EVALs
		seam_vertsIdx, _ = wla_meshwrap.objectm_extractVertsByType(active_obj)
		all_vertsIdx = []
		for v in active_obj.data.vertices:
			all_vertsIdx.append(v.index)
		deform_verts, _ = wla_bm.bm_getDeformedCos(active_obj)
		prevStickman = wla.find_child_by_name(armatr, config.kWPLObjCharRefStickman, False)
		if prevStickman is not None and prevStickman.name == active_obj.name:
			self.report({'ERROR'}, "Select mesh with armature")
			return {'CANCELLED'}
		if prevStickman is not None:
			bpy.data.objects.remove(prevStickman, do_unlink=True)
		stickname = armatr.name + config.kWPLObjCharRefStickman # config.kWPLObjProtoToken[1] + 
		stickname = stickname.replace("_charr", "") # should not hide with armature
		print("- adding stickman",stickname)
		meshData = bpy.data.meshes.new( stickname + "_mesh" )
		meshObj = bpy.data.objects.new( stickname, meshData )
		wla_do.link_object_to_scene(meshObj, armatr)
		meshObj.matrix_world = active_obj.matrix_world.copy()
		meshObj.show_wire = True
		meshObj.show_all_edges = True
		#meshObj.display_type = 'WIRE'
		bm = bmesh.new()
		#Goes through each bone
		wla_do.select_and_change_mode(armatr, 'EDIT')
		all_deformBns = [b.name for b in armatr.data.edit_bones if b.use_deform]
		bn_max = {}
		bn_min = {}
		bn_len = {}
		bn_head = {}
		bn_tail = {}
		bn_dirx = {}
		bn_diry = {}
		bn_dirz = {}
		# bn_w = {} # same as bn_weightIn
		bn_wcaches = {}
		for boneName in all_deformBns:
			if (boneName not in armatr.data.edit_bones):
				# possible for Breasts on Male models, for example
				print("- skipping rule for bone", boneName)
				continue
			if (boneName not in bn_head):
				editBone1 = armatr.data.edit_bones[boneName]
				#newVertsAll, _, newVertsAllW = wla_attr.vg_get_verts( active_obj, active_obj.vertex_groups.get(boneName), 0.001, bn_wcaches)
				newVertsFullOnly, _, _ = wla_attr.vg_get_verts( active_obj, active_obj.vertex_groups.get(boneName), 0.4, bn_wcaches)
				_, vertMinDist, vertMaxDist = self.scaleCoToBone(editBone1, newVertsFullOnly, -1.0)
				bn_max[boneName] = vertMaxDist
				bn_min[boneName] = vertMinDist
				bn_len[boneName] = (editBone1.tail-editBone1.head).length
				bn_head[boneName] = editBone1.head
				bn_tail[boneName] = editBone1.tail
				bn_dirx[boneName] = editBone1.x_axis.normalized()
				bn_diry[boneName] = editBone1.y_axis.normalized()
				bn_dirz[boneName] = editBone1.z_axis.normalized()
				# for v_idx in all_vertsIdx:
				# 	if v_idx not in newVertsAllW:
				# 		newVertsAllW[v_idx] = 0.0
				# bn_w[boneName] = newVertsAllW # same as bn_weightIn
		usedVerts = {}
		def bn_weightGet(vIdx, bn_name): # 4EVALs
			_, _, bvw = wla_attr.vg_get_verts( active_obj, active_obj.vertex_groups.get(bn_name), 0.0, bn_wcaches)
			if vIdx in bvw:
				return bvw[vIdx]
			return 0.0
		def bn_weightIn(vIdx, bn_name, low_lim, hi_lim): # 4EVALs
			wei = bn_weightGet(vIdx, bn_name)
			if wei >= low_lim and wei <= hi_lim:
				return True
			return False
		# adding spherical stuff
		vertexGroups = {}
		vertexConvexAdds = {}
		for action in kWPLArmStickmanBnsSpheres_MLOW:
			bn_anchor = None
			if self.opt_mode == "FULL" and "anchor_f" in action:
				bn_anchor = action["anchor_f"]
			elif self.opt_mode == "LITE" and "anchor_l" in action:
				bn_anchor = action["anchor_f"]
			elif "anchor" in action:
				bn_anchor = action["anchor"]
			if bn_anchor is None:
				print("- broken rule", action)
				continue
			spheres = []
			if "sphere_rad" in action:
				# single sphere
				evalRad_val = -1.0
				evalPos_val = Vector((0,0,0))
				evalScale_val = Vector((1,1,1))
				try:
					evalRad_py = compile(action["sphere_rad"], "<string>", "eval")
					evalRad_val = eval(evalRad_py)
					evalPos_py = compile(action["sphere_co"], "<string>", "eval")
					evalPos_val = eval(evalPos_py)
					if "sphere_scale" in action:
						evalScale_py = compile(action["sphere_scale"], "<string>", "eval")
						evalScale_val = eval(evalScale_py)
						evalScale_val = Vector((evalScale_val[0],evalScale_val[1],evalScale_val[2]))
				except Exception as e:
					print("- eval error:", e, action)
					self.report({'ERROR'}, "Eval compilation: syntax error")
					return {'CANCELLED'}
				spheres.append( (evalPos_val, evalRad_val, evalScale_val, 3) )
			if "s_verts" in action:
				#seamLimWei = None
				evalSLW2_py = None
				evalSLC_py = None
				evalSLR_py = None
				try:
					evalSLW2_py = compile(action["s_verts"], "<string>", "eval")
					evalSLC_py = compile(action["convexadd_co"], "<string>", "eval")
					if "seamlim_rad" in action:
						evalSLR_py = compile(action["seamlim_rad"], "<string>", "eval")
				except Exception as e:
					print("- eval error:", e, action)
					self.report({'ERROR'}, "Eval compilation: syntax error")
					return {'CANCELLED'}
				# src_bn = bn_anchor
				# if "seamlim_src" in action:
				# 	src_bn = action["seamlim_src"]
				#if evalSLW2_py is not None:
				for v_idx in all_vertsIdx: # v_idx for evals
					evalSLW2_val = eval(evalSLW2_py)
					if evalSLW2_val != True:
						continue
					v = active_obj.data.vertices[v_idx]
					v_co = copy.copy(deform_verts[v.index]) # copy.copy(v.co)
					evalSLC_val = eval(evalSLC_py)
					evalSLR_val = 0
					if evalSLR_py is not None:
						evalSLR_val = eval(evalSLR_py)
					spheres.append( (evalSLC_val, evalSLR_val, Vector((1,1,1)), 1) )
			for sph in spheres:
				spherePos = sph[0]
				sphereRad = sph[1]
				sphereScale = sph[2]
				sphereSubd = sph[3]
				if sphereRad > 0.0:
					# print("- adding sphere", bn_anchor, sphereRad, spherePos)
					if bn_anchor not in vertexGroups:
						vertexGroups[bn_anchor] = []
					sphmatrScaleM =	Matrix().Scale(sphereScale[0], 4, Vector((1,0,0)))
					sphmatrScaleM = sphmatrScaleM @ Matrix().Scale(sphereScale[1], 4, Vector((0,1,0)))
					sphmatrScaleM = sphmatrScaleM @ Matrix().Scale(sphereScale[2], 4, Vector((0,0,1)))
					res2 = bmesh.ops.create_icosphere(bm, subdivisions=sphereSubd, radius=sphereRad, matrix=Matrix.Translation(spherePos) @ sphmatrScaleM, calc_uvs=False)
					bm.verts.ensure_lookup_table()
					bm.verts.index_update()
					for elem in res2["verts"]:
						if isinstance(elem, bmesh.types.BMVert):
							vertexGroups[bn_anchor].append((elem.index,1.0))
				else:
					# vertex go to bone convex
					if bn_anchor not in vertexConvexAdds:
						vertexConvexAdds[bn_anchor] = []
					vertexConvexAdds[bn_anchor].append(spherePos)
		# adding convex stuff
		conv_list = kWPLArmStickmanBnsConvexes_MLOW_LITE
		if self.opt_mode == 'FULL':
			conv_list = kWPLArmStickmanBnsConvexes_MLOW_FULL
		for action in conv_list:
			if "anchor" not in action:
				print("- skipping rule for action", action)
				continue
			boneName = action["anchor"]
			if (boneName not in armatr.data.edit_bones):
				# possible for Breasts on Male models, for example
				print("- skipping rule for bone", boneName)
				continue
			secndBone = None
			if "anchor2" in action:
				secndBone = action["anchor2"]
			editBone1 = armatr.data.edit_bones[boneName]
			print("- adding mesh for", boneName, secndBone)
			#Creates the mesh data for the bone
			newVertsCo = []
			weiLimit = action["s_verts"]
			allowConvexAppenders = True
			if isinstance(weiLimit, str):
				# python expression
				evalSLW2_py = None
				evalSLC_py = None
				try:
					evalSLW2_py = compile(action["s_verts"], "<string>", "eval")
					if "v_inset" in action:
						evalSLC_py = compile(action["v_inset"], "<string>", "eval")
				except Exception as e:
					print("- eval error:", e, action)
					self.report({'ERROR'}, "Eval compilation: syntax error")
					return {'CANCELLED'}
				for v_idx in all_vertsIdx: # v_idx for evals
					evalSLW2_val = eval(evalSLW2_py)
					if evalSLW2_val != True:
						continue
					v = active_obj.data.vertices[v_idx]
					v_co = copy.copy(deform_verts[v.index])
					if evalSLC_py is not None:
						v_co = eval(evalSLC_py)
					newVertsCo.append(v_co)
				allowConvexAppenders = False
			elif weiLimit > 0.0 and active_obj.vertex_groups.get(boneName) is not None:
				gscale = action["v_inset"]
				if gscale > 0.01:
					newVertsCo, _, _ = wla_attr.vg_get_verts( active_obj, active_obj.vertex_groups.get(boneName), weiLimit, bn_wcaches)
					newVertsCo, _, _ = self.scaleCoToBone(editBone1, newVertsCo, gscale)
					if (secndBone is not None) and active_obj.vertex_groups.get(secndBone) is not None:
						editBone2 = armatr.data.edit_bones[secndBone]
						newVertsCo2, _, _ = wla_attr.vg_get_verts( active_obj, active_obj.vertex_groups.get(secndBone), weiLimit, bn_wcaches)
						newVertsCo2, _, _ = self.scaleCoToBone(editBone2, newVertsCo2, gscale)
						newVertsCo = newVertsCo + newVertsCo2
			# if len(newVertsCo) == 0:
			# 	editBoneVector = editBone1.tail - editBone1.head
			# 	editBoneSize = editBoneVector.dot( editBoneVector )
			# 	editBoneRoll = editBone.roll
			# 	editBoneX = editBone.x_axis
			# 	editBoneZ = editBone.z_axis
			# 	editBoneHeadRadius = editBone.head_radius
			# 	editBoneTailRadius = editBone.tail_radius
			# 	baseSize = math.sqrt( editBoneSize )
			# 	newVerts = self.boneGeometry( editBone1.head, editBone1.tail, editBoneX, editBoneZ, baseSize, editBoneHeadRadius, editBoneTailRadius )
			if allowConvexAppenders:
				if boneName in vertexConvexAdds:
					newVertsCo = newVertsCo + vertexConvexAdds[boneName]
				if (secndBone is not None) and secndBone in vertexConvexAdds:
					newVertsCo = newVertsCo + vertexConvexAdds[secndBone]
			hullv = []
			if boneName not in vertexGroups:
				vertexGroups[boneName] = []
			for v_co in newVertsCo:
				coKey = wla.coToKey(v_co)
				#if coKey in usedVerts:
				#	continue
				usedVerts[coKey] = v_co
				bm2v = bm.verts.new(v_co)
				hullv.append(bm2v)
			if len(hullv) < 3:
				continue
			bm.verts.ensure_lookup_table()
			bm.verts.index_update()
			res = bmesh.ops.convex_hull(bm, input=hullv)
			bm.verts.ensure_lookup_table()
			bm.verts.index_update()
			for elem in res["geom"]:
				if isinstance(elem, bmesh.types.BMVert):
					vertexGroups[boneName].append((elem.index,1.0))
		# saving stickman mesh
		wla_do.select_and_change_mode(meshObj, 'OBJECT')
		bm.to_mesh(meshObj.data)
		#Assigns the vertex groups
		for name, vertexGroup in vertexGroups.items():
			groupObject = meshObj.vertex_groups.new(name = name)
			for (index, weight) in vertexGroup:
				groupObject.add([index], weight, 'REPLACE')
		wla_do.select_and_change_mode(meshObj, 'EDIT')
		bpy.ops.mesh.select_all(action='SELECT')
		bpy.ops.mesh.delete_loose()
		bpy.ops.mesh.select_all(action='SELECT')
		wla_do.select_and_change_mode(meshObj, 'OBJECT')
		wla_attr.vc_obj_ensure(meshObj, config.kWPLMeshColVC)
		facesSet = wla_attr.vc_obj_update(meshObj, 'FACE', config.kWPLMeshColVC, wla.hexToVectorRGB(kWPLArmStickmanCol) ,(1,1,1), 1.0, None, None, None)
		print("- faces recolor", facesSet)
		#Creates the armature modifier
		modifier = meshObj.modifiers.new('ArmatureMod', 'ARMATURE')
		modifier.object = armatr
		modifier.use_deform_preserve_volume = True
		modifier.use_bone_envelopes = False
		modifier.use_vertex_groups = True
		modifier.show_in_editmode = True
		modifier.show_on_cage = True
		opt_material = wla_attr.mat_find_any(kWPLArmStickmanMat)
		if opt_material is not None:
			mat = bpy.data.materials.get(opt_material)
			meshObj.data.materials.append(mat)
			print("- assigned material", mat.name)
		# restoring pose
		armatr.data.pose_position = 'POSE'
		return {'FINISHED'}

class wplpose_armsrescal(bpy.types.Operator):
	bl_idname = "object.wplpose_armsrescal"
	bl_label = "Armature rescaler"
	bl_options = {'REGISTER', 'UNDO'}

	opt_action : EnumProperty(
		name="Action",
		items=(("CREATECOPY", "Create copy", ""), 
			("APPLYCOPY_ALL", "Apply changes FULL", ""), 
			("APPLYCOPY_ARMA", "Apply changes Arma", ""),
			("CLEANUP", "Cancel", ""), 
			), 
		default="CREATECOPY"
	)

	def execute(self, context):
		if wla.is_local_view():
			self.report({'INFO'}, 'Can`t work in Local view')
			return {"CANCELLED"}
		if self.opt_action == 'CLEANUP':
			armatr2 = wla.object_by_name(kWPLArmaRescaleTemp)
			active_obj2 = wla.object_by_name(kWPLArmaRescaleTemp + "_mesh")
			if armatr2 is None or active_obj2 is None:
				self.report({'ERROR'}, "Temp Armature not found")
				return {'CANCELLED'}
			active_obj = wla.object_by_name(armatr2["orig_mesh"])
			bpy.data.objects.remove(active_obj2, do_unlink=True)
			bpy.data.objects.remove(armatr2, do_unlink=True)
			if active_obj is not None:
				wla_do.select_and_change_mode(active_obj, 'OBJECT')
			return {'FINISHED'}
		if self.opt_action == 'CREATECOPY':
			active_obj = wla.active_object(['MESH'])
			if active_obj is None:
				self.report({'ERROR'}, "Select mesh with armature")
				return {'CANCELLED'}
			if wla.modf_by_type(active_obj, 'MIRROR') is not None:
				self.report({'ERROR'}, "Mesh has MIRROR")
				return {'CANCELLED'}
			armatr = wla_arma.related_arma(active_obj)
			if armatr is None:
				self.report({'ERROR'}, "Armature not found")
				return {'CANCELLED'}
			wla_do.switch_orientation('LOCAL', 'MEDIAN_POINT')
			armatr.data.pose_position = 'REST'
			wla_do.select_and_change_mode(armatr, 'OBJECT')
			wla_do.ensure_visible(active_obj, 2)
			active_obj.select_set(True)
			armatr.select_set(True)
			wla_do.find_last_changed_objects(False)
			bpy.ops.object.duplicate(linked=False, mode='TRANSLATION')
			dups = wla_do.find_last_changed_objects(True)
			print("- arma: dups", dups)
			if len(dups) != 2:
				self.report({'ERROR'}, "Duplication failed")
				return {'CANCELLED'}
			active_obj2 = dups[0]
			armatr2 = dups[1]
			if active_obj2.type != 'MESH':
				active_obj2 = dups[1]
				armatr2 = dups[0]
			armatr2.name = kWPLArmaRescaleTemp
			armatr2.data.name = kWPLArmaRescaleTemp
			active_obj2.name = kWPLArmaRescaleTemp+"_mesh"
			active_obj2.data.name = kWPLArmaRescaleTemp+"_mesh"
			armatr2["orig_arma"] = armatr.name
			armatr2["orig_mesh"] = active_obj.name
			wla_do.select_and_change_mode(armatr2, 'POSE')
			armatr2.data.pose_position = 'REST'
			bpy.ops.pose.select_all(action='SELECT')
			bpy.ops.pose.visual_transform_apply()
			armatr2.data.pose_position = 'POSE'
			wla_do.select_and_change_mode(armatr2, 'EDIT')
			armatr2.data.use_mirror_x = False
			armatr2.data.layers = [True]*len(armatr.data.layers)
			all_editBns = [b for b in armatr2.data.edit_bones]
			all_deformBnsName = []
			all_bonesPos = {}
			for bn in all_editBns:
				# print("- edit bone", bn.name)
				bn_pos = [bn.head[0],bn.head[1],bn.head[2],bn.tail[0],bn.tail[1],bn.tail[2]] # start_xyz, end_xyz, local space
				all_bonesPos[bn.name] = bn_pos
				if bn.use_deform:
					if wla_attr.vg_get_by_name(active_obj2, bn.name) is not None:
						all_deformBnsName.append(bn.name)
						bn_par = bn.parent
						while bn_par is not None:
							if bn_par.name not in all_deformBnsName:
								all_deformBnsName.append(bn_par.name)
							bn_par = bn_par.parent
			all_deformBnsName = sorted(all_deformBnsName)
			for bn in all_editBns:
				if bn.name not in all_deformBnsName:
					armatr2.data.edit_bones.remove(bn)
				else:
					bn.use_inherit_scale = False
					constrs = []
			# calulating mapping
			all_bonesMappn = {}
			all_bonesMappnNotFound = {}
			for bn_key in all_bonesPos.keys():
				if bn_key in all_deformBnsName:
					continue
				bn_posval = all_bonesPos[bn_key]
				bn_head = Vector((bn_posval[0], bn_posval[1], bn_posval[2]))
				bn_tail = Vector((bn_posval[3], bn_posval[4], bn_posval[5]))
				isMappedHead = False
				isMappedTail = False
				for hint in kWPLArmRescaleMapHint_MLOW.keys():
					hint_base = hint.replace("<","").replace(">","")
					if hint_base in bn_key:
						hint_full = kWPLArmRescaleMapHint_MLOW[hint]
						if ".L" in bn_key:
							hint_full = hint_full.replace("??",".L")
						if ".R" in bn_key:
							hint_full = hint_full.replace("??",".R")
						if kWPLArmRescaleDebugging:
							print("- hinted mapping",hint,bn_key,hint_full)
						if "<" in hint:
							all_bonesMappn[bn_key+"<"] = hint_full
							isMappedHead = True
						elif ">" in hint:
							all_bonesMappn[bn_key+">"] = hint_full
							isMappedTail = True
						else:
							all_bonesMappn[bn_key+"<"] = hint_full
							all_bonesMappn[bn_key+">"] = hint_full
							isMappedHead = True
							isMappedTail = True
							break
				if isMappedHead == False or isMappedTail == False:
					for bndefr_key in all_deformBnsName:
						bnd_posval = all_bonesPos[bndefr_key]
						bnd_head = Vector((bnd_posval[0], bnd_posval[1], bnd_posval[2]))
						bnd_tail = Vector((bnd_posval[3], bnd_posval[4], bnd_posval[5]))
						if isMappedHead == False:
							if (bn_head - bnd_head).length < kWPLArmRescaleEpsilon:
								all_bonesMappn[bn_key+"<"] = bndefr_key+"<"
								isMappedHead = True
							elif (bn_head - bnd_tail).length < kWPLArmRescaleEpsilon:
								all_bonesMappn[bn_key+"<"] = bndefr_key+">"
								isMappedHead = True
							elif (bn_head - (bnd_head + bnd_tail)*0.5).length < kWPLArmRescaleEpsilon:
								all_bonesMappn[bn_key+"<"] = bndefr_key+"%"
								isMappedHead = True
						if isMappedTail == False:
							if (bn_tail - bnd_head).length < kWPLArmRescaleEpsilon:
								all_bonesMappn[bn_key+">"] = bndefr_key+"<"
								isMappedTail = True
							elif (bn_tail - bnd_tail).length < kWPLArmRescaleEpsilon:
								all_bonesMappn[bn_key+">"] = bndefr_key+">"
								isMappedTail = True
							elif (bn_tail - (bnd_head + bnd_tail)*0.5).length < kWPLArmRescaleEpsilon:
								all_bonesMappn[bn_key+">"] = bndefr_key+"%"
								isMappedTail = True
						if isMappedTail and isMappedHead:
							break
				if isMappedHead == True and isMappedTail == False:
					all_bonesMappn[bn_key+">"] = all_bonesMappn[bn_key+"<"]
					isMappedTail = True
				if isMappedHead == False and isMappedTail == True:
					all_bonesMappn[bn_key+"<"] = all_bonesMappn[bn_key+">"]
					isMappedHead = True
				if isMappedHead == False:
					#print("- Unmapped head:", bn_key)
					all_bonesMappnNotFound[bn_key+"<"] = "???"
				if isMappedTail == False:
					#print("- Unmapped tail:", bn_key)
					all_bonesMappnNotFound[bn_key+">"] = "???"
			print("- Mapping finished, clearing constraints/etc")
			armatr2["orig_bnpos"] = all_bonesPos
			armatr2["orig_defrnme"] = all_deformBnsName
			armatr2["orig_mappn"] = all_bonesMappn
			wla_do.select_and_change_mode(armatr2, 'POSE')
			for bn_name in all_deformBnsName:
				pbone = armatr2.pose.bones[bn_name]
				for constr in pbone.constraints:
					constrs.append(constr)
				for constr in constrs:
					try:
						pbone.constraints.remove(constr)
					except:
						pass
			bpy.ops.pose.select_all(action='SELECT')
			armatr2.data.pose_position = 'POSE'
			bpy.ops.pose.transforms_clear()
			wla_do.select_and_change_mode(armatr,"OBJECT")
			# moving TEMP Armature
			wla_do.select_and_change_mode(armatr2, 'OBJECT')
			armatr2.location = armatr2.location + Vector((0, -1.5, 0))
			wla_do.select_and_change_mode(armatr2, 'POSE')
			armatr2.pose.use_mirror_x = True
			bpy.ops.pose.select_all(action='DESELECT')
			if kWPLArmRescaleDebugging:
				print("- Mapped bones", all_bonesMappn)
			if len(all_bonesMappnNotFound) > 0:
				print("- Unmapped bones", all_bonesMappnNotFound)
				self.report({'ERROR'}, "Unmapped bones found: "+str(len(all_bonesMappnNotFound)))
				return {'FINISHED'}
			print("- Mapped bones", len(all_bonesMappn))
			self.report({'INFO'}, "Done, bones mapped: "+str(len(all_bonesMappn)))
		if self.opt_action == 'APPLYCOPY_ALL' or self.opt_action == 'APPLYCOPY_ARMA':
			# making mesh copy and replacing it in original
			armatr2 = wla.object_by_name(kWPLArmaRescaleTemp)
			active_obj2 = wla.object_by_name(kWPLArmaRescaleTemp + "_mesh")
			if armatr2 is None or active_obj2 is None:
				self.report({'ERROR'}, "Temp Armature not found")
				return {'CANCELLED'}
			armatr = wla.object_by_name(armatr2["orig_arma"])
			active_obj = wla.object_by_name(armatr2["orig_mesh"])
			if armatr is None or active_obj is None:
				self.report({'ERROR'}, "Source Armature not found")
				return {'CANCELLED'}
			wla_do.ensure_visible(armatr, 0)
			wla_do.ensure_visible(active_obj, 0)
			wla_do.ensure_visible(armatr2, 0)
			wla_do.ensure_visible(active_obj2, 0)
			all_bonesPos = armatr2["orig_bnpos"]
			all_deformBnsName = armatr2["orig_defrnme"]
			all_bonesMappn = armatr2["orig_mappn"]
			print("- original bones", len(all_bonesPos))
			if kWPLArmRescaleDebugging:
				for boneName in all_bonesPos.keys():
					refbn_inih = Vector((all_bonesPos[boneName][0],all_bonesPos[boneName][1],all_bonesPos[boneName][2]))
					refbn_init = Vector((all_bonesPos[boneName][3],all_bonesPos[boneName][4],all_bonesPos[boneName][5]))
					print("- initial pos", boneName, refbn_inih, refbn_init)
			wla_do.select_and_change_mode(active_obj2, 'OBJECT')
			wla_do.find_last_changed_objects(False)
			bpy.ops.object.duplicate(linked=False, mode='TRANSLATION')
			dups = wla_do.find_last_changed_objects(True)
			if len(dups) != 1:
				self.report({'ERROR'}, "Duplication failed")
				return {'CANCELLED'}
			active_obj2_tmp = dups[0]
			if self.opt_action == 'APPLYCOPY_ALL':
				print("- Applying armature and cloning mesh...")
				md = wla.modf_by_type(active_obj2_tmp, 'ARMATURE')
				if md is None:
					self.report({'ERROR'}, "Duplication failed - no armature")
					return {'CANCELLED'}
				bpy.ops.object.modifier_apply(modifier=md.name)
				active_obj.data = active_obj2_tmp.data
			bpy.data.objects.remove(active_obj2_tmp, do_unlink=True)
			wla_do.select_and_change_mode(armatr2, 'OBJECT')
			armatr2_bn_pos = {}
			wla_do.select_and_change_mode(armatr2, 'POSE')
			bpy.ops.pose.visual_transform_apply()
			for boneName in all_deformBnsName:
				pbone = armatr2.pose.bones[boneName]
				pblocs = wla_arma.posebone_localpos(pbone, armatr2)
				phead = pblocs[0]
				ptail = pblocs[1]
				armatr2_bn_pos[boneName] = (copy.copy(phead), copy.copy(ptail))
			bonesUpdated = {
				'direct':0,
				'heads':0,
				'tails':0,
				'miss':0
			}
			armatr.data.pose_position = 'REST'
			wla_do.select_and_change_mode(armatr,"EDIT")
			armatr.data.use_mirror_x = False
			eboneTestPos = {}
			for boneName in reversed(all_bonesPos.keys()):
				ebone = armatr.data.edit_bones[boneName]
				if ebone is None:
					print("- reapply error: bone not found", boneName)
					continue
				if boneName in all_deformBnsName:
					# direct copy
					refbn_inih = Vector((all_bonesPos[boneName][0],all_bonesPos[boneName][1],all_bonesPos[boneName][2]))
					refbn_init = Vector((all_bonesPos[boneName][3],all_bonesPos[boneName][4],all_bonesPos[boneName][5]))
					refshift1 = refbn_inih - armatr2_bn_pos[boneName][0]
					refshift2 = refbn_init - armatr2_bn_pos[boneName][1]
					ebone.head = armatr2_bn_pos[boneName][0]
					ebone.tail = armatr2_bn_pos[boneName][1]
					bonesUpdated['direct'] = bonesUpdated['direct']+1
					eboneTestPos[ebone.name] = (copy.copy(ebone.head), copy.copy(ebone.tail))
					if kWPLArmRescaleDebugging and refshift1.length+refshift2.length > 0.0:
						print("- direct. shift on", boneName, refshift1.length+refshift2.length)
					continue
				if boneName+'<' in all_bonesMappn:
					headMappn = all_bonesMappn[boneName+'<']
					refbn = None
					refbn_now = None
					refbn_ini = None
					if '<' in headMappn:
						refbn = headMappn[:-1]
						refbn_now = armatr2_bn_pos[refbn][0]
						refbn_ini = Vector((all_bonesPos[refbn][0],all_bonesPos[refbn][1],all_bonesPos[refbn][2]))
					if '>' in headMappn:
						refbn = headMappn[:-1]
						refbn_now = armatr2_bn_pos[refbn][1]
						refbn_ini = Vector((all_bonesPos[refbn][3],all_bonesPos[refbn][4],all_bonesPos[refbn][5]))
					if '%' in headMappn:
						refbn = headMappn[:-1]
						refbn_now = (armatr2_bn_pos[refbn][0] + armatr2_bn_pos[refbn][1]) * 0.5
						refbn_ini = (Vector((all_bonesPos[refbn][0],all_bonesPos[refbn][1],all_bonesPos[refbn][2])) + Vector((all_bonesPos[refbn][3],all_bonesPos[refbn][4],all_bonesPos[refbn][5]))) * 0.5
					if refbn is not None:
						refshift = refbn_now - refbn_ini
						ebone.head = Vector((all_bonesPos[boneName][0],all_bonesPos[boneName][1],all_bonesPos[boneName][2])) + refshift
						bonesUpdated['heads'] = bonesUpdated['heads']+1
						if kWPLArmRescaleDebugging and refshift.length > 0.0:
							print("- head. shift on", boneName, refshift.length)
				else:
					bonesUpdated['miss'] = bonesUpdated['miss']+1
				if boneName+'>' in all_bonesMappn:
					headMappn = all_bonesMappn[boneName+'>']
					refbn = None
					refbn_now = None
					refbn_ini = None
					if '<' in headMappn:
						refbn = headMappn[:-1]
						refbn_now = armatr2_bn_pos[refbn][0]
						refbn_ini = Vector((all_bonesPos[refbn][0],all_bonesPos[refbn][1],all_bonesPos[refbn][2]))
					if '>' in headMappn:
						refbn = headMappn[:-1]
						refbn_now = armatr2_bn_pos[refbn][1]
						refbn_ini = Vector((all_bonesPos[refbn][3],all_bonesPos[refbn][4],all_bonesPos[refbn][5]))
					if '%' in headMappn:
						refbn = headMappn[:-1]
						refbn_now = (armatr2_bn_pos[refbn][0] + armatr2_bn_pos[refbn][1]) * 0.5
						refbn_ini = (Vector((all_bonesPos[refbn][0],all_bonesPos[refbn][1],all_bonesPos[refbn][2])) + Vector((all_bonesPos[refbn][3],all_bonesPos[refbn][4],all_bonesPos[refbn][5]))) * 0.5
					if refbn is not None:
						refshift = refbn_now - refbn_ini
						ebone.tail = Vector((all_bonesPos[boneName][3],all_bonesPos[boneName][4],all_bonesPos[boneName][5])) + refshift
						bonesUpdated['tails'] = bonesUpdated['tails']+1
						if kWPLArmRescaleDebugging and refshift.length > 0.0:
							print("- tail. shift on", boneName, refshift.length)
				else:
					bonesUpdated['miss'] = bonesUpdated['miss']+1
				eboneTestPos[ebone.name] = (copy.copy(ebone.head), copy.copy(ebone.tail))
			# for all StretchTo constraints setting proper REST length
			# for all EXCEPT "VIS-..."!!! -> lines from Knees/Elbows to Control Spheres
			wla_do.select_and_change_mode(armatr,"POSE")
			for boneName in reversed(all_bonesPos.keys()):
				pbone = armatr.pose.bones[boneName]
				if len(pbone.constraints) > 0:
					for constr in pbone.constraints:
						if constr.type == 'STRETCH_TO' and wla.isTokenInStr(kWPLArmRescaleNoStretchFox_MLOW, boneName) == False:
							trgBone = constr.subtarget
							distVec = wla.math_lerp1D(constr.head_tail,eboneTestPos[trgBone][0],eboneTestPos[trgBone][1])-eboneTestPos[boneName][0]
							if kWPLArmRescaleDebugging:
								print("- stretch fix on", boneName, distVec.length, constr.rest_length)
							constr.rest_length = distVec.length
			wla_do.select_and_change_mode(armatr,"OBJECT")
			wla_do.select_and_change_mode(armatr2,"OBJECT")
			armatr.data.pose_position = 'REST'
			if kWPLArmRescaleDebugging: # do post-checks
				# testing new positions of bones
				wla_do.select_and_change_mode(armatr,"EDIT")
				for boneName in all_bonesPos.keys():
					ebone = armatr.data.edit_bones[boneName]
					if ebone.name in eboneTestPos:
						if (ebone.head - eboneTestPos[ebone.name][0]).length > 0.00001:
							print("- WARNING: post-shift on head", boneName, (ebone.head - eboneTestPos[ebone.name][0]).length)
						if (ebone.tail - eboneTestPos[ebone.name][1]).length > 0.00001:
							print("- WARNING: post-shift on tail", boneName, (ebone.tail - eboneTestPos[ebone.name][1]).length)
			wla_do.select_and_change_mode(armatr,"OBJECT")
			armatr.data.pose_position = 'POSE'
			# applying current pose as REST -> or JUMPS and vgBIND проблемы
			wla_do.select_and_change_mode(armatr,"POSE")
			bpy.ops.pose.select_all(action='SELECT')
			bpy.ops.pose.transforms_clear()
			bpy.ops.pose.armature_apply(selected=False)
			wla_do.select_and_change_mode(armatr,"OBJECT")
			print("- apply stats", bonesUpdated)
			self.report({'INFO'}, "Done, skipped: "+str(bonesUpdated['miss']))
		return {'FINISHED'}

# class wplpose_verts_toggle(bpy.types.Operator):
# 	bl_idname = "object.wplpose_verts_toggle"
# 	bl_label = "Select verts by bone"
# 	bl_options = {'REGISTER', 'UNDO'}

# 	opt_nameTokens : StringProperty(
# 		name = "Name token",
# 		default = ""
# 	)

# 	def execute(self, context):
# 		active_obj = wla.active_object(['MESH'])
# 		if active_obj is None:
# 			self.report({'ERROR'}, "Select mesh object first")
# 			return {'FINISHED'}
# 		wla_do.select_and_change_mode(active_obj, 'OBJECT')
# 		bns = wla.strTokensMap(self.opt_nameTokens, 0.099, False)
# 		okCnt = 0
# 		for bn in bns.keys():
# 			wlim = float(bns[bn])
# 			print("- checking", bn, wlim)
# 			vgg = wla_attr.vg_get_weightMap(active_obj, bn, wlim)
# 			for vIdx in vgg:
# 				active_obj.data.vertices[vIdx].select = True
# 				okCnt = okCnt+1
# 		wla_do.select_and_change_mode(active_obj, 'EDIT')
# 		context.tool_settings.mesh_select_mode = (True, False, False) # 'VERT'
# 		self.report({'INFO'}, "Done. verts="+str(okCnt))
# 		return {'FINISHED'}

class wplpose_objs_toggle(bpy.types.Operator):
	bl_idname = "object.wplpose_objs_toggle"
	bl_label = "Toggle objects tree visibility"
	bl_options = {'REGISTER', 'UNDO'}

	opt_nameTokens : StringProperty(
		name = "Name token",
		default = ""
	)
	opt_scopeTokens : StringProperty(
		name = "Scope token",
		default = ""
	)
	opt_shouldBeVisible : BoolProperty(
		name="Visibility",
		default=True
	)
	opt_wholeTrees : BoolProperty(
		name="With all childs",
		default=True
	)
	opt_checkCollections : BoolProperty(
		name="Also collections",
		default=False
	)

	def execute(self, context):
		# Switching from edit modes...
		# NOT REALLY! Disabling props inside edit is really useful
		# in posing only
		active_obj = wla.active_object()
		if wla.is_pose_mode() and (active_obj is not None):
			wla_do.select_and_change_mode(active_obj,'OBJECT')
		if config.kWPLSystemMainCam in self.opt_nameTokens:
			# special case - selecting/adding cam
			# helpful for DBG-Views in localview mode (trigger emis, etc)
			# helpful for tuning rotated frames in local mode
			camera_obj = wla.object_by_name(config.kWPLSystemMainCam)
			if  wla.object_by_name(config.kWPLSystemPffCam) is not None:
				# pff mode
				print("- pff mode")
				camera_obj = wla.object_by_name(config.kWPLSystemPffCam)
			if camera_obj is not None:
				wla_do.ensure_visible(camera_obj, 1)
				camera_obj.select_set(True)
			if "XFLIP:" in self.opt_nameTokens:
				scal = camera_obj.scale
				scal[0] = -1*scal[0]
				camera_obj.scale = scal
				camera_obj.data.shift_x = -1.0*camera_obj.data.shift_x
				self.report({'INFO'}, "Flipped, dir: "+str(scal[0]))
			elif "ZROT:" in self.opt_nameTokens:
				wla_do.select_and_change_mode(camera_obj,"OBJECT")
				bpy.ops.transform.rotate(value=1.5708, orient_axis='Z', orient_type='LOCAL')
				tmp = camera_obj.data.shift_x
				camera_obj.data.shift_x = camera_obj.data.shift_y
				camera_obj.data.shift_y = tmp
				if active_obj is not None:
					wla_do.select_and_change_mode(active_obj,"OBJECT")
				self.report({'INFO'}, "Rotated")
			else:
				# switching to camera away from any mode/object
				wla_do.select_and_change_mode(camera_obj,"OBJECT")
			return {'FINISHED'}
		def update4tag(toks, fullTree, visState):
			objs2update = []
			for objx in bpy.data.objects:
				if len(self.opt_scopeTokens) > 0 and wla.isTokenInStr(self.opt_scopeTokens, wla.object_full_name(objx)) == False:
					continue
				if wla.isTokenInStr(toks, objx.name):
					if objx not in objs2update:
						objs2update.append(objx)
					if fullTree:
						wla.all_childs_recursive(objx, objs2update)
			ok = len(objs2update)
			for obj in objs2update:
				#print("- obj", obj.name, self.opt_shouldBeVisible)
				if visState == True:
					if config.kWPLSuppZZZZPrefix in obj.name:
						# finalized hair curves/etc not needed
						continue
					if obj.hide_select == True:
						# non-selectables not needed
						continue
				obj.hide_viewport = not visState
			if self.opt_checkCollections:
				for cl in bpy.data.collections:
					if wla.isTokenInStr(toks, cl.name):
						cl.hide_viewport = not visState
			return ok
		okObjs = 0
		if "!" not in self.opt_nameTokens:
			print("- invcheck", self.opt_nameTokens)
			okObjs = update4tag(self.opt_nameTokens, self.opt_wholeTrees, self.opt_shouldBeVisible)
		else:
			# excusivity case: enabling one, disabling others
			toksList = wla.getTokensAsList(self.opt_nameTokens)
			print("- check", toksList)
			for tok in toksList:
				if "!" not in tok:
					okObjs = update4tag(tok, self.opt_wholeTrees, self.opt_shouldBeVisible)
				else:
					tok2 = tok.replace("!","")
					update4tag(tok2, self.opt_wholeTrees, not self.opt_shouldBeVisible)
		wla_do.sys_update_view(True, False)
		self.report({'INFO'}, "Done, handled: "+str(okObjs))
		return {'FINISHED'}

# ==========================================

def uilayout_propVisibilityBox(col, context):
	active_obj = wla.active_object()
	box3 = col.box()
	box3.label( text='Prop visibility')

	row1 = box3.row()
	spl1 = row1.split(align=True, factor = 0.8)
	op = spl1.operator("object.wplpose_objs_toggle", text="[+] Garms")
	op.opt_nameTokens = "_garm, _dress"
	op.opt_scopeTokens = ""
	op.opt_shouldBeVisible = True
	op.opt_wholeTrees = True
	op.opt_checkCollections = False
	op = spl1.operator("object.wplpose_objs_toggle", text="[-]")
	op.opt_nameTokens = "_garm, _dress"
	op.opt_scopeTokens = ""
	op.opt_shouldBeVisible = False
	op.opt_wholeTrees = True
	op.opt_checkCollections = False
	spl1 = row1.split(align=True, factor = 0.8)
	op = spl1.operator("object.wplpose_objs_toggle", text="[+] Hairs")
	op.opt_nameTokens = "_hairs"
	op.opt_scopeTokens = ""
	op.opt_shouldBeVisible = True
	op.opt_wholeTrees = True
	op.opt_checkCollections = False
	op = spl1.operator("object.wplpose_objs_toggle", text="[-]")
	op.opt_nameTokens = "_hairs"
	op.opt_scopeTokens = ""
	op.opt_shouldBeVisible = False
	op.opt_wholeTrees = True
	op.opt_checkCollections = False
	
	row1 = box3.row()
	spl1 = row1.split(align=True, factor = 0.8)
	op = spl1.operator("object.wplpose_objs_toggle", text="[+] Backs")
	op.opt_nameTokens = "_bg, bg_"
	op.opt_scopeTokens = ""
	op.opt_shouldBeVisible = True
	op.opt_wholeTrees = True
	op.opt_checkCollections = True
	op = spl1.operator("object.wplpose_objs_toggle", text="[-]")
	op.opt_nameTokens = "_bg, bg_"
	op.opt_scopeTokens = ""
	op.opt_shouldBeVisible = False
	op.opt_wholeTrees = True
	op.opt_checkCollections = True
	spl1 = row1.split(align=True, factor = 0.8)
	op = spl1.operator("object.wplpose_objs_toggle", text="[+] Fore")
	op.opt_nameTokens = "_fg, fg_"
	op.opt_scopeTokens = ""
	op.opt_shouldBeVisible = True
	op.opt_wholeTrees = True
	op.opt_checkCollections = False
	op = spl1.operator("object.wplpose_objs_toggle", text="[-]")
	op.opt_nameTokens = "_fg, fg_"
	op.opt_scopeTokens = ""
	op.opt_shouldBeVisible = False
	op.opt_wholeTrees = True
	op.opt_checkCollections = False
	if ("#emo:" in wla.object_full_name(active_obj)):
		row1 = box3.row(align=True)
		op = row1.operator("object.wplpose_objs_toggle", text="[A]")
		op.opt_nameTokens = "#emo:A, !#emo:B, !#emo:C, !#emo:D, !#emo:E, !#emo:F, !#emo:G"
		op.opt_scopeTokens = "#emo:"
		op.opt_shouldBeVisible = True
		op.opt_wholeTrees = True
		op.opt_checkCollections = False
		op = row1.operator("object.wplpose_objs_toggle", text="[B]")
		op.opt_nameTokens = "!#emo:A, #emo:B, !#emo:C, !#emo:D, !#emo:E, !#emo:F, !#emo:G"
		op.opt_scopeTokens = "#emo:"
		op.opt_shouldBeVisible = True
		op.opt_wholeTrees = True
		op.opt_checkCollections = False
		op = row1.operator("object.wplpose_objs_toggle", text="[C]")
		op.opt_nameTokens = "!#emo:A, !#emo:B, #emo:C, !#emo:D, !#emo:E, !#emo:F, !#emo:G"
		op.opt_scopeTokens = "#emo:"
		op.opt_shouldBeVisible = True
		op.opt_wholeTrees = True
		op.opt_checkCollections = False
		op = row1.operator("object.wplpose_objs_toggle", text="[D]")
		op.opt_nameTokens = "!#emo:A, !#emo:B, !#emo:C, #emo:D, !#emo:E, !#emo:F, !#emo:G"
		op.opt_scopeTokens = "#emo:"
		op.opt_shouldBeVisible = True
		op.opt_wholeTrees = True
		op.opt_checkCollections = False
		op = row1.operator("object.wplpose_objs_toggle", text="[E]")
		op.opt_nameTokens = "!#emo:A, !#emo:B, !#emo:C, !#emo:D, #emo:E, !#emo:F, !#emo:G"
		op.opt_scopeTokens = "#emo:"
		op.opt_shouldBeVisible = True
		op.opt_wholeTrees = True
		op.opt_checkCollections = False
		op = row1.operator("object.wplpose_objs_toggle", text="[F]")
		op.opt_nameTokens = "!#emo:A, !#emo:B, !#emo:C, !#emo:D, !#emo:E, #emo:F, !#emo:G"
		op.opt_scopeTokens = "#emo:"
		op.opt_shouldBeVisible = True
		op.opt_wholeTrees = True
		op.opt_checkCollections = False
		op = row1.operator("object.wplpose_objs_toggle", text="[G]")
		op.opt_nameTokens = "!#emo:A, !#emo:B, !#emo:C, !#emo:D, !#emo:E, !#emo:F, #emo:G"
		op.opt_scopeTokens = "#emo:"
		op.opt_shouldBeVisible = True
		op.opt_wholeTrees = True
		op.opt_checkCollections = False
		op = row1.operator("object.wplpose_objs_toggle", text="[x]")
		op.opt_nameTokens = "#emo:A, #emo:B, #emo:C, #emo:D, #emo:E, #emo:F, #emo:G"
		op.opt_scopeTokens = "#emo:"
		op.opt_shouldBeVisible = True
		op.opt_wholeTrees = True
		op.opt_checkCollections = False
	row1 = box3.row()
	spl1 = row1.split(factor = 0.6)
	op = spl1.operator("object.wplpose_objs_toggle", text="@MainCam")
	op.opt_nameTokens = config.kWPLSystemMainCam
	op.opt_scopeTokens = ""
	op.opt_shouldBeVisible = True
	op.opt_wholeTrees = False
	op = spl1.operator("object.wplpose_objs_toggle", text="SX-1")
	op.opt_nameTokens = "XFLIP:"+config.kWPLSystemMainCam
	op.opt_scopeTokens = ""
	op.opt_shouldBeVisible = True
	op.opt_wholeTrees = False
	op = spl1.operator("object.wplpose_objs_toggle", text="RZ+90")
	op.opt_nameTokens = "ZROT:"+config.kWPLSystemMainCam
	op.opt_scopeTokens = ""
	op.opt_shouldBeVisible = True
	op.opt_wholeTrees = False
	from . import ops_scene_man
	ops_scene_man.uilayout_trafarefBox(box3, context)

class WPL_PT_PosePanel(bpy.types.Panel):
	bl_idname = "WPL_PT_PosePanel"
	bl_label = "Pose tools"
	bl_space_type = 'VIEW_3D'
	bl_region_type = 'UI'
	bl_category = "CHAR"

	def draw(self, context):
		layout = self.layout
		active_obj = wla.active_object()
		col = layout.column()
		if active_obj is not None and active_obj.type == 'ARMATURE' and bpy.context.mode == 'POSE':
			col.separator()
			col.operator("object.wplpose_ar_toggle", text="Stop Posing").opt_postAction = 'POSE_OFF'
		else:
			spl1 = col.split(factor = 0.75)
			spl1.column().operator("object.wplpose_ar_toggle", text="Start Posing").opt_postAction = 'POSE_ON'
			spl1.column().operator("object.wplpose_ar_toggle", text="Rest Pose").opt_postAction = 'POSE_ON_REST'
		col.separator()
		if active_obj is not None and ('POSE' in bpy.context.mode):
			box2 = col.box()
			box2.label( text='Bone tweaks')
			spl1 = box2.split(factor = 0.75)
			spl1.column().operator("object.wplpose_bn_copypaste", text = "Copy bones").opt_mode = 'COPY'
			op = spl1.column().operator("object.wplpose_bn_copypaste", text = "Paste ALL")
			op.opt_mode = 'PASTEALL'
			op.opt_autoFuzzy = False
			spl1 = box2.split(factor = 0.75)
			op = spl1.column().operator("object.wplpose_bn_copypaste", text = "Rotate similars")
			op.opt_mode = 'PASTE'
			op.opt_autoFuzzy = True
			op = spl1.column().operator("object.wplpose_bn_copypaste", text = "Paste SEL")
			op.opt_mode = 'PASTESEL'
			op.opt_autoFuzzy = False
			box2.separator()
			box2.operator("object.wplpose_bn_slide", text="Slide selected bones").opt_rotats = (0.0,0.0,0.0)
			# row1 = box2.row()
			# spl1 = row1.split(factor = 0.8)
			# op = spl1.operator("object.wplpose_ar_toggle", text="[+] Lock:Move")
			# op.opt_postAction = 'MOVLOC_OFF'
			# op.opt_nameTok = "<sel>"
			# op = spl1.operator("object.wplpose_ar_toggle", text="[-]")
			# op.opt_postAction = 'MOVLOC_ON'
			# op.opt_nameTok = "<sel>"
			# spl1 = row1.split(factor = 0.8)
			# op = spl1.operator("object.wplpose_ar_toggle", text="[+] Lock:Scale")
			# op.opt_postAction = 'SCLINH_OFF'
			# op.opt_nameTok = "<sel>"
			# op = spl1.operator("object.wplpose_ar_toggle", text="[-]")
			# op.opt_postAction = 'SCLINH_ON'
			# op.opt_nameTok = "<sel>"
			# row1 = box2.row()
			# spl1 = row1.split(factor = 0.8)
			# op = spl1.operator("object.wplpose_ar_toggle", text="[+] Lock:Rotate")
			# op.opt_postAction = 'ROTINH_OFF'
			# op.opt_nameTok = "<sel>"
			# op = spl1.operator("object.wplpose_ar_toggle", text="[-]")
			# op.opt_postAction = 'ROTINH_ON'
			# op.opt_nameTok = "<sel>"
			# spl1 = row1.split(factor = 0.8)
			# op = spl1.operator("object.wplpose_ar_toggle", text="[+] Constraints")
			# op.opt_postAction = 'CONSTRS_ON'
			# op.opt_nameTok = "<sel>" # MLow problem: "ORG-foot.R"
			# op = spl1.operator("object.wplpose_ar_toggle", text="[-]")
			# op.opt_postAction = 'CONSTRS_OFF'
			# op.opt_nameTok = "<sel>"
		box4 = col.box()
		if (active_obj is not None) and (active_obj.type == 'MESH') and (wla.modf_by_type(active_obj, 'ARMATURE') is not None):
			row1 = box4.row()
			row1.operator("object.wplpose_armskel", text="Stickman: Full").opt_mode = 'FULL'
			row1.operator("object.wplpose_armskel", text="Stickman: Lite").opt_mode = 'LITE'
		row1 = box4.row()
		spl1 = row1.split(align=True, factor = 0.8)
		op = spl1.operator("object.wplpose_objs_toggle", text="[+] Rigs")
		op.opt_nameTokens = "_charr, _rig, _loomis, _deform"
		op.opt_scopeTokens = ""
		op.opt_shouldBeVisible = True
		op.opt_wholeTrees = False
		op.opt_checkCollections = False
		op = spl1.operator("object.wplpose_objs_toggle", text="[-]")
		op.opt_nameTokens = "_charr, _rig, _loomis, _deform"
		op.opt_scopeTokens = ""
		op.opt_shouldBeVisible = False
		op.opt_wholeTrees = False
		op.opt_checkCollections = False
		spl1 = row1.split(align=True, factor = 0.8)
		op = spl1.operator("object.wplpose_objs_toggle", text="[+] Helpers")
		op.opt_nameTokens = "_loomis, _stick, _altuv,"+",".join(config.kWPLSystemOslAssets)
		op.opt_scopeTokens = ""
		op.opt_shouldBeVisible = True
		op.opt_wholeTrees = True
		op.opt_checkCollections = False
		op = spl1.operator("object.wplpose_objs_toggle", text="[-]")
		op.opt_nameTokens = "_loomis, _stick, _altuv,"+",".join(config.kWPLSystemOslAssets)
		op.opt_scopeTokens = ""
		op.opt_shouldBeVisible = False
		op.opt_wholeTrees = True
		op.opt_checkCollections = False
		
		row1 = box4.row()
		spl1 = row1.split(align=True, factor = 0.8)
		op = spl1.operator("object.wplpose_objs_toggle", text="[+] Charb")
		op.opt_nameTokens = "_charb"
		op.opt_shouldBeVisible = True
		op.opt_wholeTrees = True
		op.opt_checkCollections = False
		op = spl1.operator("object.wplpose_objs_toggle", text="[-]")
		op.opt_nameTokens = "_charb"
		op.opt_shouldBeVisible = False
		op.opt_wholeTrees = True
		op.opt_checkCollections = False
		spl1 = row1.split(align=True, factor = 0.8)
		op = spl1.operator("object.wplpose_objs_toggle", text="[+] Faces")
		op.opt_nameTokens = "_face, _mouth, _eye_, _eyes, _eyebrow, _secondar"
		op.opt_scopeTokens = ""
		op.opt_shouldBeVisible = True
		op.opt_wholeTrees = False
		op.opt_checkCollections = False
		op = spl1.operator("object.wplpose_objs_toggle", text="[-]")
		op.opt_nameTokens = "_face, _mouth, _eye_, _eyes, _eyebrow, _secondar"
		op.opt_scopeTokens = ""
		op.opt_shouldBeVisible = False
		op.opt_wholeTrees = False
		op.opt_checkCollections = False
		if (wla.object_by_name(kWPLArmaRescaleTemp) is None) and (active_obj is not None) and (config.kWPLObjCharBodyPostfix in active_obj.name):
			box4.separator()
			box4.operator("object.wplpose_armsrescal", text="Character: Start rescale").opt_action = 'CREATECOPY'
		elif wla.object_by_name(kWPLArmaRescaleTemp) is not None:
			box4.separator()
			row1 = box4.row()
			row1.label(text="Apply rescale:")
			row1.operator("object.wplpose_armsrescal", text="FULL").opt_action = 'APPLYCOPY_ALL'
			row1.operator("object.wplpose_armsrescal", text="ARMA only ").opt_action = 'APPLYCOPY_ARMA'
			box4.operator("object.wplpose_armsrescal", text="CANCEL & CLEANUP").opt_action = 'CLEANUP'

class WPL_PT_CharPanel(bpy.types.Panel):
	bl_idname = "WPL_PT_CharPanel"
	bl_label = "Char tools"
	bl_space_type = 'VIEW_3D'
	bl_region_type = 'UI'
	bl_category = "CHAR"

	def draw(self, context):
		layout = self.layout
		active_obj = wla.active_object()
		col = layout.column()
		uilayout_propVisibilityBox(col, context)
		col.separator()
		box4 = col.box()
		# if wla.is_edit_mode() and active_obj is not None and (active_obj.type == 'MESH'):
		# 	row1 = box4.row() # not so used much
		# 	row1.operator("object.wplbind_manual_edging_gp", text="SysE: vHist").opt_mode = 'EDIT_VHIST'
		# 	row1.operator("object.wplbind_manual_edging_gp", text="SysE: vSel/fSel").opt_mode = 'EDIT_SEL'
		# 	box4.operator("object.wplbind_auto_fill_gp", text="SysE: GP-Fill").opt_mode = 'EDIT_SEL'
		# 	box4.separator()
		# 	box4.operator("mesh.wplvc_cppaste", text="Isls: Add Segment by fSel").opt_op = 'SEGMENT'
		# 	return
		row = box4.row()
		spl = row.split(align=True, factor=0.8)
		spl.column().operator("object.wplheal_clonehier", text="Objects: CLONE Hier")
		spl.column().operator("object.wplheal_massrename", text="[-]").opt_objReplc = "[-]_;.001:_A;.002:_B;.003:_C;.004:_D;.005:_E;.006:_F;.007:_G;.008:_H;.000:_Z;&nbsp:_;@full_hier"
		#spl.column().operator("object.wplheal_massrename", text="[+]").opt_objReplc = "[+]_;@full_hier"
		# bindings
		if len(wla.selected_objects(["MESH", "CURVE", "EMPTY"])) > 0:
			row1 = box4.row()
			row1.operator("object.wplbind_apply_vgbind", text="vgBind", icon='LIBRARY_DATA_DIRECT')
			# For charb/charh: making mesh version
			opt_makeVersion = False
			if (active_obj is not None) and active_obj.type == 'MESH':
				isCharbObj = (wla.isTokenInStr([config.kWPLObjCharBodyPostfix, config.kWPLObjCharHeadPostfix], active_obj.name) == True)
				opt_makeVersion = isCharbObj
			finAll = row1.operator("object.wplbind_apply_transf", text="Finalize", icon='MOD_MESHDEFORM')
			finAll.opt_applyConstrs = False
			finAll.opt_applyMirror = True
			finAll.opt_applyArmat = True
			finAll.opt_applyHooks = True
			finAll.opt_applyShrinks = True
			finAll.opt_applyArrays = True
			finAll.opt_applySubd = opt_makeVersion
			finAll.opt_makeVersion = opt_makeVersion
			row1.operator("object.wplbind_apply_vgscript", text="vgScript", icon='PARTICLEMODE')
		if len(wla.selected_objects(["MESH", "CURVE", "EMPTY"])) > 0:
			# many mesh objects
			box4.separator()
			if wla.is_edit_mode():
				box4.operator("mesh.wplvc_cppaste", text="Isls: Add Segment by fSel").opt_op = 'SEGMENT'
			else:
				box4.operator("object.wplpose_armsegm", text="Hier: Auto-Segment by Bones", icon="GROUP_VERTEX")
				if len( wla.selected_objects(['CURVE']) ) > 0:
					box4.operator("curve.wplcurve_curve_2mesh", icon="FILE_REFRESH")
				op1 = box4.operator("object.wpluvvg_gen_isl", text = "Hier: Generate DBG:BW", icon="MOD_BOOLEAN")
				op1.opt_generType = 'MTL_ISL_DBG'
				op1 = box4.operator("object.wplbind_auto_foldbase_verf", text="Folds: Add base")
				op1.opt_matReplace = "" #op1.opt_matReplace = "placeholder"
				row = box4.row()
				row.operator("object.wplbind_auto_edging_gp", text="Edges: GP-Converter")
				row.operator("object.wplbind_lineart_edging", text="Edges: Add LineArt")
				row = box4.row()
				op1 = row.operator("object.wplbind_auto_uvbase_syse", text="Alt-UV: MESH")
				op1.opt_matReplace = "placeholder"
				op = row.operator("object.wpluvvg_unwrap_edges_grid", text = "Alt-UV: GRID", icon='UV_DATA')
				op.opt_uvPrefx = config.kWPLGridUV+"_ALT"
				op.opt_vgSeedV = "_sel2"
				op.opt_tranfType='DST_GRD'
				op.opt_selectedOnly = False
				box4.separator()
				box4.operator("object.wpluvvg_gen_nrms", text="Hier: Bake FlatNrm/Isls/etc finals", icon="MOD_BOOLEAN")
				#row1.operator("object.wplbind_auto_veil", text="SysC: Add Under-Veil")
		if len(wla.selected_objects()) > 0:
			curve_obj = None
			sel_objs = wla.selected_objects(['CURVE'])
			if len(sel_objs) > 0:
				curve_obj = sel_objs[0]
			if (curve_obj is not None) and len(curve_obj.data.materials)>0 and (config.kWPLMatTokenSVG in curve_obj.data.materials[0].name):
				# SVG Import: convert to mesh with colors, etc
				box4.operator("curve.wplcurve_svg_2mesh", icon="FILE_REFRESH", text = 'Obj: SVG-curves to mesh')
			else:
				box4.operator("object.wpluvvg_transferdat", text="Objects: Transfer VC/VG/Arma", icon="MOD_DATA_TRANSFER")

def doAutoSetupCustomProp(face_obj):
	# if wla.isTokenInStr(config.kWPLObjCharFaceMouthToken, face_obj.name):
	# 	# need to set custom props
	# 	print("- autosetup: mouth custom props")
	# 	if kWPLAutoSetupMouthCSC not in face_obj:
	# 		face_obj[kWPLAutoSetupMouthCSC] = (0.25,0.25,1.0)
	# 	if kWPLAutoSetupMouthLSC not in face_obj:
	# 		face_obj[kWPLAutoSetupMouthLSC] = (0.3,-0.3,1.0)
	# 	if kWPLAutoSetupMouthUPC not in face_obj:
	# 		face_obj[kWPLAutoSetupMouthUPC] = 1111111
	# 		ui_data = face_obj.id_properties_ui(kWPLAutoSetupMouthUPC)
	# 		ui_data.update( min = 0, max = 9999999 )
	# 	if kWPLAutoSetupMouthDNC not in face_obj:
	# 		face_obj[kWPLAutoSetupMouthDNC] = 1111111
	# 		ui_data = face_obj.id_properties_ui(kWPLAutoSetupMouthDNC)
	# 		ui_data.update( min = 0, max = 9999999 )
	# else:
	# 	print("- autosetup: eyes custom props")
	# 	if kWPLAutoSetupEyesRings not in face_obj:
	# 		face_obj[kWPLAutoSetupEyesRings] = (0.4,0.85,0.9)
	return

# ==========================================
# ==========================================

classes = (
	WPL_PT_PosePanel,
	WPL_PT_CharPanel,
	wplpose_objs_toggle,
	#wplpose_verts_toggle,
	wplpose_ar_toggle,
	wplpose_bn_slide,
	wplpose_bn_copypaste,
	wplpose_armskel,
	wplpose_armsegm,
	wplpose_armsrescal
)

def register():
	for cls in classes:
		bpy.utils.register_class(cls)

def unregister():
	for cls in reversed(classes):
		bpy.utils.unregister_class(cls)

if __name__ == "__main__":
	register()