import os, sys, time, datetime
import math, copy, string, random
import numpy as np
import bpy, bmesh, mathutils

import bpy.types
from mathutils import Vector, Matrix, Euler, Quaternion
from mathutils.bvhtree import BVHTree
from mathutils.kdtree import KDTree
from bpy_extras import view3d_utils
from bpy.props import *

from . import config
from .tools import wla
from .tools import wla_do
from .tools import wla_bm
from .tools import wla_arma
from .tools import wla_meshwrap
from .tools import wla_attr
from .tools import wla_curve

kWPLHookDeformerTemp = "zzz_tempGrid"
kWPLArmaDeformerTemp = "zzz_tempRig"
kWPLMeshDeformShCageMod = "_shacage"
EPS = np.finfo(float).eps
STATE_NOTHING = 0
STATE_ACTIVE = 1
LAYERS_DEFAULT = 0
LAYERS_PUSH_MOD = 28
LAYERS_INFL_BND = 29
LAYERS_BND_ROOT = 30
BNNRM_DEFLEN = 0.1

class ARMD:
	last_state = STATE_NOTHING
	next_state = STATE_NOTHING
	active_timer = None
	active_hashbase = 0

	target_name = ""
	target_verts = {} # and initial positions
	target_cache = {"mode": "", "radius": 0.0, "shk": {}}
	target_wrapmesh = None

	# collid_bvh = None
	# collid_vert_cache = {}

	defrm_type = "ARMA" # ARMA BARI

	arma_name = ""
	arma_need_rebind = False
	arma_bn_restmap = {}
	#arma_bn_infl_bnd = []

def ARMD_prepareObjectAndArma(context, active_obj, active_meshw, selvertsAll, mode, modeVertsHint):
	wpl_armdOpts = context.scene.wpl_armdOpts
	active_vertIdx = None
	#active_cursorPos = None
	ARMD.target_verts = {}
	ARMD.target_cache["shk"] = {}
	if active_meshw is None:
		active_meshw = wla_meshwrap.object_wrappedmesh(active_obj, {wla_meshwrap.kWPL_NoFocusChanges: True})
	ARMD.target_wrapmesh = active_meshw
	if mode == 'START_ACTIVE': # or START_3DCACTIVE
		histVertsIdx = wla_meshwrap.meshwrap_recent_vertsIdx(active_meshw)
		if len(histVertsIdx) > 0:
			active_vertIdx = histVertsIdx[0]
	# if mode == 'START_3DCACTIVE':
	# 	active_cursorPos = wla.active_context_cursor()
	wla_do.select_and_change_mode(active_obj,'OBJECT')
	ARMD.target_name = active_obj.name
	wla_do.modf_toggle(active_obj, wla_do.kWPLModifsHeavies, False, ARMD.target_cache)
	wla_do.modf_toggle(active_obj, ['show_wire'], True, ARMD.target_cache)

	# ??? objectm_vertsAvgCo
	v_center = Vector((0,0,0))
	v_cennrm = Vector((0,0,0))
	for vIdx in selvertsAll:
		v = active_meshw.vertices[vIdx]
		ARMD.target_verts[vIdx] = copy.copy(v.co)
		v_center = v_center + v.co
		v_cennrm = v_cennrm + v.normal
	v_center = v_center/len(selvertsAll)
	v_cennrm = (v_cennrm/len(selvertsAll)).normalized()
	vIdxClosest = -1
	vIdxClosestDst = 999
	vIdxFarestDst = 0
	for vIdx in ARMD.target_verts.keys():
		v = active_meshw.vertices[vIdx]
		dst = (v.co - v_center).length
		if vIdxClosestDst > dst:
			vIdxClosestDst = dst
			vIdxClosest = vIdx
		if dst > vIdxFarestDst:
			vIdxFarestDst = dst
	ARMD.target_cache["radius"] = vIdxFarestDst
	if vIdxClosest != -1:
		v = active_meshw.vertices[vIdxClosest]
		v_center = v.co
		v_cennrm = v.normal
	# if (ARMD.collid_bvh is not None) and wpl_armdOpts.opt_collidermod != 'IGNORE':
	# 	# need to remember distance+normal sign
	# 	ARMD.collid_vert_cache = {}
	# 	for vIdx in ARMD.target_verts.keys():
	# 		v = active_meshw.vertices[vIdx]
	# 		hit_loc, hit_nrm, hit_index, hit_dst = ARMD.collid_bvh.find_nearest(v.co, 10)
	# 		if hit_loc is not None:
	# 			hit_dir = (v.co - hit_loc).normalized()
	# 			if hit_dir.dot(hit_nrm) < 0.0:
	# 				hit_dst = -1*hit_dst
	# 			ARMD.collid_vert_cache[vIdx] = hit_dst
	# creating armature
	# needBack2LV = False
	# if wla.is_local_view():
	# 	bpy.ops.view3d.localview(frame_selected=False)
	# 	needBack2LV = True
	ARMD.arma_name = kWPLArmaDeformerTemp
	active_arma = wla.object_by_name(ARMD.arma_name)
	if active_arma is not None:
		bpy.data.objects.remove(active_arma, do_unlink=True)
	amt = bpy.data.armatures.new(ARMD.arma_name+"_arm")
	active_arma = bpy.data.objects.new(ARMD.arma_name, amt)
	# AMUST: object local == armature local
	wla_do.ensure_visible(active_arma, 2) # Import in Local mode if needed
	wla_do.link_object_sideBySide(active_arma, active_obj) # matrix MUST match!!!
	active_arma.show_in_front = True
	active_arma.data.display_type = 'STICK'
	active_arma.data.pose_position = 'POSE'
	active_arma.data.layers = wla.arrBools(len(active_arma.data.layers), True)
	# if needBack2LV == True:
	# 	needBack2LV = False
	# 	active_arma.select_set(True)
	# 	active_obj.select_set(True)
	# 	bpy.ops.view3d.localview(frame_selected=False)
	
	bn_deflen = min(BNNRM_DEFLEN, 0.1*vIdxFarestDst) #max(active_obj.dimensions[0], active_obj.dimensions[1])
	# adding start bones
	wla_do.select_and_change_mode(active_arma,'EDIT')
	# if mode == 'START_BARIVERTS' and len(modeVertsHint) > 0: # 'START_NONHIDDEN' # TOGGLE_DT_BARI
	# 	for bnvIdx in modeVertsHint:
	# 		bone = amt.edit_bones.new('Bone')
	# 		active_v = active_meshw.vertices[bnvIdx]
	# 		bone.head = active_v.co
	# 		bone.tail = active_v.co + active_v.normal*bn_deflen
	# else:
	bone = amt.edit_bones.new('Bone')
	if mode == 'START_ACTIVE' and (active_vertIdx is not None):
		active_v = active_meshw.vertices[active_vertIdx]
		bone.head = active_v.co
		bone.tail = active_v.co + active_v.normal*bn_deflen
	# elif mode == 'START_3DCACTIVE' and (active_vertIdx is not None) and (active_cursorPos is not None):
	# 	active_v = active_meshw.vertices[active_vertIdx]
	# 	bone.head = active_obj.matrix_world.inverted() @ active_cursorPos
	# 	bone.tail = active_v.co
	else:
		bone.head = v_center
		bone.tail = v_center+v_cennrm*bn_deflen
	#print("- armadef: created", active_arma)
	return True

def ARMD_restoreObjectState(keep_verts):
	active_arma = wla.object_by_name(ARMD.arma_name)
	if active_arma is not None:
		bpy.data.objects.remove(active_arma, do_unlink=True)
	active_obj = wla.object_by_name(ARMD.target_name)
	active_meshw = ARMD.target_wrapmesh
	ARMD.arma_name = ""
	ARMD.target_wrapmesh = None
	ARMD.target_name = ""
	if active_obj is None:
		return
	wla_do.modf_toggle(active_obj, wla_do.kWPLModifsHeavies, None, ARMD.target_cache)
	wla_do.modf_toggle(active_obj, ['show_wire'], None, ARMD.target_cache)
	if keep_verts == False:
		wla_do.select_and_change_mode(active_obj, 'OBJECT')
		cntOk = 0
		for vIdx in ARMD.target_verts.keys():
			if vIdx in active_meshw.all_vertsIdx():
				v = active_meshw.vertices[vIdx]
				v.co = ARMD.target_verts[vIdx]
				cntOk = cntOk+1
		active_meshw.to_mesh()
		print("- arma: ARMD_restoreObjectState: reverted to REST: "+str(cntOk)+" keep_verts="+str(keep_verts))
	if len(ARMD.target_cache["mode"]) > 0:
		wla_do.select_and_change_mode(active_obj,ARMD.target_cache["mode"])
		ARMD.target_cache["mode"] = ""
	ARMD.target_verts = {}
	active_meshw.to_mesh()

def ARMD_prepareArmaState(context):
	# Armature "EDIT"-mode bones dump
	active_arma = wla.object_by_name(ARMD.arma_name)
	active_obj = wla.object_by_name(ARMD.target_name)
	if active_obj is None or active_arma is None:
		return
	ARMD.arma_bn_restmap = {}
	#curmode = wla_do.select_and_change_mode(active_arma,"EDIT")
	all_editBns = [b for b in active_arma.data.bones] # no need for edit_bones

	# Deformation: ARMATURE preps
	all_bns = []
	for bn in all_editBns:
		all_bns.append(bn.name)
		bn_head = Vector((bn.head_local[0],bn.head_local[1],bn.head_local[2]))
		bn_tail = Vector((bn.tail_local[0],bn.tail_local[1],bn.tail_local[2]))
		allmin_dst = 999
		allmax_dst = 0
		for vIdx in ARMD.target_verts.keys():
			v_co = ARMD.target_verts[vIdx]
			min_dst = min((bn_head-v_co).length, (bn_tail-v_co).length)
			max_dst = max((bn_head-v_co).length, (bn_tail-v_co).length)
			if min_dst < allmin_dst:
				allmin_dst = min_dst
			if max_dst > allmax_dst:
				allmax_dst = max_dst
		#print("- DBG: allmax_dst-allmin_dst", allmax_dst, allmin_dst)
		if abs(allmax_dst-allmin_dst) < EPS:
			print("- WARNING: problems with allmax_dst/allmin_dst", allmin_dst, allmax_dst)
		for vIdx in ARMD.target_verts.keys():
			v_co = ARMD.target_verts[vIdx]
			intresct = mathutils.geometry.intersect_point_line(v_co, bn_head, bn_tail)
			#if intresct[1] >= 0.0 and intresct[1] <= 1.0:
			reldist = wla.math_clamp(intresct[1],0.0,1.0)+config.kWPLRaycastEpsilon
			reldist_overflow = 0.0
			if intresct[1] < 0.0:
				reldist_overflow = -1.0 * intresct[1]
			if intresct[1] > 1.0:
				reldist_overflow = intresct[1] - 1.0
			relpos = bn_head+(bn_tail-bn_head)*reldist
			#print("- val test ", (relpos-v_co).length,allmin_dst, allmax_dst)
			vco_wei = 1.0 - (EPS+(relpos-v_co).length-allmin_dst) / (EPS+allmax_dst-allmin_dst)
			vco_plocal_this = bn.matrix_local.inverted() @ v_co
			vco_plocal_prev = None
			if bn.parent is not None:
				vco_plocal_prev = bn.parent.matrix_local.inverted() @ v_co
			ARMD.arma_bn_restmap[str(vIdx)+bn.name] = {
				"plocal_this": vco_plocal_this,
				"plocal_prev": vco_plocal_prev,
				"weight": vco_wei,
				"ht_fac": reldist,
				"ht_fac_ovr": reldist_overflow
			}
	# # if ARMD.defrm_type == 'BARI':  # TOGGLE_DT_BARI
	# # Deformation: Baricentric preps
	# # delaunoi triangulation from screen-projected
	# # https://blenderartists.org/t/how-to-connect-loose-geometry-vertex-into-plane-by-script/1306744
	# # https://github.com/jmespadero/pyDelaunay2D
	# bn_triags = []
	# bn_triags_allow = {}
	# if len(all_editBns) > 2:
	# 	bn_2dc = []
	# 	bn_len_sum = 0
	# 	bn_len_cnt = 0
	# 	for bn in all_editBns:
	# 		bn_head = Vector((bn.head_local[0],bn.head_local[1],bn.head_local[2]))
	# 		bn_tail = Vector((bn.tail_local[0],bn.tail_local[1],bn.tail_local[2]))
	# 		bn_len_sum = bn_len_sum+(bn_tail-bn_head).length
	# 		bn_len_cnt = bn_len_cnt+1.0
	# 		bn_triag_pt = bn_tail #(bn_head+bn_tail)*0.5
	# 		bn_center_3d_g = active_arma.matrix_world @ bn_triag_pt
	# 		bn_center_2d = wla.view_point3dToPoint2d(bn_center_3d_g) -> active_view_region(pt)
	# 		bn_2dc.append(bn_center_2d)
	# 	# bn_len_avg = bn_len_sum/bn_len_cnt
	# 	_, _, dd_faces, _, _, _ = mathutils.geometry.delaunay_2d_cdt(bn_2dc, [], [], 0, 0.0001)
	# 	fIdx = 1
	# 	for dd_f_vIdx in dd_faces:
	# 		ff_set_nm = []
	# 		ff_set_co = []
	# 		ff_set_co_2d = []
	# 		for dd_vi in dd_f_vIdx:
	# 			bn = all_editBns[dd_vi]
	# 			bn_head = Vector((bn.head_local[0],bn.head_local[1],bn.head_local[2]))
	# 			bn_tail = Vector((bn.tail_local[0],bn.tail_local[1],bn.tail_local[2]))
	# 			bn_triag_pt = bn_tail #(bn_head+bn_tail)*0.5
	# 			ff_set_nm.append(bn.name)
	# 			ff_set_co.append(bn_triag_pt.copy())
	# 			bn_triag_pt_2d = wla.view_point3dToPoint2d(active_arma.matrix_world @ bn_triag_pt) -> active_view_region(pt)
	# 			ff_set_co_2d.append(bn_triag_pt_2d)
	# 		bn_triags.append( (fIdx, ff_set_nm, ff_set_co, ff_set_co_2d) )
	# 		fIdx = fIdx+1
	# 	# checkin projections to limit
	# 	for vIdx in ARMD.target_verts.keys():
	# 		v_co = ARMD.target_verts[vIdx]
	# 		for triag_pp in bn_triags:
	# 			triag_id = triag_pp[0]
	# 			#triag_before = triag_pp[2]
	# 			triag_befor2d = triag_pp[3]
	# 			# extending vert 10% - or "edge-aligned" verts will be missed in deform
	# 			#triag_cntr = (triag_before[0]+triag_before[1]+triag_before[2])*0.333
	# 			# triag_before[0] = triag_before[0] + (triag_before[0]-triag_cntr).normalized() * 0.01
	# 			# triag_before[1] = triag_before[1] + (triag_before[1]-triag_cntr).normalized() * 0.01
	# 			# triag_before[2] = triag_before[2] + (triag_before[2]-triag_cntr).normalized() * 0.01
	# 			#triag_proj = mathutils.geometry.intersect_point_tri(v_co, triag_before[0], triag_before[1], triag_before[2])
	# 			v_co_2d = wla.view_point3dToPoint2d(active_arma.matrix_world @ v_co) -> active_view_region(pt)
	# 			triag_proj = mathutils.geometry.intersect_point_tri(v_co_2d, triag_befor2d[0], triag_befor2d[1], triag_befor2d[2])
	# 			if (triag_proj is None): # and (v_co-triag_before[0]).length>bn_len_avg and (v_co-triag_before[1]).length>bn_len_avg and (v_co-triag_before[2]).length>bn_len_avg:
	# 				continue
	# 			if triag_id not in bn_triags_allow:
	# 				bn_triags_allow[triag_id] = set()
	# 			triag_vrt = bn_triags_allow[triag_id]
	# 			triag_vrt.add(vIdx)
	# ARMD.arma_bn_restmap["all_bns_triags"] = bn_triags
	# ARMD.arma_bn_restmap["all_bns_triags_allow"] = bn_triags_allow
	# #wla_do.select_and_change_mode(active_arma,curmode)
	# finalization
	ARMD.arma_bn_restmap["all_bns"] = sorted(all_bns)
	ARMD.arma_bn_restmap["all_bns_hash"] = ARMD_getBnPosHash(context)
	print("- arma: ARMD_prepareArmaState ok")
	return
	
def ARMD_getBnPosHash(context):
	bnhash = ARMD.active_hashbase
	active_arma = wla.object_by_name(ARMD.arma_name)
	if active_arma is None:
		return bnhash
	all_bns = ARMD.arma_bn_restmap["all_bns"]
	for bn_name in all_bns:
		pbone = active_arma.pose.bones[bn_name]
		bnhash += pbone.head[0]+pbone.head[1]+pbone.head[2]
		bnhash += pbone.tail[0]+pbone.tail[1]+pbone.tail[2]
		bnhash += pbone.scale[0]+pbone.scale[1]+pbone.scale[2]
	if context is not None:
		wpl_armdOpts = context.scene.wpl_armdOpts
		bnhash += wpl_armdOpts.opt_headtail_pow
		bnhash += wpl_armdOpts.opt_distfalloff_pow
		bnhash += wpl_armdOpts.opt_headtail_overflow
	return bnhash

# def ARMD_updateTargetMesh_BARI(context, active_arma, active_meshw): # TOGGLE_DT_BARI
# 	# if ARMD.defrm_type == 'BARI':
# 	#opt_distfalloff_pow = 1.0
# 	#if context is not None:
# 	#	wpl_armdOpts = context.scene.wpl_armdOpts
# 	#	#opt_distfalloff_pow = wpl_armdOpts.opt_distfalloff_pow
# 	bn_triags = ARMD.arma_bn_restmap["all_bns_triags"]
# 	bn_triags_allow = ARMD.arma_bn_restmap["all_bns_triags_allow"]
# 	for vIdx in ARMD.target_verts.keys():
# 		v = active_meshw.vertices[vIdx]
# 		ini_pos = ARMD.target_verts[vIdx]
# 		new_pos_sum = Vector((0,0,0))
# 		new_pos_cnt = 0.0
# 		for triag_pp in bn_triags:
# 			triag_id = triag_pp[0]
# 			if triag_id not in bn_triags_allow:
# 				continue # no verts in it
# 			triag_verts = bn_triags_allow[triag_id]
# 			if vIdx not in triag_verts:
# 				continue
# 			triag_before = triag_pp[2]
# 			triag_after = []
# 			for bn_name in triag_pp[1]:
# 				pbone = active_arma.pose.bones[bn_name]
# 				bn_head = pbone.matrix @ Vector((0,0,0))
# 				bn_tail = pbone.matrix @ Vector((0,pbone.length,0))
# 				bn_center_3d = bn_tail #((bn_head+bn_tail)*0.5)
# 				triag_after.append(bn_center_3d)
# 			new_pos = mathutils.geometry.barycentric_transform(ini_pos, triag_before[0], triag_before[1], triag_before[2], triag_after[0], triag_after[1], triag_after[2])
# 			# dbg_trgdiff = (triag_before[0]-triag_after[0]).length+(triag_before[1]-triag_after[1]).length+(triag_before[2]-triag_after[2]).length
# 			# dbg_vvvdiff = (ini_pos-new_pos).length
# 			# print("- DBG: diffs", dbg_trgdiff, dbg_vvvdiff)
# 			new_pos_sum = new_pos_sum+new_pos
# 			new_pos_cnt = new_pos_cnt+1.0
# 		if new_pos_cnt > 0.0:
# 			v.co = new_pos_sum/new_pos_cnt
# 	active_meshw.to_mesh()
# 	return

def ARMD_updateTargetMesh_ARMA(context, active_arma, active_meshw):
	opt_headtail_pow = 1.0
	opt_headtail_overflow = 0.0
	opt_distfalloff_pow = 1.0
	if context is not None:
		wpl_armdOpts = context.scene.wpl_armdOpts
		opt_headtail_pow = wpl_armdOpts.opt_headtail_pow
		opt_headtail_overflow = wpl_armdOpts.opt_headtail_overflow
		opt_distfalloff_pow = wpl_armdOpts.opt_distfalloff_pow
	# object local == armature local
	#ao_inv = active_obj.matrix_world.inverted()
	all_bns = ARMD.arma_bn_restmap["all_bns"]
	zone_rad = ARMD.target_cache["radius"]
	for vIdx in ARMD.target_verts.keys():
		v = active_meshw.vertices[vIdx]
		ini_pos = ARMD.target_verts[vIdx]
		lnew_pos = []
		lnew_wei = []
		influence = 1.0
		push_bns = []
		for bn_name in all_bns:
			ebone = active_arma.data.bones[bn_name]
			pbone = active_arma.pose.bones[bn_name]
			if ebone.layers[LAYERS_DEFAULT] or ebone.layers[LAYERS_BND_ROOT]:
				if str(vIdx)+bn_name in ARMD.arma_bn_restmap:
					bn_dat = ARMD.arma_bn_restmap[str(vIdx)+bn_name]
					# posed head/tail
					rel_pos_tail = pbone.matrix @ bn_dat["plocal_this"]
					rel_pos_head = rel_pos_tail
					if (pbone.parent is None) and (ebone.layers[LAYERS_BND_ROOT] and not ebone.layers[LAYERS_DEFAULT]):
						rel_pos_head = ini_pos
					if (pbone.parent is not None) and (bn_dat["plocal_prev"] is not None):
						rel_pos_head = pbone.parent.matrix @ bn_dat["plocal_prev"]
					# lerping along bone
					ht_fac = math.pow(bn_dat["ht_fac"], opt_headtail_pow)
					wei_fac = math.pow(bn_dat["weight"], opt_distfalloff_pow)
					wei_fac = max(0.0, wei_fac - wla.math_lerp1D(opt_headtail_overflow, 0.0, bn_dat["ht_fac_ovr"]))
					rel_pos = rel_pos_head.lerp(rel_pos_tail, ht_fac)
					# print("- DBG: rel_pos", vIdx, rel_pos)
					lnew_pos.append(rel_pos)
					lnew_wei.append(wei_fac + EPS)
			elif ebone.layers[LAYERS_INFL_BND]:
				bn_head = pbone.matrix @ Vector((0,0,0))
				bn_tail = pbone.matrix @ Vector((0,pbone.length,0))
				intresct = mathutils.geometry.intersect_point_line(v.co, bn_head, bn_tail)
				reldist = wla.math_clamp(intresct[1],0.0,1.0)
				relpos = bn_head+(bn_tail-bn_head)*reldist
				dist = (relpos-v.co).length / pbone.scale[0]
				if dist < zone_rad:
					fac = math.pow(dist/zone_rad, abs(pbone.scale[2])+EPS)
					influence = influence * fac
			elif ebone.layers[LAYERS_PUSH_MOD]:
				push_bns.append(bn_name)
		push_offset = Vector((0,0,0))
		if len(push_bns) > 0:
			v_base_co = ini_pos # using v.co NOT ok -> non re-terable
			for bn_name in push_bns:
				ebone = active_arma.data.bones[bn_name]
				pbone = active_arma.pose.bones[bn_name]
				bn_head = pbone.matrix @ Vector((0,0,0))
				bn_tail = pbone.matrix @ Vector((0,pbone.length,0))
				intresct = mathutils.geometry.intersect_point_line(v_base_co, bn_head, bn_tail)
				reldist = wla.math_clamp(intresct[1],0.0,1.0)
				relpos = bn_head+(bn_tail-bn_head)*reldist
				dist = (relpos - v_base_co).length / pbone.scale[0]
				if dist < zone_rad:
					fac = math.pow(1.0-dist/zone_rad, abs(pbone.scale[2])+EPS)
					bn_dir = (pbone.matrix.inverted().transposed().to_3x3() @ Vector((0,0,1.0))).normalized()
					push_offset = push_offset.lerp(bn_dir,fac)
			# v.co = v.co.lerp(v.co+push_offset, influence)
		v_co_new = None
		if len(lnew_wei) > 0:
			nx = np.average([itm[0] for itm in lnew_pos],weights=lnew_wei)
			ny = np.average([itm[1] for itm in lnew_pos],weights=lnew_wei)
			nz = np.average([itm[2] for itm in lnew_pos],weights=lnew_wei)
			new_pos = Vector((nx, ny, nz))+push_offset
			v_co_new = ini_pos.lerp(new_pos, influence)
		else:
			v_co_new = ini_pos.lerp(ini_pos+push_offset, influence)

		# if (ARMD.collid_bvh is not None) and wpl_armdOpts.opt_collidermod != 'IGNORE' and (vIdx in ARMD.collid_vert_cache):
		# 	kCollidBVHMaxDist = 10
		# 	# need to restore distance+normal sign
		# 	hit_loc, hit_nrm, _, hit_dst = ARMD.collid_bvh.find_nearest(v_co_new, kCollidBVHMaxDist)
		# 	if hit_loc is not None:
		# 		hit_dst_ini = ARMD.collid_vert_cache[vIdx]
		# 		hit_dir = (v_co_new - hit_loc).normalized()
		# 		if hit_dir.dot(hit_nrm) < 0.0:
		# 			hit_dst = -1*hit_dst
		# 		isSignChange = False
		# 		cast_loc = None
		# 		cast_nrm = None
		# 		if hit_dst_ini<0.0001 or hit_dst*hit_dst_ini <= 0.0:
		# 			isSignChange = True
		# 			# # ok, but of sharp deforms -> NOT OK
		# 			# cast_dir = (v_co_new-ini_pos).normalized()
		# 			# cast_loc, cast_nrm, _, _ = ARMD.collid_bvh.ray_cast(ini_pos, cast_dir, kCollidBVHMaxDist)
		# 			# cast_dir = (v_co_new-ini_pos).normalized()
		# 			# if cast_loc is not None and (cast_dir.dot...): # not cover all cases... rotation etc
		# 		if wpl_armdOpts.opt_collidermod == 'DST_KEEP' and (isSignChange or abs(hit_dst) < abs(hit_dst_ini)):
		# 			if cast_loc is not None:
		# 				v_co_new = cast_loc + cast_nrm*hit_dst_ini
		# 			else:
		# 				v_co_new = hit_loc + hit_nrm*hit_dst_ini
		# 		if isSignChange and wpl_armdOpts.opt_collidermod == 'DST_CLAMP':
		# 			if cast_loc is not None:
		# 				v_co_new = cast_loc
		# 			else:
		# 				v_co_new = hit_loc
		v.co = v_co_new
	active_meshw.to_mesh()

def ARMD_updateTargetMesh(toPosePos, context):
	active_arma = wla.object_by_name(ARMD.arma_name)
	active_obj = wla.object_by_name(ARMD.target_name)
	active_meshw = ARMD.target_wrapmesh
	if active_obj is None or active_arma is None:
		return
	if toPosePos == False:
		cntOk = 0
		for vIdx in ARMD.target_verts.keys():
			if vIdx in active_meshw.all_vertsIdx():
				v = active_meshw.vertices[vIdx]
				v.co = ARMD.target_verts[vIdx]
				cntOk = cntOk+1
		active_meshw.to_mesh()
		print("- arma: ARMD_updateTargetMesh: reverted to REST: "+str(cntOk))
		return
	if active_arma.mode != 'POSE':
		print("- arma: ARMD_updateTargetMesh: skipped, arma not in POSE")
		return
	bnsHash = ARMD_getBnPosHash(context)
	if bnsHash == ARMD.arma_bn_restmap["all_bns_hash"]:
		# positions didn`t change
		# print("- bones not changed, skipping")
		return
	# print("- bones changed, updating mesh")
	ARMD.arma_bn_restmap["all_bns_hash"] = bnsHash
	if ARMD.defrm_type == 'ARMA':
		ARMD_updateTargetMesh_ARMA(context, active_arma, active_meshw)
	# if ARMD.defrm_type == 'BARI':
	# 	ARMD_updateTargetMesh_BARI(context, active_arma, active_meshw)
	return

# ============================================
# class wplarmd_alignarma(bpy.types.Operator):
# 	# not possible to normally undo under MODAL ArmaDef
# 	bl_idname = "mesh.wplarmd_alignarma"
# 	bl_label = "Align ArmaDeformer"
# 	bl_options = {'REGISTER'} # , 'UNDO'

# 	opt_alignMode : EnumProperty(
# 		items = [
# 			('ALIGN_YX', "Align YX", "", 1),
# 			('ALIGN_YZ', "Align YZ", "", 2),
# 		],
# 		name="Align mode",
# 		default='ALIGN_YX',
# 	)
# 	opt_invertDir : BoolProperty(
# 		name="Invert direction",
# 		default=False
# 	)

# 	def execute( self, context ):
# 		active_arma = wla.object_by_name(ARMD.arma_name)
# 		if active_arma is None or active_arma.mode != 'POSE':
# 			self.report({'ERROR'}, "ArmaDef not active or not in POSE mode")
# 			return {'FINISHED'}
# 		# if active_arma.mode != 'POSE':
# 		# 	wla_do.select_and_change_mode(active_arma,'POSE')
# 		# 	#self.tickTimer(None)
# 		(strands_points, _) = config.WPL_G.store[config.kWPLGKey_EdgePinStrands]
# 		if len(strands_points) == 0:
# 			self.report({'ERROR'}, "Store some edgelines first")
# 			return {'FINISHED'}
# 		# getting selected bones in parenting order
# 		all_bns = ARMD.arma_bn_restmap["all_bns"]
# 		selbones = []
# 		for boneName in all_bns:
# 			ebone = active_arma.data.bones[boneName]
# 			if ebone.select:
# 				pbone = active_arma.pose.bones[boneName]
# 				pbone.rotation_mode = 'QUATERNION'
# 				selbones.append(pbone)
# 		if len(selbones) == 0:
# 			self.report({'ERROR'}, "Select bones first")
# 			return {'FINISHED'}
# 		targAxis = ('Y','X')
# 		if self.opt_alignMode == 'ALIGN_YZ':
# 			targAxis = ('Y','Z')
# 		selbones = sorted(selbones, key=lambda p: len(wla_arma.posebone_parentchain(p)), reverse=False )
# 		# getting stored edge spline
# 		strand = strands_points[-1]
# 		#print("- strands_points:", len(strands_points), len(strand))
# 		t_yp_px = []
# 		t_yp_py = []
# 		t_yp_pz = []
# 		len_trg = 0
# 		t_xp = []
# 		gp_p_last = None
# 		for gp_p in strand:
# 			t_yp_px.append(gp_p[0])
# 			t_yp_py.append(gp_p[1])
# 			t_yp_pz.append(gp_p[2])
# 			if gp_p_last is not None:
# 				len_trg = len_trg+(gp_p_last-gp_p).length
# 			#print("- strand step:", len_trg)
# 			t_xp.append(len_trg)
# 			gp_p_last = gp_p
# 		# shiftin/moving bones positions
# 		strand_len = 0
# 		for pbone in selbones:
# 			# strand_len t_pos*len_trg
# 			bn_head = active_arma.matrix_world @ (pbone.matrix @ Vector((0,0,0)))
# 			bn_tail = active_arma.matrix_world @ (pbone.matrix @ Vector((0,pbone.length,0)))
# 			interp_len = (bn_tail-bn_head).length # pbone.length is NOT real length in world sizes...
# 			interp_pos = strand_len
# 			interp_pos_next = strand_len+interp_len
# 			if self.opt_invertDir:
# 				interp_pos = len_trg-interp_pos
# 				interp_pos_next = len_trg-interp_pos_next
# 			bn_head_new_g = Vector((np.interp(interp_pos, t_xp, t_yp_px), np.interp(interp_pos, t_xp, t_yp_py), np.interp(interp_pos, t_xp, t_yp_pz)))
# 			bn_tail_new_g = Vector((np.interp(interp_pos_next, t_xp, t_yp_px), np.interp(interp_pos_next, t_xp, t_yp_py), np.interp(interp_pos_next, t_xp, t_yp_pz)))
# 			#print("- step:", strand_len, "+"+str(interp_len), " of "+str(len_trg), (bn_tail-bn_head).length)
# 			strand_len = strand_len+interp_len
# 			#if strand_len < len_trg:
# 			#	break
# 			bn_head_new_l = active_arma.matrix_world.inverted() @ bn_head_new_g
# 			bn_tail_new_l = active_arma.matrix_world.inverted() @ bn_tail_new_g

# 			#bpy.context.view_layer.update()
# 			pbLocV, pbRotQ, pbScaV = pbone.matrix.decompose()
# 			pbLocM = mathutils.Matrix.Translation(bn_head_new_l)
# 			pbRotM = pbRotQ.to_matrix().to_4x4()
# 			pbRotM = (bn_tail_new_l-bn_head_new_l).to_track_quat(targAxis[0],targAxis[1]).to_matrix().to_4x4() 
# 			#print("- track quat:", pbRotM, (bn_tail_new_l-bn_head_new_l))
# 			pbScaM = Matrix().Scale(pbScaV[0], 4, Vector((1,0,0)))
# 			pbScaM = pbScaM @ Matrix().Scale(pbScaV[1], 4, Vector((0,1,0)))
# 			pbScaM = pbScaM @ Matrix().Scale(pbScaV[2], 4, Vector((0,0,1)))
# 			pbone.matrix = pbLocM @ pbRotM @ pbScaM
# 			wla_do.sys_update_view(True, False) # !!! important !!!
# 		ARMD.active_hashbase = ARMD.active_hashbase+0.1
# 		self.report({'INFO'}, "Bones aligned")
# 		return {'FINISHED'}

class wplarmd_tickflow(bpy.types.Operator):
	bl_idname = "mesh.wplarmd_tickflow"
	bl_label = "ArmaDeformer for object"
	bl_options = {'REGISTER'} # 'UNDO' -> Not feasible! ALL Armature actionts will be "Undoable"

	opt_action : EnumProperty(
		items = [
			('START_CENTER', "Start: center", "", 1),
			('START_ACTIVE', "Start: Active", "", 2),
			#('START_BARIVERTS', "Start: BariVerts", "", 3),# TOGGLE_DT_BARI
			#('START_3DCACTIVE', "Start: CursorActive", "", 4), # Not used?
			#('START_NONHIDDEN', "Start: NonHidden", "", 5), # Not used?
			('STOP_APPLY', "Stop: Apply", "", 5),
			('STOP_CANCEL', "Stop: Cancel", "", 6),
			('TOGGLE_AR_MODE', "Toggle arma mode", "", 7),
			('TOGGLE_DT_ARMA', "Toggle deformation: Armature", "", 8),
			#('TOGGLE_DT_BARI', "Toggle deformation: Baricentric", "", 9),
			('TOGGLE_BN_MODE_DSTROOT', "Bone: Default, sticky ends", "", 10),
			('TOGGLE_BN_MODE_DSTROOT_NO', "Bone: Default, non-sticky root", "", 11),
			('TOGGLE_BN_MODE_INFL_MASKER', "Bone: Limit Influence", "", 12),
			('TOGGLE_BN_MODE_DIR_PUSHER', "Bone: Directional push", "", 13),
		],
		name="Action",
		default='START_CENTER',
	)

	def tickTimer(self, context):
		#active_arma = wla.active_object(["ARMATURE"])
		active_arma = wla.object_by_name(ARMD.arma_name)
		if context is not None:
			needCancel = False
			if ARMD.next_state == STATE_NOTHING:
				needCancel = True
				print("- armadef: cancel")
			if active_arma is None or active_arma.name != ARMD.arma_name:
				needCancel = True
				print("- armadef: cancel", active_arma)
			if needCancel:
				ARMD_restoreObjectState(False)
				self.cancel(context)
				return {'FINISHED'}
		if active_arma is not None and active_arma.mode == 'EDIT':
			if ARMD.arma_need_rebind == False:
				ARMD_updateTargetMesh(False, context)
				if context is not None:
					context.area.tag_redraw()
			ARMD.arma_need_rebind = True
		if active_arma is not None and active_arma.mode == 'POSE':
			if ARMD.arma_need_rebind:
				ARMD.arma_need_rebind = False
				ARMD_prepareArmaState(context)
				if context is not None:
					context.area.tag_redraw()
			ARMD_updateTargetMesh(True, context)
		return {'RUNNING_MODAL'}

	def modal(self, context, event):
		if event.type in {'ESC'}:
			print("- armadef: cancel 2")
			ARMD_restoreObjectState(False)
			self.cancel(context)
			return {'CANCELLED'}
		if event.type == 'TIMER':
			context.area.header_text_set(f'User armature to deform object. Edit == Setup, Pose == Deform')
			return self.tickTimer(context)
		return {'PASS_THROUGH'}

	#def execute(self, context):
	def invoke( self, context, event ):
		wm = context.window_manager
		if self.opt_action == 'TOGGLE_BN_MODE_DSTROOT' or self.opt_action == 'TOGGLE_BN_MODE_DSTROOT_NO' or self.opt_action == 'TOGGLE_BN_MODE_INFL_MASKER' or self.opt_action == 'TOGGLE_BN_MODE_DIR_PUSHER':
			active_arma = wla.object_by_name(ARMD.arma_name)
			okCnt = 0
			if active_arma is not None:
				sel_bns = wla_arma.arm_bonenames_tok(active_arma, "<sel>")
				print("- arma: selected bones:", sel_bns)
				for bn_name in sel_bns:
					if self.opt_action == 'TOGGLE_BN_MODE_DSTROOT':
						wla_arma.move_bn2layer(active_arma, bn_name, LAYERS_DEFAULT)
						okCnt = okCnt+1
					if self.opt_action == 'TOGGLE_BN_MODE_DSTROOT_NO':
						wla_arma.move_bn2layer(active_arma, bn_name, LAYERS_BND_ROOT)
						okCnt = okCnt+1
					if self.opt_action == 'TOGGLE_BN_MODE_INFL_MASKER':
						wla_arma.move_bn2layer(active_arma, bn_name, LAYERS_INFL_BND)
						okCnt = okCnt+1
					if self.opt_action == 'TOGGLE_BN_MODE_DIR_PUSHER':
						wla_arma.move_bn2layer(active_arma, bn_name, LAYERS_PUSH_MOD)
						okCnt = okCnt+1
				self.report({'INFO'}, "Bones affected: "+str(okCnt))
				if active_arma.mode == 'POSE':
					self.tickTimer(None)
			return {'FINISHED'}
		
		if self.opt_action == 'TOGGLE_DT_ARMA': # or self.opt_action == 'TOGGLE_DT_BARI':
			active_arma = wla.object_by_name(ARMD.arma_name)
			ARMD.defrm_type = 'ARMA'
			# if self.opt_action == 'TOGGLE_DT_BARI':
			# 	ARMD.defrm_type = 'BARI'
			self.report({'INFO'}, "Deformation type: "+ARMD.defrm_type)
			if active_arma.mode == 'POSE':
				self.tickTimer(None)
			return {'FINISHED'}
		if self.opt_action == 'TOGGLE_AR_MODE':
			active_arma = wla.object_by_name(ARMD.arma_name)
			if active_arma is not None:
				if active_arma.mode != 'POSE':
					wla_do.select_and_change_mode(active_arma,'POSE')
				else:
					wla_do.select_and_change_mode(active_arma,'EDIT')
				self.tickTimer(None)
			return {'FINISHED'}
		if self.opt_action == 'START_CENTER' or self.opt_action == 'START_ACTIVE': # or self.opt_action == 'START_BARIVERTS': TOGGLE_DT_BARI # or self.opt_action == 'START_3DCACTIVE' or self.opt_action == 'START_NONHIDDEN'
			if ARMD.next_state == STATE_NOTHING and ARMD.active_timer is None:
				#bpy.ops.ed.undo_push()
				active_obj = wla.active_object(wla_meshwrap.kWPLMESHWRAP_TYPES)
				if active_obj is None:
					self.report({'ERROR'}, "Select Mesh Object")
					return {'FINISHED'}
				if abs(active_obj.scale[0]-active_obj.scale[1]) + abs(active_obj.scale[2]-active_obj.scale[1]) > 0.001:
					print("- arma: bad dimensions", active_obj.scale)
					self.report({'ERROR'}, "Object has non-uniform scale")
					return {'FINISHED'}
				
				# wpl_armdOpts = context.scene.wpl_armdOpts
				# ARMD.collid_bvh = None
				# if wpl_armdOpts.opt_collidermod != 'IGNORE':
				# 	list_of_bvh = wla_bm.bm_sceneColldersBVH(active_obj, True)
				# 	if list_of_bvh is not None and len(list_of_bvh)>0:
				# 		ARMD.collid_bvh = list_of_bvh[0]
				ARMD.target_cache["mode"] = wla_do.select_and_change_mode(active_obj,'OBJECT')
				active_meshw = wla_meshwrap.object_wrappedmesh(active_obj, {wla_meshwrap.kWPL_NoFocusChanges: True})
				ARMD.target_name = active_obj.name
				selvertsAll = active_meshw.selected_vertsIdx() # wla.selected_vertsIdx(active_mesh)
				actionVertsHint = []
				ARMD.defrm_type = 'ARMA'
				# if self.opt_action == 'START_BARIVERTS': # TOGGLE_DT_BARI
				# 	ARMD.defrm_type = 'BARI' # TOGGLE_DT_BARI
				# 	actionVertsHint = selvertsAll
				# 	selvertsAll = wla_meshwrap.meshwrap_vertsStepOut(active_meshw, selvertsAll, 20)
				# 	#print("- BARI verts", len(actionVertsHint), len(selvertsAll))
				# if self.opt_action == 'START_NONHIDDEN':
				# 	actionVertsHint = selvertsAll
				# 	selvertsAll = active_meshw.hidden_vertsIdx(False) # wla.hidden_vertsIdx(active_mesh, False)
				if len(selvertsAll)<3:
					self.report({'ERROR'}, "No verts, cant start. mode:"+self.opt_action)
					return {'FINISHED'}
				if not ARMD_prepareObjectAndArma(context, active_obj, active_meshw, selvertsAll, self.opt_action, actionVertsHint):
					self.report({'ERROR'}, "Initialization failed. mode:"+self.opt_action)
					return {'FINISHED'}
				ARMD_prepareArmaState(context)
				# ungrabbing selection/restoring PIVOT. After INITS!!!
				#bpy.ops.mesh.wplverts_getori(opt_mode='UNGRAB')
				print("- arma: action: start", wla.active_object())
				ARMD.last_state = STATE_ACTIVE
				ARMD.next_state = STATE_ACTIVE
				ARMD.active_timer = wm.event_timer_add(0.3, window=context.window)
				wm.modal_handler_add(self)
				return {'RUNNING_MODAL'}
			else:
				print("- arma: action: skipping start", ARMD.next_state, ARMD.active_timer)
			return {'FINISHED'}
		if self.opt_action == 'STOP_APPLY' or self.opt_action == 'STOP_CANCEL':
			if ARMD.last_state == STATE_ACTIVE:
				ARMD.next_state = STATE_NOTHING
				if self.opt_action == 'STOP_APPLY':
					ARMD_restoreObjectState(True)
				else:
					print("- armadef: cancel 3")
					ARMD_restoreObjectState(False)
				print("- arma: action: stop")
			else:
				ARMD.next_state = STATE_NOTHING
				print("- action: skipping stop")
		return {'FINISHED'}

	def cancel(self, context):
		if context is not None:
			context.area.header_text_set(None)
			context.area.tag_redraw()
		wm = context.window_manager
		print("- arma: stop executed")
		ARMD.last_state = STATE_NOTHING
		ARMD.next_state = STATE_NOTHING
		if ARMD.active_timer is not None:
			wm.event_timer_remove(ARMD.active_timer)
			ARMD.active_timer = None

# class wplarmd_railedtra(bpy.types.Operator):
# 	bl_idname = "mesh.wplarmd_railedtra"
# 	bl_label = "Railed displacement"
# 	bl_options = {'REGISTER', 'UNDO'}

# 	opt_smoothLoops : IntProperty(
# 		name="Smoothing loops",
# 		min=0, max=100,
# 		default=5,
# 	)
# 	opt_lerpAxisAlso : BoolProperty(
# 		name="With axis twist",
# 		default=True
# 	)
# 	opt_lerpFromStrt : BoolProperty(
# 		name="Reinforce rail starts",
# 		default=False
# 	)
# 	opt_weightByDist : FloatProperty(
# 		name="Re-weight by distance",
# 		min=0.0, max=10,
# 		default=0.0,
# 	)
# 	def execute( self, context ):
# 		active_obj = wla.active_object(['MESH'])
# 		if active_obj is None:
# 			self.report({'ERROR'}, "Select mesh object first")
# 			return {'FINISHED'}
# 		active_mesh = active_obj.data
# 		selverts = wla.selected_vertsIdx(active_mesh)
# 		seledgs = wla.selected_edgesIdx(active_mesh)
# 		if len(selverts) == 0:
# 			self.report({'ERROR'}, "No selected verts found")
# 			return {'FINISHED'}
# 		camera_gCo, camera_gOrtho, camera_gDir, camera_gDirUp = wla.active_camera()
# 		wla_do.select_and_change_mode(active_obj, 'EDIT' )
# 		context.tool_settings.mesh_select_mode = (True, False, False) # 'VERT'
# 		bm = bmesh.from_edit_mesh(active_mesh)
# 		bm.verts.ensure_lookup_table()
# 		bm.faces.ensure_lookup_table()
# 		bm.verts.index_update()
# 		if len(seledgs) == 0:
# 			# auto-adding rails from selected tips
# 			vertGuides = wla_bm.bm_vertsCollectGuides(bm, selverts, 'WIRE', 100)
# 			if vertGuides is None:
# 				self.report({'ERROR'}, "Can`t collect guides")
# 				return {'FINISHED'}
# 			for line in vertGuides:
# 				for vIdx in line:
# 					if vIdx not in selverts:
# 						selverts.append(vIdx)
# 		(_, vertsWeight, _, _) = wla_bm.bm_vertsPropagations_v02(bm, selverts, self.opt_smoothLoops)
# 		# vertsWeight - by merged selection, not "per rail"
# 		verts2del = []
# 		stepsInRail = 999
# 		vertsInRail = []
# 		for vIdx in selverts:
# 			vertsWeight[vIdx] = 1.0
# 		# getting wire edges as reailing steps
# 		for vIdx in selverts:
# 			v = bm.verts[vIdx]
# 			if len(v.link_edges) == 1:
# 				# finish point! getting back
# 				vlist = [ (vIdx, copy.copy(v.co)) ]
# 				cur_e = v.link_edges[0]
# 				while cur_e is not None:
# 					#print("vlist",vlist)
# 					vLast = bm.verts[ vlist[-1][0] ]
# 					if vLast.index in vertsWeight:
# 						# should not be there - except very first
# 						del vertsWeight[vLast.index]
# 						verts2del.append(vLast)
# 					vNext = cur_e.other_vert(vLast)
# 					cur_e_next = None
# 					if len(vNext.link_edges) == 2:
# 						if vNext.link_edges[0] == cur_e:
# 							cur_e_next = vNext.link_edges[1]
# 						else:
# 							cur_e_next = vNext.link_edges[0]
# 					cur_e = cur_e_next
# 					vlist.append( (vNext.index, copy.copy(vNext.co)) )
# 				vlist = list(reversed(vlist))
# 				stepsInRail = min(len(vlist), stepsInRail)
# 				vertsInRail.append(vlist)
# 		if len(vertsInRail) == 0:
# 			self.report({'ERROR'}, "No rail/wire edges found")
# 			return {'FINISHED'}
# 		# getting matrix per each vertex in rail
# 		axis4rail = {}
# 		for step_i in range(stepsInRail):
# 			for rail_i in range( len(vertsInRail) ):
# 				rail_cos = vertsInRail[rail_i]
# 				#v1_idx = rail_vIdxs[step_i][0]
# 				#v1_co = bm.verts[v1_idx].co
# 				v1_co = rail_cos[step_i][1]
# 				v2_co = None
# 				y_scale = 1.0
# 				if step_i < stepsInRail-1:
# 					#v2_co = bm.verts[rail_vIdxs[step_i+1]].co
# 					v2_co = rail_cos[step_i+1][1]
# 				else:
# 					y_scale = -1.0
# 					#v2_co = bm.verts[rail_vIdxs[step_i-1]].co
# 					v2_co = rail_cos[step_i-1][1]
# 				ax_y = (v2_co-v1_co).normalized()*y_scale
# 				ax_x = None
# 				if len(vertsInRail) == 1:
# 					# one rail-line... using LocalZ
# 					# if ax_tang_fisrt is None:# only first step!!! to avoid extra-twisting
# 					# 	#ax_tang_fisrt = ax_y.cross( Vector((0,0,1)) )
# 					# 	v1_f_nrm = wla_vgs.srcbvh_orientToSurroundFaces(active_obj, v1_idx, None, None)
# 					# 	ax_tang_fisrt = v1_f_nrm.cross(ax_y)
# 					ax_x = ax_y.cross(camera_gDirUp) # Vector((0,0,1))
# 					#ax_x = ax_tang_fisrt
# 				else:
# 					# many rails... using dir on next rail, same step
# 					#v3Idx = vertsInRail[ (rail_i+1)%len(vertsInRail) ][step_i]
# 					#v3_co = bm.verts[v3Idx].co
# 					v3_co = vertsInRail[ (rail_i+1)%len(vertsInRail) ][step_i][1]
# 					ax_x = (v3_co-v1_co).normalized()
# 				ax_z = ax_x.cross(ax_y).normalized()
# 				ax_x = ax_z.cross(ax_y).normalized()
# 				step_key = str(step_i)+"_"+str(rail_i)
# 				axis4rail[step_key] = ( copy.copy(v1_co), ax_x, ax_y, ax_z )
# 		if False: # DBG: selecting affected
# 			for vIdx in vertsWeight.keys():
# 				vT = bm.verts[vIdx]
# 				vT.select = True
# 			bmesh.update_edit_mesh(active_mesh)
# 			wla_do.select_and_change_mode(active_obj, 'EDIT' )
# 			return {'FINISHED'}
# 		# WAS: precalcing distance weight (to starts of rails)
# 		# - problematic, weight should FOLLOW the track 
# 		# - or movements will keep initial weight field -> Looks BAD
# 		if self.opt_weightByDist > 0.0001:
# 			# for irregular edgenet distance weight gives more consistent results
# 			skips = 0
# 			for vIdx in vertsWeight.keys():
# 				if vertsWeight[vIdx] > 0.99:
# 					# no need to re-weight
# 					continue
# 				v = bm.verts[vIdx]
# 				allmax_dst = 0
# 				allmin_dst = 999
# 				# precalcing distances for weight calculations
# 				for ini_vIdx in selverts:
# 					if ini_vIdx not in vertsWeight:
# 						# wire edges should not affect re-weighting
# 						continue
# 					rail_v = bm.verts[ini_vIdx]
# 					dist = (rail_v.co - v.co).length
# 					allmax_dst = max(allmax_dst, dist)
# 					allmin_dst = min(allmin_dst, dist)
# 				if allmin_dst > self.opt_weightByDist:
# 					vertsWeight[vIdx] = 0.0
# 					skips = skips+1
# 					continue
# 				v_wei = 1.0 - (EPS+allmin_dst) / (EPS+self.opt_weightByDist)
# 				vertsWeight[vIdx] = v_wei
# 			print("- reweighted by distance. skipped", skips)
# 		# loops from vert to first vert in rail
# 		vertsWeightPerRail = {}
# 		if self.opt_lerpFromStrt:
# 			vertsCache = {}
# 			for vIdx in vertsWeight.keys():
# 				v = bm.verts[vIdx]
# 				step_i = 0
# 				for rail_i in range( len(vertsInRail) ):
# 					rail_vIdx0 = vertsInRail[rail_i][step_i][0]
# 					vR = bm.verts[rail_vIdx0]
# 					vvr_key = str(vIdx)+"_"+str(rail_i)
# 					loops = wla_edger.edgeVert2VertDst(vR, v, self.opt_smoothLoops, vertsCache, self.opt_smoothLoops+1.0)
# 					vertsWeightPerRail[vvr_key] = 1.0 - loops/(self.opt_smoothLoops+1.0)
# 		# final interpolations
# 		allmax_dst = None
# 		allmin_dst = None
# 		for step_i in range(stepsInRail-1):
# 			# saving positions - important for cross directions to avoid walk-order-dependency
# 			v_co_ini = {}
# 			for vIdx in vertsWeight.keys():
# 				v = bm.verts[vIdx]
# 				ini_pos = copy.copy(v.co)
# 				v_co_ini[vIdx] = ini_pos
# 			# v2: and precalcing distances for weight calculations
# 			# using distance weight to END of previous step -> better results
# 			allmax_dst = None
# 			if (allmax_dst is None) or (allmin_dst is None):
# 				allmax_dst = 0
# 				allmin_dst = 999
# 				for vIdx in vertsWeight.keys():
# 					v = bm.verts[vIdx]
# 					ini_pos = copy.copy(v.co)
# 					for rail_i in range( len(vertsInRail) ):
# 						rail_cos = vertsInRail[rail_i]
# 						#rail_v_co = bm.verts[ rail_vIdxs[step_i+1] ].co
# 						rail_v_co = rail_cos[step_i+1][1]
# 						dist = (rail_v_co - ini_pos).length
# 						allmax_dst = max(allmax_dst, dist)
# 						allmin_dst = min(allmin_dst, dist)
# 				print("- rail step:", step_i+1, "minDist", allmin_dst, "maxDist", allmax_dst)
# 			for vIdx in vertsWeight.keys():
# 				infl = vertsWeight[vIdx]
# 				if infl < 0.001:
# 					continue
# 				v = bm.verts[vIdx]
# 				ini_pos = v_co_ini[vIdx]
# 				vShifts_pos = []
# 				vShifts_w = []
# 				for rail_i in range( len(vertsInRail) ):
# 					step_key = str(step_i)+"_"+str(rail_i)
# 					stepNext_key = str(step_i+1)+"_"+str(rail_i)
# 					axisFrom = axis4rail[step_key]
# 					axisTo = axis4rail[stepNext_key]
# 					matFrom = wla.math_matrix4axis(axisFrom[0], axisFrom[1], axisFrom[2], axisFrom[3])
# 					if matFrom is None:
# 						print("- failed to get custom axis matrix (matFrom)", step_key, "->", stepNext_key, axisFrom[0], axisFrom[1], axisFrom[2], axisFrom[3])
# 						continue
# 					matTo = None
# 					if self.opt_lerpAxisAlso:
# 						matTo = wla.math_matrix4axis(axisTo[0], axisTo[1], axisTo[2], axisTo[3])
# 					else:
# 						matTo = wla.math_matrix4axis(axisTo[0], axisFrom[1], axisFrom[2], axisFrom[3])
# 					if matTo is None:
# 						print("- failed to get custom axis matrix (matTo)", step_key,  "->", stepNext_key, axisTo[0], axisFrom[1], axisFrom[2], axisFrom[3])
# 						continue
# 					dist = (axisFrom[0]-ini_pos).length
# 					v_local_w = (allmax_dst - dist)
# 					if abs(allmax_dst-allmin_dst) > EPS:
# 						v_local_w = 1.0 - (dist-allmin_dst) / (EPS+allmax_dst-allmin_dst)
# 					vvr_key = str(vIdx)+"_"+str(rail_i)
# 					if vvr_key in vertsWeightPerRail:
# 						# verts should not be affected by rails not in contact
# 						# initial weights are for TOTAL loops dist from selection
# 						v_local_w = v_local_w * vertsWeightPerRail[vvr_key]
# 					# if v_local_w < 0:
# 					# 	# AMUST is 2 rail points (due cross-directional madness/blow)
# 					# 	# not happen if min/max distance calcualted for all verts in step
# 					# 	continue
# 					#v_local_w = vert2railTip[vIdx] # fixed initial weights
# 					v_local_from = matFrom.inverted() @ ini_pos
# 					v_local_to = matTo @ v_local_from
# 					vShifts_pos.append(v_local_to-ini_pos)
# 					vShifts_w.append(v_local_w)
# 				if len(vShifts_pos) == 0:
# 					# no good verts...
# 					continue
# 				nx = vShifts_pos[0][0]
# 				ny = vShifts_pos[0][1]
# 				nz = vShifts_pos[0][2]
# 				if np.sum(vShifts_w) > 0:
# 					#print("- variants", v.index, vShifts_pos, vShifts_w)
# 					nx = np.average([itm[0] for itm in vShifts_pos], weights=vShifts_w)
# 					ny = np.average([itm[1] for itm in vShifts_pos], weights=vShifts_w)
# 					nz = np.average([itm[2] for itm in vShifts_pos], weights=vShifts_w)
# 				# if self.opt_steppingPow > 0:
# 				# 	infl = infl * math.pow(1.0 - float(step_i)/float(stepsInRail), self.opt_steppingPow)
# 				v.co = ini_pos + Vector((nx, ny, nz))*infl
# 				#print("- vert:", v.index, vShifts_pos, vShifts_w)
# 		bmesh.ops.delete(bm, geom=verts2del, context='VERTS')
# 		bmesh.update_edit_mesh(active_mesh)
# 		wla_do.select_and_change_mode(active_obj, 'EDIT' )
# 		self.report({'INFO'}, "Railing finished, rails: "+str(len(vertsInRail)))
# 		return {'FINISHED'}

# def WPL_CurveMappingMod(context, canCreate):
# 	cw_obj = wla.object_by_name(kWPLHookDeformerTemp)
# 	if cw_obj is None and canCreate:
# 		active_obj = wla.active_object()
# 		if active_obj is not None:
# 			wla_do.select_and_change_mode(active_obj, 'OBJECT')
# 		wla_do.find_last_changed_objects(False)
# 		bpy.ops.mesh.primitive_grid_add(x_subdivisions=1, y_subdivisions=1, size=1.0, align='WORLD', location=Vector((0,0,0)), rotation=(0, 0, 0), scale=(1, 1, 1))
# 		dups = wla_do.find_last_changed_objects(True)
# 		cw_obj = dups[0]
# 		cw_obj.name = kWPLHookDeformerTemp
# 		sysempty = wla.sys_empty(config.kWPLSystemObjShapes)
# 		wla_do.link_object_to_scene(cw_obj, sysempty, 2)
# 	if cw_obj is None:
# 		return None
# 	cw_mod = wla.modf_by_type(cw_obj, None, "wpl_ui_curvtmp")
# 	if cw_mod is None and canCreate:
# 		cw_mod = cw_obj.modifiers.new("wpl_ui_curvtmp", 'HOOK')
# 		cw_mod.falloff_type = 'CURVE'
# 	return cw_mod

# class wplarmd_loopprofs_reset(bpy.types.Operator):
# 	bl_idname = "mesh.wplarmd_loopprofs_reset"
# 	bl_label = "LoopProfile: reset"
# 	bl_options = {'REGISTER', 'UNDO'}

# 	def execute( self, context ):
# 		# https://docs.blender.org/api/current/bpy.types.CurveMapping.html#bpy.types.CurveMapping
# 		cw_mod = WPL_CurveMappingMod(context, True)
# 		pts = cw_mod.falloff_curve.curves[0].points
# 		pts[0].location = (0.0, 0.5)
# 		pts[-1].location = (1.0, 0.5)
# 		if len(pts) > 0:
# 			for i in range(1, len(pts)-1):
# 				pts[i].location = (pts[i].location[0], 0.5)
# 		cw_mod.falloff_curve.update()
# 		return {'FINISHED'}

class wplarmd_loopprofs_use(bpy.types.Operator):
	bl_idname = "mesh.wplarmd_loopprofs_use"
	bl_label = "LoopProfile: activate on selection"
	bl_options = {'REGISTER', 'UNDO'}

	opt_cuhInfluence : StringProperty(
		name="Influence CUH",
		default = '16961'
	)
	opt_inverseLoops : BoolProperty(
		name="Reverse curve",
		default=False
	)
	opt_baseDir : EnumProperty(
		name="Up Direction", default="ORIG_ALL",
		items=(	
			("CURSOR_ORIENT", "Cursor Orientation", ""),
			("ORIG_ALL", "Vert, avg all", ""),
			("ORIG_TIPS", "Vert, avg tips", ""),
			("TOVIEW_TIPS", "To View Up", ""),
			("TOCAM_TIPS", "To Camera", ""),
			("TOCAM_INDIV", "Camera, per vert", ""), 
		)
	)
	opt_upDist : FloatProperty(
		name="Additional height",
		min=-10.0, max=10,
		default=0.03,
	)
	opt_upOrigScale : FloatProperty(
		name="Original height",
		min=-10.0, max=10,
		default=1.00,
	)
	opt_evenDistribAlong : FloatProperty(
		name="Distribute along line",
		min=0, max=1,
		default=0.0,
	)
	opt_proportionalDst : FloatProperty(
		name="Smoothing Distance",
		min=0, max=100,
		default = 0.0,
	)
	opt_cuhProportional : StringProperty(
		name="Smoothing Factor CUH",
		default="951",
	)
	opt_influence : FloatProperty(
		name="Influence",
		min=-10, max=10,
		default = 1.0,
	)

	def resetOpts(self):
		self.opt_evenDistribAlong = 0
		self.opt_upOrigScale = 0.0
		self.opt_upDist = 0.0
		self.opt_proportionalDst = 0.0
		self.opt_cuhProportional = "951"
		self.opt_influence = 1.0
		return

	def execute( self, context ):
		#cw_mod = WPL_CurveMappingMod(context, True)
		active_obj = wla.active_object(['MESH'])
		if active_obj is None:
			self.resetOpts()
			self.report({'ERROR'}, "Select mesh object first")
			return {'FINISHED'}
		if len(self.opt_cuhInfluence) == 0:
			wpl_armdOpts = context.scene.wpl_armdOpts
			self.opt_cuhInfluence = wpl_armdOpts.opt_loopprofile_curvehash
			self.opt_upDist = wpl_armdOpts.opt_loopprofile_curvehei
		def sampleCwMod(rel_pt):
			# cw_mod_sampler = cw_mod.falloff_curve
			# cwfac = cw_mod_sampler.evaluate(cw_mod_sampler.curves[0], rel_pt)
			cwfac = wla.remap_curve_hash(self.opt_cuhInfluence, rel_pt)
			# cwfac = (cwfac-0.5)*2.0 # remapping [0.0, 1.0] to [-1.0, 1.0]
			return cwfac
		camera_gCo, camera_gOrtho, camera_gDir, camera_gDirUp = wla.active_camera()
		matrix_world = active_obj.matrix_world
		matrix_world_nrml = active_obj.matrix_world.inverted().transposed().to_3x3()
		bm, strands_vidx = wla_meshwrap.objectm_selection_to_bmStrands(active_obj)
		if strands_vidx is None:
			self.resetOpts()
			wla_do.select_and_change_mode(active_obj,'EDIT')
			self.report({'ERROR'}, "No edges found")
			return {'FINISHED'} # or all changes get lost!!!
		print("- loops found", len(strands_vidx))
		vertsShift = {}
		vertsIniCo = {}
		for v in bm.verts:
			vertsIniCo[v.index] = v.co.copy()
		for i in range(len(strands_vidx)):
			vidx_es = strands_vidx[i]
			if self.opt_inverseLoops:
				vidx_es = list(reversed(vidx_es))
			#baseMaxUp = 0.0
			curve_cache = {}
			curve_nrms = []
			curve_nrmavg = Vector((0,0,0))
			for vIdx in vidx_es:
				v = bm.verts[vIdx]
				v_co = copy.copy(v.co)
				v_dist = wla.math_lerpCurveAdd(v_co, [v_co], curve_cache)
				curve_cache[vIdx] = v_dist
				curve_nrm = Vector((0,0,0)) 
				for f in v.link_faces:
					curve_nrm = curve_nrm+f.normal
				curve_nrm = curve_nrm.normalized()
				curve_nrmavg = curve_nrmavg+curve_nrm
				curve_nrms.append(curve_nrm)
				#baseMaxUp = max(baseMaxUp, abs(mathutils.geometry.distance_point_to_plane(v_co, vF_co, baseNormal)))
			if curve_cache["len"] < 0.0001:
				print("- invalid curve found (len == 0)")
				continue
			# base triangle - forst, last, averaged normal
			vF = bm.verts[vidx_es[0]]
			vF_co = vF.co
			vL = bm.verts[vidx_es[-1]]
			vF_co = copy.copy(vF.co)
			vL_co = copy.copy(vL.co)
			# baseFlowDir = (vL_co-vF_co).normalized()
			baseUpDir = curve_nrms[0]
			if self.opt_baseDir == 'CURSOR_ORIENT':
				if wla.active_context_orient() is not None:
					orientation = wla.active_context_orient().matrix
					baseUpDir =  matrix_world_nrml.inverted() @ (orientation @ Vector(( 0, 0, 1)))
					print("- baseUpDir CURSOR_ORIENT", baseUpDir)
			if self.opt_baseDir == 'ORIG_TIPS':
				baseUpDir = (curve_nrms[0]+curve_nrms[-1]).normalized()
				print("- baseUpDir ORIG_TIPS", baseUpDir)
			if self.opt_baseDir == 'ORIG_ALL':
				baseUpDir = curve_nrmavg.normalized()
				print("- baseUpDir ORIG_ALL", baseUpDir)
			if self.opt_baseDir == 'TOCAM_TIPS' or self.opt_baseDir == 'TOCAM_INDIV':
				if camera_gOrtho:
					baseUpDir = matrix_world_nrml.inverted() @ camera_gDir
				else:
					baseUpDir = ((matrix_world.inverted() @ camera_gCo) - ((vL_co+vF_co)*0.5)).normalized()
			if self.opt_baseDir == 'TOVIEW_TIPS':
				region, _ = wla.active_view_region()
				baseUpDir = matrix_world_nrml.inverted() @ (region.view_rotation @ Vector((0.0, 1.0, 0.0)))
			# baseTangent = baseFlowDir.cross(baseUpDir)
			# baseUpDir = baseTangent.cross(baseFlowDir)
			for i,vIdx in enumerate(vidx_es):
				v = bm.verts[vIdx]
				v_refp = curve_cache[vIdx]/curve_cache["len"]
				v_ev_refp = float(i)/float(len(vidx_es)-1)
				if self.opt_evenDistribAlong > 0.0:
					v_ed_co = wla.math_lerpCurveGet(v_ev_refp, 0, curve_cache)
					v_refp = wla.math_lerp1D(self.opt_evenDistribAlong, v_refp, v_ev_refp)
					v.co = v.co.lerp(v_ed_co, self.opt_evenDistribAlong)
				v_upfac = sampleCwMod(v_refp)
				v_co_proj = vF_co.lerp(vL.co, v_refp)
				baseNormal = baseUpDir
				if self.opt_baseDir == 'TOCAM_INDIV':
					# getting per-vert direction to Camera
					if camera_gOrtho:
						baseNormal = matrix_world_nrml.inverted() @ camera_gDir
					else:
						baseNormal = ((matrix_world.inverted() @ camera_gCo) - v_co_proj).normalized()
				v_updist = abs(self.opt_upDist)
				if self.opt_upDist < 0:
					baseNormal = -1 * baseNormal
				v_shiftIni = vertsIniCo[v.index]-v_co_proj
				v_co_new = v_co_proj + (self.opt_upOrigScale * v_shiftIni) + (baseNormal *  v_updist * v_upfac)
				v.co = v.co.lerp(v_co_new, self.opt_influence)
				vertsShift[v.index] = v.co - vertsIniCo[v.index]
		bm.normal_update()
		bmesh.update_edit_mesh(active_obj.data)
		if self.opt_proportionalDst > 0:
			pttree = KDTree(1000)
			for vIdx in vertsShift:
				v = bm.verts[vIdx]
				#pttree.insert(v.co, v.index)
				pttree.insert(vertsIniCo[v.index], v.index)
			pttree.balance()
			shifts2 = 0
			for v in bm.verts:
				if v.index in vertsShift:
					continue
				if v.hide:
					continue
				pts_dat = pttree.find_range(v.co, self.opt_proportionalDst)
				if (pts_dat is None) or len(pts_dat) == 0:
					continue
				# averaging shifts and influence
				weights = []
				shifts = []
				for pt_itm in pts_dat:
					pt_vIdx = pt_itm[1]
					pt_w = 1.0 - (pt_itm[2]/self.opt_proportionalDst)
					weights.append(pt_w)
					pt_sh = vertsShift[pt_vIdx] * wla.remap_curve_hash(self.opt_cuhProportional, 1.0-pt_w)
					shifts.append(pt_sh)
				nx = np.average([itm[0] for itm in shifts], weights=weights)
				ny = np.average([itm[1] for itm in shifts], weights=weights)
				nz = np.average([itm[2] for itm in shifts], weights=weights)
				v.co = v.co + Vector((nx,ny,nz))
				shifts2 = shifts2+1
			print("- proportionally shifted:", shifts2)
			bm.normal_update()
			bmesh.update_edit_mesh(active_obj.data)
		return {'FINISHED'}

class wplarmd_viewlattice(bpy.types.Operator):
	bl_idname = "mesh.wplarmd_viewlattice"
	bl_label = "Lattice editing"
	bl_options = {'REGISTER', 'UNDO'}

	opt_action : EnumProperty(
		name="Action", default="CAMERA",
		items=(
			("OBJECT", "Add, Object orienataion", ""), 
			("CAMERA", "Add, Camera orientation", ""),
			("VIEW", "Add, View orientation", ""),
			("APPLY", "Apply active", ""),
			("CANCEL", "Cancel active", ""),
			("RESETDEFRM", "Reset deformations", ""),
		)
	)

	opt_affectGridOnly: BoolProperty(
		name="Affect grid only",
		default=False
	)

	def invoke( self, context, event ):
		modname_latt = config.kWPLMeshDeformMod
		modname_shcage = config.kWPLMeshDeformMod + kWPLMeshDeformShCageMod
		if self.opt_action == 'RESETDEFRM':
			active_obj = wla.active_object(['LATTICE'])
			if active_obj is not None:
				uvw = (active_obj.data.points_u, active_obj.data.points_v, active_obj.data.points_w)
				active_obj.data.points_u = 2 if uvw[0]>1 else 1
				active_obj.data.points_v = 2 if uvw[1]>1 else 1
				active_obj.data.points_w = 2 if uvw[2]>1 else 1
				wla_do.sys_update_mesh(active_obj)
				# wla_do.sys_update_view(True, True)
				active_obj.data.points_u = uvw[0]
				active_obj.data.points_v = uvw[1]
				active_obj.data.points_w = uvw[2]
				wla_do.sys_update_mesh(active_obj)
				return {'FINISHED'}
		if self.opt_action in ['APPLY', 'CANCEL']:
			src_obj = None
			active_obj = wla.active_object(['LATTICE'])
			if (active_obj is not None) and (config.kWPLMeshDeformMod in active_obj):
				src_obj_name = active_obj[config.kWPLMeshDeformMod]
				src_obj = wla.object_by_name(src_obj_name)
			if (src_obj is not None) and (config.kWPLMeshDeformMod in active_obj):
				wla_do.select_and_change_mode(src_obj, "OBJECT")
				isFakeUser = src_obj.data.use_fake_user
				if isFakeUser:
					# disabling before apply - important for versioned mesh/gpencil objects
					src_obj.data.use_fake_user = False
					wla_do.sys_update_mesh(src_obj)
					print("- temporary disable fake user")
				if src_obj.type == 'GPENCIL':
					prevModifier = wla.modf_by_type(src_obj, None, modname_latt)
					if prevModifier is not None:
						if self.opt_action == 'CANCEL':
							src_obj.grease_pencil_modifiers.remove(prevModifier)
						else:
							bpy.ops.object.gpencil_modifier_apply(modifier=modname_latt)
				else:
					prevModifier = wla.modf_by_type(src_obj, None, modname_latt)
					if prevModifier is not None:
						if self.opt_action == 'CANCEL':
							src_obj.modifiers.remove(prevModifier)
						else:
							bpy.ops.object.modifier_apply(modifier=modname_latt)
				if isFakeUser:
					print("- restoring fake user")
					src_obj.data.use_fake_user = True
				wla_attr.vg_remove(src_obj, config.kWPLObjDefrmPostfix)
				prevModifier = src_obj.modifiers.get(modname_shcage)
				if prevModifier is not None:
					shcage_object = prevModifier.target
					if self.opt_action == 'CANCEL':
						src_obj.modifiers.remove(prevModifier)
					else:
						bpy.ops.object.modifier_apply(modifier=modname_shcage)
					bpy.data.objects.remove(shcage_object, do_unlink=True)
				wla_do.modf_toggle(src_obj, ['show_wire'], None, ARMD.target_cache)
			if (src_obj is not None) and (config.kWPLMeshDeformMod in active_obj):
				bpy.data.objects.remove(active_obj, do_unlink=True)
				wla_do.select_and_change_mode(src_obj, "EDIT")
			else:
				# just any lattice, do nothing
				wla_do.select_and_change_mode(active_obj, "OBJECT")
			wla_do.switch_orientation('LOCAL', 'MEDIAN_POINT')
			return {'FINISHED'}
		if self.opt_action in ["CAMERA", "VIEW"]:
			wla_do.switch_orientation('VIEW', 'MEDIAN_POINT')
		v_maxsize_g = 0
		v_center_g = Vector((0,0,0))
		active_obj = wla.active_object()
		if (active_obj is not None) and active_obj.type in ['CURVE', 'GPENCIL']:
			if self.opt_affectGridOnly:
				self.report({'ERROR'}, "View+Grid: not possible for curve")
				return {'CANCELLED'}
			# simple case for curve
			selvertsAll = []
			wla_do.select_and_change_mode(active_obj,'EDIT')
			(selected_polys_all, selected_polys_sel, selected_polys_cu) = wla_curve.cu_getSelectedStrokes(active_obj, True, True)
			selected_polys = selected_polys_sel
			if len(selected_polys) == 0:
				selected_polys = selected_polys_all
			#print("- selected_polys_sel", selected_polys_sel, selected_polys_all, selected_polys_cu)
			wla_attr.vg_remove(active_obj, config.kWPLObjDefrmPostfix)
			for sel_pts in selected_polys:
				for pt in sel_pts:
					pt_co = Vector((pt.co[0], pt.co[1], pt.co[2]))
					selvertsAll.append(pt_co)
					v_co_g = active_obj.matrix_world @ pt_co
					v_center_g = v_center_g + v_co_g
			if len(selvertsAll) == 0:
				self.report({'ERROR'}, "No points in curve")
				return {'CANCELLED'}
			v_center_g = v_center_g/len(selvertsAll)
			for pt_co in selvertsAll:
				v_co_g = active_obj.matrix_world @ pt_co
				v_maxsize_g = max(v_maxsize_g, (v_co_g-v_center_g).length )
			if active_obj.type == 'GPENCIL' and len(selected_polys_cu) > 0:
				vg = wla_attr.vg_get_or_new(active_obj, config.kWPLObjDefrmPostfix)
				for spine in selected_polys_cu:
					for i, pt in enumerate(spine.points):
						if pt.select:
							spine.points.weight_set(vertex_group_index=vg.index, point_index=i, weight=1.0)
		if (active_obj is not None) and active_obj.type in ['MESH']:
			active_obj_nonoperable = wla.is_object_nonoperable(active_obj, None)
			if active_obj_nonoperable is not None:
				print("- problem:", active_obj_nonoperable)
				self.report({'ERROR'}, "Object not ready:" + active_obj_nonoperable)
				return {'CANCELLED'}
			active_mesh = active_obj.data
			selvertsAll = wla.selected_vertsIdx(active_mesh)
			if len(selvertsAll) == 0:
				self.report({'ERROR'}, "No selected verts found")
				return {'FINISHED'}
			for vIdx in selvertsAll:
				v = active_obj.data.vertices[vIdx]
				v_co_g = active_obj.matrix_world @ v.co
				v_center_g = v_center_g + v_co_g
			v_center_g = v_center_g/len(selvertsAll)
			for vIdx in selvertsAll:
				v = active_obj.data.vertices[vIdx]
				v_co_g = active_obj.matrix_world @ v.co
				v_maxsize_g = max(v_maxsize_g, (v_co_g-v_center_g).length )
			# adding VG for later use in lattice modifier (by name)
			wla_attr.vg_remove(active_obj, config.kWPLObjDefrmPostfix)
			wla_attr.vg_add_verts2vg(active_obj, config.kWPLObjDefrmPostfix, selvertsAll, 1.0)
		if v_maxsize_g < 0.001:
			self.report({'ERROR'}, "Zero size, nothing to do")
			return {'CANCELLED'}
		deformer_name = config.kWPLSuppZZZZPrefix + active_obj.name + config.kWPLObjDefrmPostfix
		shcage_object = None
		if self.opt_affectGridOnly and active_obj.type == 'MESH':
			# making copy without modifiers for shrinkwrapping
			deformer_cage_name = deformer_name + kWPLMeshDeformShCageMod
			shcage_data = active_obj.data.copy()
			shcage_object = bpy.data.objects.new(name=deformer_cage_name, object_data=shcage_data)
			wla_do.link_object_sideBySide(shcage_object, active_obj)
			shcage_object.hide_viewport = True
		wla_do.modf_toggle(active_obj, ['show_wire'], True, ARMD.target_cache)
		lattice_data = bpy.data.lattices.new(name=deformer_name)
		lattice_object = bpy.data.objects.new(name=deformer_name, object_data=lattice_data)
		lattice_data.points_u = int(7)
		lattice_data.points_v = int(1)
		lattice_data.points_w = int(7)
		if active_obj.type == 'EMPTY':
			wla_do.link_object_to_scene(lattice_object, active_obj, 2)
		else:
			wla_do.link_object_sideBySide(lattice_object, active_obj)
		#v_maxsize_ll =  (active_obj.matrix_world.inverted() @ Vector((v_maxsize_g, 0, 0))).length
		print("- Local lattice: size", v_maxsize_g)
		aLoc, aRot, aSca = lattice_object.matrix_world.decompose()
		aSca = (v_maxsize_g*2.0,v_maxsize_g*2.0,v_maxsize_g*2.0)
		if v_center_g is not None:
			aLoc = v_center_g
		lattice_object.matrix_world = Matrix.LocRotScale(aLoc, aRot, aSca)
		lattice_object.show_in_front = True
		deformer_object = lattice_object
		if self.opt_action == 'CAMERA':
			camera_obj = wla.object_by_name(config.kWPLSystemMainCam)
			if camera_obj is not None:
				followCon = deformer_object.constraints.new('TRACK_TO')
				followCon.track_axis = 'TRACK_Y'
				followCon.up_axis = 'UP_Z'
				followCon.target = camera_obj
		if self.opt_action == 'VIEW':
			# PY: view-orientation-3axis
			# https://gist.github.com/PauloBarbeiro/3524535f1c583d18d9ede0359a45b784
			region, _ = wla.active_view_region()
			axisZ_g = (region.view_rotation @ Vector((0.0, 0.0, 1.0)))
			axisY_g = (region.view_rotation @ Vector((0.0, 1.0, 0.0)))
			axisX_g = (region.view_rotation @ Vector((1.0, 0.0, 0.0)))
			rotMt = Matrix((axisY_g, axisZ_g, axisX_g))
			rotMt.transpose()
			rotMt.normalize()
			rotMt = rotMt.to_4x4()
			deformer_object.matrix_world = wla.math_matrixReplace(deformer_object.matrix_world, None, rotMt, None)
		if active_obj.type == 'GPENCIL':
			prevModifier = wla.modf_by_type(active_obj, None, modname_latt)
			if prevModifier is not None:
				active_obj.grease_pencil_modifiers.remove(prevModifier)
			meshdef_modifier = active_obj.grease_pencil_modifiers.new(name = modname_latt, type = 'GP_LATTICE')
			meshdef_modifier.object = deformer_object
			meshdef_modifier.show_in_editmode = True
			if wla_attr.vg_get_by_name(active_obj, config.kWPLObjDefrmPostfix) is not None:
				meshdef_modifier.vertex_group = config.kWPLObjDefrmPostfix
			wla_do.modf_sendBackByName(active_obj, meshdef_modifier.name, False)
		else:
			prevModifier = wla.modf_by_type(active_obj, None, modname_latt)
			if prevModifier is not None:
				active_obj.modifiers.remove(prevModifier)
			meshdef_modifier = active_obj.modifiers.new(name = modname_latt, type = 'LATTICE')
			meshdef_modifier.object = deformer_object
			meshdef_modifier.show_in_editmode = True
			meshdef_modifier.show_on_cage = True
			meshdef_modifier.use_apply_on_spline = True
			if wla_attr.vg_get_by_name(active_obj, config.kWPLObjDefrmPostfix) is not None:
				meshdef_modifier.vertex_group = config.kWPLObjDefrmPostfix
			# wla_do.modf_sendBackByType(active_obj, 'EDGE_SPLIT')
			# wla_do.modf_sendBackByType(active_obj, 'SUBSURF')
			# MUST be first!!! особенно для GN важно - может мутировать VG/etc
			wla_do.modf_sendBackByName(active_obj, meshdef_modifier.name, False)
			if self.opt_affectGridOnly and shcage_object is not None:
				prevModifier = active_obj.modifiers.get(modname_shcage)
				if prevModifier is not None:
					active_obj.modifiers.remove(prevModifier)
				shrinkwrap_modifier = active_obj.modifiers.new(name = modname_shcage, type = 'SHRINKWRAP')
				shrinkwrap_modifier.offset = 0.0
				shrinkwrap_modifier.target = shcage_object
				shrinkwrap_modifier.wrap_method = 'NEAREST_SURFACEPOINT'
				shrinkwrap_modifier.wrap_mode = 'ABOVE_SURFACE'
				shrinkwrap_modifier.show_in_editmode = True
				shrinkwrap_modifier.use_apply_on_spline = True
		wla_do.select_and_change_mode(deformer_object, "EDIT")
		deformer_object[config.kWPLMeshDeformMod] = active_obj.name
		return {'FINISHED'}

# ==========================================
# ==========================================

class WPL_ARMDMOPTS(bpy.types.PropertyGroup):
	opt_headtail_pow : FloatProperty(
		name="Head-Tail Pow",
		default = 1.0
	)
	opt_headtail_overflow : FloatProperty(
		name="Head-Tail Overflow",
		default = 0.0
	)
	opt_distfalloff_pow : FloatProperty(
		name="Distance Pow",
		default = 3.0
	)

	# opt_collidermod : EnumProperty(
	# 	items = [
	# 		('IGNORE', "Ignore", ""),
	# 		('DST_KEEP', "Keep distance", ""),
	# 		('DST_CLAMP', "Stop penetration", ""),
	# 	],
	# 	name="Colliders",
	# 	default='IGNORE',
	# )

	# LoopProfile options
	opt_loopprofile_curvehash : StringProperty(
		name="Curve Hash",
		default = '169961'
	)
	opt_loopprofile_curvehei : FloatProperty(
		name="Curve Height",
		default = 0.03
	)

class WPL_PT_ArmdPanel1(bpy.types.Panel):
	bl_idname = "WPL_PT_ArmdPanel1"
	bl_label = "Smart Deformers"
	bl_space_type = 'VIEW_3D'
	bl_region_type = 'UI'
	bl_category = "vSel"
	#bl_category = 'Sculpt'

	def draw(self, context):
		layout = self.layout
		wpl_armdOpts = context.scene.wpl_armdOpts
		col = layout.column()
		active_obj = wla.active_object()
		if active_obj is not None and active_obj.type == 'LATTICE' and wla.is_edit_mode():
			from . import ops_tool_pin
			ops_tool_pin.uilayout_lattBox(col, context)
			return
		if ARMD.next_state != STATE_NOTHING:
			box1 = col.box()
			box1.label(text = "ArmaDef: Target: "+ARMD.target_name)
			arma_mode = "???"
			active_arma = None
			if len(ARMD.arma_name) > 0:
				active_arma = wla.object_by_name(ARMD.arma_name)
			if active_arma is not None:
				arma_mode = active_arma.mode
			box1.separator()
			box1.operator("mesh.wplarmd_tickflow", text='Toggle mode (now: '+arma_mode+')').opt_action = 'TOGGLE_AR_MODE'
			box1.operator("mesh.wplarmd_tickflow", text='Apply deformations').opt_action = 'STOP_APPLY'
			# if (arma_mode == 'EDIT'):
			# 	row1 = box1.row()
			# 	if ARMD.defrm_type == 'ARMA':
			# 		row1.operator("mesh.wplarmd_tickflow", text='* Armature').opt_action = 'TOGGLE_DT_ARMA'
			# 		row1.operator("mesh.wplarmd_tickflow", text='Triangle').opt_action = 'TOGGLE_DT_BARI'
			# 	else:
			# 		row1.operator("mesh.wplarmd_tickflow", text='Armature').opt_action = 'TOGGLE_DT_ARMA'
			# 		row1.operator("mesh.wplarmd_tickflow", text='* Triangle').opt_action = 'TOGGLE_DT_BARI'
			# else:
			# 	box1.label(text = 'Deformation type: '+ARMD.defrm_type)
			box1.separator()
			box1.operator("mesh.wplarmd_tickflow", text='Cancel').opt_action = 'STOP_CANCEL'
			box1.separator()
			box1.label(text = "Selected Bones: switch type")
			row1 = box1.row()
			row1.operator("mesh.wplarmd_tickflow", text='TAIL ONLY').opt_action = 'TOGGLE_BN_MODE_DSTROOT_NO'
			row1.operator("mesh.wplarmd_tickflow", text='LIMIT').opt_action = 'TOGGLE_BN_MODE_INFL_MASKER'
			row1 = box1.row()
			row1.operator("mesh.wplarmd_tickflow", text='TAIL&HEAD').opt_action = 'TOGGLE_BN_MODE_DSTROOT'
			row1.operator("mesh.wplarmd_tickflow", text='PUSH').opt_action = 'TOGGLE_BN_MODE_DIR_PUSHER'
			if active_arma is not None:
				box1.separator()
				box1.label(text = "Deformation parameters")
				box1.prop(wpl_armdOpts, "opt_distfalloff_pow", text = "Tightness: Distance")
				if ARMD.defrm_type == 'ARMA':
					box1.prop(wpl_armdOpts, "opt_headtail_pow", text = "Tightness: Head-Tail gradient")
					box1.prop(wpl_armdOpts, "opt_headtail_overflow", text = "Tightness: Perpendicular")
			return

		col.separator()
		box1 = col.box()
		row1 = box1.row()
		op = row1.operator("mesh.wplarmd_viewlattice", text = 'Camera Lattice')
		op.opt_action = "CAMERA"
		op.opt_affectGridOnly = False
		op = row1.operator("mesh.wplarmd_viewlattice", text = 'View Lattice')
		op.opt_action = "VIEW"
		op.opt_affectGridOnly = False
		row1 = box1.row()
		op = row1.operator("mesh.wplarmd_viewlattice", text = 'Local Lattice')
		op.opt_action = "OBJECT"
		op.opt_affectGridOnly = False
		op = row1.operator("mesh.wplarmd_viewlattice", text = 'Edgenet Lattice')
		op.opt_action = "VIEW"
		op.opt_affectGridOnly = True

		box1 = col.box()
		if active_obj is None or active_obj.type != 'MESH' or wla.is_edit_mode() == False:
			box1.label(text = "LoopProfiler: Inactive, need edit mesh")
		else:
			# col.operator("mesh.wplarmd_railedtra", text = 'Railed displacement', icon="PARTICLE_POINT")
			# cw_mod = WPL_CurveMappingMod(context, False)
			# if cw_mod is None:
			# 	row1 = box1.row()
			# 	row1.label(text = "LoopProfiler: Not inited")
			# 	row1.operator("mesh.wplarmd_loopprofs_reset", text = 'Init')
			# 	return
			#box1.template_curve_mapping(cw_mod, "falloff_curve")
			#box1.operator("mesh.wplarmd_loopprofs_reset", text = 'Reset to line')
			box1.label(text = "LoopProfile")
			row1 = box1.row()
			row1.prop(wpl_armdOpts, "opt_loopprofile_curvehash", text="Curve Hash")
			row1.prop(wpl_armdOpts, "opt_loopprofile_curvehei", text="Height")
			row1 = box1.row()
			op = row1.operator("mesh.wplarmd_loopprofs_use", text = 'Apply add')
			op.opt_cuhInfluence = ''
			op.opt_upOrigScale = 1.0
			op = row1.operator("mesh.wplarmd_loopprofs_use", text = 'Apply replace')
			op.opt_cuhInfluence = ''
			op.opt_upOrigScale = 0.0

		box1 = col.box()
		if wla.is_edit_mode() == False:
			box1.label(text = "ArmaDef: inactive, need edit mesh")
		else:
			box1.label(text = "ArmaDef: inactive")
			box1.operator("mesh.wplarmd_tickflow", text = 'Start: Selection+Active').opt_action = 'START_ACTIVE'
			# box1.separator()
			# box1.operator("mesh.wplarmd_tickflow", text = 'Start: Non-hidden').opt_action = 'START_NONHIDDEN'
			# box1.operator("mesh.wplarmd_tickflow", text = 'Start: Cursor -> Active').opt_action = 'START_3DCACTIVE'
			box1.operator("mesh.wplarmd_tickflow", text = 'Start: Selection center').opt_action = 'START_CENTER'
			#box1.operator("mesh.wplarmd_tickflow", text = 'Start: Bari-verts').opt_action = 'START_BARIVERTS' # TOGGLE_DT_BARI
		
		# row1 = box1.row()
		# row1.prop(wpl_armdOpts, "opt_collidermod", text = "Colliders")
		# row1.operator("object.wplheal_tweakobj", text='Mark Colliders', icon = 'PHYSICS').opt_actionType = 'ADDCOL_EXCL'

# ==========================================
# ==========================================

classes = (
	WPL_ARMDMOPTS,
	WPL_PT_ArmdPanel1,
	wplarmd_tickflow,
	#wplarmd_alignarma,
	#wplarmd_railedtra,
	#wplarmd_loopprofs_reset,
	wplarmd_loopprofs_use,
	wplarmd_viewlattice,
)

def register():
	for cls in classes:
		bpy.utils.register_class(cls)
	bpy.types.Scene.wpl_armdOpts = bpy.props.PointerProperty(type=WPL_ARMDMOPTS)

def unregister():
	for cls in reversed(classes):
		bpy.utils.unregister_class(cls)
	del bpy.types.Scene.wpl_armdOpts

if __name__ == "__main__":
	register()