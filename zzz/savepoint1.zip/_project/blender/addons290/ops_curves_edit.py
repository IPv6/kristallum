import os, sys, time, datetime
import math, copy, string, random
import numpy as np
import bpy, bmesh, mathutils
import json

import bpy.types
from mathutils import Vector, Matrix, Euler, Quaternion
from mathutils.bvhtree import BVHTree
from mathutils.kdtree import KDTree
from bpy_extras import view3d_utils
from bpy.props import *

from . import config
from .tools import wla
from .tools import wla_do
from .tools import wla_bm
from .tools import wla_curve
from .tools import wla_attr
from . import ops_prop_edging
from .ops_scene_man import _mix3l, _mix3s, _mix2, _mixArc, _cuh, _rndf

kWPLDefaultBevelProfile = (0.01,0.01,1.0)
kWPLDefaultProfileMulFac = "_mix3s(0.09, 1.0, 0.09, 0.5, facL)"
kWPLDefaultProfileMulLFac = "_mix3s(1.0, 0.7, 0.09, 0.5, facL)"
kWPLDefaultProfileMulRFac = "_mix3s(0.09, 0.7, 1.0, 0.5, facL)"

# ================================

def cu_desel_all(curveObj):
	# if curveObj.type == 'GPENCIL':
	# 	bpy.ops.gpencil.select_all(action='DESELECT') # edit mode only
	# else:
	# 	bpy.ops.curve.select_all(action='DESELECT') # edit mode only
	# Both in edit and object mode:
	splines = wla_curve.cu_getSplines(curveObj)
	for polyline in splines:
		pts = wla_curve.cu_getPoints(polyline)
		for pt in pts:
			wla_curve.cu_setSel(pt,False)

def cu_subd_sel(obj, cuts):
	if obj.type == 'GPENCIL':
		bpy.ops.gpencil.stroke_subdivide(only_selected=False, number_cuts=cuts)
	else:
		bpy.ops.curve.subdivide(number_cuts=cuts)

def cu_delv_sel(obj):
	if obj.type == 'GPENCIL':
		bpy.ops.gpencil.delete(type='POINTS')
	else:
		bpy.ops.curve.delete(type='VERT')

def cu_del_spl(obj, polyline):
	if obj.type == 'GPENCIL':
		curveData = obj.data
		for i1, layer in enumerate(curveData.layers):
			for i2, stroke in enumerate(layer.active_frame.strokes):
				if stroke == polyline:
					layer.active_frame.strokes.remove(stroke)
					return
	else:
		obj.data.splines.remove(polyline)

def cu_delPointByIndex(obj, curveSpline, ptIdx):
	cu_desel_all(obj)
	if curveSpline is None or ptIdx < 0 or  ptIdx >= len(curveSpline.points):
		#print("- curve_delPointByIndex skipped", ptIdx, len(curveSpline.points))
		return
	#print("- curve_delPointByIndex", ptIdx, len(curveSpline.points))
	del_pt = curveSpline.points[ptIdx]
	wla_curve.cu_setSel(del_pt, True)
	cu_delv_sel(obj)
	return


# def materializeBevel(subcurveObj, hairCurve):
# 	sysempty = wla.sys_empty(config.kWPLSystemObjShapes) # precreates Collection
# 	wla_do.link_object_to_scene(subcurveObj, sysempty)
# 	subcurveObj.use_fake_user = False
# 	if hairCurve is not None and hairCurve.data.bevel_object == subcurveObj:
# 		subcurveObj.name = hairCurve.name + config.kWPLObjShapeToken[0]
# 		subcurveObj.data.name = hairCurve.name + config.kWPLObjShapeToken[0]
# 	wla_do.set_object_noShadow(subcurveObj, True, True)

# ================================

class wplcurve_curves_hidepnt(bpy.types.Operator):
	bl_label = "Curves: insta-selection"
	bl_idname = "curve.wplcurve_curves_hidepnt"
	bl_options = {"REGISTER", "UNDO"}

	opt_actionType : EnumProperty(
		name="Action Type", default="HIDE",
		items=(("HIDE", "Hide", ""), ("HEADS", "Select heads", ""), ("TAILS", "Select tails", ""))
	)

	def execute(self, context):
		active_obj = wla.active_object(['CURVE', 'GPENCIL'])
		if active_obj is None:
			self.report({'INFO'}, 'Use operator on curve type object')
			return {"CANCELLED"}
		wla_do.select_and_change_mode(active_obj, "EDIT")
		curves_changed = 0
		sel_polylines = []
		splines = wla_curve.cu_getSplines(active_obj)
		for i, polyline in enumerate(splines):  # for strand point
			points = wla_curve.cu_getPoints(polyline)
			selpoints = wla_curve.cu_getPointsSel(polyline)
			if len(selpoints) == 0 or len(points)<2:
				continue
			sel_polylines.append((polyline, points))
		cu_desel_all(active_obj)
		for plpair in sel_polylines:
			points = plpair[1]
			curves_changed = curves_changed+1
			if self.opt_actionType == 'HIDE':
				for j, curvePoint in enumerate(points):
					wla_curve.cu_setSel(curvePoint, True)
				if active_obj.type == 'GPENCIL':
					bpy.ops.gpencil.hide(unselected=False)
				else:
					bpy.ops.curve.hide(unselected=False)
			if self.opt_actionType == 'HEADS':
				wla_curve.cu_setSel(points[0], True)
			if self.opt_actionType == 'TAILS':
				wla_curve.cu_setSel(points[-1], True)
		self.report({'INFO'}, "Updated "+str(curves_changed)+" curves")
		return {"FINISHED"}

# class wplcurve_add_bevel(bpy.types.Operator):
# 	bl_label = "Create BEVEL"
# 	bl_idname = "curve.wplcurve_add_bevel"
# 	bl_options = {"REGISTER", "UNDO"}
# 	bl_description = "Add ribbon to curve profile"

# 	strandResU : IntProperty(
# 		name="Segments U", default=3, min=1, max=10
# 	)
# 	strandResV : IntProperty(
# 		name="Segments V", default=2, min=1, max=10
# 	)
# 	opt_strandWidth : FloatProperty(
# 		name="Strand Width", default=1.0, min=0.0, max=10
# 	)
# 	strandPeak : FloatProperty(
# 		name="Strand peak", default=0.4, min=0.0, max=10
# 	)
# 	strandUplift : FloatProperty(
# 		name="Strand uplift", default=0.0, min=-10, max=10
# 	)
# 	opt_tilt_add : FloatProperty(
# 		name="Additional tilt",
# 		min=-180.0, max=180.0,
# 		step=30,
# 		default=0.0
# 	)
# 	opt_duplicateExisting : BoolProperty(
# 		name="Duplicate existing (if present)",
# 		default=True
# 	)

# 	def invoke(self,context, event):
# 		hairCurve = wla.active_object(['CURVE', 'POLY', 'NURBS'])
# 		if hairCurve is None:
# 			self.report({'INFO'}, 'Select curve object first')
# 			return {"CANCELLED"}
# 		bevelObj = hairCurve.data.bevel_object
# 		if bevelObj and len(bevelObj.data.splines) > 0:
# 			points = bevelObj.data.splines[0].points[:]
# 			if len(points) > 0:
# 				self.strandResV = len(points)-1
# 				self.strandResU = hairCurve.data.resolution_u
# 		return  self.execute(context)

# 	def execute(self, context):
# 		hairCurve = wla.active_object(['CURVE', 'POLY', 'NURBS'])
# 		if hairCurve is None:
# 			self.report({'INFO'}, 'Select curve object first')
# 			return {"CANCELLED"}
# 		if self.opt_duplicateExisting and hairCurve.data.bevel_object:
# 			# duplicating bevel
# 			prevBevel = hairCurve.data.bevel_object
# 			wla_do.ensure_visible(prevBevel, 2)
# 			wla_do.select_and_change_mode(prevBevel, 'OBJECT')
# 			wla_do.find_last_changed_objects(False)
# 			bpy.ops.object.duplicate(linked=False, mode='TRANSLATION')
# 			dups = wla_do.find_last_changed_objects(True)
# 			newBevel = dups[0]
# 			hairCurve.data.bevel_object = newBevel
# 			self.report({'INFO'}, 'Bevel duplicated: '+newBevel.name)
# 			return {"FINISHED"}
# 		pointsCo = []
# 		strandWidth = self.opt_strandWidth * max(0.001,hairCurve.data.bevel_depth)
# 		for i in range(self.strandResV + 1):
# 			x = 2 * i / self.strandResV - 1  # normalise and map from -1 to 1
# 			pointsCo.append((x * strandWidth , ((1 - x * x) * self.strandPeak + self.strandUplift) * strandWidth  , 0))  # **self.strandWidth to mantain proportion while changing widht
# 		# create the Curve Datablock
# 		BevelCurveData = bpy.data.curves.new(hairCurve.name + config.kWPLObjShapeToken[0], type='CURVE')  # new CurveData
# 		BevelCurveData.dimensions = '2D'
# 		curveBevelObj = bpy.data.objects.new(hairCurve.name + config.kWPLObjShapeToken[0], BevelCurveData)  # new object
# 		hairCurve.data.bevel_object = curveBevelObj
# 		hairCurve.data.bevel_mode = 'OBJECT'
# 		wla_do.set_object_noShadow(curveBevelObj, True, True)
# 		bevelSpline = BevelCurveData.splines.new('POLY')  # new spline
# 		bevelSpline.points.add(len(pointsCo) - 1)
# 		for i, coord in enumerate(pointsCo):
# 			x, y, z = coord
# 			bevelSpline.points[i].co = (x, y, z, 1)
# 		#curveBevelObj.use_fake_user = True
# 		materializeBevel(curveBevelObj, hairCurve)
# 		hairCurve.data.resolution_u = self.strandResU
# 		hairCurve.data.use_auto_texspace = True
# 		if abs(self.opt_tilt_add) > 0.01:
# 			for i, polyline in enumerate(hairCurve.data.splines):  # for strand point
# 				points = wla_curve.cu_getPoints(polyline)
# 				for j, curvePoint in enumerate(points):
# 					curvePoint.tilt = curvePoint.tilt+math.radians(self.opt_tilt_add)
# 		return {"FINISHED"}

# class wplcurve_edit_bevel(bpy.types.Operator):
# 	bl_label = "Edit BEVEL"
# 	bl_idname = "curve.wplcurve_edit_bevel"
# 	bl_options = {"REGISTER", "UNDO"}
# 	bl_description = "Edit ribbon curve"

# 	opt_curveType : EnumProperty(
# 		name="Subcurve type", default="BEVEL",
# 		items=(("BEVEL", "Bevel", ""), ("TAPER", "Taper", ""))
# 	)

# 	def execute(self, context):
# 		hairCurve = wla.active_object(['CURVE', 'POLY', 'NURBS'])
# 		if hairCurve is None:
# 			self.report({'INFO'}, 'Select curve object first')
# 			return {"CANCELLED"}
# 		subcurveObj = None
# 		if self.opt_curveType == 'BEVEL':
# 			subcurveObj = hairCurve.data.bevel_object
# 		if self.opt_curveType == 'TAPER':
# 			subcurveObj = hairCurve.data.taper_object
# 		if subcurveObj is None:
# 			return {"CANCELLED"}
# 		if wla.is_local_view():
# 			self.report({'ERROR'}, "Can`t work in Local view")
# 			return {'CANCELLED'}
# 		materializeBevel(subcurveObj, hairCurve)
# 		wla_do.ensure_visible(hairCurve, 2)
# 		wla_do.ensure_visible(subcurveObj, 2)
# 		hairCurve.select_set(False)
# 		subcurveObj.select_set(True)
# 		wla_do.select_and_change_mode(subcurveObj, 'EDIT')
# 		bpy.ops.view3d.localview()
# 		bpy.ops.view3d.view_persportho()
# 		bpy.ops.view3d.view_axis(type='TOP')
# 		bpy.ops.curve.select_all(action = 'SELECT')
# 		return {"FINISHED"}


class wplcurve_smooth_pos(bpy.types.Operator):
	bl_label = "Smooth positions"
	bl_idname = "curve.wplcurve_smooth_pos"
	bl_options = {"REGISTER", "UNDO"}

	opt_iters : IntProperty(
		name="Iterations", default=10, min=1, max=1000
	)

	@staticmethod
	def execute(self, context):
		active_obj = wla.active_object(['CURVE', 'POLY', 'NURBS', 'GPENCIL'])
		if active_obj is None:
			self.report({'INFO'}, 'Use operator on curve type object')
			return {"CANCELLED"}
		oldmode = wla_do.select_and_change_mode(active_obj, 'EDIT')
		# remembering curve tips/selection tips
		fixPoints = []
		splines = wla_curve.cu_getSplines(active_obj)
		for i, polyline in enumerate(splines):  # for strand point
			points = wla_curve.cu_getPoints(polyline)
			selcnt = 0
			for j, pt in enumerate(points):
				if pt.select:
					selcnt = selcnt+1
					if j == len(points)-1 or (points[j+1].select == False):
						fixPoints.append( (i, j) )
					if j == 0 or (points[j-1].select == False):
						fixPoints.append( (i, j) )
			if selcnt == 1: # full curve
				fixPoints = []
				fixPoints.append( (i, 0) )
				fixPoints.append( (i, len(points)-1) )
				for j, pt in enumerate(points):
					wla_curve.cu_setSel(pt, True)
		if len(fixPoints)>0:
			# deselecting points for better smoothing
			for sif_itx in fixPoints:
				polyline = splines[sif_itx[0]]
				points = wla_curve.cu_getPoints(polyline)
				pt = points[sif_itx[1]]
				wla_curve.cu_setSel(pt, False)
		for i in range(self.opt_iters):
			if active_obj.type == 'GPENCIL':
				bpy.ops.gpencil.stroke_smooth(only_selected=True, smooth_thickness=False)
			else:
				bpy.ops.curve.smooth()
		if len(fixPoints)>0:
			# reselecting points for better smoothing
			print("- fixPoints to restore", len(fixPoints))
			for sif_itx in fixPoints:
				polyline = splines[sif_itx[0]]
				points = wla_curve.cu_getPoints(polyline)
				pt = points[sif_itx[1]]
				wla_curve.cu_setSel(pt, True)
		self.report({'INFO'}, 'Done, smoothed')
		wla_do.select_and_change_mode(active_obj, oldmode)
		return {"FINISHED"}

class wplcurve_radius_tilt(bpy.types.Operator):
	bl_label = "Smooth tilt/radius"
	bl_idname = "curve.wplcurve_radius_tilt"
	bl_description = "Smooth tilt/radius"
	bl_options = {"REGISTER", "UNDO"}

	opt_radius_strength : IntProperty(
		name="Radius avg: points",
		default = 2,
		min=-1, max=10
	)
	opt_tilt_strength : IntProperty(
		name="Tilt avg: points",
		default = 2,
		min=-1, max=10
	)
	opt_radius_add : FloatVectorProperty(
		name="Radius Mul && Add",
		min=-10.0, max=10.0,
		step = 0.1, size=2,
		default = (1.0, 0.0),
	)
	opt_tilt_add : FloatVectorProperty(
		name="Tilt Mul && Add",
		min=-180.0, max=180.0,
		step = 30, size=2,
		default = (1.0, 0.0),
	)
	opt_skipTips : BoolProperty(
		name="Protect Tips",
		default=False
	)
	opt_radius_revert : BoolProperty(
		name="Revert radius",
		default=False
	)
	opt_tilt_revert : BoolProperty(
		name="Revert tilt",
		default=False
	)

	@staticmethod
	def smooth(y, box_pts):
		len_y = len(y)
		smoothed = []
		max_val = 0
		for i in range(len(y)):
			max_val = max(max_val, y[i])
		for i in range(len(y)):
			if box_pts == 0:
				smoothed.append(y[i])
				continue
			if box_pts < 0:
				smoothed.append(max_val)
				continue
			low = max(0, i - box_pts)
			hi = min(len_y, i + box_pts)
			smoothed.append(np.sum(y[low:hi]) / (hi - low))  # average
		return smoothed

	def execute(self, context):
		active_obj = wla.active_object(['CURVE', 'GPENCIL'])
		if active_obj is None:
			self.report({'INFO'}, 'Use operator on curve type object')
			return {"CANCELLED"}
		okCnt = 0
		splines = wla_curve.cu_getSplines(active_obj)
		for i, polyline in enumerate(splines):  # for strand point
			points = None
			points_sel = wla_curve.cu_getPointsSel(polyline)
			if len(points_sel) == 0:
				continue
			if len(points_sel) >= 3:
				points = points_sel
			else:
				# 1, 2 selected points == full stroke
				points = wla_curve.cu_getPoints(polyline)
			if len(points) < 2:
				continue
			okCnt = okCnt+1
			smoothedTilts = None
			smoothedRads = None
			smoothedStre = None
			if active_obj.type != 'GPENCIL':
				curveTiltList = [curvePoint.tilt for curvePoint in points]
				smoothedTilts = self.smooth(curveTiltList, self.opt_tilt_strength)
				curveRadList = [curvePoint.radius for curvePoint in points]
				smoothedRads = self.smooth(curveRadList, self.opt_radius_strength)
			else:
				curveStreList = [curvePoint.pressure for curvePoint in points]
				smoothedStre = self.smooth(curveStreList, self.opt_radius_strength)
			for j, curvePoint in enumerate(points):
				if self.opt_skipTips:
					if j == 0 or j == len(points)-1:
						continue
				idxT = j
				idxR = j
				if self.opt_tilt_revert:
					idxT = len(points)-1-idxT
				if self.opt_radius_revert:
					idxR = len(points)-1-idxR
				if smoothedTilts is not None:
					curvePoint.tilt = smoothedTilts[idxT]*self.opt_tilt_add[0] + math.radians(self.opt_tilt_add[1])
				if smoothedRads is not None:
					new_r = smoothedRads[idxR]*self.opt_radius_add[0] + self.opt_radius_add[1]
					if new_r > 0.0:
						curvePoint.radius = new_r
				if smoothedStre is not None:
					new_r = smoothedStre[idxR]*self.opt_radius_add[0] + self.opt_radius_add[1]
					if new_r > 0.0:
						curvePoint.pressure = new_r
		self.report({'INFO'}, 'Smooth done, curves='+str(okCnt))
		return {"FINISHED"}

class wplcurve_taper_pts(bpy.types.Operator):
	bl_label = "Taper Curve"
	bl_idname = "curve.wplcurve_taper_pts"
	bl_description = "Taper Curve radius over length"
	bl_options = {"REGISTER", "UNDO"}

	opt_EvalMul: StringProperty(
		name = "Factor",
		default = kWPLDefaultProfileMulFac
	)
	opt_Radius : FloatProperty(
		name="Radius",
		default=0,
		min=0, max=100
	)
	opt_onlySelection : BoolProperty(
		name="Only Selected",
		default=True
	)

	def invoke(self, context, event):
		if bpy.context.mode != 'OBJECT':
			self.opt_onlySelection = True
		elif bpy.context.mode == 'OBJECT':
			self.opt_onlySelection = False
		return self.execute(context)

	def execute(self, context):
		okCnt = 0
		selectedCurves = wla.selected_objects(['CURVE','GPENCIL'])
		if len(selectedCurves) == 0:
			self.report({'ERROR'}, "Nothing selected")
			return {'CANCELLED'}
		opt_EvalMul_py = None
		try:
			opt_EvalMul_py = compile(self.opt_EvalMul, "<string>", "eval")
		except Exception as e:
			print("- eval error:", self.opt_EvalMul, e)
			self.report({'ERROR'}, "Eval compilation: syntax error")
			return {'CANCELLED'}
		for objCurve in selectedCurves:
			splines = wla_curve.cu_getSplines(objCurve)
			for polyline in splines: # for strand point
				points = wla_curve.cu_getPoints(polyline)
				if self.opt_onlySelection:
					# 1 selected point == full stroke
					points_sel = wla_curve.cu_getPointsSel(polyline)
					if len(points_sel) == 0:
						continue
					if len(points_sel) > 1:
						points = points_sel
				toRadius = self.opt_Radius
				curveDistTotal = 0
				maxRadius = -100
				pprev = None
				for i,p in enumerate(points):
					if isinstance(p, bpy.types.GPencilStrokePoint):
						maxRadius = max(maxRadius, p.pressure)
					else:
						maxRadius = max(maxRadius, p.radius)
					if pprev is not None:
						curveDistTotal = curveDistTotal+(p.co-pprev.co).length
					pprev = p
				if toRadius < 0.00001:
					toRadius = maxRadius
				#toRadius = wla_curve.cu_rescale_radius(points, (0.01, 0.01, 1.0), 0.5, toRadius)
				curveDist = 0
				pprev = None
				for i, p in enumerate(points):
					if len(points) < 2:
						continue
					if pprev is not None:
						curveDist = curveDist+(p.co-pprev.co).length
					pprev = p
					facI = float(i)/float(len(points)-1) # 4EVAL
					facL = curveDist/curveDistTotal # 4EVAL
					opt_EvalMul_val = eval(opt_EvalMul_py)
					radiusNew = toRadius * opt_EvalMul_val
					radiusNew = max(0.00001,radiusNew)
					if isinstance(p, bpy.types.GPencilStrokePoint):
						# grease pencil
						p.pressure = radiusNew
					else:
						p.radius = radiusNew
				print("- Tapering: radius used:", toRadius)
				okCnt = okCnt+1
		self.report({'INFO'}, 'Taper done, curves='+str(okCnt))
		return {"FINISHED"}

class wplcurve_evenly_pts(bpy.types.Operator):
	bl_label = "Distribute points"
	bl_idname = "curve.wplcurve_evenly_pts"
	bl_options = {"REGISTER", "UNDO"}

	opt_linearizeCo : FloatProperty(
		name="Linearize positions",
		min=0.0, max=1.0,
		default=0,
	)
	opt_onlySelection : BoolProperty(
		name="Only Selected",
		default=True
	)

	@staticmethod
	def invoke(self, context, event):
		if bpy.context.mode != 'OBJECT':
			self.opt_onlySelection = True
		elif bpy.context.mode == 'OBJECT':
			self.opt_onlySelection = False
		return self.execute(context)

	def execute(self, context):
		active_obj = wla.active_object(['CURVE', 'GPENCIL'])
		if active_obj is None:
			self.report({'INFO'}, 'Use operator on curve type object')
			return {"CANCELLED"}
		splines = wla_curve.cu_getSplines(active_obj)
		for i, polyline in enumerate(splines):
			points = wla_curve.cu_getPoints(polyline)
			if self.opt_onlySelection:
				# 1,2 selected points == full stroke
				points_sel = wla_curve.cu_getPointsSel(polyline)
				if len(points_sel) == 0:
					continue
				if len(points_sel) >= 3:
					points = points_sel
			#print("- points to redistribute", len(points))
			if len(points) < 3:
				continue
			len_trg = 0
			t_xp = []
			t_yp_px = []
			t_yp_py = []
			t_yp_pz = []
			curve_pt_last = None
			for j, curve_pt in enumerate(points):
				t_yp_px.append(curve_pt.co[0])
				t_yp_py.append(curve_pt.co[1])
				t_yp_pz.append(curve_pt.co[2])
				if curve_pt_last is not None:
					len_trg = len_trg+(curve_pt_last.co-curve_pt.co).length
				t_xp.append(len_trg)
				curve_pt_last = curve_pt
			if len_trg>0.00001:
				for j, curve_pt in enumerate(points):
					t_pos_rel = float(j)/float(len(points)-1)
					t_pos = t_pos_rel*len_trg
					ptx = np.interp(t_pos, t_xp, t_yp_px)
					pty = np.interp(t_pos, t_xp, t_yp_py)
					ptz = np.interp(t_pos, t_xp, t_yp_pz)
					if self.opt_linearizeCo > 0.0:
						ptxLin = wla.math_lerp1D(t_pos_rel, t_yp_px[0], t_yp_px[-1])
						ptyLin = wla.math_lerp1D(t_pos_rel, t_yp_py[0], t_yp_py[-1])
						ptzLin = wla.math_lerp1D(t_pos_rel, t_yp_pz[0], t_yp_pz[-1])
						ptx = wla.math_lerp1D(self.opt_linearizeCo, ptx, ptxLin)
						pty = wla.math_lerp1D(self.opt_linearizeCo, pty, ptyLin)
						ptz = wla.math_lerp1D(self.opt_linearizeCo, ptz, ptzLin)
					wla_curve.cu_setCo(curve_pt, ptx, pty, ptz)
		return {"FINISHED"}


# class wplcurve_blendtips_pts(bpy.types.Operator):
# 	bl_label = "UnBend arounds to straight arc"
# 	bl_idname = "curve.wplcurve_blendtips_pts"
# 	bl_options = {"REGISTER", "UNDO"}

# 	opt_influence : FloatProperty(
# 		name		= "Influence",
# 		default	 = 1.0,
# 		min		 = -1.0,
# 		max		 = 1.0
# 	)
# 	opt_steps : IntProperty(
# 		name		= "Steps",
# 		default	 = 3,
# 		min		 = 1,
# 		max		 = 100
# 	)
# 	opt_falloff : FloatProperty(
# 		name		= "Falloff",
# 		default	 = 1.5,
# 		min		 = 0.0,
# 		max		 = 3.0
# 	)

# 	opt_dir2head : BoolProperty(
# 		name		= "Direction: Head",
# 		default	 = True
# 	)
# 	opt_dir2tail : BoolProperty(
# 		name		= "Direction: Tail",
# 		default	 = True
# 	)

# 	def execute(self, context):
# 		active_obj = wla.active_object(['CURVE', 'POLY', 'NURBS', 'GPENCIL'])
# 		if active_obj is None:
# 			self.report({'INFO'}, 'Use operator on curve type object')
# 			return {"CANCELLED"}
# 		okPts = 0
# 		splines = wla_curve.cu_getSplines(active_obj)
# 		for i, polyline in enumerate(splines):
# 			sel_points = wla_curve.cu_getPointsSel(polyline)
# 			if len(sel_points) < 1:
# 				continue
# 			all_points = wla_curve.cu_getPoints(polyline)
# 			pnt_root_map = {}
# 			sel_dirs = {}
# 			for j, curve_pt in enumerate(all_points):
# 				if curve_pt in sel_points:
# 					pt_co = Vector((curve_pt.co[0],curve_pt.co[1],curve_pt.co[2]))
# 					if curve_pt not in sel_dirs:
# 						sel_dirs[curve_pt] = []
# 					if j > 0:
# 						prev_p = all_points[j-1]
# 						prev_co = Vector((prev_p.co[0],prev_p.co[1],prev_p.co[2]))
# 						sel_dirs[curve_pt].append([(prev_co-pt_co).normalized(),-1])
# 					if j < len(all_points)-1:
# 						next_p = all_points[j+1]
# 						next_co = Vector((next_p.co[0],next_p.co[1],next_p.co[2]))
# 						sel_dirs[curve_pt].append([(next_co-pt_co).normalized(),1])
# 					if len(sel_dirs[curve_pt]) == 2:
# 						d1 = sel_dirs[curve_pt][0][0]
# 						d2 = sel_dirs[curve_pt][1][0]
# 						d_avg = ((d1+(-1.0*d2))*0.5).normalized()
# 						sel_dirs[curve_pt] = [[d_avg,-1],[-1*d_avg,1]]
# 					continue
# 				for k in range(j-self.opt_steps,j+self.opt_steps+1):
# 					if k==j or k<0 or k>=len(all_points):
# 						continue
# 					test_p = all_points[k]
# 					if test_p in sel_points:
# 						if curve_pt not in pnt_root_map:
# 							pnt_root_map[curve_pt] = []
# 						dst = 0.0
# 						for k2 in range(min(j,k),max(j,k)):
# 							p1_co = Vector((all_points[k2].co[0],all_points[k2].co[1],all_points[k2].co[2]))
# 							p2_co = Vector((all_points[k2+1].co[0],all_points[k2+1].co[1],all_points[k2+1].co[2]))
# 							dst = dst+(p2_co-p1_co).length
# 						weight = 1.0
# 						if self.opt_falloff > 0.0:
# 							weight = weight * pow(1.0-abs(float(k-j))/float(self.opt_steps+1.0),self.opt_falloff)
# 							#weight = pow(self.opt_falloff,abs(k-j))
# 						pnt_root_map[curve_pt].append([test_p, weight, j-k, dst])
# 			pt_new_co = {}
# 			for pt in pnt_root_map:
# 				if pt not in pt_new_co:
# 					pt_new_co[pt] = []
# 				pt_co = Vector((pt.co[0],pt.co[1],pt.co[2]))
# 				for pt_root_list in pnt_root_map[pt]:
# 					pt_root = pt_root_list[0]
# 					pt_root_co = Vector((pt_root.co[0],pt_root.co[1],pt_root.co[2]))
# 					pt2root_dir = (pt_co-pt_root_co).normalized()
# 					pt_root_wei = pt_root_list[1]
# 					pt_root_flow = pt_root_list[2]
# 					pt_root_dst = pt_root_list[3]
# 					pt_co_dst = pt_root_co + pt_root_dst*pt2root_dir
# 					if pt_root_flow < 0 and self.opt_dir2head == False:
# 						continue
# 					if pt_root_flow > 0 and self.opt_dir2tail == False:
# 						continue
# 					if pt_root in sel_dirs:
# 						pt_root_dirs = sel_dirs[pt_root]
# 						for rdir_list in pt_root_dirs:
# 							rdir = rdir_list[0]
# 							rdir_flow = rdir_list[1]
# 							#if pt2root_dir.dot(rdir)<0:
# 							#	continue
# 							if math.copysign(1,rdir_flow) == math.copysign(1,pt_root_flow):
# 								infl = (pt_root_wei * self.opt_influence)
# 								if infl<0:
# 									infl = -1.0*infl
# 									rdir = -1.0*rdir
# 								diff_quat = (infl * pt2root_dir.rotation_difference(rdir))
# 								diff_matRot = Matrix.Translation(pt_root_co) @ diff_quat.to_matrix().to_4x4() @ Matrix.Translation(-pt_root_co)
# 								diff_co = diff_matRot @ (pt_co.lerp(pt_co_dst,min(1,max(0,abs(infl)))))
# 								pt_new_co[pt].append(diff_co)
# 			for pt in pt_new_co:
# 				if active_obj.type != 'GPENCIL' and pt.hide > 0:
# 					continue
# 				if len(pt_new_co[pt]) == 0:
# 					continue
# 				pt_co = Vector((pt.co[0],pt.co[1],pt.co[2]))
# 				new_co_sum = Vector((0,0,0))
# 				new_co_cnt = 0.0
# 				for new_co in pt_new_co[pt]:
# 					new_co_sum = new_co_sum+new_co
# 					new_co_cnt = new_co_cnt+1.0
# 				if new_co_cnt>0:
# 					new_co = new_co_sum/new_co_cnt
# 					#new_co = pt_co.lerp(new_co,self.opt_influence)
# 					wla_curve.cu_setCo(pt, new_co[0],new_co[1],new_co[2])
# 					okPts = okPts+1
# 		self.report({'INFO'}, "Updated "+str(okPts)+" points")
# 		return {"FINISHED"}

class wplcurve_fastpin_ini(bpy.types.Operator):
	bl_idname = "curve.wplcurve_fastpin_ini"
	bl_label = "Fast pin selected"
	bl_options = {'REGISTER', 'UNDO'}

	opt_pinId : StringProperty(
		name		= "Pin ID",
		default	 	= "curveFastpin"
	)

	def execute( self, context ):
		active_obj = wla.active_object(['CURVE', 'POLY', 'NURBS'])
		if active_obj is None:
			self.report({'INFO'}, 'Use operator on curve type object')
			return {"CANCELLED"}
		wla_do.select_and_change_mode(active_obj,'EDIT')
		curveData = active_obj.data
		curvePtsMap = {}
		okCnt = 0
		for i,spl in enumerate(curveData.splines):
			pt_locks = []
			for j, pt in enumerate(spl.points):
				isSel = 0
				if pt.select:
					isSel = 1
				pt_co = Vector((pt.co[0],pt.co[1],pt.co[2]))
				pt_locks.append([j, pt_co, isSel])
				okCnt = okCnt+1
			curvePtsMap[str(i)] = pt_locks
		config.WPL_G.store[self.opt_pinId] = curvePtsMap
		self.report({'INFO'}, "Done. Pinned points="+str(okCnt))
		return {'FINISHED'}

class wplcurve_fastpin_apl(bpy.types.Operator):
	bl_idname = "curve.wplcurve_fastpin_apl"
	bl_label = "Enforce pins"
	bl_options = {'REGISTER', 'UNDO'}

	opt_influence : FloatProperty (
		name = "Influence",
		min = 0.0, max = 1.0,
		default = 1.0
	)

	opt_pinId : StringProperty(
		name		= "Pin ID",
		default	 	= "curveFastpin"
	)

	opt_pinType : EnumProperty(
		name="Pin type", default="INISEL",
		items=(("INISEL", "Initially selected", ""), ("NOWSEL", "Currently selected", ""))
	)

	opt_smoothLoops : IntProperty (
		name = "Smoothing loops",
		min = 0, max = 100,
		default = 3
	)
	opt_smoothPow : FloatProperty (
		name = "Smoothing pow",
		min = 0.0, max = 10.0,
		default = 1.0
	)

	def execute( self, context ):
		active_obj = wla.active_object(['CURVE', 'POLY', 'NURBS'])
		if active_obj is None:
			self.report({'INFO'}, 'Use operator on curve type object')
			return {"CANCELLED"}
		wla_do.select_and_change_mode(active_obj,'EDIT')
		curveData = active_obj.data
		if self.opt_pinId not in config.WPL_G.store:
			self.report({'ERROR'}, "Pin points first")
			return {'CANCELLED'}
		okCnt = 0
		curvePtsMap =config. WPL_G.store[self.opt_pinId]
		for i,spl in enumerate(curveData.splines):
			if str(i) not in curvePtsMap:
				continue
			pt_all = curvePtsMap[str(i)]
			pt_locks = []
			if self.opt_pinType == 'INISEL':
				for lock_data in pt_all:
					if lock_data[2] > 0:
						pt_locks.append(lock_data)
			else:
				for lock_data in pt_all:
					pt_idx = lock_data[0]
					if pt_idx >= 0 and pt_idx < len(spl.points):
						pt = spl.points[pt_idx]
						if pt.select:
							pt_locks.append(lock_data)
			for lock_data in pt_locks:
				pt_idx = lock_data[0]
				pt_coIni = lock_data[1]
				if pt_idx >= 0 and pt_idx < len(spl.points):
					okCnt = okCnt+1
					pt = spl.points[pt_idx]
					pt_coCur = Vector((pt.co[0],pt.co[1],pt.co[2]))
					if self.opt_pinType == 'INISEL':
						pt_coCur2 = pt_coCur.lerp(pt_coIni, self.opt_influence)
						pt.co = (pt_coCur2[0], pt_coCur2[1], pt_coCur2[2], 1.0)
					else:
						pt_coCur2 = pt_coIni.lerp(pt_coCur, self.opt_influence)
						pt_coCur = pt_coIni
					if self.opt_smoothLoops > 0:
						for k in range(pt_idx-self.opt_smoothLoops, pt_idx+self.opt_smoothLoops+1):
							if k < 0 or k == pt_idx or k >= len(spl.points):
								continue
							isInLocks = False
							for lld2 in pt_locks:
								if lld2[0] == k:
									isInLocks = True
									break
							if isInLocks:
								continue
							smoothInfl = pow(1.0-abs(k-pt_idx)/float(self.opt_smoothLoops), self.opt_smoothPow)
							ptSm = spl.points[k]
							ptSm_co = Vector((ptSm.co[0],ptSm.co[1],ptSm.co[2]))
							ptSm_co = ptSm_co+(pt_coCur2-pt_coCur)*smoothInfl
							ptSm.co = (ptSm_co[0], ptSm_co[1], ptSm_co[2], 1.0)
		self.report({'INFO'}, "Done. Enforced points="+str(okCnt))
		return {'FINISHED'}

class wplcurve_forcexmirr(bpy.types.Operator):
	bl_label = "Mirror duplicate"
	bl_idname = "curve.wplcurve_forcexmirr"
	bl_options = {"REGISTER", "UNDO"}

	opt_onlySelection : BoolProperty(
		name="Only Selected",
		default=True
	)

	def invoke(self, context, event):
		if bpy.context.mode != 'OBJECT':
			self.opt_onlySelection = True
		elif bpy.context.mode == 'OBJECT':
			self.opt_onlySelection = False
		return self.execute(context)

	def execute(self, context):
		active_obj = wla.active_object(['CURVE'])
		if active_obj is None:
			self.report({'INFO'}, 'Use operator on curve type object')
			return {"CANCELLED"}
		wla_curve.cu_apply_xmirror(active_obj, self.opt_onlySelection)
		return {"FINISHED"}

class wplcurve_cnormalize(bpy.types.Operator):
	bl_label = "Normalize curves"
	bl_idname = "curve.wplcurve_cnormalize"
	bl_options = {"REGISTER", "UNDO"}
	opt_mainDirection : FloatVectorProperty(
		name="Primary direction (begin->end)",
		default=(0,0,-1)
	)
	opt_ensureSegmentLength : FloatProperty(
		name="Auto-recut selection (segment length)",
		default= 0.0
	)
	opt_reapplyShrinkw : BoolProperty(
		name="Reaply shrinkwrap if present",
		default=True
	)
	opt_reapplyDistribute : BoolProperty(
		name="Reaply Distribute",
		default=False
	)

	def execute(self, context):
		active_obj = wla.active_object(['CURVE', 'GPENCIL'])
		if active_obj is None:
			self.report({'INFO'}, 'Use operator on curve type object')
			return {"CANCELLED"}
		oldmode = wla_do.select_and_change_mode(active_obj,'EDIT')
		maindir = Vector((self.opt_mainDirection[0],self.opt_mainDirection[1],self.opt_mainDirection[2]))
		maindir = maindir.normalized()
		ok = 0.0
		ensureSegLen = abs(self.opt_ensureSegmentLength)
		if ensureSegLen > 0.0001:
			# subdiving BEFORE deletions and distributions
			wla_do.select_and_change_mode(active_obj,"EDIT")
			if self.opt_ensureSegmentLength > 0:
				# all splines
				splines = wla_curve.cu_getSplines(active_obj)
			if self.opt_ensureSegmentLength < 0:
				# only selected
				(_, _, splines) = wla_curve.cu_getSelectedStrokes(active_obj, True, True)
				cu_desel_all(active_obj)
			isAnyChange = -1
			isAllCahnges = 0
			while isAnyChange != 0:
				isAnyChange = 0
				for i, polyline in enumerate(splines):
					points = wla_curve.cu_getPoints(polyline)
					for j in range(len(points)-1):
						pt1 = points[j]
						pt2 = points[j+1]
						needSubd = 0
						if needSubd == 0:
							dist = (Vector((pt1.co[0], pt1.co[1], pt1.co[2])) - Vector((pt2.co[0], pt2.co[1], pt2.co[2]))).length
							if dist > ensureSegLen:
								needSubd = int(dist/ensureSegLen)
						if needSubd == 0 and len(points) < 4:
							# curves with 2 lines are not exported well - no fill can be build on 2 points
							needSubd = 1
						if needSubd > 0:
							cu_desel_all(active_obj)
							wla_curve.cu_setSel(pt1, True)
							wla_curve.cu_setSel(pt2, True)
							cu_subd_sel(active_obj, needSubd)
							isAnyChange = isAnyChange+1
							isAllCahnges = isAllCahnges+1
							break
				if isAllCahnges > 1000:
					print("- too many iterations, stopping")
					break
			if isAllCahnges>0:
				ok = ok + len(splines)
				if self.opt_ensureSegmentLength < 0:
					# reselecting points in previously selected splines
					for i, polyline in enumerate(splines):
						points = wla_curve.cu_getPoints(polyline)
						for pt in points:
							wla_curve.cu_setSel(pt, True)
				print("- subdivs to the length:", isAllCahnges)
				print("// max segment length:", ensureSegLen)
		# next updates - on all curves ALWAYS
		curves2switch = []
		cruves2del = []
		splines = wla_curve.cu_getSplines(active_obj)
		for i, polyline in enumerate(splines):
			points = wla_curve.cu_getPoints(polyline)
			if active_obj.type == 'GPENCIL':
				isAllNoPressure = True
				for pt in points:
					# point with no pressure -> problems on svg-export!!!
					if pt.pressure > 0.2:
						isAllNoPressure = False
				if isAllNoPressure:
					cruves2del.append(polyline)
					continue
			if len(points) == 1:
				cruves2del.append(polyline)
				continue
		if len(cruves2del) > 0:
			print("- deleting 1pt curves:", len(cruves2del))
			for polyline in cruves2del:
				cu_del_spl(active_obj, polyline)
			ok = ok+len(cruves2del)
		splines = wla_curve.cu_getSplines(active_obj)
		for i, polyline in enumerate(splines):
			points = wla_curve.cu_getPoints(polyline)
			if active_obj.type == 'CURVE':
				# Fixing after mesh-curve conversions
				polyline.use_endpoint_u = True
				polyline.use_smooth = True
			selpoints = wla_curve.cu_getPointsSel(polyline)
			for point in points:
				wla_curve.cu_setSel(point, False)
			if len(selpoints) == 0 or len(points)<2:
				continue
			needSwitch = False
			p1 = active_obj.matrix_world @ points[0].co
			p1 = Vector((p1[0],p1[1],p1[2]))
			p2 = active_obj.matrix_world @ points[-1].co
			p2 = Vector((p2[0],p2[1],p2[2]))
			if (p1-p2).normalized().dot(maindir) > (p2-p1).normalized().dot(maindir):
				needSwitch = True
			if needSwitch:
				curves2switch.append(polyline)
		if len(curves2switch)>0:
			print("- unifiying curves:", len(curves2switch))
			for polyline in curves2switch:
				points = wla_curve.cu_getPoints(polyline)
				for point in points:
					wla_curve.cu_setSel(point, True)
			if active_obj.type == 'CURVE':
				bpy.ops.curve.switch_direction()
			if active_obj.type == 'GPENCIL':
				bpy.ops.gpencil.stroke_flip()
			ok = ok+len(curves2switch)
		if self.opt_reapplyDistribute:
			wla_do.select_and_change_mode(active_obj,"OBJECT")
			bpy.ops.curve.wplcurve_evenly_pts(opt_onlySelection=False)
			ok = ok+1
		if self.opt_reapplyShrinkw and wla.modf_by_type(active_obj, 'SHRINKWRAP') is not None:
			if wla.is_object_nonoperable(active_obj, None):
				print("- shrinkwrap apply: skipped, non operable")
			else:
				wla_do.select_and_change_mode(active_obj,"OBJECT")
				mod = wla.modf_by_type(active_obj, 'SHRINKWRAP')
				bpy.ops.object.modifier_copy(modifier=mod.name)
				bpy.ops.object.modifier_apply(modifier=mod.name)
				ok = ok+1
		wla_do.select_and_change_mode(active_obj,oldmode)
		cu_desel_all(active_obj)
		print("- total normalizations: ", ok)
		self.report({'INFO'}, "Curves normalized, iters:"+str(ok))
		return {"FINISHED"}

class wplcurve_symmetrize_pts(bpy.types.Operator):
	bl_label = "Make curve symmetrical"
	bl_idname = "curve.wplcurve_symmetrize_pts"
	bl_options = {"REGISTER", "UNDO"}

	opt_refCo : EnumProperty(
		name="Reference point", default="ABS",
		items=(("MIDDLE", "Middle vert", ""), ("ABS", "ABSOLUTE", ""))
	)

	@staticmethod
	def execute(self, context):
		active_obj = wla.active_object(['CURVE'])
		if active_obj is None:
			self.report({'INFO'}, 'Use operator on curve type object')
			return {"CANCELLED"}
		wla_do.select_and_change_mode(active_obj,'EDIT')
		points2check = []
		polys2check = []
		middlePtCo = Vector((0,0,0))
		splines = wla_curve.cu_getSplines(active_obj)
		for i, polyline in enumerate(splines):
			points = wla_curve.cu_getPoints(polyline)
			selpoints = wla_curve.cu_getPointsSel(polyline)
			if len(selpoints) < 1 or len(points) < 2:
				print("- skipping spline: 2-3 points needed")
				continue
			polys2check.append( [polyline, selpoints, 0] )
			for p in selpoints:
				points2check.append( p )
				middlePtCo = middlePtCo+Vector((p.co[0],p.co[1],p.co[2]))
		if len(points2check) == 0:
			self.report({'INFO'}, 'Select points first')
			return {"CANCELLED"}
		middlePtCo = middlePtCo/len(points2check)
		if self.opt_refCo == 'ABS':
			middlePtCo = Vector((0.0, middlePtCo[1], middlePtCo[2]))
		ptsOk = 0
		usedPolys = []
		for ppp in polys2check:
			polyline = ppp[0]
			if polyline in usedPolys:
				continue
			points = list(ppp[1])
			if points[0].co[0] >= middlePtCo[0] and points[-1].co[0] < middlePtCo[0]:
				points.reverse()
			if points[0].co[0] < middlePtCo[0] and points[-1].co[0] >= middlePtCo[0]:
				# simple case - curve intersects center-line
				print("- polyline: curve reverse mode")
				for i in range(len(points)):
					j = len(points)-i-1
					if i > j:
						break
					rp_i = points[i]
					if i == j:
						wla_curve.cu_setCo(rp_i, middlePtCo[0], rp_i.co[1], rp_i.co[2])
						ptsOk = ptsOk+1
						break
					sym_co = (middlePtCo[0]+(middlePtCo[0]-rp_i.co[0]), rp_i.co[1], rp_i.co[2], 1.0)
					rp_j = points[j]
					wla_curve.cu_setCo(rp_j, sym_co[0], sym_co[1], sym_co[2])
					rp_j.radius = rp_i.radius
					ptsOk = ptsOk+1
				# this curve is done
				usedPolys.append(polyline)
				continue
			if points[0].co[0] > middlePtCo[0]:
				continue
			# searching for most similar polyline
			bests = []
			for ppp2 in polys2check:
				polyline2 = ppp2[0]
				if (polyline2 in usedPolys) or (polyline2 == polyline):
					continue
				points2 = ppp2[1]
				if len(points2) != len(points):
					continue
				diffFrm = 0
				diffRev = 0
				for i in range(len(points)):
					p1 = points[i].co
					p1Co = Vector((p1[0],p1[1],p1[2]))
					sym_co = Vector( (middlePtCo[0]+(middlePtCo[0]-p1Co[0]), p1Co[1], p1Co[2]) )
					p2a = points2[i].co
					p2aCo = Vector((p2a[0],p2a[1],p2a[2]))
					p2b = points2[len(points)-i-1].co
					p2bCo = Vector((p2b[0],p2b[1],p2b[2]))
					diffFrm = diffFrm+(p2aCo-sym_co).length
					diffRev = diffRev+(p2bCo-sym_co).length
				bests.append( (diffFrm, polyline2, list(points2)) )
				bests.append( (diffRev, polyline2, list(reversed(list(points2)))))
			bests.sort(key=lambda ia: ia[0], reverse=False)
			if len(bests) > 0:
				print("- polyline: full mirror mode")
				polyline2 = bests[0][1]
				points2 = bests[0][2]
				usedPolys.append(polyline)
				usedPolys.append(polyline2)
				for i in range(len(points)):
					p1 = points[i].co
					p1Co = Vector((p1[0],p1[1],p1[2]))
					sym_co = Vector( (middlePtCo[0]+(middlePtCo[0]-p1Co[0]), p1Co[1], p1Co[2]) )
					wla_curve.cu_setCo(points2[i], sym_co[0], sym_co[1], sym_co[2])
					points2[i].radius = points[i].radius
					ptsOk = ptsOk+1
		#p1CoBest = Vector((middlePtCo[0]+(middlePtCo[0]-p1Co[0]), p1Co[1], p1Co[2]))
		print("- pts checked:", len(points2check), "matches:", ptsOk)
		self.report({'INFO'}, "Done. Aligned points="+str(ptsOk))
		return {"FINISHED"}

class wplcurve_svg_2mesh(bpy.types.Operator):
	bl_label = "Convert SVG to mesh"
	bl_idname = "curve.wplcurve_svg_2mesh"
	bl_options = {"REGISTER", "UNDO"}
	bl_description = 'Bake gpencil to mesh with metadata'

	opt_depth : FloatProperty(
		name="Final mesh height",
		default= 0.005
	)

	# Running as separate dialog
	def invoke(self, context, event):
		return context.window_manager.invoke_props_dialog(self, width = 200)

	def execute(self, context):  # svg2mesh
		selobjs = wla.selected_objects(['CURVE', 'GPENCIL'])
		if len(selobjs) == 0:
			self.report({'INFO'}, 'Select gpencil object')
			return {"CANCELLED"}
		selobjs_names = [obj.name for obj in selobjs]
		#selobjs_names.sort(key=lambda str: str.ljust(10,"0")) # zfill at right
		selobjs_names.sort(key=lambda str: str.replace("Curve","").replace(".","").zfill(10))
		addedObjs = []
		zorder_step = self.opt_depth / len(selobjs_names)
		print("- SVG: meshing curves...", len(selobjs))
		for oi, obj_name in enumerate(selobjs_names):
			obj = wla.object_by_name(obj_name)
			if obj.type == 'GPENCIL':
				# depsgraph = bpy.context.evaluated_depsgraph_get()
				# obj_eval = obj.evaluated_get(depsgraph)
				# curveMesh = obj_eval.to_mesh()
				# bm = bmesh.new()
				# bm.from_mesh(curveMesh)
				# tmp_ground_data=bpy.data.meshes.new(name='Mesh')
				# bm.to_mesh(tmp_ground_data)
				# test_ob = bpy.data.objects.new(name="aaa", object_data=tmp_ground_data)
				# bpy.context.scene.collection.objects.link(test_ob)
				continue
			mfcName = obj.name
			obj.name = config.kWPLSuppZZZPrefix + obj.name # at start
			curveMeshedObj = wla_do.clone_evaluated_obj(obj, mfcName, True, False, None)
			curveMeshedObj.location = curveMeshedObj.location + Vector((0,0,(float(oi)*zorder_step)))
			addedObjs.append(curveMeshedObj)
			#wla_do.select_and_change_mode(curveMeshedObj, 'OBJECT')
		if len(addedObjs) == 0:
			self.report({'INFO'}, "Nothing added.")
			return {"FINISHED"}
		print("- SVG: removing initials...", len(selobjs))
		for obj in selobjs:
			bpy.data.objects.remove(obj, do_unlink=True)
		firstObjCollName = None
		firstObj = addedObjs[0]
		if len(firstObj.users_collection) > 0:
			firstObjCollName = firstObj.users_collection[0].name
		firstObjName = firstObj.name
		print("- SVG: joining...", firstObjName)
		wla_do.select_and_activate_multi(addedObjs, firstObj)
		bpy.ops.object.join()
		meshObj = wla.object_by_name(firstObjName)
		if firstObjCollName is not None:
			meshObj.name = firstObjCollName
		wla_do.select_and_change_mode(meshObj, 'OBJECT')
		print("- SVG: replacing and coloring...")
		try:
			bpy.ops.object.wplheal_replacemats(opt_objmatReplRules = config.kWPLSystemMatReplaceSVGDef, opt_col2DecorC = 'WITH_GAMMA')
		except Exception as e:
			print("- SVG: wplheal_replacemats FAILED", e)
		print("- SVG: finalizing mesh...")
		wla_do.select_and_change_mode(meshObj, 'EDIT')
		bpy.ops.mesh.select_all( action = 'SELECT' )
		bpy.ops.mesh.dissolve_degenerate()
		bpy.ops.mesh.select_all( action = 'SELECT' )
		bpy.ops.mesh.dissolve_limited()
		bpy.ops.mesh.select_all( action = 'SELECT' )
		bpy.ops.mesh.delete_loose()
		wla_do.select_and_change_mode(meshObj, 'OBJECT')
		print("- SVG: done", meshObj)
		self.report({'INFO'}, "Done.")
		return {"FINISHED"}

class wplcurve_curve_2mesh(bpy.types.Operator):
	bl_label = "Final meshing: Convert curve"
	bl_idname = "curve.wplcurve_curve_2mesh"
	bl_options = {"REGISTER", "UNDO"}
	bl_description = 'Bake curve to mesh with metadata'

	def execute(self, context):
		# if wla.is_local_view():
		# 	self.report({'ERROR'}, "Can`t work in Local view")
		# 	return {'CANCELLED'}
		selobjs = wla.selected_objects(['CURVE', 'POLY', 'NURBS'])
		if len(selobjs) == 0:
			self.report({'INFO'}, 'Select curve object')
			return {"CANCELLED"}
		for active_obj in selobjs:
			wla_do.ensure_visible(active_obj, 2)
			wla_do.select_and_change_mode(active_obj, 'OBJECT')
			curveData = active_obj.data
			curve_poly_lencache = {}
			curve_poly_radcache = {}
			curve_poly_trrcache = {}
			pttree_cache = []
			isGNCurve = False
			invalidModfs = copy.copy(wla_do.kWPLModifsIndexBreakersStrict)
			if wla.modf_by_type(active_obj, 'NODES') is not None:
				invalidModfs.remove('NODES')
				isGNCurve = True
			if isGNCurve == False and len(active_obj.data.materials)>0:
				while len(active_obj.data.materials)<len(curveData.splines):
					active_obj.data.materials.append(active_obj.data.materials[0])
				for i,polyline in enumerate(curveData.splines):
					points = wla_curve.cu_getPoints(polyline)
					polyline.material_index = i
					clen = 0
					crad = 0
					clen_pprev = None
					pttree = KDTree(1000)
					for p in points:
						if clen_pprev is not None:
							clen = clen+(p.co-clen_pprev.co).length
						if p.radius > crad:
							crad = p.radius
						clen_pprev = p
						p_co = Vector((p.co[0], p.co[1], p.co[2]))
						pttree_cache.append( (p_co, p.radius) )
						pttree.insert(p_co, len(pttree_cache)-1)
					pttree.balance()
					curve_poly_lencache[i] = clen
					curve_poly_radcache[i] = crad
					curve_poly_trrcache[i] = pttree
			#print("curves", curve_poly_lencache, curve_poly_radcache)
			if config.kWPLSuppZZZZPrefix in active_obj.name:
				# reruns should not add prefix again
				active_obj.name = active_obj.name.replace(config.kWPLSuppZZZZPrefix, "")
			mfcName = active_obj.name
			active_obj.name = config.kWPLSuppZZZZPrefix + active_obj.name
			curveMeshedObj = wla_do.clone_evaluated_obj(active_obj, mfcName, True, False, invalidModfs)
			curveMeshedMesh = curveMeshedObj.data
			wla_do.select_and_change_mode(curveMeshedObj, 'OBJECT')
			active_obj.hide_render = True
			active_obj.hide_select = True
			active_obj.hide_viewport = True
			if isGNCurve == False:
				# renaming basic UVMap to EdgeUnwrap
				baseUVMap = curveMeshedMesh.uv_layers.get("UVMap")
				if baseUVMap is not None:
					baseUVMap.name = config.kWPLGridUV
					print("- UVMap renamed to", baseUVMap.name)
				curvl_map = wla_attr.uv_obj_ensure(curveMeshedObj, config.kWPLGridUV + "_curvlen")
				for poly in curveMeshedMesh.polygons:
					poly_curv = poly.material_index
					ipoly = poly.index
					for idx, lIdx in enumerate(curveMeshedMesh.polygons[ipoly].loop_indices):
						pt_radmax = curve_poly_radcache[poly_curv]
						pt_len = curve_poly_lencache[poly_curv]
						# calcing average radius
						# ivdx = curveMeshedMesh.polygons[ipoly].vertices[idx]
						# v = curveMeshedMesh.vertices[ivdx]
						# pttree = curve_poly_trrcache[poly_curv]
						# pt_res = pttree.find_n(v.co, 2)
						# if pt_res is not None and len(pt_res) > 1:
						# 	pt_item1 = pttree_cache[pt_res[0][1]]
						# 	pt_item2 = pttree_cache[pt_res[1][1]]
						# 	pt_prj = mathutils.geometry.intersect_point_line(v.co, pt_item1[0], pt_item2[0])
						# # 	pt_diff = pt_prj[0]-v.co # closest point on curve
						# #	pt_width = ((pt_item1[1]+pt_item2[1])*0.5)
						# 	pt_prj_perc = pt_prj[1]
						# 	pt_width = (pt_item2[1]*(pt_prj_perc) + pt_item1[1]*(1.0-pt_prj_perc))
						# curvl_map.data[lIdx].uv = Vector((pt_width, pt_len))
						# Avarage not needed actually... max better
						curvl_map.data[lIdx].uv = Vector((pt_radmax*0.1, pt_len)) # 0.1 - comparison Anna(Curve hairs) vs Mako(GN hairs)
				md_subs = wla.modf_by_type(curveMeshedObj,'SUBSURF')
				if md_subs is not None:
					# enabling stuff to avoid difference in final render
					md_subs.show_on_cage = True
					md_subs.show_in_editmode = True
					md_subs.levels = md_subs.render_levels
		return {"FINISHED"}

# class wplcurve_edges_2curves(bpy.types.Operator):
# 	bl_idname = "mesh.wplcurve_edges_2curves"
# 	bl_label = "Edges to curves"
# 	bl_options = {'REGISTER', 'UNDO'}

# 	opt_curveType : EnumProperty(
# 		name="Curve Type", default="NURBS",
# 		items=(("NURBS", "Nurbs", ""), ("POLY", "Poly", ""))
# 	)
# 	opt_flowDir : FloatVectorProperty(
# 		name	 = "Preferred direction",
# 		size	 = 3,
# 		min=-1.0, max=1.0,
# 		default	 = (0.0,0.0,-1.0)
# 	)
# 	opt_initRadFrac : FloatProperty(
# 		name	 = "Initial radius (edgelen frac)",
# 		min=-100.0000, max=100.0,
# 		default	 = 0.5
# 	)

# 	def execute(self, context):
# 		active_obj = wla.active_object(['MESH'])
#		active_obj_nonoperable = wla.is_object_nonoperable(active_obj, ["obj_multi_user"])
# 		if active_obj_nonoperable is not None:
# 			print("- problem:", active_obj_nonoperable)
# 			self.report({'ERROR'}, "Object not ready:" + active_obj_nonoperable)
# 			return {'CANCELLED'}
# 		active_mesh = active_obj.data
# 		wla_do.select_and_change_mode(active_obj, 'OBJECT')
# 		vertsIdx = wla.selected_vertsIdx(active_mesh)
# 		edgesIdx = wla.selected_edgesIdx(active_mesh)
# 		if len(edgesIdx)<1:
# 			self.report({'ERROR'}, "No selected edges found, select some edges first")
# 			return {'FINISHED'} # or all changes get lost!!!

# 		wla_do.select_and_change_mode(active_obj, 'EDIT')
# 		bm = bmesh.from_edit_mesh(active_mesh)
# 		bm.verts.ensure_lookup_table()
# 		bm.faces.ensure_lookup_table()
# 		bm.verts.index_update()
# 		edgelenAvg = wla_bm.bm_averageEdgeLen(bm, vertsIdx, 1.0)
# 		strands_points,_ = wla_bm.bm_edgesAsStrands_v04(active_obj, bm, vertsIdx, edgesIdx, self.opt_flowDir, None)
# 		if strands_points is None:
# 			self.report({'ERROR'}, "No edges found")
# 			return {'FINISHED'} # or all changes get lost!!!
# 		#print("Edges found",strands_points)
# 		curveObjName = active_obj.name + config.kWPLObjProtoToken[0]
# 		curveDataName = active_obj.name + "_curve"
# 		curveData = bpy.data.curves.new(curveDataName, type='CURVE')
# 		curveData.dimensions = '3D'
# 		curveData.twist_mode = 'MINIMUM' #'TANGENT'
# 		curveData.fill_mode = 'FULL'
# 		if self.opt_initRadFrac>0:
# 			curveData.bevel_depth = edgelenAvg*self.opt_initRadFrac
# 		else:
# 			curveData.bevel_depth = abs(self.opt_initRadFrac)
# 		curveData.bevel_resolution = 2
# 		curveOB = bpy.data.objects.new(curveObjName, curveData)
# 		wla_do.link_object_sideBySide(curveOB, active_obj)
# 		if len(curveOB.data.materials) == 0 and len(active_obj.data.materials)>0:
# 			curveOB.data.materials.append(active_obj.data.materials[0])
# 		#activeName = active_obj.name
# 		#curveName = curveOB.name
# 		for i,strand_curve in enumerate(strands_points):
# 			polyline = curveData.splines.new(self.opt_curveType)
# 			polyline.points.add(len(strand_curve) - 1)
# 			for j, co in enumerate(strand_curve):
# 				polyline.points[j].co = (co[0], co[1], co[2], 1)
# 			if self.opt_curveType == 'NURBS':
# 				polyline.order_u = 3 # like bezier thing
# 				polyline.use_endpoint_u = True
# 		wla_do.select_and_change_mode(active_obj, 'OBJECT')
# 		wla_do.attach_objToSourceObject(curveOB, active_obj, False, True, 0)
# 		return {'FINISHED'}

# class wplcurve_fastpin_mesh_apl(bpy.types.Operator):
# 	bl_idname = "curve.wplcurve_fastpin_mesh_apl"
# 	bl_label = "Align curve to stored edgeline"
# 	bl_options = {'REGISTER', 'UNDO'}

# 	opt_onlySelection : BoolProperty(
# 		name="Only Selected",
# 		default=True
# 	)

# 	opt_invertDir : BoolProperty(
# 		name="Invert direction",
# 		default=False
# 	)

# 	def execute( self, context ):
# 		active_obj = wla.active_object(['CURVE']) # , 'POLY', 'NURBS' -> BEZIER needed for BEZIER-mesh-shaper
# 		if active_obj is None:
# 			self.report({'INFO'}, 'Use operator on curve type object')
# 			return {"CANCELLED"}
# 		wla_do.select_and_change_mode(active_obj,'EDIT')
# 		curveData = active_obj.data
# 		if (config.kWPLGKey_EdgePinStrands not in config.WPL_G.store):
# 			self.report({'ERROR'}, "Pin points first")
# 			return {'CANCELLED'}
# 		okPts = 0
# 		curStr = 0
# 		(strands_points, _) = config.WPL_G.store[config.kWPLGKey_EdgePinStrands]
# 		for i,polyline in enumerate(curveData.splines):
# 			pns = wla_curve.cu_getPoints(polyline)
# 			if self.opt_onlySelection:
# 				pns = wla_curve.cu_getPointsSel(polyline)
# 			if len(pns) < 2:
# 				continue
# 			strand = strands_points[curStr]
# 			t_yp_px = []
# 			t_yp_py = []
# 			t_yp_pz = []
# 			len_trg = 0
# 			t_xp = []
# 			gp_p_last = None
# 			for gp_p in strand:
# 				t_yp_px.append(gp_p[0])
# 				t_yp_py.append(gp_p[1])
# 				t_yp_pz.append(gp_p[2])
# 				if gp_p_last is not None:
# 					len_trg = len_trg+(gp_p_last-gp_p).length
# 				t_xp.append(len_trg)
# 				gp_p_last = gp_p
# 			if len_trg>0.00001:
# 				if polyline.type == 'NURBS' or polyline.type == 'POLY':
# 					for j, curve_pt in enumerate(pns):
# 						okPts = okPts+1
# 						t_pos = float(j)/float(len(pns)-1)
# 						if self.opt_invertDir:
# 							t_pos = 1.0 - t_pos
# 						new_co_g = Vector((np.interp(t_pos*len_trg, t_xp, t_yp_px), np.interp(t_pos*len_trg, t_xp, t_yp_py), np.interp(t_pos*len_trg, t_xp, t_yp_pz)))
# 						new_co_l = active_obj.matrix_world.inverted() @ new_co_g
# 						curve_pt.co = Vector((new_co_l[0], new_co_l[1], new_co_l[2], 1))
# 				if polyline.type == 'BEZIER':
# 					# specially for Bezier Mesh Shaper
# 					for j, curve_pt in enumerate(pns):
# 						okPts = okPts+1
# 						t_pos = float(j)/float(len(pns)-1)
# 						t_pos_l = float(j-0.3)/float(len(pns)-1)
# 						t_pos_r = float(j+0.3)/float(len(pns)-1)
# 						if self.opt_invertDir:
# 							t_pos = 1.0 - t_pos
# 							t_pos_l = 1.0 - t_pos_l
# 							t_pos_r = 1.0 - t_pos_r
# 						new_co_g = Vector((np.interp(t_pos*len_trg, t_xp, t_yp_px), np.interp(t_pos*len_trg, t_xp, t_yp_py), np.interp(t_pos*len_trg, t_xp, t_yp_pz)))
# 						new_co_l = active_obj.matrix_world.inverted() @ new_co_g
# 						new_coL_g = Vector((np.interp(t_pos_l*len_trg, t_xp, t_yp_px), np.interp(t_pos_l*len_trg, t_xp, t_yp_py), np.interp(t_pos_l*len_trg, t_xp, t_yp_pz)))
# 						new_coL_l = active_obj.matrix_world.inverted() @ new_coL_g
# 						new_coR_g = Vector((np.interp(t_pos_r*len_trg, t_xp, t_yp_px), np.interp(t_pos_r*len_trg, t_xp, t_yp_py), np.interp(t_pos_r*len_trg, t_xp, t_yp_pz)))
# 						new_coR_l = active_obj.matrix_world.inverted() @ new_coR_g
# 						if t_pos_l <= 0.0:
# 							new_coL_l = new_co_l - (new_coR_l-new_co_l)
# 						if t_pos_r >= 1.0:
# 							new_coR_l = new_co_l - (new_coL_l-new_co_l)
# 						curve_pt.co = Vector((new_co_l[0], new_co_l[1], new_co_l[2]))
# 						curve_pt.handle_left = Vector((new_coL_l[0], new_coL_l[1], new_coL_l[2]))
# 						curve_pt.handle_right = Vector((new_coR_l[0], new_coR_l[1], new_coR_l[2]))
# 			curStr = curStr+1
# 			if curStr >= len(strands_points):
# 				break
# 		self.report({'INFO'}, "Done. Aligned points="+str(okPts))
# 		return {'FINISHED'}

class wplcurve_align_tilt_view(bpy.types.Operator):
	bl_label = "Align tilt to camera"
	bl_idname = "curve.wplcurve_align_tilt_view"
	bl_options = {"REGISTER", "UNDO"}
	opt_onlySelection : BoolProperty(
		name="Only Selected",
		default=True
	)
	opt_orientMode : EnumProperty(
		items = [
			('ALIGN_CAM', "Align to Camera", "", 1),
			('ALIGN_COLL', "Align to Collider", "", 2),
		],
		name="Align mode",
		default='ALIGN_CAM',
	)
	opt_independendSplines : BoolProperty(
		name="Independent splines",
		default=True
	)
	opt_stepsPrimary : FloatVectorProperty(
		name="Primary/Secondary steps",
		size=4,
		default=(-180,180,10,10)
	)
	opt_influence : FloatProperty(
		name="Influence",
		default=0.9,
	)

	def invoke(self, context, event):
		if bpy.context.mode == 'OBJECT':
			self.opt_onlySelection = False
		return self.execute(context)

	def execute(self, context):
		active_obj = wla.active_object(['CURVE']) # , 'POLY', 'NURBS' -> BEZIER needed for BEZIER-mesh-shaper
		if active_obj is None:
			self.report({'INFO'}, 'Use operator on curve type object')
			return {"CANCELLED"}
		md_mirr = wla.modf_by_type(active_obj,'MIRROR')
		if (md_mirr is not None) and (md_mirr.show_viewport or md_mirr.show_render):
			self.report({'ERROR'}, "Curve has active MIRROR")
			return {'FINISHED'}
		matrix_world = active_obj.matrix_world
		matrix_world_inv = matrix_world.inverted()
		matrix_world_nrml = matrix_world_inv.transposed().to_3x3()
		camera_gCo, camera_gOrtho, camera_gDir, camera_gDirUp = wla.active_camera()
		if camera_gCo is None:
			self.report({'ERROR'}, "Camera not found: "+config.kWPLSystemMainCam)
			return {'CANCELLED'}
		bvh2collides = None
		if self.opt_orientMode == 'ALIGN_COLL':
			#verts_snap_map, faces_snap_map = wla_bm.bm_getPinmapFastIdx(active_obj, None, "<collider>")
			bvh2collides = wla_bm.bm_sceneColldersBVH(None, False)
			if len(bvh2collides) == 0:
				self.report({'ERROR'}, "Colliders not found")
				return {'CANCELLED'}
		oldmode = wla_do.select_and_change_mode(active_obj,'OBJECT')
		initilts = {}
		for i, polyline in enumerate(active_obj.data.splines):
			points = wla_curve.cu_getPoints(polyline)
			for j, curvePoint in enumerate(points):
				initilts[curvePoint] = 0.0+curvePoint.tilt
		def getCurvePolyMeasure(p):
			ddt = 0
			if self.opt_orientMode == 'ALIGN_CAM':
				view_dir = camera_gDir
				if camera_gOrtho == False:
					v_co_g = matrix_world @ p.center
					view_dir = (camera_gCo-v_co_g).normalized()
				vnrm_g = matrix_world_nrml @ p.normal
				ddt = view_dir.dot(vnrm_g)
			if self.opt_orientMode == 'ALIGN_COLL' and bvh2collides is not None:
				v_co_g = matrix_world @ p.center
				for bvh_collide in bvh2collides:
					location, normal, index, distance = bvh_collide.find_nearest(v_co_g, 1)
					if location is not None:
						vnrm_g = matrix_world_nrml @ p.normal
						ddt = ddt + normal.dot(vnrm_g)
			#print("- p", p.index, ddt)
			return ddt
		def tiltTryout(splnId, step_tilt, influence, doRealtesting):
			points_count = 0
			wla_do.select_and_change_mode(active_obj,'OBJECT')
			for i, polyline in enumerate(active_obj.data.splines):
				# restoring tilts for non-tryout curves
				points = wla_curve.cu_getPoints(polyline)
				if splnId < 0 or splnId != i:
					continue
				if self.opt_onlySelection:
					points = wla_curve.cu_getPointsSel(polyline)
				if len(points) == 0:
					#nothing to do
					return None
				for j, curvePoint in enumerate(points):  # for strand point
					points_count = points_count+1
					curvePoint.tilt = initilts[curvePoint]+(step_tilt-initilts[curvePoint])*influence
			normalDifference = 0
			if doRealtesting:
				depsgraph = bpy.context.evaluated_depsgraph_get()
				active_obj_eval = active_obj.evaluated_get(depsgraph)
				curveMesh = active_obj_eval.to_mesh()
				testedVerts = 0
				for p in curveMesh.polygons:
					ddt = getCurvePolyMeasure(p)
					normalDifference = normalDifference + ddt
					testedVerts = testedVerts+1
				active_obj_eval.to_mesh_clear()
				#print("- Tryout for curve:", splnId,"; points affected:",points_count,"; angle:",math.degrees(step_tilt),"->",normalDifference)
			return normalDifference
		if self.opt_stepsPrimary[2]>1:
			for splnId in range(len(active_obj.data.splines)):
				maximalDiff = None
				minimalTilt = 0
				minimalTiltAddon = 0
				test_splnId = splnId
				if self.opt_independendSplines == False:
					test_splnId = -1
				for stp in range(int(self.opt_stepsPrimary[2])):
					angle = math.radians(self.opt_stepsPrimary[0])+float(stp)/float(self.opt_stepsPrimary[2]-1)*(math.radians(self.opt_stepsPrimary[1]-self.opt_stepsPrimary[0]))
					diff = tiltTryout(test_splnId, angle, 1.0, True)
					#print("tiltTryout primary", splnId, stp,angle,diff)
					if diff is not None and (maximalDiff is None or diff > maximalDiff):
						maximalDiff = diff
						minimalTilt = angle
				if self.opt_stepsPrimary[3]>1:
					fullStepDeg = (self.opt_stepsPrimary[1]-self.opt_stepsPrimary[0])/(self.opt_stepsPrimary[2]-1)
					finet1 = -fullStepDeg
					finet2 = fullStepDeg
					for stp in range(int(self.opt_stepsPrimary[3])):
						angle = math.radians(finet1)+float(stp)/float(self.opt_stepsPrimary[3]-1)*(math.radians(finet2-finet1))
						diff = tiltTryout(test_splnId, minimalTilt+angle, 1.0, True)
						#print("tiltTryout Finetune", splnId, stp, minimalTilt+angle, diff)
						if diff is not None and (maximalDiff is None or diff > maximalDiff):
							maximalDiff = diff
							minimalTiltAddon = angle
				if maximalDiff is not None:
					print("// Align to view result:", splnId, math.degrees(minimalTilt+minimalTiltAddon), maximalDiff)
				tiltTryout(splnId, minimalTilt+minimalTiltAddon, self.opt_influence, False)
				if test_splnId < 0:
					break
		wla_do.select_and_change_mode(active_obj, oldmode)
		self.report({'INFO'}, "Done")
		return {"FINISHED"}

class wplcurve_merge(bpy.types.Operator):
	bl_idname = "curve.wplcurve_merge"
	bl_label = "Merge selected curves"
	bl_options = {'REGISTER', 'UNDO'}
	# opt_mergeMeth : EnumProperty(
	# 	items = [
	# 		('NEAREST', "Nearest", "", 1),
	# 		('RECUT', "Cut-off", "", 2),
	# 	],
	# 	name="Merge method",
	# 	default='NEAREST',
	# )
	opt_postSubdiv : IntProperty(
		name="Post-subdiv segments",
		min=0, max=10,
		default = 1,
	)

	def execute( self, context ):
		active_obj = wla.active_object(['CURVE', 'POLY', 'NURBS','GPENCIL'])
		if active_obj is None:
			self.report({'INFO'}, 'Use operator on curve type object')
			return {"CANCELLED"}
		wla_do.select_and_change_mode(active_obj,'EDIT')
		(selected_polys_all, _, _) = wla_curve.cu_getSelectedStrokes(active_obj, True, False)
		cu_desel_all(active_obj)
		if len(selected_polys_all) < 2:
			self.report({'ERROR'}, "Select two distinct curves first")
			return {'CANCELLED'}
		minpp = None
		# if self.opt_mergeMeth == 'RECUT':
		# 	minpp = []
		# 	cu_desel_all(active_obj)
		# 	for curv in range(0,2):
		# 		pt_sel = selected_polys_pnt[curv][0]
		# 		pt_sel_idx = selected_polys_all[curv].index(pt_sel)
		# 		total_pts = len(selected_polys_all[curv])
		# 		#print("pt_sel_idx", pt_sel, pt_sel_idx, len(selected_polys_all[curv]))
		# 		if pt_sel_idx == 0 or pt_sel_idx == total_pts-1:
		# 			minpp.append(pt_sel)
		# 			continue
		# 		pt_curve = selected_polys_curv[curv]
		# 		if pt_sel_idx < total_pts-1-pt_sel_idx:
		# 			minpp.append(pt_curve.points[0])
		# 			for i in reversed(range(0,pt_sel_idx)):
		# 				cu_delPointByIndex(active_obj, pt_curve, i)
		# 		else:
		# 			minpp.append(pt_curve.points[pt_sel_idx])
		# 			for i in reversed(range(pt_sel_idx+1,total_pts)):
		# 				cu_delPointByIndex(active_obj, pt_curve, i)
		# else:
		possibilities = [(selected_polys_all[0][0],selected_polys_all[1][0]),(selected_polys_all[0][0],selected_polys_all[1][-1]),(selected_polys_all[0][-1],selected_polys_all[1][0]),(selected_polys_all[0][-1],selected_polys_all[1][-1])]
		minlen = 9999
		for pp in possibilities:
			posn = (pp[0].co-pp[1].co).length
			if posn<minlen:
				minlen = posn
				minpp = pp
		if minpp is not None:
			wla_curve.cu_setSel(minpp[0], True)
			wla_curve.cu_setSel(minpp[1], True)
			if active_obj.type == 'GPENCIL':
				#bpy.ops.gpencil.stroke_merge()
				bpy.ops.gpencil.stroke_join(type='JOIN')
			else:
				bpy.ops.curve.make_segment()
			if self.opt_postSubdiv>0:
				for i in range(self.opt_postSubdiv):
					cu_subd_sel(active_obj, 1)
			(selected_polys_all, _, _) = wla_curve.cu_getSelectedStrokes(active_obj, False, False)
			for poly in selected_polys_all:
				wla_curve.cu_rescale_radius(poly, kWPLDefaultBevelProfile, 0.5, 0)
		return {'FINISHED'}

class wplcurve_disjoint(bpy.types.Operator):
	bl_label = "Disjoint selected curves"
	bl_idname = "curve.wplcurve_disjoint"
	bl_options = {"REGISTER", "UNDO"}

	def execute(self, context):
		active_obj = wla.active_object(['CURVE', 'POLY', 'NURBS', 'GPENCIL'])
		if active_obj is None:
			self.report({'INFO'}, 'Use operator on curve type object')
			return {"CANCELLED"}
		wla_do.select_and_change_mode(active_obj, 'EDIT')
		# (selected_polys_all, selected_polys_sel, _) = wla_curve.cu_getSelectedStrokes(active_obj, True, False)
		# for i in range(len(selected_polys_all)):
		# 	points_all = selected_polys_all[i]
		# 	points_sel = selected_polys_sel[i]
		# 	if(len(points_sel) == 1):
		# 		# selecting to shorter end
		# 		idx = points_all.index(points_sel[0])
		# 		if idx > len(points_all)/2:
		# 			if idx < len(points_all)-1:
		# 				wla_curve.cu_setSel(points_all[idx+1], True)
		# 		else:
		# 			if idx > 0:
		# 				wla_curve.cu_setSel(points_all[idx-1], True)
		# subdiving and deleting inners
		# remebering points coKeys, since GP selects nothing after delete...
		all_pcCoKeys = []
		if active_obj.type == 'GPENCIL':
			bpy.ops.gpencil.select_more()
			bpy.ops.gpencil.stroke_subdivide(number_cuts = 1, only_selected=True, smooth_thickness = False, smooth_strength = True, smooth_position = False)
			(_, selected_polys_sel, _) = wla_curve.cu_getSelectedStrokes(active_obj, False, False)
			for points_sel in selected_polys_sel:
				for pt in points_sel:
					all_pcCoKeys.append(wla.coToKey(pt.co))
			bpy.ops.gpencil.select_less()
			bpy.ops.gpencil.select_less()
			bpy.ops.gpencil.delete(type='POINTS')
		else:
			bpy.ops.curve.select_more()
			bpy.ops.curve.subdivide(number_cuts = 1)
			(_, selected_polys_sel, _) = wla_curve.cu_getSelectedStrokes(active_obj, False, False)
			for points_sel in selected_polys_sel:
				for pt in points_sel:
					all_pcCoKeys.append(wla.coToKey(pt.co))
			bpy.ops.curve.select_less()
			bpy.ops.curve.delete(type='SEGMENT')
		cu_desel_all(active_obj)
		okCnt = 0
		splines = wla_curve.cu_getSplines(active_obj)
		for polyline in splines:
			pts = wla_curve.cu_getPoints(polyline)
			needRetaper = False
			for pt in pts:
				if wla.coToKey(pt.co) in all_pcCoKeys:
					needRetaper = True
					break
			if needRetaper:
				okCnt = okCnt+1
				wla_curve.cu_rescale_radius(pts, kWPLDefaultBevelProfile, 0.5, 0)
		self.report({'INFO'}, "Done. verts="+str(okCnt))
		return {"FINISHED"}

class wplcurve_recreate(bpy.types.Operator):
	bl_label = "Recreate from selected"
	bl_idname = "curve.wplcurve_recreate"
	bl_options = {"REGISTER", "UNDO"}

	opt_postSubd : IntProperty (
		name = "Subdivide curve",
		default = 0
	)
	opt_delUsed : BoolProperty (
		name = "Delete used",
		default = True
	)
	opt_mergeByDst : FloatProperty (
		name = "Merge by distance",
		min=0.0, max=10,
		default = 0.002
	)
	opt_mode : EnumProperty(
		name="Mode", default="DST3D",
		items=(("DST3D", "3D-distance", ""), ("DST2D", "2D-distance (mainCam)", "") )
	)

	def execute(self, context):
		camera_obj = wla.object_by_name(config.kWPLSystemMainCam)
		if camera_obj is None:
			self.report({'ERROR'}, "Camera not found: "+config.kWPLSystemMainCam)
			return {'CANCELLED'}
		camera_gCo = camera_obj.matrix_world.to_translation()
		active_obj = wla.active_object(['CURVE', 'POLY', 'NURBS','GPENCIL'])
		if active_obj is None:
			self.report({'INFO'}, 'Use operator on curve type object')
			return {"CANCELLED"}
		oldmode = wla_do.select_and_change_mode(active_obj, 'EDIT')
		curveData = active_obj.data
		basePoints = []
		basePoints_co = {}
		basePoints_co3d = {}
		curveMatIdx = None
		(selected_polys_all, selected_polys_sel, selected_polys_cu) = wla_curve.cu_getSelectedStrokes(active_obj, True, True)
		gp_layer2add = None
		if active_obj.type == 'GPENCIL':
			for i1, layer in enumerate(curveData.layers):
				for i2, polyline in enumerate(layer.active_frame.strokes):
					if polyline in selected_polys_cu:
						gp_layer2add = layer
						break
		for i in range(len(selected_polys_all)):
			#points_all = selected_polys[i]
			points_sel = selected_polys_sel[i]
			if(len(points_sel) > 0):
				if curveMatIdx is None:
					curveMatIdx = selected_polys_cu[i].material_index
				for sp in points_sel:
					sp_co = Vector((sp.co[0], sp.co[1], sp.co[2]))
					basePoints_co3d[sp] = sp_co
					if self.opt_mode == 'DST2D':
						prj_co_l = wla.math_vecCamProj(active_obj, active_obj.matrix_world @ sp_co, True, None)
						if prj_co_l is not None:
							sp_co = prj_co_l
							# sp.co = (prj_co[0], prj_co[1], prj_co[2],1.0) # DBG !!!
					if self.opt_mergeByDst > 0.0:
						for sp2, sp2_co in basePoints_co.items():
							if (sp2_co-sp_co).length < self.opt_mergeByDst:
								# ignoring
								sp_co = None
								# replacing position with camera-closest
								sp2_co3d = basePoints_co3d[sp2]
								if (camera_gCo-basePoints_co3d[sp]).length > (camera_gCo-sp2_co3d).length:
									basePoints_co3d[sp] = sp2_co3d
									wla_curve.cu_setCo(sp, sp2_co3d[0], sp2_co3d[1], sp2_co3d[2])
									#sp.co = (sp2_co3d[0], sp2_co3d[1], sp2_co3d[2], 1.0)
								break
					if sp_co is not None:
						basePoints.append(sp)
						basePoints_co[sp] = sp_co
		# first point. most sharp angle from others
		basePoints2 = []
		for sp1 in basePoints:
			sumDot = 999
			for sp2 in basePoints:
				for sp3 in basePoints:
					if sp1==sp2 or sp1==sp3 or sp2==sp3:
						continue
					sp1co = basePoints_co[sp1]
					sp2co = basePoints_co[sp2]
					sp3co = basePoints_co[sp3]
					ddot = (sp2co-sp1co).normalized().dot((sp3co-sp1co).normalized())
					sumDot = min(sumDot, ddot) # most widest angle needed
			basePoints2.append((sp1, sumDot))
		basePoints2 = sorted(basePoints2, key=lambda v:v[1], reverse=True)
		# sorting new points by distance
		basePoints3 = []
		basePoints3.append(basePoints2[0][0])
		while len(basePoints3)<len(basePoints):
			sp1 = basePoints3[-1]
			nextp = None
			nextpDist = 999
			for sp2 in basePoints:
				if sp2 in basePoints3:
					continue
				sp1co = basePoints_co[sp1]
				sp2co = basePoints_co[sp2]
				sp12len = (sp2co-sp1co).length
				if sp12len < nextpDist:
					nextpDist = sp12len
					nextp = sp2
			if nextp is None:
				break
			basePoints3.append(nextp)
		# creating new curve
		newPolyPoints = []
		if len(basePoints3) > 1:
			if active_obj.type == 'GPENCIL':
				if gp_layer2add is not None:
					stroke = gp_layer2add.active_frame.strokes.new()
					stroke.line_width = selected_polys_cu[0].line_width
					stroke.material_index = selected_polys_cu[0].material_index
					stroke.points.add(len(basePoints3))
					stroke.start_cap_mode = 'FLAT'
					stroke.end_cap_mode = 'FLAT'
					for j, sp in enumerate(basePoints3):
						newPolyPoints.append(stroke.points[j])
						stroke.points[j].co = (sp.co[0], sp.co[1], sp.co[2])
						stroke.points[j].pressure = sp.pressure
			else:
				newPolyline = curveData.splines.new('NURBS')
				newPolyline.order_u = 3 # like bezier thing
				newPolyline.use_endpoint_u = True
				newPolyline.points.add(len(basePoints3) - 1)
				if curveMatIdx is not None:
					newPolyline.material_index = curveMatIdx
				for j, sp in enumerate(basePoints3):
					newPolyPoints.append(newPolyline.points[j])
					newPolyline.points[j].co = (sp.co[0], sp.co[1], sp.co[2], 1)
					newPolyline.points[j].radius = sp.radius
			wla_curve.cu_rescale_radius(newPolyPoints, kWPLDefaultBevelProfile, 0.5, 0.0)
		if self.opt_delUsed:
			for poly in selected_polys_all:
				cu_desel_all(active_obj)
				for p in poly:
					wla_curve.cu_setSel(p, True)
				cu_delv_sel(active_obj)
		cu_desel_all(active_obj)
		for sp in newPolyPoints:
			wla_curve.cu_setSel(sp, True)
		if self.opt_postSubd>0:
			cu_subd_sel(active_obj, self.opt_postSubd)
		# if active_obj.type == 'GPENCIL':
		# 	wla_do.select_and_change_mode(active_obj, 'OBJECT')
		wla_do.select_and_change_mode(active_obj, oldmode)
		self.report({'INFO'}, "Done. verts="+str(len(newPolyPoints)))
		return {"FINISHED"}

class wplcurve_strokes_copy(bpy.types.Operator):
	bl_idname = "curve.wplcurve_strokes_copy"
	bl_label = "GP Copy/Cut strokes"
	bl_description = "Copy/Cut strokes to paperclip"
	bl_options = {"REGISTER"}

	opt_mode : EnumProperty(
		name="Mode", default="COPY",
		items=(("COPY", "Copy", ""), ("CUT", "Cut", "") )
	)

	def execute(self, context):
		#ct = check_pressure()
		active_obj = wla.active_object(['GPENCIL','CURVE'])
		if active_obj is None:
			self.report({'INFO'}, 'Use operator on GP/CURVE')
			return {"CANCELLED"}
		isCopy = True
		if self.opt_mode != 'COPY':
			isCopy = False
		strokelist = None
		if active_obj.type == 'CURVE':
			strokelist = wla_curve.cu_copycut_strokes(active_obj, copy=isCopy)
		if active_obj.type == 'GPENCIL':
			strokelist = wla_curve.gp_copycut_strokes(active_obj, copy=isCopy, keep_empty=True)
		if not strokelist:
			self.report({'ERROR'},'Failed to copy/cut')
			return {"CANCELLED"}
		bpy.context.window_manager.clipboard = json.dumps(strokelist)
		if isCopy:
			self.report({'INFO'}, 'Copy: done')
		else:
			self.report({'INFO'}, 'Cut: done')
		return {"FINISHED"}

class wplcurve_strokes_paste(bpy.types.Operator):
	bl_idname = "curve.wplcurve_strokes_paste"
	bl_label = "GP Paste strokes"
	bl_description = "Paste stroke from paperclip"
	bl_options = {"REGISTER"}

	@classmethod
	def poll(cls, context):
		return True

	def execute(self, context):
		#add a validity check por the content of the paperclip (check if not data.startswith('[{') ? )
		active_obj = wla.active_object(['GPENCIL','CURVE'])
		if active_obj is None:
			self.report({'INFO'}, 'Use operator on GP/CURVE')
			return {"CANCELLED"}
		try:
			data = json.loads(bpy.context.window_manager.clipboard)
		except:
			self.report({'ERROR'}, 'Clipboard does not contain drawing data (load error)')
			return {"CANCELLED"}
		if active_obj.type == 'CURVE':
			wla_curve.cu_paste_multiple_strokes(active_obj, data)
		if active_obj.type == 'GPENCIL':
			wla_curve.gp_paste_multiple_strokes(active_obj, data, None, True)
		self.report({'INFO'},'Paste: done')
		return {"FINISHED"}

# ===================================================

class WPL_PT_CurvesPanel(bpy.types.Panel):
	bl_idname = "WPL_PT_CurvesPanel"
	bl_label = "Curve tools"
	bl_space_type = 'VIEW_3D'
	bl_region_type = 'UI'
	bl_category = 'CU/GP'

	def draw(self, context):
		active_obj = wla.active_object(['CURVE', 'POLY', 'NURBS', 'BEZIER', 'GPENCIL'])
		layout = self.layout
		col = layout.column()
		if wla.is_edit_mode():
			row = col.row()
			row.operator("curve.wplcurve_curves_hidepnt", text="Heads", icon="TRACKING_REFINE_FORWARDS").opt_actionType = 'HEADS'
			row.operator("curve.wplcurve_curves_hidepnt", text="Tails", icon="TRACKING_REFINE_BACKWARDS").opt_actionType = 'TAILS'
			# row.operator("curve.wplcurve_curves_hidepnt", text="HIDE", icon="HIDE_ON").opt_actionType = 'HIDE'
			col.separator()
		if wla.is_edit_mode() and (active_obj is not None) and active_obj.type == 'CURVE':
			col.operator("curve.wplcurve_smooth_pos", text="Smooth curves", icon="MOD_SMOOTH").opt_iters = 10
			#row.operator("mesh.wplsculpt_flt_toconvex_view2d", text = 'Convex 2D', icon = 'SHADING_WIRE')
			row = col.row(align=True)
			row.operator("mesh.wplsculpt_flt_toconvex_view2d", text = '<<', icon="TRIA_LEFT_BAR").opt_normCastMode = "VIEWL"
			row.operator("mesh.wplsculpt_flt_toconvex_view2d", text = 'UP', icon="TRIA_UP_BAR").opt_normCastMode = "VIEWT"
			row.operator("mesh.wplsculpt_flt_toconvex_view2d", text = 'DN', icon="TRIA_DOWN_BAR").opt_normCastMode = "VIEWB"
			row.operator("mesh.wplsculpt_flt_toconvex_view2d", text = '>>', icon="TRIA_RIGHT_BAR").opt_normCastMode = "VIEWR"
			row = col.row()
			row.operator("curve.wplcurve_evenly_pts", text="Straighten", icon = 'IPO_LINEAR').opt_linearizeCo = 1.0
			row.operator("mesh.wplsculpt_stepsubd", text="Subd +1", icon="MOD_PARTICLE_INSTANCE")
			op = row.operator("curve.wplcurve_radius_tilt", text="Reset Ra/Ti")
			op.opt_radius_add = (0.0,1.0)
			op.opt_tilt_add = (0.0,0.0)
			row = col.row()
			op = row.operator("curve.wplcurve_taper_pts", text="Taper curves", icon="SPHERECURVE")
			op.opt_EvalMul = kWPLDefaultProfileMulFac
			row.operator("curve.wplcurve_evenly_pts", text = "Distribute", icon="PARTICLE_POINT").opt_linearizeCo = 0.0
			# row.operator("curve.wplcurve_blendtips_pts", text = "UnBend sides")
			col.separator()
			col.separator()
			row = col.row()
			row.operator("curve.wplcurve_recreate", text = "Recreate", icon="CURVE_DATA").opt_mode = 'DST2D'
			row.operator("curve.wplcurve_merge", text = "Merge Heads")
			#row.operator("curve.wplcurve_merge", text = "Join here").opt_mergeMeth = 'RECUT'
			row = col.row()
			row.operator("curve.wplcurve_cnormalize", text="NORMALIZE", icon="ORPHAN_DATA")
			row.operator("curve.wplcurve_disjoint", text = "Disjoint", icon="DECORATE_LIBRARY_OVERRIDE")
			col.separator()
			box1x = col.column(align=True)
			box1x.operator("curve.wplcurve_fastpin_ini", icon="SNAP_NORMAL")
			row = box1x.row(align=True)
			op = row.operator("curve.wplcurve_fastpin_apl", text = "Smooth selection", icon="GP_SELECT_POINTS")
			op.opt_pinType = 'NOWSEL'
			op = row.operator("curve.wplcurve_fastpin_apl", text = "Enforce pinned")
			op.opt_pinType = 'INISEL'
			col.separator()
			row = col.row()
			row.operator("curve.wplcurve_symmetrize_pts", text="Symmetrize")
			row.operator("curve.wplcurve_forcexmirr", text="Curve XMirror", icon = 'MOD_MIRROR')
			# if active_obj.type == 'CURVE' and active_obj.data.bevel_object is not None:
			# 	row.operator("curve.wplcurve_edit_bevel", text='Edit Bevel').opt_curveType = 'BEVEL'
			# else:
			# 	row.operator("curve.wplcurve_add_bevel", text='Add Bevel')
			# if active_obj.data.taper_object is not None:
			# 	row.operator("curve.wplcurve_edit_bevel", text='T: EDIT', icon="OUTLINER_OB_SURFACE").opt_curveType = 'TAPER'
		if wla.is_edit_mode() and (active_obj is not None) and active_obj.type == 'GPENCIL':
			row1 = col.row()
			row1.operator("curve.wplcurve_recreate", text = "RECREATE", icon="CURVE_DATA").opt_mode = 'DST2D'
			row1.operator("curve.wplcurve_smooth_pos", text="SMOOTH", icon="MOD_SMOOTH").opt_iters = 2
			row1 = col.row()
			spl1 = row1.split(align=True, factor = 0.5)
			op1 = spl1.operator("curve.wplcurve_taper_pts", text="Taper curves", icon="SPHERECURVE")
			op1.opt_EvalMul = kWPLDefaultProfileMulFac
			op2 = spl1.operator("curve.wplcurve_taper_pts", text="2Left")
			op2.opt_EvalMul = kWPLDefaultProfileMulLFac
			op3 = spl1.operator("curve.wplcurve_taper_pts", text="2Right")
			op3.opt_EvalMul = kWPLDefaultProfileMulRFac

			row = col.row(align=True)
			row.operator("mesh.wplsculpt_flt_toconvex_view2d", text = '<<', icon="TRIA_LEFT_BAR").opt_normCastMode = "VIEWL"
			row.operator("mesh.wplsculpt_flt_toconvex_view2d", text = 'UP', icon="TRIA_UP_BAR").opt_normCastMode = "VIEWT"
			row.operator("mesh.wplsculpt_flt_toconvex_view2d", text = 'DN', icon="TRIA_DOWN_BAR").opt_normCastMode = "VIEWB"
			row.operator("mesh.wplsculpt_flt_toconvex_view2d", text = '>>', icon="TRIA_RIGHT_BAR").opt_normCastMode = "VIEWR"
			col.separator()
			row = col.row()
			row.operator("curve.wplcurve_evenly_pts", text="Straighten", icon = 'IPO_LINEAR').opt_linearizeCo = 1.0
			row.operator("curve.wplcurve_evenly_pts", text = "Distribute", icon="PARTICLE_POINT").opt_linearizeCo = 0.0
			# if active_obj.constraints.get(ops_prop_edging.kWPLEdgeSecondariesTrackConName):
			# 	# face secondaries
			# 	gp_segms = -0.005
			row = col.row()
			row.operator("mesh.wplsculpt_stepsubd", text="Subd +1", icon="MOD_PARTICLE_INSTANCE")
			row.operator("curve.wplcurve_disjoint", text = "Disjoint", icon="DECORATE_LIBRARY_OVERRIDE")
			col.separator()
			box1x = col.column(align=True)
			row = box1x.row(align=True)
			row.operator('curve.wplcurve_strokes_copy', text='GP Copy', icon='COPYDOWN').opt_mode = 'COPY'
			row.operator('curve.wplcurve_strokes_copy', text='GP Cut', icon='PASTEFLIPUP').opt_mode = 'CUT'
			box1x.operator('curve.wplcurve_strokes_paste', text='GP Paste strokes', icon='PASTEDOWN')
			box1x.separator()
			row = box1x.row()
			row.operator("object.wplbind_cleanup_edging_cc_gp", text="Cleanup Intersections").opt_onlySelected = True
			row.operator("curve.wplcurve_cnormalize", text="NORMALIZE", icon="ORPHAN_DATA").opt_ensureSegmentLength = -0.03
			row = box1x.row(align=True)
			op = row.operator("mesh.wplbind_maskout", text='GP: ZHide', icon = 'MOD_MASK')
			op.opt_extraAction = 'HIDE'
			op = row.operator("mesh.wplbind_maskout", text='GP: ZUnhide')
			op.opt_extraAction = 'UNHIDE'
			# op = spl1.operator("mesh.wplbind_maskout", text='GP: ZUnhide && Cleanup')
			# op.opt_extraAction = 'SWAP'
			box1x.separator()
			op = box1x.operator("mesh.wplbind_maskout", text='GP: Extract to clean', icon = 'MOD_MASK')
			op.opt_extraAction = 'EXTRACT'
		if len(wla.selected_objects(['CURVE'])) > 0:# can be with Empties, etc
			col.separator()
			box1x = col.column(align=True)
			row = box1x.row(align=True)
			row.operator('curve.wplcurve_strokes_copy', text='CV Copy', icon='COPYDOWN').opt_mode = 'COPY'
			row.operator('curve.wplcurve_strokes_copy', text='CV Cut', icon='PASTEFLIPUP').opt_mode = 'CUT'
			box1x.operator('curve.wplcurve_strokes_paste', text='CV Paste strokes', icon='PASTEDOWN')
			col.separator()
			row = col.row(align=True)
			row.operator("curve.wplcurve_align_tilt_view", text="Orient to camera", icon = 'CAMERA_DATA').opt_orientMode = 'ALIGN_CAM'
			row.operator("curve.wplcurve_align_tilt_view", text="Orient to colliders").opt_orientMode = 'ALIGN_COLL'
			col.separator()
			col.operator("curve.wplcurve_curve_2mesh", icon="FILE_REFRESH")
		# active_curve_any = wla.active_object(['CURVE'])
		# if (active_curve_any is not None) and (config.kWPLGKey_EdgePinStrands in config.WPL_G.store):
		# 	col.separator()
		# 	col.operator("curve.wplcurve_fastpin_mesh_apl", icon="PARTICLE_TIP")
		#if wla.active_object(['MESH']) is not None:
		# box.operator("mesh.wplcurve_edges_2curves", text="Edges to curves", icon="FILE_REFRESH")
		if wla.is_edit_mode() and wla.active_object(['MESH']) is not None:
			col.separator()
			col.operator("mesh.wplverts_sele_toggleact", text="vSel: Toggle edge tip").opt_mode='TOGGLE'
			col.operator("mesh.wplvc_cppaste", text="Isls: Add Segment by fSel").opt_op = 'SEGMENT'
			row = col.row()
			row.operator("object.wplbind_manual_edging_gp", text="SysE: vHist").opt_mode = 'EDIT_VHIST'
			row.operator("object.wplbind_manual_edging_gp", text="SysE: vSel/fSel").opt_mode = 'EDIT_SEL'
			# col.operator("object.wplbind_auto_fill_gp", text="SysE: GP-Fill").opt_mode = 'EDIT_SEL'
		if wla.is_object_mode():
			if len(wla.selected_objects(['CURVE', 'MESH']))>0:
				col.separator()
				row = col.row()
				row.operator("object.wplbind_auto_edging_gp", text="Edges: GP-Converter")
				row.operator("object.wplbind_lineart_edging", text="Edges: Add LineArt")
				# col.operator("object.wplbind_auto_fill_gp", text="Objects: Generate GP-Fills (per mat)").opt_mode = 'ALL_FACES_SUBD'
			if len(wla.selected_objects(['GPENCIL'])) > 0:# can be with Empties, etc
				active_obj = wla.active_object(['GPENCIL']) # still CAN be NONE
				col.separator()
				if active_obj is not None and wla.isTokenInStr(config.kWPLObjEdgeOutlToken, active_obj.name):
					col.operator("object.wplbind_outline_rebound", text="SysE: Outlines: Rebound to GP-Edges")
				if active_obj is not None and wla.isTokenInStr(config.kWPLObjEdgeToken, active_obj.name):
					col.operator("object.wplbind_outline_edging_dup", text="SysE: GP-Edges: Duplicate to outline")

# ==========================================
# ==========================================

classes = (
	WPL_PT_CurvesPanel,
	wplcurve_curves_hidepnt,
	wplcurve_merge,
	wplcurve_disjoint,
	wplcurve_recreate,

	wplcurve_smooth_pos,
	wplcurve_radius_tilt,
	wplcurve_taper_pts,
	wplcurve_evenly_pts,
	# wplcurve_blendtips_pts,

	wplcurve_fastpin_ini,
	wplcurve_fastpin_apl,
	
	wplcurve_cnormalize,
	wplcurve_forcexmirr,
	wplcurve_align_tilt_view,
	wplcurve_symmetrize_pts,

	#wplcurve_add_bevel,
	#wplcurve_edit_bevel,
	#wplcurve_fastpin_mesh_apl,
	#wplcurve_edges_2curves,
	wplcurve_curve_2mesh,
	wplcurve_svg_2mesh,

	wplcurve_strokes_copy,
	wplcurve_strokes_paste
)

def register():
	for cls in classes:
		bpy.utils.register_class(cls)

def unregister():
	for cls in reversed(classes):
		bpy.utils.unregister_class(cls)

if __name__ == "__main__":
	register()