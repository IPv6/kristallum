import os, sys, time, datetime
import math, copy, string, random
import numpy as np
import bpy, bmesh, mathutils
from functools import reduce

import bpy.types
from mathutils import Vector, Matrix, Euler, Quaternion
from mathutils.bvhtree import BVHTree
from mathutils.kdtree import KDTree
from bpy_extras import view3d_utils
from bpy.props import *

from . import config
from .tools import wla
from .tools import wla_do
from .tools import wla_bm
from .tools import wla_attr
from .tools import wla_curve
from .tools import wla_meshfair
from .ops_scene_man import _mix3l, _mix3s, _mix2, _mixArc, _cuh, _rndf

kWPDefaultStripifyWHCuh = "333 *avgE"
kWPDefaultStripifyXYCuh = "0 *0"
kWPDefaultStripifyRotCuh = "0"
kWPDefaultStripifyCCCuh = "555"
kWPLDefaultPatchCuh = "0 *avgE"

# ============================================

def getBmVertDupli(bm, bm_v, cach):
	key = "vrt"+str(bm_v.index) #+int(v_dir.dot(Vector((0,0,1)))*2)*1000+int(v_dir.dot(Vector((0,1,0)))*2)*100+int(v_dir.dot(Vector((1,0,0)))*2)*10
	if key in cach:
		return cach[key]
	v_dups = bmesh.ops.duplicate(bm, geom = [bm_v])
	vd = v_dups["geom"][0]
	cach[key] = vd
	return vd

def getVgWeightMapByTokALL(active_obj, vgname):
	vgs = wla_attr.vg_names_by_nameToken(active_obj, vgname)
	if len(vgs) == 0:
		return {}, None, None
	vgnames_all = []
	vgmaps_all = []
	wmap_all = {}
	for vgname in vgs:
		wmap = wla_attr.vg_get_weightMap(active_obj, vgname)
		vgnames_all.append(vgname)
		vgmaps_all.append(wmap)
		for vIdx in wmap:
			if (vIdx not in wmap_all) or (wmap_all[vIdx] < wmap[vIdx]):
				wmap_all[vIdx] = wmap[vIdx]
	return wmap_all, vgnames_all, vgmaps_all

class wpldeform_smart_stripify(bpy.types.Operator):
	bl_idname = "mesh.wpldeform_smart_stripify"
	bl_label = "Stripify edges"
	bl_options = {'REGISTER', 'UNDO'}

	opt_action : EnumProperty(
		items = [
			('EDGESEL', "Selected edges", "", 1),
			('VERTHIST', "Vert history", "", 2),
			('INDIVELEM', "Individual", "", 3),
		],
		name="Action",
		default='VERTHIST',
	)
	opt_cuhW : StringProperty(
		name = "Width CUH",
		default = kWPDefaultStripifyWHCuh
	)
	opt_cuhH : StringProperty(
		name = "Height CUH",
		default = kWPDefaultStripifyWHCuh
	)
	opt_cuhU : StringProperty(
		name = "U-offset",
		default = kWPDefaultStripifyXYCuh
	)
	opt_cuhV : StringProperty(
		name = "V-offset",
		default = kWPDefaultStripifyXYCuh
	)
	opt_cuhRot : StringProperty(
		name = "Rotation",
		default = kWPDefaultStripifyRotCuh
	)
	opt_cuhCC : StringProperty(
		name = "Center",
		default = kWPDefaultStripifyCCCuh
	)
	opt_FlowNorml : EnumProperty(
		items = [
			('AUTO', "Auto", "", 1),
			('LOCALZ', "Local Z", "", 2),
			('LOCALX', "Local X", "", 3),
			('LOCALY', "Local Y", "", 4),
		],
		name="Flow normal",
		default='AUTO',
	)
	opt_ResampleEdges : IntProperty(
		name	= "Resample (0 - per vert)",
		default	= 0,
	)
	opt_Solidify : BoolProperty(
		name="Solidify stripe",
		default=True
	)
	opt_PostSelectNew : BoolProperty(
		name="Select added geom",
		default=True
	)

	def resetOpts(self):
		self.opt_cuhW = kWPDefaultStripifyWHCuh
		self.opt_cuhH = kWPDefaultStripifyWHCuh
		self.opt_cuhU = kWPDefaultStripifyXYCuh
		self.opt_cuhV = kWPDefaultStripifyXYCuh
		self.opt_cuhCC = kWPDefaultStripifyCCCuh
		self.opt_cuhRot = kWPDefaultStripifyRotCuh
		self.opt_Solidify = True
		self.opt_ResampleEdges = 0
		return

	def execute( self, context ):
		active_obj = wla.active_object(['MESH'])
		if active_obj is None:
			self.report({'ERROR'}, "Select mesh object first")
			return {'CANCELLED'}
		active_mesh = active_obj.data
		vertsIdx = wla.selected_vertsIdx(active_mesh)
		edgesIdx = wla.selected_edgesIdx(active_mesh)
		facesIdx = wla.selected_facesIdx(active_mesh)
		wla_do.select_and_change_mode(active_obj, 'EDIT')
		if len(vertsIdx) == 0:
			self.resetOpts()
			self.report({'ERROR'}, "No verts (opts reset)")
			return {'FINISHED'}
		if context.tool_settings.mesh_select_mode[2] == True: # 'FACE' selection
			selmode = 2
		elif context.tool_settings.mesh_select_mode[1] == True: # 'EDGE' selection
			selmode = 1
		else:
			selmode = 0
		bm = bmesh.from_edit_mesh(active_mesh)
		bm.verts.ensure_lookup_table()
		bm.verts.index_update()
		bm.edges.ensure_lookup_table()
		bm.edges.index_update()
		bm.faces.ensure_lookup_table()
		bm.faces.index_update()
		refDir = Vector((0,0,1))
		edgelenAvg = wla_bm.bm_averageEdgeLen(bm, vertsIdx, 1.0)
		strands_points = None
		strands_vidx = None
		strands_normals = None
		strands_notcachables = []
		#strands_vnrmreplace = {}
		def finNrm(nrmVec):
			if self.opt_FlowNorml == 'LOCALX':
				nrmVec = Vector((1,0,0))
			if self.opt_FlowNorml == 'LOCALY':
				nrmVec = Vector((0,1,0))
			if self.opt_FlowNorml == 'LOCALZ':
				nrmVec = Vector((0,0,1))
			return Vector(nrmVec)
		if self.opt_action == 'INDIVELEM':
			strands_points = []
			strands_normals = []
			strands_vidx = []
			if len(facesIdx) > 0 and selmode == 2:
				for fIdx in facesIdx:
					f = bm.faces[fIdx]
					flowDir = finNrm(f.normal)
					vIdx = f.verts[0].index
					v_co = f.calc_center_median()
					sideDir = (v_co-f.verts[0].co).normalized()
					vNrm = (sideDir.cross(flowDir)).cross(flowDir)
					#strands_vnrmreplace[vIdx] = (sideDir.cross(flowDir)).cross(flowDir)
					strands_points.append([v_co - flowDir*edgelenAvg*0.5, v_co + flowDir*edgelenAvg*0.5])
					strands_normals.append([vNrm, vNrm])
					strands_vidx.append([vIdx,vIdx])
					strands_notcachables.append(vIdx)
			if len(edgesIdx) > 0 and selmode == 1:
				for eIdx in edgesIdx:
					e = bm.edges[eIdx]
					flowDir = finNrm((e.verts[0].co-e.verts[1].co).normalized())
					vIdx = e.verts[0].index
					v_co =  (e.verts[0].co+e.verts[1].co)*0.5
					sideDir = (v_co-e.link_faces[0].calc_center_median()).normalized()
					vNrm = (sideDir.cross(flowDir)).cross(flowDir)
					#strands_vnrmreplace[vIdx] = (sideDir.cross(flowDir)).cross(flowDir)
					strands_points.append([v_co - flowDir*edgelenAvg*0.5, v_co + flowDir*edgelenAvg*0.5])
					strands_normals.append([vNrm, vNrm])
					strands_vidx.append([vIdx,vIdx])
					strands_notcachables.append(vIdx)
			if len(vertsIdx) > 0 and selmode == 0:
				for vIdx in vertsIdx:
					v = bm.verts[vIdx]
					flowDir = finNrm(v.normal)
					sideDir = refDir
					sideDirAng = -999
					for e in v.link_edges:
						edr = (v.co-e.other_vert(v).co).normalized()
						edrd = abs(edr.dot(refDir))
						if edrd > sideDirAng:
							sideDirAng = edrd
							sideDir = edr
					vNrm = (sideDir.cross(flowDir)).cross(flowDir)
					#strands_vnrmreplace[vIdx] = (sideDir.cross(flowDir)).cross(flowDir)
					strands_points.append([v.co - flowDir*edgelenAvg*0.5, v.co + flowDir*edgelenAvg*0.5])
					strands_normals.append([vNrm, vNrm])
					strands_vidx.append([vIdx,vIdx])
					strands_notcachables.append(vIdx)
		if self.opt_action == 'VERTHIST':
			histVertsIdx = wla_bm.bm_historyVertsIdx(bm)
			if len(histVertsIdx) >= 2:
				strands_points_line = []
				strands_nrms_line = []
				strands_vidx_line = []
				for vIdx in reversed(histVertsIdx):
					v = bm.verts[vIdx]
					strands_points_line.append(v.co)
					strands_nrms_line.append(finNrm(v.normal))
					strands_vidx_line.append(v.index)
				strands_points=[strands_points_line]
				strands_normals=[strands_nrms_line]
				strands_vidx=[strands_vidx_line]
		if self.opt_action == 'EDGESEL':
			if len(edgesIdx) > 0:
				strands_points, strands_vidx = wla_bm.bm_edgesAsStrands_v04(active_obj, bm, vertsIdx, edgesIdx, refDir, None)
				strands_normals = []
				for i, strands_vidx_line in enumerate(strands_vidx):
					strands_nrms_line = []
					for j, vIdx in enumerate(strands_vidx_line):
						v = bm.verts[vIdx]
						strands_nrms_line.append(finNrm(v.normal))
					strands_normals.append(strands_nrms_line)
		#print("strands_points",strands_points,strands_vidx)
		if (strands_points is None) or len(strands_points) == 0:
			self.report({'ERROR'}, "Nothing to do, check selection (no looped, etc)")
			return {'FINISHED'}
		if self.opt_ResampleEdges > 0:
			newlen = self.opt_ResampleEdges + 2
			strands_points2 = []
			strands_normals2 = []
			strands_vidx2 = []
			for i, strands_vidx_line in enumerate(strands_vidx):
				curve_cache = {}
				for j, vIdx in enumerate(strands_vidx_line):
					wla.math_lerpCurveAdd(strands_points[i][j], [ strands_points[i][j], strands_normals[i][j], (j,0,0) ], curve_cache)
				strands_points2_line = []
				strands_normals2_line = []
				strands_vidx2_line = []
				for j in range(0, newlen):
					posFac = float(j)/float(newlen-1)
					ptCo = wla.math_lerpCurveGet(posFac, 0, curve_cache)
					ptNrm = wla.math_lerpCurveGet(posFac, 1, curve_cache)
					ptIdx = wla.math_lerpCurveGet(posFac, 2, curve_cache)
					ptIdx = int(ptIdx[0])
					strands_points2_line.append(ptCo)
					strands_normals2_line.append(ptNrm)
					strands_vidx2_line.append( strands_vidx[i][ptIdx] )
				strands_points2.append(strands_points2_line)
				strands_normals2.append(strands_normals2_line)
				strands_vidx2.append(strands_vidx2_line)
				#print("- resampled curve",len(strands_vidx_line),len(strands_vidx2_line))
			strands_points = strands_points2
			strands_normals = strands_normals2
			strands_vidx = strands_vidx2
		if self.opt_PostSelectNew:
			context.tool_settings.mesh_select_mode = (True, False, False) # 'VERT'
			for v in bm.verts:
				v.select = False
		vIdx_cache = {}
		vIdx_vccache = {}
		def getVertsForStrokePoint(bm, posFac, posCo, posNrm, vIdx, flowDir, flowDirNext):
			sp_key = wla.coToKey(posCo)
			if sp_key in vIdx_cache:
				return vIdx_cache[sp_key]
			bm.verts.ensure_lookup_table()
			bm.verts.index_update()
			bm_v = bm.verts[vIdx]
			facI = posFac # 4EVAL
			avgE = edgelenAvg # 4EVAL
			l_width_scale = 1.0
			l_width_cuh = self.opt_cuhW
			if "*avgE" in l_width_cuh:
				l_width_cuh = l_width_cuh.replace("*avgE","")
				l_width_scale = avgE
			l_width = wla.remap_curve_hash(l_width_cuh, facI) * 2.0 * l_width_scale
			h_offset_scale = 1.0
			h_offset_cuh = self.opt_cuhH
			if "*avgE" in h_offset_cuh:
				h_offset_cuh = h_offset_cuh.replace("*avgE","")
				h_offset_scale = avgE
			h_offset = wla.remap_curve_hash(h_offset_cuh, facI) * h_offset_scale

			u_offset = wla.remap_curve_hash(self.opt_cuhU, facI)
			v_offset = wla.remap_curve_hash(self.opt_cuhV, facI)
			cc_offset = wla.remap_curve_hash(self.opt_cuhCC, facI)
			r_angl_s = wla.remap_curve_hash(self.opt_cuhRot, facI)
			cen_flow = flowDir.normalized()
			cen_perp = posNrm.cross(cen_flow)
			cen_edge_vec = Matrix.Rotation(r_angl_s, 4, cen_flow) @ posNrm
			cen_side_vec = (Matrix.Rotation(r_angl_s, 4, cen_flow) @ cen_perp) * l_width
			posCo = posCo + (u_offset) * cen_perp.normalized() + (v_offset) * posNrm.normalized()
			s3d_prev = None
			s3d_next = None
			if flowDir is not None:
				s3d_prev = posCo-flowDir
			if flowDirNext is not None:
				s3d_next = posCo+flowDirNext
			v1_p = wla.math_vecOffsetClipped(posCo, cen_edge_vec*h_offset+cen_side_vec*cc_offset, s3d_prev, s3d_next, 1)
			v2_p = wla.math_vecOffsetClipped(posCo, cen_edge_vec*h_offset-cen_side_vec*(1.0-cc_offset), s3d_prev, s3d_next, 1)
			v1_dups = bmesh.ops.duplicate(bm, geom = [bm_v])
			v1 = v1_dups["geom"][0]
			v1.co = v1_p
			v2_dups = bmesh.ops.duplicate(bm, geom = [bm_v])
			v2 = v2_dups["geom"][0]
			v2.co = v2_p
			vIdx_cacheval = None
			if self.opt_Solidify:
				v3_p = wla.math_vecOffsetClipped(posCo, -cen_edge_vec*h_offset+cen_side_vec*cc_offset, s3d_prev, s3d_next, 1)
				v4_p = wla.math_vecOffsetClipped(posCo, -cen_edge_vec*h_offset-cen_side_vec*(1.0-cc_offset), s3d_prev, s3d_next, 1)
				#v3 = bm.verts.new(v3_p)
				v3_dups = bmesh.ops.duplicate(bm, geom = [bm_v])
				v3 = v3_dups["geom"][0]
				v3.co = v3_p
				#v4 = bm.verts.new(v4_p)
				v4_dups = bmesh.ops.duplicate(bm, geom = [bm_v])
				v4 = v4_dups["geom"][0]
				v4.co = v4_p
				vIdx_cacheval = (v1,v2,v4,v3)
			else:
				vIdx_cacheval = (v1,v2)
			#print("New points",vIdx,vIdx_cacheval,cen_p,posNrm,cen_perp)
			if vIdx not in strands_notcachables:
				vIdx_cache[sp_key] = vIdx_cacheval
			return vIdx_cacheval
		okCnt = 0
		addedVerts = set()
		for i, strand_curve in enumerate(strands_points):
			if len(strand_curve) < 2:
				print("Bad curve",strand_curve)
				continue
			vIdx_prv = 0
			flowDir = Vector((0,0,0))
			las_num = float(len(strand_curve))
			#print("- handling",i,"of",len(strands_points),"points:",len(strand_curve))
			bm_vf = None
			for j in range(0, len(strand_curve) ):
				bm.verts.ensure_lookup_table()
				bm.faces.ensure_lookup_table()
				vIdx_now = strands_vidx[i][j]
				if vIdx_now > 0:
					bm_v = bm.verts[vIdx_now]
					if len(bm_v.link_faces)>0:
						bm_vf = bm_v.link_faces[0]
				if j > 0:
					coLast = strand_curve[j-1]
					coThis = strand_curve[j]
					nrmLast = strands_normals[i][j-1]
					nrmThis = strands_normals[i][j]
					flowDir = coThis-coLast
					if flowDir.length < 0.00001:
						#self.report({'ERROR'}, "Duplicated verts found")
						print("- Error: duplicated verts, skipping", j)
						continue
					flowDirNext = None
					if j < len(strand_curve)-1:
						coNext = strand_curve[j+1]
						flowDirNext = coNext-coThis
					##########################################
					v_prev = getVertsForStrokePoint(bm, float(j-1)/las_num, coLast, nrmLast, vIdx_prv, flowDir, flowDirNext)
					v_this = getVertsForStrokePoint(bm, float(j)/(las_num-1), coThis, nrmThis, vIdx_now, flowDir, flowDirNext)
					if v_prev is None or v_this is None:
						self.report({'ERROR'}, "Eval compilation: syntax error")
						return {'CANCELLED'}
					addedVerts = addedVerts.union(set(v_prev))
					addedVerts = addedVerts.union(set(v_this))
					#try:
					f1 = bm.faces.new([v_prev[0],v_prev[1],v_this[1],v_this[0]])
					# except Exception as e:
					# 	print("- Error during face creation", e, v_prev, v_this, flowDir, flowDir.length, flowDirNext )
					# 	self.report({'ERROR'}, "Can`t create faces")
					# 	return {'CANCELLED'}
					wla_bm.bm_copy_face2face(bm, bm_vf, f1, vIdx_vccache)
					if self.opt_Solidify:
						f2 = bm.faces.new([v_prev[1],v_prev[2],v_this[2],v_this[1]])
						f3 = bm.faces.new([v_prev[2],v_prev[3],v_this[3],v_this[2]])
						f4 = bm.faces.new([v_prev[3],v_prev[0],v_this[0],v_this[3]])
						wla_bm.bm_copy_face2face(bm, bm_vf, f2, vIdx_vccache)
						wla_bm.bm_copy_face2face(bm, bm_vf, f3, vIdx_vccache)
						wla_bm.bm_copy_face2face(bm, bm_vf, f4, vIdx_vccache)
						# if j == 1:
						# 	# start cap
						# 	f5 = bm.faces.new([v_prev[0],v_prev[1],v_prev[2],v_prev[3]])
						# 	wla_bm.bm_copy_face2face(bm, bm_vf, f5, vIdx_vccache)
						# elif j == len(strand_curve)-1:
						# 	# end cap
						# 	f5 = bm.faces.new([v_this[0],v_this[1],v_this[2],v_this[3]])
						# 	wla_bm.bm_copy_face2face(bm, bm_vf, f5, vIdx_vccache)
					##########################################
					okCnt = okCnt+1
				vIdx_prv = vIdx_now
		bm.verts.ensure_lookup_table()
		bm.verts.index_update()
		bm.faces.ensure_lookup_table()
		bm.faces.index_update()
		bm.normal_update()
		if self.opt_PostSelectNew:
			bpy.ops.mesh.select_all(action = 'DESELECT')
			wla_bm.bm_selectVertEdgesFaces(bm, [v.index for v in addedVerts], None)
			print("- reselected", len(addedVerts))
		bmesh.update_edit_mesh(active_mesh)
		# vg copy not needed - vertex duplication
		# ???.bm_copy_faces2faces
		if okCnt == 0:
			self.report({'INFO'}, "Stripify: Nothing added, no edges/histVerts")
		else:
			self.report({'INFO'}, "Stripify: Faces added: "+str(okCnt))
		return {'FINISHED'}


class wpldeform_smart_patch(bpy.types.Operator):
	bl_idname = "mesh.wpldeform_smart_patch"
	bl_label = "Patch verts"
	bl_options = {'REGISTER', 'UNDO'}

	opt_cuhL : StringProperty(
		name = "Left height CUH",
		default = kWPLDefaultPatchCuh
	)
	opt_cuhR : StringProperty(
		name = "Right height CUH",
		default = kWPLDefaultPatchCuh
	)

	opt_postSel : EnumProperty(
		items = [
			('SELBOTHI', "All except tips", "", 1),
			('SELALL', "All", "", 2),
			('SELLEFT', "Left all", "", 3),
			('SELRIGHT', "Right all", "", 4),
			('SELLEFTI', "Left inner", "", 5),
			('SELRIGHTI', "Right inner", "", 6),
			('SELNOP', "Nothing", "", 7),
		],
		name="Post-selection",
		default='SELBOTHI',
	)

	def resetOpts(self):
		self.opt_cuhL = kWPLDefaultPatchCuh
		self.opt_cuhR = kWPLDefaultPatchCuh
		self.opt_postSel = 'SELNOP'
		return

	def execute( self, context ):
		active_obj = wla.active_object(['MESH'])
		if active_obj is None:
			self.resetOpts()
			self.report({'ERROR'}, "Select mesh (opts reset)")
			return {'CANCELLED'}
		active_mesh = active_obj.data
		wla_do.select_and_change_mode(active_obj, 'EDIT')
		context.tool_settings.mesh_select_mode = (True, False, False) # 'VERT'
		bm = bmesh.from_edit_mesh(active_mesh)
		m_subsurf = wla.modf_by_type(active_obj,'SUBSURF')
		m_crease = None
		if m_subsurf is not None:
			# prepare creasing BEFORE getting BMEdges!!
			if len(bm.edges.layers.crease) > 0:
				m_crease = bm.edges.layers.crease[0]
			else:
				m_crease = bm.edges.layers.crease.new()
		bm.verts.ensure_lookup_table()
		bm.verts.index_update()
		bm.edges.ensure_lookup_table()
		bm.edges.index_update()
		bm.faces.ensure_lookup_table()
		bm.faces.index_update()
		histVerts = wla_bm.bm_historyVertsIdx(bm)
		if len(histVerts) < 3:
			self.resetOpts()
			self.report({'ERROR'}, "No verts, min 3 history (opts reset)")
			return {'FINISHED'}
		edgelenAvg = wla_bm.bm_averageEdgeLen(bm, histVerts, 1.0)
		bmduplisCache = {}
		newFaces = []
		bndEdges = []
		srcf = None
		lastIdx = len(histVerts)-2
		for i in range(0, lastIdx):
			v1 = bm.verts[histVerts[i]]
			v2 = bm.verts[histVerts[i+1]]
			v3 = bm.verts[histVerts[i+2]]
			if srcf is None:
				srcf = v1.link_faces[0]
			vd1 = getBmVertDupli(bm, v1, bmduplisCache)
			vd2 = getBmVertDupli(bm, v2, bmduplisCache)
			vd3 = getBmVertDupli(bm, v3, bmduplisCache)
			EvalL_val = 0.0
			EvalR_val = 0.0
			if i > 0:
				facI = float(i)/float(len(histVerts)-2) # 4EVAL
				avgE = edgelenAvg # 4EVAL
				EvalL_val_scale = 1.0
				EvalL_val_cuh = self.opt_cuhL
				if "*avgE" in EvalL_val_cuh:
					EvalL_val_cuh = EvalL_val_cuh.replace("*avgE","")
					EvalL_val_scale = avgE
				EvalL_val =  wla.remap_curve_hash(EvalL_val_cuh, facI) * EvalL_val_scale
				EvalR_val_scale = 1.0
				EvalR_val_cuh = self.opt_cuhR
				if "*avgE" in EvalR_val_cuh:
					EvalR_val_cuh = EvalR_val_cuh.replace("*avgE","")
					EvalR_val_scale = avgE
				EvalR_val = wla.remap_curve_hash(EvalR_val_cuh, facI) * EvalR_val_scale
			if i%2 == 0:
				vd1.co = v1.co+v1.normal*EvalL_val
				vd2.co = v2.co+v2.normal*EvalR_val
			else:
				vd1.co = v1.co+v1.normal*EvalR_val
				vd2.co = v2.co+v2.normal*EvalL_val
			f = bm.faces.new([vd1,vd2,vd3])
			f.select = False
			wla_bm.bm_copy_face2face(bm, srcf, f, bmduplisCache)
			newFaces.append(f)
			for fe in f.edges:
				if i == 0:
					if (fe.verts[0] == vd1 and fe.verts[1] == vd3) or (fe.verts[1] == vd1 and fe.verts[0] == vd3):
						bndEdges.append(fe)
					if (fe.verts[0] == vd1 and fe.verts[1] == vd2) or (fe.verts[1] == vd1 and fe.verts[0] == vd2):
						bndEdges.append(fe)
				elif i == lastIdx-1:
					if (fe.verts[0] == vd2 and fe.verts[1] == vd3) or (fe.verts[1] == vd2 and fe.verts[0] == vd3):
						bndEdges.append(fe)
					if (fe.verts[0] == vd1 and fe.verts[1] == vd3) or (fe.verts[1] == vd1 and fe.verts[0] == vd3):
						bndEdges.append(fe)
				elif (fe.verts[0] == vd1 and fe.verts[1] == vd3) or (fe.verts[1] == vd1 and fe.verts[0] == vd3):
					bndEdges.append(fe)
		okFaces = len(newFaces)
		if m_crease is not None:
			# bpy.ops.transform.edge_crease(value=1)
			for e in bndEdges:
				e[m_crease] = 1.0
		if self.opt_postSel != 'SELNOP':
			bpy.ops.mesh.select_all(action = 'DESELECT')
			for i in range(0, len(histVerts)):
				v1 = bm.verts[histVerts[i]]
				vd1 = getBmVertDupli(bm, v1, bmduplisCache)
				isStartEnd = False
				if i == 0 or i == len(histVerts)-1:
					isStartEnd = True
				if self.opt_postSel == 'SELLEFT' and ((i%2) == 0 or isStartEnd):
					vd1.select = True
				if (self.opt_postSel == 'SELLEFTI' or self.opt_postSel == 'SELBOTHI') and ((i%2) == 0 and isStartEnd == False):
					vd1.select = True
				if self.opt_postSel == 'SELRIGHT' and ((i%2) == 1 or isStartEnd):
					vd1.select = True
				if (self.opt_postSel == 'SELRIGHTI' or self.opt_postSel == 'SELBOTHI') and ((i%2) == 1 and isStartEnd == False):
					vd1.select = True
				if self.opt_postSel == 'SELALL':
					vd1.select = True
		wla_attr.uv_resetUV(bm, config.kWPLGridUV, [f.index for f in newFaces], (0.0,0.0))
		bmesh.ops.recalc_face_normals(bm, faces=newFaces)
		bm.verts.ensure_lookup_table()
		bm.faces.ensure_lookup_table()
		bm.verts.index_update()
		bm.normal_update()
		bmesh.update_edit_mesh(active_mesh)
		wla_do.select_and_change_mode(active_obj, 'OBJECT')
		wla_do.select_and_change_mode(active_obj, 'EDIT')
		self.report({'INFO'}, "Tri-Patch: Faces added: "+str(okFaces))
		return {'FINISHED'}

class wpldeform_smart_grow_edge(bpy.types.Operator):
	bl_idname = "mesh.wpldeform_smart_grow_edge"
	bl_label = "Grow edge"
	bl_options = {'REGISTER', 'UNDO'}

	opt_stepDst : FloatProperty(
		name = "Step",
		default = 0.03
	)
	opt_cuhProfile: StringProperty(
		name="Profile CUH",
		default="999",
	)
	opt_cuhRotation: StringProperty(
		name="Rotation CUH",
		default="111",
	)
	opt_invertDir: BoolProperty(
		name="Invert direction",
		default=False,
	)

	def execute( self, context ):
		active_obj = wla.active_object(['MESH'])
		if active_obj is None:
			self.report({'ERROR'}, "Select mesh object first")
			return {'CANCELLED'}
		active_mesh = active_obj.data
		facesIdx = wla.selected_facesIdx(active_mesh)
		vertsIdx = wla.selected_vertsIdx(active_mesh)
		edgesIdx = wla.selected_edgesIdx(active_mesh)
		if len(edgesIdx) == 0:
			self.report({'ERROR'}, "No selected edges found")
			return {'FINISHED'}
		wla_do.select_and_change_mode(active_obj, 'EDIT')
		bpy.ops.mesh.select_all( action = 'DESELECT' )
		bm = bmesh.from_edit_mesh(active_mesh)
		bm.verts.ensure_lookup_table()
		bm.verts.index_update()
		bm.edges.ensure_lookup_table()
		bm.edges.index_update()
		bm.faces.ensure_lookup_table()
		bm.faces.index_update()
		if len(facesIdx) > 0:
			# Cut mode
			print("- cut mode")
			context.tool_settings.mesh_select_mode = (True, False, False) # 'VERT'
			newFaces = [bm.faces[fIdx] for fIdx in facesIdx]
			res = bmesh.ops.split(bm, geom=newFaces)
			# clearing GridUV for bound verts
			bndFacesIdx = set()
			for elem in res["geom"]:
				if elem.is_valid == False:
					continue
				elem.select = True
				if isinstance(elem, bmesh.types.BMFace):
					for fv in elem.verts:
						for e in fv.link_edges:
							if (e.is_boundary) or len(e.link_faces) < 2:
								#elem.select = True
								bndFacesIdx.add(elem.index)
								break
			bm.normal_update()
			bmesh.update_edit_mesh(active_mesh)
			wla_do.select_and_change_mode(active_obj, 'OBJECT')
			wla_do.select_and_change_mode(active_obj, 'EDIT')
			bm = bmesh.from_edit_mesh(active_mesh)
			wla_attr.uv_resetUV(bm, config.kWPLGridUV, bndFacesIdx, (0.0,0.0))
			bmesh.update_edit_mesh(active_mesh)
			self.report({'INFO'}, "Cut finished: bndfaces="+str(len(bndFacesIdx)))
			return {'FINISHED'}
		print("- Grow mode")
		_, strands_vidx = wla_bm.bm_edgesAsStrands_v04(active_obj, bm, vertsIdx, edgesIdx, None, None)
		context.tool_settings.mesh_select_mode = (True, False, False) # 'VERT'
		bmduplisCache = {}
		newFaces = []
		okCnt = 0
		verts2sel = []
		for i, strands_vidx_line in enumerate(strands_vidx):
			if self.opt_invertDir:
				strands_vidx_line = list(reversed(strands_vidx_line))
			for j in range(1, len(strands_vidx_line)):
				e_v1 = bm.verts[strands_vidx_line[j-1]]
				e_v2 = bm.verts[strands_vidx_line[j]]
				e_axis = (e_v1.co-e_v2.co).normalized()
				srcf = None
				srcf_nrm = Vector((0,0,0))
				srcf_nrm_c = 0
				for lf in (list(e_v2.link_faces) + list(e_v1.link_faces)):
					if (srcf is None) and (lf not in newFaces):
						srcf = lf
					srcf_nrm_c = srcf_nrm_c+1.0
					srcf_nrm = srcf_nrm + lf.normal
				if srcf is None:
					continue
				fac1 = float(j-1)/float(len(strands_vidx_line)-1)
				fac2 = float(j)/float(len(strands_vidx_line)-1)
				srcf_nrm = srcf_nrm/srcf_nrm_c
				mdir = srcf_nrm.cross(e_axis.normalized())
				mdir1 = mdir.copy()
				mdir1.rotate( Matrix.Rotation( math.radians(wla.remap_curve_hash(self.opt_cuhRotation, fac1)*180), 4, e_axis) )
				mdir2 = mdir.copy()
				mdir2.rotate( Matrix.Rotation( math.radians(wla.remap_curve_hash(self.opt_cuhRotation, fac2)*180), 4, e_axis) )
				vd1 = getBmVertDupli(bm, e_v1, bmduplisCache)
				vd2 = getBmVertDupli(bm, e_v2, bmduplisCache)
				vd1.co = e_v1.co+mdir1*self.opt_stepDst * wla.remap_curve_hash(self.opt_cuhProfile, fac1)
				vd2.co = e_v2.co+mdir2*self.opt_stepDst * wla.remap_curve_hash(self.opt_cuhProfile, fac2)
				f = bm.faces.new([vd1, vd2, e_v2, e_v1])
				verts2sel.append(vd1.index)
				verts2sel.append(vd2.index)
				verts2sel.append(e_v2.index)
				verts2sel.append(e_v1.index)
				f.select = False
				wla_bm.bm_copy_face2face(bm, srcf, f, bmduplisCache)
				newFaces.append(f)
		for v in bm.verts:
			v.select = False
			if v.index in verts2sel and v.index not in vertsIdx:
				v.select = True
		bmesh.ops.recalc_face_normals(bm, faces=newFaces)
		wla_attr.uv_resetUV(bm, config.kWPLGridUV, [f.index for f in newFaces], (0.0,0.0))
		bm.verts.ensure_lookup_table()
		bm.faces.ensure_lookup_table()
		bm.verts.index_update()
		bm.normal_update()
		bmesh.update_edit_mesh(active_mesh)
		wla_do.select_and_change_mode(active_obj, 'OBJECT')
		wla_do.select_and_change_mode(active_obj, 'EDIT')
		self.report({'INFO'}, "Grow finished: "+str(okCnt))
		return {'FINISHED'}

class wpldeform_smart_quads(bpy.types.Operator):
	# Shard edges - guides
	# selected Loop - start line
	bl_idname = "mesh.wpldeform_smart_quads"
	bl_label = "Remesh with quad sword"
	bl_options = {'REGISTER', 'UNDO'}

	opt_cutDensity: FloatProperty(
		name="Number of cuts",
		description="Define the density of the cuts",
		default=5,
		min = 1,
		step = 1
	)
	opt_cutDensityPerAxis: FloatVectorProperty(
		name="Segments per axis",
		size=3, default=(1.0,1.0,1.0),
		min = 0.0,
		max = 50.0
	)

	opt_bboxMargin: FloatProperty(
		name="Margin",
		description="Define the negative margin of the projection",
		default=1.01,
		min = 1,
		max = 5
	)

	opt_cutSelectionOnly: BoolProperty(
		name="Selected Faces Only",
		description="Only cut the selected faces",
		default=False,
	)

	opt_postCleanup: BoolProperty(
		name="Remove old edges",
		default=True,
	)

	# Running as separate dialog
	def invoke(self, context, event):
		return context.window_manager.invoke_props_dialog(self, width = 200)

	def execute( self, context ):
		active_obj = wla.active_object(['MESH'])
		if active_obj is None:
			self.report({'ERROR'}, "Select mesh object first")
			return {'FINISHED'}
		modf_cache = {}
		wla_do.modf_toggle(active_obj, wla_do.kWPLModifsHeavies, False, modf_cache)
		oldmode = wla_do.select_and_change_mode(active_obj,'EDIT')
		if self.opt_cutSelectionOnly:
			if any([v.select == True for v in active_obj.data.vertices]) == False:
				self.report({'ERROR'}, "Select some verts first")
				return {'FINISHED'}
		print("- starting cuts")
		bs = [Vector(p) for p in active_obj.bound_box]
		if self.opt_cutSelectionOnly:
			bpy.ops.mesh.select_mode(type="FACE")
			bpy.ops.mesh.hide(unselected=True)
			bs = [Vector(v.co) for v in active_obj.data.vertices]

		x1 = min(bs, key=lambda e:e.x).x
		x2 = max(bs, key=lambda e:e.x).x
		y1 = min(bs, key=lambda e:e.y).y
		y2 = max(bs, key=lambda e:e.y).y
		z1 = min(bs, key=lambda e:e.z).z
		z2 = max(bs, key=lambda e:e.z).z
		margin = self.opt_bboxMargin
		x1 *= margin
		x2 *= margin
		y1 *= margin
		y2 *= margin
		z1 *= margin
		z2 *= margin
		
		bisect_lines = []
		bisect_lines = bisect_lines+wla_meshfair.bisect_gen_lines(int(self.opt_cutDensity*self.opt_cutDensityPerAxis[0]), Vector((x1, y1, z1)), Vector((x2, y1, z1)), Vector((1, 0, 0)))
		bisect_lines = bisect_lines+wla_meshfair.bisect_gen_lines(int(self.opt_cutDensity*self.opt_cutDensityPerAxis[1]), Vector((x1, y1, z1)), Vector((x1, y2, z1)), Vector((0, 1, 0)))
		bisect_lines = bisect_lines+wla_meshfair.bisect_gen_lines(int(self.opt_cutDensity*self.opt_cutDensityPerAxis[2]), Vector((x1, y1, z1)), Vector((x1, y1, z2)), Vector((0, 0, 1)))
		if len(bisect_lines) == 0:
			self.report({'ERROR'}, "No bisect lines")
			return {'FINISHED'}
		wla_do.select_and_change_mode(active_obj,'OBJECT')
		wla_do.select_and_change_mode(active_obj,'EDIT')
		active_mesh = active_obj.data
		bm = bmesh.from_edit_mesh( active_mesh )
		bm.verts.index_update()
		bm.verts.ensure_lookup_table()
		bm.edges.index_update()
		bm.edges.ensure_lookup_table()
		bm.faces.index_update()
		bm.faces.ensure_lookup_table()
		verts_protect_co = wla_meshfair.bisect_make_mass(bm, bisect_lines)
		bmesh.update_edit_mesh(active_mesh)
		
		if self.opt_postCleanup:
			print("- cleaning mesh, lines",len(bisect_lines))
			maxTries = 50
			while maxTries > 0:
				maxTries = maxTries-1
				wla_do.select_and_change_mode(active_obj,'OBJECT')
				wla_do.select_and_change_mode(active_obj,'EDIT')
				#bpy.ops.mesh.select_all( action = 'DESELECT' )
				active_mesh = active_obj.data
				bm = bmesh.from_edit_mesh( active_mesh )
				bm.verts.index_update()
				bm.verts.ensure_lookup_table()
				bm.edges.index_update()
				bm.edges.ensure_lookup_table()
				bm.faces.index_update()
				bm.faces.ensure_lookup_table()
				vertsUsed = set()
				edges2Diss = []
				diff = 0.0001
				for e in bm.edges:
					if e.hide or any([f.hide == True for f in e.link_faces]):
						continue
					if e.seam or e.is_wire or e.is_boundary or active_obj.data.edges[e.index].use_freestyle_mark:
						continue
					if (e.verts[0] in vertsUsed) or (e.verts[1] in vertsUsed):
						continue
					v0co = e.verts[0].co
					v1co = e.verts[1].co
					isEdgeFromCutlines = False
					for cutpp in bisect_lines:
						dst0 = abs(mathutils.geometry.distance_point_to_plane(v0co, cutpp[0], cutpp[1]))
						dst1 = abs(mathutils.geometry.distance_point_to_plane(v1co, cutpp[0], cutpp[1]))
						if dst0 < diff and dst1 < diff:
							isEdgeFromCutlines = True
							break
					if isEdgeFromCutlines:
						continue
					#e.select = True
					vertsUsed.add(e.verts[0])
					vertsUsed.add(e.verts[1])
					edges2Diss.append(e)
				if len(edges2Diss) == 0:
					print("- nothing to dissolve", maxTries)
					break
				print("- dissolving edges", maxTries, len(edges2Diss))
				bmesh.ops.dissolve_edges(bm, edges = edges2Diss, use_verts=True, use_face_split=False)
				bmesh.update_edit_mesh(active_mesh)
		bpy.ops.mesh.select_all(action = 'DESELECT')
		wla_do.select_and_change_mode(active_obj,'OBJECT')
		wla_do.modf_toggle(active_obj, wla_do.kWPLModifsHeavies, None, modf_cache)
		if self.opt_cutSelectionOnly:
			wla_do.select_and_change_mode(active_obj,'EDIT')
			bpy.ops.mesh.reveal()
			bpy.ops.mesh.select_all(action='INVERT')
		wla_do.select_and_change_mode(active_obj, oldmode)
		self.report({'INFO'}, "Quad sword applied. lines "+str(len(bisect_lines)))
		return {'FINISHED'}

class wpldeform_smart_remesh(bpy.types.Operator):
	# Seam/Wire edges - guides. Quad Wrap/Quad-Wrap
	# selected Loop - start line
	bl_idname = "mesh.wpldeform_smart_remesh"
	bl_label = "Remesh with guides"
	bl_options = {'REGISTER', 'UNDO'}

	opt_guidesMeth : EnumProperty(
		items = [
			#('STOREDEDG', "Saved edgelines", "", 1),
			('WIRE', "Wire edges", "", 1), # selection = Head Ring/Start Points, Wire edges = railing guides
			('SEAM', "Seam edges", "", 2), # selection = Head Ring/Start Points, Seam edges = railing guides
			#('SHARP', "Sharp edges", "", 2), # selection = Head Ring/Start Points, Sharp edges = railing guides
		],
		name="Guides",
		default='WIRE',
	)

	opt_QuadsW : IntProperty(
		name		= "Guide->Guide Quads (0 - edgeflow)",
		default	 = 0,
	)
	opt_QuadsH : IntProperty(
		name		= "Head->Tail Quads (0 - edgeflow)",
		default	 = 0,
	)
	opt_shrinkwrapVerts : BoolProperty(
		name ="Shrinkwrap verts",
		default=False
	)
	opt_closeAround : BoolProperty(
		name ="Close baseloop",
		default=False
	)
	# opt_deleteOriginal : BoolProperty(
	# 	name ="Delete original faces/wires",
	# 	default=False
	# )

	def execute( self, context ):
		active_obj = wla.active_object(['MESH'])
		if active_obj is None:
			self.report({'ERROR'}, "Select mesh object first")
			return {'FINISHED'}
		# if self.opt_guidesMeth == 'STOREDEDG' and (config.kWPLGKey_EdgePinStrands not in config.WPL_G.store):
		# 	self.report({'ERROR'}, "Save some edgelines first")
		# 	return {'FINISHED'}
		active_mesh = active_obj.data
		oldmode = wla_do.select_and_change_mode(active_obj, 'OBJECT')
		modf_cache = {}
		wla_do.modf_toggle(active_obj, wla_do.kWPLModifsIndexBreakersStrict, False, modf_cache)
		selvertsAll = wla.selected_vertsIdx(active_mesh)
		if len(selvertsAll) == 0:
			self.report({'ERROR'}, "Select starting verts first")
			return {'FINISHED'}
		vertsIdx = selvertsAll
		guidEdges = str(self.opt_guidesMeth)
		# if self.opt_guidesMeth == 'SHARP':
		# 	(_, guidEdges) = wla_meshwrap.objectm_extractEdgesByType(active_obj)
		# ordering selected verts
		okCnt = 0
		# faces2del = []
		# verts2del = []
		wla_do.select_and_change_mode(active_obj, 'EDIT')
		bm = bmesh.from_edit_mesh( active_mesh )
		bm.verts.index_update()
		bm.verts.ensure_lookup_table()
		bm.edges.index_update()
		bm.edges.ensure_lookup_table()
		bm.faces.index_update()
		bm.faces.ensure_lookup_table()
		vertsPerIslands = None
		# if self.opt_guidesMeth == 'STOREDEDG':
		# 	vertsIdxAll = []
		# 	guidesFake = []
		# 	fake_vIdx = 1000
		# 	(strands_pointsIni, _) = config.WPL_G.store[config.kWPLGKey_EdgePinStrands]
		# 	for i_s, strand in enumerate(strands_pointsIni):
		# 		guideFake = []
		# 		vertsIdxGuide = []
		# 		for s_co_g in strand:
		# 			v_co_l = active_obj.matrix_world.inverted() @ s_co_g
		# 			v_index = wla_bm.bm_closestVertIdx(bm, v_co_l, modf_cache)
		# 			if v_index not in vertsIdxGuide:
		# 				vertsIdxGuide.append(v_index)
		# 			fake_vIdx = fake_vIdx+1
		# 			modf_cache[fake_vIdx] = v_co_l
		# 			guideFake.append(fake_vIdx)
		# 		guidesFake.append(guideFake)
		# 		# extending faces
		# 		print("- edgeline: extending zone", i_s+1, len(strands_pointsIni), len(vertsIdxGuide))
		# 		(_, _, vertsIdxZone, _) = wla_bm.bm_vertsPropagations_v02(bm, vertsIdxGuide, 10)
		# 		vertsIdxAll = list(set(vertsIdxAll+vertsIdxZone))
		# 	#print("- island from guides", vertsIdxAll)
		# 	vertsPerIslands = [ (vertsIdxAll, guidesFake) ]
		if vertsPerIslands is None:
			print("- guides: preparing islands", len(selvertsAll))
			vertsIdx = wla_bm.bm_sortVertsByConnection(bm, selvertsAll, True, True)
			vpi_raw = wla_bm.bm_expandVertsToIslands_v02(bm, vertsIdx, None)
			vertsPerIslands = []
			for vertsIsland in vpi_raw:
				baseverts = [vIdx for vIdx in vertsIdx if vIdx in vertsIsland]
				vertGuides = wla_bm.bm_vertsCollectGuides(bm, baseverts, guidEdges, 100)
				if vertGuides is None:
					self.report({'ERROR'}, "Can`t collect guides")
					return {'FINISHED'}
				print("- baseloop", len(baseverts), len(vertsIsland), len(vertGuides))
				vertsPerIslands.append( (vertsIsland, vertGuides) )
		print("- vertsPerIslands:", len(vertsPerIslands))
		for islDat in vertsPerIslands:
			vertsIsland = islDat[0]
			vertGuides = islDat[1]
			bm.verts.index_update()
			bm.verts.ensure_lookup_table()
			bm.edges.index_update()
			bm.edges.ensure_lookup_table()
			bm.faces.index_update()
			bm.faces.ensure_lookup_table()
			# if self.opt_guidesMeth == 'WIRE':
			# 	for vIdx in selvertsAll:
			# 		v = bm.verts[vIdx]
			# 		if v not in verts2del:
			# 			verts2del.append(v)
			# 	for guid1 in vertGuides:
			# 		for vIdx in guid1:
			# 			v = bm.verts[vIdx]
			# 			if v not in verts2del:
			# 				verts2del.append(v)
			islFacesIdx = []
			for f in bm.faces:
				for v in f.verts:
					if v.index in vertsIsland:
						islFacesIdx.append(f.index)
						#faces2del.append(f)
						break
			if len(vertGuides) < 2:
				print("- Skipping, need and least 2 guides per loop", baseverts, vertGuides)
				continue
			quadsH = self.opt_QuadsH
			if self.opt_QuadsH == 0:
				# autodetect
				for guide in vertGuides:
					if quadsH == 0:
						quadsH = len(guide)
					if quadsH != len(guide):
						print("- Skipping, guides verts count do not match", quadsH, len(guide))
						continue
			if len(vertGuides) > 2 and self.opt_closeAround:
				# adding first after last to finish circkle
				vertGuides.append(vertGuides[0])
			bm_bvh, _ = wla_bm.bm_BVHFromFaces(bm, islFacesIdx)
			# making faces
			vertCoCache = {}
			facesNew = []
			for guidIdx in range(len(vertGuides)-1):
				bm.verts.index_update()
				bm.verts.ensure_lookup_table()
				bm.edges.index_update()
				bm.edges.ensure_lookup_table()
				bm.faces.index_update()
				bm.faces.ensure_lookup_table()
				guidEdgeVerts = []
				guid1 = vertGuides[guidIdx]
				guid2 = vertGuides[guidIdx+1]
				curve1_cache = {}
				for vIdx in guid1:
					if vIdx in modf_cache:
						v_co = modf_cache[vIdx]
					else:
						v = bm.verts[vIdx]
						v_co = copy.copy(v.co)
					wla.math_lerpCurveAdd(v_co, [v_co], curve1_cache)
				curve2_cache = {}
				for vIdx in guid2:
					if vIdx in modf_cache:
						v_co = modf_cache[vIdx]
					else:
						v = bm.verts[vIdx]
						v_co = copy.copy(v.co)
					wla.math_lerpCurveAdd(v_co, [v_co], curve2_cache)
				p1_co0 = wla.math_lerpCurveGet(0, 0, curve1_cache)
				p2_co0 = wla.math_lerpCurveGet(0, 0, curve2_cache)
				verts_betweens = vertsIdx[ vertsIdx.index(guid1[0]) : vertsIdx.index(guid2[0]) ]
				verts_betweens.append(guid2[0]) # adding last vert as is
				verts_betweens_co = []
				for vIdx in verts_betweens:
					if vIdx in modf_cache:
						v_co = modf_cache[vIdx]
					else:
						v = bm.verts[vIdx]
						v_co = copy.copy(v.co)
					verts_betweens_co.append(v_co)
				for idxH in range(quadsH+1):
					if self.opt_QuadsH == 0:
						if idxH == 0:
							continue
						# direct values from cache
						p1_co = curve1_cache["val0co"][idxH-1]
						p2_co = curve2_cache["val0co"][idxH-1]
					else:
						relposH = float(idxH) / float(quadsH)
						p1_co = wla.math_lerpCurveGet(relposH, 0, curve1_cache)
						p2_co = wla.math_lerpCurveGet(relposH, 0, curve2_cache)
					guidVerts = []
					w_pts_len = float(self.opt_QuadsW)
					if self.opt_QuadsW == 0:
						w_pts_len = len(verts_betweens)-1
					for idxW in range(int(w_pts_len+1)):
						relposW = float(idxW) / w_pts_len
						pt = p1_co.lerp(p2_co, relposW)
						if self.opt_QuadsW == 0:
							# adding shift between wire-guides start points to real locations
							# so points will follow original edge-flow betwee initial points
							pt0_lin = p1_co0.lerp(p2_co0, relposW)
							pt = pt+ (verts_betweens_co[idxW] - pt0_lin)
						pt_k = wla.coToKey(pt)
						pt_v = None
						if pt_k in vertCoCache:
							pt_v = vertCoCache[pt_k]
						else:
							pt_v = bm.verts.new(pt)
							vertCoCache[pt_k] = pt_v
							if self.opt_shrinkwrapVerts:
								n_loc, _, _, _ = bm_bvh.find_nearest(pt)
								#print("- shrinkwrapping", pt, n_loc)
								if n_loc is not None:
									pt_v.co = n_loc
						guidVerts.append(pt_v)
					guidEdgeVerts.append(guidVerts)
				# real face generation
				for feIdx in range(len(guidEdgeVerts)-1):
					fe1 = guidEdgeVerts[feIdx]
					fe2 = guidEdgeVerts[feIdx+1]
					for fvIdx in range(len(fe1)-1):
						try:
							new_f = bm.faces.new([fe1[fvIdx],fe1[fvIdx+1],fe2[fvIdx+1],fe2[fvIdx]])
							facesNew.append(new_f)
							okCnt = okCnt+1
						except Exception as err:
							print("- failed to create face", err)
			facesNewIdx = []
			for f in facesNew:
				facesNewIdx.append(f.index)
			wla_bm.bm_copy_faces2faces(active_obj, bm, islFacesIdx, facesNewIdx, modf_cache)
		bm.verts.index_update()
		bm.verts.ensure_lookup_table()
		bm.edges.index_update()
		bm.edges.ensure_lookup_table()
		bm.faces.index_update()
		bm.faces.ensure_lookup_table()
		# if self.opt_deleteOriginal:
		# 	if len(faces2del) > 0:
		# 		bmesh.ops.delete(bm, geom=faces2del, context='FACES')
		# 	elif len(verts2del) > 0:
		# 		print("verts2del", verts2del)
		# 		bmesh.ops.delete(bm, geom=verts2del, context='VERTS')
		bmesh.update_edit_mesh(active_mesh)
		#if self.opt_deleteOriginal == False:
		# copying vertex groups
		print("- duplicating vertex weights")
		wla_bm.bm_copy_faces2faces(active_obj, None, None, None, modf_cache)
		wla_do.select_and_change_mode(active_obj,oldmode)
		wla_do.modf_toggle(active_obj, wla_do.kWPLModifsIndexBreakersStrict, None, modf_cache)
		self.report({'INFO'}, "Quads added: "+str(okCnt))
		return {'FINISHED'}

class wpldeform_fill_simple(bpy.types.Operator):
	bl_idname = "mesh.wpldeform_fill_simple"
	bl_label = "Refill simple"
	bl_options = {'REGISTER', 'UNDO'}

	opt_flatnMeth : EnumProperty(
		items = [
			('FILLTRIG', "Fix-n-triang", "", 1),
			('FILLPOKE', "Fix-n-poke", "", 2),
			('WFRAM', "Add Wireframe", "", 3)
		],
		name="Method",
		default='FILLTRIG',
	)

	opt_sizeScale : FloatProperty(
		name		= "Scale",
		default	 = 1.0,
	)

	def execute( self, context ):
		active_obj = wla.active_object(['MESH'])
		if active_obj is None:
			self.report({'ERROR'}, "Select mesh object first")
			return {'CANCELLED'}
		active_mesh = active_obj.data
		oldmode = wla_do.select_and_change_mode(active_obj, 'OBJECT')
		selvertsAll = wla.selected_vertsIdx(active_mesh)
		seledgsAll = wla.selected_edgesIdx(active_mesh)
		selfaceAll = wla.selected_facesIdx(active_mesh)
		wla_do.select_and_change_mode(active_obj, 'EDIT')
		if self.opt_flatnMeth in ['FILLTRIG','FILLPOKE'] and len(selfaceAll) == 0:
			print("- faces not found, getting region")
			bpy.ops.mesh.loop_to_region()
			selvertsAll = wla.selected_vertsIdx(active_mesh)
			selfaceAll = wla.selected_facesIdx(active_mesh)
			wla_do.select_and_change_mode(active_obj, 'EDIT')
		bpy.ops.mesh.region_to_loop()
		selvertsBnd = wla.selected_vertsIdx(active_mesh)
		# vertices in selection that are NOT on bound loops
		# selvertsInner = list(filter(lambda plt: plt not in selvertsBnd, selvertsAll))
		wla_do.select_and_change_mode(active_obj, 'EDIT')
		context.tool_settings.mesh_select_mode = (True, False, False) # 'VERT'
		bm = bmesh.from_edit_mesh(active_mesh)
		bm.verts.ensure_lookup_table()
		bm.edges.ensure_lookup_table()
		bm.faces.ensure_lookup_table()
		# remeber verts for reselection
		vcos = set()
		vcosBnd = set()
		for vIdx in selvertsAll:
			v = bm.verts[vIdx]
			vcos.add( wla.coToKey(v.co) )
		for vIdx in selvertsBnd:
			v = bm.verts[vIdx]
			vcosBnd.add( wla.coToKey(v.co) )
		if self.opt_flatnMeth == 'WFRAM':
			context.tool_settings.mesh_select_mode = (False, True, False) # 'EDGE'
			len_min = 999.0
			len_sum = 0.0
			len_cnt = 0.0
			len_frac = 0.2
			for e in bm.edges:
				if e.verts[0].index in selvertsBnd and e.verts[1].index in selvertsBnd:
					len_e = e.calc_length()
					len_cnt = len_cnt+1.0
					len_sum = len_sum+len_e
					if len_e < len_min:
						len_min = len_e
			if len_cnt > 0:
				newFaces = set()
				vert_curves = wla_bm.bm_splitVertsByConnection(bm, selvertsAll, True, seledgsAll, None)
				for curv_vIdx in vert_curves:
					bpy.ops.mesh.select_all(action = 'DESELECT')
					for e in bm.edges:
						if e.verts[0].index in curv_vIdx and e.verts[1].index in curv_vIdx:
							if e.verts[0].index in selvertsBnd and e.verts[1].index in selvertsBnd:
								e.select = True
					bmesh.update_edit_mesh(active_mesh)
					bpy.ops.mesh.duplicate()
					bpy.ops.mesh.edge_face_add()
					bm.faces.ensure_lookup_table()
					bm.faces.index_update()
					maxFaceIdx = 0
					for f in bm.faces:
						maxFaceIdx = max(maxFaceIdx, f.index)
					bpy.ops.mesh.wireframe(use_replace=True, use_even_offset=True, use_relative_offset=False, thickness= (len_sum/len_cnt*len_frac + (1.0-len_frac)*len_min) * self.opt_sizeScale)
					# new faces from wireframe: always added, index grow
					for f in bm.faces:
						if f.index > maxFaceIdx and f.is_valid:
							newFaces.add(f)
				wla_attr.uv_resetUV(bm, config.kWPLGridUV, [f.index for f in newFaces], (0.0,0.0))
		if self.opt_flatnMeth in ['FILLTRIG','FILLPOKE'] and len(selfaceAll) > 0:
			print("- deleting inner faces and re-adding back")
			wla_bm.bm_selectVertEdgesFaces(bm, None, vcos)
			bmesh.update_edit_mesh(active_mesh)
			bpy.ops.mesh.delete(type='ONLY_FACE')
			bm = bmesh.from_edit_mesh(active_mesh)
			bm.verts.ensure_lookup_table()
			bpy.ops.mesh.select_all(action = 'DESELECT')
			wla_bm.bm_selectVertEdgesFaces(bm, None, vcos-vcosBnd)
			#bpy.ops.mesh.delete_loose(use_verts=True, use_edges=True, use_faces=False) # Bad for separated block
			bpy.ops.mesh.delete(type='VERT')
			wla_do.select_and_change_mode(active_obj, 'EDIT')
			bm = bmesh.from_edit_mesh(active_mesh)
			bm.verts.ensure_lookup_table()
			bm.edges.ensure_lookup_table()
			bm.faces.ensure_lookup_table()
			wla_bm.bm_selectVertEdgesFaces(bm, None, vcos)
			bmesh.update_edit_mesh(active_mesh)
			bpy.ops.mesh.edge_face_add()
			bm = bmesh.from_edit_mesh(active_mesh) # again!!!
			bm.verts.ensure_lookup_table()
			bm.edges.ensure_lookup_table()
			bm.faces.ensure_lookup_table()
			bmesh.update_edit_mesh(active_mesh)
			if self.opt_flatnMeth == 'FILLPOKE':
				print("- poking")
				bpy.ops.mesh.poke(center_mode='MEDIAN_WEIGHTED')
			else:
				print("- triangulating")
				bpy.ops.mesh.quads_convert_to_tris(quad_method='BEAUTY', ngon_method='BEAUTY')
			if self.opt_sizeScale>1:
				# bpy.ops.mesh.select_all(action = 'DESELECT')
				# wla_bm.bm_selectVertEdgesFaces(bm, None, vcosBnd)
				bpy.ops.mesh.subdivide(number_cuts=int(self.opt_sizeScale))
			bpy.ops.mesh.faces_shade_smooth()
		wla_do.select_and_change_mode(active_obj, oldmode)
		return {'FINISHED'}

class wpldeform_force_xmirr(bpy.types.Operator):
	bl_idname = "mesh.wpldeform_force_xmirr"
	bl_label = "Smart XMirror"
	bl_options = {'REGISTER', 'UNDO'}

	opt_xThreshold : FloatProperty(
		name		= "Threshold",
		default	 = (1.0/config.kWPLCoordPrecision)*10.0,
	)

	def execute( self, context ):
		active_obj = wla.active_object(['MESH'])
		active_obj_nonoperable = wla.is_object_nonoperable(active_obj, None)
		if active_obj_nonoperable is not None:
			print("- problem:", active_obj_nonoperable)
			self.report({'ERROR'}, "Object not ready:" + active_obj_nonoperable)
			return {'CANCELLED'}
		active_mesh = active_obj.data
		oldmode = wla_do.select_and_change_mode(active_obj, 'OBJECT')
		#selvertsAll = wla.selected_vertsIdx(active_mesh)
		xMirrAsymmetryCo1 = {}
		xMirrAsymmetryVg1 = {}
		wla_do.select_and_change_mode(active_obj, 'EDIT')
		if wla.modf_by_type(active_obj,'MIRROR'):
			self.report({'INFO'}, 'MIRROR not allowed')
			return {"CANCELLED"}
		bpy.ops.mesh.select_all(action = 'DESELECT')
		xMirrAsymmetryCo1, _, _ = getVgWeightMapByTokALL(active_obj, config.kWPLSuppVGNoMirror)
		xMirrAsymmetryVg1, vertAsymmVgNames, vertAsymmVgMaps = getVgWeightMapByTokALL(active_obj, config.kWPLSuppVGNoMirrorVG)
		wla_do.select_and_change_mode(active_obj, 'EDIT')
		context.tool_settings.mesh_select_mode = (True, False, False) # 'VERT'
		bm = bmesh.from_edit_mesh(active_mesh)
		bm.verts.ensure_lookup_table()
		bm.edges.ensure_lookup_table()
		bm.faces.ensure_lookup_table()
		vertAsymmCo = {}
		vertAsymmVgUn = {}
		verts2del = []
		xThresh = self.opt_xThreshold
		if wla.isTokenInStr(config.kWPLObjCharBodyPostfix, active_obj.name):
			xThresh = xThresh * 0.1
			print("- Correcting threshold (to avoid legs glueling, etc)", self.opt_xThreshold, xThresh)
		for v in bm.verts:
			if (v.index in xMirrAsymmetryCo1):
				if abs(v.co[0]) <= xThresh:
					# vertex will be merged by mirror modifier -> problems!!!
					bpy.ops.mesh.select_all(action = 'DESELECT')
					v.select = True
					bmesh.update_edit_mesh(active_mesh)
					self.report({'ERROR'}, "Skipped: Asymmetry vertex in danger zone")
					return {'FINISHED'}
			# if (v.index in xMirrAsymmetryCo1):
			# 	if wla.coToKey( Vector((-1.0*v.co[0], v.co[1], v.co[2])) ) in vertAsymmCo:
			# 		bpy.ops.mesh.select_all(action = 'DESELECT')
			# 		v.select = True
			# 		bmesh.update_edit_mesh(active_mesh)
			# 		self.report({'ERROR'}, "Skipped: Asymmetry vertex has symmetrical counterpart")
			# 		return {'FINISHED'}
			if (v.index in xMirrAsymmetryCo1) and xMirrAsymmetryCo1[v.index] >= 0.1:
				coKey = wla.coToKey(v.co)
				vertAsymmCo[coKey] = v.index
				continue # should NOT be deleted
			if (v.index in xMirrAsymmetryVg1) and xMirrAsymmetryVg1[v.index] >= 0.1:
				coKey = wla.coToKey(v.co)
				for vgi, vgn in enumerate(vertAsymmVgNames):
					if v.index not in vertAsymmVgMaps[vgi]:
						continue
					coKeyVg = vgn+coKey
					if coKeyVg in vertAsymmVgUn:
						bpy.ops.mesh.select_all(action = 'DESELECT')
						v.select = True
						bmesh.update_edit_mesh(active_mesh)
						self.report({'ERROR'}, "Skipped: Asymmetry vertex same value in one point: "+coKeyVg)
						return {'FINISHED'}
					vertAsymmVgUn[coKeyVg] = vertAsymmVgMaps[vgi][v.index]
				# MUST be deleted (if needed)
			if abs(v.co[0]) <= xThresh:
				v.co = Vector((0, v.co[1], v.co[2]))
			elif v.co[0] > 0.0:
				verts2del.append(v)
		if len(verts2del) > 0:
			bmesh.ops.delete(bm, geom=verts2del, context='VERTS')
		bmesh.update_edit_mesh(active_mesh)
		bm.verts.index_update()
		bm.verts.ensure_lookup_table()
		vertsMaxIndex = 0 # AFTER deleting verts - max index less that initial
		for v in bm.verts:
			vertsMaxIndex = max(vertsMaxIndex, v.index)
		wla_do.select_and_change_mode(active_obj, 'OBJECT')
		#return {'FINISHED'} # DBG
		mirrorModifier = active_obj.modifiers.new("TmpMirror", 'MIRROR')
		wla_do.modf_sendBackByType(active_obj, 'MIRROR', False)
		bpy.ops.object.modifier_apply(modifier = mirrorModifier.name)
		if len(vertAsymmCo) > 0:
			print("- Smart XMirror: restoring no-mirrorable vertexes")
			# deleting wrongly duplicated verts
			wla_do.select_and_change_mode(active_obj, 'EDIT')
			xMirrAsymmetryCo2, _ = wla_attr.vg_get_weightMapByTok(active_obj, config.kWPLSuppVGNoMirror)
			bm = bmesh.from_edit_mesh(active_mesh)
			bm.verts.index_update()
			bm.verts.ensure_lookup_table()
			bm.edges.ensure_lookup_table()
			bm.faces.ensure_lookup_table()
			verts2del = []
			for v in bm.verts:
				if (v.index in xMirrAsymmetryCo2) and xMirrAsymmetryCo2[v.index] >= 0.1:
					cok = wla.coToKey(v.co)
					# assuming mirror only ADD verts (index > original)
					if (cok not in vertAsymmCo) or (v.index > vertsMaxIndex):
						verts2del.append(v)
			bmesh.ops.delete(bm, geom=verts2del, context='VERTS')
			bmesh.update_edit_mesh(active_mesh)
			wla_do.select_and_change_mode(active_obj, 'OBJECT')
		if len(vertAsymmVgUn) > 0:
			# removing symmetrical vertex from specific VGs
			_, vertAsymmVgNames, _ = getVgWeightMapByTokALL(active_obj, config.kWPLSuppVGNoMirrorVG)
			print("- Smart XMirror: restoring no-mirrorable VGs", vertAsymmVgNames)
			#vg2clean = wla.strExtractOuterBrackets(vertAsymmVgName)
			for v in active_obj.data.vertices:
				for vgi, vgn in enumerate(vertAsymmVgNames):
					vg_id = active_obj.vertex_groups[vgn]
					coKey = wla.coToKey(v.co)
					coKeyVg = vgn+coKey
					if coKeyVg not in vertAsymmVgUn:
						# vertex, created by symmetry
						# must remove vert from VGs - AND from vertAsymmVgName - it should be the same for rerunnability
						vg_id.remove([v.index])
					else:
						# original vertex weight
						w = vertAsymmVgUn[coKeyVg]
						try:
							vg_id.add([v.index], w, 'REPLACE')
						except Exception as e:
							vg_id.add([v.index], w, 'ADD')
		wla_do.select_and_change_mode(active_obj, oldmode)
		self.report({'INFO'}, "Symmetry restored")
		return {'FINISHED'}

class wpldeform_2curve(bpy.types.Operator):
	bl_idname = "object.wpldeform_2curve"
	bl_label = "Add detail Curve"
	bl_options = {'REGISTER', 'UNDO'}
	opt_sourceMeth : EnumProperty(
		items = [
			('VHIST', "Vert history", "", 1),
			('SELC', "Selection", "", 2)
		],
		name="Source",
		default='SELC',
	)
	opt_targetTune : EnumProperty(
		items = [
			('DETAIL_TUBE', "Detail object (Tube)", "", 1),
			('DETAIL_STRIPE', "Detail object (Stripe)", "", 2),
			('DETAIL_SEW', "Detail object (Sew)", "", 3),
			('GN_CURVE', "Pure Curve (for GN)", "", 4),
			# ??? not using. GN deformed is easier/better
			('CURVE_DEFORM', "Curve deform object", "", 5)
		],
		name="Source",
		default='GN_CURVE',
	)
	opt_deflRadius : FloatProperty(
		name = "Points Radius",
		default	 = 0.01,
	)
	opt_subdLenRel : FloatProperty(
		name	= "Subdiv target (Edge-relative)",
		subtype	= 'PERCENTAGE',
		default	= 200,
		min		= 0.0,
		max		= 1000.0
	)
	opt_shrw2src : BoolProperty(
		name 	= "Shrinkwrap",
		default	= True
	)
	opt_noShadow : BoolProperty(
		name 	= "Wireframe && No Shadow",
		default	= True
	)
	opt_reusePrevs : BoolProperty(
		name 	= "Reuse Previous",
		default	= False
	)
	def execute( self, context ):
		active_obj = wla.active_object(['MESH'])
		active_obj_nonoperable = wla.is_object_nonoperable(active_obj, ["obj_multi_user"])
		if active_obj_nonoperable is not None:
			print("- problem:", active_obj_nonoperable)
			self.report({'ERROR'}, "Object not ready:" + active_obj_nonoperable)
			return {'CANCELLED'}
		bm_defrco, _ = wla_bm.bm_getDeformedCos(active_obj)
		oldmode = wla_do.select_and_change_mode(active_obj,'EDIT')
		active_mesh = active_obj.data
		vertsIdx = []
		bm = None
		bm = bmesh.from_edit_mesh( active_mesh )
		if self.opt_sourceMeth == 'VHIST':
			vertsIdx = wla_bm.bm_historyVertsIdx(bm)
		else:
			vertsIdx = [v.index for v in bm.verts if v.select]
			# sorting according to nearness
			vertsIdx = wla_bm.bm_sortVertsByConnection(bm, vertsIdx, True, True)
		#except:
		#	pass
		if len(vertsIdx) <= 1:
			self.report({'ERROR'}, "No history verts found, select something first")
			return {'FINISHED'}
		edgesMaxLen = 0.0
		vertsCo = []
		for i,v_idx in enumerate(vertsIdx):
			v = bm.verts[v_idx]
			vco = bm_defrco[v_idx]
			vertsCo.append(vco)
			for e in v.link_edges:
				edgesMaxLen = max(edgesMaxLen,e.calc_length())
		sel_obj_name = active_obj.name
		edgeObjName = sel_obj_name + config.kWPLObjProtoToken[0]
		edgeDataName = sel_obj_name + "_curve"
		if self.opt_targetTune == 'CURVE_DEFORM':
			edgeObjName = sel_obj_name + config.kWPLObjDefrmPostfix
			edgeDataName = sel_obj_name + "_curvedfr_manual"
		if self.opt_targetTune == 'DETAIL_SEW':
			edgeObjName = sel_obj_name + config.kWPLObjManSewPostfix
			edgeDataName = sel_obj_name + "_curvesews_manual"
		edgeObj = None
		curveData = None
		curveBaseRadius = 1.0
		if self.opt_targetTune == 'DETAIL_STRIPE':
			curveBaseRadius = self.opt_deflRadius
		if self.opt_targetTune == 'DETAIL_TUBE' and edgesMaxLen>0.0:
			curveBaseRadius = edgesMaxLen * (self.opt_deflRadius*10*3) # 0.3 by default
		else:
			curveBaseRadius = self.opt_deflRadius
		if self.opt_reusePrevs and (self.opt_targetTune != 'CURVE_DEFORM'):
			curveData = bpy.data.curves.get(edgeDataName)
			print("- looking for existing curve data", edgeDataName, curveData)
		else:
			curveData = None
		if curveData is None:
			#needUpdateBevelDepth = True
			curveData = bpy.data.curves.new(name = edgeDataName, type='CURVE')
			curveData.dimensions = '3D'
			curveData.offset = 0.0
			curveData.render_resolution_u = 50 # need for stripe-compatible triangles
			curveData.resolution_u = 10
			if self.opt_targetTune == 'DETAIL_STRIPE':
				curveData.bevel_mode = 'PROFILE'
				curveData.extrude = 1.0
				curveData.bevel_depth = 0.0
				curveData.bevel_resolution = 0
			if self.opt_targetTune in ['DETAIL_TUBE', 'DETAIL_SEW']: 
				curveData.fill_mode = 'FULL'
				curveData.bevel_depth = 1.0
				curveData.bevel_resolution = 2
			curveData.use_fill_caps = False
			print("- creating curve data", curveData.name)
		polyline = curveData.splines.new('NURBS')
		curveLength = float(len(vertsIdx))
		subdlen = edgesMaxLen*(self.opt_subdLenRel*0.01)
		if subdlen > 0.0:
			vertsCo = wla.math_vecsSubd(vertsCo, subdlen)
			# needContinue = True
			# while needContinue:
			# 	needContinue = False
			# 	for i,v_co_l in enumerate(vertsCo):
			# 		if i>0 and (v_co_l-vertsCo[i-1]).length > subdlen:
			# 			v_co_l2 = (v_co_l+vertsCo[i-1])*0.5
			# 			vertsCo.insert(i,v_co_l2)
			# 			needContinue = True
			# 			break
		for i,v_co_l in enumerate(vertsCo):
			if len(polyline.points) <= i:
				polyline.points.add(1)
			polyline.points[i].co = (v_co_l[0], v_co_l[1], v_co_l[2], 1)
			polyline.points[i].radius = curveBaseRadius
		if self.opt_targetTune != 'CURVE_DEFORM':
			polyline.order_u = 2
			polyline.use_endpoint_u = True
			# wla_curve.cu_rescale_radius(polyline.points, self.opt_deflRadius, 0.5, curveBaseRadius)
			edgeObj = wla.object_by_name(edgeObjName)
			if edgeObj is not None and edgeObj.data.name != curveData.name:
				edgeObj = None
		else:
			polyline.order_u = 4
			polyline.use_endpoint_u = True
		if edgeObj is None:
			edgeObj = bpy.data.objects.new(edgeObjName, object_data=curveData)
			wla_do.link_object_sideBySide(edgeObj, active_obj)
			wla_do.link_with_vgsbind(active_obj, edgeObj)
		wla_do.attach_objToSourceObject(edgeObj, active_obj, False, self.opt_shrw2src, 0)
		if self.opt_noShadow:
			wla_do.set_object_noShadow(edgeObj, True, False)
		if self.opt_targetTune == 'CURVE_DEFORM':
			wla_do.select_and_change_mode(edgeObj,'OBJECT')
			# adding empty cube
			# MUST BE in same hierarchy and at the same origin as curve
			curveData.bevel_depth = 0.0
			bpy.ops.mesh.primitive_cube_add(size = edgesMaxLen*0.3)
			defl_cube = bpy.context.active_object
			wla_do.link_object_sideBySide(defl_cube, active_obj)
			defl_cube.name = edgeObjName
			defl_cube.data.name = edgeDataName
			array_modf = defl_cube.modifiers.new(name = 'curve_len', type = 'ARRAY')
			#array_modf.count = 3
			array_modf.fit_type = 'FIT_CURVE'
			array_modf.curve = edgeObj
			array_modf.show_in_editmode = True
			array_modf.show_on_cage = True
			curve_modf = defl_cube.modifiers.new(name = 'curve_defm', type = 'CURVE')
			curve_modf.object = edgeObj
			curve_modf.show_in_editmode = True
			curve_modf.show_on_cage = True
			if len(active_obj.material_slots) > 0:
				wla_attr.mat_obj_ensuremat(defl_cube, active_obj.material_slots[0].name, False)
			copyRotCon = edgeObj.constraints.new('COPY_TRANSFORMS')
			copyRotCon.target = active_obj
			copyRotCon = defl_cube.constraints.new('COPY_TRANSFORMS')
			copyRotCon.target = edgeObj #active_obj
		wla_do.select_and_change_mode(active_obj,oldmode)
		self.report({'INFO'}, "Added "+str(curveLength)+" points")
		return {'FINISHED'}

# class wpldeform_extrskin(bpy.types.Operator):
# 	bl_idname = "object.wpldeform_extrskin"
# 	bl_label = "Skintube from selection"
# 	bl_options = {'REGISTER', 'UNDO'}

# 	opt_skinSize : FloatProperty(
# 		name		= "Skinning size",
# 		default	 = 0.015,
# 		min		 = 0.001,
# 		max		 = 1.0
# 		)
# 	opt_postShrwSize : FloatProperty(
# 		name		= "Post-shrinkwrap distance",
# 		default	 = 0.003,
# 		min		 = 0.0,
# 		max		 = 1.0
# 		)

# 	def execute( self, context ):
# 		active_obj = wla.active_object(['MESH'])
# 		if active_obj is None:
# 			self.report({'ERROR'}, "Select mesh object first")
# 			return {'CANCELLED'}
# 		if wla.is_local_view():
# 			self.report({'ERROR'}, "Can`t work in Local view")
# 			return {'CANCELLED'}
# 		active_mesh = active_obj.data
# 		edgesIdx = wla.selected_edgesIdx(active_mesh)
# 		if len(edgesIdx) == 0:
# 			self.report({'ERROR'}, "No selected edges found")
# 			return {'FINISHED'}
		
# 		objsBefore = [obj for obj in bpy.data.objects]
# 		wla_do.select_and_change_mode(active_obj, 'EDIT')
# 		context.tool_settings.mesh_select_mode = (False, True, False) # 'EDGE'
# 		bpy.ops.mesh.separate(type='SELECTED')
# 		objsAfter = [obj for obj in bpy.data.objects]
# 		if len(objsAfter) == len(objsBefore):
# 			self.report({'ERROR'}, "Nothing extracted, ignoring")
# 			return {'CANCELLED'}
# 		edgeObj = None
# 		for obj in objsAfter:
# 			if obj not in objsBefore:
# 				edgeObj = obj
# 				break
# 		if edgeObj is None:
# 			self.report({'ERROR'}, "Extraction not found, ignoring")
# 			return {'CANCELLED'}
# 		edgeObj.select_set(False)
# 		edgeObj.name = active_obj.name + config.kWPLObjVgsSkinPostfix
# 		wla_do.attach_objToSourceObject(edgeObj, active_obj, True, True, 0)
# 		skin_modf = edgeObj.modifiers.new(name = 'edge_skin', type = 'SKIN')
# 		wla_do.select_and_change_mode(active_obj, 'OBJECT')
# 		isRootSet = False
# 		vSkinData = edgeObj.data.skin_vertices[0].data
# 		for vIdx,vS in enumerate(vSkinData):
# 			vS.radius = (self.opt_skinSize, self.opt_skinSize)
# 			vS.use_loose = False
# 			#v = edgeObj.vertices(vIdx)
# 			if isRootSet == False:
# 				isRootSet = True
# 				vS.use_root = True
# 		edgeObj.modifiers.new(name = "Subsurf", type = 'SUBSURF')
# 		if self.opt_postShrwSize > 0:
# 			shrinkwrap_modifier2 = edgeObj.modifiers.new(name = "WPL_Edge2src2", type = 'SHRINKWRAP')
# 			shrinkwrap_modifier2.offset = self.opt_postShrwSize
# 			shrinkwrap_modifier2.target = active_obj
# 			shrinkwrap_modifier2.use_apply_on_spline = False
# 			shrinkwrap_modifier2.wrap_method = 'NEAREST_SURFACEPOINT'
# 			shrinkwrap_modifier2.wrap_mode = 'ABOVE_SURFACE'
# 		self.report({'INFO'}, "Skinned detail extracted")
# 		return {'FINISHED'}

class wpldeform_smart_convx(bpy.types.Operator):
	bl_idname = "mesh.wpldeform_smart_convx"
	bl_label = "Patch with convex"
	bl_options = {'REGISTER', 'UNDO'}

	opt_remeshDensity : IntProperty(
		name="Remesh density",
		min=-5000, max=5000,
		default=2000
	)
	# opt_recastInfluence : FloatProperty(
	# 	name="Wrap: Influence",
	# 	default=0.0
	# )
	# opt_EvalRecastFeats : StringProperty(
	# 	name = "Wrap: CastFuzz/CastQual/MaxShift/PrePush",
	# 	default	 = "(0.1, 5, 0.3, 0.2)"
	# )

	def execute(self, context):
		active_obj = wla.active_object(['MESH'])
		if active_obj is None:
			self.report({'ERROR'}, "Select mesh object first")
			return {'CANCELLED'}
		needBack2LV = False
		if wla.is_local_view():
			#self.report({'ERROR'}, "Can`t work in Local view")
			#return {'CANCELLED'}
			bpy.ops.view3d.localview()
			needBack2LV = True
		active_mesh = active_obj.data
		oldmode = wla_do.select_and_change_mode(active_obj, 'EDIT' )
		# isPatchMode = False
		# if self.opt_EvalRecastFeats == "<patch>":
		# 	isPatchMode = True
		bm1 = bmesh.from_edit_mesh(active_mesh)
		hullc_co_g = Vector((0,0,0))
		selvertsCo = []
		selvertsIdx = []
		selfacesAll = []
		selfacesIni = []
		for bm1_v in bm1.verts:
			if bm1_v.select:
				v_co_g = active_obj.matrix_world @ bm1_v.co
				selvertsCo.append(v_co_g)
				selvertsIdx.append(bm1_v.index)
				hullc_co_g = hullc_co_g+v_co_g
		for bm1_f in bm1.faces:
			if bm1_f.select:
				# independent, for patch
				selfacesIni.append(bm1_f.index)
			if bm1_f.index in selfacesAll:
				continue
			if bm1_f.select:
				selfacesAll.append(bm1_f.index)
				continue
			for fv in bm1_f.verts:
				if fv.select:
					selfacesAll.append(bm1_f.index)
					break
		if len(selvertsCo) == 0:
			self.report({'ERROR'}, "Nothing selected")
			return {'CANCELLED'}
		hullc_co_g = hullc_co_g/len(selvertsCo)
		max_rad = 0
		for co_g in selvertsCo:
			v_rad = (co_g - hullc_co_g).length
			if v_rad > max_rad:
				max_rad = v_rad
		#bvh_orig = wla_bm.bm_BVHFromFacesIdx(active_obj, bm1, selfacesAll, True)
		bpy.ops.mesh.select_all( action = 'DESELECT' ) # important, new mesh will be selected only
		tmp_targetConvName = "zzz_convex"
		wla_do.select_and_change_mode(active_obj, 'OBJECT' )
		hullObj = wla.object_by_name(tmp_targetConvName)
		if hullObj is not None:
			bpy.data.objects.remove(hullObj, do_unlink=True)
			hullObj = None
		if hullObj is None:
			bm2m = bpy.data.meshes.new(name = tmp_targetConvName + "_mesh")
			bm2_obj = bpy.data.objects.new(name = tmp_targetConvName, object_data=bm2m)
			wla_do.link_object_sideBySide(bm2_obj, active_obj)
		hullObj = wla.object_by_name(tmp_targetConvName)
		kFCStoreTmpKey = "faceCopyPasteTmp"
		if True:
			wla_do.select_and_change_mode(hullObj, 'EDIT' )
			bm2 = bmesh.from_edit_mesh(hullObj.data)
			hullv = []
			for co_g in selvertsCo:
				co_l = hullObj.matrix_world.inverted() @ co_g
				bm2v = bm2.verts.new(co_l)
				hullv.append(bm2v)
			bm2.verts.ensure_lookup_table()
			bm2.verts.index_update()
			result = bmesh.ops.convex_hull(bm2, input=hullv)
			if "geom_unused" in result and len(result["geom_unused"])>0:
				for v in result["geom_unused"]:
					bm2.verts.remove(v)
		wla_do.select_and_change_mode(hullObj, 'OBJECT' )
		bpy.ops.object.origin_set(type='ORIGIN_GEOMETRY', center='MEDIAN')
		if self.opt_remeshDensity < 0:
			# remeshing... sometimes fails
			wla_do.sys_update_mesh(hullObj)
			wla_do.select_and_change_mode(hullObj, 'OBJECT' )
			faceCnt = min(max(100, int(max_rad*max_rad*max_rad*abs(self.opt_remeshDensity))), 3000)
			res = bpy.ops.object.quadriflow_remesh(use_preserve_sharp=True, use_preserve_boundary=True, preserve_paint_mask=False, smooth_normals=True, mode='FACES', target_ratio=1.0, target_edge_length=0.1, target_faces=faceCnt, mesh_area=-1, seed=0)
			print("- quadriflow_remesh: faces", faceCnt, res)
		if self.opt_remeshDensity > 0:
			wla_do.sys_update_mesh(hullObj)
			wla_do.select_and_change_mode(hullObj, 'OBJECT' )
			print("- voxel_remesh", self.opt_remeshDensity)
			remmodf = hullObj.modifiers.new(name = "tmp_r", type = 'REMESH')
			remmodf.octree_depth = 6
			remmodf.mode = "SHARP"
			remmodf.scale = 0.2
			remmodf.use_remove_disconnected = False
			remmodf.use_smooth_shade = True
			remmodf.sharpness = 1
			remmodf.voxel_size = 0.03
			#return {'FINISHED'}
			bpy.ops.object.modifier_apply(modifier="tmp_r")
		# transferring data - problematic, no way to limit source vertices
		# wla_do.transfer_data(active_obj, hullObj, True, True)
		# reprojecting backward
		# wla_do.select_and_change_mode(hullObj, 'EDIT' )
		# bpy.ops.mesh.select_all( action = 'SELECT' )
		# if self.opt_remeshDensity > 0:
		# 	# subdiv
		# 	print("-subdividing", abs(self.opt_remeshDensity))
		# 	bpy.ops.mesh.subdivide(number_cuts=abs(self.opt_remeshDensity))
		# if bvh_orig is not None and self.opt_recastInfluence > 0.0: #  and isPatchMode == False
		# 	hull_mw_nrm_g = hullObj.matrix_world.inverted().transposed().to_3x3()
		# 	bm_hull = bmesh.from_edit_mesh(hullObj.data)
		# 	bm_hull.verts.ensure_lookup_table()
		# 	bm_hull.verts.index_update()
		# 	bm_hull.faces.ensure_lookup_table()
		# 	bm_hull.faces.index_update()
		# 	opt_dopFeats = (0.1, 5, 0.3, 0.2)
		# 	try:
		# 		recastFeats_py = compile(self.opt_EvalRecastFeats, "<string>", "eval")
		# 		opt_dopFeats = eval(recastFeats_py)
		# 	except Exception as e:
		# 		print("- eval error", self.opt_EvalRecastFeats, e)
		# 		self.report({'ERROR'}, "Eval compilation: syntax error")
		# 		return {'CANCELLED'}
		# 	for v in bm_hull.verts:
		# 		maxShift = (opt_dopFeats[2]*max_rad) # can be adjusted per vertex
		# 		prePush = (opt_dopFeats[3]*max_rad)
		# 		v_co_g = hullObj.matrix_world @ v.co
		# 		if opt_dopFeats[0] >= 0.0:
		# 			proj_dir = -1 * (hull_mw_nrm_g @ v.normal)
		# 		else:
		# 			proj_dir = (hullc_co_g - v_co_g).normalized()
		# 		# print("- proj_dir", proj_dir)
		# 		v_co_g = v_co_g-proj_dir*prePush
		# 		n_loc_g, _ = wla_bm.bm_fuzzyBVHRayCast_v01(bvh_orig, v_co_g, proj_dir, abs(opt_dopFeats[0]), int(opt_dopFeats[1]), 'AVG')
		# 		if n_loc_g is not None:
		# 			v_co_new = hullObj.matrix_world.inverted() @ n_loc_g
		# 			# protecting from moving under surface (as with direct cast)
		# 			n_locSnip_g, _ = wla_bm.bm_fuzzyBVHRayCast_v01(bvh_orig, v_co_g, proj_dir, 0, 0, 'AVG')
		# 			if n_locSnip_g is not None:
		# 				maxShift = min(maxShift, ((hullObj.matrix_world.inverted() @ n_locSnip_g) - v.co).length)
		# 			if (v_co_new-v.co).length > maxShift:
		# 				maxshift_dir = (v_co_new-v.co).normalized() * maxShift
		# 				v_co_new = v.co + maxshift_dir
		# 			v.co = v.co.lerp(v_co_new, self.opt_recastInfluence)
		# 	bmesh.update_edit_mesh(hullObj.data)
		wla_do.select_and_change_mode(hullObj, 'OBJECT' )
		# joining back 
		# !!! not by Join !!! Kills material indexes for same material
		# https://developer.blender.org/T85578
		# bpy.ops.object.select_all(action='DESELECT')
		# active_obj.select_set(True)
		# hullObj.select_set(True)
		# wla_do.set_active_object(active_obj)
		# bpy.ops.object.join()
		allverts =  [e.index for e in hullObj.data.vertices]
		wla_bm.bm_copyFaces(hullObj, kFCStoreTmpKey, allverts, None, None)
		selfacesNew = wla_bm.bm_pasteFaces(active_obj, kFCStoreTmpKey)
		if selfacesNew is None:
			self.report({'ERROR'}, "Failed to paste FACES")
			return {'CANCELLED'}
		# updating material indexes, etc
		transferCache = {}
		wla_do.select_and_change_mode(active_obj, 'EDIT' )
		#bpy.ops.mesh.delete_loose() # kills selection
		bm = bmesh.from_edit_mesh(active_obj.data)
		wla_bm.bm_copy_faces2faces(active_obj, bm, selfacesAll, selfacesNew, transferCache)
		bmesh.update_edit_mesh(active_mesh)
		wla_bm.bm_copy_faces2faces(active_obj, None, None, None, transferCache)
		bm = bmesh.from_edit_mesh(active_obj.data) # again
		wla_attr.uv_resetUV(bm, config.kWPLGridUV, selfacesNew, (0.0,0.0))

		# fixing normals
		# wla_do.select_and_change_mode(active_obj,'EDIT')
		# bpy.ops.mesh.select_all(action='SELECT')
		bpy.ops.mesh.faces_shade_smooth()
		# bpy.ops.mesh.select_all(action='DESELECT')
		if active_obj.data.use_auto_smooth == False:
			wla_do.select_and_change_mode(active_obj,'OBJECT')
			bpy.ops.mesh.customdata_custom_splitnormals_clear()
			active_obj.data.use_auto_smooth = True
			active_obj.data.auto_smooth_angle = math.radians(30)

		# finishing
		wla_do.select_and_change_mode(active_obj, oldmode )
		if needBack2LV == True:
			bpy.ops.view3d.localview(frame_selected=False)
		bpy.data.objects.remove(hullObj, do_unlink=True)
		self.report({'INFO'}, "Done")
		return {'FINISHED'}

class wpldeform_bindmodf(bpy.types.Operator):
	bl_idname = "mesh.wpldeform_bindmodf"
	bl_label = "Multi-bind mesh/lat deform"
	bl_options = {'REGISTER', 'UNDO'}

	opt_makeWireInvis : BoolProperty(
		name="Surf: Wireframe & No-Render",
		default=True,
	)

	def execute(self, context):
		active_obj = wla.object_by_name(config.kWPLSystemMainCam)
		sel_all = []
		for sel_obj in bpy.context.selected_objects:
			# multi-user ok - not ok for APPLY only
			# non-default scale ok - face emotions on scaled head
			sel_obj_nonoperable = wla.is_object_nonoperable(sel_obj, ["obj_multi_user", "obj_scale_not_applied"])
			if sel_obj_nonoperable is not None:
				print("- problem:", sel_obj_nonoperable)
				self.report({'ERROR'}, "Object not ready:" + sel_obj_nonoperable)
				return {'CANCELLED'}
			if wla.modf_by_type(sel_obj,'MIRROR') is not None:
				# mesh with mirror -> modifier will not be appliable!!!
				# assymetry will be lost
				print("- MIRROR found:", sel_obj)
				self.report({'ERROR'}, 'Object has Mirror modifier')
				return {"CANCELLED"}
			if sel_obj.type == 'EMPTY':
				childs = wla.all_childs_recursive(sel_obj)
				for ch_obj in childs:
					if ch_obj.name not in sel_all:
						sel_all.append(ch_obj.name)
				continue
			sel_all.append(sel_obj.name)
		wla_do.select_and_change_mode(active_obj,"OBJECT")
		if len(sel_all) == 0:
			self.report({'ERROR'}, "No objects selected")
			return {'CANCELLED'}
		deformToolsOpts = context.scene.wpl_deformOpts
		cage_object = wla.object_by_name(deformToolsOpts.bind_targ)
		if cage_object is None:
			self.report({'ERROR'}, "No proper cage found, choose mesh/lattice object first")
			return {'CANCELLED'}
		for md in cage_object.modifiers:
			self.report({'ERROR'}, "Cage has modifier: "+md.type)
			return {'CANCELLED'}
		if self.opt_makeWireInvis:
			wla_do.set_object_noShadow(cage_object, True, True)
		modname = config.kWPLMeshDeformMod
		ok = 0
		error = 0
		maxSize = 0
		if cage_object.type == 'EMPTY':
			wla_do.select_and_change_mode(cage_object,"OBJECT")
			maxSize = 2.0*max(max(cage_object.scale[0], cage_object.scale[1]), cage_object.scale[2])
			bpy.ops.view3d.snap_cursor_to_active()
		for i, sel_obj_name in enumerate(sel_all):
			if sel_obj_name == cage_object.name:
				continue
			sel_obj = wla.object_by_name(sel_obj_name)
			if sel_obj.type == 'EMPTY' or sel_obj.type == 'ARMATURE' or sel_obj.data is None:
				continue
			print("Handling object "+str(i+1)+" of "+str(len(sel_all)), sel_obj.name)
			prevModifier = sel_obj.modifiers.get(modname)
			wla_do.select_and_change_mode(sel_obj,"OBJECT")
			if sel_obj.type == 'MESH' or sel_obj.type == 'CURVE':
				if cage_object.type == 'LATTICE':
					if prevModifier is not None:
						sel_obj.modifiers.remove(prevModifier)
					meshdef_modifier = sel_obj.modifiers.new(name = modname, type = 'LATTICE')
					meshdef_modifier.object = cage_object
					meshdef_modifier.show_in_editmode = True
					meshdef_modifier.show_on_cage = True
					if sel_obj.type == 'CURVE':
						meshdef_modifier.use_apply_on_spline = True
					if wla_attr.vg_get_by_name(sel_obj, config.kWPLObjDefrmPostfix) is not None:
						meshdef_modifier.vertex_group = config.kWPLObjDefrmPostfix
					wla_do.modf_sendBackByName(sel_obj, meshdef_modifier.name, False)
					# wla_do.modf_sendBackByType(sel_obj, 'EDGE_SPLIT')
					# wla_do.modf_sendBackByType(sel_obj, 'SHRINKWRAP')
					# wla_do.modf_sendBackByType(sel_obj, 'SUBSURF')
					# wla_do.modf_sendBackByType(sel_obj, 'NODES') # Geometry Nodes
					ok = ok+1
				if cage_object.type == 'MESH':
					if prevModifier is not None:
						sel_obj.modifiers.remove(prevModifier)
					meshdef_modifier = sel_obj.modifiers.new(name = modname, type = 'SURFACE_DEFORM')
					meshdef_modifier.target = cage_object
					meshdef_modifier.falloff = 5
					if wla_attr.vg_get_by_name(sel_obj, config.kWPLObjDefrmPostfix) is not None:
						meshdef_modifier.vertex_group = config.kWPLObjDefrmPostfix
					meshdef_modifier.show_in_editmode = True
					meshdef_modifier.show_on_cage = True
					if sel_obj.type == 'CURVE':
						meshdef_modifier.use_apply_on_spline = True
					wla_do.modf_sendBackByName(sel_obj, meshdef_modifier.name, False)
					# wla_do.modf_sendBackByType(sel_obj, 'EDGE_SPLIT')
					# wla_do.modf_sendBackByType(sel_obj, 'SOLIDIFY')
					# wla_do.modf_sendBackByType(sel_obj, 'SUBSURF') #before binding!
					# wla_do.modf_sendBackByType(sel_obj, 'NODES') # Geometry Nodes
					bpy.ops.object.surfacedeform_bind(modifier = meshdef_modifier.name)
					ok = ok+1
				if cage_object.type == 'EMPTY':
					hookdef_modifier = sel_obj.modifiers.new(name = modname, type = 'HOOK')
					modname = hookdef_modifier.name #can be many
					hookdef_modifier.object = cage_object
					hookdef_modifier.falloff_radius = maxSize
					hookdef_modifier.falloff_type = 'SMOOTH'
					#hookdef_modifier.use_falloff_uniform = True
					hookdef_modifier.show_in_editmode = True
					hookdef_modifier.show_on_cage = True
					if sel_obj.type == 'CURVE':
						hookdef_modifier.use_apply_on_spline = True
					wla_do.modf_sendBackByName(sel_obj, meshdef_modifier.name, False)
					# wla_do.modf_sendBackByType(sel_obj, 'EDGE_SPLIT')
					# wla_do.modf_sendBackByType(sel_obj, 'SOLIDIFY')
					# wla_do.modf_sendBackByType(sel_obj, 'SUBSURF') #before binding!
					# wla_do.modf_sendBackByType(sel_obj, 'NODES') # Geometry Nodes
					wla_do.select_and_change_mode(sel_obj,"EDIT")
					if sel_obj.type == 'CURVE':
						bpy.ops.curve.select_all(action='SELECT')
					else:
						bpy.ops.mesh.select_all(action='SELECT')
					bpy.ops.object.hook_assign(modifier = meshdef_modifier.name)
					bpy.ops.object.hook_reset(modifier = meshdef_modifier.name)
					bpy.ops.object.hook_recenter(modifier = meshdef_modifier.name)
					if sel_obj.type == 'CURVE':
						bpy.ops.curve.select_all(action='DESELECT')
					else:
						bpy.ops.mesh.select_all(action='DESELECT')
					wla_do.select_and_change_mode(sel_obj,"OBJECT")
					ok = ok+1
		self.report({'INFO'}, "Done: count="+str(ok)+"/"+str(len(sel_all)))
		wla_do.select_and_change_mode(cage_object,"OBJECT")
		return {'FINISHED'}

class wpldeform_objlattice(bpy.types.Operator):
	bl_idname = "object.wpldeform_objlattice"
	bl_label = "Add Deformer for object"
	bl_options = {'REGISTER', 'UNDO'}

	opt_mode : EnumProperty(
		name="Type", default="LATT",
		items=(("LATT", "Lattice", ""), ("GRID", "Grid", ""))
	)
	opt_orientation : EnumProperty(
		name="Orientation", default="OBJECT",
		items=(("OBJECT", "Object", ""), ("CAMERA", "Look2Cam", ""))
	)

	def execute(self, context):
		active_obj = wla.active_object()
		if self.opt_mode != 'LATT':
			active_obj_nonoperable = wla.is_object_nonoperable(active_obj, ["obj_multi_user"])
			if active_obj_nonoperable is not None:
				print("- problem:", active_obj_nonoperable)
				self.report({'ERROR'}, "Object not ready:" + active_obj_nonoperable)
				return {'CANCELLED'}
		if wla.is_pose_mode():
			self.report({'ERROR'}, "Make empty wrapper instead")
			return {'CANCELLED'}
		prevmode = wla_do.select_and_change_mode(active_obj,"OBJECT")
		v_maxsize_g = None
		v_center_g = None
		selFacesVC = None
		selFacesMat = None
		deformer_name = active_obj.name + config.kWPLObjDefrmPostfix
		if self.opt_mode == 'LATT':
			deformer_name = config.kWPLSuppZZZZPrefix + active_obj.name + config.kWPLObjDefrmPostfix
		if self.opt_mode == 'GRID':
			deformer_name = active_obj.name + config.kWPLObjProtoToken[0]
			if active_obj.type == 'ARMATURE' and active_obj.parent is not None:
				deformer_name = active_obj.parent.name + config.kWPLObjProtoToken[0]
		if 'EDIT' in prevmode and active_obj.type == 'MESH':
			selvertsAll = wla.selected_vertsIdx(active_obj.data)
			if len(selvertsAll) > 0:
				# mask_group MAY be is used on bind -> Now in armadef specials
				# mask_group = wla_attr.vg_add_verts2vg(active_obj, config.kWPLObjDefrmPostfix, selvertsAll, 1.0)
				srcFaces = []
				v_center_g = Vector((0,0,0))
				for vIdx in selvertsAll:
					v = active_obj.data.vertices[vIdx]
					v_co_g = active_obj.matrix_world @ v.co
					v_center_g = v_center_g + v_co_g
				v_center_g = v_center_g/len(selvertsAll)
				v_maxsize_g = 0
				for vIdx in selvertsAll:
					v = active_obj.data.vertices[vIdx]
					v_co_g = active_obj.matrix_world @ v.co
					v_maxsize_g = max(v_maxsize_g, (v_co_g-v_center_g).length )
				for f in active_obj.data.polygons:
						for idx in f.vertices:
							if (idx in selvertsAll) and (f.index not in srcFaces):
								srcFaces.append(f.index)
				selFacesVC, selFacesMat = wla_attr.vc_obj_avgcolor(active_obj, config.kWPLMeshColVC, srcFaces)
				print("- Selection found:", v_center_g, v_maxsize_g, selFacesVC, selFacesMat)
		deformer_object = None
		if v_maxsize_g is None:
			print("- active_obj dimensions", active_obj.dimensions, active_obj.name)
			#v_maxsize_g = (active_obj.dimensions[0]*1.2, active_obj.dimensions[1]*1.2, active_obj.dimensions[2]*1.2)
			v_maxsize_g = max(max(active_obj.dimensions[0], active_obj.dimensions[1]), active_obj.dimensions[2])*1.2
		else:
			print("- selection dimensions", v_maxsize_g)
			v_maxsize_g = v_maxsize_g*1.5
		if v_maxsize_g < 0.001:
			# for empties, etc - can be 0
			v_maxsize_g = 1.0
		if self.opt_mode == 'LATT':
			lattice_data = bpy.data.lattices.new(name=deformer_name)
			lattice_object = bpy.data.objects.new(name=deformer_name, object_data=lattice_data)
			lattice_data.points_u = int(5)
			lattice_data.points_v = int(1)
			lattice_data.points_w = int(5)
			#lattice_data.use_outside = True
			if active_obj.type == 'EMPTY':
				wla_do.link_object_to_scene(lattice_object, active_obj, 2)
			else:
				wla_do.link_object_sideBySide(lattice_object, active_obj)
			aLoc, aRot, aSca = lattice_object.matrix_world.decompose()
			aSca = (v_maxsize_g,v_maxsize_g,v_maxsize_g)
			if v_center_g is not None:
				aLoc = v_center_g
			lattice_object.matrix_world = Matrix.LocRotScale(aLoc, aRot, aSca)
			lattice_object.show_in_front = True
			#if active_obj.dimensions[1] < active_obj.dimensions[0] and active_obj.dimensions[1] < active_obj.dimensions[2]:
				# vertical stuff - like face
				# rotation should match face Y dir... or BIND will be fucked
			#	lattice_object.rotation_euler.rotate_axis("X", math.radians(-90))
			deformer_object = lattice_object
			wla_do.select_and_change_mode(active_obj,"OBJECT")
			# updating important CustomProps - for vgBind
			vg_groups = wla_attr.vg_names_by_nameToken(active_obj, config.kWPLSuppVGScriptToken)
			for vgname in vg_groups:
				deformer_object[vgname] = {"-1": 0.0}
			print("- Obj lattice: size", v_maxsize_g)
		if self.opt_mode == 'GRID':
			if active_obj.type == 'EMPTY':
				v_maxsize_g = 1.0
				v_center_g = wla.active_context_cursor()
			subd = 20
			if v_maxsize_g < 0.5:
				subd = 5
			elif v_maxsize_g < 3.0:
				subd = int(v_maxsize_g/0.5)
			elif v_maxsize_g < 10.0:
				subd = int(v_maxsize_g)
			wla_do.find_last_changed_objects(False)
			bpy.ops.mesh.primitive_grid_add(x_subdivisions=subd, y_subdivisions=subd, size=v_maxsize_g, align='WORLD', location=Vector((0,0,0)), rotation=(0, 0, 0), scale=(1, 1, 1))
			dups = wla_do.find_last_changed_objects(True)
			if len(dups) != 1:
				self.report({'ERROR'}, "Duplication failed")
				return {'CANCELLED'}
			grid_object = dups[0]
			if active_obj.type == 'EMPTY':
				wla_do.link_object_to_scene(grid_object, active_obj, 2)
			else:
				wla_do.link_object_sideBySide(grid_object, active_obj)
			wla_do.select_and_change_mode(grid_object,"OBJECT")
			if selFacesVC is not None:
				print("- grid: color", selFacesVC)
				wla_attr.vc_obj_ensure(grid_object, config.kWPLMeshColVC)
				wla_attr.vc_obj_update(grid_object,'FACE',config.kWPLMeshColVC, selFacesVC, (1.0,1.0,1.0), 1.0, None, None, None)
			if selFacesMat is not None:
				print("- grid: material", selFacesMat)
				wla_attr.mat_obj_ensuremat(grid_object, selFacesMat, False)
			if selFacesMat is None and config.kWPLGKey_vercolCP in config.WPL_G.store:
				print("- grid: pasting last copied VC/MAT")
				bpy.ops.mesh.wplvc_cppaste(opt_op = 'PASTE')
			elif len(active_obj.material_slots) > 0:
				wla_attr.mat_obj_ensuremat(grid_object, active_obj.material_slots[0].name, False)
			grid_object.name = deformer_name
			matrix_world = wla.math_matrixReplace(grid_object.matrix_world, v_center_g, None, None)
			grid_object.matrix_world = matrix_world
			grid_object.rotation_mode = 'XYZ'
			#grid_object.rotation_euler.rotate_axis("X", math.radians(90))
			# if 'POSE' in prevmode and active_obj.type == 'ARMATURE':
			# 	sel_bns = wla_arma.arm_bonenames_tok(active_obj, "<pose_sel>")
			# 	if len(sel_bns) == 1:
			# 		print("- object matrix: using selected bone", sel_bns[0])
			# 		# COPY_TRANSFORMS -> проблемы при сдвигах scene, рутовые трансформации складываются
			# 		# CHILD_OF -> тоже самое
			# 		pcontr = grid_object.constraints.new('COPY_TRANSFORMS')
			# 		pcontr.target = active_obj
			# 		pcontr.subtarget = sel_bns[0]
			# 		pcontr.mix_mode = 'REPLACE' # 'BEFORE' not ok, REPLACE works...
			# 		# Bone Parenting - ok, but OBJECT must be under ARMATURE... not convinient
			# 		# grid_object.parent = active_obj
			# 		# grid_object.parent_bone = sel_bns[0]
			# 		# grid_object.parent_type = 'BONE'
			# 		# grid_object.matrix_world = matrix_world.inverted()
			# 		#wla_do.select_and_change_mode(grid_object,"OBJECT")
			# 		#bpy.ops.object.parent_set()
			# else
			wla_do.link_with_vgsbind(active_obj, grid_object)
			deformer_object = grid_object
			print("- Grid created")
		if self.opt_orientation == 'CAMERA':
			camera_obj = wla.object_by_name(config.kWPLSystemMainCam)
			if camera_obj is not None:
				followCon = deformer_object.constraints.new('TRACK_TO')
				if self.opt_mode == 'GRID':
					followCon.track_axis = 'TRACK_Z'
				else:
					followCon.track_axis = 'TRACK_X'
				followCon.up_axis = 'UP_Y'
				followCon.target = camera_obj
		wla_do.sys_update_view(True, False)
		deformToolsOpts = context.scene.wpl_deformOpts
		deformToolsOpts.bind_targ = deformer_object.name
		return {'FINISHED'}

# ==========================================
# ==========================================

class WPL_DEFORMOPTS(bpy.types.PropertyGroup):
	bind_targ : StringProperty(
		name="Deformer",
		default = ""
	)

# class WPL_PT_DeformPanel1(bpy.types.Panel):
# 	bl_idname = "WPL_PT_DeformPanel1"
# 	bl_label = "GeomTools"
# 	bl_space_type = 'VIEW_3D'
# 	bl_region_type = 'UI'
# 	bl_category = 'Sculpt'

def uilayout_geomtBox(col, context):
	col.operator("mesh.wpldeform_force_xmirr", text='Smart XMirror', icon='MOD_MIRROR')
	col.separator()
	col.label(text = "vgBIND-Friendly:")
	row3 = col.row()
	op = row3.operator("mesh.wpldeform_smart_stripify", text='Stripify edges')
	op.opt_action = 'EDGESEL'
	op = row3.operator("mesh.wpldeform_smart_stripify", text='Cubify verts')
	op.opt_action = 'INDIVELEM'
	row4 = col.row()
	op = row4.operator("mesh.wpldeform_smart_convx", text='Add Convex')
	op.opt_remeshDensity = 0
	row4.operator("mesh.wpldeform_fill_simple", text='Add Wireframe').opt_flatnMeth = 'WFRAM'
	row4 = col.row()
	row4.operator("mesh.wpldeform_smart_grow_edge", text='Break/Grow edge')
	row4.operator("mesh.wplsculpt_edge_regul", text="Squarify edges")
	row4 = col.row()
	row4.operator("mesh.wpldeform_smart_patch", text='Tri-Stripe (vHist)', icon="MOD_TRIANGULATE")
	row4.operator("mesh.wpldeform_fill_simple", text='Refill (fSel)', icon="MOD_TRIANGULATE").opt_flatnMeth = 'FILLTRIG'
	col.label(text = "Other Tools:")
	col.operator("mesh.wplverts_weldinto", text='Weld selection', icon="AUTOMERGE_ON")
	row4 = col.row()
	row4.operator("mesh.wpldeform_smart_quads", text='Quad-Sword')
	row4.operator("mesh.wpldeform_smart_remesh", text='Quad-Wrap (wires)').opt_guidesMeth = 'WIRE'
	row4 = col.row()
	row4.operator("mesh.wplsculpt_edge_bisect", text = 'Bisect/edge')
	row4.operator("mesh.wplsculpt_edge_outline", text = 'Bisect/outline')
	box = col.box()
	box.label(text = "Add Details:")
	row4 = box.row()
	row4.operator("object.wpldeform_objlattice", text = '+SmartGrid (vgBIND)').opt_mode = 'GRID'
	addc4 = row4.operator("object.wpldeform_2curve", text = '+Curve/GN (vHis)')
	addc4.opt_targetTune = 'GN_CURVE'
	addc4.opt_sourceMeth = 'VHIST'
	addc4.opt_deflRadius = 1.0
	addc4.opt_shrw2src = True
	addc4.opt_noShadow = False
	addc4.opt_reusePrevs = True
	# row4 = box.row()
	# addc4 = row4.operator("object.wpldeform_2curve", text = '+Curve/Tube (vSel)')
	# addc4.opt_targetTune = 'DETAIL_TUBE'
	# addc4.opt_sourceMeth = 'SELC'
	# addc4.opt_deflRadius = 0.01
	# addc4.opt_shrw2src = True
	# addc4.opt_noShadow = True
	# addc4.opt_reusePrevs = False
	# addc4 = row4.operator("object.wpldeform_2curve", text = '+Curve/Stripe (vSel)')
	# addc4.opt_targetTune = 'DETAIL_STRIPE'
	# addc4.opt_sourceMeth = 'SELC'
	# addc4.opt_deflRadius = 0.01
	# addc4.opt_shrw2src = True
	# addc4.opt_noShadow = True
	# addc4.opt_reusePrevs = False
	row4 = box.row()
	addc4 = row4.operator("object.wpldeform_2curve", text = '+Curve/Sew (vSel)')
	addc4.opt_targetTune = 'DETAIL_SEW'
	addc4.opt_sourceMeth = 'SELC'
	addc4.opt_deflRadius = 0.0003
	addc4.opt_shrw2src = True
	addc4.opt_noShadow = True
	addc4.opt_reusePrevs = True
	addc4 = row4.operator("object.wpldeform_2curve", text = '+Curve/Sew (vHis)')
	addc4.opt_targetTune = 'DETAIL_SEW'
	addc4.opt_sourceMeth = 'VHIST'
	addc4.opt_deflRadius = 0.0003
	addc4.opt_shrw2src = True
	addc4.opt_noShadow = True
	addc4.opt_reusePrevs = True

	# addc1 = col.operator("object.wpldeform_2curve", text = '+Cube/Curve') # better with GN deformer
	# addc1.opt_targetTune = 'CURVE_DEFORM'
	# addc1.opt_sourceMeth = 'SELC'
	# box3.operator("object.wpldeform_extrskin", text = 'Add skinned tube')
	#row4.operator("mesh.wplsculpt_edge_unfuck", text="Unfuck")
	# from . import ops_tool_geomp
	# box1 = col.box()
	# ops_tool_geomp.uilayout_geompBox(box1, context)
	# from . import ops_tool_stampp
	# box1 = col.box()
	# ops_tool_stampp.uilayout_stamppBox(box1, context, False)

# ==========================================
# ==========================================

classes = (

	WPL_DEFORMOPTS,
	#WPL_PT_DeformPanel1,

	wpldeform_smart_stripify,
	wpldeform_smart_grow_edge,
	wpldeform_smart_patch,
	wpldeform_smart_remesh,
	wpldeform_smart_quads,
	wpldeform_smart_convx,
	wpldeform_fill_simple,
	wpldeform_force_xmirr,

	wpldeform_2curve,
	wpldeform_bindmodf,
	wpldeform_objlattice
	#wpldeform_extrskin,
)

def register():
	for cls in classes:
		bpy.utils.register_class(cls)
	bpy.types.Scene.wpl_deformOpts = bpy.props.PointerProperty(type=WPL_DEFORMOPTS)

def unregister():
	for cls in reversed(classes):
		bpy.utils.unregister_class(cls)
	del bpy.types.Scene.wpl_deformOpts

if __name__ == "__main__":
	register()