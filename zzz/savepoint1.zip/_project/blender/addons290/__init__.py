# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful, but
# WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTIBILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
# General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program. If not, see <http://www.gnu.org/licenses/>.

bl_info = {
    "name" : "WPLStudio",
    "author" : "IPv6",
    "description" : "",
    "blender" : (2, 90, 0),
    "version" : (1, 5, 2),
    "location" : "",
    "warning" : "",
    "category" : "Generic"
}

from . import config

from . import ops_scene_man
from . import ops_scene_nodes
from . import ops_tool_pff

from . import ops_curves_edit
from . import ops_prop_pose
from . import ops_prop_pose_rigui
from . import ops_mesh_edit1
from . import ops_mesh_edit2
from . import ops_tool_pin
from . import ops_tool_armadef
from . import ops_tool_geomp
from . import ops_tool_stampp
from . import ops_tool_camcut

from . import ops_prop_vgs
from . import ops_prop_helpers
from . import ops_prop_edging

from . import ops_mesh_selection
from . import ops_attr_uvvg
from . import ops_attr_vc

def register():
    print("WPLStudio: registering panels")

    config.init()

    ops_scene_man.register()
    ops_prop_vgs.register()
    ops_prop_edging.register()
    ops_prop_pose.register()
    ops_prop_pose_rigui.register()
    ops_mesh_edit1.register()
    ops_tool_pin.register()
    ops_tool_armadef.register()
    ops_tool_geomp.register()
    ops_tool_stampp.register()
    ops_tool_camcut.register()
    ops_mesh_edit2.register()
    ops_mesh_selection.register()
    ops_attr_vc.register()
    ops_attr_uvvg.register()
    ops_curves_edit.register()
    ops_prop_helpers.register()
    ops_scene_nodes.register()
    ops_tool_pff.register()
    print("WPLStudio: register done")

def unregister():

    ops_scene_man.unregister()
    ops_mesh_edit1.unregister()
    ops_tool_pin.unregister()
    ops_tool_armadef.unregister()
    ops_tool_geomp.unregister()
    ops_tool_stampp.unregister()
    ops_tool_camcut.unregister()
    ops_mesh_edit2.unregister()
    ops_mesh_selection.unregister()
    ops_attr_vc.unregister()
    ops_prop_vgs.unregister()
    ops_prop_edging.unregister()
    ops_attr_uvvg.unregister()
    ops_curves_edit.unregister()
    ops_prop_helpers.unregister()
    ops_scene_nodes.unregister()
    ops_prop_pose.unregister()
    ops_prop_pose_rigui.unregister()
    ops_tool_pff.unregister()
    print("WPLStudio: unregister done")
