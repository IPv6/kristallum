from faulthandler import is_enabled
import os, sys, time, datetime, io
import math, copy, string, random
import subprocess
import json
import numpy as np
import bpy, bmesh, mathutils

import bpy.types
from mathutils import Vector, Matrix, Euler, Quaternion
from mathutils.bvhtree import BVHTree
from mathutils.kdtree import KDTree
from bpy_extras import object_utils
from bpy.props import *

from . import config
from .tools import wla
from .tools import wla_do
from .tools import wla_bm
from .tools import wla_attr

kWPLPffProjImages = "#pff:proj_images"
kWPLPffPixels2Meters = 0.01
kWPLPffLayerNum2meters = 0.03
kWPLPffImageFolder = "_render"
kWPLPffGizmoPrefix = "zzz_gizmo"
kWPLPffCamDatas = "pff_camdata"
kWPLPffLayersPrefix = config.kWPLSuppPffPrefix+"layer"

# Need to know for proper frame-grid detection
# artset_cg_ww1920_hh1080 artset_char_poses_ww1944_hh3456
kWPLValidImageFrameDims = [ (1920, 1080), (int(1920/2), int(1080/2)), (1944, 3456), (int(1944/2), int(3456/2)) ]
# readable images
kWPL_PFF_EXT = ["png", "jpg", "jpeg", "tif", "tiff", "exr", "hdr"]
kWPL_PFF_EXT_hdr = "hdr_,.tiff,.tif,.exr,.hdr"

# PFF Material:
# - Material with "pff_" prefix
# - Textblock with SAME name, containing json with options
# "effect_name":"Normal Factor",
# "effect_samples":1,
# "opt1": {"name":"UVZ Image", "type":"image" }
# name
# description
# min_max
# default:
# - zero if none
# - 1.0, (-1.0, -1.0), (-1.0, -1.0, -1.0)
# type:
# - image
# - float1 float2 float3 int1
# - slider
# - mask_framegrid // see osl_texMaskGrid_v03.osl
# - gizmo_3dcUv gizmo_zdir

def gizmo_color_update(obj, metadata):
	col = metadata["prop_val"]
	opt_key = metadata["target_prop_name"]
	opt_key_obj = config.kWPLSystemNodeTagPFF + opt_key
	# need apply gamma correction to be on par with texture sampling
	obj[opt_key_obj] = [ pow(col[0], 2.2), pow(col[1], 2.2), pow(col[2], 2.2) ]
	#obj[opt_key_obj] = [ pow(col[0],0.42), pow(col[1],0.42), pow(col[2],0.42) ]
	#obj[opt_key_obj] = [col[0], col[1], col[2]]
	obj.data.update()

def gizmo_zdir_update(gizmo_zdir, metadata):
	base_grid = gizmo_zdir.parent
	if base_grid is not None:
		opt_key = metadata["target_prop_name"]
		opt_key_obj = config.kWPLSystemNodeTagPFF + opt_key
		matrix_world_inv = gizmo_zdir.matrix_world.inverted()
		matrix_world_norm = matrix_world_inv.transposed().to_3x3()
		zdir = matrix_world_norm @ Vector(( 0.0, 0.0, 1.0 ))
		zdir = (zdir[0], zdir[1], zdir[2])
		base_grid[opt_key_obj] = zdir
		#print("// value:", zdir)
		base_grid.data.update()
	return

def sendImgToClip(render_path):
	# # opening in Affinity, if present - works for Win, but fails to load image to already-opened instance on Mac
	# kWPLExecPaths = [
	# 	"c:\\Program Files\\Affinity\\Photo Customer Beta\\Photo.exe", 
	# 	"c:\\Program Files\\Affinity\\Photo\\Photo.exe",
	# 	#"/Applications/Affinity Photo Beta.app/Contents/MacOS/Affinity Photo Beta",
	# 	#"/Applications/Affinity Photo.app/Contents/MacOS/Affinity Photo"
	# ]
	# editr_path = None
	# for test_path in kWPLExecPaths:
	# 	if os.path.exists(test_path):
	# 		editr_path = test_path
	# 		break
	# if editr_path is not None:
	# 	#print("- external editor path", editr_path)
	# 	#editr_env = os.environ.copy()
	# 	# run WAITS for AP to finish
	# 	# editr_call = []
	# 	# editr_call.append(editr_path)
	# 	# editr_call.append(render_path)
	# 	# subprocess.run(editr_call, capture_output = False, shell=True) # , env=editr_env
	# 	ap_pid = subprocess.Popen( [editr_path, render_path]).pid
	# 	print("- external editor: image sent", editr_path, ap_pid)
	# else:
	# 	print("- external editor: not found", kWPLExecPaths)
	if sys.platform == "darwin":
		# direct open in preview application
		# ap_pid = subprocess.Popen( ["open", render_path]).pid
		# put to clipboard via AppleScript
		# https://stackoverflow.com/questions/6919403/set-clipboard-to-image-pbcopy
		#ap_pid = subprocess.Popen( ["osascript", "-e", "set the clipboard to (read (POSIX file '"+render_path+"') as \"class PNGf\")"]).pid
		#ap_pid = subprocess.Popen( ["osascript", "-e", "set the clipboard to POSIX file ('"+render_path+"')"]).pid
		# pasteboard module - MacOs only
		# https://github.com/tobywf/pasteboard/blob/master/tests.py
		if wla_do.pip_ensure_install("pasteboard"):
			import pasteboard
			pb = pasteboard.Pasteboard()
			with open(render_path, "rb") as imageFile:
				pb.set_contents(imageFile.read(), type=pasteboard.PNG)
			print("- clipboard: PNG saved")
	if sys.platform == "win32":
		# winclip32, win32clipboard - not ok, bloated instals also
		# ??? HDROP ??? https://www.reddit.com/r/learnpython/comments/akwfsc/for_the_past_couple_of_days_ive_been_trying_to/
		# https://superuser.com/questions/251411/how-can-i-load-an-image-directly-into-the-windows-clipboard-from-the-command-lin
		# http://www.nirsoft.net/utils/nircmd.html - works! but no transparency
		ap_pid = subprocess.Popen( ["c:\\_WPLabs\\Programs\\NirCmd\\nircmdc.exe", "clipboard", "copyimage", render_path]).pid
		print("- clipboard: BMP saved", ap_pid)
	# #if sys.platform == "linux":

def getImgFromClip(save_to_path):
	if sys.platform == "darwin":
		if wla_do.pip_ensure_install("pasteboard"):
			import pasteboard
			pb = pasteboard.Pasteboard()
			imgContent = pb.get_contents(diff = False, type=pasteboard.PNG)
			if imgContent is not None:
				with open(save_to_path, "wb") as imageFile:
					imageFile.write(imgContent)
				print("- clipboard: PNG saved to", save_to_path)
			else:
				print("- clipboard: PNG NOT saved, no data", save_to_path)
			return save_to_path
	return None

def getProjFolderPath(context, subfolder, imgname):
	wpl_pffOpts = context.scene.wpl_pffOpts
	proj_sub_folder = wpl_pffOpts.proj_folder
	proj_sub_folder = os.path.realpath(proj_sub_folder)
	if subfolder is not None:
		proj_sub_folder = os.path.join(proj_sub_folder, subfolder)
		proj_sub_folder = os.path.realpath(proj_sub_folder)
		if not os.path.exists(proj_sub_folder):
			os.makedirs(proj_sub_folder)
	if imgname is not None:
		render_path = os.path.join(proj_sub_folder, imgname)
		render_path = os.path.realpath(render_path)
		return render_path
	return proj_sub_folder

def getProjFolderSafePathName(context, img_name):
	proj_folder = getProjFolderPath(context, None, None)
	fname_safe = img_name
	fname_safe = fname_safe.replace(proj_folder,"")
	fname_safe = fname_safe.strip("/")
	fname_safe = fname_safe.strip("\\")
	fname_safe = fname_safe.strip(" ")
	# fname_safe = fname_safe.replace("/","_")
	# fname_safe = fname_safe.replace("\\","_")
	return fname_safe

def getProjSaveImageName(context, prefix, is_hdr = False):
	ts = time.time()
	save_name = prefix + "%Y%m%d_%H%M%S"
	render_name = datetime.datetime.fromtimestamp(ts).strftime(save_name)
	if is_hdr:
		render_name = render_name+".exr"
	else:
		render_name = render_name+".png"
	#render_path = os.path.join(wpl_pffOpts.proj_folder, render_name) # NOPE! need name only
	return render_name

def getMatEffectDescriptionForObj(active_obj):
	if (active_obj is not None) and (kWPLPffLayersPrefix in active_obj.name) and ("pff_effect" in active_obj):
		active_eff = active_obj["pff_effect"]
		desc_active, desc_optkeys = getMatEffectDescription(active_eff)
		return desc_active, desc_optkeys
	return None, None

def getMatEffectDescription(matName):
	if (matName is None) or len(matName) == 0:
		return None, None
	if bpy.data.materials.get(matName) is None:
		return None, None
	desc = None
	textblock = bpy.data.texts.get(matName)
	if textblock is not None:
		text = textblock.as_string()
		try:
			desc = json.loads(text)
		except Exception as e:
			print("- PFF: material description is not valid:", matName, e)
			return None, None
	desc_optkeys = []
	for ok in desc.keys():
		if (type(desc[ok]) is dict) and ("type" in desc[ok]):
			desc_optkeys.append(ok)
	if "opt_order" in desc:
		order = desc["opt_order"]
		desc_optkeys.sort(key=lambda ia: str(order.index(ia)).zfill(2)+ia if (ia in order) else "zzz_"+ia, reverse=False)
	else:
		desc_optkeys.sort()
	return desc, desc_optkeys

def getBaseFramesGrid(context):
	wpl_pffOpts = context.scene.wpl_pffOpts
	br_ww = int(wpl_pffOpts.base_resolution[0])
	br_hh = int(wpl_pffOpts.base_resolution[1])
	if br_ww <= 1 or br_hh <= 1:
		return None
	grid_ww = 1
	grid_hh = 1
	for respair in kWPLValidImageFrameDims:
		if br_ww == respair[0]:
			grid_hh = br_hh/respair[1]
			break
		elif br_ww == respair[1]:
			grid_hh = br_hh/respair[0]
			break
		elif br_hh == respair[0]:
			grid_ww = br_ww/respair[1]
			break
		elif br_hh == respair[1]:
			grid_ww = br_ww/respair[0]
			break
	return (grid_ww, grid_hh)

def imgLoadReload(context, img_name, img_cachdat):
	image_path = None
	fname_safe = None
	if img_name == "<clipboard>":
		render_name = getProjSaveImageName(context, "zzz_clip_")
		render_path = getProjFolderPath(context, kWPLPffImageFolder, render_name)
		img_name = getImgFromClip(render_path)
	if img_name is not None:
		# searching for name without folder
		image_path = img_name
		proj_folder = getProjFolderPath(context, None, None)
		if proj_folder not in image_path:
			image_path = getProjFolderPath(context, None, image_path)
			print("// getting path2", image_path, proj_folder)
		fname_safe = getProjFolderSafePathName(context, img_name)
		img = wla.sys_findImg(fname_safe, False)
	if img is None:
		# loading image
		if (image_path is not None) and os.path.exists(image_path):
			print("- PFF: loading image:", img_name, image_path, fname_safe)
			img = bpy.data.images.load(filepath = image_path)
			img.name = fname_safe
			if img is not None:
				if wla.isTokenInStr(kWPL_PFF_EXT_hdr, img_name):
					img.colorspace_settings.name = 'Non-Color'
					img.colorspace_settings.is_data = True
					#img.reload() # or negative value will be killed....
				else:
					img.colorspace_settings.name = 'sRGB'
					img.colorspace_settings.is_data = False
	else:
		print("- PFF: reusing/reloading image:", img_name)
		if img not in img_cachdat:
			img.reload()
			img_cachdat[img_name] = img
	if img is not None and (img.size[0] < 1.0 or img.size[1] < 1.0):
		print("- PFF: image loaded, but with errors", img_name, img)
		img = None
	if img is None:
		print("- PFF: failed to load image", img_name, image_path)
	return img

def imgInjectInMat(context, base_mat, imgs):
	if base_mat.use_nodes:
		for node in base_mat.node_tree.nodes:
			if config.kWPLSystemNodeTagPFF in node.label:
				for img_dat in imgs:
					ii_opt_key = img_dat[0]
					ii_opt_img = img_dat[1]
					if ii_opt_key in node.label:
						if node.type == 'TEX_IMAGE' or node.type == 'TEX_ENVIRONMENT':
							print("// Inject: Image: ", ii_opt_img.name)
							node.image = ii_opt_img
	return

class wplpff_layer_add(bpy.types.Operator):
	bl_idname = "object.wplpff_layer_add"
	bl_label = "PFF: Layer add"
	bl_options = {'REGISTER', 'UNDO'}

	def execute( self, context ):
		from . import ops_scene_man
		c_scene = bpy.context.scene
		pff_camera_obj = wla.object_by_name(config.kWPLSystemPffCam)
		if (pff_camera_obj is None) or (pff_camera_obj != c_scene.camera):
			self.report({'ERROR'}, "PFF not initialized")
			return {'CANCELLED'}
		wpl_pffOpts = context.scene.wpl_pffOpts
		# getting pff-material (check setup is present)
		matName = wpl_pffOpts.pff_matlist
		desc, desc_optkeys = getMatEffectDescription(matName)
		if desc is None:
			print("- PFF: effect description not valid", matName)
			self.report({'ERROR'}, "Invalid effect description")
			return {'CANCELLED'}
		# loading images according to pff-material, with proper color mode (sRGB/Non-color)
		imgs = []
		imgs_cache = {}
		imgs_to_load = 0
		for opt_key in desc_optkeys:
			if (opt_key in desc) and ("image" in desc[opt_key]["type"]):
				propKey_key = (desc[opt_key]["type"]).replace("image","").replace(",","")
				imgs_to_load = imgs_to_load+1
				img = None
				img_name = getattr(wpl_pffOpts, propKey_key)
				img = imgLoadReload(context, img_name, imgs_cache)
				if img is None:
					self.report({'ERROR'}, "Invalid image")
					return {'CANCELLED'}
				imgs.append( (opt_key, img, img_name) )
		base_img = None
		img_w = None
		img_h = None
		if len(imgs) == 0:
			if (getBaseFramesGrid(context) is not None):
				# grid_size = getBaseFramesGrid(context)
				img_w = wpl_pffOpts.base_resolution[0]
				img_h = wpl_pffOpts.base_resolution[1]
		else:
			base_img = imgs[0][1]
			img_w = base_img.size[0]
			img_h = base_img.size[1]
		if (img_w is None) or (img_h is None):
			print("- failed to get image size", img_w, img_h, imgs)
			self.report({'ERROR'}, "Layer dimensions are not known")
			return {'CANCELLED'}
		print("- PFF: layer images", imgs, img_w, img_h)
		# making grid, adding material(duplicated), proper size/position
		layers_left = wla.all_objects_by_name(kWPLPffLayersPrefix)
		layer_numtok = str(len(layers_left)+1).zfill(2)
		layer_name = kWPLPffLayersPrefix + layer_numtok + "_" + wla.strBareName(desc["effect_name"],False,True,True,False,True,True)
		base_mesh = bpy.data.meshes.new(kWPLPffLayersPrefix + layer_numtok + "mesh")
		base_grid = bpy.data.objects.new(layer_name, base_mesh)
		base_grid.matrix_world = Matrix.LocRotScale( Vector((0,0, kWPLPffLayerNum2meters*len(layers_left))), Matrix.Identity(3), (1,1,1))
		base_mat_idx = wla_attr.mat_obj_ensuremat(base_grid, matName, True)
		base_mat_slot = base_grid.material_slots[base_mat_idx]
		base_mat = base_mat_slot.material
		base_mat = base_mat.copy()
		base_mat.name = config.kWPLMatTokenLocal + matName
		base_mat_slot.material = base_mat
		bm = bmesh.new()
		init_content = "rect"
		if "effect_intial_content" in desc:
			init_content = desc["effect_intial_content"] # "empty"
		verts_v = []
		rect_verts_co = [ (-img_w*kWPLPffPixels2Meters*0.5, -img_h*kWPLPffPixels2Meters*0.5, 0.0), (img_w*kWPLPffPixels2Meters*0.5, -img_h*kWPLPffPixels2Meters*0.5, 0.0), (img_w*kWPLPffPixels2Meters*0.5, img_h*kWPLPffPixels2Meters*0.5, 0.0), (-img_w*kWPLPffPixels2Meters*0.5, img_h*kWPLPffPixels2Meters*0.5, 0.0) ]
		if init_content == "rect":
			pff_coUV = bm.verts.layers.float_vector.new("pff_coUV")
			for vCo in rect_verts_co:
				v = bm.verts.new( Vector(vCo) )
				v_uv_u = (vCo[0]-rect_verts_co[0][0])/(rect_verts_co[2][0] - rect_verts_co[0][0])
				v_uv_v = (vCo[1]-rect_verts_co[0][1])/(rect_verts_co[2][1] - rect_verts_co[0][1])
				v[pff_coUV] = Vector( ( v_uv_u, v_uv_v, 0.0 ))
				verts_v.append(v)
			# adding vertex attribute
		else:
			# CanvasUV needs to know coords to calc UVs
			base_grid["pff_coLT"] = rect_verts_co[0]
			base_grid["pff_coRB"] = rect_verts_co[2]
		bm.to_mesh(base_mesh)
		bm.verts.ensure_lookup_table()
		if len(verts_v) > 0:
			base_face = bm.faces.new(verts_v)
			base_face.material_index = base_mat_idx
			# pff_coUV = bm.loops.layers.float_vector.new("pff_coUV")
			# for v in bm.verts:
			# 	vCo = v.co
			# 	v_uv_u = (vCo[0]-rect_verts_co[0][0])/(rect_verts_co[2][0] - rect_verts_co[0][0])
			# 	v_uv_v = (vCo[1]-rect_verts_co[0][1])/(rect_verts_co[2][1] - rect_verts_co[0][1])
			# 	for loop in v.link_loops:
			# 	# for f in bm.faces:
			# 	# 	for loop in f.loops:
			# 		loop[pff_coUV] = Vector( ( v_uv_u, v_uv_v, 0.0 ))
			bm.to_mesh(base_mesh)
		base_grid.data.update()
		bm.free()
		wla_do.link_object_to_scene(base_grid, config.kWPLSystemPffColl)
		# injecting images into pff-material
		imgInjectInMat(context,base_mat,imgs)
		# adding custom prop according to pff-material opts
		wla_do.select_and_change_mode(base_grid, 'OBJECT')
		base_grid["pff_effect"] = matName
		base_grid["pff_img_w"] = img_w
		base_grid["pff_img_h"] = img_h
		for opt_key in desc_optkeys:
			opt_key_obj = config.kWPLSystemNodeTagPFF + opt_key
			if (opt_key in desc) and ("image" in desc[opt_key]["type"]):
				for img_dat in imgs:
					ii_opt_key = img_dat[0]
					ii_opt_img = img_dat[1]
					if ii_opt_key == opt_key:
						base_grid[opt_key_obj] = ii_opt_img.name
			if (opt_key in desc) and ("customprop" in desc[opt_key]["type"]):
				isFloat = True
				if "int1" in desc[opt_key]["type"]:
					isFloat = False
					d = 0
					if "default" in desc[opt_key]:
						d = desc[opt_key]["default"]
					desc[opt_key]["default"] = int(d)
				if "float1" in desc[opt_key]["type"]:
					isFloat = True
					d = 0.0
					if "default" in desc[opt_key]:
						d = desc[opt_key]["default"]
					desc[opt_key]["default"] = float(d)
				if "float2" in desc[opt_key]["type"]:
					isFloat = True
					d = (0.0, 0.0)
					if "default" in desc[opt_key]:
						d = desc[opt_key]["default"]
					desc[opt_key]["default"] = ( float(d[0]), float(d[1]) )
				if "float3" in desc[opt_key]["type"]:
					isFloat = True
					d = (0.0, 0.0, 0.0)
					if "default" in desc[opt_key]:
						d = desc[opt_key]["default"]
					desc[opt_key]["default"] = ( float(d[0]), float(d[1]), float(d[2]) )
				if ("default" in desc[opt_key]):
					print("- adding custom prop", desc[opt_key])
					base_grid[opt_key_obj] = desc[opt_key]["default"]
				else:
					print("- skipping custom prop, no default", desc[opt_key])
					continue
				if ("min_max" in desc[opt_key]):
					ui_data = base_grid.id_properties_ui(opt_key_obj)
					if isFloat:
						ui_data.update( min = float(desc[opt_key]["min_max"][0]), max = float(desc[opt_key]["min_max"][1]) )
					else:
						ui_data.update( min = int(desc[opt_key]["min_max"][0]), max = int(desc[opt_key]["min_max"][1]) )
				if ("description" in desc[opt_key]):
					print("- updating desc",  desc[opt_key]["description"])
					ui_data = base_grid.id_properties_ui(opt_key_obj)
					ui_data.update( description = desc[opt_key]["description"])
				# "slider" "mask_framegrid" "gizmo_3dcUv"
				if ("gizmo_zdir" in desc[opt_key]["type"]):
					# adding empty as gizmo
					hotobj = ops_scene_man.kWPLGKey_HT_Objects
					gizmo_name = kWPLPffGizmoPrefix + "_" + layer_numtok + "_" + "gizmo_zdir"
					gizmo_empty = wla.find_child_by_name(base_grid, gizmo_name)
					if gizmo_empty is None:
						gizmo_empty = bpy.data.objects.new(gizmo_name, None)
						gizmo_empty.empty_display_size = min(img_w, img_h)*kWPLPffPixels2Meters*0.1
						gizmo_empty.empty_display_type = 'SPHERE' #'PLAIN_AXES'
						wla_do.link_object_to_scene(gizmo_empty, base_grid)
						gizmo_empty.matrix_world = Matrix.Identity(4)
					empty_ht_key = ops_scene_man.kWPLGKey_HT_ObjUpdate + gizmo_empty.name
					if empty_ht_key not in hotobj:
						hotobj[empty_ht_key] = {}
						hotobj[empty_ht_key]["object"] = gizmo_empty.name
						hotobj[empty_ht_key]["update"] = {}
					hotobj[empty_ht_key]["target_prop_name"] = opt_key
					hotobj[empty_ht_key]["update"]["gizmo_zdir"] = gizmo_zdir_update
		# if needed - initializing render according to base layer resolution
		if (getBaseFramesGrid(context) is None) and (base_img is not None):
			wpl_pffOpts.base_resolution = (base_img.size[0], base_img.size[1])
			bpy.ops.object.wplpff_setup_proj(opt_initCam = True, opt_initResol = True)
		base_grid.data.update()
		return {'FINISHED'}

class wplpff_layer_alter(bpy.types.Operator):
	bl_idname = "object.wplpff_layer_alter"
	bl_label = "PFF: Layer alter"
	bl_options = {'REGISTER', 'UNDO'}

	opt_action : EnumProperty(
		name="Action", default="ACTIVATE",
		items=(	
			("ACTIVATE", "Activate Layer", ""), 
			("DEL", "Delete Layer", ""),
			("ALT_OPT_FRAMEGRID", "Alt opt: frame grid", ""),
			("ALT_OPT_3DCUV", "Alt opt: UV from 3D Cursor", ""),
			("ALT_OPT_COLOR", "Alt opt: Color from picker", ""),
			("ALT_OPT_TOGIZMO", "Alt opt: Activate Gizmo", ""),
		)
	)
	opt_layerName: StringProperty(
		name		= "Layer Name",
		default	 	= "",
	)
	opt_optionName: StringProperty(
		name		= "Option Name",
		default	 	= "",
	)
	opt_optionVal: StringProperty(
		name		= "Option Value",
		default	 	= "",
	)

	def execute( self, context ):
		layer_obj = wla.object_by_name(self.opt_layerName)
		if layer_obj is None:
			self.report({'ERROR'}, "Invalid layer name")
			return {'CANCELLED'}
		wpl_pffOpts = context.scene.wpl_pffOpts
		if self.opt_action == 'DEL':
			# deleting old mesh
			print("- PFF: deleting layer grid", layer_obj.name)
			if len(layer_obj.children) > 0:
				# need to delete shole hierarchy (gizmos)
				for child in layer_obj.children:
					bpy.data.objects.remove(child, do_unlink=True)
			bpy.data.objects.remove(layer_obj, do_unlink=True)
			# if no layers left - resetting resolution
			layers_left = wla.all_objects_by_name(kWPLPffLayersPrefix)
			if len(layers_left) == 0:
				print("- PFF: no layers left, resetting base resolution")
				wpl_pffOpts.base_resolution = (0.0, 0.0)
		if self.opt_action == 'ACTIVATE':
			wla_do.select_and_change_mode(layer_obj, 'OBJECT')
		if self.opt_action == 'ALT_OPT_COLOR':
			col = getattr(wpl_pffOpts, self.opt_optionVal)
			metadata = {}
			metadata["target_prop_name"] = self.opt_optionName
			metadata["prop_val"] = col
			gizmo_color_update(layer_obj, metadata)
		if self.opt_action == 'ALT_OPT_FRAMEGRID':
			# osl_texMaskGrid_v03.osl
			grid_size = getBaseFramesGrid(context)
			opt_key_obj = config.kWPLSystemNodeTagPFF + self.opt_optionName
			if (opt_key_obj not in layer_obj) or (grid_size is None):
				self.report({'ERROR'}, "Invalid option or no base found")
				return {'CANCELLED'}
			opt_val = layer_obj[opt_key_obj]
			opt_val = [opt_val[0], opt_val[1]]
			grid_idx = 0
			val_pos_inv = False
			grid_len = max(grid_size[1], grid_size[0])
			if grid_size[1] > grid_size[0]:
				grid_idx = 1
			else:
				val_pos_inv = True
			if opt_val[grid_idx] < 0:
				opt_val[grid_idx] = pow(10, grid_len)-1
			val_str = list(str(int(opt_val[grid_idx])))
			val_pos = int(self.opt_optionVal)-1
			if val_pos_inv:
				val_pos = int(grid_len-val_pos-1)
			print("- changing frame vis", val_str, val_pos)
			if val_str[val_pos] == '9':
				val_str[val_pos] = '1'
			else:
				val_str[val_pos] = '9'
			opt_val[grid_idx] = float(''.join(val_str))
			layer_obj[opt_key_obj] = opt_val
			layer_obj.data.update()
		if self.opt_action == 'ALT_OPT_3DCUV':
			opt_key_obj = config.kWPLSystemNodeTagPFF + self.opt_optionName
			targetCenter_g =  wla.active_context_cursor()
			if (opt_key_obj not in layer_obj) or (targetCenter_g is None):
				self.report({'ERROR'}, "Invalid option or no cursor found")
				return {'CANCELLED'}
			bbc = []
			bbc.extend([layer_obj.matrix_world @ Vector(corner) for corner in layer_obj.bound_box])
			bbc_min_pt = [ min(item[0] for item in bbc), min(item[1] for item in bbc), min(item[2] for item in bbc)]
			bbc_max_pt = [ max(item[0] for item in bbc), max(item[1] for item in bbc), max(item[2] for item in bbc)]
			#targetCenter_l = layer_obj.matrix_world.inverted() @ targetCenter_g
			coord_u = (targetCenter_g[0]-bbc_min_pt[0])/(bbc_max_pt[0]-bbc_min_pt[0])
			coord_v = (targetCenter_g[1]-bbc_min_pt[1])/(bbc_max_pt[1]-bbc_min_pt[1])
			layer_obj[opt_key_obj] = (coord_u, coord_v)
			layer_obj.data.update()
		if self.opt_action == 'ALT_OPT_TOGIZMO':
			gizmo_empty = wla.object_by_name(self.opt_optionVal)
			if gizmo_empty is not None:
				wla_do.ensure_visible(gizmo_empty, True)
				wla_do.select_and_change_mode(gizmo_empty, 'OBJECT')
		return {'FINISHED'}

class wplpff_save_compo(bpy.types.Operator):
	bl_idname = "object.wplpff_save_compo"
	bl_label = "PFF: Save Render"
	bl_options = {'REGISTER', 'UNDO'}

	opt_action : EnumProperty(
		name="Action", default="EXPORT",
		items=(	
			("EXPORT", "Export to clipboard", ""), 
			("NEWPLAIN", "Save for Layer", ""),
			("BATCH32", "Batch Processing", "")
		)
	)
	opt_renderSamples : IntProperty(
		name="Samples",
		min=1, max=100,
		default=1
	)

	def execute( self, context ):
		from . import ops_scene_man
		wpl_pffOpts = context.scene.wpl_pffOpts
		proj_folder = getProjFolderPath(context, None, None)
		if (proj_folder is None) or  len(proj_folder) < 5 or (not os.path.exists(proj_folder)):
			print("- PFF: project path not valid", proj_folder)
			self.report({'ERROR'}, "Invalid project path")
			return {'FINISHED'}
		c_scene = bpy.context.scene
		pff_camera_obj = wla.object_by_name(config.kWPLSystemPffCam)
		if pff_camera_obj is None:
			self.report({'ERROR'}, "Invalid camera")
			return {'FINISHED'}
		if kWPLPffCamDatas not in config.WPL_G.store:
			self.report({'ERROR'}, "PFF needs Re-activation")
			return {'FINISHED'}
		max_samps = self.opt_renderSamples
		is_hdr = False
		layers_left = wla.all_objects_by_name(kWPLPffLayersPrefix)
		if len(layers_left) > 0:
			for layer_obj in layers_left:
				if layer_obj.hide_render or layer_obj.hide_viewport:
					continue
				active_eff = layer_obj["pff_effect"]
				desc, _ = getMatEffectDescription(active_eff)
				if desc is None:
					continue
				# print("- layer desc", desc, wla.isTokenInStr(kWPL_PFF_EXT_hdr, desc["effect_mode"]))
				if "effect_samples" in desc:
					max_samps = max(max_samps, int(desc["effect_samples"]))
				if "effect_mode" in desc:
					if wla.isTokenInStr(kWPL_PFF_EXT_hdr, desc["effect_mode"]):
						is_hdr = True
		render_name = getProjSaveImageName(context, "tmp_", is_hdr)
		if self.opt_action == 'NEWPLAIN':
			render_name = getProjSaveImageName(context, "zzz_save_", is_hdr)
			render_path = getProjFolderPath(context, None, render_name)
		else:
			render_path = getProjFolderPath(context, kWPLPffImageFolder, render_name)
		if kWPLPffCamDatas in config.WPL_G.store:
			#print("- restoring camera")
			pff_camera_obj.matrix_world = config.WPL_G.store[kWPLPffCamDatas][0]
			pff_camera_obj.data.shift_x = config.WPL_G.store[kWPLPffCamDatas][1]
			pff_camera_obj.data.shift_y = config.WPL_G.store[kWPLPffCamDatas][2]
			pff_camera_obj.rotation_mode = config.WPL_G.store[kWPLPffCamDatas][3]
			wla_do.sys_update_view(True, False)
		else:
			print("- restoring camera: skipped, no data")
		vl_main = ops_scene_man.getViewLayer(config.kWPLLayerRenderMain)
		if vl_main is None:
			self.report({'ERROR'}, "Invalid main view layer")
			return {'CANCELLED'}
		context.window.view_layer = vl_main
		vl_main.samples = max_samps
		vl_main.use_pass_combined = True
		vl_main.use_pass_material_index = False
		vl_main.use_pass_z = False
		vl_main.use_pass_shadow = False
		vl_main.use_pass_normal = False
		vl_main.use_pass_mist = False
		vl_main.use_pass_diffuse_color = False
		vl_main.use_pass_emit = False
		vl_main.use_pass_glossy_color = False
		vl_main.use_pass_transmission_color = False
		vl_main.use_pass_subsurface_color = False
		vl_main.use_pass_ambient_occlusion = False
		vl_main.cycles.use_denoising = False
		# for vl in bpy.context.scene.view_layers:
		# 	if vl.name == vl_main.name:
		# 		vl.use = True
		# 	else:
		# 		vl.use = False
		cur_scene_filepath = c_scene.render.filepath
		config.WPL_G.store["drv_verbose"] = 0
		c_scene.cycles.max_bounces = 1
		c_scene.cycles.use_denoising = False
		c_scene.cycles.use_preview_denoising = False
		c_scene.cycles.use_adaptive_sampling = False
		c_scene.view_settings.view_transform = 'Standard'
		c_scene.sequencer_colorspace_settings.name = 'Raw'
		c_scene.render.resolution_percentage = 100
		c_scene.render.use_border = False
		c_scene.render.use_compositing = False
		c_scene.render.use_sequencer = False
		if self.opt_action == 'EXPORT' or self.opt_action == 'NEWPLAIN':
			print("- PFF: Starting render to", render_path, "samples", max_samps)
			if is_hdr:
				c_scene.render.image_settings.file_format ='OPEN_EXR'
				c_scene.render.image_settings.color_mode = 'RGBA'
				c_scene.render.image_settings.color_depth = '16'
			else:
				c_scene.render.image_settings.file_format ='PNG'
				c_scene.render.image_settings.color_mode = 'RGBA'
				c_scene.render.image_settings.color_depth = '8'
			c_scene.render.filepath = render_path
			bpy.ops.render.render(animation=False, write_still=True, use_viewport=False, scene=c_scene.name, layer=vl_main.name)
			print("- Render saved to", render_path)
			self.report({'INFO'}, "Done, saved to "+render_path)
			if is_hdr == False:
				sendImgToClip(render_path)
			if self.opt_action == 'NEWPLAIN':
				if kWPLPffProjImages in config.WPL_G.store:
					del config.WPL_G.store[kWPLPffProjImages]
				# proj_folder_ensureFiles(context) render_name MUST be in list of files
				wpl_pffOpts.pff_img01 = render_name
		if self.opt_action == 'BATCH32':
			okCnt = 0
			active_obj = wla.active_object()
			base_mat = None
			if active_obj is not None:
				base_mat_slot = active_obj.material_slots[0]
				if base_mat_slot is not None:
					base_mat = base_mat_slot.material
			batched_key = None
			desc_active, desc_optkeys = getMatEffectDescriptionForObj(active_obj)
			if (desc_active is not None) and ("effect_batchable_opt" in desc_active):
				batched_key = desc_active["effect_batchable_opt"]
			else:
				print("- skipping batch: no batchable image description found", desc_active)
			# print("- Batch processing", desc_active, wpl_pffOpts.batch_folder)
			if (batched_key is not None) and len(wpl_pffOpts.batch_folder) > 0 and (base_mat is not None):
				render_path = getProjFolderPath(context, None, None)
				batch_folder = bpy.path.abspath(wpl_pffOpts.batch_folder)
				batch_files = wla.sys_filesWithSubd(batch_folder, kWPL_PFF_EXT)
				batch_files.sort()
				# print("- files to render", batch_folder, batch_files, render_path)
				fimg_cache = {}
				fimg_tmp_tok = "_tmp_"
				for idx,fimg_path in enumerate(batch_files):
					print("- batch: loading image", idx+1, "of", len(batch_files), fimg_path)
					img = imgLoadReload(context, fimg_path, fimg_cache)
					imgInjectInMat(context, base_mat, [ (batched_key, img) ] )
					wla_do.sys_update_view(True, True)
					render_path = (os.path.splitext(fimg_path)[0]) + fimg_tmp_tok
					if wla.isTokenInStr(kWPL_PFF_EXT_hdr, fimg_path):
						c_scene.render.image_settings.file_format ='OPEN_EXR'
						c_scene.render.image_settings.color_mode = 'RGBA'
						c_scene.render.image_settings.color_depth = '16'
						render_path = render_path+".exr"
					else:
						c_scene.render.image_settings.file_format ='PNG'
						c_scene.render.image_settings.color_mode = 'RGBA'
						c_scene.render.image_settings.color_depth = '8'
						render_path = render_path+".png"
					c_scene.render.filepath = render_path
					print("// rendering to", render_path)
					bpy.ops.render.render(animation=False, write_still=True, use_viewport=False, scene=c_scene.name, layer=vl_main.name)
					if os.path.exists(render_path):
						okCnt = okCnt+1
						print("- batch: finishing file", idx+1, "of", len(batch_files))
						os.remove(fimg_path)
						render_path_fin = render_path.replace(fimg_tmp_tok, "")
						os.rename(render_path, render_path_fin)
					else:
						print("- batch: finishing file", idx+1," skipped, render problem. path:", render_path)
			self.report({'INFO'}, "Done, rendered "+str(okCnt)+" files")
		c_scene.render.filepath = cur_scene_filepath
		config.WPL_G.store[ops_scene_man.kWPLGKey_DRV_SyncStatus] = config.kWPLSystemNodeTagPFF+"INVALID" # to force resyncs after PFF renderings
		return {'FINISHED'}

class wplpff_setup_proj(bpy.types.Operator):
	bl_idname = "object.wplpff_setup_proj"
	bl_label = "PFF: setup"
	bl_options = {'REGISTER', 'UNDO'}

	opt_initCam : BoolProperty(
		name="Initialize Camera",
		default=True,
	)
	opt_initResol : BoolProperty(
		name="Initialize Resolution",
		default=False,
	)

	def execute( self, context ):
		wpl_pffOpts = context.scene.wpl_pffOpts
		proj_folder = getProjFolderPath(context, None, None)
		if (proj_folder is None) or  len(proj_folder) < 5 or (not os.path.exists(proj_folder)):
			print("- PFF: project path not valid", proj_folder)
			self.report({'ERROR'}, "Invalid project path")
			return {'CANCELLED'}
		wpl_stamppOpts = context.scene.wpl_stamppOpts
		wpl_stamppOpts.opt_gridorient = 'LOCAL_XY' # default drawing plane - Top View
		wpl_stamppOpts.opt_curv_fg_cuh = '111'
		from . import ops_scene_man
		c_scene = bpy.context.scene
		c_scene.frame_set(0)
		wla.sys_collection(config.kWPLSystemPffColl)
		vl_main = ops_scene_man.getViewLayer(config.kWPLLayerRenderMain)
		if vl_main is not None:# may be none for test scenes
			context.window.view_layer = vl_main
			lc_all = wla_do.view_layer_asllchildren(vl_main.layer_collection.children, True)
			for lc in lc_all:
				if config.kWPLSystemPffColl in lc.name:
					lc.exclude = False
				else:
					lc.exclude = True
		pff_camera_obj = wla.object_by_name(config.kWPLSystemPffCam)
		if pff_camera_obj is None:
			print("- creating camera: ", config.kWPLSystemPffCam)
			cam_data = bpy.data.cameras.new(config.kWPLSystemPffCam)
			pff_camera_obj = bpy.data.objects.new(config.kWPLSystemPffCam, cam_data)
			wla_do.link_object_to_scene(pff_camera_obj, config.kWPLSystemPffColl)
		pff_camera_obj.data.type = 'ORTHO'
		pff_camera_obj.data.shift_x = 0
		pff_camera_obj.data.shift_y = 0
		pff_camera_obj.data.clip_start = 0.03
		pff_camera_obj.data.clip_end = 10000
		pff_camera_obj.location = Vector((0,0,10))
		pff_camera_obj.rotation_mode = 'XYZ'
		pff_camera_obj.rotation_euler = (0,0,0)
		#pff_camera_obj.rotation_mode = 'QUATERNION'
		#pff_camera_obj.rotation_quaternion = Euler((0,0,0), 'XYZ').to_quaternion()
		pff_camera_obj.hide_render = False
		c_scene.camera = pff_camera_obj
		wla_do.sys_update_view(True, False)
		if self.opt_initResol:
			print("- PFF: resolution", wpl_pffOpts.base_resolution)
			if getBaseFramesGrid(context) is not None:
				ops_scene_man.ensureSceneDefauts(pff_camera_obj)
				#depsgraph = bpy.context.evaluated_depsgraph_get()
				img_w = wpl_pffOpts.base_resolution[0]
				img_h = wpl_pffOpts.base_resolution[1]
				print("- PFF: resolution", img_w, img_h)
				# verts_co = ( (-img_w*kWPLPffPixels2Meters*0.5, -img_h*kWPLPffPixels2Meters*0.5, 0.0), (img_w*kWPLPffPixels2Meters*0.5, -img_h*kWPLPffPixels2Meters*0.5, 0.0), (img_w*kWPLPffPixels2Meters*0.5, img_h*kWPLPffPixels2Meters*0.5, 0.0), (-img_w*kWPLPffPixels2Meters*0.5, img_h*kWPLPffPixels2Meters*0.5, 0.0) )
				# verts_co = verts_co + ( (-img_w*kWPLPffPixels2Meters*0.5, -img_h*kWPLPffPixels2Meters*0.5, 1.0), (img_w*kWPLPffPixels2Meters*0.5, -img_h*kWPLPffPixels2Meters*0.5, 1.0), (img_w*kWPLPffPixels2Meters*0.5, img_h*kWPLPffPixels2Meters*0.5, 1.0), (-img_w*kWPLPffPixels2Meters*0.5, img_h*kWPLPffPixels2Meters*0.5, 1.0) )
				c_scene.render.resolution_percentage = 100
				c_scene.render.resolution_x = int(img_w)
				c_scene.render.resolution_y = int(img_h)
				wla_do.sys_update_view(True, False)
				vert_l_t = Vector( (-img_w*kWPLPffPixels2Meters*0.5, -img_h*kWPLPffPixels2Meters*0.5, 0.0) )
				vert_l_t_cam = Vector( (0.0, 0.0) )
				# - NDC 1-2-3 <Vector (-21.1000, -21.1000, 10.0000)> <Vector (-10.3000, -10.3000, 10.0000)> <Vector (-6.7000, -6.7000, 10.0000)>
				# Need to get scale so world_to_camera_view returns NDC (-1, -1, ???)
				# SEARCHING BY BISECT - enough for pixel-perfect
				max_bisects = 100
				scal_lim = [1,100]
				scal_to_one = scal_lim[0]
				while max_bisects > 0:
					max_bisects = max_bisects-1
					scal_to_one = (scal_lim[0]+scal_lim[1]) * 0.5
					pff_camera_obj.data.ortho_scale = scal_to_one
					# returns in (0,0)-(1,1)
					scal_p = object_utils.world_to_camera_view(c_scene, pff_camera_obj, vert_l_t )
					if abs(scal_p[0] - vert_l_t_cam[0]) <= config.kWPLRaycastEpsilon*0.1:
						break
					if scal_p[0] < vert_l_t_cam[0]:
						scal_lim[0] = scal_to_one
					else:
						scal_lim[1] = scal_to_one
				print("- Bisects to find scale:", 100-max_bisects)
				#scal_to_one = math.log( max(img_w, img_h), 2)
				pff_camera_obj.data.ortho_scale = scal_to_one
				# coords = [t for b in verts_co for t in b]
				# cam_v, cam_scale = pff_camera_obj.camera_fit_coords(depsgraph, coords) # not exactly cover
				# pff_camera_obj.data.ortho_scale = cam_scale
				# starting render mode
				bpy.context.space_data.shading.type = 'RENDERED'
				bpy.context.space_data.overlay.show_overlays = True
				bpy.context.space_data.overlay.show_face_orientation = False
		if kWPLPffProjImages in config.WPL_G.store:
			del config.WPL_G.store[kWPLPffProjImages]
		config.WPL_G.store[ops_scene_man.kWPLGKey_DRV_SyncStatus] = config.kWPLSystemNodeTagPFF+"INVALID" # to force resyncs after PFF renderings
		config.WPL_G.store[kWPLPffCamDatas] = [pff_camera_obj.matrix_world.copy(), pff_camera_obj.data.shift_x, pff_camera_obj.data.shift_y, pff_camera_obj.rotation_mode]
		return {'FINISHED'}

# ==========================================
# ==========================================
def proj_folder_ensureFiles(context):
	if kWPLPffProjImages not in config.WPL_G.store:
		wpl_pffOpts = context.scene.wpl_pffOpts
		flist = []
		if len(wpl_pffOpts.proj_folder) > 0:
			#proj_files = os.listdir(wpl_pffOpts.proj_folder)
			proj_folder = getProjFolderPath(context, None, None)
			proj_files = wla.sys_filesWithSubd(proj_folder, kWPL_PFF_EXT)
			proj_files.sort()
			for fname in proj_files:
				if ((kWPLPffImageFolder+"/") in fname) or ((kWPLPffImageFolder+"\\") in fname):
					# PFF saves, not needed
					continue
				fname = fname.replace(proj_folder, '').strip("/")
				fname = fname.replace(proj_folder, '').strip("\\")
				flist.append(fname)
		flist.append("<clipboard>")
		config.WPL_G.store[kWPLPffProjImages] = flist
	return config.WPL_G.store[kWPLPffProjImages]
def WPL_PFFOPTS_proj_folder_get(self):
	if (self is None) or ("proj_folder" not in self):
		return ""
	return self["proj_folder"]
def WPL_PFFOPTS_proj_folder_set(self, value):
	#print("WPL_PFFOPTS_projpath_set", value, bpy.path.abspath(value))
	self["proj_folder"] = bpy.path.abspath(value)
	if kWPLPffProjImages in config.WPL_G.store:
		del config.WPL_G.store[kWPLPffProjImages]

def WPL_PFFOPTS_pff_matlist_items(self, context):
	lst = []
	for mat in bpy.data.materials:
		if config.kWPLMatTokenLocal in mat.name:
			# local duplications
			continue 
		if config.kWPLSuppPffPrefix in mat.name:
			desc, _ = getMatEffectDescription(mat.name)
			if desc is None:
				continue
			lst.append((mat.name, mat.name, "PFF effect"))
	lst.sort(key=lambda ia: ia[0], reverse=False)
	return lst
def WPL_PFFOPTS_pff_img01_items(self, context):
	lst = []
	proj_folder_ensureFiles(context)
	for fname in config.WPL_G.store[kWPLPffProjImages]:
		lst.append((fname, fname, "Project image"))
	return lst

class WPL_PFFOPTS(bpy.types.PropertyGroup):
	proj_folder : StringProperty(
		subtype = 'DIR_PATH',
		name = "Project folder",
		default = "",
		get = WPL_PFFOPTS_proj_folder_get,
		set = WPL_PFFOPTS_proj_folder_set
	)
	batch_folder : StringProperty(
		subtype = 'DIR_PATH',
		name = "Batch folder",
		default = "",
	)

	base_resolution :  FloatVectorProperty(
		name = "Project resolution",
		size = 2,
		default	 = (0.0,0.0),
	)

	pff_matlist: EnumProperty(
		# https://blender.stackexchange.com/questions/214189/how-do-i-set-the-selected-value-of-an-enumproperty
		name = "Filter",
		items = WPL_PFFOPTS_pff_matlist_items,
		#update = WPL_PFFOPTS_pff_matlist_set
	)

	pff_img01: EnumProperty(
		name = "Project image",
		items = WPL_PFFOPTS_pff_img01_items,
	)
	pff_img02: EnumProperty(
		name = "Project image",
		items = WPL_PFFOPTS_pff_img01_items,
	)
	pff_img03: EnumProperty(
		name = "Project image",
		items = WPL_PFFOPTS_pff_img01_items,
	)
	pff_img04: EnumProperty(
		name = "Project image",
		items = WPL_PFFOPTS_pff_img01_items,
	)
	pff_col01 : FloatVectorProperty(name="Col", subtype='COLOR_GAMMA', min=0.0, max=1.0, default = (0.0,0.0,0.0))
	pff_col02 : FloatVectorProperty(name="Col", subtype='COLOR_GAMMA', min=0.0, max=1.0, default = (0.0,0.0,0.0))
	pff_col03 : FloatVectorProperty(name="Col", subtype='COLOR_GAMMA', min=0.0, max=1.0, default = (0.7,0.3,0.3))
	pff_col04 : FloatVectorProperty(name="Col", subtype='COLOR_GAMMA', min=0.0, max=1.0, default = (0.7,0.3,0.3))
	pff_col05 : FloatVectorProperty(name="Col", subtype='COLOR_GAMMA', min=0.0, max=1.0, default = (1.0,1.0,1.0))
	pff_col06 : FloatVectorProperty(name="Col", subtype='COLOR_GAMMA', min=0.0, max=1.0, default = (1.0,1.0,1.0))
	pff_col07 : FloatVectorProperty(name="Col", subtype='COLOR_GAMMA', min=0.0, max=1.0, default = (0.3,0.3,0.3))
	pff_col08 : FloatVectorProperty(name="Col", subtype='COLOR_GAMMA', min=0.0, max=1.0, default = (0.3,0.3,0.3))
# Used colors as intermediary values
kWPL_PFF_COLPROPRNAMES = ["pff_col01", "pff_col02", "pff_col03", "pff_col04", "pff_col05", "pff_col06", "pff_col07", "pff_col08"]
# Used image properties
kWPL_PFF_IMGPROPRNAMES = ["pff_img01", "pff_img02", "pff_img03", "pff_img04"]

class WPL_PT_PffPanel(bpy.types.Panel):
	bl_idname = "WPL_PT_PffPanel"
	bl_label = "Pixel Filter Forger"
	bl_space_type = 'VIEW_3D'
	bl_region_type = 'UI'
	bl_category = 'PFF'

	def draw(self, context):
		from . import ops_scene_man
		wpl_pffOpts = context.scene.wpl_pffOpts
		layout = self.layout
		col = layout.column()
		row1 = col.row()
		row1.label( text = "Project folder")
		row1.prop(wpl_pffOpts, 'proj_folder')
		pff_camera_obj = wla.object_by_name(config.kWPLSystemPffCam)
		proj_folder = getProjFolderPath(context, None, None)
		# if (pff_camera_obj is not None) and (kWPLPffProjcetFolderPath in pff_camera_obj):
		# 	proj_folder = pff_camera_obj[kWPLPffProjcetFolderPath]
		if (proj_folder is not None):
			if len(proj_folder) < 5:
				#print("- PFF: project folder too short", proj_folder)
				proj_folder = None
			elif not os.path.exists(proj_folder):
				#print("- PFF: project folder not valid", proj_folder)
				proj_folder = None
		#print("- PFF: project folder", proj_folder)
		if (proj_folder is None) or (pff_camera_obj is None):
			col.label(text = "Pixel Filter Forger not initialized")
			op = col.operator("object.wplpff_setup_proj", text = 'Init project')
			op.opt_initResol = False
			return
		op = col.operator("object.wplpff_setup_proj", text = 'Re-Activate / Update files')
		op.opt_initResol = True
		col.separator()
		# active layer options
		desc_active = None
		desc_optkeys = None
		active_obj = wla.active_object()
		desc_active, desc_optkeys = getMatEffectDescriptionForObj(active_obj)
		# list of layers
		box = col.box()
		layers_left = wla.all_objects_by_name(kWPLPffLayersPrefix)
		if len(layers_left) > 0:
			for layer_obj in layers_left:
				lay_nm = layer_obj.name
				row1 = box.row()
				spl = row1.split(align=True, factor=0.8)
				op = spl.column().operator("object.wplpff_layer_alter", text = "[ "+lay_nm+" ]")
				op.opt_action = 'ACTIVATE'
				op.opt_layerName = lay_nm
				op = spl.column().operator("object.wplpff_layer_alter", text = 'DEL')
				op.opt_action = 'DEL'
				op.opt_layerName = lay_nm
			# save current compositions (final render)
			spl = col.split(align=True, factor=0.8)
			op = spl.operator("object.wplpff_save_compo", text = 'EXPORT TO CLIPBOARD', icon="RENDER_ANIMATION")
			op.opt_action = 'EXPORT'
			op.opt_renderSamples = 1
			op = spl.operator("object.wplpff_save_compo", text = 'ULTRA')
			op.opt_action = 'EXPORT'
			op.opt_renderSamples = 50
			#col.operator("object.wplpff_save_compo", text = 'SAVE FOR NEW LAYER', icon="THREE_DOTS").opt_action = 'NEWPLAIN'
		col.separator()
		if desc_active is not None:
			box = col.box()
			row = box.row()
			spl = row.split(align=True, factor=0.3)
			spl_col1 = spl.column()
			spl_col2 = spl.column()
			spl_col1.label( text = "Layer: ")
			spl_col2.label( text = active_obj.name)
			spl_col1.label( text = "Effect: ")
			spl_col2.label( text = desc_active["effect_name"])
			pff_col_nameIdx = 0
			for opt_key in desc_optkeys:
				opt_key_obj = config.kWPLSystemNodeTagPFF + opt_key
				if ( opt_key_obj in active_obj ) and ( opt_key in desc_active ):
					row = box.row()
					spl = row.split(align=True, factor=0.3)
					spl.column().label(text = desc_active[opt_key]["name"], translate=False)
					if "image" in desc_active[opt_key]["type"]:
						# just adding the name
						img_name = active_obj[opt_key_obj]
						spl_col = spl.column()
						spl_col.label(text = img_name)
						# searching for name without folder
						fname_safe = getProjFolderSafePathName(context, img_name)
						img = wla.sys_findImg(fname_safe, False)
						if img is not None:
							aspc = img.size[0]/img.size[1]
							spl_col.label(text = f"{img.size[0]}:{img.size[1]} {aspc:.2f}")
						continue
					# if "checkbox" in desc_active[opt_key]["type"]:
					# 	spl.column().prop(active_obj, f'["{opt_key_obj}"]', text = "", toggle=1)
					if "slider" in desc_active[opt_key]["type"]:
						spl.column().prop(active_obj, f'["{opt_key_obj}"]', text = "", slider=True)
					else:
						spl.column().prop(active_obj, f'["{opt_key_obj}"]', text = "")
					if "mask_framegrid" in desc_active[opt_key]["type"]:
						grid_size = getBaseFramesGrid(context)
						if (grid_size is not None) and (grid_size[0]+grid_size[1]) > 2:
							row = box.row()
							for i in range(0, int(max(grid_size[0],grid_size[1])) ):
								op = row.operator("object.wplpff_layer_alter", text = 'F'+str(i+1))
								op.opt_action = 'ALT_OPT_FRAMEGRID'
								op.opt_layerName = active_obj.name
								op.opt_optionName = opt_key
								op.opt_optionVal = str(i+1)
					if "gizmo_zdir" in desc_active[opt_key]["type"]:
						gizmo_empty = wla.find_child_by_name(active_obj, "gizmo_zdir")
						if gizmo_empty is not None:
							op = box.operator("object.wplpff_layer_alter", text = 'Switch to gizmo')
							op.opt_action = 'ALT_OPT_TOGIZMO'
							op.opt_layerName = active_obj.name
							op.opt_optionName = opt_key
							op.opt_optionVal = gizmo_empty.name
					if "gizmo_3dcUv" in desc_active[opt_key]["type"]:
						op = box.operator("object.wplpff_layer_alter", text = 'Fill from 3D Cursor')
						op.opt_action = 'ALT_OPT_3DCUV'
						op.opt_layerName = active_obj.name
						op.opt_optionName = opt_key
						op.opt_optionVal = ''
					if "color" in desc_active[opt_key]["type"]:
						col_name = kWPL_PFF_COLPROPRNAMES[pff_col_nameIdx]
						pff_col_nameIdx = pff_col_nameIdx+1
						row = box.row()
						spl = row.split(align=True, factor=0.8)
						spl.prop(wpl_pffOpts, col_name, text = "")
						# Additional button:
						# Generally not needed, auto-updated already
						# BUT color may differ from Object prop value AT START
						op = spl.operator("object.wplpff_layer_alter", text = 'Use')
						op.opt_action = 'ALT_OPT_COLOR'
						op.opt_layerName = active_obj.name
						op.opt_optionName = opt_key
						op.opt_optionVal = col_name
						hotobj = ops_scene_man.kWPLGKey_HT_Objects
						col_ht_key = ops_scene_man.kWPLGKey_HT_PropUpdate + active_obj.name + col_name
						if col_ht_key not in hotobj:
							hotobj[col_ht_key] = {}
							hotobj[col_ht_key]["object"] = active_obj.name
							hotobj[col_ht_key]["update"] = {}
						hotobj[col_ht_key]["pgroup"] = wpl_pffOpts
						hotobj[col_ht_key]["pgroup_prop"] = col_name
						hotobj[col_ht_key]["target_prop_name"] = opt_key
						hotobj[col_ht_key]["update"][col_name] = gizmo_color_update
			if "effect_helper_tools" in desc_active:
				if "stampp" in desc_active["effect_helper_tools"]:
					from . import ops_tool_stampp
					box = col.box()
					ops_tool_stampp.uilayout_stamppBox(box, context, True)
		col.separator()
		# add new layer 
		# - material to be used by grid
		# - 1-3 images (depending on material definition) to be set in material
		box = col.box()
		if wla.is_edit_mode():
			box.operator("mesh.wplsculpt_stepsubd", text="Subd +1", icon="MOD_PARTICLE_INSTANCE")
		else:
			box.prop(wpl_pffOpts, 'pff_matlist', text = 'Layer filter')
			desc_x, desc_x_optkeys = getMatEffectDescription(wpl_pffOpts.pff_matlist)
			if desc_x is not None:
				for opt_key in desc_x_optkeys:
					if (opt_key in desc_x) and ("image" in desc_x[opt_key]["type"]):
						propKey_key = (desc_x[opt_key]["type"]).replace("image","").replace(",","")
						box.prop(wpl_pffOpts, propKey_key, text = desc_x[opt_key]["name"])
				box.operator("object.wplpff_layer_add", text = "[ "+desc_x["effect_name"]+"] : Add Layer")
		if desc_active is not None:
			row1 = col.row()
			op = row1.operator("object.wplpff_save_compo", text = 'DO BATCH', icon="RENDER_ANIMATION")
			op.opt_action = 'BATCH32'
			op.opt_renderSamples = 1
			row1.prop(wpl_pffOpts, 'batch_folder', text = "From")

# ==========================================
# ==========================================
# ==========================================
# ==========================================

classes = (
	WPL_PFFOPTS,
	WPL_PT_PffPanel,

	wplpff_setup_proj,
	wplpff_save_compo,
	wplpff_layer_add,
	wplpff_layer_alter,
)

def register():
	for cls in classes:
		bpy.utils.register_class(cls)
	bpy.types.Scene.wpl_pffOpts = bpy.props.PointerProperty(type=WPL_PFFOPTS)

def unregister():
	for cls in reversed(classes):
		bpy.utils.unregister_class(cls)
	del bpy.types.Scene.wpl_pffOpts

if __name__ == "__main__":
	register()