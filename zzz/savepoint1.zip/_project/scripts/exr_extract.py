# coding=utf-8
# Extracts layers from Multi-layered EXR into set of PNG files
# With proper half/float and Linear->sRGB conversion
# Using oiiotool from OpenImageIO suite, without python bindings

#MAC
#python3 ~/Documents/zzz_CloudFiles/WPLabs19/_project/scripts/exr_extract.py /Users/ipv6/Documents/zzz_CloudFiles/Yandex.Disk.localized/_Renders/???/
#python3 ~/Documents/zzz_CloudFiles/WPLabs19/_project/scripts/exr_extract.py /Users/ipv6/Documents/zzz_tmp/???/
#python3 ~/Documents/zzz_CloudFiles/WPLabs19/_project/scripts/exr_extract.py /Users/ipv6/Downloads/???/

#WIN (windows strore python)
#python3 "c:\_WPLabs\BitBucket\wplabs-19\_project\scripts\exr_extract.py" c:\_WPLabs\YandexDisk\_Renders\???\
#python3 "c:\_WPLabs\BitBucket\wplabs-19\_project\scripts\exr_extract.py" c:\_WPLabs\Downloads\???\

# POSTPROCESSING
# UNUSED: python3 ~/Documents/zzz_CloudFiles/WPLabs19/_project/scripts/exr_extract.py /Users/ipv6/Documents/zzz_tmp/???/ --emihdr
# // --emihdr: extract с tiff на слои освещения

#MAC: Extract SVG from PNG
#https://github.com/visioncortex/vtracer
#~/Documents/zzz_tmp/vtracer-mac --input ~/Downloads/???.png --output ~/Downloads/traced.svg

import re
import os
import sys
import subprocess
import os.path

layer_ignored_toks = ["_qGOOD", "_qNORM", "_qULTRA", "_V", ".[V]", "(float)", "(half)"]

tool_opts_ruleset = [
	{"*.Noisy*": "skip"},{"*.IndexOB*": "skip"},{"*.Depth*": "skip"},{"RenderLayer*": "skip"},
	#{"_L2_*": "skip"},{"_L3_*": "skip"},{"_L4_*": "skip"}, # not needed separately

	{"zzz_final_color_step0.RGB": {"tif":False}},
	{"zzz_color_base_lu.RGB": {"tif":False}},
	{"zzz_color_base_sh.RGB": {"tif":False}},
	{"z_mask_zDecorC.RGB": {"tif":False}},
	{"z_mask_zIslands.RGB": {"tif":False}},
	{"z_mask_zObjects.RGB": {"tif":False}},
	{"z_mask_zMaterials.RGB": {"tif":False}},
	{"z_mask_map.RGB": {"tif":False}},
	{"zz_tex_col_edges2px.RGB": {"tif":False}},
	{"zz_tex_col_sysp.RGB": {"tif":False}},
	{"hdr_uvz_tex.RGB": {"tif":True}},
	{"hdr_uvz_tex_alt.RGB": {"tif":True}},
	{"hdr_nrm_wrl.RGB": {"tif":True}},
	{"hdr_nrm_flat.RGB": {"tif":True}},
	{"hdr_nrm_cam.RGB": {"tif":True}},
	{"hdr_xyz_cam.RGB": {"tif":True}},
	{"hdr_xyz_wrl.RGB": {"tif":True}},

	# =====

	{"sysLayers_Main.Combined.R": {"name":"emi_main_R", "renorm_clamped":(0.05,100.0), "tif":False}},
	{"sysLayers_Main.Combined.G": {"name":"emi_main_G", "renorm_clamped":(0.05,100.0), "tif":False}},
	{"sysLayers_Main.Combined.B": {"name":"emi_main_B", "renorm_clamped":(0.05,100.0), "tif":False}},
	{"sysLayers_Main_EmiA.Combined.R": {"name":"emi_A_R", "renorm_clamped":(0.05,100.0,"as_emission"), "tif":False}},
	{"sysLayers_Main_EmiA.Combined.G": {"name":"emi_A_G", "renorm_clamped":(0.05,100.0,"as_emission"), "tif":False}},
	{"sysLayers_Main_EmiA.Combined.B": {"name":"emi_A_B", "renorm_clamped":(0.05,100.0,"as_emission"), "tif":False}},
	{"sysLayers_Main_EmiB.Combined.R": {"name":"emi_B_R", "renorm_clamped":(0.05,100.0,"as_emission"), "tif":False}},
	{"sysLayers_Main_EmiB.Combined.G": {"name":"emi_B_G", "renorm_clamped":(0.05,100.0,"as_emission"), "tif":False}},
	{"sysLayers_Main_EmiB.Combined.B": {"name":"emi_B_B", "renorm_clamped":(0.05,100.0,"as_emission"), "tif":False}},
	{"sysLayers_Main_EmiC.Combined.R": {"name":"emi_C_R", "renorm_clamped":(0.05,100.0,"as_emission"), "tif":False}},
	{"sysLayers_Main_EmiC.Combined.G": {"name":"emi_C_G", "renorm_clamped":(0.05,100.0,"as_emission"), "tif":False}},
	{"sysLayers_Main_EmiC.Combined.B": {"name":"emi_C_B", "renorm_clamped":(0.05,100.0,"as_emission"), "tif":False}},

	# {"sysLayers_Main.Combined.R": {"name":"hdr_emi_main_R", "renorm_clamped":(0.01,100.0), "tif":True, "if": "--emihdr"}},
	# {"sysLayers_Main.Combined.G": {"name":"hdr_emi_main_G", "renorm_clamped":(0.01,100.0), "tif":True, "if": "--emihdr"}},
	# {"sysLayers_Main.Combined.B": {"name":"hdr_emi_main_B", "renorm_clamped":(0.01,100.0), "tif":True, "if": "--emihdr"}},
	# {"sysLayers_Main_EmiA.Combined.R": {"name":"hdr_emi_A_R", "renorm_clamped":(0.01,100.0), "tif":True, "if": "--emihdr"}},
	# {"sysLayers_Main_EmiA.Combined.G": {"name":"hdr_emi_A_G", "renorm_clamped":(0.01,100.0), "tif":True, "if": "--emihdr"}},
	# {"sysLayers_Main_EmiA.Combined.B": {"name":"hdr_emi_A_B", "renorm_clamped":(0.01,100.0), "tif":True, "if": "--emihdr"}},
	# {"sysLayers_Main_EmiB.Combined.R": {"name":"hdr_emi_B_R", "renorm_clamped":(0.01,100.0), "tif":True, "if": "--emihdr"}},
	# {"sysLayers_Main_EmiB.Combined.G": {"name":"hdr_emi_B_G", "renorm_clamped":(0.01,100.0), "tif":True, "if": "--emihdr"}},
	# {"sysLayers_Main_EmiB.Combined.B": {"name":"hdr_emi_B_B", "renorm_clamped":(0.01,100.0), "tif":True, "if": "--emihdr"}},
	# {"sysLayers_Main_EmiC.Combined.R": {"name":"hdr_emi_C_R", "renorm_clamped":(0.01,100.0), "tif":True, "if": "--emihdr"}},
	# {"sysLayers_Main_EmiC.Combined.G": {"name":"hdr_emi_C_G", "renorm_clamped":(0.01,100.0), "tif":True, "if": "--emihdr"}},
	# {"sysLayers_Main_EmiC.Combined.B": {"name":"hdr_emi_C_B", "renorm_clamped":(0.01,100.0), "tif":True, "if": "--emihdr"}},

	# {"sysLayersC.Combined.RGB": {"name":"emi_sysC", "tif":True}},
	{"sysLayersC.Combined.R": {"name":"emi_sysC_R", "tif":False, "renorm_clamped":(0.001,100.0,"as_emission")}},
	{"sysLayersC.Combined.G": {"name":"emi_sysC_G", "tif":False, "renorm_clamped":(0.001,100.0,"as_emission")}},
	{"sysLayersC.Combined.B": {"name":"emi_sysC_B", "tif":False, "renorm_clamped":(0.001,100.0,"as_emission")}},

	{"sysLayersF.DiffCol.RGB": {"name":"face_col_top", "tif":False}},
	{"sysLayersF.Emit.RGB": {"name":"face_col_btm", "tif":False}},
	{"sysLayersF.GlossCol.R": {"name":"face_grad1"}},
	{"sysLayersF.GlossCol.G": {"name":"face_grad2"}},
	{"sysLayersF.GlossCol.B": {"name":"face_grad_blooms"}},
	{"sysLayersF.TransCol.RGB": {"name":"face_mask_map"}},
	# {"sysLayersF.TransCol.R": {"name":"face_mask_full"}},
	# {"sysLayersF.TransCol.G": {"name":"face_mask_top"}},
	# {"sysLayersF.TransCol.B": {"name":"face_mask_btm"}},

	
	{"sysLayersP.TransCol.RGB": {"name":"hdr_nrm_cam", "tif":True}},
	{"sysLayersP.GlossCol.RGB": {"name":"z_tex_col_sysp", "tif":False}},
	{"sysLayersP.DiffCol.R": {"name":"z_tex1_r"}, "renorm_clamped":(0.0,1.0)},
	{"sysLayersP.DiffCol.G": {"name":"z_tex1_g"}, "renorm_clamped":(0.0,1.0)},
	{"sysLayersP.DiffCol.B": {"name":"z_tex1_b"}, "renorm_clamped":(0.0,1.0)},
	{"sysLayersP.Emit.R": {"name":"z_tex2_r"}, "renorm_clamped":(0.0,1.0)},
	{"sysLayersP.Emit.G": {"name":"z_tex2_g"}, "renorm_clamped":(0.0,1.0)},
	{"sysLayersP.Emit.B": {"name":"z_tex2_b"}, "renorm_clamped":(0.0,1.0)},

	# =====

	{"sysLayersT_FgFolds.Combined.R": {"name":"emi_fgFolds_R", "tif":False, "renorm_clamped":(0.001,100.0,"as_emission")}},
	{"sysLayersT_FgFolds.Combined.G": {"name":"emi_fgFolds_G", "tif":False, "renorm_clamped":(0.001,100.0,"as_emission")}},
	{"sysLayersT_FgFolds.Combined.B": {"name":"emi_fgFolds_B", "tif":False, "renorm_clamped":(0.001,100.0,"as_emission")}},

	{"sysLayersT_RefEmi.DiffCol.R": {"name":"emi_ref1_pntLN", "tif":False }},
	{"sysLayersT_RefEmi.DiffCol.G": {"name":"emi_ref1_pntSN", "tif":False }},
	{"sysLayersT_RefEmi.DiffCol.B": {"name":"emi_ref1_pntSV", "tif":False }},
	{"sysLayersT_RefEmi.GlossCol.R": {"name":"emi_ref3_pntLN", "tif":False }},
	{"sysLayersT_RefEmi.GlossCol.G": {"name":"emi_ref3_pntSN", "tif":False }},
	{"sysLayersT_RefEmi.GlossCol.B": {"name":"emi_ref3_pntSV", "tif":False }},
	{"sysLayersT_RefEmi.TransCol.R": {"name":"emi_sun_pntLN", "tif":False }},
	{"sysLayersT_RefEmi.TransCol.G": {"name":"emi_sun_pntSN", "tif":False }},
	{"sysLayersT_RefEmi.TransCol.B": {"name":"emi_sun_pntSV", "tif":False }},
	{"sysLayersT_RefEmi.Emit.R": {"name":"emi_ref2_pntLN", "tif":False }},
	{"sysLayersT_RefEmi.Emit.G": {"name":"emi_ref2_pntSN", "tif":False }},
	{"sysLayersT_RefEmi.Emit.B": {"name":"emi_ref2_pntSV", "tif":False }},

	# =====

	{"sysLayersT_BgReflect.DiffCol.RGB": {"name":"z_bg_refl_col", "tif":False}},
	{"sysLayersT_BgReflect.Emit.RGB": {"name":"hdr_uvz_bg_refl_sph", "tif":True}},
	{"sysLayersT_BgReflect.GlossCol.RGB": {"name":"hdr_uvz_bg_refl_cam", "tif":True}},
	{"sysLayersT_BgReflect.TransCol.RGB": {"name":"hdr_nrm_refl_cam", "tif":True}},
 
	{"sysLayersT_BgEdge.DiffCol.R": {"name":"z_bg_edge_fe_dc", "tif":False}},
	{"sysLayersT_BgEdge.DiffCol.G": {"name":"z_bg_edge_fe_cu", "tif":False}},
	{"sysLayersT_BgEdge.DiffCol.B": {"name":"z_bg_edge_fe_sp", "tif":False}},
	{"sysLayersT_BgEdge.GlossCol.R": {"name":"z_bg_edge_pp_front", "tif":False, "renorm_clamped":(0.0,100.0)}},
	{"sysLayersT_BgEdge.GlossCol.G": {"name":"z_bg_edge_pp_back", "tif":False, "renorm_clamped":(0.0,100.0)}},
	{"sysLayersT_BgEdge.GlossCol.B": {"name":"z_bg_edge_pp_area", "tif":False, "renorm_clamped":(0.0,1.0)}},
	{"sysLayersT_BgEdge.TransCol.R": {"name":"z_bg_edge_outl1_front", "tif":False, "renorm_clamped":(0.0,100.0)}},
	{"sysLayersT_BgEdge.TransCol.G": {"name":"z_bg_edge_outl2_front", "tif":False, "renorm_clamped":(0.0,100.0)}},
	{"sysLayersT_BgEdge.TransCol.B": {"name":"z_bg_edge_outl3_front", "tif":False, "renorm_clamped":(0.0,100.0)}},
	{"sysLayersT_BgEdge.Emit.R": {"name":"z_bg_edge_bvl_smooth", "tif":False}},
	{"sysLayersT_BgEdge.Emit.G": {"name":"z_bg_edge_fe_thick", "tif":False}},
	{"sysLayersT_BgEdge.Emit.B": {"name":"z_bg_edge_bvl_ao", "tif":False}},

	{"sysLayersT_DecCrystal.DiffCol.R": {"name":"dec_crystal_DC_R", "tif":False, "renorm_clamped":(0.0,1.0)}},
	{"sysLayersT_DecCrystal.DiffCol.G": {"name":"dec_crystal_DC_G", "tif":False, "renorm_clamped":(0.0,1.0)}},
	{"sysLayersT_DecCrystal.DiffCol.B": {"name":"dec_crystal_DC_B", "tif":False, "renorm_clamped":(0.0,1.0)}},
	{"sysLayersT_DecCrystal.GlossCol.R": {"name":"dec_crystal_GC_R", "tif":False, "renorm_clamped":(0.0,1.0)}},
	{"sysLayersT_DecCrystal.GlossCol.G": {"name":"dec_crystal_GC_G", "tif":False, "renorm_clamped":(0.0,1.0)}},
	{"sysLayersT_DecCrystal.GlossCol.B": {"name":"dec_crystal_GC_B", "tif":False, "renorm_clamped":(0.0,1.0)}},
	{"sysLayersT_DecCrystal.TransCol.R": {"name":"dec_crystal_TC_R", "tif":False, "renorm_clamped":(0.0,1.0)}},
	{"sysLayersT_DecCrystal.TransCol.G": {"name":"dec_crystal_TC_G", "tif":False, "renorm_clamped":(0.0,1.0)}},
	{"sysLayersT_DecCrystal.TransCol.B": {"name":"dec_crystal_TC_B", "tif":False, "renorm_clamped":(0.0,1.0)}},
	{"sysLayersT_DecCrystal.Emit.R": {"name":"dec_crystal_EC_R", "tif":False, "renorm_clamped":(0.0,1.0)}},
	{"sysLayersT_DecCrystal.Emit.G": {"name":"dec_crystal_EC_G", "tif":False, "renorm_clamped":(0.0,1.0)}},
	{"sysLayersT_DecCrystal.Emit.B": {"name":"dec_crystal_EC_B", "tif":False, "renorm_clamped":(0.0,1.0)}},

	{"sysLayersT_DecAmber.DiffCol.R": {"name":"dec_amber_DC_R", "tif":False, "renorm_clamped":(0.0,1.0)}},
	{"sysLayersT_DecAmber.DiffCol.G": {"name":"dec_amber_DC_G", "tif":False, "renorm_clamped":(0.0,1.0)}},
	{"sysLayersT_DecAmber.DiffCol.B": {"name":"dec_amber_DC_B", "tif":False, "renorm_clamped":(0.0,1.0)}},
	{"sysLayersT_DecAmber.GlossCol.R": {"name":"dec_amber_GC_R", "tif":False, "renorm_clamped":(0.0,1.0)}},
	{"sysLayersT_DecAmber.GlossCol.G": {"name":"dec_amber_GC_G", "tif":False, "renorm_clamped":(0.0,1.0)}},
	{"sysLayersT_DecAmber.GlossCol.B": {"name":"dec_amber_GC_B", "tif":False, "renorm_clamped":(0.0,1.0)}},
	{"sysLayersT_DecAmber.TransCol.R": {"name":"dec_amber_TC_R", "tif":False, "renorm_clamped":(0.0,1.0)}},
	{"sysLayersT_DecAmber.TransCol.G": {"name":"dec_amber_TC_G", "tif":False, "renorm_clamped":(0.0,1.0)}},
	{"sysLayersT_DecAmber.TransCol.B": {"name":"dec_amber_TC_B", "tif":False, "renorm_clamped":(0.0,1.0)}},
	{"sysLayersT_DecAmber.Emit.R": {"name":"dec_amber_EC_R", "tif":False, "renorm_clamped":(0.0,1.0)}},
	{"sysLayersT_DecAmber.Emit.G": {"name":"dec_amber_EC_G", "tif":False, "renorm_clamped":(0.0,1.0)}},
	{"sysLayersT_DecAmber.Emit.B": {"name":"dec_amber_EC_B", "tif":False, "renorm_clamped":(0.0,1.0)}},

	{"sysLayersT_DecLines.DiffCol.R": {"name":"dec_lines_DC_R", "tif":False, "renorm_clamped":(0.0,1.0)}},
	{"sysLayersT_DecLines.DiffCol.G": {"name":"dec_lines_DC_G", "tif":False, "renorm_clamped":(0.0,1.0)}},
	{"sysLayersT_DecLines.DiffCol.B": {"name":"dec_lines_DC_B", "tif":False, "renorm_clamped":(0.0,1.0)}},
	{"sysLayersT_DecLines.GlossCol.R": {"name":"dec_lines_GC_R", "tif":False, "renorm_clamped":(0.0,1.0)}},
	{"sysLayersT_DecLines.GlossCol.G": {"name":"dec_lines_GC_G", "tif":False, "renorm_clamped":(0.0,1.0)}},
	{"sysLayersT_DecLines.GlossCol.B": {"name":"dec_lines_GC_B", "tif":False, "renorm_clamped":(0.0,1.0)}},
	{"sysLayersT_DecLines.TransCol.R": {"name":"dec_lines_TC_R", "tif":False, "renorm_clamped":(0.0,1.0)}},
	{"sysLayersT_DecLines.TransCol.G": {"name":"dec_lines_TC_G", "tif":False, "renorm_clamped":(0.0,1.0)}},
	{"sysLayersT_DecLines.TransCol.B": {"name":"dec_lines_TC_B", "tif":False, "renorm_clamped":(0.0,1.0)}},
	{"sysLayersT_DecLines.Emit.R": {"name":"dec_lines_EC_R", "tif":False, "renorm_clamped":(0.0,1.0)}},
	{"sysLayersT_DecLines.Emit.G": {"name":"dec_lines_EC_G", "tif":False, "renorm_clamped":(0.0,1.0)}},
	{"sysLayersT_DecLines.Emit.B": {"name":"dec_lines_EC_B", "tif":False, "renorm_clamped":(0.0,1.0)}},

	# =====

	{"sysLayersT_RefGlossUV.DiffCol.RGB": {"name":"hdr_uvz_gloss_ref1", "tif":True}},
	{"sysLayersT_RefGlossUV.Emit.RGB": {"name":"hdr_uvz_gloss_ref2", "tif":True}},
	{"sysLayersT_RefGlossUV.GlossCol.RGB": {"name":"hdr_uvz_gloss_ref3", "tif":True}},
	{"sysLayersT_RefGlossUV.TransCol.RGB": {"name":"hdr_uvz_gloss_sun", "tif":True}},

	{"sysLayersT_RefSheenUV.DiffCol.RGB": {"name":"hdr_uvz_sheen_ref1", "tif":True}},
	{"sysLayersT_RefSheenUV.Emit.RGB": {"name":"hdr_uvz_sheen_ref2", "tif":True}},
	{"sysLayersT_RefSheenUV.GlossCol.RGB": {"name":"hdr_uvz_sheen_ref3", "tif":True}},
	{"sysLayersT_RefSheenUV.TransCol.RGB": {"name":"hdr_uvz_sheen_sun", "tif":True}},

	{"sysLayersT_RefAreaUV.DiffCol.RGB": {"name":"hdr_uvz_area_ref1", "tif":True}},
	{"sysLayersT_RefAreaUV.Emit.RGB": {"name":"hdr_uvz_area_ref2", "tif":True}},
	{"sysLayersT_RefAreaUV.GlossCol.RGB": {"name":"hdr_uvz_area_ref3", "tif":True}},
	{"sysLayersT_RefAreaUV.TransCol.RGB": {"name":"hdr_uvz_area_sun", "tif":True}},

	# =====

	# if nothing matched - skipping definitly internal layers
	{"sysLayers_Main*": "skip"},{"*.Combined*": "skip"},{"*.Normal*": "skip"},
	{"sysLayersC*": "skip"},{"sysLayersT_FgFolds*": "skip"},
	{"sysLayersA*": "skip"},{"sysLayersB*": "skip"},{"sysLayersD*": "skip"},
	{"sysLayersE*": "skip"},{"sysLayersM*": "skip"},
	{"sysLayersF*": "skip"},
]

tool_opts_extra = []
tool_input_opts = []
for i in range(len(sys.argv)):
	argvval = sys.argv[i]
	if "--" in argvval:
		tool_opts_extra.append(argvval)
	else:
		tool_input_opts.append(argvval)

if len(tool_input_opts) < 2:
	print('Need path to folder with EXR files, quitting')
	sys.exit(0)

def setupOiioTool():
	# https://people.cs.clemson.edu/~dhouse/courses/404/papers/openimageio.pdf
	tool_setups = [
		# MAC: brew https://github.com/OpenImageIO/oiio/blob/master/INSTALL.md
		# brew install openexr; brew install openimageio
		("/usr/local/bin/oiiotool",""),
		# Windows: v2: vcpkg-compiled tools. 64-version required
		# cd c:\_WPLabs\Programs\vcpkg\; .\vcpkg search openimageio; .\vcpkg install openimageio[webp,ffmpeg,gif,opencolorio,openjpeg,tools] --triplet=x64-windows
		# - Upgrade oiiotool: .\vcpkg upgrade
		# - BL 3.0, BL 3.1: needs proper config.ocio (can be found inside Blender installation folder)
		# // returncode=3221226505 -> Wrong Blender path, config.ocio not found. config.ocio must be valid
		# - BL 3.2: not working with config.ocio - subprocess return no data
		("c:\\_WPLabs\\Programs\\vcpkg\\installed\\x64-windows\\tools\\openimageio\\oiiotool.exe", ""), # "c:\\_WPLabs\\Programs\\blender320\\3.2\\datafiles\\colormanagement\\config.ocio"),
	]
	oiio_exe = "???"
	ocio_conf = "???"
	for stp in tool_setups:
		#print('- Oiiotool path:', stp[0])
		if os.path.exists(stp[0]):
			oiio_exe = stp[0]
			ocio_conf = stp[1]
			break
	print('- Oiiotool path:', oiio_exe)
	if not os.path.exists(oiio_exe):
		print('Invalid path to oiiotool, quitting')
		sys.exit(0)
	oiio_env = os.environ.copy()
	if len(ocio_conf) > 0:
		print('- Ocio_conf path:', ocio_conf)
		oiio_env["OCIO"] = ocio_conf
	return oiio_exe, oiio_env
oiio_exe, oiio_env = setupOiioTool()

#####################################
exr_folder = tool_input_opts[1]
print('- Folder:', exr_folder)
if not os.path.exists(exr_folder):
	print('Invalid folder, quitting')
	sys.exit(0)

stats = {}
stats["filesSaved"] = 0
def safeStr1(outname,lwr):
	outname = outname.replace(".","_")
	outname = outname.replace("+","_")
	outname = outname.replace("/","_")
	outname = outname.replace("\\","_")
	outname = outname.replace("\"","_")
	outname = outname.replace("'","_")
	if lwr:
		outname = outname.lower()
	return outname

def safeStr4FS(outname):
	outname = safeStr1(outname, False)
	outname = outname.replace("_jpeg","")
	outname = outname.replace("_tiff","")
	outname = outname.replace("_png","")
	outname = outname.replace("_jpg","")
	outname = outname.replace("_tif","")
	outname = outname.replace("_bw","")
	outname = outname.replace(" ","")
	outname = safeStr2(outname)
	return outname

def safeStr2(outname):
	for tk in layer_ignored_toks:
		outname = outname.replace(tk,"")
	outname = outname.strip()
	return outname

def safeStr3(outname):
	if outname.lower().endswith('.r'):
		outname = outname[:-2]
	if outname.lower().endswith('.g'):
		outname = outname[:-2]
	if outname.lower().endswith('.b'):
		outname = outname[:-2]
	if outname.lower().endswith('.a'):
		outname = outname[:-2]
	if outname.lower().endswith('.z'):
		outname = outname[:-2]
	if outname.lower().endswith('.v'):
		outname = outname[:-2]
	if outname.lower().endswith('.rgb'):
		outname = outname[:-4]
	return outname

def isStrTokenPresent(teststr, tokens):
	isPresent = False
	for bwmark in tokens:
		if safeStr1(bwmark, True) in safeStr1(teststr, True):
			isPresent = True
			break
	return isPresent

def ruleSet4Name(layerName):
	layerOpts = None
	for rulePack in tool_opts_ruleset:
		rule = list(rulePack.keys())[0]
		ruleval = rulePack[rule]
		if "if" in ruleval:
			if ruleval["if"] not in tool_opts_extra:
				# ignored
				continue
		if "ifnot" in ruleval:
			if ruleval["ifnot"] in tool_opts_extra:
				# ignored
				continue
		isMatch = False
		if layerName == rule:
			isMatch = True
		elif ("*" in rule):
			ruleKey = rule.replace("*","")
			# if "replace_key_token" in ruleval:
			# 	layerName = layerName.replace(ruleKey, ruleval["replace_key_token"])
			# 	# looking futher!
			# 	continue
			if (ruleKey.lower() in layerName.lower()):
				isMatch = True
		if isMatch:
			layerOpts = ruleval
			break
	if (layerOpts is not None) and isinstance(layerOpts, str):
		layerOpts = {str(layerOpts): True}
	return layerOpts

def layerExportName(layerName):
	#print("> skip?", layerName)
	layerName = safeStr2(layerName)
	if layerName.lower().endswith('.a'):
		# separate alpha channels not needed
		#print("> skip0", layerName)
		return None, None, None
	isFullLayer = False
	if layerName.lower().endswith('.rgb'):
		isFullLayer = True
	layerOpts = ruleSet4Name(layerName)
	if layerOpts is None and isFullLayer == False:
		# checking .RGB opt, skip channel if present
		fullLayerOpts = ruleSet4Name(safeStr3(layerName)+".RGB")
		if fullLayerOpts is not None:
			#print("> skip1", layerName)
			return None, None, None
	if layerOpts is None and isFullLayer == True:
		# full layers skipped, if no opts provided
		# only channels generated by default
		# layerOptsR = ruleSet4Name(safeStr3(layerName)+".R")
		# layerOptsG = ruleSet4Name(safeStr3(layerName)+".G")
		# layerOptsB = ruleSet4Name(safeStr3(layerName)+".B")
		# if (layerOptsR is None) and (layerOptsG is None) and (layerOptsB is None):
		#print("> skip2", layerName)
		return None, None, None
	outname = safeStr3(layerName)	
	outnameExt = ".png"
	if (layerOpts is not None):
		if ("skip" in layerOpts) and (layerOpts["skip"] == True):
			#print("> skip3", layerName, layerOpts)
			return None, None, None
		if ("tif" in layerOpts) and (layerOpts["tif"] == True):
			outnameExt = ".tif"
		if ("name" in layerOpts):
			outname = layerOpts["name"]
	if (layerOpts is None) and isFullLayer == False:
		# channel name should be in file name too...
		if layerName.lower().endswith('.r'):
			outname = outname+"_R"
		if layerName.lower().endswith('.g'):
			outname = outname+"_G"
		if layerName.lower().endswith('.b'):
			outname = outname+"_B"
	outname_full = safeStr4FS(outname)+outnameExt
	#print("> opts", layerName, outname_full)
	return outname, outname_full, layerOpts

def extractFile(exr_file, exr_output_folder):
	#print('- EXR to parse:', exr_file)
	#print("-- output:", exr_output_folder)
	if not os.path.exists(exr_file):
		print('Invalid path to EXR, quitting', exr_file)
		return
	print('')
	print('- EXR: Getting layers info...', exr_file)
	exrlayers = []
	oiio_call0 = []
	oiio_call0.append(oiio_exe)
	oiio_call0.append("--info")
	oiio_call0.append("-v")
	oiio_call0.append(exr_file)
	# print("// cmd: ", oiio_call0)
	stdres = subprocess.run(oiio_call0, capture_output = True, shell=False, env=oiio_env)
	exrinfo_layers = stdres.stdout.splitlines()

	oiio_call0 = []
	oiio_call0.append(oiio_exe)
	oiio_call0.append("--stats")
	oiio_call0.append(exr_file)
	# print("// cmd: ", oiio_call0)
	stdres = subprocess.run(oiio_call0, capture_output = True, shell=False, env=oiio_env)
	exrinfo_stats = stdres.stdout.splitlines()
	exrinfo_layers.extend(exrinfo_stats)
	# print("// output: ", exrinfo_layers)

	perChannel_Max = {}
	perChannel_Min = {}
	for exril in exrinfo_layers:
		exrinfoline = str(exril)
		if exrinfoline.find("channel list:") >= 0:
			headr_content = exrinfoline.split(':')
			headr_list = headr_content[1]
			headr_list = headr_list.replace("'", "")
			exrlayers = [x.strip() for x in headr_list.split(',')]
			break
	for exril in exrinfo_layers:
		exrinfoline = str(exril)
		if exrinfoline.find("Stats Min:") >= 0:
			headr_content = exrinfoline.split(':')
			headr_list = headr_content[1].replace("'", "")
			headr_list = safeStr2(headr_list)
			mins_list = [float(x.strip()) for x in headr_list.split(' ')]
			for i, ll in enumerate(exrlayers):
				perChannel_Min[safeStr2(ll)] = mins_list[i]
		if exrinfoline.find("Stats Max:") >= 0:
			headr_content = exrinfoline.split(':')
			headr_list = headr_content[1].replace("'", "")
			headr_list = safeStr2(headr_list)
			maxs_list = [float(x.strip()) for x in headr_list.split(' ')]
			for i, ll in enumerate(exrlayers):
				perChannel_Max[safeStr2(ll)] = maxs_list[i]
	if len(exrlayers) == 0:
		print('No layers found, quitting')
		return
	print("perChannel_Min", perChannel_Min)
	print("perChannel_Max", perChannel_Max)
	# some layers has A, some not. Putting it back.
	# First channel of all layers should be R
	exrlayers.sort(key=lambda str: str.replace(".R",".01").replace(".G",".02").replace(".B",".03").replace(".A",".04").replace(".V",".04"))
	print('- Layers found:', exrlayers)
	exrname = os.path.basename(exr_file)
	exrname = os.path.splitext(exrname)[0]

	def get_renorm4layer(layrName, layr_opts):
		renorm_steps = []
		layrName = safeStr2(layrName)
		renorm_int = (0.0, 1.0)
		if "renorm_clamped" in layr_opts:
			renorm_int = layr_opts["renorm_clamped"]
		lmin = 0.0
		if layrName in perChannel_Min:
			lmin = perChannel_Min[layrName]
		else:
			print("// renorm: no min", layrName)
		lmax = 0.0
		if layrName in perChannel_Max:
			lmax = perChannel_Max[layrName]
		else:
			print("// renorm: no max", layrName)
		if abs(lmax-lmin) < 0.05:
			renorm_steps.append( "--clamp:min=0:max=0" )
			renorm_steps.extend( ["--ch", "R=R,G=G,B=B,A=1.0"] )
			print("// renorm: blacking out, no diff", lmin, lmax)
			return renorm_steps
		# if len(renorm_int) >= 3 and ("as_emission" in renorm_int[2]):
		# 	# as_emission: removing most overbrighten zones
		# 	# but lesser values -> ok to fall into remapping
		# 	if lmax > 1.0:
		# 		if lmax*0.5 > 1.0:
		# 			lmax = lmax*0.5
		lmin_fin = max(lmin, renorm_int[0])
		lmax_fin = min(lmax, renorm_int[1])
		#renorm_steps.append( "--clamp:min="+str.format("{:.2f}", lmin_fin)+":max="+str.format("{:.2f}", lmax_fin) )
		if len(renorm_int) >= 3 and ("as_emission" in renorm_int[2]) and lmax_fin > 1.01:
			renorm_steps.append( "--contrast:black="+str.format("{:.2f}", lmin_fin)+":white="+str.format("{:.2f}", lmax_fin)+":min=0.0:max=1.0:clamp=0" )
			renorm_steps.append( "--contrast:scontrast=5" )
		else:
			renorm_steps.append( "--contrast:black="+str.format("{:.2f}", lmin_fin)+":white="+str.format("{:.2f}", lmax_fin)+":min=0.0:max=1.0:clamp=1" )
		renorm_steps.extend( ["--ch", "R=R,G=G,B=B,A=1.0"] ) # Alpha also renormed! Refilling with 1.0
		#print("// renorm: DBG:", perChannel_Min[layrName], perChannel_Max[layrName], renorm_steps)
		#print("// renorm: DBG:", lmin, lmax, lmin_fin, lmax_fin, renorm_int)
		return renorm_steps

	def dump_layers_stack(stk, stkfrm):
		if len(stk) == 0:
			return
		outname1, outname1_full, outname1_opts = layerExportName(safeStr3(stk[0])+".RGB")
		if (outname1 is None) or (outname1_full is None):
			return
		stats["filesSaved"] = stats["filesSaved"]+1
		if os.path.isfile(os.path.join(exr_output_folder,outname1_full)):
			print("- "+str(stats["filesSaved"])+". RGB: ", outname1, "skipped, already exists", stk)
			return
		print("- "+str(stats["filesSaved"])+". RGB: ", outname1 , stk)
		stkfrm = stkfrm.replace("(","").replace(")","").replace(" ","")
		# for tiff all channels should be present, even alpha=1.0
		while len(stk)<4:
			stk.append("1.0")
		oiio_call = []
		oiio_call.append(oiio_exe)
		oiio_call.append(exr_file)
		oiio_call.append("--no-autopremult") # or semitransparent will be overdarkened
		oiio_call.extend( ["--ch", "R="+stk[0]+",G="+stk[1]+",B="+stk[2]+",A="+stk[3]] )
		oiio_call.extend( ["-d", stkfrm] )
		# if tool_opts_scale != 100:
		# 	oiio_call.extend( ["--resize", str(tool_opts_scale)+"%"] )
		if ".png" in outname1_full:
			oiio_call.extend( ["--tocolorspace", "sRGB"] )
		# output file
		#print("-- DBG: command line:",oiio_call)
		oiio_call.extend( ["-o", os.path.join(exr_output_folder,outname1_full)] )
		ps1 = subprocess.Popen(oiio_call, stdin = subprocess.PIPE, stdout = subprocess.PIPE, env=oiio_env)
		(stdout, stderr) = ps1.communicate()
		#print("-- DBG: result:", stdout, stderr)
		return

	def dump_layer_chann(layr, stkfrm):
		outname2, outname2_full, outname2_opts = layerExportName(layr)
		if (outname2 is None) or (outname2_full is None):
			return
		stats["filesSaved"] = stats["filesSaved"]+1
		if os.path.isfile(os.path.join(exr_output_folder,outname2_full)):
			print("- "+str(stats["filesSaved"])+". BW: ", outname2, "skipped, already exists")
			return
		print("- "+str(stats["filesSaved"])+". BW: ", outname2)
		stkfrm = stkfrm.replace("(","").replace(")","").replace(" ","")
		oiio_call = []
		oiio_call.append(oiio_exe)
		oiio_call.append(exr_file)
		# adding R,G,B,A=1.0 -> compose rely on it
		oiio_call.extend( ["--ch", "R="+layr+",G="+layr+",B="+layr+",A=1.0"] )
		oiio_call.extend( ["-d",stkfrm] )
		if outname2_opts is not None and "renorm_clamped" in outname2_opts:
			renorm_step = get_renorm4layer(layr, outname2_opts)
			oiio_call.extend(renorm_step)
		# output format
		if ".png" in outname2_full:
			oiio_call.extend( ["--tocolorspace", "sRGB"] )
		# output file
		oiio_call.extend( ["-o", os.path.join(exr_output_folder,outname2_full)] )
		#print("-- DBG: command line:",oiio_call)
		ps2 = subprocess.Popen(oiio_call, stdin = subprocess.PIPE, stdout = subprocess.PIPE, env=oiio_env)
		(stdout, stderr) = ps2.communicate()
		#print("-- DBG: result:", stdout, stderr)
		return

	curr_format = "half"
	curr_chstack = []
	for layername in exrlayers:
		name_type_pair = layername.split(' ')
		if len(name_type_pair) > 0:
			layerName = name_type_pair[0]
			if len(name_type_pair) > 1:
				layerFrmt = name_type_pair[1]
			else:
				layerFrmt = "(half)"
			# needSkip = isStrTokenPresent(layerName, tool_opts_skip)
			# if needSkip == False:
			layerNameL = layerName.lower()
			if layerNameL.find(".z") >= 0:
				# depth-only
				dump_layer_chann(layerName, layerFrmt)
				continue
			if layerNameL.find(".r") >= 0:
				# flushing previous layer
				dump_layers_stack(curr_chstack, curr_format)
				# setting new layer up
				curr_chstack = []
				curr_format = layerFrmt
			if layerNameL.find(".r") >= 0 or layerNameL.find(".g") >= 0 or layerNameL.find(".b") >= 0 or layerNameL.find(".a") >= 0:
				curr_chstack.append(layerName)
			dump_layer_chann(layerName, layerFrmt)
			# if layerNameL.find(".v") >= 0:
			# 	dump_layer_chann(layerName, layerFrmt)
			# else:
			# 	layerFileName = safeStr4FS(layerName)
			# 	isLayerDumpable = isStrTokenPresent(layerName, tool_opts_bw)
			# 	if isNegStrTokenPresent(layerFileName, tool_opts_bw):
			# 		# skipping partial layer
			# 		print("-", layerName, "partial, skipped")
			# 		isLayerDumpable = False
			# 	if isLayerDumpable:
			# 		dump_layer_chann(layerName, layerFrmt)
			# else:
			# 	print("-", layerName, "ignored")
	dump_layers_stack(curr_chstack, curr_format)
	curr_chstack = []

exr_files = os.listdir(exr_folder)
exr_files.sort()
#print("- EXRs found", exr_files)
for fl in exr_files:
	if ".exr" not in fl:
		continue
	fl_path_name = os.path.splitext(fl)[0]
	fl_out_dir = os.path.join(exr_folder,fl_path_name)
	if not os.path.exists(fl_out_dir):
		os.makedirs(fl_out_dir)
	extractFile(exr_folder+fl, fl_out_dir)

print("- All done")