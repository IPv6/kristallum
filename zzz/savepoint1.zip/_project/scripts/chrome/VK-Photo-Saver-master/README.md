VK Photo Saver
==============

Google Chrome extension for uploading images (and making screenshots) from web to VK.
