#!/usr/bin/env python
# -*- coding: utf-8 -*-

# MacOs: 
# - script must be executable! chmod +x *.py
# - script path must be in PLUGINS dirs
# /Applications/Gimp-2.10.app/Contents/MacOS/gimp --verbose;
# cd /Applications/GIMP-2.10.app/Contents/MacOS; ./gimp &

# Win debug:
# cd "C:\Program Files\GIMP 2\bin"
# gimp-2.10.exe --verbose --console-messages
# GIMP не должен менять цветовое пространство при открытии!!!

print '************************* char_export_gimp.py loading *************************'

from gimpfu import *
import json
import math
import sys
import os
import codecs
import datetime

# CharDesk: emotions will be created automatically for all poses! <EmoName><PoseString>
# PSD height must be < 2048!
exportMaxHeight = 2030 #2048 texture problem;// 1920->1366
exportDebug = False
tagAll = ("*", "all")

def ensure_dir(directory):
    #directory = os.path.dirname(file_path)
    if not os.path.exists(directory):
        os.makedirs(directory)

def chardesc_target_dir(char_desc):
    exports_tag = char_desc["actor_tag"]
    exportTarget = char_desc["exportTarget"]
    exportToTmp = exportTarget+exports_tag+datetime.datetime.today().strftime('%y%m%d')
    ensure_dir(exportToTmp)
    print "- target path:", exportToTmp
    return exportToTmp

def enum_all_layers(root_group, all_layers):
    for layer in root_group.layers:
        all_layers.append(layer)
        if isinstance(layer, gimp.GroupLayer):
            all_layers.append(layer)
            enum_all_layers(layer, all_layers)
    return

def isSameName(layerName, name):
    if layerName == name:
        return True
    if layerName.startswith(name+" #"):
        return True
    return False

def hideSublayers(psd_doc, rootLayer):
    #print("- hideSublayers:", rootLayer.name, rootLayer)
    if rootLayer is None:
        return
    if isinstance(rootLayer, gimp.GroupLayer) or isinstance(rootLayer, gimp.Layer):
        rootLayer.visible = False
    if isinstance(rootLayer, gimp.GroupLayer) or isinstance(rootLayer, gimp.Image):
        for layer in rootLayer.layers:
            layer.visible = False
            hideSublayers(psd_doc, layer)

def resetSublayersToImage(psd_doc, rootLayer):
    if rootLayer is None:
        return
    if isinstance(rootLayer, gimp.GroupLayer) or isinstance(rootLayer, gimp.Layer):
        #pdb.gimp_image_set_active_layer(psd_doc, rootLayer)
        pdb.gimp_layer_resize_to_image_size(rootLayer)
    if isinstance(rootLayer, gimp.GroupLayer) or isinstance(rootLayer, gimp.Image):
        for layer in rootLayer.layers:
            resetSublayersToImage(psd_doc, layer)

def findSublayerByName(rootLayer, name):
    if name is None or len(name) == 0:
        return None
    #print("- findSublayerByName:",rootLayer.name, name)
    if rootLayer is None:
        return None
    if isinstance(rootLayer, gimp.GroupLayer) or isinstance(rootLayer, gimp.Layer):
        if isSameName(rootLayer.name, name):
            return rootLayer
    if isinstance(rootLayer, gimp.GroupLayer) or isinstance(rootLayer, gimp.Image):
        for layer in rootLayer.layers:
            if isSameName(layer.name, name):
                return layer
            if isinstance(layer, gimp.GroupLayer):
                for sub in layer.layers:
                    isInSub = findSublayerByName(sub, name)
                    if isInSub is not None:
                        return isInSub
    return None

def showLayer(layer):
    if isinstance(layer, gimp.GroupLayer) or isinstance(layer, gimp.Layer):
        layer.visible = True
    parent = layer.parent
    if parent is not None:
        showLayer(parent)

def getLayerBounds(layer):
    bnd = {}
    bnd["x"] = float(int(layer.offsets[0]))
    bnd["y"] = float(int(layer.offsets[1]))
    bnd["width"] = float(int(layer.width))
    bnd["height"] = float(int(layer.height))
    #print("getLayerBounds", layer, bnd)
    return bnd

# ================= ================== =============== =============== ===============

def makeCharDescription(char_desc):
    exports_tag = char_desc["actor_tag"]
    exports = char_desc["exports"]
    exportToTmp = chardesc_target_dir(char_desc)
    all_poses = []
    all_dress = []
    all_emos = []
    for exp_line in exports:
        line_t = exp_line[0]
        if line_t not in char_desc:
            print("- makeCharDescription: export type not found: "+line_t)
            return
        exp = char_desc[line_t]
        if exp["dress"] not in tagAll and exp["dress"] not in all_dress:
            all_dress.append(exp["dress"])
        if exp["pose"] not in tagAll and exp["pose"] not in all_poses:
            all_poses.append(exp["pose"])
        if exp["type"] == "em":
            if exp_line[4] not in all_emos:
                all_emos.append(exp_line[4])
    if len(all_emos) == 0 or len(all_poses) == 0 or len(all_dress) == 0:
        print("- makeCharDescription: char defn skipped: not enough data", all_dress, all_poses, all_emos)
        return
    print("- makeCharDescription: char defn:", all_dress, all_poses, all_emos)
    json_cnt = "{\"vn_chars:"+exports_tag+"\":{" # tag root
    for dress in all_dress:
        if json_cnt.endswith('}'):
            json_cnt = json_cnt + ","
        mood_id_defl = all_emos[0]+all_poses[0]
        json_cnt = json_cnt + "\n\t\""+exports_tag+"_dress"+dress+"\": {" # tag dress
        json_cnt = json_cnt + "\n\t\t\"actor_tag\":\""+exports_tag+"\","
        #json_cnt = json_cnt + "\n\t\t\"actor_nick\":\""+char_desc["actor_nick"]+"\"," # not used, Localizaed separately
        json_cnt = json_cnt + "\n\t\t\"mood_def\":\""+mood_id_defl+"\","
        json_cnt = json_cnt + "\n\t\t\"moods\": {" # tag moods
        for pose in all_poses:
            for emo in all_emos:
                if json_cnt.endswith('}'):
                    json_cnt = json_cnt + ","
                mood_id = emo+pose
                json_cnt = json_cnt + "\n\t\t\t\""+mood_id+"\":{"
                for exp_line in exports:
                    exp = char_desc[exp_line[0]]
                    if exp["type"] == "av" and exp_line[4] == emo:
                        if (exp["dress"] == dress or exp["dress"] in tagAll) and (exp["pose"] == pose or exp["pose"] in tagAll):
                            json_cnt = json_cnt + "\"slot_avt\":\"%("+exp_line[1]+")\","
                            break
                for exp_line in exports:
                    exp = char_desc[exp_line[0]]
                    if exp["type"] == "em" and exp_line[4] == emo:
                        if (exp["dress"] == dress or exp["dress"] in tagAll) and (exp["pose"] == pose or exp["pose"] in tagAll):
                            json_cnt = json_cnt + "\"slot_emo\":\"%("+exp_line[1]+")\","
                            break
                for exp_line in exports:
                    exp = char_desc[exp_line[0]]
                    if exp["type"] == "bd":
                        if (exp["dress"] == dress or exp["dress"] in tagAll) and (exp["pose"] == pose or exp["pose"] in tagAll):
                            json_cnt = json_cnt + "\"slot_dress\":\"%("+exp_line[1]+")\""
                            break
                json_cnt = json_cnt + "}"
        json_cnt = json_cnt + "\n\t\t}" # tag moods
        if "inject_dress" in char_desc:
            # special code for each dress
            inject_obj = char_desc["inject_dress"]
            for inject_dress_key in inject_obj:
                json_cnt = json_cnt + ",\n\t\t"
                json_cnt = json_cnt + "\"" + inject_dress_key + "\"" + ": " + json.dumps(inject_obj[inject_dress_key], sort_keys=True, indent=4)
        json_cnt = json_cnt + "\n\t}" # tag dress
    json_cnt = json_cnt + "\n}}" # tag root
    #json_file = codecs.open(exportToTmp+"/"+exports_tag+"_char.json", "w", "utf-8-sig")
    output_file = exportToTmp+"/"+exports_tag+"_char.json"
    json_file = codecs.open(output_file, "w", "utf-8")
    json_file.write(json_cnt)
    json_file.close()
    print("- makeCharDescription: char defn saved", output_file)

def exportDoc(psd_doc, basepath, pngname, cropLayer, offsLayer, fixedSquareSize):
    # https://stackoverflow.com/questions/15482280/gimp-python-fu-exporting-file-only-exports-transparent-layer
    # https://github.com/jfmdev/PythonFuSamples/blob/master/test-save-to-files.py
    if cropLayer is None:
        print("- exportDoc failed: no cropLayer", pngname)
        return "?"
    exportPngName = pngname
    cropBnd = getLayerBounds(cropLayer)
    if cropBnd["width"] < 1 or cropBnd["height"] < 1:
        print(">>> cropLayer invalid", pngname, cropBnd)
        return "?"
    offsBnd = None
    if offsLayer is not None:
        offsBnd = getLayerBounds(offsLayer)
        if offsBnd["width"] < 1 or offsBnd["height"] < 1:
            print(">>> offsLayer invalid", pngname, offsBnd)
            return "?"
    rescale = 1.0
    if fixedSquareSize > 0:
        cropBnd["width"] = max(cropBnd["width"],cropBnd["height"])
        cropBnd["height"] = max(cropBnd["width"],cropBnd["height"])
        sclx = float(fixedSquareSize)/cropBnd["width"]
        scly = float(fixedSquareSize)/cropBnd["height"]
        rescale = rescale*min(sclx,scly)
        while int(rescale*cropBnd["width"])<fixedSquareSize or int(rescale*cropBnd["height"])<fixedSquareSize:
            rescale = rescale + 0.001
    if cropBnd["x"] < 0:
        cropBnd["x"] = 0
    if cropBnd["y"] < 0:
        cropBnd["y"] = 0
    print("- exportDoc cropping:", pngname, cropBnd, rescale)
    psd_doc_copy = pdb.gimp_image_duplicate(psd_doc)
    psd_doc_copy.disable_undo()
    if exportDebug:
        psd_doc_copy_display = pdb.gimp_display_new(psd_doc_copy) # debug
    # x/y must be bigger than 0, width/height must be less/equal document size
    pdb.gimp_image_crop(psd_doc_copy, cropBnd["width"], cropBnd["height"], cropBnd["x"], cropBnd["y"])
    if rescale < 1.0: 
        pdb.gimp_image_scale_full(psd_doc_copy, int(cropBnd["width"]*rescale), int(cropBnd["height"]*rescale), INTERPOLATION_CUBIC)
    exportPngNameCropped = exportPngName
    if offsBnd is not None:
        exportPngNameCropped = exportPngNameCropped+"_ox"+str(int(rescale*(cropBnd["x"]+cropBnd["width"]*0.5-(offsBnd["x"]+offsBnd["width"]*0.5))))
        exportPngNameCropped = exportPngNameCropped+"_oy"+str(int(rescale*(cropBnd["y"]+cropBnd["height"]*0.5-(offsBnd["y"]+offsBnd["height"]*0.5))))
    exportPngNameCropped = exportPngNameCropped+"_ww"+str(int(rescale*cropBnd["width"]))+"_hh"+str(int(rescale*cropBnd["height"]))
    exportPngFileCropped = basepath+"/"+exportPngNameCropped+".png"
    resetSublayersToImage(psd_doc_copy, psd_doc_copy)
    flat_layer = pdb.gimp_image_merge_visible_layers(psd_doc_copy, EXPAND_AS_NECESSARY)
    pdb.file_png_save_defaults(psd_doc_copy, flat_layer, exportPngFileCropped, exportPngNameCropped+".png")
    #pdb.gimp_file_save(GIMP_RUN_NONINTERACTIVE, psd_doc_copy, layer, exportPngFileCropped, '?')
    if not exportDebug:
        pdb.gimp_image_delete(psd_doc_copy)
    exportPngName = exportPngNameCropped
    return exportPngName

def makePngExport(psd_doc, char_desc):
    all_layers = []
    enum_all_layers(psd_doc, all_layers)
    #print "all_layers:", all_layers
    exports = char_desc["exports"]
    exports_tag = char_desc["actor_tag"]
    exportRefsPath = char_desc["exportRefsPath"]
    exportToTmp = chardesc_target_dir(char_desc)
    ensure_dir(exportToTmp)
    json_cnt = "{\"vn_refs:char_"+exports_tag+"\": {"
    exported_idx = 0
    exported_errs = 0
    if psd_doc is not None:
        for line in exports:
            exported_idx = exported_idx+1
            if json_cnt.endswith('"'):
                json_cnt = json_cnt + ","
            hideSublayers(psd_doc, psd_doc)
            line_t = line[0]
            if line_t not in char_desc:
                print("- WARN: export type not found: "+line_t)
                #exportErrors.append(err)
                exported_errs = exported_errs+1
                continue
            outputCropset = char_desc[line_t]
            outputFileBase = line[1]
            sceneLayerName = line[2]
            sceneLayer = findSublayerByName(psd_doc, sceneLayerName)
            sublayers = line[3].split("+")
            for sublname in sublayers:
                subl = findSublayerByName(sceneLayer, sublname)
                if subl is None:
                    print("- WARN: layer not found: "+sceneLayerName+"/"+sublname)
                    #exportErrors.append(err)
                    exported_errs = exported_errs+1
                    continue
                showLayer(subl)
            cropLayer = findSublayerByName(sceneLayer, outputCropset["bounds_main"])
            if cropLayer is None:
                cropLayer = findSublayerByName(psd_doc, outputCropset["bounds_main"])
            if cropLayer is None:
                print("- WARN: cropLayer not found: "+outputCropset["bounds_main"])
                #exportErrors.append(err)
                exported_errs = exported_errs+1
                continue
            offsLayer = findSublayerByName(sceneLayer, outputCropset["bounds_rel"])
            if offsLayer is None:
                offsLayer = findSublayerByName(psd_doc, outputCropset["bounds_rel"])
            respath = exportDoc(psd_doc, exportToTmp, outputFileBase, cropLayer, offsLayer, outputCropset["fixed_size"])
            print("- Export", "#"+str(exported_idx)+"/"+str(len(exports)), respath)
            if len(respath) > 1:
                json_cnt = json_cnt+ "\n\t\t\""+outputFileBase+"\": \""+exportRefsPath+respath+".png"+"\""
            else:
                exported_errs = exported_errs+1
            #break
    json_cnt = json_cnt + "\n\t}}"
    json_file = open(exportToTmp+"/"+exports_tag+"_refs.json", "w")
    json_file.write(json_cnt)
    json_file.close()
    print("- makePngExport: all saved", exported_errs, exported_idx, len(exports))
    return exported_errs

# ================= ================== =============== =============== ===============

def wpl_export_char(psd_doc, args) :
    #pdb.gimp_image_undo_group_start(psd_doc)
    char_desc = json.loads(args)
    if ("exportTarget" not in char_desc) or (not os.path.exists(char_desc["exportTarget"])):
        pdb.gimp_message('ERROR! exportTarget path not found')
        return
    exportTarget = char_desc["exportTarget"]
    sys.stderr = open( os.path.join(exportTarget,'gimpstderr.txt'), 'w')
    sys.stdout = open( os.path.join(exportTarget,'gimpstdout.txt'), 'w')
    #print "psd_doc", psd_doc
    #print "char_desc:", char_desc
    makeCharDescription(char_desc)
    psd_doc_copy = pdb.gimp_image_duplicate(psd_doc)
    psd_doc_copy.disable_undo()
    if exportMaxHeight < psd_doc_copy.height:
        globalScale = float(exportMaxHeight)/float(psd_doc_copy.height-1)
        doc_ww = int(float(psd_doc_copy.width)*globalScale)
        doc_hh = int(float(psd_doc_copy.height)*globalScale)
        print("- Scaling to",doc_ww,doc_hh)
        pdb.gimp_progress_init("Scaling Image...",None)
        pdb.gimp_context_set_interpolation(INTERPOLATION_LANCZOS)
        pdb.gimp_image_scale(psd_doc_copy, doc_ww, doc_hh)
    pdb.gimp_progress_init("Exporting parts...",None)
    if exportDebug:
        psd_doc_copy_display = pdb.gimp_display_new(psd_doc_copy) # debug
    errs = makePngExport(psd_doc_copy,char_desc)
    pdb.gimp_progress_end()
    #pdb.gimp_image_undo_group_end(psd_doc_copy)
    if not exportDebug:
        pdb.gimp_image_delete(psd_doc_copy)
    pdb.gimp_message('DONE! errs='+str(errs))

register( 
    "python-fu-wpl-export-char",                           
    "WPL: Export character",
    "WPL: Export character",
    "IPv6",
    "IPv6",
    "2019",
    "Export character",
    "RGBA", 
    [
        (PF_IMAGE, "image", "Current PSD", None),
        (PF_STRING, "char_description", "Character JSON", "???")
    ],
    [],
    wpl_export_char,
    menu="<Image>/WPLExport")

# https://habr.com/ru/post/135863/
# https://www.gimp.org/docs/python/index.html
# https://developer.gimp.org/api/2.0/libgimp/index.html
# GIMP auto-execution stub - https://ntcore.com/?p=509
# if __name__ == "__main__":
#     import os, sys, subprocess
#     if len(sys.argv) < 2:
#         print("you must specify a function to execute!")
#         sys.exit(-1)
#     scrdir = os.path.dirname(os.path.realpath(__file__))
#     scrname = os.path.splitext(os.path.basename(__file__))[0]
#     shcode = "import sys;sys.path.insert(0, '" + scrdir + "');import " + scrname + ";" + scrname + "." + sys.argv[1] + str(tuple(sys.argv[2:]))
#     shcode = "gimp-console -idf --batch-interpreter python-fu-eval -b \"" + shcode + "\" -b \"pdb.gimp_quit(1)\""
#     sys.exit(subprocess.call(shcode, shell=True))
# else:
#     from gimpfu import *

main()
