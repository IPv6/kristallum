#!/usr/bin/env python
# -*- coding: utf-8 -*-

# MacOs: 
# - script must be executable! chmod +x *.py
# - script path must be in PLUGINS dirs
# /Applications/Gimp-2.10.app/Contents/MacOS/gimp --verbose;

print '************************* ui_export_gimp.py loading *************************'

# Layers with TAG: layer hidden except when export claim this tag
# Layers with HIDE: SYS: TBD: -> just hidden on any export
# Layers with EXPORT: -> actual export to PNG.
# // <folder>/<name>; <elemTag>, <elemTag>, ...

from gimpfu import *
import json
import math
import sys
import os
import codecs
import datetime

def ensure_dir(directory):
    if not os.path.exists(directory):
        os.makedirs(directory)

def enum_all_layers(root_group, all_layers):
    for layer in root_group.layers:
        all_layers.append(layer)
        if isinstance(layer, gimp.GroupLayer):
            all_layers.append(layer)
            enum_all_layers(layer, all_layers)
    return

def isSameName(layerName, name):
    if layerName == name:
        return True
    if layerName.startswith(name+" #"):
        return True
    return False

def hideSublayers(psd_doc, rootLayer):
    if rootLayer is None:
        return
    if isinstance(rootLayer, gimp.GroupLayer) or isinstance(rootLayer, gimp.Layer):
        rootLayer.visible = False
    if isinstance(rootLayer, gimp.GroupLayer) or isinstance(rootLayer, gimp.Image):
        for layer in rootLayer.layers:
            layer.visible = False
            hideSublayers(psd_doc, layer)

def showLayer(layer):
    if isinstance(layer, gimp.GroupLayer) or isinstance(layer, gimp.Layer):
        layer.visible = True
    parent = layer.parent
    if parent is not None:
        showLayer(parent)

def getLayerBounds(layer):
    bnd = {}
    bnd["x"] = float(int(layer.offsets[0]))
    bnd["y"] = float(int(layer.offsets[1]))
    bnd["width"] = float(int(layer.width))
    bnd["height"] = float(int(layer.height))
    return bnd

def resetSublayersToImage(psd_doc, rootLayer):
    if rootLayer is None:
        return
    if isinstance(rootLayer, gimp.GroupLayer) or isinstance(rootLayer, gimp.Layer):
        #pdb.gimp_image_set_active_layer(psd_doc, rootLayer)
        pdb.gimp_layer_resize_to_image_size(rootLayer)
    if isinstance(rootLayer, gimp.GroupLayer) or isinstance(rootLayer, gimp.Image):
        for layer in rootLayer.layers:
            resetSublayersToImage(psd_doc, layer)

# ================= ================== =============== =============== ===============

def wpl_export_ui(psd_doc, exportTarget) :
    ensure_dir(exportTarget)
    sys.stderr = open( os.path.join(exportTarget,'__gimpstderr.txt'), 'w')
    sys.stdout = open( os.path.join(exportTarget,'__gimpstdout.txt'), 'w')
    all_layers = []
    enum_all_layers(psd_doc, all_layers)
    exports = 0
    pdb.gimp_progress_init("Exporting parts...",None)
    # hiding system layers...
    layer_2export = {}
    layer_2tag = {}
    for l0 in all_layers:
        if "TAG:" in l0.name:
            tagName = l0.name
            tagName = tagName.replace(" ","")
            tagName = tagName.replace("TAG:","")
            tagName = tagName.strip().lower()
            layer_2tag[tagName] = l0
            continue
        if "EXPORT:" in l0.name:
            layerData = getLayerBounds(l0)
            layerTags = []
            fileName = l0.name
            fileName = fileName.replace(" ","")
            fileName = fileName.replace(".","_")
            fileName = fileName.replace("+",",")
            fileName = fileName.replace("\\","/")
            fileName = fileName.replace("TAG:","")
            fileName = fileName.replace("SYS:","")
            fileName = fileName.replace("HIDE:","")
            fileName = fileName.replace("EXPORT:","")
            if ";" in fileName:
                parts = fileName.partition(";")
                fileName = parts[0]
                tagsList = parts[2]
                for tg in tagsList.split(","):
                    layerTags.append(tg.strip().lower())
            layerData["fileName"] = fileName
            layerData["layerTags"] = layerTags
            layer_2export[l0.name] = layerData
    for l1 in all_layers:
        if l1.name not in layer_2export:
            continue
        # This layer should be exported
        cropBnd = layer_2export[l1.name]
        fileName = cropBnd["fileName"]
        print(">>> exporting", l1.name, fileName, cropBnd)
        # initializing visibility. Disabling ALL tagged layers. All untagged are visible (group roots, etc)
        for l2 in all_layers:
            if ("TAG:" in l2.name) or ("HIDE:" in l2.name) or ("SYS:" in l2.name) or ("TBD:" in l2.name) or ("EXPORT:" in l2.name):
                l2.visible = False
            else:
                l2.visible = True
        if ("HIDE:" in l1.name) or ("SYS:" in l1.name):
            l1.visible = False # self always visible
        else:
            # by default self/EXPORT always visible
            l1.visible = True
        layerTags = cropBnd["layerTags"]
        for tg in layerTags:
            if tg in layer_2tag:
                l2 = layer_2tag[tg]
                l2.visible = True
        # exporting cropped duplicate
        fileDir = None
        if "/" in fileName:
            # subdir required
            parts = fileName.split("/")
            fileName = parts[-1]
            del parts[-1]
            fileDir = "/".join(parts)
        else:
            # default subdir
            fileDir = "exports"
        exportPngFileCropped = os.path.join(exportTarget, fileName+".png")
        if fileDir is not None:
            exportTarget2 = os.path.join(exportTarget, fileDir)
            ensure_dir(exportTarget2)
            exportPngFileCropped = os.path.join(exportTarget2, fileName+".png")
        psd_doc_copy = pdb.gimp_image_duplicate(psd_doc)
        psd_doc_copy.disable_undo()
        resetSublayersToImage(psd_doc_copy, psd_doc_copy)
        flat_layer = pdb.gimp_image_merge_visible_layers(psd_doc_copy, EXPAND_AS_NECESSARY)
        pdb.gimp_image_crop(psd_doc_copy, cropBnd["width"], cropBnd["height"], cropBnd["x"], cropBnd["y"])
        pdb.file_png_save_defaults(psd_doc_copy, flat_layer, exportPngFileCropped, exportPngFileCropped)
        pdb.gimp_image_delete(psd_doc_copy)
        exports = exports+1
    pdb.gimp_progress_end()
    pdb.gimp_message('DONE! exports='+str(exports))

register( 
    "python-fu-wpl-export-ui",
    "WPL: Export UI",
    "WPL: Export UI",
    "IPv6",
    "IPv6",
    "2019",
    "Export UI",
    "RGBA", 
    [
        (PF_IMAGE, "image", "Current PSD", None),
        (PF_DIRNAME,    'directory',    'Directory',   '.')
    ],
    [],
    wpl_export_ui,
    menu="<Image>/WPLExport")

main()
