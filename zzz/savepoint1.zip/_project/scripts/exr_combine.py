# coding=utf-8
# Combine same files from different folders into one strip
# folders can be out-induced by partal match (compatible with extrude.py)
# --o=out output folder name/path
# --g=3x2 final grid, omit for auto detection (vertical/horizontal)
# --post="..." oiiotool command to postprocess combined image

# MAC
#python3 ~/Documents/zzz_CloudFiles/WPLabs19/_project/scripts/exr_combine.py "/Users/ipv6/Documents/zzz_CloudFiles/Yandex.Disk.localized/_Renders/" --o=out --g=3x2 in1 in2 in3 in4 in5 in6
#python3 ~/Documents/zzz_CloudFiles/WPLabs19/_project/scripts/exr_combine.py "/Users/ipv6/Documents/zzz_tmp/as117/v2/" --o=out_fa --g=3x2 ?fa01 ?fa02 ?fa03 ?fa04 ?fa05 ?fa06
#python3 ~/Documents/zzz_CloudFiles/WPLabs19/_project/scripts/exr_combine.py "/Users/ipv6/Documents/zzz_tmp/???/" --o=out_fb ?fb01 ?fb02 ?fb03 ?fb04
#python3 ~/Documents/zzz_CloudFiles/WPLabs19/_project/scripts/exr_combine.py "/Users/ipv6/Downloads/???/" --o=out_fa ?asis01 ?asis02 ?asis03 ?asis04

# WIN
#python "c:\_WPLabs\BitBucket\wplabs-19\_project\scripts\exr_combine.py" "c:\_WPLabs\YandexDisk\_Renders\" --o=out_fa --g=3x2 in1 in2 in3 in4 in5 in6
#python "c:\_WPLabs\BitBucket\wplabs-19\_project\scripts\exr_combine.py" "c:\_WPLabs\YandexDisk\_Renders\" --o=out_fa --g=3x2 ?fa01 ?fa02 ?fa03 ?fa04 ?fa05 ?fa06
#python "c:\_WPLabs\BitBucket\wplabs-19\_project\scripts\exr_combine.py" "c:\_WPLabs\YandexDisk\_Renders\" --o=out_fb ?fb01 ?fb02 ?fb03 ?fb04
#python "c:\_WPLabs\BitBucket\wplabs-19\_project\scripts\exr_combine.py" "c:\_WPLabs\Downloads\???\" --o=out_fa ?fa01 ?fa02 ?fa03 ?fa04

# POSTPROCESSING
#python3 ~/Documents/zzz_CloudFiles/WPLabs19/_project/scripts/exr_combine.py "/Users/ipv6/Documents/zzz_tmp/as117/v1/" --o=out_fa ?fa05 --post="--cut 1920x1080+0+1226"
# --post: additional commands for combined image
# https://openimageio.readthedocs.io/en/latest/oiiotool.html
# --resize 1920x1080 --resize 50% --resize 0x1024 --cut 128x128+900+300

import re
import os
import sys
import subprocess
import os.path

if len(sys.argv) < 4:
	print('Need path to folders, quitting')
	sys.exit(0)

def setupOiioTool():
	tool_setups = [
		# Windows: vcpkg, as extract.py
		# Windows: needs proper config.ocio (can be found inside Blender installation folder)
		("c:\\_WPLabs\\Programs\\vcpkg\\installed\\x64-windows\\tools\\openimageio\\oiiotool.exe", "c:\\_WPLabs\\Programs\\blender300\\3.0\\datafiles\\colormanagement\\config.ocio"),
		# MAC: brew, as extract.py
		("/usr/local/bin/oiiotool","")
	]
	oiio_exe = "???"
	ocio_conf = "???"
	for stp in tool_setups:
		#print('- Oiiotool path:', stp[0])
		if os.path.exists(stp[0]):
			oiio_exe = stp[0]
			ocio_conf = stp[1]
			break
	print('- Oiiotool path:', oiio_exe)
	if not os.path.exists(oiio_exe):
		print('Invalid path to oiiotool, quitting')
		sys.exit(0)
	oiio_env = os.environ.copy()
	if len(ocio_conf) > 0:
		oiio_env["OCIO"] = ocio_conf
	return oiio_exe, oiio_env
oiio_exe, oiio_env = setupOiioTool()

stats = {}
stats['idx'] = 0
stats['saved'] = 0
stats['skipped'] = 0

def safeStr(outname,lwr):
	outname = outname.replace(".","_")
	outname = outname.replace("+","_")
	outname = outname.replace("/","_")
	outname = outname.replace("\\","_")
	outname = outname.replace("\"","_")
	outname = outname.replace("'","_")
	if lwr:
		outname = outname.lower()
	return outname

def safeStr2(outname):
	outname = safeStr(outname, False)
	outname = outname.replace("_jpeg","")
	outname = outname.replace("_tiff","")
	outname = outname.replace("_png","")
	outname = outname.replace("_jpg","")
	outname = outname.replace("_tif","")
	outname = outname.replace("_bw","")
	outname = outname.replace("_V","")
	return outname

def sortName(fullpath, reverted):
	bnm = os.path.basename(fullpath)
	bnm = safeStr2(bnm).lower()
	if reverted:
		bnm_rev = (bnm[::-1]).ljust(500)
		return bnm_rev
	return bnm

def isStrTokenPresent(teststr, tokens):
	isPresent = False
	for bwmark in tokens:
		if safeStr(bwmark, True) in safeStr(teststr, True):
			isPresent = True
			break
	return isPresent

def allFilesWithSubd(path, extensions):
	#exr_files = os.listdir(exr_folder) # not recursive
	files = []
	# r=root, d=directories, f = files
	for r, d, f in os.walk(path):
		for file_name in f:
			for extn in extensions:
				if '.'+extn.lower() in file_name.lower():
					files.append(os.path.join(r, file_name))
					break
	return files

#####################################
print('- Getting list of files...')
cwd_folder = sys.argv[1] #os.getcwd()
out_folder = "out"
out_grid = []
tool_opts_extra = []
in_folder_files = []
min_files = 999
fl_check = {}
for i in range(2, len(sys.argv)):
	input_template = str(sys.argv[i]).strip()
	if ("--o=" in input_template):
		spl = input_template.replace("--o=","")
		out_folder = spl
		continue
	if ("--g=" in input_template):
		spl = input_template.replace("--g=","")
		spl = spl.split("x")
		if len(spl) == 2:
			out_grid = [int(spl[0]), int(spl[1])]
		continue
	if ("--post=" in input_template):
		spl = input_template.replace("--post=","")
		spl = spl.replace("  "," ")
		spl = spl.split(" ")
		print("- postprocess:", spl)
		tool_opts_extra.append(spl)
		continue
	# input folder
	exr_files = None
	if input_template[0] == '?':
		# mask for set of folders
		# Checking for all folders with proper token
		exr_folder_mask = input_template[1:]
		print("- folders by mask:", exr_folder_mask)
		exr_folders = os.listdir(cwd_folder) # not recursive
		exr_files = []
		for itm_name in exr_folders:
			itm_path = os.path.join(cwd_folder, itm_name)
			if (exr_folder_mask in itm_name) and (os.path.isdir(itm_path)):
				img_inside = allFilesWithSubd(itm_path, ['png','tif','tiff'])
				exr_files = exr_files+img_inside
				#print("\n- ", itm_path, img_inside)
	else:
		# folder path
		exr_folder = input_template
		print("- folder:", exr_folder)
		if not os.path.exists(exr_folder):
			exr_folder = os.path.join(cwd_folder, exr_folder)
		if os.path.exists(exr_folder):
			exr_files = allFilesWithSubd(exr_folder, ['png','tif','tiff'])
	if exr_files is None:
		print('Invalid input, quitting. folder/template=', input_template)
		sys.exit(0)
	#sorting by reversed name+justification. Ignoring folder/path
	exr_files.sort(key=lambda fl: sortName(fl, True) )
	in_folder_files.append(exr_files)
	min_files = min(len(exr_files), min_files)
	for fl in exr_files:
		fl_key = sortName(fl, False)
		if fl_key not in fl_check:
			fl_check[fl_key] = 0
		fl_check[fl_key] = fl_check[fl_key]+1

# constructing full path from folder name
if not os.path.exists(out_folder):
	out_folder = os.path.join(cwd_folder, out_folder)

# sanity check
fl_fails = []
for fl_key in fl_check:
	if fl_check[fl_key] != len(in_folder_files):
		fl_fails.append(fl_key+":"+str(fl_check[fl_key])+"/"+str(len(in_folder_files)))
if len(fl_fails) > 0:
	print('Image mapping mismatch. names=', fl_fails)
	sys.exit(0)

print("- File count (per input):", min_files)
print("- Output folder:", out_folder)
if not os.path.exists(out_folder):
	os.makedirs(out_folder)

def mergeFiles(output_file, in_files, in_grid):
	print( (stats['idx']+1),'.',output_file,' <= ', in_files)
	stats['idx'] = stats['idx']+1
	images = {}
	oiio_call1 = []
	oiio_call1.append(oiio_exe)
	for input_file in in_files:
		oiio_call1.extend( ["-i", input_file] )
		oiio_call1.extend( ["--echo:newline=0", ""+safeStr2(input_file)+" {TOP.width} {TOP.height}"+""] )
		oiio_call1.extend( ["--colorcount:eps=0.001,0.001,0.001,1000", "0,0,0,1"] )
	# ps1 = subprocess.Popen(oiio_call1, stdin = subprocess.PIPE, stdout = subprocess.PIPE, env=oiio_env)
	# (stdout, stderr) = ps1.communicate()
	# imginfo = stdout.splitlines()
	stdres = subprocess.run(oiio_call1, capture_output = True, shell=False, env=oiio_env)
	imginfo = stdres.stdout.splitlines()
	# 3 files example: [b'IMG=1920x1080    6894  0,0,0,1', b'IMG=1920x1080    5751  0,0,0,1', b'IMG=1920x1080    6894  0,0,0,1']
	#print("imginfo=",imginfo)
	max_img_w = 0
	max_img_h = 0
	for line in imginfo:
		line = (line.decode("utf-8")).replace("  "," ")
		line = line.replace("  "," ")
		line = line.replace("  "," ")
		line = line.replace("  "," ")
		spl = line.split(" ")
		idx = len(images)
		if idx < len(in_files):
			if safeStr2(spl[0]) == safeStr2(in_files[idx]):
				# print("File info", spl, line)
				im_w = int(spl[1])
				im_h = int(spl[2])
				max_img_w = max(max_img_w, im_w)
				max_img_h = max(max_img_h, im_h)
				images[in_files[idx]] = [int(spl[3]), 0, 0, im_w, im_h]
			else:
				print("// can`t parse", spl[0])
	if len(images) != len(in_files):
		# failed to gen info on some files!!!
		stats['skipped'] = stats['skipped']+1
		print('-- Skipped: invalid image info', len(images), len(in_files), imginfo)
		#print('// ', " ".join(oiio_call1))
		#print('// -> ', stdres, '\n')
		return
	empty_ims = 0
	for input_file in in_files:
		im_data = images[input_file]
		im_w = im_data[3]
		im_h = im_data[4]
		if len(in_grid) == 0:
			if im_h > im_w:
				in_grid = [ len(in_files), 1 ]
			else:
				in_grid = [ 1, len(in_files) ]
		# checking is image completely black|white|gray|red|blue|green
		if (im_data[0] >= im_w*im_h - 3):
			empty_ims = empty_ims+1
	max_w = in_grid[0]*max_img_w
	max_h = in_grid[1]*max_img_h
	print('-- size:', in_grid, max_w, max_h)
	if empty_ims == len(in_files):
		# all files are empty!!!
		stats['skipped'] = stats['skipped']+1
		print('-- Skipped: monocolor image')
		return
	for iif,input_file in enumerate(in_files):
		im_data = images[input_file]
		grid_x = iif % in_grid[0]
		grid_y = int(iif / in_grid[0])
		im_data[1] = grid_x*max_img_w
		im_data[2] = grid_y*max_img_h
	#######################
	# saving combined image
	# new_im.save(output_file, 'PNG')
	# oiiotool: ok for png and tiffs
	img_pushed = 0
	oiio_call2 = []
	oiio_call2.append(oiio_exe)
	oiio_call2.append("--autocc")
	oiio_call2.append("--no-autopremult") # or semitransparent will be overdarkened
	for input_file in in_files:
		im_data = images[input_file]
		oiio_call2.extend( ["-i", input_file] )
		if ".png" in output_file:
			oiio_call2.extend( ["--tocolorspace", "sRGB"] )
		oiio_call2.extend( ["--fullsize", str(max_w)+"x"+str(max_h)] )
		oiio_call2.extend( ["--origin", "+"+str(im_data[1])+"+"+str(im_data[2])] )
		oiio_call2.extend( ["--crop", str(im_data[3])+"x"+str(im_data[4])+"+"+str(im_data[1])+"+"+str(im_data[2])] )
		if img_pushed > 0:
			oiio_call2.append( "--over" )
		#oiio_call2.extend( ["-o", output_file.replace(".",str(img_pushed)+"z.")] )
		img_pushed = img_pushed+1
	if len(tool_opts_extra) > 0:
		for ppstep in tool_opts_extra:
			oiio_call2.extend(ppstep)
	# output file
	oiio_call2.extend( ["-o", output_file] )
	#print("-- oiio_call command line:",oiio_call2)
	ps1 = subprocess.Popen(oiio_call2, stdin = subprocess.PIPE, stdout = subprocess.PIPE, env=oiio_env)
	(stdout, stderr) = ps1.communicate()
	print('-- Saved')
	stats['saved'] = stats['saved']+1
	return

for idx in range(0,min_files):
	out_file = ""
	strip_files = []
	for jdx in range(0, len(in_folder_files)):
		fls = in_folder_files[jdx]
		file_name = fls[idx]
		strip_files.append(file_name)
		if len(out_file) == 0:
			exten = "png"
			if isStrTokenPresent(file_name, ['tif','tiff']):
				exten = "tif"
			out_file = os.path.join(out_folder, safeStr2(os.path.split(file_name)[1])+"."+exten)
	mergeFiles(out_file, strip_files, out_grid)

print("- All done. Saved: "+str(stats['saved'])+", Skipped: "+str(stats['skipped']))